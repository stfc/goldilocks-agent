import { n as e } from "./rolldown-runtime-DtPi1Y-2.js";
import * as t from "react";
import n, { Activity as r, Children as i, Fragment as a, cloneElement as o, createContext as s, createElement as c, forwardRef as l, use as u, useCallback as d, useContext as f, useEffect as p, useEffectEvent as m, useId as h, useLayoutEffect as g, useMemo as _, useRef as v, useState as y, useSyncExternalStore as b } from "react";
import x, { createPortal as S, flushSync as C } from "react-dom";
import { Fragment as w, jsx as T, jsxs as E } from "react/jsx-runtime";
//#region node_modules/@mantine/core/esm/core/utils/keys/keys.mjs
function D(e) {
	return Object.keys(e);
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/deep-merge/deep-merge.mjs
function O(e) {
	return e && typeof e == "object" && !Array.isArray(e);
}
function k(e, t) {
	let n = { ...e }, r = t;
	return O(e) && O(t) && Object.keys(t).forEach((t) => {
		O(r[t]) && t in e ? n[t] = k(n[t], r[t]) : n[t] = r[t];
	}), n;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/camel-to-kebab-case/camel-to-kebab-case.mjs
function ee(e) {
	return e.replace(/[A-Z]/g, (e) => `-${e.toLowerCase()}`);
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/units-converters/px.mjs
function A(e) {
	return typeof e != "string" || !e.includes("var(--mantine-scale)") ? e : e.match(/^calc\((.*?)\)$/)?.[1].split("*")[0].trim();
}
function j(e) {
	let t = A(e);
	return typeof t == "number" ? t : typeof t == "string" ? t.includes("calc") || t.includes("var") ? t : t.includes("px") ? Number(t.replace("px", "")) : t.includes("rem") ? Number(t.replace("rem", "")) * 16 : t.includes("em") ? Number(t.replace("em", "")) * 16 : Number(t) : NaN;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/units-converters/rem.mjs
function M(e) {
	return e === "0rem" ? "0rem" : `calc(${e} * var(--mantine-scale))`;
}
function N(e, { shouldScale: t = !1 } = {}) {
	function n(r) {
		if (r === 0 || r === "0") return `0${e}`;
		if (typeof r == "number") {
			let n = `${r / 16}${e}`;
			return t ? M(n) : n;
		}
		if (typeof r == "string") {
			if (r === "" || r.startsWith("calc(") || r.startsWith("clamp(") || r.includes("rgba(")) return r;
			if (r.includes(",")) return r.split(",").map((e) => n(e)).join(",");
			if (r.includes(" ")) return r.split(" ").map((e) => n(e)).join(" ");
			let i = r.replace("px", "");
			if (!Number.isNaN(Number(i))) {
				let n = `${Number(i) / 16}${e}`;
				return t ? M(n) : n;
			}
		}
		return r;
	}
	return n;
}
var P = N("rem", { shouldScale: !0 }), te = N("em");
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/filter-props/filter-props.mjs
function ne(e) {
	return Object.keys(e).reduce((t, n) => (e[n] !== void 0 && (t[n] = e[n]), t), {});
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/is-number-like/is-number-like.mjs
function F(e) {
	if (typeof e == "number") return !0;
	if (typeof e == "string") {
		if (e.startsWith("calc(") || e.startsWith("var(") || e.includes(" ") && e.trim() !== "") return !0;
		let t = /^[+-]?[0-9]+(\.[0-9]+)?(px|em|rem|ex|ch|lh|rlh|vw|vh|vmin|vmax|vb|vi|svw|svh|lvw|lvh|dvw|dvh|cm|mm|in|pt|pc|q|cqw|cqh|cqi|cqb|cqmin|cqmax|%)?$/;
		return e.trim().split(/\s+/).every((e) => t.test(e));
	}
	return !1;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/is-element/is-element.mjs
function I(e) {
	return Array.isArray(e) || e === null ? !1 : typeof e == "object" && e.type !== a;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/create-safe-context/create-safe-context.mjs
function re(e) {
	let t = s(null);
	return [t, () => {
		let n = u(t);
		if (n === null) throw Error(e);
		return n;
	}];
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/get-safe-id/get-safe-id.mjs
function L(e, t) {
	return (n) => {
		if (typeof n != "string" || n.trim().length === 0) throw Error(t);
		return `${e}-${n}`;
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/find-element-ancestor/find-element-ancestor.mjs
function R(e, t) {
	let n = e;
	for (; (n = n.parentElement) && !n.matches(t););
	return n;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/create-scoped-keydown-handler/create-scoped-keydown-handler.mjs
function z(e, t, n) {
	for (let n = e - 1; n >= 0; --n) if (!t[n].disabled) return n;
	if (n) {
		for (let e = t.length - 1; e > -1; --e) if (!t[e].disabled) return e;
	}
	return e;
}
function ie(e, t, n) {
	for (let n = e + 1; n < t.length; n += 1) if (!t[n].disabled) return n;
	if (n) {
		for (let e = 0; e < t.length; e += 1) if (!t[e].disabled) return e;
	}
	return e;
}
function ae(e, t, n) {
	return R(e, n) === R(t, n);
}
function oe({ parentSelector: e, siblingSelector: t, onKeyDown: n, loop: r = !0, activateOnFocus: i = !1, dir: a = "rtl", orientation: o }) {
	return (s) => {
		n?.(s);
		let c = Array.from(R(s.currentTarget, e)?.querySelectorAll(t) || []).filter((t) => ae(s.currentTarget, t, e)), l = c.findIndex((e) => s.currentTarget === e), u = ie(l, c, r), d = z(l, c, r), f = a === "rtl" ? d : u, p = a === "rtl" ? u : d;
		switch (s.key) {
			case "ArrowRight":
				o === "horizontal" && (s.stopPropagation(), s.preventDefault(), c[f].focus(), i && c[f].click());
				break;
			case "ArrowLeft":
				o === "horizontal" && (s.stopPropagation(), s.preventDefault(), c[p].focus(), i && c[p].click());
				break;
			case "ArrowUp":
				o === "vertical" && (s.stopPropagation(), s.preventDefault(), c[d].focus(), i && c[d].click());
				break;
			case "ArrowDown":
				o === "vertical" && (s.stopPropagation(), s.preventDefault(), c[u].focus(), i && c[u].click());
				break;
			case "Home":
				s.stopPropagation(), s.preventDefault(), c[ie(-1, c, !1)]?.focus();
				break;
			case "End": s.stopPropagation(), s.preventDefault(), c[z(c.length, c, !1)]?.focus();
		}
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/get-default-z-index/get-default-z-index.mjs
var se = {
	app: 100,
	modal: 200,
	popover: 300,
	overlay: 400,
	max: 9999
};
function ce(e) {
	return se[e];
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/noop/noop.mjs
var le = () => {};
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/get-size/get-size.mjs
function B(e, t = "size", n = !0) {
	if (e !== void 0) return F(e) ? n ? P(e) : e : `var(--${t}-${e})`;
}
function V(e) {
	return B(e, "mantine-spacing");
}
function ue(e) {
	return e === void 0 ? "var(--mantine-radius-default)" : B(e, "mantine-radius");
}
function H(e) {
	return B(e, "mantine-font-size");
}
function de(e) {
	return B(e, "mantine-line-height", !1);
}
function U(e) {
	if (e) return B(e, "mantine-shadow", !1);
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/get-breakpoint-value/get-breakpoint-value.mjs
function fe(e, t) {
	return e in t ? j(t[e]) : j(e);
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/get-sorted-breakpoints/get-sorted-breakpoints.mjs
function pe(e, t) {
	let n = e.map((e) => ({
		value: e,
		px: fe(e, t)
	}));
	return n.sort((e, t) => e.px - t.px), n;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/get-base-value/get-base-value.mjs
function me(e) {
	return typeof e == "object" && e ? "base" in e ? e.base : void 0 : e;
}
//#endregion
//#region node_modules/@mantine/hooks/esm/utils/clamp/clamp.mjs
function he(e, t, n) {
	return t === void 0 && n === void 0 ? e : t !== void 0 && n === void 0 ? Math.max(e, t) : Math.min(t === void 0 && n !== void 0 ? e : Math.max(e, t), n);
}
//#endregion
//#region node_modules/@mantine/hooks/esm/utils/random-id/random-id.mjs
function ge(e = "mantine-") {
	return `${e}${Math.random().toString(36).slice(2, 11)}`;
}
//#endregion
//#region node_modules/@mantine/hooks/esm/utils/use-callback-ref/use-callback-ref.mjs
function _e(e) {
	let t = v(e);
	return p(() => {
		t.current = e;
	}), _(() => ((...e) => t.current?.(...e)), []);
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-debounced-callback/use-debounced-callback.mjs
function ve(e, t) {
	let { delay: n, flushOnUnmount: r, leading: i, maxWait: a } = typeof t == "number" ? {
		delay: t,
		flushOnUnmount: !1,
		leading: !1,
		maxWait: void 0
	} : t, o = _e(e), s = v(0), c = v(0), l = v(null), u = _(() => {
		let e = Object.assign((...t) => {
			window.clearTimeout(s.current), l.current = t;
			let r = e._isFirstCall;
			e._isFirstCall = !1;
			function u() {
				window.clearTimeout(s.current), window.clearTimeout(c.current), s.current = 0, c.current = 0, e._isFirstCall = !0, e._hasPendingCallback = !1;
			}
			function d() {
				a !== void 0 && c.current === 0 && (c.current = window.setTimeout(() => {
					if (s.current !== 0) {
						let e = l.current;
						u(), o(...e);
					}
				}, a));
			}
			if (i && r) {
				o(...t), e.flush = () => {
					s.current !== 0 && (u(), o(...t));
				}, e.cancel = () => {
					u();
				}, s.current = window.setTimeout(() => {
					u();
				}, n), d();
				return;
			}
			if (i && !r) {
				e._hasPendingCallback = !0, e.flush = () => {
					s.current !== 0 && (u(), o(...t));
				}, e.cancel = () => {
					u();
				}, s.current = window.setTimeout(() => {
					u();
				}, n), d();
				return;
			}
			e._hasPendingCallback = !0;
			let f = () => {
				s.current !== 0 && (u(), o(...t));
			};
			e.flush = f, e.cancel = () => {
				u();
			}, s.current = window.setTimeout(f, n), d();
		}, {
			flush: () => {},
			cancel: () => {},
			isPending: () => e._hasPendingCallback,
			_isFirstCall: !0,
			_hasPendingCallback: !1
		});
		return e;
	}, [
		o,
		n,
		i,
		a
	]);
	return p(() => () => {
		r ? u.flush() : u.cancel();
	}, [u, r]), u;
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-media-query/use-media-query.mjs
function ye(e, t) {
	return typeof t == "boolean" ? t : typeof window < "u" && "matchMedia" in window && window.matchMedia(e).matches;
}
function be(e, t, { getInitialValueInEffect: n } = { getInitialValueInEffect: !0 }) {
	let [r, i] = y(n ? t : ye(e));
	return p(() => {
		try {
			if ("matchMedia" in window) {
				let t = window.matchMedia(e);
				i(t.matches);
				let n = (e) => i(e.matches);
				return t.addEventListener("change", n), () => {
					t.removeEventListener("change", n);
				};
			}
		} catch {
			return;
		}
	}, [e]), r || !1;
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-color-scheme/use-color-scheme.mjs
function xe(e, t) {
	return be("(prefers-color-scheme: dark)", e === "dark", t) ? "dark" : "light";
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-isomorphic-effect/use-isomorphic-effect.mjs
var Se = typeof document < "u" ? g : p;
//#endregion
//#region node_modules/@mantine/hooks/esm/use-did-update/use-did-update.mjs
function W(e, t) {
	let n = v(!1);
	p(() => () => {
		n.current = !1;
	}, []), p(() => {
		if (n.current) return e();
		n.current = !0;
	}, t);
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-focus-return/use-focus-return.mjs
function Ce({ opened: e, shouldReturnFocus: t = !0 }) {
	let n = v(null), r = () => {
		n.current && "focus" in n.current && typeof n.current.focus == "function" && n.current?.focus({ preventScroll: !0 });
	};
	return W(() => {
		let i = -1, a = (e) => {
			e.key === "Tab" && window.clearTimeout(i);
		};
		if (document.addEventListener("keydown", a), e) n.current = document.activeElement;
		else if (t) {
			let e = document.activeElement;
			i = window.setTimeout(() => {
				let t = document.activeElement;
				(t === null || t === document.body || t === e) && r();
			}, 10);
		}
		return () => {
			window.clearTimeout(i), document.removeEventListener("keydown", a);
		};
	}, [e, t]), r;
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-focus-trap/tabbable.mjs
var we = /input|select|textarea|button|object/, Te = "a, input, select, textarea, button, object, [tabindex]";
function Ee(e) {
	return e.style.display === "none";
}
function De(e) {
	if (e.getAttribute("aria-hidden") || e.getAttribute("hidden") || e.getAttribute("type") === "hidden") return !1;
	let t = e;
	for (; t && t !== document.body && t.nodeType !== 11;) {
		if (Ee(t)) return !1;
		t = t.parentNode;
	}
	return !0;
}
function Oe(e) {
	let t = e.getAttribute("tabindex");
	return t === null && (t = void 0), parseInt(t, 10);
}
function ke(e) {
	let t = e.nodeName.toLowerCase(), n = !Number.isNaN(Oe(e));
	return (we.test(t) && !e.disabled || e instanceof HTMLAnchorElement && e.href || n) && De(e);
}
function Ae(e) {
	let t = Oe(e);
	return (Number.isNaN(t) || t >= 0) && ke(e);
}
function je(e) {
	return Array.from(e.querySelectorAll(Te)).filter(Ae);
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-focus-trap/scope-tab.mjs
function Me(e, t) {
	let n = je(e);
	if (!n.length) {
		t.preventDefault();
		return;
	}
	let r = n[t.shiftKey ? 0 : n.length - 1], i = e.getRootNode(), a = r === i.activeElement || e === i.activeElement, o = i.activeElement;
	if (o.tagName === "INPUT" && o.getAttribute("type") === "radio" && (a = n.filter((e) => e.getAttribute("type") === "radio" && e.getAttribute("name") === o.getAttribute("name")).includes(r)), !a) return;
	t.preventDefault();
	let s = n[t.shiftKey ? n.length - 1 : 0];
	s && s.focus();
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-focus-trap/use-focus-trap.mjs
function Ne(e = !0) {
	let t = v(null), n = (e) => {
		let t = e.querySelector("[data-autofocus]");
		if (!t) {
			let n = Array.from(e.querySelectorAll(Te));
			t = n.find(Ae) || n.find(ke) || null, !t && ke(e) && (t = e);
		}
		t ? t.focus({ preventScroll: !0 }) : console.warn("[@mantine/hooks/use-focus-trap] Failed to find focusable element within provided node", e);
	}, r = d((r) => {
		if (e) {
			if (r === null) {
				t.current = null;
				return;
			}
			t.current !== r && (setTimeout(() => {
				r.getRootNode() ? n(r) : console.warn("[@mantine/hooks/use-focus-trap] Ref node is not part of the dom", r);
			}), t.current = r);
		}
	}, [e]);
	return p(() => {
		if (!e) return;
		t.current && setTimeout(() => {
			t.current && n(t.current);
		});
		let r = (e) => {
			e.key === "Tab" && t.current && Me(t.current, e);
		};
		return document.addEventListener("keydown", r), () => document.removeEventListener("keydown", r);
	}, [e]), r;
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-id/use-id.mjs
function Pe(e) {
	let t = h(), [n, r] = y(`mantine-${t.replace(/:/g, "")}`), i = v(!1);
	return Se(() => {
		i.current || (i.current = !0, r(ge()));
	}, []), typeof e == "string" ? e : n;
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-window-event/use-window-event.mjs
function Fe(e, t, n) {
	let r = m(t);
	p(() => (window.addEventListener(e, r, n), () => window.removeEventListener(e, r, n)), [e]);
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-merged-ref/use-merged-ref.mjs
function Ie(e, t) {
	if (typeof e == "function") return e(t);
	typeof e == "object" && e && "current" in e && (e.current = t);
}
function Le(...e) {
	let t = /* @__PURE__ */ new Map();
	return (n) => {
		if (e.forEach((e) => {
			let r = Ie(e, n);
			r && t.set(e, r);
		}), t.size > 0) return () => {
			e.forEach((e) => {
				let n = t.get(e);
				n && typeof n == "function" ? n() : Ie(e, null);
			}), t.clear();
		};
	};
}
function Re(...e) {
	return d(Le(...e), e);
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-uncontrolled/use-uncontrolled.mjs
function ze({ value: e, defaultValue: t, finalValue: n, onChange: r = () => {} }) {
	let [i, a] = y(t === void 0 ? n : t);
	return e === void 0 ? [
		i,
		(e, ...t) => {
			a(e), r?.(e, ...t);
		},
		!1
	] : [
		e,
		r,
		!0
	];
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-reduced-motion/use-reduced-motion.mjs
function Be(e, t) {
	return be("(prefers-reduced-motion: reduce)", e, t);
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-collapse/use-collapse.mjs
function Ve(e) {
	if (!e || typeof e == "string") return 0;
	let t = e / 36;
	return Math.round((4 + 15 * t ** .25 + t / 5) * 10);
}
function He(e) {
	return e.current ? e.current.scrollHeight : "auto";
}
function Ue({ transitionDuration: e, transitionTimingFunction: t = "ease", onTransitionEnd: n, onTransitionStart: r, expanded: i, keepMounted: a }) {
	let o = {
		height: 0,
		overflow: "hidden",
		...a ? {} : { display: "none" }
	}, s = m(() => r?.()), c = v(null), [l, u] = y(i ? {} : o), [d, f] = y(i ? "entered" : "exited"), p = (e) => {
		C(() => u(e));
	}, h = (e) => {
		p((t) => ({
			...t,
			...e
		}));
	}, g = (n) => {
		let r = e ?? Ve(n);
		return { transition: `height ${r}ms ${t}, opacity ${r}ms ${t}` };
	};
	W(() => {
		e !== 0 && s(), i ? window.requestAnimationFrame(() => {
			C(() => f("entering")), h({
				willChange: "height",
				display: "block",
				overflow: "hidden"
			}), window.requestAnimationFrame(() => {
				let e = He(c);
				h({
					...g(e),
					height: e
				});
			});
		}) : window.requestAnimationFrame(() => {
			C(() => f("exiting"));
			let e = He(c);
			h({
				...g(e),
				willChange: "height",
				height: e
			}), window.requestAnimationFrame(() => h({
				height: 0,
				overflow: "hidden"
			}));
		});
	}, [i]);
	let _ = (e) => {
		if (e.target === c.current && e.propertyName === "height") {
			if (i) {
				let e = He(c);
				e === l.height ? p({}) : h({ height: e }), f("entered"), n?.();
			} else l.height === 0 && (p(o), f("exited"), n?.());
		}
	};
	return {
		state: d,
		getCollapseProps: (e) => ({
			"aria-hidden": !i,
			inert: !i,
			ref: Le(c, e?.ref),
			onTransitionEnd: _,
			style: {
				boxSizing: "border-box",
				...e?.style,
				...l
			}
		})
	};
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-collapse/use-horizontal-collapse.mjs
function We(e) {
	if (!e || typeof e == "string") return 0;
	let t = e / 36;
	return Math.round((4 + 15 * t ** .25 + t / 5) * 10);
}
function Ge(e) {
	return e.current ? e.current.scrollWidth : "auto";
}
function Ke({ transitionDuration: e, transitionTimingFunction: t = "ease", onTransitionEnd: n, onTransitionStart: r, expanded: i, keepMounted: a }) {
	let o = {
		width: 0,
		overflow: "hidden",
		...a ? {} : { display: "none" }
	}, s = m(() => r?.()), c = v(null), [l, u] = y(i ? {} : o), [d, f] = y(i ? "entered" : "exited"), p = (e) => {
		C(() => u(e));
	}, h = (e) => {
		p((t) => ({
			...t,
			...e
		}));
	}, g = (n) => {
		let r = e ?? We(n);
		return { transition: `width ${r}ms ${t}, opacity ${r}ms ${t}` };
	};
	W(() => {
		e !== 0 && s(), i ? window.requestAnimationFrame(() => {
			C(() => f("entering")), h({
				willChange: "width",
				display: "block",
				overflow: "hidden"
			}), window.requestAnimationFrame(() => {
				let e = Ge(c);
				h({
					...g(e),
					width: e
				});
			});
		}) : window.requestAnimationFrame(() => {
			C(() => f("exiting"));
			let e = Ge(c);
			h({
				...g(e),
				willChange: "width",
				width: e
			}), window.requestAnimationFrame(() => h({
				width: 0,
				overflow: "hidden"
			}));
		});
	}, [i]);
	let _ = (e) => {
		if (e.target === c.current && e.propertyName === "width") {
			if (i) {
				let e = Ge(c);
				e === l.width ? p({}) : h({ width: e }), f("entered"), n?.();
			} else l.width === 0 && (p(o), f("exited"), n?.());
		}
	};
	return {
		state: d,
		getCollapseProps: (e) => ({
			"aria-hidden": !i,
			inert: !i,
			ref: Le(c, e?.ref),
			onTransitionEnd: _,
			style: {
				boxSizing: "border-box",
				...e?.style,
				...l
			}
		})
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/get-env/get-env.mjs
function qe() {
	return typeof process < "u" && process.env, "development";
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/get-single-element-child/get-single-element-child.mjs
function Je(e) {
	let t = i.toArray(e);
	return t.length !== 1 || !I(t[0]) ? null : t[0];
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/create-vars-resolver/create-vars-resolver.mjs
function G(e) {
	return e;
}
//#endregion
//#region node_modules/clsx/dist/clsx.mjs
function Ye(e) {
	var t, n, r = "";
	if (typeof e == "string" || typeof e == "number") r += e;
	else if (typeof e == "object") {
		if (Array.isArray(e)) {
			var i = e.length;
			for (t = 0; t < i; t++) e[t] && (n = Ye(e[t])) && (r && (r += " "), r += n);
		} else for (n in e) e[n] && (r && (r += " "), r += n);
	}
	return r;
}
function Xe() {
	for (var e, t, n = 0, r = "", i = arguments.length; n < i; n++) (e = arguments[n]) && (t = Ye(e)) && (r && (r += " "), r += t);
	return r;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/resolve-class-names/resolve-class-names.mjs
var Ze = {};
function Qe(e) {
	let t = {};
	return e.forEach((e) => {
		Object.entries(e).forEach(([e, n]) => {
			t[e] ? t[e] = Xe(t[e], n) : t[e] = n;
		});
	}), t;
}
function $e({ theme: e, classNames: t, props: n, stylesCtx: r }) {
	return Qe((Array.isArray(t) ? t : [t]).map((t) => typeof t == "function" ? t(e, n, r) : t || Ze));
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-style/resolve-styles/resolve-styles.mjs
function et({ theme: e, styles: t, props: n, stylesCtx: r }) {
	let i = Array.isArray(t) ? t : [t], a = {};
	for (let t of i) typeof t == "function" ? Object.assign(a, t(e, n, r)) : t && Object.assign(a, t);
	return a;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-scheme-managers/is-mantine-color-scheme.mjs
function tt(e) {
	return e === "auto" || e === "dark" || e === "light";
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-scheme-managers/local-storage-manager.mjs
function nt({ key: e = "mantine-color-scheme-value" } = {}) {
	let t;
	return {
		get: (t) => {
			if (typeof window > "u") return t;
			try {
				let n = window.localStorage.getItem(e);
				return tt(n) ? n : t;
			} catch {
				return t;
			}
		},
		set: (t) => {
			try {
				window.localStorage.setItem(e, t);
			} catch (e) {
				console.warn("[@mantine/core] Local storage color scheme manager was unable to save color scheme.", e);
			}
		},
		subscribe: (n) => {
			t = (t) => {
				t.storageArea === window.localStorage && t.key === e && tt(t.newValue) && n(t.newValue);
			}, window.addEventListener("storage", t);
		},
		unsubscribe: () => {
			window.removeEventListener("storage", t);
		},
		clear: () => {
			window.localStorage.removeItem(e);
		}
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-functions/get-primary-shade/get-primary-shade.mjs
function rt(e, t) {
	return typeof e.primaryShade == "number" ? e.primaryShade : t === "dark" ? e.primaryShade.dark : e.primaryShade.light;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-functions/to-rgba/to-rgba.mjs
function it(e) {
	return /^#?([0-9A-F]{3}){1,2}([0-9A-F]{2})?$/i.test(e);
}
function at(e) {
	let t = e.replace("#", "");
	if (t.length === 3) {
		let e = t.split("");
		t = [
			e[0],
			e[0],
			e[1],
			e[1],
			e[2],
			e[2]
		].join("");
	}
	if (t.length === 8) {
		let e = parseInt(t.slice(6, 8), 16) / 255;
		return {
			r: parseInt(t.slice(0, 2), 16),
			g: parseInt(t.slice(2, 4), 16),
			b: parseInt(t.slice(4, 6), 16),
			a: e
		};
	}
	let n = parseInt(t, 16);
	return {
		r: n >> 16 & 255,
		g: n >> 8 & 255,
		b: n & 255,
		a: 1
	};
}
function ot(e) {
	let [t, n, r, i] = e.replace(/[^0-9,./]/g, "").split(/[/,]/).map(Number);
	return {
		r: t,
		g: n,
		b: r,
		a: i === void 0 ? 1 : i
	};
}
function st(e) {
	let t = e.match(/^hsla?\(\s*(\d+)\s*,\s*(\d+%)\s*,\s*(\d+%)\s*(,\s*(0?\.\d+|\d+(\.\d+)?))?\s*\)$/i);
	if (!t) return {
		r: 0,
		g: 0,
		b: 0,
		a: 1
	};
	let n = parseInt(t[1], 10), r = parseInt(t[2], 10) / 100, i = parseInt(t[3], 10) / 100, a = t[5] ? parseFloat(t[5]) : void 0, o = (1 - Math.abs(2 * i - 1)) * r, s = n / 60, c = o * (1 - Math.abs(s % 2 - 1)), l = i - o / 2, u, d, f;
	return s >= 0 && s < 1 ? (u = o, d = c, f = 0) : s >= 1 && s < 2 ? (u = c, d = o, f = 0) : s >= 2 && s < 3 ? (u = 0, d = o, f = c) : s >= 3 && s < 4 ? (u = 0, d = c, f = o) : s >= 4 && s < 5 ? (u = c, d = 0, f = o) : (u = o, d = 0, f = c), {
		r: Math.round((u + l) * 255),
		g: Math.round((d + l) * 255),
		b: Math.round((f + l) * 255),
		a: a || 1
	};
}
function ct(e) {
	return it(e) ? at(e) : e.startsWith("rgb") ? ot(e) : e.startsWith("hsl") ? st(e) : {
		r: 0,
		g: 0,
		b: 0,
		a: 1
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-functions/luminance/luminance.mjs
function lt(e) {
	return e <= .03928 ? e / 12.92 : ((e + .055) / 1.055) ** 2.4;
}
function ut(e) {
	let t = e.match(/oklch\((.*?)%\s/);
	return t ? parseFloat(t[1]) : null;
}
function dt(e) {
	if (e.startsWith("oklch(")) return (ut(e) || 0) / 100;
	let { r: t, g: n, b: r } = ct(e), i = t / 255, a = n / 255, o = r / 255, s = lt(i), c = lt(a), l = lt(o);
	return .2126 * s + .7152 * c + .0722 * l;
}
function ft(e, t = .179) {
	return !e.startsWith("var(") && dt(e) > t;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-functions/parse-theme-color/parse-theme-color.mjs
function pt({ color: e, theme: t, colorScheme: n }) {
	if (typeof e != "string") throw Error(`[@mantine/core] Failed to parse color. Expected color to be a string, instead got ${typeof e}`);
	if (e === "bright") return {
		color: e,
		value: n === "dark" ? t.white : t.black,
		shade: void 0,
		isThemeColor: !1,
		isLight: ft(n === "dark" ? t.white : t.black, t.luminanceThreshold),
		variable: "--mantine-color-bright"
	};
	if (e === "dimmed") return {
		color: e,
		value: n === "dark" ? t.colors.dark[2] : t.colors.gray[7],
		shade: void 0,
		isThemeColor: !1,
		isLight: ft(n === "dark" ? t.colors.dark[2] : t.colors.gray[6], t.luminanceThreshold),
		variable: "--mantine-color-dimmed"
	};
	if (e === "white" || e === "black") return {
		color: e,
		value: e === "white" ? t.white : t.black,
		shade: void 0,
		isThemeColor: !1,
		isLight: ft(e === "white" ? t.white : t.black, t.luminanceThreshold),
		variable: `--mantine-color-${e}`
	};
	let [r, i] = e.split("."), a = i ? Number(i) : void 0, o = r in t.colors;
	if (o) {
		let e = a === void 0 ? t.colors[r][rt(t, n || "light")] : t.colors[r][a];
		return {
			color: r,
			value: e,
			shade: a,
			isThemeColor: o,
			isLight: ft(e, t.luminanceThreshold),
			variable: i ? `--mantine-color-${r}-${a}` : `--mantine-color-${r}-filled`
		};
	}
	return {
		color: e,
		value: e,
		isThemeColor: o,
		isLight: ft(e, t.luminanceThreshold),
		shade: a,
		variable: void 0
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-functions/get-theme-color/get-theme-color.mjs
function mt(e, t) {
	let n = pt({
		color: e || t.primaryColor,
		theme: t
	});
	return n.variable ? `var(${n.variable})` : e;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/virtual-color/virtual-color.mjs
function ht(e) {
	return !!e && typeof e == "object" && "mantine-virtual-color" in e;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-functions/darken/darken.mjs
function gt(e, t) {
	if (e.startsWith("var(")) return `color-mix(in srgb, ${e}, black ${t * 100}%)`;
	let { r: n, g: r, b: i, a } = ct(e), o = 1 - t, s = (e) => Math.round(e * o);
	return `rgba(${s(n)}, ${s(r)}, ${s(i)}, ${a})`;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-functions/get-gradient/get-gradient.mjs
function _t(e, t) {
	let n = {
		from: e?.from || t.defaultGradient.from,
		to: e?.to || t.defaultGradient.to,
		deg: e?.deg ?? t.defaultGradient.deg ?? 0
	}, r = mt(n.from, t), i = mt(n.to, t);
	return `linear-gradient(${n.deg}deg, ${r} 0%, ${i} 100%)`;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-functions/rgba/rgba.mjs
function vt(e, t) {
	if (typeof e != "string" || t > 1 || t < 0) return "rgba(0, 0, 0, 1)";
	if (e.startsWith("var(")) return `color-mix(in srgb, ${e}, transparent ${(1 - t) * 100}%)`;
	if (e.startsWith("oklch")) return e.includes("/") ? e.replace(/\/\s*[\d.]+\s*\)/, `/ ${t})`) : e.replace(")", ` / ${t})`);
	let { r: n, g: r, b: i } = ct(e);
	return `rgba(${n}, ${r}, ${i}, ${t})`;
}
var yt = vt, bt = ({ color: e, theme: t, variant: n, gradient: r, autoContrast: i }) => {
	let a = pt({
		color: e,
		theme: t
	}), o = typeof i == "boolean" ? i : t.autoContrast;
	if (n === "none") return {
		background: "transparent",
		hover: "transparent",
		color: "inherit",
		border: "none"
	};
	if (n === "filled") {
		let n = a.isThemeColor && a.shade === void 0 && ht(t.colors[a.color]), r = o ? n ? `var(--mantine-color-${a.color}-contrast)` : a.isLight ? "var(--mantine-color-black)" : "var(--mantine-color-white)" : "var(--mantine-color-white)";
		return a.isThemeColor ? a.shade === void 0 ? {
			background: `var(--mantine-color-${e}-filled)`,
			hover: `var(--mantine-color-${e}-filled-hover)`,
			color: r,
			border: `${P(1)} solid transparent`
		} : {
			background: `var(--mantine-color-${a.color}-${a.shade})`,
			hover: `var(--mantine-color-${a.color}-${a.shade === 9 ? 8 : a.shade + 1})`,
			color: r,
			border: `${P(1)} solid transparent`
		} : {
			background: e,
			hover: gt(e, .1),
			color: r,
			border: `${P(1)} solid transparent`
		};
	}
	if (n === "light") {
		if (a.isThemeColor) {
			if (a.shade === void 0) return {
				background: `var(--mantine-color-${e}-light)`,
				hover: `var(--mantine-color-${e}-light-hover)`,
				color: `var(--mantine-color-${e}-light-color)`,
				border: `${P(1)} solid transparent`
			};
			let n = t.colors[a.color][a.shade];
			return {
				background: n,
				hover: gt(n, .1),
				color: `var(--mantine-color-${a.color}-light-color)`,
				border: `${P(1)} solid transparent`
			};
		}
		return {
			background: vt(e, .1),
			hover: vt(e, .12),
			color: e,
			border: `${P(1)} solid transparent`
		};
	}
	if (n === "outline") return a.isThemeColor ? a.shade === void 0 ? {
		background: "transparent",
		hover: `var(--mantine-color-${e}-outline-hover)`,
		color: `var(--mantine-color-${e}-outline)`,
		border: `${P(1)} solid var(--mantine-color-${e}-outline)`
	} : {
		background: "transparent",
		hover: vt(t.colors[a.color][a.shade], .05),
		color: `var(--mantine-color-${a.color}-${a.shade})`,
		border: `${P(1)} solid var(--mantine-color-${a.color}-${a.shade})`
	} : {
		background: "transparent",
		hover: vt(e, .05),
		color: e,
		border: `${P(1)} solid ${e}`
	};
	if (n === "subtle") {
		if (a.isThemeColor) {
			if (a.shade === void 0) return {
				background: "transparent",
				hover: `var(--mantine-color-${e}-light-hover)`,
				color: `var(--mantine-color-${e}-light-color)`,
				border: `${P(1)} solid transparent`
			};
			let n = t.colors[a.color][a.shade];
			return {
				background: "transparent",
				hover: vt(n, .12),
				color: `var(--mantine-color-${a.color}-${Math.min(a.shade, 6)})`,
				border: `${P(1)} solid transparent`
			};
		}
		return {
			background: "transparent",
			hover: vt(e, .12),
			color: e,
			border: `${P(1)} solid transparent`
		};
	}
	return n === "transparent" ? a.isThemeColor ? a.shade === void 0 ? {
		background: "transparent",
		hover: "transparent",
		color: `var(--mantine-color-${e}-light-color)`,
		border: `${P(1)} solid transparent`
	} : {
		background: "transparent",
		hover: "transparent",
		color: `var(--mantine-color-${a.color}-${Math.min(a.shade, 6)})`,
		border: `${P(1)} solid transparent`
	} : {
		background: "transparent",
		hover: "transparent",
		color: e,
		border: `${P(1)} solid transparent`
	} : n === "white" ? a.isThemeColor ? a.shade === void 0 ? {
		background: "var(--mantine-color-white)",
		hover: gt(t.white, .01),
		color: `var(--mantine-color-${e}-filled)`,
		border: `${P(1)} solid transparent`
	} : {
		background: "var(--mantine-color-white)",
		hover: gt(t.white, .01),
		color: `var(--mantine-color-${a.color}-${a.shade})`,
		border: `${P(1)} solid transparent`
	} : {
		background: "var(--mantine-color-white)",
		hover: gt(t.white, .01),
		color: e,
		border: `${P(1)} solid transparent`
	} : n === "gradient" ? {
		background: _t(r, t),
		hover: _t(r, t),
		color: "var(--mantine-color-white)",
		border: "none"
	} : n === "default" ? {
		background: "var(--mantine-color-default)",
		hover: "var(--mantine-color-default-hover)",
		color: "var(--mantine-color-default-color)",
		border: `${P(1)} solid var(--mantine-color-default-border)`
	} : {};
};
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-functions/get-contrast-color/get-contrast-color.mjs
function xt({ color: e, theme: t, autoContrast: n, colorScheme: r }) {
	return (typeof n == "boolean" ? n : t.autoContrast) && pt({
		color: e || t.primaryColor,
		theme: t,
		colorScheme: r
	}).isLight ? "var(--mantine-color-black)" : "var(--mantine-color-white)";
}
function St(e, t, n) {
	return xt({
		color: n === "dark" ? e.dark : e.light,
		theme: t,
		colorScheme: n,
		autoContrast: !0
	});
}
function Ct(e, t) {
	let n = e.colors[e.primaryColor];
	return ht(n) ? e.autoContrast ? St(n, e, t) : "var(--mantine-color-white)" : xt({
		color: n[rt(e, t)],
		theme: e,
		autoContrast: null
	});
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-functions/get-auto-contrast-value/get-auto-contrast-value.mjs
function wt(e, t) {
	return typeof e == "boolean" ? e : t.autoContrast;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/Mantine.context.mjs
var Tt = s(null);
function Et() {
	let e = u(Tt);
	if (!e) throw Error("[@mantine/core] MantineProvider was not found in tree");
	return e;
}
function Dt() {
	return Et().cssVariablesResolver;
}
function Ot() {
	return Et().classNamesPrefix;
}
function kt() {
	return Et().getStyleNonce;
}
function At() {
	return Et().withStaticClasses;
}
function jt() {
	return Et().headless;
}
function Mt() {
	return Et().stylesTransform?.sx;
}
function Nt() {
	return Et().stylesTransform?.styles;
}
function Pt() {
	return Et().env || "default";
}
function Ft() {
	return Et().deduplicateInlineStyles;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/use-mantine-color-scheme/use-mantine-color-scheme.mjs
function It(e) {
	let t = document.createElement("style");
	return t.setAttribute("data-mantine-styles", "inline"), t.innerHTML = "*, *::before, *::after {transition: none !important;}", t.setAttribute("data-mantine-disable-transition", "true"), e && t.setAttribute("nonce", e), document.head.appendChild(t), () => document.querySelectorAll("[data-mantine-disable-transition]").forEach((e) => e.remove());
}
function Lt({ keepTransitions: e } = {}) {
	let t = v(le), n = v(-1), r = u(Tt), i = kt(), a = v(i?.());
	if (!r) throw Error("[@mantine/core] MantineProvider was not found in tree");
	let o = (i) => {
		r.setColorScheme(i), t.current = e ? () => {} : It(a.current), window.clearTimeout(n.current), n.current = window.setTimeout(() => {
			t.current?.();
		}, 10);
	}, s = () => {
		r.clearColorScheme(), t.current = e ? () => {} : It(a.current), window.clearTimeout(n.current), n.current = window.setTimeout(() => {
			t.current?.();
		}, 10);
	}, c = xe("light", { getInitialValueInEffect: !1 }), l = r.colorScheme === "auto" ? c : r.colorScheme, f = d(() => o(l === "light" ? "dark" : "light"), [o, l]);
	return p(() => () => {
		t.current?.(), window.clearTimeout(n.current);
	}, []), {
		colorScheme: r.colorScheme,
		setColorScheme: o,
		clearColorScheme: s,
		toggleColorScheme: f
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/use-mantine-color-scheme/use-provider-color-scheme.mjs
function Rt(e, t) {
	let n = typeof window < "u" && "matchMedia" in window && window.matchMedia("(prefers-color-scheme: dark)")?.matches, r = e === "auto" ? n ? "dark" : "light" : e;
	t()?.setAttribute("data-mantine-color-scheme", r);
}
function zt({ manager: e, defaultColorScheme: t, getRootElement: n, forceColorScheme: r }) {
	let i = v(null), [a, o] = y(() => e.get(t)), s = r || a, c = d((t) => {
		r || (Rt(t, n), o(t), e.set(t));
	}, [
		e.set,
		s,
		r
	]), l = d(() => {
		o(t), Rt(t, n), e.clear();
	}, [e.clear, t]);
	return p(() => (e.subscribe(c), e.unsubscribe), [e.subscribe, e.unsubscribe]), Se(() => {
		Rt(e.get(t), n);
	}, []), p(() => {
		if (r) return Rt(r, n), () => {};
		r === void 0 && Rt(a, n), typeof window < "u" && "matchMedia" in window && (i.current = window.matchMedia("(prefers-color-scheme: dark)"));
		let e = (e) => {
			a === "auto" && Rt(e.matches ? "dark" : "light", n);
		};
		return i.current?.addEventListener("change", e), () => i.current?.removeEventListener("change", e);
	}, [a, r]), {
		colorScheme: s,
		setColorScheme: c,
		clearColorScheme: l
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/use-mantine-color-scheme/use-computed-color-scheme.mjs
function Bt(e, t = { getInitialValueInEffect: !0 }) {
	let n = xe(e, t), { colorScheme: r } = Lt();
	return r === "auto" ? n : r;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/default-colors.mjs
var Vt = {
	dark: [
		"#C9C9C9",
		"#b8b8b8",
		"#828282",
		"#696969",
		"#424242",
		"#3b3b3b",
		"#2e2e2e",
		"#242424",
		"#1f1f1f",
		"#141414"
	],
	gray: [
		"#f8f9fa",
		"#f1f3f5",
		"#e9ecef",
		"#dee2e6",
		"#ced4da",
		"#adb5bd",
		"#868e96",
		"#495057",
		"#343a40",
		"#212529"
	],
	red: [
		"#fff5f5",
		"#ffe3e3",
		"#ffc9c9",
		"#ffa8a8",
		"#ff8787",
		"#ff6b6b",
		"#fa5252",
		"#f03e3e",
		"#e03131",
		"#c92a2a"
	],
	pink: [
		"#fff0f6",
		"#ffdeeb",
		"#fcc2d7",
		"#faa2c1",
		"#f783ac",
		"#f06595",
		"#e64980",
		"#d6336c",
		"#c2255c",
		"#a61e4d"
	],
	grape: [
		"#f8f0fc",
		"#f3d9fa",
		"#eebefa",
		"#e599f7",
		"#da77f2",
		"#cc5de8",
		"#be4bdb",
		"#ae3ec9",
		"#9c36b5",
		"#862e9c"
	],
	violet: [
		"#f3f0ff",
		"#e5dbff",
		"#d0bfff",
		"#b197fc",
		"#9775fa",
		"#845ef7",
		"#7950f2",
		"#7048e8",
		"#6741d9",
		"#5f3dc4"
	],
	indigo: [
		"#edf2ff",
		"#dbe4ff",
		"#bac8ff",
		"#91a7ff",
		"#748ffc",
		"#5c7cfa",
		"#4c6ef5",
		"#4263eb",
		"#3b5bdb",
		"#364fc7"
	],
	blue: [
		"#e7f5ff",
		"#d0ebff",
		"#a5d8ff",
		"#74c0fc",
		"#4dabf7",
		"#339af0",
		"#228be6",
		"#1c7ed6",
		"#1971c2",
		"#1864ab"
	],
	cyan: [
		"#e3fafc",
		"#c5f6fa",
		"#99e9f2",
		"#66d9e8",
		"#3bc9db",
		"#22b8cf",
		"#15aabf",
		"#1098ad",
		"#0c8599",
		"#0b7285"
	],
	teal: [
		"#e6fcf5",
		"#c3fae8",
		"#96f2d7",
		"#63e6be",
		"#38d9a9",
		"#20c997",
		"#12b886",
		"#0ca678",
		"#099268",
		"#087f5b"
	],
	green: [
		"#ebfbee",
		"#d3f9d8",
		"#b2f2bb",
		"#8ce99a",
		"#69db7c",
		"#51cf66",
		"#40c057",
		"#37b24d",
		"#2f9e44",
		"#2b8a3e"
	],
	lime: [
		"#f4fce3",
		"#e9fac8",
		"#d8f5a2",
		"#c0eb75",
		"#a9e34b",
		"#94d82d",
		"#82c91e",
		"#74b816",
		"#66a80f",
		"#5c940d"
	],
	yellow: [
		"#fff9db",
		"#fff3bf",
		"#ffec99",
		"#ffe066",
		"#ffd43b",
		"#fcc419",
		"#fab005",
		"#f59f00",
		"#f08c00",
		"#e67700"
	],
	orange: [
		"#fff4e6",
		"#ffe8cc",
		"#ffd8a8",
		"#ffc078",
		"#ffa94d",
		"#ff922b",
		"#fd7e14",
		"#f76707",
		"#e8590c",
		"#d9480f"
	]
}, Ht = "-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Helvetica, Arial, sans-serif, Apple Color Emoji, Segoe UI Emoji", Ut = {
	scale: 1,
	fontSmoothing: !0,
	focusRing: "auto",
	white: "#fff",
	black: "#000",
	colors: Vt,
	primaryShade: {
		light: 6,
		dark: 8
	},
	primaryColor: "blue",
	variantColorResolver: bt,
	autoContrast: !1,
	luminanceThreshold: .3,
	fontFamily: Ht,
	fontFamilyMonospace: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, Liberation Mono, Courier New, monospace",
	respectReducedMotion: !1,
	cursorType: "default",
	defaultGradient: {
		from: "blue",
		to: "cyan",
		deg: 45
	},
	defaultRadius: "md",
	activeClassName: "mantine-active",
	focusClassName: "",
	headings: {
		fontFamily: Ht,
		fontWeight: "700",
		textWrap: "wrap",
		sizes: {
			h1: {
				fontSize: P(34),
				lineHeight: "1.3"
			},
			h2: {
				fontSize: P(26),
				lineHeight: "1.35"
			},
			h3: {
				fontSize: P(22),
				lineHeight: "1.4"
			},
			h4: {
				fontSize: P(18),
				lineHeight: "1.45"
			},
			h5: {
				fontSize: P(16),
				lineHeight: "1.5"
			},
			h6: {
				fontSize: P(14),
				lineHeight: "1.5"
			}
		}
	},
	fontSizes: {
		xs: P(12),
		sm: P(14),
		md: P(16),
		lg: P(18),
		xl: P(20)
	},
	lineHeights: {
		xs: "1.4",
		sm: "1.45",
		md: "1.55",
		lg: "1.6",
		xl: "1.65"
	},
	fontWeights: {
		regular: "400",
		medium: "600",
		bold: "700"
	},
	radius: {
		xs: P(2),
		sm: P(4),
		md: P(8),
		lg: P(16),
		xl: P(32)
	},
	spacing: {
		xs: P(10),
		sm: P(12),
		md: P(16),
		lg: P(20),
		xl: P(32)
	},
	breakpoints: {
		xs: "36em",
		sm: "48em",
		md: "62em",
		lg: "75em",
		xl: "88em"
	},
	shadows: {
		xs: `0 ${P(1)} ${P(3)} rgba(0, 0, 0, 0.05), 0 ${P(1)} ${P(2)} rgba(0, 0, 0, 0.1)`,
		sm: `0 ${P(1)} ${P(3)} rgba(0, 0, 0, 0.05), rgba(0, 0, 0, 0.05) 0 ${P(10)} ${P(15)} ${P(-5)}, rgba(0, 0, 0, 0.04) 0 ${P(7)} ${P(7)} ${P(-5)}`,
		md: `0 ${P(1)} ${P(3)} rgba(0, 0, 0, 0.05), rgba(0, 0, 0, 0.05) 0 ${P(20)} ${P(25)} ${P(-5)}, rgba(0, 0, 0, 0.04) 0 ${P(10)} ${P(10)} ${P(-5)}`,
		lg: `0 ${P(1)} ${P(3)} rgba(0, 0, 0, 0.05), rgba(0, 0, 0, 0.05) 0 ${P(28)} ${P(23)} ${P(-7)}, rgba(0, 0, 0, 0.04) 0 ${P(12)} ${P(12)} ${P(-7)}`,
		xl: `0 ${P(1)} ${P(3)} rgba(0, 0, 0, 0.05), rgba(0, 0, 0, 0.05) 0 ${P(36)} ${P(28)} ${P(-7)}, rgba(0, 0, 0, 0.04) 0 ${P(17)} ${P(17)} ${P(-7)}`
	},
	other: {},
	components: {}
}, Wt = "[@mantine/core] MantineProvider: Invalid theme.primaryColor, it accepts only key of theme.colors, learn more – https://mantine.dev/theming/colors/#primary-color", Gt = "[@mantine/core] MantineProvider: Invalid theme.primaryShade, it accepts only 0-9 integers or an object { light: 0-9, dark: 0-9 }";
function Kt(e) {
	return e < 0 || e > 9 ? !1 : parseInt(e.toString(), 10) === e;
}
function qt(e) {
	if (!(e.primaryColor in e.colors)) throw Error(Wt);
	if (typeof e.primaryShade == "object" && (!Kt(e.primaryShade.dark) || !Kt(e.primaryShade.light)) || typeof e.primaryShade == "number" && !Kt(e.primaryShade)) throw Error(Gt);
}
function Jt(e, t) {
	if (!t) return qt(e), e;
	let n = k(e, t);
	return t.fontFamily && !t.headings?.fontFamily && (n.headings = {
		...n.headings,
		fontFamily: t.fontFamily
	}), qt(n), n;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/MantineThemeProvider/MantineThemeProvider.mjs
var Yt = s(null), Xt = () => u(Yt) || Ut;
function Zt() {
	let e = u(Yt);
	if (!e) throw Error("@mantine/core: MantineProvider was not found in component tree, make sure you have it in your app");
	return e;
}
function Qt({ theme: e, children: t, inherit: n = !0 }) {
	let r = Xt(), i = _(() => Jt(n ? r : Ut, e), [
		e,
		r,
		n
	]);
	return /* @__PURE__ */ T(Yt, {
		value: i,
		children: t
	});
}
Qt.displayName = "@mantine/core/MantineThemeProvider";
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/convert-css-variables/css-variables-object-to-string.mjs
function $t(e) {
	return Object.entries(e).map(([e, t]) => `${e}: ${t};`).join("");
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/convert-css-variables/convert-css-variables.mjs
function en(e, t) {
	let n = t ? [t] : [":root", ":host"], r = $t(e.variables), i = r ? `${n.join(", ")}{${r}}` : "", a = $t(e.dark), o = $t(e.light), s = (e) => n.map((t) => t === ":host" ? `${t}([data-mantine-color-scheme="${e}"])` : `${t}[data-mantine-color-scheme="${e}"]`).join(", ");
	return `${i}\n\n${a ? `${s("dark")}{${a}}` : ""}\n\n${o ? `${s("light")}{${o}}` : ""}`;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/get-css-color-variables.mjs
function tn({ theme: e, color: t, colorScheme: n, name: r = t, withColorValues: i = !0 }) {
	if (!e.colors[t]) return {};
	if (n === "light") {
		let n = rt(e, "light"), a = {
			[`--mantine-color-${r}-text`]: `var(--mantine-color-${r}-filled)`,
			[`--mantine-color-${r}-filled`]: `var(--mantine-color-${r}-${n})`,
			[`--mantine-color-${r}-filled-hover`]: `var(--mantine-color-${r}-${n === 9 ? 8 : n + 1})`,
			[`--mantine-color-${r}-light`]: `var(--mantine-color-${r}-1)`,
			[`--mantine-color-${r}-light-hover`]: `var(--mantine-color-${r}-2)`,
			[`--mantine-color-${r}-light-color`]: `var(--mantine-color-${r}-9)`,
			[`--mantine-color-${r}-outline`]: `var(--mantine-color-${r}-${n})`,
			[`--mantine-color-${r}-outline-hover`]: yt(e.colors[t][n], .05)
		};
		return i ? {
			[`--mantine-color-${r}-0`]: e.colors[t][0],
			[`--mantine-color-${r}-1`]: e.colors[t][1],
			[`--mantine-color-${r}-2`]: e.colors[t][2],
			[`--mantine-color-${r}-3`]: e.colors[t][3],
			[`--mantine-color-${r}-4`]: e.colors[t][4],
			[`--mantine-color-${r}-5`]: e.colors[t][5],
			[`--mantine-color-${r}-6`]: e.colors[t][6],
			[`--mantine-color-${r}-7`]: e.colors[t][7],
			[`--mantine-color-${r}-8`]: e.colors[t][8],
			[`--mantine-color-${r}-9`]: e.colors[t][9],
			...a
		} : a;
	}
	let a = rt(e, "dark"), o = {
		[`--mantine-color-${r}-text`]: `var(--mantine-color-${r}-4)`,
		[`--mantine-color-${r}-filled`]: `var(--mantine-color-${r}-${a})`,
		[`--mantine-color-${r}-filled-hover`]: `var(--mantine-color-${r}-${a === 9 ? 8 : a + 1})`,
		[`--mantine-color-${r}-light`]: gt(e.colors[t][9], .5),
		[`--mantine-color-${r}-light-hover`]: gt(e.colors[t][9], .3),
		[`--mantine-color-${r}-light-color`]: `var(--mantine-color-${r}-0)`,
		[`--mantine-color-${r}-outline`]: `var(--mantine-color-${r}-${Math.max(a - 4, 0)})`,
		[`--mantine-color-${r}-outline-hover`]: yt(e.colors[t][Math.max(a - 4, 0)], .05)
	};
	return i ? {
		[`--mantine-color-${r}-0`]: e.colors[t][0],
		[`--mantine-color-${r}-1`]: e.colors[t][1],
		[`--mantine-color-${r}-2`]: e.colors[t][2],
		[`--mantine-color-${r}-3`]: e.colors[t][3],
		[`--mantine-color-${r}-4`]: e.colors[t][4],
		[`--mantine-color-${r}-5`]: e.colors[t][5],
		[`--mantine-color-${r}-6`]: e.colors[t][6],
		[`--mantine-color-${r}-7`]: e.colors[t][7],
		[`--mantine-color-${r}-8`]: e.colors[t][8],
		[`--mantine-color-${r}-9`]: e.colors[t][9],
		...o
	} : o;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/default-css-variables-resolver.mjs
function nn(e, t, n) {
	D(t).forEach((r) => Object.assign(e, { [`--mantine-${n}-${r}`]: t[r] }));
}
var rn = (e) => {
	let t = rt(e, "light"), n = e.defaultRadius in e.radius ? e.radius[e.defaultRadius] : P(e.defaultRadius), r = {
		variables: {
			"--mantine-z-index-app": "100",
			"--mantine-z-index-modal": "200",
			"--mantine-z-index-popover": "300",
			"--mantine-z-index-overlay": "400",
			"--mantine-z-index-max": "9999",
			"--mantine-scale": e.scale.toString(),
			"--mantine-cursor-type": e.cursorType,
			"--mantine-webkit-font-smoothing": e.fontSmoothing ? "antialiased" : "unset",
			"--mantine-moz-font-smoothing": e.fontSmoothing ? "grayscale" : "unset",
			"--mantine-color-white": e.white,
			"--mantine-color-black": e.black,
			"--mantine-line-height": e.lineHeights.md,
			"--mantine-font-family": e.fontFamily,
			"--mantine-font-family-monospace": e.fontFamilyMonospace,
			"--mantine-font-family-headings": e.headings.fontFamily,
			"--mantine-heading-font-weight": e.headings.fontWeight,
			"--mantine-heading-text-wrap": e.headings.textWrap,
			"--mantine-radius-default": n,
			"--mantine-primary-color-filled": `var(--mantine-color-${e.primaryColor}-filled)`,
			"--mantine-primary-color-filled-hover": `var(--mantine-color-${e.primaryColor}-filled-hover)`,
			"--mantine-primary-color-light": `var(--mantine-color-${e.primaryColor}-light)`,
			"--mantine-primary-color-light-hover": `var(--mantine-color-${e.primaryColor}-light-hover)`,
			"--mantine-primary-color-light-color": `var(--mantine-color-${e.primaryColor}-light-color)`
		},
		light: {
			"--mantine-color-scheme": "light",
			"--mantine-primary-color-contrast": Ct(e, "light"),
			"--mantine-color-bright": "var(--mantine-color-black)",
			"--mantine-color-text": e.black,
			"--mantine-color-body": e.white,
			"--mantine-color-error": "var(--mantine-color-red-6)",
			"--mantine-color-success": "var(--mantine-color-teal-8)",
			"--mantine-color-placeholder": "var(--mantine-color-gray-5)",
			"--mantine-color-anchor": `var(--mantine-color-${e.primaryColor}-${t})`,
			"--mantine-color-default": "var(--mantine-color-white)",
			"--mantine-color-default-hover": "var(--mantine-color-gray-0)",
			"--mantine-color-default-color": "var(--mantine-color-black)",
			"--mantine-color-default-border": "var(--mantine-color-gray-4)",
			"--mantine-color-dimmed": "var(--mantine-color-gray-6)",
			"--mantine-color-disabled": "var(--mantine-color-gray-2)",
			"--mantine-color-disabled-color": "var(--mantine-color-gray-5)",
			"--mantine-color-disabled-border": "var(--mantine-color-gray-3)"
		},
		dark: {
			"--mantine-color-scheme": "dark",
			"--mantine-primary-color-contrast": Ct(e, "dark"),
			"--mantine-color-bright": "var(--mantine-color-white)",
			"--mantine-color-text": "var(--mantine-color-dark-0)",
			"--mantine-color-body": "var(--mantine-color-dark-7)",
			"--mantine-color-error": "var(--mantine-color-red-8)",
			"--mantine-color-success": "var(--mantine-color-teal-8)",
			"--mantine-color-placeholder": "var(--mantine-color-dark-3)",
			"--mantine-color-anchor": `var(--mantine-color-${e.primaryColor}-4)`,
			"--mantine-color-default": "var(--mantine-color-dark-6)",
			"--mantine-color-default-hover": "var(--mantine-color-dark-5)",
			"--mantine-color-default-color": "var(--mantine-color-white)",
			"--mantine-color-default-border": "var(--mantine-color-dark-4)",
			"--mantine-color-dimmed": "var(--mantine-color-dark-2)",
			"--mantine-color-disabled": "var(--mantine-color-dark-6)",
			"--mantine-color-disabled-color": "var(--mantine-color-dark-3)",
			"--mantine-color-disabled-border": "var(--mantine-color-dark-4)"
		}
	};
	nn(r.variables, e.breakpoints, "breakpoint"), nn(r.variables, e.spacing, "spacing"), nn(r.variables, e.fontSizes, "font-size"), nn(r.variables, e.lineHeights, "line-height"), nn(r.variables, e.shadows, "shadow"), nn(r.variables, e.radius, "radius"), nn(r.variables, e.fontWeights, "font-weight"), e.colors[e.primaryColor].forEach((t, n) => {
		r.variables[`--mantine-primary-color-${n}`] = `var(--mantine-color-${e.primaryColor}-${n})`;
	}), D(e.colors).forEach((t) => {
		let n = e.colors[t];
		if (ht(n)) {
			Object.assign(r.light, tn({
				theme: e,
				name: n.name,
				color: n.light,
				colorScheme: "light",
				withColorValues: !0
			})), Object.assign(r.dark, tn({
				theme: e,
				name: n.name,
				color: n.dark,
				colorScheme: "dark",
				withColorValues: !0
			})), r.light[`--mantine-color-${n.name}-contrast`] = St(n, e, "light"), r.dark[`--mantine-color-${n.name}-contrast`] = St(n, e, "dark");
			return;
		}
		n.forEach((e, n) => {
			r.variables[`--mantine-color-${t}-${n}`] = e;
		}), Object.assign(r.light, tn({
			theme: e,
			color: t,
			colorScheme: "light",
			withColorValues: !1
		})), Object.assign(r.dark, tn({
			theme: e,
			color: t,
			colorScheme: "dark",
			withColorValues: !1
		}));
	});
	let i = e.headings.sizes;
	return D(i).forEach((t) => {
		r.variables[`--mantine-${t}-font-size`] = i[t].fontSize, r.variables[`--mantine-${t}-line-height`] = i[t].lineHeight, r.variables[`--mantine-${t}-font-weight`] = i[t].fontWeight || e.headings.fontWeight;
	}), r;
};
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/MantineClasses/MantineClasses.mjs
function an() {
	let e = Zt(), t = kt(), n = D(e.breakpoints).reduce((t, n) => {
		let r = e.breakpoints[n].includes("px"), i = j(e.breakpoints[n]);
		return `${t}@media (max-width: ${r ? `${i - .1}px` : te(i - .1)}) {.mantine-visible-from-${n} {display: none !important;}}@media (min-width: ${r ? `${i}px` : te(i)}) {.mantine-hidden-from-${n} {display: none !important;}}`;
	}, "");
	return /* @__PURE__ */ T("style", {
		"data-mantine-styles": "classes",
		nonce: t?.(),
		dangerouslySetInnerHTML: { __html: n }
	});
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/get-merged-variables.mjs
function on({ theme: e, generator: t }) {
	let n = rn(e), r = t?.(e);
	return r ? k(n, r) : n;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/remove-default-variables.mjs
var sn = rn(Ut);
function cn(e) {
	let t = {
		variables: {},
		light: {},
		dark: {}
	};
	return D(e.variables).forEach((n) => {
		sn.variables[n] !== e.variables[n] && (t.variables[n] = e.variables[n]);
	}), D(e.light).forEach((n) => {
		sn.light[n] !== e.light[n] && (t.light[n] = e.light[n]);
	}), D(e.dark).forEach((n) => {
		sn.dark[n] !== e.dark[n] && (t.dark[n] = e.dark[n]);
	}), t;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/MantineCssVariables.mjs
function ln(e) {
	return en({
		variables: {},
		dark: { "--mantine-color-scheme": "dark" },
		light: { "--mantine-color-scheme": "light" }
	}, e);
}
function un({ cssVariablesSelector: e, deduplicateCssVariables: t }) {
	let n = Zt(), r = kt(), i = on({
		theme: n,
		generator: Dt()
	}), a = (e === void 0 || e === ":root" || e === ":host") && t, o = en(a ? cn(i) : i, e);
	return o ? /* @__PURE__ */ T("style", {
		"data-mantine-styles": !0,
		nonce: r?.(),
		dangerouslySetInnerHTML: { __html: `${o}${a ? "" : ln(e)}` }
	}) : null;
}
un.displayName = "@mantine/CssVariables";
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/use-respect-reduce-motion/use-respect-reduce-motion.mjs
function dn({ respectReducedMotion: e, getRootElement: t }) {
	Se(() => {
		e && t()?.setAttribute("data-respect-reduced-motion", "true");
	}, [e]);
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/MantineProvider.mjs
function fn({ theme: e, children: t, getStyleNonce: n, withStaticClasses: r = !0, withGlobalClasses: i = !0, deduplicateCssVariables: a = !0, withCssVariables: o = !0, cssVariablesSelector: s, classNamesPrefix: c = "mantine", colorSchemeManager: l = nt(), defaultColorScheme: u = "light", getRootElement: d = () => document.documentElement, cssVariablesResolver: f, forceColorScheme: p, stylesTransform: m, env: h, deduplicateInlineStyles: g = !1 }) {
	let { colorScheme: _, setColorScheme: v, clearColorScheme: y } = zt({
		defaultColorScheme: u,
		forceColorScheme: p,
		manager: l,
		getRootElement: d
	});
	return dn({
		respectReducedMotion: e?.respectReducedMotion || !1,
		getRootElement: d
	}), /* @__PURE__ */ T(Tt, {
		value: {
			colorScheme: _,
			setColorScheme: v,
			clearColorScheme: y,
			getRootElement: d,
			classNamesPrefix: c,
			getStyleNonce: n,
			cssVariablesResolver: f,
			cssVariablesSelector: s ?? ":root",
			withStaticClasses: r,
			stylesTransform: m,
			env: h,
			deduplicateInlineStyles: g
		},
		children: /* @__PURE__ */ E(Qt, {
			theme: e,
			children: [
				o && /* @__PURE__ */ T(un, {
					cssVariablesSelector: s,
					deduplicateCssVariables: a
				}),
				i && /* @__PURE__ */ T(an, {}),
				t
			]
		})
	});
}
fn.displayName = "@mantine/core/MantineProvider";
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/use-props/use-props.mjs
function K(e, t, n) {
	let r = Zt(), i = (Array.isArray(e) ? e : [e]).filter(Boolean), a = {};
	for (let e of i) {
		let t = r.components[e]?.defaultProps, n = typeof t == "function" ? t(r) : t;
		n && (a = {
			...a,
			...n
		});
	}
	return {
		...t,
		...a,
		...ne(n)
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/create-theme/create-theme.mjs
function pn(e) {
	return e;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-resolved-styles-api/use-resolved-styles-api.mjs
function mn({ classNames: e, styles: t, props: n, stylesCtx: r }) {
	let i = Zt();
	return {
		resolvedClassNames: e === void 0 ? void 0 : $e({
			theme: i,
			classNames: e,
			props: n,
			stylesCtx: r || void 0
		}),
		resolvedStyles: t === void 0 ? void 0 : et({
			theme: i,
			styles: t,
			props: n,
			stylesCtx: r || void 0
		})
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-global-class-names/get-global-class-names.mjs
var hn = {
	always: "mantine-focus-always",
	auto: "mantine-focus-auto",
	never: "mantine-focus-never"
};
function gn({ theme: e, options: t, unstyled: n }) {
	return Xe(t?.focusable && !n && (e.focusClassName || hn[e.focusRing]), t?.active && !n && e.activeClassName);
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-options-class-names/get-options-class-names.mjs
function _n({ selector: e, stylesCtx: t, options: n, props: r, theme: i }) {
	return $e({
		theme: i,
		classNames: n?.classNames,
		props: n?.props || r,
		stylesCtx: t
	})[e];
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-resolved-class-names/get-resolved-class-names.mjs
function vn({ selector: e, stylesCtx: t, theme: n, classNames: r, props: i }) {
	return $e({
		theme: n,
		classNames: r,
		props: i,
		stylesCtx: t
	})[e];
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-root-class-name/get-root-class-name.mjs
function yn({ rootSelector: e, selector: t, className: n }) {
	return e === t ? n : void 0;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-selector-class-name/get-selector-class-name.mjs
function bn({ selector: e, classes: t, unstyled: n }) {
	return n ? void 0 : t[e];
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-static-class-names/get-static-class-names.mjs
function xn({ themeName: e, classNamesPrefix: t, selector: n, withStaticClass: r }) {
	return r === !1 ? [] : e.map((e) => `${t}-${e}-${n}`);
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-variant-class-name/get-variant-class-name.mjs
function Sn({ options: e, classes: t, selector: n, unstyled: r }) {
	return e?.variant && !r ? t[`${n}--${e.variant}`] : void 0;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-class-name.mjs
function Cn({ theme: e, options: t, themeName: n, selector: r, classNamesPrefix: i, resolvedClassNames: a, resolvedThemeClassNames: o, classes: s, unstyled: c, className: l, rootSelector: u, props: d, stylesCtx: f, withStaticClasses: p, headless: m, transformedStyles: h }) {
	return Xe(gn({
		theme: e,
		options: t,
		unstyled: c || m
	}), o.map((e) => e[r]), Sn({
		options: t,
		classes: s,
		selector: r,
		unstyled: c || m
	}), a[r], vn({
		selector: r,
		stylesCtx: f,
		theme: e,
		classNames: h,
		props: d
	}), _n({
		selector: r,
		stylesCtx: f,
		options: t,
		props: d,
		theme: e
	}), yn({
		rootSelector: u,
		selector: r,
		className: l
	}), bn({
		selector: r,
		classes: s,
		unstyled: c || m
	}), p && !m && xn({
		themeName: n,
		classNamesPrefix: i,
		selector: r,
		withStaticClass: t?.withStaticClass
	}), t?.className);
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-style/resolve-style/resolve-style.mjs
function wn({ style: e, theme: t }) {
	return Array.isArray(e) ? e.reduce((e, n) => ({
		...e,
		...wn({
			style: n,
			theme: t
		})
	}), {}) : typeof e == "function" ? e(t) : e ?? {};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-style/get-style.mjs
function Tn({ theme: e, selector: t, options: n, props: r, stylesCtx: i, rootSelector: a, withStylesTransform: o, resolvedStyles: s, resolvedThemeStyles: c, resolvedVars: l, resolvedRootStyle: u }) {
	return {
		...c[t],
		...s[t],
		...!o && et({
			theme: e,
			styles: n?.styles,
			props: n?.props || r,
			stylesCtx: i
		})[t],
		...l[t],
		...a === t ? u : null,
		...wn({
			style: n?.style,
			theme: e
		})
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-style/resolve-vars/merge-vars.mjs
function En(e) {
	return e.reduce((e, t) => (t && Object.keys(t).forEach((n) => {
		e[n] = {
			...e[n],
			...ne(t[n])
		};
	}), e), {});
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/use-transformed-styles.mjs
function Dn({ props: e, stylesCtx: t, themeName: n, theme: r }) {
	let i = Nt()?.();
	return {
		getTransformedStyles: (a) => i ? [...a.map((n) => i(n, {
			props: e,
			theme: r,
			ctx: t
		})), ...n.map((n) => i(r.components[n]?.styles, {
			props: e,
			theme: r,
			ctx: t
		}))].filter(Boolean) : [],
		withStylesTransform: !!i
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/use-styles.mjs
function q({ name: e, classes: t, props: n, stylesCtx: r, className: i, style: a, rootSelector: o = "root", unstyled: s, classNames: c, styles: l, vars: u, varsResolver: d, attributes: f }) {
	let p = Zt(), m = Ot(), h = At(), g = jt(), _ = (Array.isArray(e) ? e : [e]).filter((e) => e), { withStylesTransform: v, getTransformedStyles: y } = Dn({
		props: n,
		stylesCtx: r,
		themeName: _,
		theme: p
	}), b = $e({
		theme: p,
		classNames: c,
		props: n,
		stylesCtx: r
	}), x = _.map((e) => $e({
		theme: p,
		classNames: p.components[e]?.classNames,
		props: n,
		stylesCtx: r
	})), S = v ? {} : et({
		theme: p,
		styles: l,
		props: n,
		stylesCtx: r
	}), C = {};
	if (!v) for (let e of _) {
		let t = et({
			theme: p,
			styles: p.components[e]?.styles,
			props: n,
			stylesCtx: r
		});
		for (let e of Object.keys(t)) C[e] = {
			...C[e],
			...t[e]
		};
	}
	let w = En([
		g ? {} : d?.(p, n, r),
		..._.map((e) => p.components?.[e]?.vars?.(p, n, r)),
		u?.(p, n, r)
	]), T = wn({
		style: a,
		theme: p
	});
	return (e, a) => ({
		...f?.[e],
		className: Cn({
			theme: p,
			options: a,
			themeName: _,
			selector: e,
			classNamesPrefix: m,
			resolvedClassNames: b,
			resolvedThemeClassNames: x,
			classes: t,
			unstyled: s,
			className: i,
			rootSelector: o,
			props: n,
			stylesCtx: r,
			withStaticClasses: h,
			headless: g,
			transformedStyles: y([a?.styles, l])
		}),
		style: Tn({
			theme: p,
			selector: e,
			options: a,
			props: n,
			stylesCtx: r,
			rootSelector: o,
			withStylesTransform: v,
			resolvedStyles: S,
			resolvedThemeStyles: C,
			resolvedVars: w,
			resolvedRootStyle: T
		})
	});
}
//#endregion
//#region node_modules/@mantine/core/esm/core/InlineStyles/css-object-to-string/css-object-to-string.mjs
function On(e) {
	return D(e).reduce((t, n) => e[n] === void 0 ? t : `${t}${ee(n)}:${e[n]};`, "").trim();
}
//#endregion
//#region node_modules/@mantine/core/esm/core/InlineStyles/styles-to-string/styles-to-string.mjs
function kn({ selector: e, styles: t, media: n, container: r }) {
	let i = t ? On(t) : "", a = Array.isArray(n) ? n.map((t) => `@media${t.query}{${e}{${On(t.styles)}}}`) : [], o = Array.isArray(r) ? r.map((t) => `@container ${t.query}{${e}{${On(t.styles)}}}`) : [];
	return `${i ? `${e}{${i}}` : ""}${a.join("")}${o.join("")}`.trim();
}
//#endregion
//#region node_modules/@mantine/core/esm/core/InlineStyles/InlineStyles.mjs
function An(e) {
	let t = 5381;
	for (let n = 0; n < e.length; n++) t = (t << 5) + t + e.charCodeAt(n) & 4294967295;
	return (t >>> 0).toString(36);
}
function jn({ deduplicate: e, ...t }) {
	let n = kt(), r = kn(t);
	return e ? /* @__PURE__ */ T("style", {
		href: `mantine-${An(r)}`,
		precedence: "mantine",
		nonce: n?.(),
		children: r
	}) : /* @__PURE__ */ T("style", {
		"data-mantine-styles": "inline",
		nonce: n?.(),
		dangerouslySetInnerHTML: { __html: r }
	});
}
//#endregion
//#region node_modules/@mantine/core/esm/core/InlineStyles/hash-styles.mjs
function Mn(e) {
	let t = 5381;
	for (let n = 0; n < e.length; n++) t = (t << 5) + t + e.charCodeAt(n) & 4294967295;
	return (t >>> 0).toString(36);
}
function Nn(e, t) {
	return `__mdi__-${Mn(`${e ? On(e) : ""}|${Array.isArray(t) ? t.map((e) => `${e.query}:${On(e.styles)}`).join("|") : ""}`)}`;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/extract-style-props/extract-style-props.mjs
function Pn(e) {
	let { m: t, mx: n, my: r, mt: i, mb: a, ml: o, mr: s, me: c, ms: l, mis: u, mie: d, p: f, px: p, py: m, pt: h, pb: g, pl: _, pr: v, pe: y, ps: b, pis: x, pie: S, bd: C, bdrs: w, bg: T, c: E, opacity: D, ff: O, fz: k, fw: ee, lts: A, ta: j, lh: M, fs: N, tt: P, td: te, w: F, miw: I, maw: re, h: L, mih: R, mah: z, bgsz: ie, bgp: ae, bgr: oe, bga: se, pos: ce, top: le, left: B, bottom: V, right: ue, inset: H, display: de, flex: U, hiddenFrom: fe, visibleFrom: pe, lightHidden: me, darkHidden: he, sx: ge, ..._e } = e;
	return {
		styleProps: ne({
			m: t,
			mx: n,
			my: r,
			mt: i,
			mb: a,
			ml: o,
			mr: s,
			me: c,
			ms: l,
			mis: u,
			mie: d,
			p: f,
			px: p,
			py: m,
			pt: h,
			pb: g,
			pl: _,
			pr: v,
			pis: x,
			pie: S,
			pe: y,
			ps: b,
			bd: C,
			bg: T,
			c: E,
			opacity: D,
			ff: O,
			fz: k,
			fw: ee,
			lts: A,
			ta: j,
			lh: M,
			fs: N,
			tt: P,
			td: te,
			w: F,
			miw: I,
			maw: re,
			h: L,
			mih: R,
			mah: z,
			bgsz: ie,
			bgp: ae,
			bgr: oe,
			bga: se,
			pos: ce,
			top: le,
			left: B,
			bottom: V,
			right: ue,
			inset: H,
			display: de,
			flex: U,
			bdrs: w,
			hiddenFrom: fe,
			visibleFrom: pe,
			lightHidden: me,
			darkHidden: he,
			sx: ge
		}),
		rest: _e
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/style-props-data.mjs
var Fn = {
	m: {
		type: "spacing",
		property: "margin"
	},
	mt: {
		type: "spacing",
		property: "marginTop"
	},
	mb: {
		type: "spacing",
		property: "marginBottom"
	},
	ml: {
		type: "spacing",
		property: "marginLeft"
	},
	mr: {
		type: "spacing",
		property: "marginRight"
	},
	ms: {
		type: "spacing",
		property: "marginInlineStart"
	},
	me: {
		type: "spacing",
		property: "marginInlineEnd"
	},
	mis: {
		type: "spacing",
		property: "marginInlineStart"
	},
	mie: {
		type: "spacing",
		property: "marginInlineEnd"
	},
	mx: {
		type: "spacing",
		property: "marginInline"
	},
	my: {
		type: "spacing",
		property: "marginBlock"
	},
	p: {
		type: "spacing",
		property: "padding"
	},
	pt: {
		type: "spacing",
		property: "paddingTop"
	},
	pb: {
		type: "spacing",
		property: "paddingBottom"
	},
	pl: {
		type: "spacing",
		property: "paddingLeft"
	},
	pr: {
		type: "spacing",
		property: "paddingRight"
	},
	ps: {
		type: "spacing",
		property: "paddingInlineStart"
	},
	pe: {
		type: "spacing",
		property: "paddingInlineEnd"
	},
	pis: {
		type: "spacing",
		property: "paddingInlineStart"
	},
	pie: {
		type: "spacing",
		property: "paddingInlineEnd"
	},
	px: {
		type: "spacing",
		property: "paddingInline"
	},
	py: {
		type: "spacing",
		property: "paddingBlock"
	},
	bd: {
		type: "border",
		property: "border"
	},
	bdrs: {
		type: "radius",
		property: "borderRadius"
	},
	bg: {
		type: "color",
		property: "background"
	},
	c: {
		type: "textColor",
		property: "color"
	},
	opacity: {
		type: "identity",
		property: "opacity"
	},
	ff: {
		type: "fontFamily",
		property: "fontFamily"
	},
	fz: {
		type: "fontSize",
		property: "fontSize"
	},
	fw: {
		type: "identity",
		property: "fontWeight"
	},
	lts: {
		type: "size",
		property: "letterSpacing"
	},
	ta: {
		type: "identity",
		property: "textAlign"
	},
	lh: {
		type: "lineHeight",
		property: "lineHeight"
	},
	fs: {
		type: "identity",
		property: "fontStyle"
	},
	tt: {
		type: "identity",
		property: "textTransform"
	},
	td: {
		type: "identity",
		property: "textDecoration"
	},
	w: {
		type: "spacing",
		property: "width"
	},
	miw: {
		type: "spacing",
		property: "minWidth"
	},
	maw: {
		type: "spacing",
		property: "maxWidth"
	},
	h: {
		type: "spacing",
		property: "height"
	},
	mih: {
		type: "spacing",
		property: "minHeight"
	},
	mah: {
		type: "spacing",
		property: "maxHeight"
	},
	bgsz: {
		type: "size",
		property: "backgroundSize"
	},
	bgp: {
		type: "identity",
		property: "backgroundPosition"
	},
	bgr: {
		type: "identity",
		property: "backgroundRepeat"
	},
	bga: {
		type: "identity",
		property: "backgroundAttachment"
	},
	pos: {
		type: "identity",
		property: "position"
	},
	top: {
		type: "size",
		property: "top"
	},
	left: {
		type: "size",
		property: "left"
	},
	bottom: {
		type: "size",
		property: "bottom"
	},
	right: {
		type: "size",
		property: "right"
	},
	inset: {
		type: "size",
		property: "inset"
	},
	display: {
		type: "identity",
		property: "display"
	},
	flex: {
		type: "identity",
		property: "flex"
	}
};
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/resolvers/color-resolver/color-resolver.mjs
function In(e, t) {
	let n = pt({
		color: e,
		theme: t
	});
	return n.color === "dimmed" ? "var(--mantine-color-dimmed)" : n.color === "bright" ? "var(--mantine-color-bright)" : n.variable ? `var(${n.variable})` : n.color;
}
function Ln(e, t) {
	let n = pt({
		color: e,
		theme: t
	});
	return n.isThemeColor && n.shade === void 0 ? `var(--mantine-color-${n.color}-text)` : In(e, t);
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/resolvers/border-resolver/border-resolver.mjs
function Rn(e, t) {
	if (typeof e == "number") return P(e);
	if (typeof e == "string") {
		let [n, r, ...i] = e.split(" ").filter((e) => e.trim() !== ""), a = `${P(n)}`;
		return r && (a += ` ${r}`), i.length > 0 && (a += ` ${In(i.join(" "), t)}`), a.trim();
	}
	return e;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/resolvers/font-family-resolver/font-family-resolver.mjs
var zn = {
	text: "var(--mantine-font-family)",
	mono: "var(--mantine-font-family-monospace)",
	monospace: "var(--mantine-font-family-monospace)",
	heading: "var(--mantine-font-family-headings)",
	headings: "var(--mantine-font-family-headings)"
};
function Bn(e) {
	return typeof e == "string" && e in zn ? zn[e] : e;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/resolvers/font-size-resolver/font-size-resolver.mjs
var Vn = [
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6"
];
function Hn(e, t) {
	return typeof e == "string" && e in t.fontSizes ? `var(--mantine-font-size-${e})` : typeof e == "string" && Vn.includes(e) ? `var(--mantine-${e}-font-size)` : typeof e == "number" || typeof e == "string" ? P(e) : e;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/resolvers/identity-resolver/identity-resolver.mjs
function Un(e) {
	return e;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/resolvers/line-height-resolver/line-height-resolver.mjs
var Wn = [
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6"
];
function Gn(e, t) {
	return typeof e == "string" && e in t.lineHeights ? `var(--mantine-line-height-${e})` : typeof e == "string" && Wn.includes(e) ? `var(--mantine-${e}-line-height)` : e;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/resolvers/radius-resolver/radius-resolver.mjs
function Kn(e, t) {
	return typeof e == "string" && e in t.radius ? `var(--mantine-radius-${e})` : typeof e == "number" || typeof e == "string" ? P(e) : e;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/resolvers/size-resolver/size-resolver.mjs
function qn(e) {
	return typeof e == "number" ? P(e) : e;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/resolvers/spacing-resolver/spacing-resolver.mjs
function Jn(e, t) {
	if (typeof e == "number") return P(e);
	if (typeof e == "string") {
		let n = e.replace("-", "");
		if (!(n in t.spacing)) return P(e);
		let r = `--mantine-spacing-${n}`;
		return e.startsWith("-") ? `calc(var(${r}) * -1)` : `var(${r})`;
	}
	return e;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/resolvers/index.mjs
var Yn = {
	color: In,
	textColor: Ln,
	fontSize: Hn,
	spacing: Jn,
	radius: Kn,
	identity: Un,
	size: qn,
	lineHeight: Gn,
	fontFamily: Bn,
	border: Rn
};
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/parse-style-props/sort-media-queries.mjs
function Xn(e) {
	return e.replace("(min-width: ", "").replace("em)", "");
}
function Zn({ media: e, ...t }) {
	let n = Object.keys(e).sort((e, t) => Number(Xn(e)) - Number(Xn(t))).map((t) => ({
		query: t,
		styles: e[t]
	}));
	return {
		...t,
		media: n
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/parse-style-props/parse-style-props.mjs
function Qn(e) {
	if (typeof e != "object" || !e) return !1;
	let t = Object.keys(e);
	return t.length !== 1 || t[0] !== "base";
}
function $n(e) {
	return typeof e == "object" && e ? "base" in e ? e.base : void 0 : e;
}
function er(e) {
	return typeof e == "object" && e ? D(e).filter((e) => e !== "base") : [];
}
function tr(e, t) {
	return typeof e == "object" && e && t in e ? e[t] : e;
}
function nr({ styleProps: e, data: t, theme: n }) {
	return Zn(D(e).reduce((r, i) => {
		if (i === "hiddenFrom" || i === "visibleFrom" || i === "sx") return r;
		let a = t[i], o = Array.isArray(a.property) ? a.property : [a.property], s = $n(e[i]);
		if (!Qn(e[i])) return o.forEach((e) => {
			r.inlineStyles[e] = Yn[a.type](s, n);
		}), r;
		r.hasResponsiveStyles = !0;
		let c = er(e[i]);
		return o.forEach((t) => {
			s != null && (r.styles[t] = Yn[a.type](s, n)), c.forEach((o) => {
				let s = `(min-width: ${n.breakpoints[o]})`;
				r.media[s] = {
					...r.media[s],
					[t]: Yn[a.type](tr(e[i], o), n)
				};
			});
		}), r;
	}, {
		hasResponsiveStyles: !1,
		styles: {},
		inlineStyles: {},
		media: {}
	}));
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/use-random-classname/use-random-classname.mjs
function rr() {
	return `__m__-${h().replace(/[:«»]/g, "")}`;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/get-style-object/get-style-object.mjs
function ir(e, t) {
	return Array.isArray(e) ? [...e].reduce((e, n) => ({
		...e,
		...ir(n, t)
	}), {}) : typeof e == "function" ? e(t) : e ?? {};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/factory/create-polymorphic-component.mjs
function ar(e) {
	return e;
}
var or = ar;
//#endregion
//#region node_modules/@mantine/core/esm/core/factory/factory.mjs
function sr(e) {
	return e;
}
function J(e) {
	let t = e;
	return t.extend = sr, t.withProps = (e) => {
		let n = (n) => /* @__PURE__ */ T(t, {
			...e,
			...n
		});
		return n.extend = t.extend, n.displayName = `WithProps(${t.displayName})`, n;
	}, t;
}
function cr(e) {
	return J(e);
}
//#endregion
//#region node_modules/@mantine/core/esm/core/factory/polymorphic-factory.mjs
function lr(e) {
	let t = e;
	return t.withProps = (e) => {
		let n = (n) => /* @__PURE__ */ T(t, {
			...e,
			...n
		});
		return n.extend = t.extend, n.displayName = `WithProps(${t.displayName})`, n;
	}, t.extend = sr, t;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/get-box-mod/get-box-mod.mjs
function ur(e) {
	return `data-${(e.startsWith("data-") ? e.slice(5) : e).replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase()}`;
}
function dr(e) {
	return Object.keys(e).reduce((t, n) => {
		let r = e[n];
		return r === void 0 || r === "" || r === !1 || r === null || (t[ur(n)] = e[n]), t;
	}, {});
}
function fr(e) {
	return e ? typeof e == "string" ? { [ur(e)]: !0 } : Array.isArray(e) ? [...e].reduce((e, t) => ({
		...e,
		...fr(t)
	}), {}) : dr(e) : null;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/get-box-style/get-box-style.mjs
function pr(e, t) {
	return Array.isArray(e) ? [...e].reduce((e, n) => ({
		...e,
		...pr(n, t)
	}), {}) : typeof e == "function" ? e(t) : e ?? {};
}
function mr({ theme: e, style: t, vars: n, styleProps: r }) {
	let i = pr(t, e), a = pr(n, e);
	return {
		...i,
		...a,
		...r
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/Box.mjs
function hr({ component: e, style: t, __vars: n, className: r, variant: i, mod: a, size: o, hiddenFrom: s, visibleFrom: c, lightHidden: l, darkHidden: u, renderRoot: d, __size: f, ref: p, ...m }) {
	let h = Zt(), g = e || "div", { styleProps: _, rest: v } = Pn(m), y = Mt()?.()?.(_.sx), b = rr(), x = nr({
		styleProps: _,
		theme: h,
		data: Fn
	}), S = Ft(), C = S && x.hasResponsiveStyles ? Nn(x.styles, x.media) : b, D = {
		ref: p,
		style: mr({
			theme: h,
			style: t,
			vars: n,
			styleProps: x.inlineStyles
		}),
		className: Xe(r, y, {
			[C]: x.hasResponsiveStyles,
			"mantine-light-hidden": l,
			"mantine-dark-hidden": u,
			[`mantine-hidden-from-${s}`]: s,
			[`mantine-visible-from-${c}`]: c
		}),
		"data-variant": i,
		"data-size": F(o) ? void 0 : o || void 0,
		size: f,
		...fr(a),
		...v
	};
	return /* @__PURE__ */ E(w, { children: [x.hasResponsiveStyles && /* @__PURE__ */ T(jn, {
		selector: `.${C}`,
		styles: x.styles,
		media: x.media,
		deduplicate: S
	}), typeof d == "function" ? d(D) : /* @__PURE__ */ T(g, { ...D })] });
}
hr.displayName = "@mantine/core/Box";
var Y = or(hr), gr = s({
	dir: "ltr",
	toggleDirection: () => {},
	setDirection: () => {}
});
function _r() {
	return u(gr);
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Collapse/Collapse.mjs
var vr = {
	transitionDuration: 200,
	transitionTimingFunction: "ease",
	animateOpacity: !0,
	orientation: "vertical",
	keepMounted: !0,
	keepMountedMode: "activity"
}, yr = J((e) => {
	let { children: t, expanded: n, transitionDuration: i, transitionTimingFunction: a, style: o, onTransitionEnd: s, onTransitionStart: c, animateOpacity: l, keepMounted: u, keepMountedMode: d, ref: f, orientation: p, ...m } = K("Collapse", vr, e), h = Pt(), g = Zt(), _ = Be(), v = g.respectReducedMotion && _ ? 0 : i, y = (p === "horizontal" ? Ke : Ue)({
		expanded: n,
		transitionDuration: v,
		transitionTimingFunction: a,
		onTransitionEnd: s,
		onTransitionStart: c,
		keepMounted: !1
	});
	if (v === 0) return u === !0 && (d === "display-none" || h !== "test") ? d === "display-none" ? /* @__PURE__ */ T(Y, {
		...m,
		style: {
			...ir(o, g),
			...n ? {} : { display: "none" }
		},
		ref: f,
		children: t
	}) : /* @__PURE__ */ T(r, {
		mode: n ? "visible" : "hidden",
		children: /* @__PURE__ */ T(Y, {
			...m,
			style: o,
			ref: f,
			children: t
		})
	}) : n ? /* @__PURE__ */ T(Y, {
		...m,
		style: o,
		ref: f,
		children: t
	}) : null;
	let b = y.state === "exited", x;
	return x = u === !1 ? b ? null : t : u === !0 ? d === "display-none" ? t : /* @__PURE__ */ T(r, {
		mode: b ? "hidden" : "visible",
		children: t
	}) : t, /* @__PURE__ */ T(Y, {
		...m,
		...y.getCollapseProps({
			style: {
				opacity: n || !l ? 1 : 0,
				transition: l ? `opacity ${v}ms ${a}` : "none",
				...ir(o, g),
				...u && d === "display-none" && b ? { display: "none" } : {}
			},
			ref: f
		}),
		children: x
	});
});
yr.displayName = "@mantine/core/Collapse";
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollArea.context.mjs
var [br, xr] = re("ScrollArea.Root component was not found in tree");
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/use-resize-observer.mjs
function Sr(e, t) {
	let n = m(t);
	Se(() => {
		let t = 0;
		if (e) {
			let r = new ResizeObserver(() => {
				cancelAnimationFrame(t), t = window.requestAnimationFrame(n);
			});
			return r.observe(e), () => {
				window.cancelAnimationFrame(t), r.unobserve(e);
			};
		}
	}, [e]);
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaCorner/ScrollAreaCorner.mjs
function Cr(e) {
	let { style: t, ...n } = e, r = xr(), [i, a] = y(0), [o, s] = y(0), c = !!(i && o);
	return Sr(r.scrollbarX, () => {
		let e = r.scrollbarX?.offsetHeight || 0;
		r.onCornerHeightChange(e), s(e);
	}), Sr(r.scrollbarY, () => {
		let e = r.scrollbarY?.offsetWidth || 0;
		r.onCornerWidthChange(e), a(e);
	}), c ? /* @__PURE__ */ T("div", {
		...n,
		style: {
			...t,
			width: i,
			height: o
		}
	}) : null;
}
function wr(e) {
	let t = xr(), n = !!(t.scrollbarX && t.scrollbarY);
	return t.type !== "scroll" && n ? /* @__PURE__ */ T(Cr, { ...e }) : null;
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaRoot/ScrollAreaRoot.mjs
var Tr = {
	scrollHideDelay: 1e3,
	type: "hover"
};
function Er(e) {
	let { type: t, scrollHideDelay: n, scrollbars: r, getStyles: i, ref: a, ...o } = K("ScrollAreaRoot", Tr, e), [s, c] = y(null), [l, u] = y(null), [d, f] = y(null), [p, m] = y(null), [h, g] = y(null), [_, v] = y(0), [b, x] = y(0), [S, C] = y(!1), [w, E] = y(!1), D = Re(a, c);
	return /* @__PURE__ */ T(br, {
		value: {
			type: t,
			scrollHideDelay: n,
			scrollArea: s,
			viewport: l,
			onViewportChange: u,
			content: d,
			onContentChange: f,
			scrollbarX: p,
			onScrollbarXChange: m,
			scrollbarXEnabled: S,
			onScrollbarXEnabledChange: C,
			scrollbarY: h,
			onScrollbarYChange: g,
			scrollbarYEnabled: w,
			onScrollbarYEnabledChange: E,
			onCornerWidthChange: v,
			onCornerHeightChange: x,
			getStyles: i
		},
		children: /* @__PURE__ */ T(Y, {
			...o,
			ref: D,
			__vars: {
				"--sa-corner-width": r === "xy" ? `${_}px` : "0px",
				"--sa-corner-height": r === "xy" ? `${b}px` : "0px"
			}
		})
	});
}
Er.displayName = "@mantine/core/ScrollAreaRoot";
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/utils/get-thumb-ratio.mjs
function Dr(e, t) {
	let n = e / t;
	return Number.isNaN(n) ? 0 : n;
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/utils/get-thumb-size.mjs
function Or(e) {
	let t = Dr(e.viewport, e.content), n = e.scrollbar.paddingStart + e.scrollbar.paddingEnd, r = (e.scrollbar.size - n) * t;
	return Math.max(r, 18);
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/utils/linear-scale.mjs
function kr(e, t) {
	return (n) => {
		if (e[0] === e[1] || t[0] === t[1]) return t[0];
		let r = (t[1] - t[0]) / (e[1] - e[0]);
		return t[0] + r * (n - e[0]);
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/utils/get-thumb-offset-from-scroll.mjs
function Ar(e, [t, n]) {
	return Math.min(n, Math.max(t, e));
}
function jr(e, t, n = "ltr") {
	let r = Or(t), i = t.scrollbar.paddingStart + t.scrollbar.paddingEnd, a = t.scrollbar.size - i, o = t.content - t.viewport, s = a - r, c = Ar(e, n === "ltr" ? [0, o] : [o * -1, 0]);
	return kr([0, o], [0, s])(c);
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/utils/get-scroll-position-from-pointer.mjs
function Mr(e, t, n, r = "ltr") {
	let i = Or(n), a = i / 2, o = t || a, s = i - o, c = n.scrollbar.paddingStart + o, l = n.scrollbar.size - n.scrollbar.paddingEnd - s, u = n.content - n.viewport, d = r === "ltr" ? [0, u] : [u * -1, 0];
	return kr([c, l], d)(e);
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/utils/is-scrolling-within-scrollbar-bounds.mjs
function Nr(e, t) {
	return e > 0 && e < t;
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/utils/to-int.mjs
function Pr(e) {
	return e ? parseInt(e, 10) : 0;
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/utils/compose-event-handlers.mjs
function Fr(e, t, { checkForDefaultPrevented: n = !0 } = {}) {
	return (r) => {
		e?.(r), (n === !1 || !r.defaultPrevented) && t?.(r);
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/Scrollbar.context.mjs
var [Ir, Lr] = re("ScrollAreaScrollbar was not found in tree");
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/Scrollbar.mjs
function Rr(e) {
	let { sizes: t, hasThumb: n, onThumbChange: r, onThumbPointerUp: i, onThumbPointerDown: a, onThumbPositionChange: o, onDragScroll: s, onWheelScroll: c, onResize: l, ref: u, ...d } = e, f = xr(), [h, g] = y(null), _ = Re(u, g), b = v(null), x = v(""), { viewport: S } = f, C = t.content - t.viewport, w = m(c), E = _e(o), D = ve(l, 10), O = (e) => {
		if (b.current) {
			let t = e.clientX - b.current.left, n = e.clientY - b.current.top;
			s({
				x: t,
				y: n
			});
		}
	};
	return p(() => {
		let e = (e) => {
			let t = e.target;
			h?.contains(t) && w(e, C);
		};
		return document.addEventListener("wheel", e, { passive: !1 }), () => document.removeEventListener("wheel", e, { passive: !1 });
	}, [
		S,
		h,
		C
	]), p(E, [t, E]), Sr(h, D), Sr(f.content, D), /* @__PURE__ */ T(Ir, {
		value: {
			scrollbar: h,
			hasThumb: n,
			onThumbChange: _e(r),
			onThumbPointerUp: _e(i),
			onThumbPositionChange: E,
			onThumbPointerDown: _e(a)
		},
		children: /* @__PURE__ */ T("div", {
			...d,
			ref: _,
			"data-mantine-scrollbar": !0,
			style: {
				position: "absolute",
				...d.style
			},
			onPointerDown: Fr(e.onPointerDown, (e) => {
				e.preventDefault(), e.button === 0 && (e.target.setPointerCapture(e.pointerId), b.current = h.getBoundingClientRect(), x.current = document.body.style.webkitUserSelect, document.body.style.webkitUserSelect = "none", O(e));
			}),
			onPointerMove: Fr(e.onPointerMove, O),
			onPointerUp: Fr(e.onPointerUp, (e) => {
				let t = e.target;
				t.hasPointerCapture(e.pointerId) && (e.preventDefault(), t.releasePointerCapture(e.pointerId));
			}),
			onLostPointerCapture: () => {
				document.body.style.webkitUserSelect = x.current, b.current = null;
			}
		})
	});
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/ScrollbarX.mjs
var zr = (e) => {
	let { sizes: t, onSizesChange: n, style: r, ref: i, ...a } = e, o = xr(), [s, c] = y(), l = v(null), u = Re(i, l, o.onScrollbarXChange);
	return p(() => {
		l.current && c(getComputedStyle(l.current));
	}, [l]), /* @__PURE__ */ T(Rr, {
		"data-orientation": "horizontal",
		...a,
		ref: u,
		sizes: t,
		style: {
			...r,
			"--sa-thumb-width": `${Or(t)}px`
		},
		onThumbPointerDown: (t) => e.onThumbPointerDown(t.x),
		onDragScroll: (t) => e.onDragScroll(t.x),
		onWheelScroll: (t, n) => {
			if (o.viewport) {
				let r = o.viewport.scrollLeft + t.deltaX;
				e.onWheelScroll(r), Nr(r, n) && t.preventDefault();
			}
		},
		onResize: () => {
			l.current && o.viewport && s && n({
				content: o.viewport.scrollWidth,
				viewport: o.viewport.offsetWidth,
				scrollbar: {
					size: l.current.clientWidth,
					paddingStart: Pr(s.paddingLeft),
					paddingEnd: Pr(s.paddingRight)
				}
			});
		}
	});
};
zr.displayName = "@mantine/core/ScrollAreaScrollbarX";
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/ScrollbarY.mjs
function Br(e) {
	let { sizes: t, onSizesChange: n, style: r, ref: i, ...a } = e, o = xr(), [s, c] = y(), l = v(null), u = Re(i, l, o.onScrollbarYChange);
	return p(() => {
		l.current && c(window.getComputedStyle(l.current));
	}, []), /* @__PURE__ */ T(Rr, {
		...a,
		"data-orientation": "vertical",
		ref: u,
		sizes: t,
		style: {
			"--sa-thumb-height": `${Or(t)}px`,
			...r
		},
		onThumbPointerDown: (t) => e.onThumbPointerDown(t.y),
		onDragScroll: (t) => e.onDragScroll(t.y),
		onWheelScroll: (t, n) => {
			if (o.viewport) {
				let r = o.viewport.scrollTop + t.deltaY;
				e.onWheelScroll(r), Nr(r, n) && t.preventDefault();
			}
		},
		onResize: () => {
			l.current && o.viewport && s && n({
				content: o.viewport.scrollHeight,
				viewport: o.viewport.offsetHeight,
				scrollbar: {
					size: l.current.clientHeight,
					paddingStart: Pr(s.paddingTop),
					paddingEnd: Pr(s.paddingBottom)
				}
			});
		}
	});
}
Br.displayName = "@mantine/core/ScrollAreaScrollbarY";
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/ScrollAreaScrollbarVisible.mjs
function Vr(e) {
	let { orientation: t = "vertical", ...n } = e, { dir: r } = _r(), i = xr(), a = v(null), o = v(0), [s, c] = y({
		content: 0,
		viewport: 0,
		scrollbar: {
			size: 0,
			paddingStart: 0,
			paddingEnd: 0
		}
	}), l = Dr(s.viewport, s.content), u = {
		...n,
		sizes: s,
		onSizesChange: c,
		hasThumb: l > 0 && l < 1,
		onThumbChange: (e) => {
			a.current = e;
		},
		onThumbPointerUp: () => {
			o.current = 0;
		},
		onThumbPointerDown: (e) => {
			o.current = e;
		}
	}, d = (e, t) => Mr(e, o.current, s, t);
	return t === "horizontal" ? /* @__PURE__ */ T(zr, {
		...u,
		onThumbPositionChange: () => {
			if (i.viewport && a.current) {
				let e = i.viewport.scrollLeft, t = jr(e, s, r);
				a.current.style.transform = `translate3d(${t}px, 0, 0)`;
			}
		},
		onWheelScroll: (e) => {
			i.viewport && (i.viewport.scrollLeft = e);
		},
		onDragScroll: (e) => {
			i.viewport && (i.viewport.scrollLeft = d(e, r));
		}
	}) : t === "vertical" ? /* @__PURE__ */ T(Br, {
		...u,
		onThumbPositionChange: () => {
			if (i.viewport && a.current) {
				let e = i.viewport.scrollTop, t = jr(e, s);
				s.scrollbar.size === 0 ? a.current.style.setProperty("--thumb-opacity", "0") : a.current.style.setProperty("--thumb-opacity", "1"), a.current.style.transform = `translate3d(0, ${t}px, 0)`;
			}
		},
		onWheelScroll: (e) => {
			i.viewport && (i.viewport.scrollTop = e);
		},
		onDragScroll: (e) => {
			i.viewport && (i.viewport.scrollTop = d(e));
		}
	}) : null;
}
Vr.displayName = "@mantine/core/ScrollAreaScrollbarVisible";
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/ScrollAreaScrollbarAuto.mjs
function Hr(e) {
	let t = xr(), { forceMount: n, ...r } = e, [i, a] = y(!1), o = e.orientation === "horizontal", s = ve(() => {
		if (t.viewport) {
			let e = t.viewport.offsetWidth < t.viewport.scrollWidth, n = t.viewport.offsetHeight < t.viewport.scrollHeight;
			a(o ? e : n);
		}
	}, 10);
	return Sr(t.viewport, s), Sr(t.content, s), n || i ? /* @__PURE__ */ T(Vr, {
		"data-state": i ? "visible" : "hidden",
		...r
	}) : null;
}
Hr.displayName = "@mantine/core/ScrollAreaScrollbarAuto";
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/ScrollAreaScrollbarHover.mjs
function Ur(e) {
	let { forceMount: t, ...n } = e, r = xr(), [i, a] = y(!1);
	return p(() => {
		let { scrollArea: e } = r, t = 0;
		if (e) {
			let n = () => {
				window.clearTimeout(t), a(!0);
			}, i = () => {
				t = window.setTimeout(() => a(!1), r.scrollHideDelay);
			};
			return e.addEventListener("pointerenter", n), e.addEventListener("pointerleave", i), () => {
				window.clearTimeout(t), e.removeEventListener("pointerenter", n), e.removeEventListener("pointerleave", i);
			};
		}
	}, [r.scrollArea, r.scrollHideDelay]), t || i ? /* @__PURE__ */ T(Hr, {
		"data-state": i ? "visible" : "hidden",
		...n
	}) : null;
}
Ur.displayName = "@mantine/core/ScrollAreaScrollbarHover";
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/ScrollAreaScrollbarScroll.mjs
function Wr(e) {
	let { forceMount: t, ...n } = e, r = xr(), i = e.orientation === "horizontal", [a, o] = y("hidden"), s = ve(() => o("idle"), 100);
	return p(() => {
		if (a === "idle") {
			let e = window.setTimeout(() => o("hidden"), r.scrollHideDelay);
			return () => window.clearTimeout(e);
		}
	}, [a, r.scrollHideDelay]), p(() => {
		let { viewport: e } = r, t = i ? "scrollLeft" : "scrollTop";
		if (e) {
			let n = e[t], r = () => {
				let r = e[t];
				n !== r && (o("scrolling"), s()), n = r;
			};
			return e.addEventListener("scroll", r), () => e.removeEventListener("scroll", r);
		}
	}, [
		r.viewport,
		i,
		s
	]), t || a !== "hidden" ? /* @__PURE__ */ T(Vr, {
		"data-state": a === "hidden" ? "hidden" : "visible",
		...n,
		onPointerEnter: Fr(e.onPointerEnter, () => o("interacting")),
		onPointerLeave: Fr(e.onPointerLeave, () => o("idle"))
	}) : null;
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/ScrollAreaScrollbar.mjs
function Gr(e) {
	let { forceMount: t, ...n } = e, r = xr(), { onScrollbarXEnabledChange: i, onScrollbarYEnabledChange: a } = r, o = e.orientation === "horizontal";
	return p(() => (o ? i(!0) : a(!0), () => {
		o ? i(!1) : a(!1);
	}), [
		o,
		i,
		a
	]), r.type === "hover" ? /* @__PURE__ */ T(Ur, {
		...n,
		forceMount: t
	}) : r.type === "scroll" ? /* @__PURE__ */ T(Wr, {
		...n,
		forceMount: t
	}) : r.type === "auto" ? /* @__PURE__ */ T(Hr, {
		...n,
		forceMount: t
	}) : r.type === "always" ? /* @__PURE__ */ T(Vr, { ...n }) : null;
}
Gr.displayName = "@mantine/core/ScrollAreaScrollbar";
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/utils/add-unlinked-scroll-listener.mjs
function Kr(e, t = () => {}) {
	let n = {
		left: e.scrollLeft,
		top: e.scrollTop
	}, r = 0;
	return (function i() {
		let a = {
			left: e.scrollLeft,
			top: e.scrollTop
		}, o = n.left !== a.left, s = n.top !== a.top;
		(o || s) && t(), n = a, r = window.requestAnimationFrame(i);
	})(), () => window.cancelAnimationFrame(r);
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaThumb/ScrollAreaThumb.mjs
function qr(e) {
	let { style: t, ref: n, ...r } = e, i = xr(), a = Lr(), { onThumbPositionChange: o } = a, s = Re(n, a.onThumbChange), c = v(void 0), l = ve(() => {
		c.current &&= (c.current(), void 0);
	}, 100);
	return p(() => {
		let { viewport: e } = i;
		if (e) {
			let t = () => {
				if (l(), !c.current) {
					let t = Kr(e, o);
					c.current = t, o();
				}
			};
			return o(), e.addEventListener("scroll", t), () => e.removeEventListener("scroll", t);
		}
	}, [
		i.viewport,
		l,
		o
	]), /* @__PURE__ */ T("div", {
		"data-state": a.hasThumb ? "visible" : "hidden",
		...r,
		ref: s,
		style: {
			width: "var(--sa-thumb-width)",
			height: "var(--sa-thumb-height)",
			...t
		},
		onPointerDownCapture: Fr(e.onPointerDownCapture, (e) => {
			let t = e.target.getBoundingClientRect(), n = e.clientX - t.left, r = e.clientY - t.top;
			a.onThumbPointerDown({
				x: n,
				y: r
			});
		}),
		onPointerUp: Fr(e.onPointerUp, a.onThumbPointerUp)
	});
}
qr.displayName = "@mantine/core/ScrollAreaThumb";
function Jr(e) {
	let { forceMount: t, ...n } = e, r = Lr();
	return t || r.hasThumb ? /* @__PURE__ */ T(qr, { ...n }) : null;
}
Jr.displayName = "@mantine/core/ScrollAreaThumb";
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaViewport/ScrollAreaViewport.mjs
function Yr({ children: e, style: t, ref: n, onWheel: r, ...i }) {
	let a = xr(), o = Re(n, a.onViewportChange), s = (e) => {
		if (r?.(e), a.scrollbarXEnabled && a.viewport && e.shiftKey) {
			let { scrollTop: t, scrollHeight: n, clientHeight: r, scrollWidth: i, clientWidth: o } = a.viewport, s = t < 1, c = t >= n - r - 1;
			i > o && (s || c) && e.stopPropagation();
		}
	};
	return /* @__PURE__ */ T(Y, {
		...i,
		ref: o,
		onWheel: s,
		"data-scrollarea-viewport": !0,
		style: {
			overflowX: a.scrollbarXEnabled ? "scroll" : "hidden",
			overflowY: a.scrollbarYEnabled ? "scroll" : "hidden",
			...t
		},
		children: /* @__PURE__ */ T("div", {
			...a.getStyles("content"),
			ref: a.onContentChange,
			children: e
		})
	});
}
Yr.displayName = "@mantine/core/ScrollAreaViewport";
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollArea.module.mjs
var Xr = {
	root: "m_d57069b5",
	content: "m_b1336c6",
	viewport: "m_c0783ff9",
	viewportInner: "m_f8f631dd",
	scrollbar: "m_c44ba933",
	thumb: "m_d8b5e363",
	corner: "m_21657268"
};
({ ...t }).useInsertionEffect;
//#endregion
//#region node_modules/@floating-ui/react/dist/floating-ui.react.mjs
function Zr(e) {
	let n = t.useRef(void 0), r = t.useCallback((t) => {
		let n = e.map((e) => {
			if (e != null) {
				if (typeof e == "function") {
					let n = e, r = n(t);
					return typeof r == "function" ? r : () => {
						n(null);
					};
				}
				return e.current = t, () => {
					e.current = null;
				};
			}
		});
		return () => {
			n.forEach((e) => e?.());
		};
	}, e);
	return t.useMemo(() => e.every((e) => e == null) ? null : (e) => {
		n.current &&= (n.current(), void 0), e != null && (n.current = r(e));
	}, e);
}
var Qr = "ArrowLeft", $r = "ArrowRight", ei = "ArrowUp", ti = "ArrowDown", ni = [Qr, $r], ri = [ei, ti];
[...ni, ...ri], { ...t }.useId, process.env.NODE_ENV;
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollArea.mjs
var ii = {
	scrollHideDelay: 1e3,
	type: "hover",
	scrollbars: "xy"
}, ai = G((e, { scrollbarSize: t, overscrollBehavior: n, scrollbars: r }) => {
	let i = n;
	return n && r && (r === "x" ? i = `${n} auto` : r === "y" && (i = `auto ${n}`)), { root: {
		"--scrollarea-scrollbar-size": P(t),
		"--scrollarea-over-scroll-behavior": i
	} };
}), oi = J((e) => {
	let t = K("ScrollArea", ii, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, scrollbarSize: s, vars: c, type: l, scrollHideDelay: u, viewportProps: f, viewportRef: p, onScrollPositionChange: m, children: h, offsetScrollbars: g, scrollbars: _, onBottomReached: b, onTopReached: x, onLeftReached: S, onRightReached: C, overscrollBehavior: w, startScrollPosition: D, verticalScrollbarPosition: O, attributes: k, ...ee } = t, [A, j] = y(!1), [M, N] = y(!1), [P, te] = y(!1), ne = v(!0), F = v(!1), I = v(!0), re = v(!1), L = q({
		name: "ScrollArea",
		props: t,
		classes: Xr,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: k,
		vars: c,
		varsResolver: ai
	}), R = v(null), [z, ie] = y(null), ae = Zr([
		p,
		R,
		d((e) => {
			ie((t) => t === e ? t : e);
		}, [])
	]);
	return Sr(g === "present" ? z : null, () => {
		let e = R.current;
		e && (N(e.scrollHeight > e.clientHeight), te(e.scrollWidth > e.clientWidth));
	}), Se(() => {
		D && R.current && R.current.scrollTo({
			left: D.x ?? 0,
			top: D.y ?? 0
		});
	}, []), /* @__PURE__ */ E(Er, {
		getStyles: L,
		type: l === "never" ? "always" : l,
		scrollHideDelay: u,
		scrollbars: _,
		...L("root"),
		...ee,
		children: [
			/* @__PURE__ */ T(Yr, {
				...f,
				...L("viewport", { style: f?.style }),
				ref: ae,
				"data-offset-scrollbars": g === !0 ? "xy" : g || void 0,
				"data-scrollbars": _ || void 0,
				"data-vertical-scrollbar-position": O || void 0,
				"data-horizontal-hidden": g === "present" && !P ? "true" : void 0,
				"data-vertical-hidden": g === "present" && !M ? "true" : void 0,
				onScroll: (e) => {
					f?.onScroll?.(e), m?.({
						x: e.currentTarget.scrollLeft,
						y: e.currentTarget.scrollTop
					});
					let { scrollTop: t, scrollHeight: n, clientHeight: r, scrollLeft: i, scrollWidth: a, clientWidth: o } = e.currentTarget, s = t - (n - r) >= -.8, c = t === 0;
					s && !F.current && b?.(), c && !ne.current && x?.(), F.current = s, ne.current = c;
					let l = i - (a - o) >= -.8, u = i === 0;
					l && !re.current && C?.(), u && !I.current && S?.(), re.current = l, I.current = u;
				},
				children: h
			}),
			(_ === "xy" || _ === "x") && /* @__PURE__ */ T(Gr, {
				...L("scrollbar"),
				orientation: "horizontal",
				"data-vertical-scrollbar-position": O || void 0,
				"data-hidden": l === "never" || g === "present" && !P || void 0,
				forceMount: !0,
				onMouseEnter: () => j(!0),
				onMouseLeave: () => j(!1),
				children: /* @__PURE__ */ T(Jr, { ...L("thumb") })
			}),
			(_ === "xy" || _ === "y") && /* @__PURE__ */ T(Gr, {
				...L("scrollbar"),
				orientation: "vertical",
				"data-vertical-scrollbar-position": O || void 0,
				"data-hidden": l === "never" || g === "present" && !M || void 0,
				forceMount: !0,
				onMouseEnter: () => j(!0),
				onMouseLeave: () => j(!1),
				children: /* @__PURE__ */ T(Jr, { ...L("thumb") })
			}),
			/* @__PURE__ */ T(wr, {
				...L("corner"),
				"data-vertical-scrollbar-position": O || void 0,
				"data-hovered": A || void 0,
				"data-hidden": l === "never" || void 0
			})
		]
	});
});
oi.displayName = "@mantine/core/ScrollArea";
var si = J((e) => {
	let { children: t, classNames: n, styles: r, scrollbarSize: i, scrollHideDelay: a, type: o, dir: s, offsetScrollbars: c, overscrollBehavior: l, viewportRef: u, onScrollPositionChange: f, unstyled: p, variant: h, viewportProps: g, scrollbars: _, style: b, vars: x, onBottomReached: S, onTopReached: C, startScrollPosition: w, verticalScrollbarPosition: E, onOverflowChange: D, ...O } = K("ScrollAreaAutosize", ii, e), k = v(null), [ee, A] = y(null), j = Zr([
		u,
		k,
		d((e) => {
			A((t) => t === e ? t : e);
		}, [])
	]), M = v(!1), N = v(!1), P = m(() => {
		let e = k.current;
		if (!e || !D) return;
		let t = e.scrollHeight > e.clientHeight;
		t !== M.current && (N.current ? D(t) : (N.current = !0, t && D(!0)), M.current = t);
	});
	return Sr(D ? ee : null, P), /* @__PURE__ */ T(Y, {
		...O,
		variant: h,
		style: [{
			display: "flex",
			overflow: "hidden"
		}, b],
		children: /* @__PURE__ */ T(Y, {
			style: {
				display: "flex",
				flexDirection: "column",
				flex: 1,
				overflow: "hidden",
				..._ === "y" && { minWidth: 0 },
				..._ === "x" && { minHeight: 0 },
				..._ === "xy" && {
					minWidth: 0,
					minHeight: 0
				},
				..._ === !1 && {
					minWidth: 0,
					minHeight: 0
				}
			},
			children: /* @__PURE__ */ T(oi, {
				classNames: n,
				styles: r,
				scrollHideDelay: a,
				scrollbarSize: i,
				type: o,
				dir: s,
				offsetScrollbars: c,
				overscrollBehavior: l,
				viewportRef: j,
				onScrollPositionChange: f,
				unstyled: p,
				variant: h,
				viewportProps: g,
				vars: x,
				scrollbars: _,
				onBottomReached: S,
				onTopReached: C,
				startScrollPosition: w,
				verticalScrollbarPosition: E,
				"data-autosize": "true",
				children: t
			})
		})
	});
});
oi.classes = Xr, oi.varsResolver = ai, si.displayName = "@mantine/core/ScrollAreaAutosize", si.classes = Xr, oi.Autosize = si;
//#endregion
//#region node_modules/@mantine/core/esm/components/UnstyledButton/UnstyledButton.module.mjs
var ci = { root: "m_87cf2631" }, li = { __staticSelector: "UnstyledButton" }, ui = lr((e) => {
	let t = K("UnstyledButton", li, e), { className: n, component: r = "button", __staticSelector: i, unstyled: a, classNames: o, styles: s, style: c, attributes: l, ...u } = t, d = q({
		name: i,
		props: t,
		classes: ci,
		className: n,
		style: c,
		classNames: o,
		styles: s,
		unstyled: a,
		attributes: l
	});
	return /* @__PURE__ */ T(Y, {
		...d("root", { focusable: !0 }),
		component: r,
		type: r === "button" ? "button" : void 0,
		...u
	});
});
ui.classes = ci, ui.displayName = "@mantine/core/UnstyledButton";
//#endregion
//#region node_modules/@mantine/core/esm/components/VisuallyHidden/VisuallyHidden.module.mjs
var di = { root: "m_515a97f8" }, fi = J((e) => {
	let t = K("VisuallyHidden", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, attributes: c, ...l } = t, u = q({
		name: "VisuallyHidden",
		classes: di,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: c
	});
	return /* @__PURE__ */ T(Y, {
		component: "span",
		...u("root"),
		...l
	});
});
fi.classes = di, fi.displayName = "@mantine/core/VisuallyHidden";
//#endregion
//#region node_modules/@mantine/core/esm/components/Paper/Paper.module.mjs
var pi = { root: "m_1b7284a3" }, mi = G((e, { radius: t, shadow: n }) => ({ root: {
	"--paper-radius": t === void 0 ? void 0 : ue(t),
	"--paper-shadow": U(n)
} })), hi = lr((e) => {
	let t = K("Paper", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, withBorder: s, vars: c, radius: l, shadow: u, variant: d, mod: f, attributes: p, ...m } = t, h = q({
		name: "Paper",
		props: t,
		classes: pi,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: p,
		vars: c,
		varsResolver: mi
	});
	return /* @__PURE__ */ T(Y, {
		mod: [{ withBorder: s }, f],
		...h("root"),
		variant: d,
		...m
	});
});
hi.classes = pi, hi.varsResolver = mi, hi.displayName = "@mantine/core/Paper";
//#endregion
//#region node_modules/@mantine/core/esm/components/Overlay/Overlay.module.mjs
var gi = { root: "m_9814e45f" }, _i = { zIndex: ce("modal") }, vi = G((e, { gradient: t, color: n, backgroundOpacity: r, blur: i, radius: a, zIndex: o }) => ({ root: {
	"--overlay-bg": t || (n !== void 0 || r !== void 0) && vt(n || "#000", r ?? .6) || void 0,
	"--overlay-filter": i ? `blur(${P(i)})` : void 0,
	"--overlay-radius": a === void 0 ? void 0 : ue(a),
	"--overlay-z-index": o?.toString()
} })), yi = lr((e) => {
	let t = K("Overlay", _i, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, fixed: c, center: l, children: u, radius: d, zIndex: f, gradient: p, blur: m, color: h, backgroundOpacity: g, mod: _, attributes: v, ...y } = t, b = q({
		name: "Overlay",
		props: t,
		classes: gi,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: v,
		vars: s,
		varsResolver: vi
	});
	return /* @__PURE__ */ T(Y, {
		...b("root"),
		mod: [{
			center: l,
			fixed: c
		}, _],
		...y,
		children: u
	});
});
yi.classes = gi, yi.varsResolver = vi, yi.displayName = "@mantine/core/Overlay";
//#endregion
//#region node_modules/@mantine/core/esm/components/Portal/Portal.mjs
function bi(e) {
	let t = document.createElement("div");
	return t.setAttribute("data-portal", "true"), typeof e.className == "string" && t.classList.add(...e.className.split(" ").filter(Boolean)), typeof e.style == "object" && Object.assign(t.style, e.style), typeof e.id == "string" && t.setAttribute("id", e.id), t;
}
function xi({ target: e, reuseTargetNode: t, ...n }) {
	if (e) return typeof e == "string" ? document.querySelector(e) || bi(n) : e;
	if (t) {
		let e = document.querySelector("[data-mantine-shared-portal-node]");
		if (e) return e;
		let t = bi(n);
		return t.setAttribute("data-mantine-shared-portal-node", "true"), document.body.appendChild(t), t;
	}
	return bi(n);
}
var Si = { reuseTargetNode: !0 }, Ci = J((e) => {
	let { children: t, target: n, reuseTargetNode: r, ref: i, ...a } = K("Portal", Si, e), [o, s] = y(!1), c = v(null);
	return Se(() => (s(!0), c.current = xi({
		target: n,
		reuseTargetNode: r,
		...a
	}), Ie(i, c.current), !n && !r && c.current && document.body.appendChild(c.current), () => {
		!n && !r && c.current && document.body.removeChild(c.current);
	}), [n]), !o || !c.current ? null : S(/* @__PURE__ */ T(w, { children: t }), c.current);
});
Ci.displayName = "@mantine/core/Portal";
//#endregion
//#region node_modules/@mantine/core/esm/components/Portal/OptionalPortal.mjs
var wi = J(({ withinPortal: e = !0, children: t, ...n }) => Pt() === "test" || !e ? /* @__PURE__ */ T(w, { children: t }) : /* @__PURE__ */ T(Ci, {
	...n,
	children: t
}));
wi.displayName = "@mantine/core/OptionalPortal";
//#endregion
//#region node_modules/@mantine/core/esm/components/Transition/transitions.mjs
var Ti = (e) => ({
	in: {
		opacity: 1,
		transform: "scale(1)"
	},
	out: {
		opacity: 0,
		transform: `scale(.9) translateY(${e === "bottom" ? 10 : -10}px)`
	},
	transitionProperty: "transform, opacity"
}), Ei = {
	fade: {
		in: { opacity: 1 },
		out: { opacity: 0 },
		transitionProperty: "opacity"
	},
	"fade-up": {
		in: {
			opacity: 1,
			transform: "translateY(0)"
		},
		out: {
			opacity: 0,
			transform: "translateY(30px)"
		},
		transitionProperty: "opacity, transform"
	},
	"fade-down": {
		in: {
			opacity: 1,
			transform: "translateY(0)"
		},
		out: {
			opacity: 0,
			transform: "translateY(-30px)"
		},
		transitionProperty: "opacity, transform"
	},
	"fade-left": {
		in: {
			opacity: 1,
			transform: "translateX(0)"
		},
		out: {
			opacity: 0,
			transform: "translateX(30px)"
		},
		transitionProperty: "opacity, transform"
	},
	"fade-right": {
		in: {
			opacity: 1,
			transform: "translateX(0)"
		},
		out: {
			opacity: 0,
			transform: "translateX(-30px)"
		},
		transitionProperty: "opacity, transform"
	},
	scale: {
		in: {
			opacity: 1,
			transform: "scale(1)"
		},
		out: {
			opacity: 0,
			transform: "scale(0)"
		},
		common: { transformOrigin: "top" },
		transitionProperty: "transform, opacity"
	},
	"scale-y": {
		in: {
			opacity: 1,
			transform: "scaleY(1)"
		},
		out: {
			opacity: 0,
			transform: "scaleY(0)"
		},
		common: { transformOrigin: "top" },
		transitionProperty: "transform, opacity"
	},
	"scale-x": {
		in: {
			opacity: 1,
			transform: "scaleX(1)"
		},
		out: {
			opacity: 0,
			transform: "scaleX(0)"
		},
		common: { transformOrigin: "left" },
		transitionProperty: "transform, opacity"
	},
	"skew-up": {
		in: {
			opacity: 1,
			transform: "translateY(0) skew(0deg, 0deg)"
		},
		out: {
			opacity: 0,
			transform: "translateY(-20px) skew(-10deg, -5deg)"
		},
		common: { transformOrigin: "top" },
		transitionProperty: "transform, opacity"
	},
	"skew-down": {
		in: {
			opacity: 1,
			transform: "translateY(0) skew(0deg, 0deg)"
		},
		out: {
			opacity: 0,
			transform: "translateY(20px) skew(-10deg, -5deg)"
		},
		common: { transformOrigin: "bottom" },
		transitionProperty: "transform, opacity"
	},
	"rotate-left": {
		in: {
			opacity: 1,
			transform: "translateY(0) rotate(0deg)"
		},
		out: {
			opacity: 0,
			transform: "translateY(20px) rotate(-5deg)"
		},
		common: { transformOrigin: "bottom" },
		transitionProperty: "transform, opacity"
	},
	"rotate-right": {
		in: {
			opacity: 1,
			transform: "translateY(0) rotate(0deg)"
		},
		out: {
			opacity: 0,
			transform: "translateY(20px) rotate(5deg)"
		},
		common: { transformOrigin: "top" },
		transitionProperty: "transform, opacity"
	},
	"slide-down": {
		in: {
			opacity: 1,
			transform: "translateY(0)"
		},
		out: {
			opacity: 0,
			transform: "translateY(-100%)"
		},
		common: { transformOrigin: "top" },
		transitionProperty: "transform, opacity"
	},
	"slide-up": {
		in: {
			opacity: 1,
			transform: "translateY(0)"
		},
		out: {
			opacity: 0,
			transform: "translateY(100%)"
		},
		common: { transformOrigin: "bottom" },
		transitionProperty: "transform, opacity"
	},
	"slide-left": {
		in: {
			opacity: 1,
			transform: "translateX(0)"
		},
		out: {
			opacity: 0,
			transform: "translateX(100%)"
		},
		common: { transformOrigin: "left" },
		transitionProperty: "transform, opacity"
	},
	"slide-right": {
		in: {
			opacity: 1,
			transform: "translateX(0)"
		},
		out: {
			opacity: 0,
			transform: "translateX(-100%)"
		},
		common: { transformOrigin: "right" },
		transitionProperty: "transform, opacity"
	},
	pop: {
		...Ti("bottom"),
		common: { transformOrigin: "center center" }
	},
	"pop-bottom-left": {
		...Ti("bottom"),
		common: { transformOrigin: "bottom left" }
	},
	"pop-bottom-right": {
		...Ti("bottom"),
		common: { transformOrigin: "bottom right" }
	},
	"pop-top-left": {
		...Ti("top"),
		common: { transformOrigin: "top left" }
	},
	"pop-top-right": {
		...Ti("top"),
		common: { transformOrigin: "top right" }
	}
}, Di = {
	entering: "in",
	entered: "in",
	exiting: "out",
	exited: "out",
	"pre-exiting": "out",
	"pre-entering": "out"
};
function Oi({ transition: e, state: t, duration: n, timingFunction: r }) {
	let i = {
		WebkitBackfaceVisibility: "hidden",
		transitionDuration: `${n}ms`,
		transitionTimingFunction: r
	};
	return typeof e == "string" ? e in Ei ? {
		transitionProperty: Ei[e].transitionProperty,
		...i,
		...Ei[e].common,
		...Ei[e][Di[t]]
	} : {} : {
		transitionProperty: e.transitionProperty,
		...i,
		...e.common,
		...e[Di[t]]
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Transition/use-transition.mjs
function ki({ duration: e, exitDuration: t, timingFunction: n, mounted: r, onEnter: i, onExit: a, onEntered: o, onExited: s, enterDelay: c, exitDelay: l }) {
	let u = Zt(), d = Be(), f = u.respectReducedMotion ? d : !1, [m, h] = y(f ? 0 : e), [g, _] = y(r ? "entered" : "exited"), b = v(-1), S = v(-1), C = v(-1);
	function w() {
		window.clearTimeout(b.current), window.clearTimeout(S.current), cancelAnimationFrame(C.current);
	}
	let T = (n) => {
		w();
		let r = n ? i : a, c = n ? o : s, l = f ? 0 : n ? e : t;
		h(l), l === 0 ? (typeof r == "function" && r(), typeof c == "function" && c(), _(n ? "entered" : "exited")) : C.current = requestAnimationFrame(() => {
			x.flushSync(() => {
				_(n ? "pre-entering" : "pre-exiting");
			}), C.current = requestAnimationFrame(() => {
				typeof r == "function" && r(), _(n ? "entering" : "exiting"), b.current = window.setTimeout(() => {
					typeof c == "function" && c(), _(n ? "entered" : "exited");
				}, l);
			});
		});
	}, E = (e) => {
		if (w(), typeof (e ? c : l) != "number") {
			T(e);
			return;
		}
		S.current = window.setTimeout(() => {
			T(e);
		}, e ? c : l);
	};
	return W(() => {
		E(r);
	}, [r]), p(() => () => {
		w();
	}, []), {
		transitionDuration: m,
		transitionStatus: g,
		transitionTimingFunction: n || "ease"
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Transition/Transition.mjs
function Ai({ keepMounted: e, keepMountedMode: t = "activity", transition: n = "fade", duration: i = 250, exitDuration: a = i, mounted: o, children: s, timingFunction: c = "ease", onExit: l, onEntered: u, onEnter: d, onExited: f, enterDelay: p, exitDelay: m }) {
	let h = Pt(), { transitionDuration: g, transitionStatus: _, transitionTimingFunction: v } = ki({
		mounted: o,
		exitDuration: a,
		duration: i,
		timingFunction: c,
		onExit: l,
		onEntered: u,
		onEnter: d,
		onExited: f,
		enterDelay: p,
		exitDelay: m
	});
	if (h === "test") return o ? /* @__PURE__ */ T(w, { children: s({}) }) : e ? s({ display: "none" }) : null;
	if (g === 0) return e ? t === "display-none" ? o ? /* @__PURE__ */ T(w, { children: s({}) }) : s({ display: "none" }) : /* @__PURE__ */ T(r, {
		mode: o ? "visible" : "hidden",
		children: s({})
	}) : o ? /* @__PURE__ */ T(w, { children: s({}) }) : null;
	let y = _ === "exited";
	if (e) {
		let e = s(y ? t === "display-none" ? { display: "none" } : {} : Oi({
			transition: n,
			duration: g,
			state: _,
			timingFunction: v
		}));
		return t === "display-none" ? e : /* @__PURE__ */ T(r, {
			mode: y ? "hidden" : "visible",
			children: e
		});
	}
	return y ? null : /* @__PURE__ */ T(w, { children: s(Oi({
		transition: n,
		duration: g,
		state: _,
		timingFunction: v
	})) });
}
Ai.displayName = "@mantine/core/Transition";
//#endregion
//#region node_modules/@mantine/core/esm/components/FocusTrap/FocusTrap.mjs
function ji({ children: e, active: t = !0, refProp: n = "ref", innerRef: r }) {
	let i = Re(Ne(t), r), a = Je(e);
	return a ? o(a, { [n]: i }) : e;
}
function Mi(e) {
	return /* @__PURE__ */ T(fi, {
		tabIndex: -1,
		"data-autofocus": !0,
		...e
	});
}
ji.displayName = "@mantine/core/FocusTrap", Mi.displayName = "@mantine/core/FocusTrapInitialFocus", ji.InitialFocus = Mi;
//#endregion
//#region node_modules/@mantine/core/esm/components/Loader/Loader.module.mjs
var Ni = {
	root: "m_5ae2e3c",
	barsLoader: "m_7a2bd4cd",
	bar: "m_870bb79",
	"bars-loader-animation": "m_5d2b3b9d",
	dotsLoader: "m_4e3f22d7",
	dot: "m_870c4af",
	"loader-dots-animation": "m_aac34a1",
	ovalLoader: "m_b34414df",
	"oval-loader-animation": "m_f8e89c4b"
}, Pi = ({ className: e, ...t }) => /* @__PURE__ */ E(Y, {
	component: "span",
	className: Xe(Ni.barsLoader, e),
	...t,
	children: [
		/* @__PURE__ */ T("span", { className: Ni.bar }),
		/* @__PURE__ */ T("span", { className: Ni.bar }),
		/* @__PURE__ */ T("span", { className: Ni.bar })
	]
});
Pi.displayName = "@mantine/core/Bars";
//#endregion
//#region node_modules/@mantine/core/esm/components/Loader/loaders/Dots.mjs
var Fi = ({ className: e, ...t }) => /* @__PURE__ */ E(Y, {
	component: "span",
	className: Xe(Ni.dotsLoader, e),
	...t,
	children: [
		/* @__PURE__ */ T("span", { className: Ni.dot }),
		/* @__PURE__ */ T("span", { className: Ni.dot }),
		/* @__PURE__ */ T("span", { className: Ni.dot })
	]
});
Fi.displayName = "@mantine/core/Dots";
//#endregion
//#region node_modules/@mantine/core/esm/components/Loader/loaders/Oval.mjs
var Ii = ({ className: e, ...t }) => /* @__PURE__ */ T(Y, {
	component: "span",
	className: Xe(Ni.ovalLoader, e),
	...t
});
Ii.displayName = "@mantine/core/Oval";
//#endregion
//#region node_modules/@mantine/core/esm/components/Loader/Loader.mjs
var Li = {
	bars: Pi,
	oval: Ii,
	dots: Fi
}, Ri = {
	loaders: Li,
	type: "oval"
}, zi = G((e, { size: t, color: n }) => ({ root: {
	"--loader-size": B(t, "loader-size"),
	"--loader-color": n ? mt(n, e) : void 0
} })), Bi = J((e) => {
	let t = K("Loader", Ri, e), { size: n, color: r, type: i, vars: a, className: o, style: s, classNames: c, styles: l, unstyled: u, loaders: d, variant: f, children: p, attributes: m, ...h } = t, g = q({
		name: "Loader",
		props: t,
		classes: Ni,
		className: o,
		style: s,
		classNames: c,
		styles: l,
		unstyled: u,
		attributes: m,
		vars: a,
		varsResolver: zi
	});
	return p ? /* @__PURE__ */ T(Y, {
		...g("root"),
		...h,
		children: p
	}) : /* @__PURE__ */ T(Y, {
		...g("root"),
		component: d[i],
		variant: f,
		size: n,
		...h
	});
});
Bi.defaultLoaders = Li, Bi.classes = Ni, Bi.varsResolver = zi, Bi.displayName = "@mantine/core/Loader";
//#endregion
//#region node_modules/@mantine/core/esm/components/ActionIcon/ActionIcon.module.mjs
var Vi = {
	root: "m_8d3f4000",
	icon: "m_8d3afb97",
	loader: "m_302b9fb1",
	group: "m_1a0f1b21",
	groupSection: "m_437b6484"
}, Hi = { orientation: "horizontal" }, Ui = G((e, { borderWidth: t }) => ({ group: { "--ai-border-width": P(t) } })), Wi = J((e) => {
	let t = K("ActionIconGroup", Hi, e), { className: n, style: r, classNames: i, styles: a, unstyled: o, orientation: s, vars: c, borderWidth: l, variant: u, mod: d, attributes: f, ...p } = t, m = q({
		name: "ActionIconGroup",
		props: t,
		classes: Vi,
		className: n,
		style: r,
		classNames: i,
		styles: a,
		unstyled: o,
		attributes: f,
		vars: c,
		varsResolver: Ui,
		rootSelector: "group"
	});
	return /* @__PURE__ */ T(Y, {
		...m("group"),
		variant: u,
		mod: [{ orientation: s }, d],
		role: "group",
		...p
	});
});
Wi.classes = Vi, Wi.varsResolver = Ui, Wi.displayName = "@mantine/core/ActionIconGroup";
//#endregion
//#region node_modules/@mantine/core/esm/components/ActionIcon/ActionIconGroupSection/ActionIconGroupSection.mjs
var Gi = G((e, { radius: t, color: n, gradient: r, variant: i, autoContrast: a, size: o }) => {
	let s = e.variantColorResolver({
		color: n || e.primaryColor,
		theme: e,
		gradient: r,
		variant: i || "filled",
		autoContrast: a
	});
	return { groupSection: {
		"--section-height": B(o, "section-height"),
		"--section-padding-x": B(o, "section-padding-x"),
		"--section-fz": H(o),
		"--section-radius": t === void 0 ? void 0 : ue(t),
		"--section-bg": n || i ? s.background : void 0,
		"--section-color": s.color,
		"--section-bd": n || i ? s.border : void 0
	} };
}), Ki = J((e) => {
	let t = K("ActionIconGroupSection", null, e), { className: n, style: r, classNames: i, styles: a, unstyled: o, vars: s, variant: c, gradient: l, radius: u, autoContrast: d, attributes: f, ...p } = t, m = q({
		name: "ActionIconGroupSection",
		props: t,
		classes: Vi,
		className: n,
		style: r,
		classNames: i,
		styles: a,
		unstyled: o,
		attributes: f,
		vars: s,
		varsResolver: Gi,
		rootSelector: "groupSection"
	});
	return /* @__PURE__ */ T(Y, {
		...m("groupSection"),
		variant: c,
		...p
	});
});
Ki.classes = Vi, Ki.varsResolver = Gi, Ki.displayName = "@mantine/core/ActionIconGroupSection";
//#endregion
//#region node_modules/@mantine/core/esm/components/ActionIcon/ActionIcon.mjs
var qi = G((e, { size: t, radius: n, variant: r, gradient: i, color: a, autoContrast: o }) => {
	let s = e.variantColorResolver({
		color: a || e.primaryColor,
		theme: e,
		gradient: i,
		variant: r || "filled",
		autoContrast: o
	});
	return { root: {
		"--ai-size": B(t, "ai-size"),
		"--ai-radius": n === void 0 ? void 0 : ue(n),
		"--ai-bg": a || r ? s.background : void 0,
		"--ai-hover": a || r ? s.hover : void 0,
		"--ai-hover-color": a || r ? s.hoverColor : void 0,
		"--ai-color": s.color,
		"--ai-bd": a || r ? s.border : void 0
	} };
}), Ji = lr((e) => {
	let t = K("ActionIcon", null, e), { className: n, unstyled: r, variant: i, classNames: a, styles: o, style: s, loading: c, loaderProps: l, size: u, color: d, radius: f, __staticSelector: p, gradient: m, vars: h, children: g, disabled: _, "data-disabled": v, autoContrast: y, mod: b, attributes: x, ...S } = t, C = q({
		name: ["ActionIcon", p],
		props: t,
		className: n,
		style: s,
		classes: Vi,
		classNames: a,
		styles: o,
		unstyled: r,
		attributes: x,
		vars: h,
		varsResolver: qi
	});
	return /* @__PURE__ */ E(ui, {
		...C("root", { active: !_ && !c && !v }),
		"aria-busy": c || void 0,
		...S,
		unstyled: r,
		variant: i,
		size: u,
		disabled: _ || c,
		mod: [{
			loading: c,
			disabled: _ || v
		}, b],
		children: [typeof c == "boolean" && /* @__PURE__ */ T(Ai, {
			mounted: c,
			transition: "slide-down",
			duration: 150,
			children: (e) => /* @__PURE__ */ T(Y, {
				component: "span",
				...C("loader", { style: e }),
				"aria-hidden": !0,
				children: /* @__PURE__ */ T(Bi, {
					color: "var(--ai-color)",
					size: "calc(var(--ai-size) * 0.55)",
					...l
				})
			})
		}), /* @__PURE__ */ T(Y, {
			component: "span",
			mod: { loading: c },
			...C("icon"),
			children: g
		})]
	});
});
Ji.classes = Vi, Ji.varsResolver = qi, Ji.displayName = "@mantine/core/ActionIcon", Ji.Group = Wi, Ji.GroupSection = Ki;
//#endregion
//#region node_modules/@mantine/core/esm/components/CloseButton/CloseIcon.mjs
function Yi({ size: e = "var(--cb-icon-size, 70%)", style: t, ...n }) {
	return /* @__PURE__ */ T("svg", {
		viewBox: "0 0 15 15",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		style: {
			...t,
			width: e,
			height: e
		},
		...n,
		children: /* @__PURE__ */ T("path", {
			d: "M11.7816 4.03157C12.0062 3.80702 12.0062 3.44295 11.7816 3.2184C11.5571 2.99385 11.193 2.99385 10.9685 3.2184L7.50005 6.68682L4.03164 3.2184C3.80708 2.99385 3.44301 2.99385 3.21846 3.2184C2.99391 3.44295 2.99391 3.80702 3.21846 4.03157L6.68688 7.49999L3.21846 10.9684C2.99391 11.193 2.99391 11.557 3.21846 11.7816C3.44301 12.0061 3.80708 12.0061 4.03164 11.7816L7.50005 8.31316L10.9685 11.7816C11.193 12.0061 11.5571 12.0061 11.7816 11.7816C12.0062 11.557 12.0062 11.193 11.7816 10.9684L8.31322 7.49999L11.7816 4.03157Z",
			fill: "currentColor",
			fillRule: "evenodd",
			clipRule: "evenodd"
		})
	});
}
Yi.displayName = "@mantine/core/CloseIcon";
//#endregion
//#region node_modules/@mantine/core/esm/components/CloseButton/CloseButton.module.mjs
var Xi = {
	root: "m_86a44da5",
	"root--subtle": "m_220c80f2"
}, Zi = { variant: "subtle" }, Qi = G((e, { size: t, radius: n, iconSize: r }) => ({ root: {
	"--cb-size": B(t, "cb-size"),
	"--cb-radius": n === void 0 ? void 0 : ue(n),
	"--cb-icon-size": P(r)
} })), $i = lr((e) => {
	let t = K("CloseButton", Zi, e), { iconSize: n, children: r, vars: i, radius: a, className: o, classNames: s, style: c, styles: l, unstyled: u, "data-disabled": d, disabled: f, variant: p, icon: m, mod: h, attributes: g, __staticSelector: _, ...v } = t, y = q({
		name: _ || "CloseButton",
		props: t,
		className: o,
		style: c,
		classes: Xi,
		classNames: s,
		styles: l,
		unstyled: u,
		attributes: g,
		vars: i,
		varsResolver: Qi
	});
	return /* @__PURE__ */ E(ui, {
		...v,
		unstyled: u,
		variant: p,
		disabled: f,
		mod: [{ disabled: f || d }, h],
		...y("root", {
			variant: p,
			active: !f && !d
		}),
		children: [m || /* @__PURE__ */ T(Yi, {}), r]
	});
});
$i.classes = Xi, $i.varsResolver = Qi, $i.displayName = "@mantine/core/CloseButton";
//#endregion
//#region node_modules/@mantine/core/esm/components/Group/filter-falsy-children/filter-falsy-children.mjs
function ea(e) {
	return i.toArray(e).filter(Boolean);
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Group/Group.module.mjs
var ta = { root: "m_4081bf90" }, na = {
	preventGrowOverflow: !0,
	gap: "md",
	align: "center",
	justify: "flex-start",
	wrap: "wrap"
}, ra = G((e, { grow: t, preventGrowOverflow: n, gap: r, align: i, justify: a, wrap: o }, { childWidth: s }) => ({ root: {
	"--group-child-width": t && n ? s : void 0,
	"--group-gap": V(r),
	"--group-align": i,
	"--group-justify": a,
	"--group-wrap": o
} })), X = J((e) => {
	let t = K("Group", na, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, children: s, gap: c, align: l, justify: u, wrap: d, grow: f, preventGrowOverflow: p, vars: m, variant: h, __size: g, mod: _, attributes: v, ...y } = t, b = ea(s), x = b.length, S = V(c ?? "md"), C = q({
		name: "Group",
		props: t,
		stylesCtx: { childWidth: `calc(${100 / x}% - (${S} - ${S} / ${x}))` },
		className: r,
		style: i,
		classes: ta,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: v,
		vars: m,
		varsResolver: ra
	});
	return /* @__PURE__ */ T(Y, {
		...C("root"),
		variant: h,
		mod: [{ grow: f }, _],
		size: g,
		...y,
		children: b
	});
});
X.classes = ta, X.varsResolver = ra, X.displayName = "@mantine/core/Group";
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/ModalBase.context.mjs
var [ia, aa] = re("ModalBase component was not found in tree");
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/use-lock-scroll.mjs
function oa({ opened: e, transitionDuration: t }) {
	let [n, r] = y(e), i = v(-1), a = Be() ? 0 : t;
	return p(() => (e ? (r(!0), window.clearTimeout(i.current)) : a === 0 ? r(!1) : i.current = window.setTimeout(() => r(!1), a), () => window.clearTimeout(i.current)), [e, a]), n;
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/use-modal.mjs
function sa({ id: e, transitionProps: t, opened: n, trapFocus: r, closeOnEscape: i, onClose: a, returnFocus: o }) {
	let s = Pe(e), [c, l] = y(!1), [u, d] = y(!1), f = oa({
		opened: n,
		transitionDuration: typeof t?.duration == "number" ? t?.duration : 200
	});
	return Fe("keydown", (e) => {
		e.key === "Escape" && i && !e.isComposing && n && e.target?.getAttribute("data-mantine-stop-propagation") !== "true" && a();
	}, { capture: !0 }), Ce({
		opened: n,
		shouldReturnFocus: r && o
	}), {
		_id: s,
		titleMounted: c,
		bodyMounted: u,
		shouldLockScroll: f,
		setTitleMounted: l,
		setBodyMounted: d
	};
}
//#endregion
//#region node_modules/tslib/tslib.es6.mjs
var ca = function() {
	return ca = Object.assign || function(e) {
		for (var t, n = 1, r = arguments.length; n < r; n++) for (var i in t = arguments[n], t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
		return e;
	}, ca.apply(this, arguments);
};
function la(e, t) {
	var n = {};
	for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
	if (e != null && typeof Object.getOwnPropertySymbols == "function") for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++) t.indexOf(r[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (n[r[i]] = e[r[i]]);
	return n;
}
function ua(e, t, n) {
	if (n || arguments.length === 2) for (var r = 0, i = t.length, a; r < i; r++) (a || !(r in t)) && (a ||= Array.prototype.slice.call(t, 0, r), a[r] = t[r]);
	return e.concat(a || Array.prototype.slice.call(t));
}
//#endregion
//#region node_modules/react-remove-scroll-bar/dist/es2015/constants.js
var da = "right-scroll-bar-position", fa = "width-before-scroll-bar", pa = "with-scroll-bars-hidden", ma = "--removed-body-scroll-bar-size";
//#endregion
//#region node_modules/use-callback-ref/dist/es2015/assignRef.js
function ha(e, t) {
	return typeof e == "function" ? e(t) : e && (e.current = t), e;
}
//#endregion
//#region node_modules/use-callback-ref/dist/es2015/useRef.js
function ga(e, t) {
	var n = y(function() {
		return {
			value: e,
			callback: t,
			facade: {
				get current() {
					return n.value;
				},
				set current(e) {
					var t = n.value;
					t !== e && (n.value = e, n.callback(e, t));
				}
			}
		};
	})[0];
	return n.callback = t, n.facade;
}
//#endregion
//#region node_modules/use-callback-ref/dist/es2015/useMergeRef.js
var _a = typeof window < "u" ? t.useLayoutEffect : t.useEffect, va = /* @__PURE__ */ new WeakMap();
function ya(e, t) {
	var n = ga(t || null, function(t) {
		return e.forEach(function(e) {
			return ha(e, t);
		});
	});
	return _a(function() {
		var t = va.get(n);
		if (t) {
			var r = new Set(t), i = new Set(e), a = n.current;
			r.forEach(function(e) {
				i.has(e) || ha(e, null);
			}), i.forEach(function(e) {
				r.has(e) || ha(e, a);
			});
		}
		va.set(n, e);
	}, [e]), n;
}
//#endregion
//#region node_modules/use-sidecar/dist/es2015/medium.js
function ba(e) {
	return e;
}
function xa(e, t) {
	t === void 0 && (t = ba);
	var n = [], r = !1;
	return {
		read: function() {
			if (r) throw Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
			return n.length ? n[n.length - 1] : e;
		},
		useMedium: function(e) {
			var i = t(e, r);
			return n.push(i), function() {
				n = n.filter(function(e) {
					return e !== i;
				});
			};
		},
		assignSyncMedium: function(e) {
			for (r = !0; n.length;) {
				var t = n;
				n = [], t.forEach(e);
			}
			n = {
				push: function(t) {
					return e(t);
				},
				filter: function() {
					return n;
				}
			};
		},
		assignMedium: function(e) {
			r = !0;
			var t = [];
			if (n.length) {
				var i = n;
				n = [], i.forEach(e), t = n;
			}
			var a = function() {
				var n = t;
				t = [], n.forEach(e);
			}, o = function() {
				return Promise.resolve().then(a);
			};
			o(), n = {
				push: function(e) {
					t.push(e), o();
				},
				filter: function(e) {
					return t = t.filter(e), n;
				}
			};
		}
	};
}
function Sa(e) {
	e === void 0 && (e = {});
	var t = xa(null);
	return t.options = ca({
		async: !0,
		ssr: !1
	}, e), t;
}
//#endregion
//#region node_modules/use-sidecar/dist/es2015/exports.js
var Ca = function(e) {
	var n = e.sideCar, r = la(e, ["sideCar"]);
	if (!n) throw Error("Sidecar: please provide `sideCar` property to import the right car");
	var i = n.read();
	if (!i) throw Error("Sidecar medium not found");
	return t.createElement(i, ca({}, r));
};
Ca.isSideCarExport = !0;
function wa(e, t) {
	return e.useMedium(t), Ca;
}
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/medium.js
var Ta = Sa(), Ea = function() {}, Da = t.forwardRef(function(e, n) {
	var r = t.useRef(null), i = t.useState({
		onScrollCapture: Ea,
		onWheelCapture: Ea,
		onTouchMoveCapture: Ea
	}), a = i[0], o = i[1], s = e.forwardProps, c = e.children, l = e.className, u = e.removeScrollBar, d = e.enabled, f = e.shards, p = e.sideCar, m = e.noRelative, h = e.noIsolation, g = e.inert, _ = e.allowPinchZoom, v = e.as, y = v === void 0 ? "div" : v, b = e.gapMode, x = la(e, [
		"forwardProps",
		"children",
		"className",
		"removeScrollBar",
		"enabled",
		"shards",
		"sideCar",
		"noRelative",
		"noIsolation",
		"inert",
		"allowPinchZoom",
		"as",
		"gapMode"
	]), S = p, C = ya([r, n]), w = ca(ca({}, x), a);
	return t.createElement(t.Fragment, null, d && t.createElement(S, {
		sideCar: Ta,
		removeScrollBar: u,
		shards: f,
		noRelative: m,
		noIsolation: h,
		inert: g,
		setCallbacks: o,
		allowPinchZoom: !!_,
		lockRef: r,
		gapMode: b
	}), s ? t.cloneElement(t.Children.only(c), ca(ca({}, w), { ref: C })) : t.createElement(y, ca({}, w, {
		className: l,
		ref: C
	}), c));
});
Da.defaultProps = {
	enabled: !0,
	removeScrollBar: !0,
	inert: !1
}, Da.classNames = {
	fullWidth: fa,
	zeroRight: da
};
//#endregion
//#region node_modules/get-nonce/dist/es2015/index.js
var Oa = function() {
	if (typeof __webpack_nonce__ < "u") return __webpack_nonce__;
};
//#endregion
//#region node_modules/react-style-singleton/dist/es2015/singleton.js
function ka() {
	if (!document) return null;
	var e = document.createElement("style");
	e.type = "text/css";
	var t = Oa();
	return t && e.setAttribute("nonce", t), e;
}
function Aa(e, t) {
	e.styleSheet ? e.styleSheet.cssText = t : e.appendChild(document.createTextNode(t));
}
function ja(e) {
	(document.head || document.getElementsByTagName("head")[0]).appendChild(e);
}
var Ma = function() {
	var e = 0, t = null;
	return {
		add: function(n) {
			e == 0 && (t = ka()) && (Aa(t, n), ja(t)), e++;
		},
		remove: function() {
			e--, !e && t && (t.parentNode && t.parentNode.removeChild(t), t = null);
		}
	};
}, Na = function() {
	var e = Ma();
	return function(n, r) {
		t.useEffect(function() {
			return e.add(n), function() {
				e.remove();
			};
		}, [n && r]);
	};
}, Pa = function() {
	var e = Na();
	return function(t) {
		var n = t.styles, r = t.dynamic;
		return e(n, r), null;
	};
}, Fa = {
	left: 0,
	top: 0,
	right: 0,
	gap: 0
}, Ia = function(e) {
	return parseInt(e || "", 10) || 0;
}, La = function(e) {
	var t = window.getComputedStyle(document.body), n = t[e === "padding" ? "paddingLeft" : "marginLeft"], r = t[e === "padding" ? "paddingTop" : "marginTop"], i = t[e === "padding" ? "paddingRight" : "marginRight"];
	return [
		Ia(n),
		Ia(r),
		Ia(i)
	];
}, Ra = function(e) {
	if (e === void 0 && (e = "margin"), typeof window > "u") return Fa;
	var t = La(e), n = document.documentElement.clientWidth, r = window.innerWidth;
	return {
		left: t[0],
		top: t[1],
		right: t[2],
		gap: Math.max(0, r - n + t[2] - t[0])
	};
}, za = Pa(), Ba = "data-scroll-locked", Va = function(e, t, n, r) {
	var i = e.left, a = e.top, o = e.right, s = e.gap;
	return n === void 0 && (n = "margin"), `
  .${pa} {
   overflow: hidden ${r};
   padding-right: ${s}px ${r};
  }
  body[${Ba}] {
    overflow: hidden ${r};
    overscroll-behavior: contain;
    ${[
		t && `position: relative ${r};`,
		n === "margin" && `
    padding-left: ${i}px;
    padding-top: ${a}px;
    padding-right: ${o}px;
    margin-left:0;
    margin-top:0;
    margin-right: ${s}px ${r};
    `,
		n === "padding" && `padding-right: ${s}px ${r};`
	].filter(Boolean).join("")}
  }
  
  .${da} {
    right: ${s}px ${r};
  }
  
  .${fa} {
    margin-right: ${s}px ${r};
  }
  
  .${da} .${da} {
    right: 0 ${r};
  }
  
  .${fa} .${fa} {
    margin-right: 0 ${r};
  }
  
  body[${Ba}] {
    ${ma}: ${s}px;
  }
`;
}, Ha = function() {
	var e = parseInt(document.body.getAttribute("data-scroll-locked") || "0", 10);
	return isFinite(e) ? e : 0;
}, Ua = function() {
	t.useEffect(function() {
		return document.body.setAttribute(Ba, (Ha() + 1).toString()), function() {
			var e = Ha() - 1;
			e <= 0 ? document.body.removeAttribute(Ba) : document.body.setAttribute(Ba, e.toString());
		};
	}, []);
}, Wa = function(e) {
	var n = e.noRelative, r = e.noImportant, i = e.gapMode, a = i === void 0 ? "margin" : i;
	Ua();
	var o = t.useMemo(function() {
		return Ra(a);
	}, [a]);
	return t.createElement(za, { styles: Va(o, !n, a, r ? "" : "!important") });
}, Ga = !1;
if (typeof window < "u") try {
	var Ka = Object.defineProperty({}, "passive", { get: function() {
		return Ga = !0, !0;
	} });
	window.addEventListener("test", Ka, Ka), window.removeEventListener("test", Ka, Ka);
} catch {
	Ga = !1;
}
var qa = Ga ? { passive: !1 } : !1, Ja = function(e) {
	return e.tagName === "TEXTAREA";
}, Ya = function(e, t) {
	if (!(e instanceof Element)) return !1;
	var n = window.getComputedStyle(e);
	return n[t] !== "hidden" && !(n.overflowY === n.overflowX && !Ja(e) && n[t] === "visible");
}, Xa = function(e) {
	return Ya(e, "overflowY");
}, Za = function(e) {
	return Ya(e, "overflowX");
}, Qa = function(e, t) {
	var n = t.ownerDocument, r = t;
	do {
		if (typeof ShadowRoot < "u" && r instanceof ShadowRoot && (r = r.host), to(e, r)) {
			var i = no(e, r);
			if (i[1] > i[2]) return !0;
		}
		r = r.parentNode;
	} while (r && r !== n.body);
	return !1;
}, $a = function(e) {
	return [
		e.scrollTop,
		e.scrollHeight,
		e.clientHeight
	];
}, eo = function(e) {
	return [
		e.scrollLeft,
		e.scrollWidth,
		e.clientWidth
	];
}, to = function(e, t) {
	return e === "v" ? Xa(t) : Za(t);
}, no = function(e, t) {
	return e === "v" ? $a(t) : eo(t);
}, ro = function(e, t) {
	return e === "h" && t === "rtl" ? -1 : 1;
}, io = function(e, t, n, r, i) {
	var a = ro(e, window.getComputedStyle(t).direction), o = a * r, s = n.target, c = t.contains(s), l = !1, u = o > 0, d = 0, f = 0;
	do {
		if (!s) break;
		var p = no(e, s), m = p[0], h = p[1] - p[2] - a * m;
		(m || h) && to(e, s) && (d += h, f += m);
		var g = s.parentNode;
		s = g && g.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? g.host : g;
	} while (!c && s !== document.body || c && (t.contains(s) || t === s));
	return (u && (i && Math.abs(d) < 1 || !i && o > d) || !u && (i && Math.abs(f) < 1 || !i && -o > f)) && (l = !0), l;
}, ao = function(e) {
	return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0];
}, oo = function(e) {
	return [e.deltaX, e.deltaY];
}, so = function(e) {
	return e && "current" in e ? e.current : e;
}, co = function(e, t) {
	return e[0] === t[0] && e[1] === t[1];
}, lo = function(e) {
	return `
  .block-interactivity-${e} {pointer-events: none;}
  .allow-interactivity-${e} {pointer-events: all;}
`;
}, uo = 0, fo = [];
function po(e) {
	var n = t.useRef([]), r = t.useRef([0, 0]), i = t.useRef(), a = t.useState(uo++)[0], o = t.useState(Pa)[0], s = t.useRef(e);
	t.useEffect(function() {
		s.current = e;
	}, [e]), t.useEffect(function() {
		if (e.inert) {
			document.body.classList.add(`block-interactivity-${a}`);
			var t = ua([e.lockRef.current], (e.shards || []).map(so), !0).filter(Boolean);
			return t.forEach(function(e) {
				return e.classList.add(`allow-interactivity-${a}`);
			}), function() {
				document.body.classList.remove(`block-interactivity-${a}`), t.forEach(function(e) {
					return e.classList.remove(`allow-interactivity-${a}`);
				});
			};
		}
	}, [
		e.inert,
		e.lockRef.current,
		e.shards
	]);
	var c = t.useCallback(function(e, t) {
		if ("touches" in e && e.touches.length === 2 || e.type === "wheel" && e.ctrlKey) return !s.current.allowPinchZoom;
		var n = ao(e), a = r.current, o = "deltaX" in e ? e.deltaX : a[0] - n[0], c = "deltaY" in e ? e.deltaY : a[1] - n[1], l, u = e.target, d = Math.abs(o) > Math.abs(c) ? "h" : "v";
		if ("touches" in e && d === "h" && u.type === "range") return !1;
		var f = window.getSelection(), p = f && f.anchorNode;
		if (p && (p === u || p.contains(u))) return !1;
		var m = Qa(d, u);
		if (!m) return !0;
		if (m ? l = d : (l = d === "v" ? "h" : "v", m = Qa(d, u)), !m) return !1;
		if (!i.current && "changedTouches" in e && (o || c) && (i.current = l), !l) return !0;
		var h = i.current || l;
		return io(h, t, e, h === "h" ? o : c, !0);
	}, []), l = t.useCallback(function(e) {
		var t = e;
		if (!(!fo.length || fo[fo.length - 1] !== o)) {
			var r = "deltaY" in t ? oo(t) : ao(t), i = n.current.filter(function(e) {
				return e.name === t.type && (e.target === t.target || t.target === e.shadowParent) && co(e.delta, r);
			})[0];
			if (i && i.should) {
				t.cancelable && t.preventDefault();
				return;
			}
			if (!i) {
				var a = (s.current.shards || []).map(so).filter(Boolean).filter(function(e) {
					return e.contains(t.target);
				});
				(a.length > 0 ? c(t, a[0]) : !s.current.noIsolation) && t.cancelable && t.preventDefault();
			}
		}
	}, []), u = t.useCallback(function(e, t, r, i) {
		var a = {
			name: e,
			delta: t,
			target: r,
			should: i,
			shadowParent: mo(r)
		};
		n.current.push(a), setTimeout(function() {
			n.current = n.current.filter(function(e) {
				return e !== a;
			});
		}, 1);
	}, []), d = t.useCallback(function(e) {
		r.current = ao(e), i.current = void 0;
	}, []), f = t.useCallback(function(t) {
		u(t.type, oo(t), t.target, c(t, e.lockRef.current));
	}, []), p = t.useCallback(function(t) {
		u(t.type, ao(t), t.target, c(t, e.lockRef.current));
	}, []);
	t.useEffect(function() {
		return fo.push(o), e.setCallbacks({
			onScrollCapture: f,
			onWheelCapture: f,
			onTouchMoveCapture: p
		}), document.addEventListener("wheel", l, qa), document.addEventListener("touchmove", l, qa), document.addEventListener("touchstart", d, qa), function() {
			fo = fo.filter(function(e) {
				return e !== o;
			}), document.removeEventListener("wheel", l, qa), document.removeEventListener("touchmove", l, qa), document.removeEventListener("touchstart", d, qa);
		};
	}, []);
	var m = e.removeScrollBar, h = e.inert;
	return t.createElement(t.Fragment, null, h ? t.createElement(o, { styles: lo(a) }) : null, m ? t.createElement(Wa, {
		noRelative: e.noRelative,
		gapMode: e.gapMode
	}) : null);
}
function mo(e) {
	for (var t = null; e !== null;) e instanceof ShadowRoot && (t = e.host, e = e.host), e = e.parentNode;
	return t;
}
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/sidecar.js
var ho = wa(Ta, po), go = t.forwardRef(function(e, n) {
	return t.createElement(Da, ca({}, e, {
		ref: n,
		sideCar: ho
	}));
});
go.classNames = Da.classNames;
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/ModalBase.mjs
function _o({ keepMounted: e, keepMountedMode: t = "activity", opened: n, onClose: r, id: i, transitionProps: a, onExitTransitionEnd: o, onEnterTransitionEnd: s, trapFocus: c, closeOnEscape: l, returnFocus: u, closeOnClickOutside: d, withinPortal: f, portalProps: p, lockScroll: m, children: h, zIndex: g, shadow: _, padding: v, __vars: y, unstyled: b, removeScrollProps: x, ...S }) {
	let { _id: C, titleMounted: w, bodyMounted: E, shouldLockScroll: D, setTitleMounted: O, setBodyMounted: k } = sa({
		id: i,
		transitionProps: a,
		opened: n,
		trapFocus: c,
		closeOnEscape: l,
		onClose: r,
		returnFocus: u
	}), { key: ee, ...A } = x || {};
	return /* @__PURE__ */ T(wi, {
		...p,
		withinPortal: f,
		children: /* @__PURE__ */ T(ia, {
			value: {
				opened: n,
				onClose: r,
				closeOnClickOutside: d,
				onExitTransitionEnd: o,
				onEnterTransitionEnd: s,
				transitionProps: {
					...a,
					keepMounted: e,
					keepMountedMode: t
				},
				getTitleId: () => `${C}-title`,
				getBodyId: () => `${C}-body`,
				titleMounted: w,
				bodyMounted: E,
				setTitleMounted: O,
				setBodyMounted: k,
				trapFocus: c,
				closeOnEscape: l,
				zIndex: g,
				unstyled: b
			},
			children: /* @__PURE__ */ T(go, {
				enabled: D && m,
				...A,
				children: /* @__PURE__ */ T(Y, {
					...S,
					id: C,
					__vars: {
						...y,
						"--mb-z-index": (g || ce("modal")).toString(),
						"--mb-shadow": U(_),
						"--mb-padding": V(v)
					},
					children: h
				})
			}, ee)
		})
	});
}
_o.displayName = "@mantine/core/ModalBase";
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/use-modal-body-id.mjs
function vo() {
	let e = aa();
	return p(() => (e.setBodyMounted(!0), () => e.setBodyMounted(!1)), []), e.getBodyId();
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/ModalBase.module.mjs
var yo = {
	title: "m_615af6c9",
	header: "m_b5489c3c",
	inner: "m_60c222c7",
	content: "m_fd1ab0aa",
	close: "m_606cb269",
	body: "m_5df29311"
};
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/ModalBaseBody.mjs
function bo({ className: e, ...t }) {
	let n = vo(), r = aa();
	return /* @__PURE__ */ T(Y, {
		id: n,
		className: Xe({ [yo.body]: !r.unstyled }, e),
		...t
	});
}
bo.displayName = "@mantine/core/ModalBaseBody";
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/ModalBaseCloseButton.mjs
function xo({ className: e, onClick: t, ...n }) {
	let r = aa();
	return /* @__PURE__ */ T($i, {
		...n,
		onClick: (e) => {
			r.onClose(), t?.(e);
		},
		className: Xe({ [yo.close]: !r.unstyled }, e),
		unstyled: r.unstyled
	});
}
xo.displayName = "@mantine/core/ModalBaseCloseButton";
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/ModalBaseContent.mjs
function So({ transitionProps: e, className: t, innerProps: n, onKeyDown: r, style: i, ref: a, ...o }) {
	let s = aa();
	return /* @__PURE__ */ T(Ai, {
		mounted: s.opened,
		transition: "pop",
		...s.transitionProps,
		onExited: () => {
			s.onExitTransitionEnd?.(), s.transitionProps?.onExited?.();
		},
		onEntered: () => {
			s.onEnterTransitionEnd?.(), s.transitionProps?.onEntered?.();
		},
		...e,
		children: (e) => /* @__PURE__ */ T("div", {
			...n,
			className: Xe({ [yo.inner]: !s.unstyled }, n.className),
			children: /* @__PURE__ */ T(ji, {
				active: s.opened && s.trapFocus,
				innerRef: a,
				children: /* @__PURE__ */ T(hi, {
					...o,
					component: "section",
					role: "dialog",
					tabIndex: -1,
					"aria-modal": !0,
					"aria-describedby": s.bodyMounted ? s.getBodyId() : void 0,
					"aria-labelledby": s.titleMounted ? s.getTitleId() : void 0,
					style: [i, e],
					className: Xe({ [yo.content]: !s.unstyled }, t),
					unstyled: s.unstyled,
					children: o.children
				})
			})
		})
	});
}
So.displayName = "@mantine/core/ModalBaseContent";
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/ModalBaseHeader.mjs
function Co({ className: e, ...t }) {
	let n = aa();
	return /* @__PURE__ */ T(Y, {
		component: "header",
		className: Xe({ [yo.header]: !n.unstyled }, e),
		...t
	});
}
Co.displayName = "@mantine/core/ModalBaseHeader";
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/use-modal-transition.mjs
var wo = {
	duration: 200,
	timingFunction: "ease",
	transition: "fade"
};
function To(e) {
	let t = aa();
	return {
		...wo,
		...t.transitionProps,
		...e
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/ModalBaseOverlay.mjs
function Eo({ onClick: e, transitionProps: t, style: n, visible: r, ...i }) {
	let a = aa(), o = To(t);
	return /* @__PURE__ */ T(Ai, {
		mounted: r === void 0 ? a.opened : r,
		...o,
		transition: "fade",
		children: (t) => /* @__PURE__ */ T(yi, {
			fixed: !0,
			style: [n, t],
			zIndex: a.zIndex,
			unstyled: a.unstyled,
			onClick: (t) => {
				e?.(t), a.closeOnClickOutside && a.onClose();
			},
			...i
		})
	});
}
Eo.displayName = "@mantine/core/ModalBaseOverlay";
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/use-modal-title-id.mjs
function Do() {
	let e = aa();
	return p(() => (e.setTitleMounted(!0), () => e.setTitleMounted(!1)), []), e.getTitleId();
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/ModalBaseTitle.mjs
function Oo({ className: e, ...t }) {
	let n = Do(), r = aa();
	return /* @__PURE__ */ T(Y, {
		component: "h2",
		className: Xe({ [yo.title]: !r.unstyled }, e),
		id: n,
		...t
	});
}
Oo.displayName = "@mantine/core/ModalBaseTitle";
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/NativeScrollArea.mjs
function ko({ children: e }) {
	return /* @__PURE__ */ T(w, { children: e });
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Input/Input.context.mjs
var Ao = s({ size: "sm" }), jo = J((e) => {
	let t = K("InputClearButton", null, e), { size: n, variant: r, vars: i, classNames: a, styles: o, ...s } = t, c = u(Ao), { resolvedClassNames: l, resolvedStyles: d } = mn({
		classNames: a,
		styles: o,
		props: t
	});
	return /* @__PURE__ */ T($i, {
		variant: r || "transparent",
		size: n || c?.size || "sm",
		classNames: l,
		styles: d,
		__staticSelector: "InputClearButton",
		style: {
			pointerEvents: "all",
			background: "var(--input-bg)",
			...s.style
		},
		...s
	});
});
jo.displayName = "@mantine/core/InputClearButton";
//#endregion
//#region node_modules/@mantine/core/esm/components/Input/InputClearSection/InputClearSection.mjs
var Mo = {
	xs: 7,
	sm: 8,
	md: 10,
	lg: 12,
	xl: 15
};
function No({ __clearable: e, __clearSection: t, rightSection: n, __defaultRightSection: r, size: i = "sm", __clearSectionMode: a = "both" }) {
	let o = e && t;
	return a === "rightSection" ? n === null ? null : n || r : a === "clear" ? n === null ? null : o || r : o && (n || r) ? /* @__PURE__ */ E("div", {
		"data-combined-clear-section": !0,
		style: {
			display: "flex",
			gap: 2,
			alignItems: "center",
			paddingInlineEnd: Mo[i]
		},
		children: [o, n || r]
	}) : n === null ? null : n || o || r;
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Input/InputWrapper.context.mjs
var Po = s({
	offsetBottom: !1,
	offsetTop: !1,
	describedBy: void 0,
	getStyles: null,
	inputId: void 0,
	labelId: void 0
}), Fo = {
	wrapper: "m_6c018570",
	input: "m_8fb7ebe7",
	bottomSection: "m_93f4ed57",
	section: "m_82577fc2",
	placeholder: "m_88bacfd0",
	root: "m_46b77525",
	label: "m_8fdc1311",
	required: "m_78a94662",
	error: "m_8f816625",
	success: "m_9d9d40e0",
	description: "m_fe47ce59"
}, Io = G((e, { size: t }) => ({ description: { "--input-description-size": t === void 0 ? void 0 : `calc(${H(t)} - ${P(2)})` } })), Lo = J((e) => {
	let t = K("InputDescription", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, __staticSelector: c, __inheritStyles: l = !0, attributes: d, ...f } = K("InputDescription", null, t), p = u(Po), m = q({
		name: ["InputWrapper", c],
		props: t,
		classes: Fo,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: d,
		rootSelector: "description",
		vars: s,
		varsResolver: Io
	}), h = l && p?.getStyles || m;
	return /* @__PURE__ */ T(Y, {
		component: "p",
		...h("description", p?.getStyles ? {
			className: r,
			style: i
		} : void 0),
		...f
	});
});
Lo.classes = Fo, Lo.varsResolver = Io, Lo.displayName = "@mantine/core/InputDescription";
//#endregion
//#region node_modules/@mantine/core/esm/components/Input/InputError/InputError.mjs
var Ro = G((e, { size: t }) => ({ error: { "--input-error-size": t === void 0 ? void 0 : `calc(${H(t)} - ${P(2)})` } })), zo = J((e) => {
	let t = K("InputError", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, attributes: c, __staticSelector: l, __inheritStyles: d = !0, ...f } = t, p = q({
		name: ["InputWrapper", l],
		props: t,
		classes: Fo,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: c,
		rootSelector: "error",
		vars: s,
		varsResolver: Ro
	}), m = u(Po), h = d && m?.getStyles || p;
	return /* @__PURE__ */ T(Y, {
		component: "p",
		...h("error", m?.getStyles ? {
			className: r,
			style: i
		} : void 0),
		...f
	});
});
zo.classes = Fo, zo.varsResolver = Ro, zo.displayName = "@mantine/core/InputError";
//#endregion
//#region node_modules/@mantine/core/esm/components/Input/InputLabel/InputLabel.mjs
var Bo = { labelElement: "label" }, Vo = G((e, { size: t }) => ({ label: {
	"--input-label-size": H(t),
	"--input-asterisk-color": void 0
} })), Ho = J((e) => {
	let t = K("InputLabel", Bo, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, labelElement: c, required: l, htmlFor: d, onMouseDown: f, children: p, __staticSelector: m, mod: h, attributes: g, ..._ } = t, v = q({
		name: ["InputWrapper", m],
		props: t,
		classes: Fo,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: g,
		rootSelector: "label",
		vars: s,
		varsResolver: Vo
	}), y = u(Po), b = y?.getStyles || v, x = _.component || c, S = typeof x != "string" || x === "label";
	return /* @__PURE__ */ E(Y, {
		...b("label", y?.getStyles ? {
			className: r,
			style: i
		} : void 0),
		component: c,
		htmlFor: S ? d : void 0,
		mod: [{ required: l }, h],
		onMouseDown: (e) => {
			f?.(e), !e.defaultPrevented && e.detail > 1 && e.preventDefault();
		},
		..._,
		children: [p, l && /* @__PURE__ */ T("span", {
			...b("required"),
			"aria-hidden": !0,
			children: " *"
		})]
	});
});
Ho.classes = Fo, Ho.varsResolver = Vo, Ho.displayName = "@mantine/core/InputLabel";
//#endregion
//#region node_modules/@mantine/core/esm/components/Input/InputPlaceholder/InputPlaceholder.mjs
var Uo = J((e) => {
	let t = K("InputPlaceholder", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, __staticSelector: c, error: l, mod: u, attributes: d, ...f } = t, p = q({
		name: ["InputPlaceholder", c],
		props: t,
		classes: Fo,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: d,
		rootSelector: "placeholder"
	});
	return /* @__PURE__ */ T(Y, {
		...p("placeholder"),
		mod: [{ error: !!l }, u],
		component: "span",
		...f
	});
});
Uo.classes = Fo, Uo.displayName = "@mantine/core/InputPlaceholder";
//#endregion
//#region node_modules/@mantine/core/esm/components/Input/InputSuccess/InputSuccess.mjs
var Wo = G((e, { size: t }) => ({ success: { "--input-success-size": t === void 0 ? void 0 : `calc(${H(t)} - ${P(2)})` } })), Go = J((e) => {
	let t = K("InputSuccess", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, attributes: c, __staticSelector: l, __inheritStyles: d = !0, ...f } = t, p = q({
		name: ["InputWrapper", l],
		props: t,
		classes: Fo,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: c,
		rootSelector: "success",
		vars: s,
		varsResolver: Wo
	}), m = u(Po), h = d && m?.getStyles || p;
	return /* @__PURE__ */ T(Y, {
		component: "p",
		...h("success", m?.getStyles ? {
			className: r,
			style: i
		} : void 0),
		...f
	});
});
Go.classes = Fo, Go.varsResolver = Wo, Go.displayName = "@mantine/core/InputSuccess";
//#endregion
//#region node_modules/@mantine/core/esm/components/Input/InputWrapper/get-input-offsets/get-input-offsets.mjs
function Ko(e, { hasDescription: t, hasError: n }) {
	let r = e.findIndex((e) => e === "input"), i = e.slice(0, r), a = e.slice(r + 1), o = t && i.includes("description") || n && i.includes("error");
	return {
		offsetBottom: t && a.includes("description") || n && a.includes("error"),
		offsetTop: o
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Input/InputWrapper/InputWrapper.mjs
var qo = {
	labelElement: "label",
	inputContainer: (e) => e,
	inputWrapperOrder: [
		"label",
		"description",
		"input",
		"error"
	]
}, Jo = G((e, { size: t }) => ({
	label: {
		"--input-label-size": H(t),
		"--input-asterisk-color": void 0
	},
	error: { "--input-error-size": t === void 0 ? void 0 : `calc(${H(t)} - ${P(2)})` },
	success: { "--input-success-size": t === void 0 ? void 0 : `calc(${H(t)} - ${P(2)})` },
	description: { "--input-description-size": t === void 0 ? void 0 : `calc(${H(t)} - ${P(2)})` }
})), Yo = J((e) => {
	let t = K("InputWrapper", qo, e), { classNames: n, className: r, style: i, styles: o, unstyled: s, vars: l, size: u, variant: d, __staticSelector: f, inputContainer: p, inputWrapperOrder: m, label: h, error: g, success: _, description: v, labelProps: y, descriptionProps: b, errorProps: x, successProps: S, labelElement: C, children: w, withAsterisk: E, id: D, required: O, __stylesApiProps: k, mod: ee, attributes: A, ...j } = t, M = q({
		name: ["InputWrapper", f],
		props: k || t,
		classes: Fo,
		className: r,
		style: i,
		classNames: n,
		styles: o,
		unstyled: s,
		attributes: A,
		vars: l,
		varsResolver: Jo
	}), N = {
		size: u,
		variant: d,
		__staticSelector: f
	}, P = Pe(D), te = typeof E == "boolean" ? E : O, ne = x?.id || `${P}-error`, F = S?.id || `${P}-success`, I = b?.id || `${P}-description`, re = P, L = !!g && typeof g != "boolean", R = !!_ && typeof _ != "boolean" && !g, z = !!v, ie = L && m.includes("error"), ae = R && m.includes("error"), oe = z && m.includes("description"), se = `${ie ? ne : ""} ${ae ? F : ""} ${oe ? I : ""}`, ce = se.trim().length > 0 ? se.trim() : void 0, le = y?.id || `${P}-label`, B = h && /* @__PURE__ */ T(Ho, {
		labelElement: C,
		id: le,
		htmlFor: re,
		required: te,
		...N,
		...y,
		children: h
	}, "label"), V = z && /* @__PURE__ */ T(Lo, {
		...b,
		...N,
		size: b?.size || N.size,
		id: b?.id || I,
		children: v
	}, "description"), ue = /* @__PURE__ */ T(a, { children: p(w) }, "input"), H = L && /* @__PURE__ */ c(zo, {
		...x,
		...N,
		size: x?.size || N.size,
		key: "error",
		id: x?.id || ne
	}, g), de = R && /* @__PURE__ */ c(Go, {
		...S,
		...N,
		size: S?.size || N.size,
		key: "success",
		id: S?.id || F
	}, _), U = m.map((e) => {
		switch (e) {
			case "label": return B;
			case "input": return ue;
			case "description": return V;
			case "error": return H || de;
			default: return null;
		}
	});
	return /* @__PURE__ */ T(Po, {
		value: {
			getStyles: M,
			describedBy: ce,
			inputId: re,
			labelId: le,
			...Ko(m, {
				hasDescription: z,
				hasError: L || R
			})
		},
		children: /* @__PURE__ */ T(Y, {
			variant: d,
			size: u,
			mod: [{
				error: !!g,
				success: !!_ && !g
			}, ee],
			id: C === "label" ? void 0 : D,
			...M("root"),
			...j,
			children: U
		})
	});
});
Yo.classes = Fo, Yo.varsResolver = Jo, Yo.displayName = "@mantine/core/InputWrapper";
//#endregion
//#region node_modules/@mantine/core/esm/components/Input/Input.mjs
var Xo = {
	variant: "default",
	leftSectionPointerEvents: "none",
	rightSectionPointerEvents: "none",
	withAria: !0,
	withErrorStyles: !0,
	withSuccessStyles: !0,
	size: "sm",
	loading: !1,
	loadingPosition: "right"
}, Zo = G((e, t, n) => ({ wrapper: {
	"--input-margin-top": n.offsetTop ? "calc(var(--mantine-spacing-xs) / 2)" : void 0,
	"--input-margin-bottom": n.offsetBottom ? "calc(var(--mantine-spacing-xs) / 2)" : void 0,
	"--input-height": B(t.size, "input-height"),
	"--input-fz": H(t.size),
	"--input-radius": t.radius === void 0 ? void 0 : ue(t.radius),
	"--input-left-section-width": t.leftSectionWidth === void 0 ? void 0 : P(t.leftSectionWidth),
	"--input-right-section-width": t.rightSectionWidth === void 0 ? void 0 : P(t.rightSectionWidth),
	"--input-padding-y": t.multiline ? B(t.size, "input-padding-y") : void 0,
	"--input-left-section-pointer-events": t.leftSectionPointerEvents,
	"--input-right-section-pointer-events": t.rightSectionPointerEvents
} })), Qo = lr((e) => {
	let t = K("Input", Xo, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, required: s, __staticSelector: c, __stylesApiProps: l, size: d, wrapperProps: f, error: p, success: m, disabled: h, leftSection: g, leftSectionProps: _, leftSectionWidth: v, rightSection: y, rightSectionProps: b, rightSectionWidth: x, rightSectionPointerEvents: S, leftSectionPointerEvents: C, variant: w, vars: D, pointer: O, multiline: k, radius: ee, id: A, withAria: j, withErrorStyles: M, withSuccessStyles: N, mod: P, inputSize: te, attributes: ne, __clearSection: F, __clearable: I, __clearSectionMode: re, __defaultRightSection: L, loading: R, loadingPosition: z, __bottomSection: ie, __bottomSectionProps: ae, rootRef: oe, dir: se, ...ce } = t, { styleProps: le, rest: B } = Pn(ce), V = u(Po), ue = {
		offsetBottom: V?.offsetBottom,
		offsetTop: V?.offsetTop
	}, H = q({
		name: ["Input", c],
		props: l || t,
		classes: Fo,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: ne,
		stylesCtx: ue,
		rootSelector: "wrapper",
		vars: D,
		varsResolver: Zo
	}), de = j ? {
		required: s,
		disabled: h,
		"aria-invalid": p ? !0 : void 0,
		"aria-describedby": V?.describedBy,
		id: V?.inputId || A
	} : {}, U = R ? /* @__PURE__ */ T(Bi, { size: z === "left" ? "calc(var(--input-left-section-size) / 2)" : "calc(var(--input-right-section-size) / 2)" }) : null, fe = R && z === "left" ? U : g, pe = No({
		__clearable: I,
		__clearSection: F,
		rightSection: R && z === "right" ? U : y,
		__defaultRightSection: L,
		size: d,
		__clearSectionMode: re
	});
	return /* @__PURE__ */ T(Ao, {
		value: { size: d || "sm" },
		children: /* @__PURE__ */ E(Y, {
			ref: oe,
			dir: se,
			...H("wrapper"),
			...le,
			...f,
			mod: [{
				error: !!p && M,
				success: !!m && !p && N,
				pointer: O,
				disabled: h,
				multiline: k,
				withRightSection: !!pe,
				withLeftSection: !!fe,
				withBottomSection: !!ie
			}, P],
			variant: w,
			size: d,
			children: [
				fe && /* @__PURE__ */ T("div", {
					..._,
					"data-position": "left",
					...H("section", {
						className: _?.className,
						style: _?.style
					}),
					children: fe
				}),
				/* @__PURE__ */ T(Y, {
					component: "input",
					...B,
					...de,
					required: s,
					mod: {
						disabled: h,
						error: !!p && M,
						success: !!m && !p && N
					},
					variant: w,
					__size: te,
					...H("input")
				}),
				ie && /* @__PURE__ */ T("div", {
					...ae,
					...H("bottomSection", {
						className: ae?.className,
						style: ae?.style
					}),
					children: ie
				}),
				pe && /* @__PURE__ */ T("div", {
					...b,
					"data-position": "right",
					...H("section", {
						className: b?.className,
						style: b?.style
					}),
					children: pe
				})
			]
		})
	});
});
Qo.classes = Fo, Qo.varsResolver = Zo, Qo.Wrapper = Yo, Qo.Label = Ho, Qo.Error = zo, Qo.Success = Go, Qo.Description = Lo, Qo.Placeholder = Uo, Qo.ClearButton = jo, Qo.displayName = "@mantine/core/Input";
//#endregion
//#region node_modules/@mantine/core/esm/components/Input/use-input-props.mjs
function $o(e, t, n) {
	let r = K([
		"Input",
		"InputWrapper",
		e
	], t, n), { label: i, description: a, error: o, success: s, required: c, classNames: l, styles: u, className: d, unstyled: f, __staticSelector: p, __stylesApiProps: m, errorProps: h, successProps: g, labelProps: _, descriptionProps: v, wrapperProps: y, id: b, size: x, style: S, inputContainer: C, inputWrapperOrder: w, withAsterisk: T, variant: E, vars: D, mod: O, attributes: k, ...ee } = r, { styleProps: A, rest: j } = Pn(ee), M = {
		label: i,
		description: a,
		error: o,
		success: s,
		required: c,
		classNames: l,
		className: d,
		__staticSelector: p,
		__stylesApiProps: m || r,
		errorProps: h,
		successProps: g,
		labelProps: _,
		descriptionProps: v,
		unstyled: f,
		styles: u,
		size: x,
		style: S,
		inputContainer: C,
		inputWrapperOrder: w,
		withAsterisk: T,
		variant: E,
		id: b,
		mod: O,
		attributes: k,
		...y
	};
	return {
		...j,
		classNames: l,
		styles: u,
		unstyled: f,
		wrapperProps: {
			...M,
			...A
		},
		inputProps: {
			required: c,
			classNames: l,
			styles: u,
			unstyled: f,
			size: x,
			__staticSelector: p,
			__stylesApiProps: m || r,
			error: o,
			success: s,
			variant: E,
			id: b,
			attributes: k
		}
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/components/InputBase/InputBase.mjs
var es = {
	__staticSelector: "InputBase",
	withAria: !0,
	size: "sm"
}, ts = lr((e) => {
	let { inputProps: t, wrapperProps: n, ...r } = $o("InputBase", es, e);
	return /* @__PURE__ */ T(Qo.Wrapper, {
		...n,
		children: /* @__PURE__ */ T(Qo, {
			...t,
			...r
		})
	});
});
ts.classes = {
	...Qo.classes,
	...Qo.Wrapper.classes
}, ts.displayName = "@mantine/core/InputBase";
//#endregion
//#region node_modules/@mantine/core/esm/components/Accordion/Accordion.context.mjs
var [ns, rs] = re("Accordion component was not found in the tree");
//#endregion
//#region node_modules/@mantine/core/esm/components/Accordion/AccordionChevron.mjs
function is({ style: e, size: t = 16, ...n }) {
	return /* @__PURE__ */ T("svg", {
		viewBox: "0 0 15 15",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		style: {
			...e,
			width: P(t),
			height: P(t),
			display: "block"
		},
		...n,
		children: /* @__PURE__ */ T("path", {
			d: "M3.13523 6.15803C3.3241 5.95657 3.64052 5.94637 3.84197 6.13523L7.5 9.56464L11.158 6.13523C11.3595 5.94637 11.6759 5.95657 11.8648 6.15803C12.0536 6.35949 12.0434 6.67591 11.842 6.86477L7.84197 10.6148C7.64964 10.7951 7.35036 10.7951 7.15803 10.6148L3.15803 6.86477C2.95657 6.67591 2.94637 6.35949 3.13523 6.15803Z",
			fill: "currentColor",
			fillRule: "evenodd",
			clipRule: "evenodd"
		})
	});
}
is.displayName = "@mantine/core/AccordionChevron";
//#endregion
//#region node_modules/@mantine/core/esm/components/Accordion/AccordionItem.context.mjs
var [as, os] = re("Accordion.Item component was not found in the tree"), ss = {
	root: "m_9bdbb667",
	panel: "m_df78851f",
	content: "m_4ba554d4",
	itemTitle: "m_8fa820a0",
	control: "m_4ba585b8",
	"control--default": "m_6939a5e9",
	"control--contained": "m_4271d21b",
	label: "m_df3ffa0f",
	chevron: "m_3f35ae96",
	icon: "m_9bd771fe",
	item: "m_9bd7b098",
	"item--default": "m_fe19b709",
	"item--contained": "m_1f921b3b",
	"item--filled": "m_2cdf939a",
	"item--separated": "m_9f59b069"
}, cs = J((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, chevron: o, icon: s, onClick: c, onKeyDown: l, children: u, disabled: d, mod: f, ...p } = K("AccordionControl", null, e), { value: m } = os(), h = rs(), g = h.isItemActive(m), _ = typeof h.order == "number", v = `h${h.order}`, y = /* @__PURE__ */ E(ui, {
		...h.getStyles("control", {
			className: n,
			classNames: t,
			style: r,
			styles: i,
			variant: h.variant
		}),
		unstyled: h.unstyled,
		mod: [
			"accordion-control",
			{
				active: g,
				"chevron-position": h.chevronPosition,
				disabled: d
			},
			f
		],
		onClick: (e) => {
			c?.(e), h.onChange(m);
		},
		type: "button",
		disabled: d,
		"aria-expanded": g,
		"aria-controls": h.getRegionId(m),
		id: h.getControlId(m),
		onKeyDown: oe({
			siblingSelector: "[data-accordion-control]",
			parentSelector: "[data-accordion]",
			activateOnFocus: !1,
			loop: h.loop,
			orientation: "vertical",
			onKeyDown: l
		}),
		...p,
		children: [
			/* @__PURE__ */ T(Y, {
				component: "span",
				mod: {
					rotate: !h.disableChevronRotation && g,
					position: h.chevronPosition
				},
				...h.getStyles("chevron", {
					classNames: t,
					styles: i
				}),
				children: o || h.chevron
			}),
			/* @__PURE__ */ T("span", {
				...h.getStyles("label", {
					classNames: t,
					styles: i
				}),
				children: u
			}),
			s && /* @__PURE__ */ T(Y, {
				component: "span",
				mod: { "chevron-position": h.chevronPosition },
				...h.getStyles("icon", {
					classNames: t,
					styles: i
				}),
				children: s
			})
		]
	});
	return _ ? /* @__PURE__ */ T(v, {
		...h.getStyles("itemTitle", {
			classNames: t,
			styles: i
		}),
		children: y
	}) : y;
});
cs.displayName = "@mantine/core/AccordionControl", cs.classes = ss;
//#endregion
//#region node_modules/@mantine/core/esm/components/Accordion/AccordionItem/AccordionItem.mjs
var ls = J((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, value: o, mod: s, ...c } = K("AccordionItem", null, e), l = rs();
	return /* @__PURE__ */ T(as, {
		value: { value: o },
		children: /* @__PURE__ */ T(Y, {
			mod: [{ active: l.isItemActive(o) }, s],
			...l.getStyles("item", {
				className: n,
				classNames: t,
				styles: i,
				style: r,
				variant: l.variant
			}),
			...c
		})
	});
});
ls.displayName = "@mantine/core/AccordionItem", ls.classes = ss;
//#endregion
//#region node_modules/@mantine/core/esm/components/Accordion/AccordionPanel/AccordionPanel.mjs
var us = J((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, children: o, keepMounted: s, keepMountedMode: c, ...l } = K("AccordionPanel", null, e), { value: u } = os(), d = rs();
	return /* @__PURE__ */ T(yr, {
		...d.getStyles("panel", {
			className: n,
			classNames: t,
			style: r,
			styles: i
		}),
		expanded: d.isItemActive(u),
		transitionDuration: d.transitionDuration ?? 200,
		role: "region",
		id: d.getRegionId(u),
		"aria-labelledby": d.getControlId(u),
		keepMounted: s ?? d.keepMounted,
		keepMountedMode: c ?? d.keepMountedMode,
		...l,
		children: /* @__PURE__ */ T("div", {
			...d.getStyles("content", {
				classNames: t,
				styles: i
			}),
			children: o
		})
	});
});
us.displayName = "@mantine/core/AccordionPanel", us.classes = ss;
//#endregion
//#region node_modules/@mantine/core/esm/components/Accordion/Accordion.mjs
var ds = {
	multiple: !1,
	loop: !0,
	disableChevronRotation: !1,
	disableCollapse: !1,
	chevronPosition: "right",
	variant: "default",
	chevronSize: "auto",
	chevronIconSize: 16,
	keepMountedMode: "activity"
}, fs = G((e, { transitionDuration: t, chevronSize: n, radius: r }) => ({ root: {
	"--accordion-transition-duration": t === void 0 ? void 0 : `${t}ms`,
	"--accordion-chevron-size": n === void 0 ? void 0 : P(n),
	"--accordion-radius": r === void 0 ? void 0 : ue(r)
} })), ps = cr((e) => {
	let t = K("Accordion", ds, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, children: c, multiple: l, value: u, defaultValue: d, onChange: f, id: p, loop: m, transitionDuration: h, disableChevronRotation: g, disableCollapse: _, chevronPosition: v, chevronSize: y, order: b, chevron: x, variant: S, radius: C, chevronIconSize: w, attributes: E, keepMounted: D, keepMountedMode: O, ...k } = t, ee = Pe(p), [A, j] = ze({
		value: u,
		defaultValue: d,
		finalValue: l ? [] : null,
		onChange: f
	}), M = (e) => Array.isArray(A) ? A.includes(e) : e === A, N = (e) => {
		if (!Array.isArray(A) && _ && e === A) return;
		let t = Array.isArray(A) ? A.includes(e) ? A.filter((t) => t !== e) : [...A, e] : e === A ? null : e;
		j(t);
	}, P = q({
		name: "Accordion",
		classes: ss,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: E,
		vars: s,
		varsResolver: fs
	});
	return /* @__PURE__ */ T(ns, {
		value: {
			isItemActive: M,
			onChange: N,
			getControlId: L(`${ee}-control`, "Accordion.Item component was rendered with invalid value or without value"),
			getRegionId: L(`${ee}-panel`, "Accordion.Item component was rendered with invalid value or without value"),
			chevron: x === null ? null : x || /* @__PURE__ */ T(is, { size: w }),
			transitionDuration: h,
			disableChevronRotation: g,
			chevronPosition: v,
			order: b,
			loop: m,
			getStyles: P,
			variant: S,
			unstyled: o,
			keepMounted: D,
			keepMountedMode: O
		},
		children: /* @__PURE__ */ T(Y, {
			...P("root"),
			id: ee,
			...k,
			variant: S,
			"data-accordion": !0,
			children: c
		})
	});
});
ps.classes = ss, ps.varsResolver = fs, ps.displayName = "@mantine/core/Accordion", ps.Item = ls, ps.Panel = us, ps.Control = cs, ps.Chevron = is;
//#endregion
//#region node_modules/@mantine/core/esm/components/Alert/Alert.module.mjs
var ms = {
	root: "m_66836ed3",
	wrapper: "m_a5d60502",
	body: "m_667c2793",
	title: "m_6a03f287",
	label: "m_698f4f23",
	icon: "m_667f2a6a",
	message: "m_7fa78076",
	closeButton: "m_87f54839"
}, hs = G((e, { radius: t, color: n, variant: r, autoContrast: i }) => {
	let a = e.variantColorResolver({
		color: n || e.primaryColor,
		theme: e,
		variant: r || "light",
		autoContrast: i
	});
	return { root: {
		"--alert-radius": t === void 0 ? void 0 : ue(t),
		"--alert-bg": n || r ? a.background : void 0,
		"--alert-color": a.color,
		"--alert-bd": n || r ? a.border : void 0
	} };
}), gs = J((e) => {
	let t = K("Alert", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, radius: c, color: l, title: u, children: d, id: f, icon: p, withCloseButton: m, onClose: h, closeButtonLabel: g, variant: _, autoContrast: v, role: y, attributes: b, ...x } = t, S = q({
		name: "Alert",
		classes: ms,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: b,
		vars: s,
		varsResolver: hs
	}), C = Pe(f), w = u && `${C}-title` || void 0, D = `${C}-body`;
	return /* @__PURE__ */ T(Y, {
		id: C,
		...S("root", { variant: _ }),
		variant: _,
		...x,
		role: y || "alert",
		"aria-describedby": d ? D : void 0,
		"aria-labelledby": u ? w : void 0,
		children: /* @__PURE__ */ E("div", {
			...S("wrapper"),
			children: [
				p && /* @__PURE__ */ T("div", {
					...S("icon"),
					children: p
				}),
				/* @__PURE__ */ E("div", {
					...S("body"),
					children: [u && /* @__PURE__ */ T("div", {
						...S("title"),
						"data-with-close-button": m || void 0,
						children: /* @__PURE__ */ T("span", {
							id: w,
							...S("label"),
							children: u
						})
					}), d && /* @__PURE__ */ T("div", {
						id: D,
						...S("message"),
						"data-variant": _,
						children: d
					})]
				}),
				m && /* @__PURE__ */ T($i, {
					...S("closeButton"),
					onClick: h,
					variant: "transparent",
					size: 16,
					iconSize: 16,
					"aria-label": g,
					unstyled: o
				})
			]
		})
	});
});
gs.classes = ms, gs.varsResolver = hs, gs.displayName = "@mantine/core/Alert";
//#endregion
//#region node_modules/@mantine/core/esm/components/Text/Text.module.mjs
var _s = { root: "m_b6d8b162" };
//#endregion
//#region node_modules/@mantine/core/esm/components/Text/Text.mjs
function vs(e) {
	if (e === "start") return "start";
	if (e === "end" || e) return "end";
}
var ys = { inherit: !1 }, bs = G((e, { variant: t, lineClamp: n, gradient: r, size: i, textWrap: a }) => ({ root: {
	"--text-fz": H(i),
	"--text-lh": de(i),
	"--text-gradient": t === "gradient" ? _t(r, e) : void 0,
	"--text-line-clamp": typeof n == "number" ? n.toString() : void 0,
	"--text-text-wrap": a
} })), Z = lr((e) => {
	let t = K("Text", ys, e), { lineClamp: n, truncate: r, inline: i, inherit: a, gradient: o, span: s, textWrap: c, __staticSelector: l, vars: u, className: d, style: f, classNames: p, styles: m, unstyled: h, variant: g, mod: _, size: v, attributes: y, ...b } = t, x = q({
		name: ["Text", l],
		props: t,
		classes: _s,
		className: d,
		style: f,
		classNames: p,
		styles: m,
		unstyled: h,
		attributes: y,
		vars: u,
		varsResolver: bs
	});
	return /* @__PURE__ */ T(Y, {
		...x("root", { focusable: !0 }),
		component: s ? "span" : "p",
		variant: g,
		mod: [{
			truncate: vs(r),
			lineClamp: typeof n == "number",
			inline: i,
			inherit: a
		}, _],
		size: v,
		...b
	});
});
Z.classes = _s, Z.varsResolver = bs, Z.displayName = "@mantine/core/Text";
//#endregion
//#region node_modules/@mantine/core/esm/components/Combobox/get-parsed-combobox-data/get-parsed-combobox-data.mjs
function xs(e) {
	return typeof e == "string" ? {
		value: e,
		label: e
	} : typeof e == "object" && "value" in e && !("label" in e) ? {
		value: e.value,
		label: `${e.value}`,
		disabled: e.disabled
	} : typeof e == "object" && "group" in e ? {
		group: e.group,
		items: e.items.map((e) => xs(e))
	} : typeof e == "number" || typeof e == "bigint" || typeof e == "boolean" ? {
		value: e,
		label: `${e}`
	} : e;
}
function Ss(e) {
	return e ? e.map((e) => xs(e)) : [];
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Combobox/Combobox.module.mjs
var Cs = {
	dropdown: "m_88b62a41",
	search: "m_985517d8",
	options: "m_b2821a6e",
	option: "m_92253aa5",
	empty: "m_2530cd1d",
	header: "m_858f94bd",
	footer: "m_82b967cb",
	group: "m_254f3e4f",
	groupLabel: "m_2bb2e9e5",
	chevron: "m_2943220b",
	optionsDropdownOption: "m_390b5f4",
	optionsDropdownCheckIcon: "m_8ee53fc2",
	optionsDropdownCheckPlaceholder: "m_a530ee0a"
}, ws = { error: null }, Ts = G((e, { size: t, color: n }) => ({ chevron: {
	"--combobox-chevron-size": B(t, "combobox-chevron-size"),
	"--combobox-chevron-color": n ? mt(n, e) : void 0
} })), Es = J((e) => {
	let t = K("ComboboxChevron", ws, e), { size: n, error: r, style: i, className: a, classNames: o, styles: s, unstyled: c, vars: l, attributes: u, mod: d, ...f } = t, p = q({
		name: "ComboboxChevron",
		classes: Cs,
		props: t,
		style: i,
		className: a,
		classNames: o,
		styles: s,
		unstyled: c,
		vars: l,
		varsResolver: Ts,
		attributes: u,
		rootSelector: "chevron"
	});
	return /* @__PURE__ */ T(Y, {
		component: "svg",
		...f,
		...p("chevron"),
		size: n,
		viewBox: "0 0 15 15",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		mod: [
			"combobox-chevron",
			{ error: r },
			d
		],
		children: /* @__PURE__ */ T("path", {
			d: "M4.93179 5.43179C4.75605 5.60753 4.75605 5.89245 4.93179 6.06819C5.10753 6.24392 5.39245 6.24392 5.56819 6.06819L7.49999 4.13638L9.43179 6.06819C9.60753 6.24392 9.89245 6.24392 10.0682 6.06819C10.2439 5.89245 10.2439 5.60753 10.0682 5.43179L7.81819 3.18179C7.73379 3.0974 7.61933 3.04999 7.49999 3.04999C7.38064 3.04999 7.26618 3.0974 7.18179 3.18179L4.93179 5.43179ZM10.0682 9.56819C10.2439 9.39245 10.2439 9.10753 10.0682 8.93179C9.89245 8.75606 9.60753 8.75606 9.43179 8.93179L7.49999 10.8636L5.56819 8.93179C5.39245 8.75606 5.10753 8.75606 4.93179 8.93179C4.75605 9.10753 4.75605 9.39245 4.93179 9.56819L7.18179 11.8182C7.35753 11.9939 7.64245 11.9939 7.81819 11.8182L10.0682 9.56819Z",
			fill: "currentColor",
			fillRule: "evenodd",
			clipRule: "evenodd"
		})
	});
});
Es.classes = Cs, Es.varsResolver = Ts, Es.displayName = "@mantine/core/ComboboxChevron";
//#endregion
//#region node_modules/@mantine/core/esm/utils/InputsGroupFieldset/InputsGroupFieldset.mjs
function Ds({ children: e, role: t }) {
	let n = u(Po);
	return n ? /* @__PURE__ */ T("div", {
		role: t,
		"aria-labelledby": n.labelId,
		"aria-describedby": n.describedBy,
		children: e
	}) : /* @__PURE__ */ T(w, { children: e });
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Checkbox/CheckboxGroup/CheckboxGroup.mjs
var Os = s(null), ks = { hiddenInputValuesSeparator: "," }, As = cr(((e) => {
	let { value: t, defaultValue: n, onChange: r, size: i, wrapperProps: a, children: o, readOnly: s, name: c, hiddenInputValuesSeparator: l, hiddenInputProps: u, maxSelectedValues: d, disabled: f, ...p } = K("CheckboxGroup", ks, e), [m, h] = ze({
		value: t,
		defaultValue: n,
		finalValue: [],
		onChange: r
	}), g = (e) => {
		let t = typeof e == "string" ? e : e.currentTarget.value;
		if (s) return;
		let n = m.includes(t);
		!n && d && m.length >= d || h(n ? m.filter((e) => e !== t) : [...m, t]);
	}, _ = (e) => {
		if (f) return !0;
		if (!d) return !1;
		let t = m.includes(e), n = m.length >= d;
		return !t && n;
	}, v = m.join(l);
	return /* @__PURE__ */ T(Os, {
		value: {
			value: m,
			onChange: g,
			size: i,
			isDisabled: _
		},
		children: /* @__PURE__ */ E(Qo.Wrapper, {
			size: i,
			...a,
			...p,
			labelElement: "div",
			__staticSelector: "CheckboxGroup",
			children: [/* @__PURE__ */ T(Ds, {
				role: "group",
				children: o
			}), /* @__PURE__ */ T("input", {
				type: "hidden",
				name: c,
				value: v,
				...u
			})]
		})
	});
}));
As.classes = Qo.Wrapper.classes, As.displayName = "@mantine/core/CheckboxGroup";
//#endregion
//#region node_modules/@mantine/core/esm/components/Checkbox/CheckboxCard/CheckboxCard.module.mjs
var js = { card: "m_26775b0a" }, Ms = s(null), Ns = { withBorder: !0 }, Ps = G((e, { radius: t }) => ({ card: { "--card-radius": ue(t) } })), Fs = J((e) => {
	let t = K("CheckboxCard", Ns, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, checked: c, mod: l, withBorder: d, value: f, onClick: p, defaultChecked: m, onChange: h, indeterminate: g, attributes: _, ...v } = t, y = q({
		name: "CheckboxCard",
		classes: js,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: _,
		vars: s,
		varsResolver: Ps,
		rootSelector: "card"
	}), b = u(Os), [x, S] = ze({
		value: typeof c == "boolean" ? c : b ? b.value.includes(f || "") : void 0,
		defaultValue: m,
		finalValue: !1,
		onChange: h
	});
	return /* @__PURE__ */ T(Ms, {
		value: {
			checked: x,
			indeterminate: g
		},
		children: /* @__PURE__ */ T(ui, {
			mod: [{
				"with-border": d,
				checked: x,
				indeterminate: g
			}, l],
			...y("card"),
			...v,
			role: "checkbox",
			"aria-checked": g ? "mixed" : x,
			onClick: (e) => {
				p?.(e), b?.onChange(f || ""), S(!x);
			}
		})
	});
});
Fs.displayName = "@mantine/core/CheckboxCard", Fs.classes = js, Fs.varsResolver = Ps;
//#endregion
//#region node_modules/@mantine/core/esm/components/Checkbox/CheckIcon.mjs
function Is({ size: e, style: t, ...n }) {
	let r = e === void 0 ? t : {
		width: P(e),
		height: P(e),
		...t
	};
	return /* @__PURE__ */ T("svg", {
		viewBox: "0 0 10 7",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		style: r,
		"aria-hidden": !0,
		...n,
		children: /* @__PURE__ */ T("path", {
			d: "M4 4.586L1.707 2.293A1 1 0 1 0 .293 3.707l3 3a.997.997 0 0 0 1.414 0l5-5A1 1 0 1 0 8.293.293L4 4.586z",
			fill: "currentColor",
			fillRule: "evenodd",
			clipRule: "evenodd"
		})
	});
}
function Ls({ indeterminate: e, ...t }) {
	return e ? /* @__PURE__ */ T("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		fill: "none",
		viewBox: "0 0 32 6",
		"aria-hidden": !0,
		...t,
		children: /* @__PURE__ */ T("rect", {
			width: "32",
			height: "6",
			fill: "currentColor",
			rx: "3"
		})
	}) : /* @__PURE__ */ T(Is, { ...t });
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Checkbox/CheckboxIndicator/CheckboxIndicator.module.mjs
var Rs = {
	indicator: "m_5e5256ee",
	icon: "m_1b1c543a",
	"indicator--outline": "m_76e20374"
}, zs = {
	icon: Ls,
	variant: "filled",
	radius: "sm"
}, Bs = G((e, { radius: t, color: n, size: r, iconColor: i, variant: a, autoContrast: o }) => {
	let s = pt({
		color: n || e.primaryColor,
		theme: e
	}), c = s.isThemeColor && s.shade === void 0 ? `var(--mantine-color-${s.color}-outline)` : s.color;
	return { indicator: {
		"--checkbox-size": B(r, "checkbox-size"),
		"--checkbox-radius": t === void 0 ? void 0 : ue(t),
		"--checkbox-color": a === "outline" ? c : mt(n, e),
		"--checkbox-icon-color": i ? mt(i, e) : wt(o, e) ? xt({
			color: n,
			theme: e,
			autoContrast: o
		}) : void 0
	} };
}), Vs = J((e) => {
	let t = K("CheckboxIndicator", zs, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, icon: c, indeterminate: l, radius: d, color: f, iconColor: p, autoContrast: m, checked: h, mod: g, variant: _, disabled: v, attributes: y, ...b } = t, x = q({
		name: "CheckboxIndicator",
		classes: Rs,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: y,
		vars: s,
		varsResolver: Bs,
		rootSelector: "indicator"
	}), S = u(Ms), C = typeof l == "boolean" ? l : S?.indeterminate, w = typeof h == "boolean" || typeof l == "boolean" ? h || l : S?.checked || S?.indeterminate || !1;
	return /* @__PURE__ */ T(Y, {
		...x("indicator", { variant: _ }),
		variant: _,
		mod: [{
			checked: w,
			disabled: v
		}, g],
		...b,
		children: /* @__PURE__ */ T(c, {
			indeterminate: C,
			...x("icon")
		})
	});
});
Vs.displayName = "@mantine/core/CheckboxIndicator", Vs.classes = Rs, Vs.varsResolver = Bs;
//#endregion
//#region node_modules/@mantine/core/esm/utils/InlineInput/InlineInput.module.mjs
var Hs = {
	root: "m_5f75b09e",
	body: "m_5f6e695e",
	labelWrapper: "m_d3ea56bb",
	label: "m_8ee546b8",
	description: "m_328f68c0",
	error: "m_8e8a99cc"
}, Us = Hs;
function Ws({ __staticSelector: e, __stylesApiProps: t, className: n, classNames: r, styles: i, unstyled: a, children: o, label: s, description: c, id: l, disabled: u, error: d, size: f, labelPosition: p = "left", bodyElement: m = "div", labelElement: h = "label", variant: g, style: _, vars: v, mod: y, attributes: b, ...x }) {
	let S = q({
		name: e,
		props: t,
		className: n,
		style: _,
		classes: Hs,
		classNames: r,
		styles: i,
		unstyled: a,
		attributes: b
	}), C = c ? `${l}-description` : void 0, w = d && typeof d != "boolean" ? `${l}-error` : void 0;
	return /* @__PURE__ */ T(Y, {
		...S("root"),
		__vars: {
			"--label-fz": H(f),
			"--label-lh": B(f, "label-lh")
		},
		mod: [{ "label-position": p }, y],
		variant: g,
		size: f,
		...x,
		children: /* @__PURE__ */ E(Y, {
			component: m,
			htmlFor: m === "label" ? l : void 0,
			...S("body"),
			children: [o, /* @__PURE__ */ E("div", {
				...S("labelWrapper"),
				"data-disabled": u || void 0,
				children: [
					s && /* @__PURE__ */ T(Y, {
						component: h,
						htmlFor: h === "label" ? l : void 0,
						...S("label"),
						"data-disabled": u || void 0,
						children: s
					}),
					c && /* @__PURE__ */ T(Qo.Description, {
						id: C,
						size: f,
						__inheritStyles: !1,
						...S("description"),
						children: c
					}),
					d && typeof d != "boolean" && /* @__PURE__ */ T(Qo.Error, {
						id: w,
						size: f,
						__inheritStyles: !1,
						...S("error"),
						children: d
					})
				]
			})]
		})
	});
}
Ws.displayName = "@mantine/core/InlineInput";
//#endregion
//#region node_modules/@mantine/core/esm/components/Checkbox/Checkbox.module.mjs
var Gs = {
	root: "m_bf2d988c",
	inner: "m_26062bec",
	input: "m_26063560",
	icon: "m_bf295423",
	"input--outline": "m_215c4542"
}, Ks = {
	labelPosition: "right",
	icon: Ls,
	withErrorStyles: !0,
	variant: "filled",
	radius: "sm"
}, qs = G((e, { radius: t, color: n, size: r, iconColor: i, variant: a, autoContrast: o }) => {
	let s = pt({
		color: n || e.primaryColor,
		theme: e
	}), c = s.isThemeColor && s.shade === void 0 ? `var(--mantine-color-${s.color}-outline)` : s.color;
	return { root: {
		"--checkbox-size": B(r, "checkbox-size"),
		"--checkbox-radius": t === void 0 ? void 0 : ue(t),
		"--checkbox-color": a === "outline" ? c : mt(n, e),
		"--checkbox-icon-color": i ? mt(i, e) : wt(o, e) ? xt({
			color: n,
			theme: e,
			autoContrast: o
		}) : void 0
	} };
}), Js = J((e) => {
	let t = K("Checkbox", Ks, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, color: c, label: l, id: d, size: f, radius: m, wrapperProps: h, checked: g, labelPosition: _, description: y, error: b, disabled: x, variant: S, indeterminate: C, icon: w, rootRef: D, iconColor: O, onChange: k, autoContrast: ee, mod: A, attributes: j, readOnly: M, onClick: N, withErrorStyles: P, ref: te, ...ne } = t, F = v(null), I = u(Os), re = f || I?.size, L = q({
		name: "Checkbox",
		props: t,
		classes: Gs,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: j,
		vars: s,
		varsResolver: qs
	}), { styleProps: R, rest: z } = Pn(ne), ie = Pe(d), ae = [
		y ? `${ie}-description` : void 0,
		b && typeof b != "boolean" ? `${ie}-error` : void 0,
		z["aria-describedby"]
	].filter(Boolean).join(" ") || void 0, oe = {
		checked: I?.value.includes(z.value) ?? g,
		onChange: (e) => {
			M || (I?.onChange(e), k?.(e));
		}
	}, se = I?.isDisabled?.(z.value) ?? !1, ce = x || se;
	return p(() => {
		F.current && (F.current.indeterminate = C || !1, C ? F.current.setAttribute("data-indeterminate", "true") : F.current.removeAttribute("data-indeterminate"));
	}, [C]), /* @__PURE__ */ T(Ws, {
		...L("root"),
		__staticSelector: "Checkbox",
		__stylesApiProps: t,
		id: ie,
		size: re,
		labelPosition: _,
		label: l,
		description: y,
		error: b,
		disabled: ce,
		classNames: n,
		styles: a,
		unstyled: o,
		"data-checked": oe.checked || g || void 0,
		variant: S,
		ref: D,
		mod: A,
		attributes: j,
		inert: z.inert,
		...R,
		...h,
		children: /* @__PURE__ */ E(Y, {
			...L("inner"),
			mod: { labelPosition: _ },
			children: [/* @__PURE__ */ T(Y, {
				component: "input",
				id: ie,
				ref: Re(F, te),
				mod: {
					error: !!b,
					"with-error-styles": P
				},
				...L("input", {
					focusable: !0,
					variant: S
				}),
				...z,
				...oe,
				"aria-describedby": ae,
				disabled: ce,
				inert: z.inert,
				type: "checkbox",
				onClick: (e) => {
					M && oe.checked === void 0 && e.preventDefault(), N?.(e);
				}
			}), /* @__PURE__ */ T(w, {
				indeterminate: C,
				...L("icon")
			})]
		})
	});
});
Js.classes = {
	...Gs,
	...Us
}, Js.varsResolver = qs, Js.displayName = "@mantine/core/Checkbox", Js.Group = As, Js.Indicator = Vs, Js.Card = Fs;
//#endregion
//#region node_modules/@mantine/core/esm/components/Badge/Badge.module.mjs
var Ys = {
	root: "m_347db0ec",
	"root--dot": "m_fbd81e3d",
	label: "m_5add502a",
	section: "m_91fdda9b"
}, Xs = G((e, { radius: t, color: n, gradient: r, variant: i, size: a, autoContrast: o, circle: s }) => {
	let c = e.variantColorResolver({
		color: n || e.primaryColor,
		theme: e,
		gradient: r,
		variant: i || "filled",
		autoContrast: o
	});
	return { root: {
		"--badge-height": B(a, "badge-height"),
		"--badge-padding-x": B(a, "badge-padding-x"),
		"--badge-fz": B(a, "badge-fz"),
		"--badge-radius": s || t === void 0 ? void 0 : ue(t),
		"--badge-bg": n || i ? c.background : void 0,
		"--badge-color": n || i ? c.color : void 0,
		"--badge-bd": n || i ? c.border : void 0,
		"--badge-dot-color": i === "dot" ? mt(n, e) : void 0
	} };
}), Zs = lr((e) => {
	let t = K("Badge", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, radius: c, color: l, gradient: u, leftSection: d, rightSection: f, children: p, variant: m, fullWidth: h, autoContrast: g, circle: _, mod: v, attributes: y, ...b } = t, x = q({
		name: "Badge",
		props: t,
		classes: Ys,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: y,
		vars: s,
		varsResolver: Xs
	});
	return /* @__PURE__ */ E(Y, {
		variant: m,
		mod: [{
			block: h,
			circle: _,
			"with-right-section": !!f,
			"with-left-section": !!d
		}, v],
		...x("root", { variant: m }),
		...b,
		children: [
			d && /* @__PURE__ */ T("span", {
				...x("section"),
				"data-position": "left",
				children: d
			}),
			/* @__PURE__ */ T("span", {
				...x("label"),
				children: p
			}),
			f && /* @__PURE__ */ T("span", {
				...x("section"),
				"data-position": "right",
				children: f
			})
		]
	});
});
Zs.classes = Ys, Zs.varsResolver = Xs, Zs.displayName = "@mantine/core/Badge";
//#endregion
//#region node_modules/@mantine/core/esm/components/Button/Button.module.mjs
var Qs = {
	root: "m_77c9d27d",
	inner: "m_80f1301b",
	label: "m_811560b9",
	section: "m_a74036a",
	loader: "m_a25b86ee",
	group: "m_80d6d844",
	groupSection: "m_70be2a01"
}, $s = { orientation: "horizontal" }, ec = G((e, { borderWidth: t }) => ({ group: { "--button-border-width": P(t) } })), tc = J((e) => {
	let t = K("ButtonGroup", $s, e), { className: n, style: r, classNames: i, styles: a, unstyled: o, orientation: s, vars: c, borderWidth: l, mod: u, attributes: d, ...f } = K("ButtonGroup", $s, e), p = q({
		name: "ButtonGroup",
		props: t,
		classes: Qs,
		className: n,
		style: r,
		classNames: i,
		styles: a,
		unstyled: o,
		attributes: d,
		vars: c,
		varsResolver: ec,
		rootSelector: "group"
	});
	return /* @__PURE__ */ T(Y, {
		...p("group"),
		mod: [{ orientation: s }, u],
		role: "group",
		...f
	});
});
tc.classes = Qs, tc.varsResolver = ec, tc.displayName = "@mantine/core/ButtonGroup";
//#endregion
//#region node_modules/@mantine/core/esm/components/Button/ButtonGroupSection/ButtonGroupSection.mjs
var nc = G((e, { radius: t, color: n, gradient: r, variant: i, autoContrast: a, size: o }) => {
	let s = e.variantColorResolver({
		color: n || e.primaryColor,
		theme: e,
		gradient: r,
		variant: i || "filled",
		autoContrast: a
	});
	return { groupSection: {
		"--section-height": B(o, "section-height"),
		"--section-padding-x": B(o, "section-padding-x"),
		"--section-fz": o?.includes("compact") ? H(o.replace("compact-", "")) : H(o),
		"--section-radius": t === void 0 ? void 0 : ue(t),
		"--section-bg": n || i ? s.background : void 0,
		"--section-color": s.color,
		"--section-bd": n || i ? s.border : void 0
	} };
}), rc = J((e) => {
	let t = K("ButtonGroupSection", null, e), { className: n, style: r, classNames: i, styles: a, unstyled: o, vars: s, gradient: c, radius: l, autoContrast: u, attributes: d, ...f } = t, p = q({
		name: "ButtonGroupSection",
		props: t,
		classes: Qs,
		className: n,
		style: r,
		classNames: i,
		styles: a,
		unstyled: o,
		attributes: d,
		vars: s,
		varsResolver: nc,
		rootSelector: "groupSection"
	});
	return /* @__PURE__ */ T(Y, {
		...p("groupSection"),
		...f
	});
});
rc.classes = Qs, rc.varsResolver = nc, rc.displayName = "@mantine/core/ButtonGroupSection";
//#endregion
//#region node_modules/@mantine/core/esm/components/Button/Button.mjs
var ic = {
	in: {
		opacity: 1,
		transform: `translate(-50%, calc(-50% + ${P(1)}))`
	},
	out: {
		opacity: 0,
		transform: "translate(-50%, -200%)"
	},
	common: { transformOrigin: "center" },
	transitionProperty: "transform, opacity"
}, ac = G((e, { radius: t, color: n, gradient: r, variant: i, size: a, justify: o, autoContrast: s }) => {
	let c = e.variantColorResolver({
		color: n || e.primaryColor,
		theme: e,
		gradient: r,
		variant: i || "filled",
		autoContrast: s
	});
	return { root: {
		"--button-justify": o,
		"--button-height": B(a, "button-height"),
		"--button-padding-x": B(a, "button-padding-x"),
		"--button-fz": a?.includes("compact") ? H(a.replace("compact-", "")) : H(a),
		"--button-radius": t === void 0 ? void 0 : ue(t),
		"--button-bg": n || i ? c.background : void 0,
		"--button-hover": n || i ? c.hover : void 0,
		"--button-color": c.color,
		"--button-bd": n || i ? c.border : void 0,
		"--button-hover-color": n || i ? c.hoverColor : void 0
	} };
}), oc = lr((e) => {
	let t = K("Button", null, e), { style: n, vars: r, className: i, color: a, disabled: o, children: s, leftSection: c, rightSection: l, fullWidth: u, variant: d, radius: f, loading: p, loaderProps: m, gradient: h, classNames: g, styles: _, unstyled: v, "data-disabled": y, autoContrast: b, mod: x, attributes: S, ...C } = t, w = q({
		name: "Button",
		props: t,
		classes: Qs,
		className: i,
		style: n,
		classNames: g,
		styles: _,
		unstyled: v,
		attributes: S,
		vars: r,
		varsResolver: ac
	}), D = !!c, O = !!l;
	return /* @__PURE__ */ E(ui, {
		...w("root", { active: !o && !p && !y }),
		unstyled: v,
		variant: d,
		disabled: o || p,
		mod: [{
			disabled: o || y,
			loading: p,
			block: u,
			"with-left-section": D,
			"with-right-section": O
		}, x],
		...C,
		children: [typeof p == "boolean" && /* @__PURE__ */ T(Ai, {
			mounted: p,
			transition: ic,
			duration: 150,
			children: (e) => /* @__PURE__ */ T(Y, {
				component: "span",
				...w("loader", { style: e }),
				"aria-hidden": !0,
				children: /* @__PURE__ */ T(Bi, {
					color: "var(--button-color)",
					size: "calc(var(--button-height) / 1.8)",
					...m
				})
			})
		}), /* @__PURE__ */ E("span", {
			...w("inner"),
			children: [
				c && /* @__PURE__ */ T(Y, {
					component: "span",
					...w("section"),
					mod: { position: "left" },
					children: c
				}),
				/* @__PURE__ */ T(Y, {
					component: "span",
					mod: { loading: p },
					...w("label"),
					children: s
				}),
				l && /* @__PURE__ */ T(Y, {
					component: "span",
					...w("section"),
					mod: { position: "right" },
					children: l
				})
			]
		})]
	});
});
oc.classes = Qs, oc.varsResolver = ac, oc.displayName = "@mantine/core/Button", oc.Group = tc, oc.GroupSection = rc;
//#endregion
//#region node_modules/@mantine/core/esm/components/Code/Code.module.mjs
var sc = { root: "m_b183c0a2" }, cc = G((e, { color: t }) => ({ root: { "--code-bg": t ? mt(t, e) : void 0 } })), lc = J((e) => {
	let t = K("Code", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, color: c, block: l, mod: u, attributes: d, ...f } = t, p = q({
		name: "Code",
		props: t,
		classes: sc,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: d,
		vars: s,
		varsResolver: cc
	});
	return /* @__PURE__ */ T(Y, {
		component: l ? "pre" : "code",
		mod: [{ block: l }, u],
		...p("root"),
		...f,
		dir: "ltr"
	});
});
lc.classes = sc, lc.varsResolver = cc, lc.displayName = "@mantine/core/Code";
//#endregion
//#region node_modules/@mantine/core/esm/components/Fieldset/Fieldset.module.mjs
var uc = {
	root: "m_e9408a47",
	"root--default": "m_84c9523a",
	"root--filled": "m_ef274e49",
	"root--unstyled": "m_eda993d3",
	legend: "m_90794832",
	"legend--unstyled": "m_74ca27fe"
}, dc = { variant: "default" }, fc = G((e, { radius: t }) => ({ root: { "--fieldset-radius": t === void 0 ? void 0 : ue(t) } })), pc = J((e) => {
	let t = K("Fieldset", dc, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, legend: c, variant: l, children: u, attributes: d, ...f } = t, p = q({
		name: "Fieldset",
		classes: uc,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: d,
		vars: s,
		varsResolver: fc
	});
	return /* @__PURE__ */ E(Y, {
		component: "fieldset",
		variant: l,
		...p("root", { variant: l }),
		...f,
		children: [c && /* @__PURE__ */ T("legend", {
			...p("legend", { variant: l }),
			children: c
		}), u]
	});
});
pc.classes = uc, pc.varsResolver = fc, pc.displayName = "@mantine/core/Fieldset";
//#endregion
//#region node_modules/@mantine/core/esm/components/FileButton/FileButton.mjs
var mc = cr((e) => {
	let { onChange: t, children: n, multiple: r, accept: i, name: a, form: o, resetRef: s, disabled: c, capture: l, inputProps: u, ref: d, ...f } = K("FileButton", null, e), p = v(null), m = () => {
		!c && p.current?.click();
	};
	return Ie(s, () => {
		p.current && (p.current.value = "");
	}), /* @__PURE__ */ E(w, { children: [/* @__PURE__ */ T("input", {
		style: { display: "none" },
		type: "file",
		accept: i,
		multiple: r,
		onChange: (e) => {
			if (e.currentTarget.files === null) return t(r ? [] : null);
			t(r ? Array.from(e.currentTarget.files) : e.currentTarget.files[0] || null);
		},
		ref: Re(d, p),
		name: a,
		form: o,
		capture: l,
		...u
	}), n({
		onClick: m,
		...f
	})] });
});
mc.displayName = "@mantine/core/FileButton";
//#endregion
//#region node_modules/@mantine/core/esm/components/Textarea/Autosize.mjs
var hc = [
	"borderBottomWidth",
	"borderLeftWidth",
	"borderRightWidth",
	"borderTopWidth",
	"boxSizing",
	"fontFamily",
	"fontSize",
	"fontStyle",
	"fontWeight",
	"letterSpacing",
	"lineHeight",
	"paddingBottom",
	"paddingLeft",
	"paddingRight",
	"paddingTop",
	"tabSize",
	"textIndent",
	"textRendering",
	"textTransform",
	"width",
	"wordBreak",
	"wordSpacing",
	"scrollbarGutter"
], gc = {
	"min-height": "0",
	"max-height": "none",
	height: "0",
	visibility: "hidden",
	overflow: "hidden",
	position: "absolute",
	"z-index": "-1000",
	top: "0",
	right: "0",
	display: "block"
};
function _c(e) {
	Object.keys(gc).forEach((t) => {
		e.style.setProperty(t, gc[t], "important");
	});
}
function vc(e) {
	let t = window.getComputedStyle(e);
	if (t === null) return null;
	let n = {};
	for (let e of hc) n[e] = t[e];
	return n.boxSizing === "" ? null : {
		sizingStyle: n,
		paddingSize: parseFloat(n.paddingBottom) + parseFloat(n.paddingTop),
		borderSize: parseFloat(n.borderBottomWidth) + parseFloat(n.borderTopWidth)
	};
}
var yc = null;
function bc(e, t, n = 1, r = Infinity) {
	yc || (yc = document.createElement("textarea"), yc.setAttribute("tabindex", "-1"), yc.setAttribute("aria-hidden", "true"), yc.setAttribute("aria-label", "autosize measurement"), _c(yc)), yc.parentNode === null && document.body.appendChild(yc);
	let { paddingSize: i, borderSize: a, sizingStyle: o } = e, { boxSizing: s } = o;
	Object.keys(o).forEach((e) => {
		yc.style[e] = o[e];
	}), _c(yc), yc.value = t;
	let c = s === "border-box" ? yc.scrollHeight + a : yc.scrollHeight - i;
	yc.value = t, c = s === "border-box" ? yc.scrollHeight + a : yc.scrollHeight - i, yc.value = "x";
	let l = yc.scrollHeight - i, u = l * n;
	s === "border-box" && (u = u + i + a), c = Math.max(u, c);
	let d = l * r;
	return s === "border-box" && (d = d + i + a), c = Math.min(d, c), [c, l];
}
function xc({ maxRows: e, minRows: t, onChange: n, ref: r, ...i }) {
	let a = i.value !== void 0, o = v(null), s = Re(o, r), c = v(0), l = v(0), u = () => {
		let n = o.current;
		if (!n) return;
		let r = vc(n);
		if (!r) return;
		let [i] = bc(r, n.value || n.placeholder || "x", t, e);
		c.current !== i && (c.current = i, n.style.setProperty("height", `${i}px`, "important"));
	}, d = (e) => {
		a || u(), n?.(e);
	};
	return g(u), p(() => {
		let e = () => u();
		return window.addEventListener("resize", e), () => window.removeEventListener("resize", e);
	}, []), p(() => {
		let e = o.current;
		if (!e || typeof ResizeObserver > "u") return;
		l.current = e.offsetWidth;
		let t = new ResizeObserver(() => {
			o.current && o.current.offsetWidth !== l.current && (l.current = o.current.offsetWidth, u());
		});
		return t.observe(e), () => t.disconnect();
	}, []), p(() => {
		let e = () => u();
		return document.fonts.addEventListener("loadingdone", e), () => document.fonts.removeEventListener("loadingdone", e);
	}, []), p(() => {
		let e = (e) => {
			if (o.current?.form === e.target && !a) {
				let e = o.current.value;
				requestAnimationFrame(() => {
					o.current && e !== o.current.value && u();
				});
			}
		};
		return document.body.addEventListener("reset", e), () => document.body.removeEventListener("reset", e);
	}, [a]), /* @__PURE__ */ T("textarea", {
		rows: t,
		...i,
		onChange: d,
		ref: s
	});
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Textarea/Textarea.mjs
var Sc = J((e) => {
	let { autosize: t, maxRows: n, minRows: r, __staticSelector: i, resize: a, bottomSection: o, bottomSectionProps: s, ...c } = K([
		"Input",
		"InputWrapper",
		"Textarea"
	], null, e), l = t && qe() !== "test", u = l ? {
		maxRows: n,
		minRows: r
	} : {};
	return /* @__PURE__ */ T(ts, {
		component: l ? xc : "textarea",
		...c,
		__staticSelector: i || "Textarea",
		__bottomSection: o,
		__bottomSectionProps: s,
		multiline: !0,
		"data-no-overflow": t && n === void 0 || void 0,
		__vars: { "--input-resize": a },
		...u
	});
});
Sc.classes = ts.classes, Sc.displayName = "@mantine/core/Textarea";
//#endregion
//#region node_modules/@mantine/core/esm/components/Modal/Modal.context.mjs
var [Cc, wc] = re("Modal component was not found in tree"), Tc = {
	root: "m_9df02822",
	content: "m_54c44539",
	inner: "m_1f958f16",
	header: "m_d0e2b9cd"
}, Ec = J((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, ...o } = K("ModalBody", null, e), s = wc();
	return /* @__PURE__ */ T(bo, {
		...s.getStyles("body", {
			classNames: t,
			style: r,
			styles: i,
			className: n
		}),
		...o
	});
});
Ec.classes = Tc, Ec.displayName = "@mantine/core/ModalBody";
//#endregion
//#region node_modules/@mantine/core/esm/components/Modal/ModalCloseButton.mjs
var Dc = J((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, ...o } = K("ModalCloseButton", null, e), s = wc();
	return /* @__PURE__ */ T(xo, {
		...s.getStyles("close", {
			classNames: t,
			style: r,
			styles: i,
			className: n
		}),
		...o
	});
});
Dc.classes = Tc, Dc.displayName = "@mantine/core/ModalCloseButton";
//#endregion
//#region node_modules/@mantine/core/esm/components/Modal/ModalContent.mjs
var Oc = J((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, children: o, __hidden: s, ...c } = K("ModalContent", null, e), l = wc(), u = l.scrollAreaComponent || ko;
	return /* @__PURE__ */ T(So, {
		...l.getStyles("content", {
			className: n,
			style: r,
			styles: i,
			classNames: t
		}),
		innerProps: l.getStyles("inner", {
			className: n,
			style: r,
			styles: i,
			classNames: t
		}),
		"data-full-screen": l.fullScreen || void 0,
		"data-modal-content": !0,
		"data-hidden": s || void 0,
		...c,
		children: /* @__PURE__ */ T(u, {
			style: { maxHeight: l.fullScreen ? "100dvh" : `calc(100dvh - (${P(l.yOffset)} * 2))` },
			children: o
		})
	});
});
Oc.classes = Tc, Oc.displayName = "@mantine/core/ModalContent";
//#endregion
//#region node_modules/@mantine/core/esm/components/Modal/ModalHeader.mjs
var kc = J((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, ...o } = K("ModalHeader", null, e), s = wc();
	return /* @__PURE__ */ T(Co, {
		...s.getStyles("header", {
			classNames: t,
			style: r,
			styles: i,
			className: n
		}),
		...o
	});
});
kc.classes = Tc, kc.displayName = "@mantine/core/ModalHeader";
//#endregion
//#region node_modules/@mantine/core/esm/components/Modal/ModalOverlay.mjs
var Ac = J((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, ...o } = K("ModalOverlay", null, e), s = wc();
	return /* @__PURE__ */ T(Eo, {
		...s.getStyles("overlay", {
			classNames: t,
			style: r,
			styles: i,
			className: n
		}),
		...o
	});
});
Ac.classes = Tc, Ac.displayName = "@mantine/core/ModalOverlay";
//#endregion
//#region node_modules/@mantine/core/esm/components/Modal/ModalRoot.mjs
var jc = {
	__staticSelector: "Modal",
	closeOnClickOutside: !0,
	withinPortal: !0,
	lockScroll: !0,
	trapFocus: !0,
	returnFocus: !0,
	closeOnEscape: !0,
	keepMounted: !1,
	zIndex: ce("modal"),
	transitionProps: {
		duration: 200,
		transition: "fade-down"
	},
	yOffset: "5dvh"
}, Mc = G((e, { radius: t, size: n, yOffset: r, xOffset: i }) => ({ root: {
	"--modal-radius": t === void 0 ? void 0 : ue(t),
	"--modal-size": B(n, "modal-size"),
	"--modal-y-offset": P(r),
	"--modal-x-offset": P(i)
} })), Nc = J((e) => {
	let t = K("ModalRoot", jc, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, yOffset: c, scrollAreaComponent: l, radius: u, fullScreen: d, centered: f, xOffset: p, __staticSelector: m, attributes: h, ...g } = t, _ = q({
		name: m,
		classes: Tc,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: h,
		vars: s,
		varsResolver: Mc
	});
	return /* @__PURE__ */ T(Cc, {
		value: {
			yOffset: c,
			scrollAreaComponent: l,
			getStyles: _,
			fullScreen: d
		},
		children: /* @__PURE__ */ T(_o, {
			..._("root"),
			"data-full-screen": d || void 0,
			"data-centered": f || void 0,
			"data-offset-scrollbars": l === oi.Autosize || void 0,
			unstyled: o,
			...g
		})
	});
});
Nc.classes = Tc, Nc.varsResolver = Mc, Nc.displayName = "@mantine/core/ModalRoot";
//#endregion
//#region node_modules/@mantine/core/esm/components/Modal/ModalStack.mjs
var Pc = s(null);
function Fc({ children: e }) {
	let [t, n] = y([]), [r, i] = y(ce("modal"));
	return /* @__PURE__ */ T(Pc, {
		value: {
			stack: t,
			addModal: (e, t) => {
				n((t) => [.../* @__PURE__ */ new Set([...t, e])]), i((e) => typeof t == "number" && typeof e == "number" ? Math.max(e, t) : e);
			},
			removeModal: (e) => n((t) => t.filter((t) => t !== e)),
			getZIndex: (e) => `calc(${r} + ${t.indexOf(e)} + 1)`,
			currentId: t[t.length - 1],
			maxZIndex: r
		},
		children: e
	});
}
Fc.displayName = "@mantine/core/ModalStack";
//#endregion
//#region node_modules/@mantine/core/esm/components/Modal/ModalTitle.mjs
var Ic = J((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, ...o } = K("ModalTitle", null, e), s = wc();
	return /* @__PURE__ */ T(Oo, {
		...s.getStyles("title", {
			classNames: t,
			style: r,
			styles: i,
			className: n
		}),
		...o
	});
});
Ic.classes = Tc, Ic.displayName = "@mantine/core/ModalTitle";
//#endregion
//#region node_modules/@mantine/core/esm/components/Modal/Modal.mjs
var Lc = {
	closeOnClickOutside: !0,
	withinPortal: !0,
	lockScroll: !0,
	trapFocus: !0,
	returnFocus: !0,
	closeOnEscape: !0,
	keepMounted: !1,
	zIndex: ce("modal"),
	transitionProps: {
		duration: 200,
		transition: "fade-down"
	},
	withOverlay: !0,
	withCloseButton: !0
}, Rc = J((e) => {
	let { title: t, withOverlay: n, overlayProps: r, withCloseButton: i, closeButtonProps: a, children: o, radius: s, opened: c, stackId: l, zIndex: d, ...f } = K("Modal", Lc, e), m = u(Pc), h = !!t || i, g = m && l ? {
		closeOnEscape: m.currentId === l,
		trapFocus: m.currentId === l,
		zIndex: m.getZIndex(l)
	} : {}, _ = n === !1 ? !1 : l && m ? m.currentId === l : c;
	return p(() => {
		m && l && (c ? m.addModal(l, d || ce("modal")) : m.removeModal(l));
	}, [
		c,
		l,
		d
	]), /* @__PURE__ */ E(Nc, {
		radius: s,
		opened: c,
		zIndex: m && l ? m.getZIndex(l) : d,
		...f,
		...g,
		children: [n && /* @__PURE__ */ T(Ac, {
			visible: _,
			transitionProps: m && l ? { duration: 0 } : void 0,
			...r
		}), /* @__PURE__ */ E(Oc, {
			radius: s,
			__hidden: m && l && c ? l !== m.currentId : !1,
			children: [h && /* @__PURE__ */ E(kc, { children: [t && /* @__PURE__ */ T(Ic, { children: t }), i && /* @__PURE__ */ T(Dc, { ...a })] }), /* @__PURE__ */ T(Ec, { children: o })]
		})]
	});
});
Rc.classes = Tc, Rc.displayName = "@mantine/core/Modal", Rc.Root = Nc, Rc.Overlay = Ac, Rc.Content = Oc, Rc.Body = Ec, Rc.Header = kc, Rc.Title = Ic, Rc.CloseButton = Dc, Rc.Stack = Fc;
//#endregion
//#region node_modules/@mantine/core/esm/components/NativeSelect/NativeSelectOption.mjs
function zc(e) {
	return "group" in e;
}
function Bc({ data: e }) {
	if (zc(e)) {
		let t = e.items.map((e) => /* @__PURE__ */ T(Bc, { data: e }, e.value));
		return /* @__PURE__ */ T("optgroup", {
			label: e.group,
			children: t
		});
	}
	let { value: t, label: n, ...r } = e;
	return /* @__PURE__ */ T("option", {
		value: e.value,
		...r,
		children: e.label
	});
}
Bc.displayName = "@mantine/core/NativeSelectOption";
//#endregion
//#region node_modules/@mantine/core/esm/components/NativeSelect/NativeSelect.mjs
var Vc = {
	size: "sm",
	rightSectionPointerEvents: "none"
}, Hc = J((e) => {
	let { data: t, children: n, size: r, error: i, rightSection: a, unstyled: o, ...s } = K([
		"Input",
		"InputWrapper",
		"NativeSelect"
	], Vc, e), c = Ss(t).map((e, t) => /* @__PURE__ */ T(Bc, { data: e }, t));
	return /* @__PURE__ */ T(ts, {
		component: "select",
		...s,
		__staticSelector: "NativeSelect",
		size: r,
		pointer: !0,
		error: i,
		unstyled: o,
		rightSection: a || /* @__PURE__ */ T(Es, {
			size: r,
			error: i,
			unstyled: o
		}),
		children: n || c
	});
});
Hc.classes = ts.classes, Hc.displayName = "@mantine/core/NativeSelect";
//#endregion
//#region node_modules/react-number-format/dist/react-number-format.es.js
function Uc(e, t) {
	var n = {};
	for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
	if (e != null && typeof Object.getOwnPropertySymbols == "function") for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++) t.indexOf(r[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (n[r[i]] = e[r[i]]);
	return n;
}
var Wc;
(function(e) {
	e.event = "event", e.props = "prop";
})(Wc ||= {});
function Gc() {}
function Kc(e) {
	var t, n = void 0;
	return function() {
		for (var r = [], i = arguments.length; i--;) r[i] = arguments[i];
		return t && r.length === t.length && r.every(function(e, n) {
			return e === t[n];
		}) ? n : (t = r, n = e.apply(void 0, r), n);
	};
}
function qc(e) {
	return !!(e || "").match(/\d/);
}
function Jc(e) {
	return e == null;
}
function Yc(e) {
	return typeof e == "number" && isNaN(e);
}
function Xc(e) {
	return Jc(e) || Yc(e) || typeof e == "number" && !isFinite(e);
}
function Zc(e) {
	return e.replace(/[-[\]/{}()*+?.\\^$|]/g, "\\$&");
}
function Qc(e) {
	switch (e) {
		case "lakh": return /(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?/g;
		case "wan": return /(\d)(?=(\d{4})+(?!\d))/g;
		default: return /(\d)(?=(\d{3})+(?!\d))/g;
	}
}
function $c(e, t, n) {
	var r = Qc(n), i = e.search(/[1-9]/);
	return i = i === -1 ? e.length : i, e.substring(0, i) + e.substring(i, e.length).replace(r, "$1" + t);
}
function el(e) {
	var t = v(e);
	return t.current = e, v(function() {
		for (var e = [], n = arguments.length; n--;) e[n] = arguments[n];
		return t.current.apply(t, e);
	}).current;
}
function tl(e, t) {
	t === void 0 && (t = !0);
	var n = e[0] === "-", r = n && t;
	e = e.replace("-", "");
	var i = e.split(".");
	return {
		beforeDecimal: i[0],
		afterDecimal: i[1] || "",
		hasNegation: n,
		addNegation: r
	};
}
function nl(e) {
	if (!e) return e;
	var t = e[0] === "-";
	t && (e = e.substring(1, e.length));
	var n = e.split("."), r = n[0].replace(/^0+/, "") || "0", i = n[1] || "";
	return (t ? "-" : "") + r + (i ? "." + i : "");
}
function rl(e, t, n) {
	for (var r = "", i = n ? "0" : "", a = 0; a <= t - 1; a++) r += e[a] || i;
	return r;
}
function il(e, t) {
	return Array(t + 1).join(e);
}
function al(e) {
	var t = e + "", n = t[0] === "-" ? "-" : "";
	n && (t = t.substring(1));
	var r = t.split(/[eE]/g), i = r[0], a = r[1];
	if (a = Number(a), !a) return n + i;
	i = i.replace(".", "");
	var o = 1 + a, s = i.length;
	return o < 0 ? i = "0." + il("0", Math.abs(o)) + i : o >= s ? i += il("0", o - s) : i = (i.substring(0, o) || "0") + "." + i.substring(o), n + i;
}
function ol(e, t, n) {
	if (["", "-"].indexOf(e) !== -1) return e;
	var r = (e.indexOf(".") !== -1 || n) && t, i = tl(e), a = i.beforeDecimal, o = i.afterDecimal, s = i.hasNegation, c = parseFloat("0." + (o || "0")), l = (o.length <= t ? "0." + o : c.toFixed(t)).split("."), u = a;
	a && Number(l[0]) && (u = a.split("").reverse().reduce(function(e, t, n) {
		return e.length > n ? (Number(e[0]) + Number(t)).toString() + e.substring(1, e.length) : t + e;
	}, l[0]));
	var d = rl(l[1] || "", t, n), f = s ? "-" : "", p = r ? "." : "";
	return "" + f + u + p + d;
}
function sl(e, t) {
	if (e.value = e.value, e !== null) {
		if (e.createTextRange) {
			var n = e.createTextRange();
			return n.move("character", t), n.select(), !0;
		}
		return e.selectionStart || e.selectionStart === 0 ? (e.focus(), e.setSelectionRange(t, t), !0) : (e.focus(), !1);
	}
}
var cl = Kc(function(e, t) {
	for (var n = 0, r = 0, i = e.length, a = t.length; e[n] === t[n] && n < i;) n++;
	for (; e[i - 1 - r] === t[a - 1 - r] && a - r > n && i - r > n;) r++;
	return {
		from: {
			start: n,
			end: i - r
		},
		to: {
			start: n,
			end: a - r
		}
	};
}), ll = function(e, t) {
	var n = Math.min(e.selectionStart, t);
	return {
		from: {
			start: n,
			end: e.selectionEnd
		},
		to: {
			start: n,
			end: t
		}
	};
};
function ul(e, t, n) {
	return Math.min(Math.max(e, t), n);
}
function dl(e) {
	return Math.max(e.selectionStart, e.selectionEnd);
}
function fl() {
	return typeof navigator < "u" && !(navigator.platform && /iPhone|iPod/.test(navigator.platform));
}
function pl(e) {
	return {
		from: {
			start: 0,
			end: 0
		},
		to: {
			start: 0,
			end: e.length
		},
		lastValue: ""
	};
}
function ml(e) {
	var t = e.currentValue, n = e.formattedValue, r = e.currentValueIndex, i = e.formattedValueIndex;
	return t[r] === n[i];
}
function hl(e, t, n, r, i, a, o) {
	o === void 0 && (o = ml);
	var s = i.findIndex(function(e) {
		return e;
	}), c = e.slice(0, s);
	!t && !n.startsWith(c) && (t = c, n = c + n, r += c.length);
	for (var l = n.length, u = e.length, d = {}, f = Array(l), p = 0; p < l; p++) {
		f[p] = -1;
		for (var m = 0, h = u; m < h; m++) if (o({
			currentValue: n,
			lastValue: t,
			formattedValue: e,
			currentValueIndex: p,
			formattedValueIndex: m
		}) && d[m] !== !0) {
			f[p] = m, d[m] = !0;
			break;
		}
	}
	for (var g = r; g < l && (f[g] === -1 || !a(n[g]));) g++;
	var _ = g === l || f[g] === -1 ? u : f[g];
	for (g = r - 1; g > 0 && f[g] === -1;) g--;
	var v = g === -1 || f[g] === -1 ? 0 : f[g] + 1;
	return v > _ ? _ : r - v < _ - r ? v : _;
}
function gl(e, t, n, r) {
	var i = e.length;
	if (t = ul(t, 0, i), r === "left") {
		for (; t >= 0 && !n[t];) t--;
		t === -1 && (t = n.indexOf(!0));
	} else {
		for (; t <= i && !n[t];) t++;
		t > i && (t = n.lastIndexOf(!0));
	}
	return t === -1 && (t = i), t;
}
function _l(e) {
	for (var t = Array.from({ length: e.length + 1 }).map(function() {
		return !0;
	}), n = 0, r = t.length; n < r; n++) t[n] = !!(qc(e[n]) || qc(e[n - 1]));
	return t;
}
function vl(e, t, n, r, i, a) {
	a === void 0 && (a = Gc);
	var o = el(function(e, t) {
		var n, a;
		return Xc(e) ? (a = "", n = "") : typeof e == "number" || t ? (a = typeof e == "number" ? al(e) : e, n = r(a)) : (a = i(e, void 0), n = r(a)), {
			formattedValue: n,
			numAsString: a
		};
	}), s = y(function() {
		return o(Jc(e) ? t : e, n);
	}), c = s[0], l = s[1], u = el(function(e, t) {
		e.formattedValue !== c.formattedValue && l({
			formattedValue: e.formattedValue,
			numAsString: e.value
		}), a(e, t);
	}), d = e, f = n;
	Jc(e) && (d = c.numAsString, f = !0);
	var m = o(d, f);
	return _(function() {
		l(m);
	}, [m.formattedValue]), p(function() {
		if (!Jc(t) && Jc(e) && c.formattedValue !== "") {
			var n = parseFloat(c.numAsString);
			u({
				formattedValue: c.formattedValue,
				value: c.numAsString,
				floatValue: isNaN(n) ? void 0 : n
			}, {
				event: void 0,
				source: Wc.props
			});
		}
	}, []), [c, u];
}
function yl(e) {
	return e.replace(/[^0-9]/g, "");
}
function bl(e) {
	return e;
}
function xl(e) {
	var t = e.type;
	t === void 0 && (t = "text");
	var r = e.displayType;
	r === void 0 && (r = "input");
	var i = e.customInput, a = e.renderText, o = e.getInputRef, s = e.format;
	s === void 0 && (s = bl);
	var c = e.removeFormatting;
	c === void 0 && (c = yl);
	var l = e.defaultValue, u = e.valueIsNumericString, d = e.onValueChange, f = e.isAllowed, m = e.onChange;
	m === void 0 && (m = Gc);
	var h = e.onKeyDown;
	h === void 0 && (h = Gc);
	var _ = e.onMouseUp;
	_ === void 0 && (_ = Gc);
	var b = e.onFocus;
	b === void 0 && (b = Gc);
	var x = e.onBlur;
	x === void 0 && (x = Gc);
	var S = e.value, C = e.getCaretBoundary;
	C === void 0 && (C = _l);
	var w = e.isValidInputCharacter;
	w === void 0 && (w = qc);
	var T = e.isCharacterSame, E = Uc(e, [
		"type",
		"displayType",
		"customInput",
		"renderText",
		"getInputRef",
		"format",
		"removeFormatting",
		"defaultValue",
		"valueIsNumericString",
		"onValueChange",
		"isAllowed",
		"onChange",
		"onKeyDown",
		"onMouseUp",
		"onFocus",
		"onBlur",
		"value",
		"getCaretBoundary",
		"isValidInputCharacter",
		"isCharacterSame"
	]), D = vl(S, l, !!u, s, c, d), O = D[0], k = O.formattedValue, ee = O.numAsString, A = D[1], j = v(), M = v({
		formattedValue: k,
		numAsString: ee
	}), N = function(e, t) {
		M.current = {
			formattedValue: e.formattedValue,
			numAsString: e.value
		}, A(e, t);
	}, P = y(!1), te = P[0], ne = P[1], F = v(null), I = v({
		setCaretTimeout: null,
		focusTimeout: null
	});
	p(function() {
		return ne(!0), function() {
			clearTimeout(I.current.setCaretTimeout), clearTimeout(I.current.focusTimeout);
		};
	}, []);
	var re = s, L = function(e, t) {
		var n = parseFloat(t);
		return {
			formattedValue: e,
			value: t,
			floatValue: isNaN(n) ? void 0 : n
		};
	}, R = function(e, t, n) {
		(e.selectionStart !== 0 || e.selectionEnd !== e.value.length) && (sl(e, t), I.current.setCaretTimeout = setTimeout(function() {
			e.value === n && e.selectionStart !== t && sl(e, t);
		}, 0));
	}, z = function(e, t, n) {
		return gl(e, t, C(e), n);
	}, ie = function(e, t, n) {
		var r = C(t), i = hl(t, k, e, n, r, w, T);
		return i = gl(t, i, r), i;
	}, ae = function(e) {
		var t = e.formattedValue;
		t === void 0 && (t = "");
		var n = e.input, r = e.source, i = e.event, a = e.numAsString, o;
		if (n) {
			var s = e.inputValue || n.value, c = dl(n);
			n.value = t, o = ie(s, t, c), o !== void 0 && R(n, o, t);
		}
		t !== k && N(L(t, a), {
			event: i,
			source: r
		});
	};
	p(function() {
		var e = M.current, t = e.formattedValue, n = e.numAsString;
		(k !== t || ee !== n) && N(L(k, ee), {
			event: void 0,
			source: Wc.props
		});
	}, [k, ee]);
	var oe = F.current ? dl(F.current) : void 0;
	(typeof window < "u" ? g : p)(function() {
		var e = F.current;
		if (k !== M.current.formattedValue && e) {
			var t = ie(M.current.formattedValue, k, oe);
			e.value = k, R(e, t, k);
		}
	}, [k]);
	var se = function(e, t, n) {
		var r = t.target, i = j.current ? ll(j.current, r.selectionEnd) : cl(k, e), a = Object.assign(Object.assign({}, i), { lastValue: k }), o = c(e, a), s = re(o);
		if (o = c(s, void 0), f && !f(L(s, o))) {
			var l = t.target, u = ie(e, k, dl(l));
			return l.value = k, R(l, u, k), !1;
		}
		return ae({
			formattedValue: s,
			numAsString: o,
			inputValue: e,
			event: t,
			source: n,
			input: t.target
		}), !0;
	}, ce = function(e, t) {
		t === void 0 && (t = 0), j.current = {
			selectionStart: e.selectionStart,
			selectionEnd: e.selectionEnd + t
		};
	}, le = function(e) {
		var t = e.target.value;
		se(t, e, Wc.event) && m(e), j.current = void 0;
	}, B = function(e) {
		var t = e.target, n = e.key, r = t.selectionStart, i = t.selectionEnd, a = t.value;
		a === void 0 && (a = "");
		var o;
		n === "ArrowLeft" || n === "Backspace" ? o = Math.max(r - 1, 0) : n === "ArrowRight" ? o = Math.min(r + 1, a.length) : n === "Delete" && (o = r);
		var s = 0;
		n === "Delete" && r === i && (s = 1);
		var c = n === "ArrowLeft" || n === "ArrowRight";
		if (o === void 0 || r !== i && !c) {
			h(e), ce(t, s);
			return;
		}
		var l = o;
		c ? (l = z(a, o, n === "ArrowLeft" ? "left" : "right"), l !== o && e.preventDefault()) : n === "Delete" && !w(a[o]) ? l = z(a, o, "right") : n === "Backspace" && !w(a[o]) && (l = z(a, o, "left")), l !== o && R(t, l, a), h(e), ce(t, s);
	}, V = function(e) {
		var t = e.target, n = function() {
			var e = t.selectionStart, n = t.selectionEnd, r = t.value;
			if (r === void 0 && (r = ""), e === n) {
				var i = z(r, e);
				i !== e && R(t, i, r);
			}
		};
		n(), requestAnimationFrame(function() {
			n();
		}), _(e), ce(t);
	}, ue = function(e) {
		e.persist && e.persist();
		var t = e.target, n = e.currentTarget;
		F.current = t, I.current.focusTimeout = setTimeout(function() {
			var r = t.selectionStart, i = t.selectionEnd, a = t.value;
			a === void 0 && (a = "");
			var o = z(a, r);
			o !== r && (r !== 0 || i !== a.length) && R(t, o, a), b(Object.assign(Object.assign({}, e), { currentTarget: n }));
		}, 0);
	}, H = function(e) {
		F.current = null, clearTimeout(I.current.focusTimeout), clearTimeout(I.current.setCaretTimeout), x(e);
	}, de = te && fl() ? "numeric" : void 0, U = Object.assign({ inputMode: de }, E, {
		type: t,
		value: k,
		onChange: le,
		onKeyDown: B,
		onMouseUp: V,
		onFocus: ue,
		onBlur: H
	});
	if (r === "text") return a ? n.createElement(n.Fragment, null, a(k, E) || null) : n.createElement("span", Object.assign({}, E, { ref: o }), k);
	if (i) {
		var fe = i;
		return n.createElement(fe, Object.assign({}, U, { ref: o }));
	}
	return n.createElement("input", Object.assign({}, U, { ref: o }));
}
function Sl(e, t) {
	var n = t.decimalScale, r = t.fixedDecimalScale, i = t.prefix;
	i === void 0 && (i = "");
	var a = t.suffix;
	a === void 0 && (a = "");
	var o = t.allowNegative, s = t.thousandsGroupStyle;
	if (s === void 0 && (s = "thousand"), e === "" || e === "-") return e;
	var c = Cl(t), l = c.thousandSeparator, u = c.decimalSeparator, d = n !== 0 && e.indexOf(".") !== -1 || n && r, f = tl(e, o), p = f.beforeDecimal, m = f.afterDecimal, h = f.addNegation;
	return n !== void 0 && (m = rl(m, n, !!r)), l && (p = $c(p, l, s)), i && (p = i + p), a && (m += a), h && (p = "-" + p), e = p + (d && u || "") + m, e;
}
function Cl(e) {
	var t = e.decimalSeparator;
	t === void 0 && (t = ".");
	var n = e.thousandSeparator, r = e.allowedDecimalSeparators;
	return n === !0 && (n = ","), r ||= [t, "."], {
		decimalSeparator: t,
		thousandSeparator: n,
		allowedDecimalSeparators: r
	};
}
function wl(e, t) {
	e === void 0 && (e = "");
	var n = /* @__PURE__ */ RegExp("(-)"), r = /* @__PURE__ */ RegExp("(-)(.)*(-)"), i = n.test(e), a = r.test(e);
	return e = e.replace(/-/g, ""), i && !a && t && (e = "-" + e), e;
}
function Tl(e, t) {
	return RegExp("(^-)|[0-9]|" + Zc(e), t ? "g" : void 0);
}
function El(e, t, n) {
	return e === "" || !t?.match(/\d/) && !n?.match(/\d/) && typeof e == "string" && !isNaN(Number(e));
}
function Dl(e, t, n) {
	var r;
	t === void 0 && (t = pl(e));
	var i = n.allowNegative, a = n.prefix;
	a === void 0 && (a = "");
	var o = n.suffix;
	o === void 0 && (o = "");
	var s = n.decimalScale, c = t.from, l = t.to, u = l.start, d = l.end, f = Cl(n), p = f.allowedDecimalSeparators, m = f.decimalSeparator, h = e[d] === m;
	if (qc(e) && (e === a || e === o) && t.lastValue === "") return e;
	if (d - u === 1 && p.indexOf(e[u]) !== -1) {
		var g = s === 0 ? "" : m;
		e = e.substring(0, u) + g + e.substring(u + 1, e.length);
	}
	var _ = function(e, t, n) {
		var r = !1, i = !1;
		a.startsWith("-") ? r = !1 : e.startsWith("--") ? (r = !1, i = !0) : o.startsWith("-") && e.length === o.length ? r = !1 : e[0] === "-" && (r = !0);
		var s = +!!r;
		return i && (s = 2), s && (e = e.substring(s), t -= s, n -= s), {
			value: e,
			start: t,
			end: n,
			hasNegation: r
		};
	}, v = _(e, u, d), y = v.hasNegation;
	r = v, e = r.value, u = r.start, d = r.end;
	var b = _(t.lastValue, c.start, c.end), x = b.start, S = b.end, C = b.value, w = e.substring(u, d);
	e.length && C.length && (x > C.length - o.length || S < a.length) && !(w && o.startsWith(w)) && (e = C);
	var T = 0;
	e.startsWith(a) ? T += a.length : u < a.length && (T = u), e = e.substring(T), d -= T;
	var E = e.length, D = e.length - o.length;
	e.endsWith(o) ? E = D : (d > D || d > e.length - o.length) && (E = d), e = e.substring(0, E), e = wl(y ? "-" + e : e, i), e = (e.match(Tl(m, !0)) || []).join("");
	var O = e.indexOf(m);
	e = e.replace(new RegExp(Zc(m), "g"), function(e, t) {
		return t === O ? "." : "";
	});
	var k = tl(e, i), ee = k.beforeDecimal, A = k.afterDecimal, j = k.addNegation;
	return l.end - l.start < c.end - c.start && ee === "" && h && !parseFloat(A) && (e = j ? "-" : ""), e;
}
function Ol(e, t) {
	var n = t.prefix;
	n === void 0 && (n = "");
	var r = t.suffix;
	r === void 0 && (r = "");
	var i = Array.from({ length: e.length + 1 }).map(function() {
		return !0;
	}), a = e[0] === "-";
	i.fill(!1, 0, Math.min(n.length + +!!a, e.length));
	var o = e.length;
	return i.fill(!1, o - r.length + 1, o + 1), i;
}
function kl(e) {
	var t = Cl(e), n = t.thousandSeparator, r = t.decimalSeparator, i = e.prefix;
	i === void 0 && (i = "");
	var a = e.allowNegative;
	if (a === void 0 && (a = !0), n === r) throw Error("\n        Decimal separator can't be same as thousand separator.\n        thousandSeparator: " + n + " (thousandSeparator = {true} is same as thousandSeparator = \",\")\n        decimalSeparator: " + r + " (default value for decimalSeparator is .)\n     ");
	return i.startsWith("-") && a && (console.error("\n      Prefix can't start with '-' when allowNegative is true.\n      prefix: " + i + "\n      allowNegative: " + a + "\n    "), a = !1), Object.assign(Object.assign({}, e), { allowNegative: a });
}
function Al(e) {
	e = kl(e), e.decimalSeparator, e.allowedDecimalSeparators, e.thousandsGroupStyle;
	var t = e.suffix, n = e.allowNegative, r = e.allowLeadingZeros, i = e.onKeyDown;
	i === void 0 && (i = Gc);
	var a = e.onBlur;
	a === void 0 && (a = Gc);
	var o = e.thousandSeparator, s = e.decimalScale, c = e.fixedDecimalScale, l = e.prefix;
	l === void 0 && (l = "");
	var u = e.defaultValue, d = e.value, f = e.valueIsNumericString, p = e.onValueChange, m = Uc(e, [
		"decimalSeparator",
		"allowedDecimalSeparators",
		"thousandsGroupStyle",
		"suffix",
		"allowNegative",
		"allowLeadingZeros",
		"onKeyDown",
		"onBlur",
		"thousandSeparator",
		"decimalScale",
		"fixedDecimalScale",
		"prefix",
		"defaultValue",
		"value",
		"valueIsNumericString",
		"onValueChange"
	]), h = Cl(e), g = h.decimalSeparator, _ = h.allowedDecimalSeparators, v = function(t) {
		return Sl(t, e);
	}, y = function(t, n) {
		return Dl(t, n, e);
	}, b = Jc(d) ? u : d, x = f ?? El(b, l, t);
	Jc(d) ? Jc(u) || (x ||= typeof u == "number") : x ||= typeof d == "number";
	var S = function(e) {
		return Xc(e) ? e : (typeof e == "number" && (e = al(e)), x && typeof s == "number" ? ol(e, s, !!c) : e);
	}, C = vl(S(d), S(u), !!x, v, y, p), w = C[0], T = w.numAsString, E = w.formattedValue, D = C[1];
	return Object.assign(Object.assign({}, m), {
		value: E,
		valueIsNumericString: !1,
		isValidInputCharacter: function(e) {
			return e === g || qc(e);
		},
		isCharacterSame: function(e) {
			var t = e.currentValue, n = e.lastValue, r = e.formattedValue, i = e.currentValueIndex, a = e.formattedValueIndex, o = t[i], u = r[a], f = cl(n, t).to, p = function(e) {
				return y(e).indexOf(".") + l.length;
			};
			return d === 0 && c && s && t[f.start] === g && p(t) < i && p(r) > a ? !1 : i >= f.start && i < f.end && _ && _.includes(o) && u === g ? !0 : o === u;
		},
		onValueChange: D,
		format: v,
		removeFormatting: y,
		getCaretBoundary: function(t) {
			return Ol(t, e);
		},
		onKeyDown: function(e) {
			var t = e.target, r = e.key, a = t.selectionStart, u = t.selectionEnd, d = t.value;
			if (d === void 0 && (d = ""), (r === "Backspace" || r === "Delete") && u < l.length && d !== "-") {
				e.preventDefault();
				return;
			}
			if (a !== u) {
				i(e);
				return;
			}
			r === "Backspace" && d[0] === "-" && a === l.length + 1 && n && sl(t, 1), s && c && (r === "Backspace" && d[a - 1] === g ? (sl(t, a - 1), e.preventDefault()) : r === "Delete" && d[a] === g && e.preventDefault()), _?.includes(r) && d[a] === g && sl(t, a + 1);
			var f = o === !0 ? "," : o;
			r === "Backspace" && d[a - 1] === f && sl(t, a - 1), r === "Delete" && d[a] === f && sl(t, a + 1), i(e);
		},
		onBlur: function(t) {
			var n = T;
			n.match(/\d/g) || (n = ""), r || (n = nl(n)), c && s && (n = ol(n, s, c)), n !== T && D({
				formattedValue: Sl(n, e),
				value: n,
				floatValue: parseFloat(n)
			}, {
				event: t,
				source: Wc.event
			}), a(t);
		}
	});
}
function jl(e) {
	var t = Al(e);
	return n.createElement(xl, Object.assign({}, t));
}
//#endregion
//#region node_modules/@mantine/core/esm/components/NumberInput/NumberInputChevron.mjs
function Ml({ direction: e, style: t, ...n }) {
	return /* @__PURE__ */ T("svg", {
		style: {
			width: "var(--ni-chevron-size)",
			height: "var(--ni-chevron-size)",
			transform: e === "up" ? "rotate(180deg)" : void 0,
			...t
		},
		viewBox: "0 0 15 15",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		...n,
		children: /* @__PURE__ */ T("path", {
			d: "M3.13523 6.15803C3.3241 5.95657 3.64052 5.94637 3.84197 6.13523L7.5 9.56464L11.158 6.13523C11.3595 5.94637 11.6759 5.95657 11.8648 6.15803C12.0536 6.35949 12.0434 6.67591 11.842 6.86477L7.84197 10.6148C7.64964 10.7951 7.35036 10.7951 7.15803 10.6148L3.15803 6.86477C2.95657 6.67591 2.94637 6.35949 3.13523 6.15803Z",
			fill: "currentColor",
			fillRule: "evenodd",
			clipRule: "evenodd"
		})
	});
}
//#endregion
//#region node_modules/@mantine/core/esm/components/NumberInput/NumberInput.module.mjs
var Nl = {
	root: "m_e2f5cd4e",
	controls: "m_95e17d22",
	control: "m_80b4b171"
}, Pl = /^(0\.0*|-0(\.0*)?)$/, Fl = /^-?0\d+(\.\d+)?\.?$/, Il = /\.\d*0$/, Ll = /^-?\d+\.$/;
function Rl(e) {
	return typeof e == "string" && e !== "" && !Number.isNaN(Number(e));
}
function zl(e) {
	return typeof e == "bigint";
}
function Bl(e) {
	return typeof e == "number" ? e < 2 ** 53 - 1 : e === "" || Rl(e) && Number(e) < 2 ** 53 - 1;
}
function Vl(e, t) {
	return e === "" || e === "-" || !t && e.startsWith("-") ? !1 : /^-?\d+$/.test(e);
}
function Hl(e, t) {
	return typeof e == "bigint" || e === "" || Vl(e, t);
}
function Ul(e) {
	if (!/^-?\d+$/.test(e)) return null;
	try {
		return BigInt(e);
	} catch {
		return null;
	}
}
function Wl(e) {
	if (typeof e == "bigint") return e;
	if (typeof e == "number" && Number.isFinite(e) && Number.isInteger(e)) return BigInt(e);
}
function Gl(e, t, n) {
	return t !== void 0 && e < t ? t : n !== void 0 && e > n ? n : e;
}
function Kl(e) {
	return e.toString().replace(".", "").length;
}
function ql(e, t) {
	return (typeof e == "number" ? e < 2 ** 53 - 1 : !Number.isNaN(Number(e))) && !Number.isNaN(e) && Kl(t) < 14 && t !== "";
}
function Jl(e, t, n) {
	return e === void 0 || (t === void 0 || e >= t) && (n === void 0 || e <= n);
}
var Yl = {
	size: "sm",
	step: 1,
	clampBehavior: "blur",
	allowDecimal: !0,
	allowNegative: !0,
	withKeyboardEvents: !0,
	allowLeadingZeros: !0,
	trimLeadingZeroesOnBlur: !0,
	startValue: 0,
	allowedDecimalSeparators: [".", ","]
}, Xl = G((e, { size: t }) => ({ controls: { "--ni-chevron-size": B(t, "ni-chevron-size") } }));
function Zl(e, t, n) {
	let r = e.toString(), i = Ll.test(r), a = r.replace(/^0+(?=\d)/, ""), o = parseFloat(a);
	if (Number.isNaN(o)) return a;
	if (o > 2 ** 53 - 1) return t === void 0 ? a : t;
	let s = he(o, n, t);
	return i ? `${s.toString().replace(/^0+(?=\d)/, "")}.` : s;
}
function Ql(e, t) {
	if (e === "" || e === "-") return e;
	let n = Ul(e);
	return n === null ? e : t.clampBehavior === "blur" ? Gl(n, t.min, t.max) : n;
}
var $l = cr((e) => {
	let t = K([
		"Input",
		"InputWrapper",
		"NumberInput"
	], Yl, e), { className: n, classNames: r, styles: i, unstyled: a, vars: o, onChange: s, onValueChange: c, value: l, defaultValue: u, max: d, min: f, step: p, hideControls: m, rightSection: h, isAllowed: g, clampBehavior: _, onBlur: y, allowDecimal: b, decimalScale: x, onKeyDown: S, onKeyDownCapture: C, handlersRef: w, startValue: D, disabled: O, rightSectionPointerEvents: k, allowNegative: ee, readOnly: A, size: j, rightSectionWidth: M, stepHoldInterval: N, stepHoldDelay: P, allowLeadingZeros: te, withKeyboardEvents: ne, trimLeadingZeroesOnBlur: F, allowedDecimalSeparators: I, selectAllOnFocus: re, onMinReached: L, onMaxReached: R, onFocus: z, attributes: ie, ref: ae, ...oe } = t, se = ee ?? !0, ce = te ?? !0, B = q({
		name: "NumberInput",
		classes: Nl,
		props: t,
		classNames: r,
		styles: i,
		unstyled: a,
		attributes: ie,
		vars: o,
		varsResolver: Xl
	}), { resolvedClassNames: V, resolvedStyles: ue } = mn({
		classNames: r,
		styles: i,
		props: t
	}), H = v(zl(l) || zl(u) ? "bigint" : "number");
	zl(l) ? H.current = "bigint" : typeof l == "number" && (H.current = "number");
	let de = H.current === "bigint", [U, fe] = ze({
		value: l,
		defaultValue: u,
		finalValue: "",
		onChange: s
	}), pe = P !== void 0 && N !== void 0, me = v(null), ge = v(null), _e = v(0), ve = typeof f == "number" ? f : void 0, ye = typeof d == "number" ? d : void 0, be = typeof p == "number" ? p : Yl.step, xe = typeof D == "number" ? D : Yl.startValue, Se = Wl(f), W = Wl(d), Ce = Wl(p) ?? BigInt(1), we = Wl(D) ?? BigInt(0), Te = (e) => !Vl(e, se) || ce && Fl.test(e) ? e : Ul(e) ?? e, Ee = (e) => {
		let t = Number(e);
		return Number.isSafeInteger(t) ? t : void 0;
	}, De = (e, t) => {
		t.source === "event" && fe(de ? Te(e.value) : ql(e.floatValue, e.value) && !Pl.test(e.value) && !(ce && Fl.test(e.value)) && !Il.test(e.value) && !Ll.test(e.value) ? e.floatValue : e.value), c?.(e, t);
	}, Oe = (e) => {
		let t = String(e).match(/(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/);
		return t ? Math.max(0, (t[1] ? t[1].length : 0) - (t[2] ? +t[2] : 0)) : 0;
	}, ke = (e) => {
		me.current && e !== void 0 && me.current.setSelectionRange(e, e);
	}, Ae = v(le);
	Ae.current = () => {
		if (de) {
			if (!Hl(U, se)) return;
			let e, t = U;
			if (typeof t == "bigint") {
				let n = t + Ce;
				W !== void 0 && n > W && R?.(), e = W !== void 0 && n > W ? W : n;
			} else if (typeof t == "string" && t !== "") {
				let n = Ul(t);
				if (n === null) return;
				let r = n + Ce;
				W !== void 0 && r > W && R?.(), e = W !== void 0 && r > W ? W : r;
			} else e = Gl(we, Se, W);
			let n = e.toString();
			fe(e), c?.({
				floatValue: Ee(e),
				formattedValue: n,
				value: n
			}, { source: "increment" }), setTimeout(() => ke(me.current?.value.length), 0);
			return;
		}
		if (!Bl(U)) return;
		let e, t = Oe(U), n = Oe(be), r = Math.max(t, n), i = 10 ** r;
		if (!Rl(U) && (typeof U != "number" || Number.isNaN(U))) e = he(xe, ve, ye);
		else if (ye !== void 0) {
			let t = (Math.round(Number(U) * i) + Math.round(be * i)) / i;
			t > ye && R?.(), e = t <= ye ? t : ye;
		} else e = (Math.round(Number(U) * i) + Math.round(be * i)) / i;
		let a = e.toFixed(r);
		fe(parseFloat(a)), c?.({
			floatValue: parseFloat(a),
			formattedValue: a,
			value: a
		}, { source: "increment" }), setTimeout(() => ke(me.current?.value.length), 0);
	};
	let je = v(le);
	je.current = () => {
		if (de) {
			if (!Hl(U, se)) return;
			let e, t = Se === void 0 ? se ? void 0 : BigInt(0) : Se, n = U;
			if (typeof n == "bigint") {
				let r = n - Ce;
				t !== void 0 && r < t && L?.(), e = t !== void 0 && r < t ? t : r;
			} else if (typeof n == "string" && n !== "") {
				let r = Ul(n);
				if (r === null) return;
				let i = r - Ce;
				t !== void 0 && i < t && L?.(), e = t !== void 0 && i < t ? t : i;
			} else e = Gl(we, t, W);
			let r = e.toString();
			fe(e), c?.({
				floatValue: Ee(e),
				formattedValue: r,
				value: r
			}, { source: "decrement" }), setTimeout(() => ke(me.current?.value.length), 0);
			return;
		}
		if (!Bl(U)) return;
		let e, t = ve === void 0 ? se ? -(2 ** 53 - 1) : 0 : ve, n = Oe(U), r = Oe(be), i = Math.max(n, r), a = 10 ** i;
		if (!Rl(U) && typeof U != "number" || Number.isNaN(U)) e = he(xe, t, ye);
		else {
			let n = (Math.round(Number(U) * a) - Math.round(be * a)) / a;
			t !== void 0 && n < t && L?.(), e = t !== void 0 && n < t ? t : n;
		}
		let o = e.toFixed(i);
		fe(parseFloat(o)), c?.({
			floatValue: parseFloat(o),
			formattedValue: o,
			value: o
		}, { source: "decrement" }), setTimeout(() => ke(me.current?.value.length), 0);
	};
	let Me = (e) => {
		let t = e.clipboardData.getData("text"), n = oe.decimalSeparator || ".", r = (I || [".", ","]).filter((e) => e !== n);
		if (r.some((e) => t.includes(e))) {
			e.preventDefault();
			let i = t;
			r.forEach((e) => {
				i = i.split(e).join(n);
			});
			let a = me.current;
			if (a) {
				let e = a.selectionStart ?? 0, t = a.selectionEnd ?? 0, n = a.value, r = n.substring(0, e) + i + n.substring(t);
				(Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set)?.call(a, r), a.dispatchEvent(new Event("change", { bubbles: !0 }));
				let o = e + i.length;
				setTimeout(() => ke(o), 0);
			}
		}
		oe.onPaste?.(e);
	}, Ne = (e) => {
		S?.(e), !(A || !ne) && (e.key === "ArrowUp" && (e.preventDefault(), Ae.current?.()), e.key === "ArrowDown" && (e.preventDefault(), je.current?.()));
	}, Pe = (e) => {
		if (C?.(e), e.key === "Backspace") {
			let t = me.current;
			t && t.selectionStart === 0 && t.selectionStart === t.selectionEnd && (e.preventDefault(), window.setTimeout(() => ke(0), 0));
		}
	}, Fe = (e) => {
		re && window.setTimeout(() => me.current?.select(), 0), z?.(e);
	}, Le = (e) => {
		let t = U;
		de ? (_ === "blur" && typeof t == "bigint" && (t = Gl(t, Se, W)), F && typeof t == "string" && (t = Ql(t, {
			min: Se,
			max: W,
			clampBehavior: _
		}))) : (_ === "blur" && typeof t == "number" && (t = he(t, ve, ye)), F && typeof t == "string" && Oe(t) < 15 && (t = Zl(t, ye, ve))), U !== t && fe(t), y?.(e);
	};
	Ie(w, {
		increment: Ae.current,
		decrement: je.current
	});
	let Be = (e) => {
		e ? Ae.current?.() : je.current?.(), _e.current += 1;
	}, Ve = (e) => {
		if (Be(e), pe) {
			let t = typeof N == "number" ? N : N(_e.current);
			ge.current = window.setTimeout(() => Ve(e), t);
		}
	}, He = (e, t) => {
		e.preventDefault(), me.current?.focus(), Be(t), pe && (ge.current = window.setTimeout(() => Ve(t), P));
	}, Ue = () => {
		ge.current && window.clearTimeout(ge.current), ge.current = null, _e.current = 0;
	}, We = /* @__PURE__ */ E("div", {
		...B("controls"),
		children: [/* @__PURE__ */ T(ui, {
			...B("control"),
			tabIndex: -1,
			"aria-hidden": !0,
			disabled: O || typeof U == "number" && ye !== void 0 && U >= ye || typeof U == "bigint" && W !== void 0 && U >= W,
			mod: { direction: "up" },
			onMouseDown: (e) => e.preventDefault(),
			onPointerDown: (e) => {
				He(e, !0);
			},
			onPointerUp: Ue,
			onPointerLeave: Ue,
			children: /* @__PURE__ */ T(Ml, { direction: "up" })
		}), /* @__PURE__ */ T(ui, {
			...B("control"),
			tabIndex: -1,
			"aria-hidden": !0,
			disabled: O || typeof U == "number" && ve !== void 0 && U <= ve || typeof U == "bigint" && Se !== void 0 && U <= Se,
			mod: { direction: "down" },
			onMouseDown: (e) => e.preventDefault(),
			onPointerDown: (e) => {
				He(e, !1);
			},
			onPointerUp: Ue,
			onPointerLeave: Ue,
			children: /* @__PURE__ */ T(Ml, { direction: "down" })
		})]
	});
	return /* @__PURE__ */ T(ts, {
		component: jl,
		allowNegative: ee,
		className: Xe(Nl.root, n),
		size: j,
		...oe,
		inputMode: de ? "numeric" : "decimal",
		readOnly: A,
		disabled: O,
		value: typeof U == "bigint" ? U.toString() : U,
		getInputRef: Re(ae, me),
		onValueChange: De,
		rightSection: m || A || !(de ? Hl(U, se) : Bl(U)) ? h : h || We,
		classNames: V,
		styles: ue,
		unstyled: a,
		__staticSelector: "NumberInput",
		decimalScale: de ? 0 : b ? x : 0,
		onPaste: Me,
		onFocus: Fe,
		onKeyDown: Ne,
		onKeyDownCapture: Pe,
		rightSectionPointerEvents: k ?? (O ? "none" : void 0),
		rightSectionWidth: M ?? `var(--ni-right-section-width-${j || "sm"})`,
		allowLeadingZeros: te,
		allowedDecimalSeparators: I,
		onBlur: Le,
		attributes: ie,
		isAllowed: (e) => {
			if (!(!g || g(e))) return !1;
			if (_ !== "strict") return !0;
			if (!de) return Jl(e.floatValue, ve, ye);
			if (e.value === "" || e.value === "-") return !0;
			let t = Ul(e.value);
			return t === null || (Se === void 0 || t >= Se) && (W === void 0 || t <= W);
		}
	});
});
$l.classes = {
	...ts.classes,
	...Nl
}, $l.varsResolver = Xl, $l.displayName = "@mantine/core/NumberInput";
//#endregion
//#region node_modules/@mantine/core/esm/components/SimpleGrid/SimpleGridVariables.mjs
function eu(e) {
	if (e !== void 0) return typeof e == "number" ? P(e) : e;
}
function tu({ spacing: e, verticalSpacing: t, cols: n, minColWidth: r, autoRows: i, selector: a }) {
	let o = Zt(), s = t === void 0 ? e : t, c = r !== void 0, l = ne({
		"--sg-spacing-x": V(me(e)),
		"--sg-spacing-y": V(me(s)),
		"--sg-auto-rows": i,
		...c ? { "--sg-min-col-width": eu(r) } : { "--sg-cols": me(n)?.toString() }
	}), u = D(o.breakpoints).reduce((t, r) => (t[r] || (t[r] = {}), typeof e == "object" && e[r] !== void 0 && (t[r]["--sg-spacing-x"] = V(e[r])), typeof s == "object" && s[r] !== void 0 && (t[r]["--sg-spacing-y"] = V(s[r])), !c && typeof n == "object" && n[r] !== void 0 && (t[r]["--sg-cols"] = n[r]), t), {}), d = pe(D(u), o.breakpoints).filter((e) => D(u[e.value]).length > 0).map((e) => ({
		query: `(min-width: ${o.breakpoints[e.value]})`,
		styles: u[e.value]
	}));
	return /* @__PURE__ */ T(jn, {
		styles: l,
		media: d,
		selector: a
	});
}
function nu(e) {
	return typeof e == "object" && e ? D(e) : [];
}
function ru(e) {
	return e.sort((e, t) => j(e) - j(t));
}
function iu({ spacing: e, verticalSpacing: t, cols: n, minColWidth: r }) {
	return ru(Array.from(/* @__PURE__ */ new Set([
		...nu(e),
		...nu(t),
		...r === void 0 ? nu(n) : []
	])));
}
function au({ spacing: e, verticalSpacing: t, cols: n, minColWidth: r, autoRows: i, selector: a }) {
	let o = t === void 0 ? e : t, s = r !== void 0, c = ne({
		"--sg-spacing-x": V(me(e)),
		"--sg-spacing-y": V(me(o)),
		"--sg-auto-rows": i,
		...s ? { "--sg-min-col-width": eu(r) } : { "--sg-cols": me(n)?.toString() }
	}), l = iu({
		spacing: e,
		verticalSpacing: t,
		cols: n,
		minColWidth: r
	}), u = l.reduce((t, r) => (t[r] || (t[r] = {}), typeof e == "object" && e[r] !== void 0 && (t[r]["--sg-spacing-x"] = V(e[r])), typeof o == "object" && o[r] !== void 0 && (t[r]["--sg-spacing-y"] = V(o[r])), !s && typeof n == "object" && n[r] !== void 0 && (t[r]["--sg-cols"] = n[r]), t), {}), d = l.map((e) => ({
		query: `simple-grid (min-width: ${e})`,
		styles: u[e]
	}));
	return /* @__PURE__ */ T(jn, {
		styles: c,
		container: d,
		selector: a
	});
}
//#endregion
//#region node_modules/@mantine/core/esm/components/SimpleGrid/SimpleGrid.module.mjs
var ou = {
	container: "m_925c2d2c",
	root: "m_2415a157"
}, su = {
	cols: 1,
	spacing: "md",
	type: "media"
}, cu = J((e) => {
	let t = K("SimpleGrid", su, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, cols: c, verticalSpacing: l, spacing: u, type: d, minColWidth: f, autoFlow: p, autoRows: m, attributes: h, ...g } = t, _ = q({
		name: "SimpleGrid",
		classes: ou,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: h,
		vars: s
	}), v = rr(), y = f === void 0 ? void 0 : p || "auto-fill";
	return d === "container" ? /* @__PURE__ */ E(w, { children: [/* @__PURE__ */ T(au, {
		...t,
		selector: `.${v}`
	}), /* @__PURE__ */ T("div", {
		..._("container"),
		children: /* @__PURE__ */ T(Y, {
			..._("root", { className: v }),
			...g,
			"data-auto-cols": y
		})
	})] }) : /* @__PURE__ */ E(w, { children: [/* @__PURE__ */ T(tu, {
		...t,
		selector: `.${v}`
	}), /* @__PURE__ */ T(Y, {
		..._("root", { className: v }),
		...g,
		"data-auto-cols": y
	})] });
});
cu.classes = ou, cu.displayName = "@mantine/core/SimpleGrid";
//#endregion
//#region node_modules/@mantine/core/esm/components/Stack/Stack.module.mjs
var lu = { root: "m_6d731127" }, uu = {
	gap: "md",
	align: "stretch",
	justify: "flex-start"
}, du = G((e, { gap: t, align: n, justify: r }) => ({ root: {
	"--stack-gap": V(t),
	"--stack-align": n,
	"--stack-justify": r
} })), Q = J((e) => {
	let t = K("Stack", uu, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, align: c, justify: l, gap: u, variant: d, attributes: f, ...p } = t, m = q({
		name: "Stack",
		props: t,
		classes: lu,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: f,
		vars: s,
		varsResolver: du
	});
	return /* @__PURE__ */ T(Y, {
		...m("root"),
		variant: d,
		...p
	});
});
Q.classes = lu, Q.varsResolver = du, Q.displayName = "@mantine/core/Stack";
//#endregion
//#region node_modules/@mantine/core/esm/components/Table/Table.context.mjs
var [fu, pu] = re("Table component was not found in the tree"), mu = {
	table: "m_b23fa0ef",
	th: "m_4e7aa4f3",
	tr: "m_4e7aa4fd",
	td: "m_4e7aa4ef",
	tbody: "m_b2404537",
	thead: "m_b242d975",
	caption: "m_9e5a3ac7",
	scrollContainer: "m_a100c15",
	scrollContainerInner: "m_62259741"
};
//#endregion
//#region node_modules/@mantine/core/esm/components/Table/Table.components.mjs
function hu(e, t) {
	if (!t) return;
	let n = {};
	return t.columnBorder && e.withColumnBorders && (n["data-with-column-border"] = !0), t.rowBorder && e.withRowBorders && (n["data-with-row-border"] = !0), t.striped && e.striped && (n["data-striped"] = e.striped), t.highlightOnHover && e.highlightOnHover && (n["data-hover"] = !0), t.captionSide && e.captionSide && (n["data-side"] = e.captionSide), t.stickyHeader && e.stickyHeader && (n["data-sticky"] = !0), n;
}
function gu(e, t) {
	let n = `Table${e.charAt(0).toUpperCase()}${e.slice(1)}`, r = J((r) => {
		let i = K(n, {}, r), { classNames: a, className: o, style: s, styles: c, ...l } = i, u = pu();
		return /* @__PURE__ */ T(Y, {
			component: e,
			...hu(u, t),
			...u.getStyles(e, {
				className: o,
				classNames: a,
				style: s,
				styles: c,
				props: i
			}),
			...l
		});
	});
	return r.displayName = `@mantine/core/${n}`, r.classes = mu, r;
}
var _u = gu("th", { columnBorder: !0 }), vu = gu("td", { columnBorder: !0 }), yu = gu("tr", {
	rowBorder: !0,
	striped: !0,
	highlightOnHover: !0
}), bu = gu("thead", { stickyHeader: !0 }), xu = gu("tbody"), Su = gu("tfoot"), Cu = gu("caption", { captionSide: !0 }), wu = { type: "scrollarea" }, Tu = G((e, { minWidth: t, maxHeight: n, type: r }) => ({ scrollContainer: {
	"--table-min-width": P(t),
	"--table-max-height": P(n),
	"--table-overflow": r === "native" ? "auto" : void 0
} })), Eu = J((e) => {
	let t = K("TableScrollContainer", wu, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, children: c, minWidth: l, maxHeight: u, type: d, scrollAreaProps: f, attributes: p, ...m } = t, h = q({
		name: "TableScrollContainer",
		classes: mu,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: p,
		vars: s,
		varsResolver: Tu,
		rootSelector: "scrollContainer"
	});
	return /* @__PURE__ */ T(Y, {
		component: d === "scrollarea" ? oi : "div",
		...d === "scrollarea" ? u ? {
			offsetScrollbars: "xy",
			...f
		} : {
			offsetScrollbars: "x",
			...f
		} : {},
		...h("scrollContainer"),
		...m,
		children: /* @__PURE__ */ T("div", {
			...h("scrollContainerInner"),
			children: c
		})
	});
});
Eu.classes = mu, Eu.varsResolver = Tu, Eu.displayName = "@mantine/core/TableScrollContainer";
//#endregion
//#region node_modules/@mantine/core/esm/components/Table/TableDataRenderer.mjs
function Du({ data: e }) {
	return /* @__PURE__ */ E(w, { children: [
		e.caption && /* @__PURE__ */ T(Cu, { children: e.caption }),
		e.head && /* @__PURE__ */ T(bu, { children: /* @__PURE__ */ T(yu, { children: e.head.map((e, t) => /* @__PURE__ */ T(_u, { children: e }, t)) }) }),
		e.body && /* @__PURE__ */ T(xu, { children: e.body.map((e, t) => /* @__PURE__ */ T(yu, { children: e.map((e, t) => /* @__PURE__ */ T(vu, { children: e }, t)) }, t)) }),
		e.foot && /* @__PURE__ */ T(Su, { children: /* @__PURE__ */ T(yu, { children: e.foot.map((e, t) => /* @__PURE__ */ T(_u, { children: e }, t)) }) })
	] });
}
Du.displayName = "@mantine/core/TableDataRenderer";
//#endregion
//#region node_modules/@mantine/core/esm/components/Table/Table.mjs
var Ou = {
	withRowBorders: !0,
	verticalSpacing: 7
}, ku = G((e, { layout: t, captionSide: n, horizontalSpacing: r, verticalSpacing: i, borderColor: a, stripedColor: o, highlightOnHoverColor: s, striped: c, highlightOnHover: l, stickyHeaderOffset: u, stickyHeader: d }) => ({ table: {
	"--table-layout": t,
	"--table-caption-side": n,
	"--table-horizontal-spacing": V(r),
	"--table-vertical-spacing": V(i),
	"--table-border-color": a ? mt(a, e) : void 0,
	"--table-striped-color": c && o ? mt(o, e) : void 0,
	"--table-highlight-on-hover-color": l && s ? mt(s, e) : void 0,
	"--table-sticky-header-offset": d ? P(u) : void 0
} })), $ = J((e) => {
	let t = K("Table", Ou, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, horizontalSpacing: c, verticalSpacing: l, captionSide: u, stripedColor: d, highlightOnHoverColor: f, striped: p, highlightOnHover: m, withColumnBorders: h, withRowBorders: g, withTableBorder: _, borderColor: v, layout: y, data: b, children: x, stickyHeader: S, stickyHeaderOffset: C, mod: w, tabularNums: E, attributes: D, ...O } = t, k = q({
		name: "Table",
		props: t,
		className: r,
		style: i,
		classes: mu,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: D,
		rootSelector: "table",
		vars: s,
		varsResolver: ku
	});
	return /* @__PURE__ */ T(fu, {
		value: {
			getStyles: k,
			stickyHeader: S,
			striped: p === !0 ? "odd" : p || void 0,
			highlightOnHover: m,
			withColumnBorders: h,
			withRowBorders: g,
			captionSide: u || "bottom"
		},
		children: /* @__PURE__ */ T(Y, {
			component: "table",
			mod: [{
				withTableBorder: _,
				tabularNums: E
			}, w],
			...k("table"),
			...O,
			children: x || !!b && /* @__PURE__ */ T(Du, { data: b })
		})
	});
});
$.classes = mu, $.varsResolver = ku, $.displayName = "@mantine/core/Table", $.Td = vu, $.Th = _u, $.Tr = yu, $.Thead = bu, $.Tbody = xu, $.Tfoot = Su, $.Caption = Cu, $.ScrollContainer = Eu, $.DataRenderer = Du;
//#endregion
//#region node_modules/@mantine/core/esm/components/TextInput/TextInput.mjs
var Au = J((e) => {
	let t = K([
		"Input",
		"InputWrapper",
		"TextInput"
	], null, e);
	return /* @__PURE__ */ T(ts, {
		component: "input",
		...t,
		__staticSelector: "TextInput"
	});
});
Au.classes = ts.classes, Au.displayName = "@mantine/core/TextInput";
//#endregion
//#region node_modules/@mantine/core/esm/components/Title/get-title-size.mjs
var ju = [
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6"
], Mu = [
	"xs",
	"sm",
	"md",
	"lg",
	"xl"
];
function Nu(e, t) {
	let n = t === void 0 ? `h${e}` : t;
	return ju.includes(n) ? {
		fontSize: `var(--mantine-${n}-font-size)`,
		fontWeight: `var(--mantine-${n}-font-weight)`,
		lineHeight: `var(--mantine-${n}-line-height)`
	} : Mu.includes(n) ? {
		fontSize: `var(--mantine-font-size-${n})`,
		fontWeight: `var(--mantine-h${e}-font-weight)`,
		lineHeight: `var(--mantine-h${e}-line-height)`
	} : {
		fontSize: P(n),
		fontWeight: `var(--mantine-h${e}-font-weight)`,
		lineHeight: `var(--mantine-h${e}-line-height)`
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Title/Title.module.mjs
var Pu = { root: "m_8a5d1357" }, Fu = { order: 1 }, Iu = G((e, { order: t, size: n, lineClamp: r, textWrap: i }) => {
	let a = Nu(t || 1, n);
	return { root: {
		"--title-fw": a.fontWeight,
		"--title-lh": a.lineHeight,
		"--title-fz": a.fontSize,
		"--title-line-clamp": typeof r == "number" ? r.toString() : void 0,
		"--title-text-wrap": i
	} };
}), Lu = J((e) => {
	let t = K("Title", Fu, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, order: s, vars: c, size: l, variant: u, lineClamp: d, textWrap: f, mod: p, attributes: m, ...h } = t, g = q({
		name: "Title",
		props: t,
		classes: Pu,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: m,
		vars: c,
		varsResolver: Iu
	});
	return [
		1,
		2,
		3,
		4,
		5,
		6
	].includes(s) ? /* @__PURE__ */ T(Y, {
		...g("root"),
		component: `h${s}`,
		variant: u,
		mod: [{
			order: s,
			lineClamp: typeof d == "number"
		}, p],
		size: l,
		...h
	}) : null;
});
Lu.classes = Pu, Lu.varsResolver = Iu, Lu.displayName = "@mantine/core/Title";
//#endregion
//#region src/api/sourceNames.ts
var Ru = {
	human: "Your override",
	ml: "Goldilocks-ML prediction",
	llm: "LLM suggestion",
	heuristic: "Heuristic default"
}, zu = "linear-gradient(90deg, #ff4a22, #7a64ff, #005de4, #08c2d3)";
function Bu({ source: e }) {
	return e === "ml" ? /* @__PURE__ */ T(Y, {
		component: "span",
		fw: 700,
		style: {
			backgroundImage: zu,
			backgroundClip: "text",
			WebkitBackgroundClip: "text",
			color: "transparent"
		},
		children: Ru.ml
	}) : /* @__PURE__ */ T(w, { children: Ru[e] });
}
//#endregion
//#region src/review/warnings.ts
function Vu(e) {
	return typeof e == "object" && !!e && "code" in e && "level" in e && "category" in e && "message" in e && typeof e.message == "string";
}
var Hu = {
	info: "blue.8",
	warning: "yellow",
	error: "red"
}, Uu = s(null);
//#endregion
//#region src/workspace/useWorkspace.ts
function Wu() {
	let e = f(Uu);
	if (e === null) throw Error("useWorkspace must be rendered inside WorkspaceProvider");
	return e;
}
function Gu() {
	let e = Wu(), t = d((t) => e.subscribe(t), [e]), n = d(() => e.getSnapshot(), [e]);
	return b(t, n, n);
}
//#endregion
//#region src/controls/overrideFieldMeta.tsx
function Ku(e) {
	let t = e.key.replace(/_/g, " ");
	return e.unit ? `${t} · ${e.unit}` : t;
}
function qu(e) {
	return typeof e == "object" && e ? JSON.stringify(e) : String(e);
}
function Ju(e) {
	return e.default === void 0 ? "Automatic" : `Automatic (${qu(e.default)})`;
}
function Yu(e, t, n) {
	return t ? /* @__PURE__ */ E(w, { children: [
		e,
		" · ",
		/* @__PURE__ */ T(Bu, { source: "human" })
	] }) : n ? /* @__PURE__ */ E(w, { children: [
		e,
		" · ",
		/* @__PURE__ */ T(Bu, { source: n })
	] }) : e;
}
//#endregion
//#region src/controls/OverrideControl.tsx
function Xu({ meta: e, value: t, resolvedValue: n, source: r, disabled: i, onChange: a }) {
	let o = t !== void 0, s = Ku(e), c = Yu(e.description, o, r), l = o ? t : n, u = o ? /* @__PURE__ */ T($i, {
		"aria-label": `Reset ${s} to automatic`,
		size: "sm",
		disabled: i,
		onMouseDown: (e) => {
			e.preventDefault();
		},
		onClick: () => {
			a(void 0);
		}
	}) : void 0;
	return e.type === "boolean" ? /* @__PURE__ */ T(Zu, {
		label: s,
		description: c,
		disabled: i,
		clearButton: u,
		value: l,
		onChange: a
	}) : e.enum && e.enum.length > 0 ? /* @__PURE__ */ T(Qu, {
		label: s,
		description: c,
		disabled: i,
		clearButton: u,
		options: e.enum,
		value: l,
		onChange: a
	}) : e.type === "integer" || e.type === "number" ? /* @__PURE__ */ T($l, {
		label: s,
		description: c,
		disabled: i,
		placeholder: Ju(e),
		value: typeof l == "number" ? l : "",
		onChange: (e) => {
			if (e === "") {
				a(void 0);
				return;
			}
			let t = Number(e);
			Number.isFinite(t) && a(t);
		}
	}) : e.type === "string" ? /* @__PURE__ */ T(Au, {
		label: s,
		description: c,
		disabled: i,
		placeholder: Ju(e),
		value: typeof l == "string" ? l : "",
		onChange: (e) => {
			let t = e.currentTarget.value;
			a(t === "" ? void 0 : t);
		}
	}) : /* @__PURE__ */ T($u, {
		label: s,
		description: e.description,
		disabled: i,
		value: t,
		onChange: a
	});
}
function Zu({ label: e, description: t, disabled: n, clearButton: r, value: i, onChange: a }) {
	let o = typeof i == "boolean" ? qu(i) : "";
	return /* @__PURE__ */ T(Hc, {
		label: e,
		description: t,
		disabled: n,
		rightSection: r,
		value: o,
		data: [
			...o === "" ? [{
				value: "",
				label: "—",
				disabled: !0
			}] : [],
			{
				value: "true",
				label: "On"
			},
			{
				value: "false",
				label: "Off"
			}
		],
		onChange: (e) => {
			a(e.currentTarget.value === "true");
		}
	});
}
function Qu({ label: e, description: t, disabled: n, clearButton: r, options: i, value: a, onChange: o }) {
	let s = typeof a == "string" ? a : "", c = s === "" || !i.includes(s);
	return /* @__PURE__ */ T(Hc, {
		label: e,
		description: t,
		disabled: n,
		rightSection: r,
		value: s,
		data: [...c ? [{
			value: "",
			label: "—",
			disabled: !0
		}] : [], ...i.map((e) => ({
			value: e,
			label: e
		}))],
		onChange: (e) => {
			o(e.currentTarget.value);
		}
	});
}
function $u({ label: e, description: t, disabled: n, value: r, onChange: i }) {
	let [a, o] = y(r), [s, c] = y(r === void 0 ? "" : JSON.stringify(r)), [l, u] = y(null);
	return r !== a && (o(r), c(r === void 0 ? "" : JSON.stringify(r)), u(null)), /* @__PURE__ */ E(Q, {
		gap: 4,
		children: [/* @__PURE__ */ T(Sc, {
			label: e,
			description: `${t} (JSON)`,
			disabled: n,
			placeholder: "Automatic",
			autosize: !0,
			minRows: 1,
			value: s,
			onChange: (e) => {
				let t = e.currentTarget.value;
				if (c(t), t.trim() === "") {
					u(null), i(void 0);
					return;
				}
				try {
					i(JSON.parse(t)), u(null);
				} catch {
					u("Not valid JSON");
				}
			}
		}), l === null ? null : /* @__PURE__ */ T(Z, {
			c: "red",
			size: "xs",
			children: l
		})]
	});
}
//#endregion
//#region src/controls/CalculationForm.tsx
var ed = { relax: ["relax", "vc-relax"] }, td = {
	resolved: "green",
	unavailable: "yellow",
	blocked: "red"
}, nd = {
	resolved: 0,
	unavailable: 1,
	blocked: 2
}, rd = [
	"k_sampling",
	"pseudo_table_id",
	"functional",
	"vdw",
	"nbnd",
	"convergence"
], id = {
	n_irr_k: "k_sampling",
	cutoffs: "pseudo_table_id"
};
function ad({ hpcProfiles: e, value: t, disabled: n, onChange: r }) {
	let i = e.length === 1 ? e[0] : void 0, a = t ?? i?.id ?? "";
	return /* @__PURE__ */ T(Hc, {
		label: "HPC profile",
		description: i === void 0 ? void 0 : "Only installed HPC profile.",
		disabled: n,
		value: a,
		data: [...a === "" ? [{
			value: "",
			label: "—",
			disabled: !0
		}] : [], ...e.map((e) => ({
			value: e.id,
			label: e.name
		}))],
		onChange: (e) => {
			r(e.currentTarget.value || null);
		}
	});
}
function od() {
	let e = Wu(), t = Gu(), { draft: n, capabilities: r, inspection: i } = t;
	if (n === null || r === null) return null;
	let a = t.operation === "inspect" || i === null;
	return /* @__PURE__ */ E(Q, {
		gap: "sm",
		children: [
			/* @__PURE__ */ T(Hc, {
				label: "Code",
				disabled: a,
				value: n.code,
				data: r.codes.map((e) => ({
					value: e.id,
					label: e.name
				})),
				onChange: (t) => {
					e.dispatch({
						type: "draft.patch",
						code: t.currentTarget.value
					});
				}
			}),
			/* @__PURE__ */ T(Hc, {
				label: "Task",
				disabled: a,
				value: n.task,
				data: r.tasks.map((e) => ({
					value: e.id,
					label: e.name
				})),
				onChange: (t) => {
					e.dispatch({
						type: "draft.patch",
						task: t.currentTarget.value
					});
				}
			}),
			/* @__PURE__ */ T(ad, {
				hpcProfiles: r.hpc_profiles,
				value: n.hpc,
				disabled: a,
				onChange: (t) => {
					e.dispatch({
						type: "draft.patch",
						hpc: t
					});
				}
			})
		]
	});
}
function sd() {
	let e = Wu(), t = Gu(), { draft: n, capabilities: r, inspection: i, reviewed: a } = t;
	if (n === null || r === null) return null;
	let o = t.operation === "inspect", s = o || i === null, c = i === null ? [] : cd(i), l = n.overrides;
	function u(t) {
		e.dispatch({
			type: "draft.patch",
			overrides: t
		});
	}
	return /* @__PURE__ */ E(Q, { children: [
		o ? /* @__PURE__ */ T(Z, {
			c: "red",
			size: "sm",
			role: "status",
			children: "Calculation settings are disabled while the new structure loads."
		}) : null,
		i === null ? /* @__PURE__ */ T(Z, {
			c: "dimmed",
			size: "sm",
			children: "Showing default settings — load a structure to configure a calculation."
		}) : null,
		/* @__PURE__ */ T(ps, {
			multiple: !0,
			transitionDuration: 0,
			classNames: { label: "workbench-accordion-label" },
			children: /* @__PURE__ */ T(yd, {
				settings: r.settings,
				task: n.task,
				overrides: l,
				reviewed: a,
				elements: c,
				pseudopotentialTables: r.pseudopotential_tables,
				disabled: s,
				onChange: u
			})
		})
	] });
}
function cd(e) {
	return [...new Set(e.structure.sites.flatMap((e) => e.species.map((e) => e.symbol)))];
}
function ld(e) {
	return [...new Set(e.map((e) => e.functional))];
}
function ud({ tables: e, elements: t, functionalOverride: n, pinned: r, resolvedTable: i, source: a, description: o, disabled: s, onChange: c }) {
	let l = e.filter((e) => (n === void 0 || e.functional === n) && t.every((t) => e.elements.includes(t))), u = typeof r == "string" ? r : void 0, d = typeof i == "object" && i && typeof i.id == "string" ? i.id : void 0, f = u ?? d, p = l.length === 0 ? "No registered table supports this structure with this functional" : void 0, m = f === void 0 || !l.some((e) => e.id === f);
	return /* @__PURE__ */ T(Hc, {
		label: "Pseudopotential table",
		description: p ?? Yu(o, u !== void 0, a),
		disabled: s,
		rightSection: u === void 0 ? void 0 : /* @__PURE__ */ T($i, {
			"aria-label": "Reset Pseudopotential table to automatic",
			size: "sm",
			disabled: s,
			onMouseDown: (e) => {
				e.preventDefault();
			},
			onClick: () => {
				c({ pseudo_table_id: void 0 });
			}
		}),
		value: f ?? "",
		data: [...m ? [{
			value: "",
			label: "—",
			disabled: !0
		}] : [], ...l.map((e) => ({
			value: e.id,
			label: `${e.provider} · ${e.functional} · ${e.accuracy} · ${e.relativistic}`
		}))],
		onChange: (e) => {
			let t = e.currentTarget.value;
			c({ pseudo_table_id: t === "" ? void 0 : t });
		}
	});
}
function dd({ tables: e, value: t, resolvedValue: n, source: r, description: i, disabled: a, onChange: o }) {
	let s = t !== void 0, c = s ? t : n, l = ld(e), u = c === void 0 || !l.includes(c);
	return /* @__PURE__ */ T(Hc, {
		label: "Functional",
		description: Yu(i, s, r),
		disabled: a,
		rightSection: s ? /* @__PURE__ */ T($i, {
			"aria-label": "Reset Functional to automatic",
			size: "sm",
			disabled: a,
			onMouseDown: (e) => {
				e.preventDefault();
			},
			onClick: () => {
				o({
					functional: void 0,
					pseudo_table_id: void 0
				});
			}
		}) : void 0,
		value: c ?? "",
		data: [...u ? [{
			value: "",
			label: "—",
			disabled: !0
		}] : [], ...l.map((e) => ({
			value: e,
			label: e
		}))],
		onChange: (e) => {
			let t = e.currentTarget.value;
			o({
				functional: t === "" ? void 0 : t,
				pseudo_table_id: void 0
			});
		}
	});
}
var fd = { pseudo_table_id: "Pseudopotential table" };
function pd(e) {
	let t = fd[e];
	if (t !== void 0) return t;
	let n = e.replace(/_/g, " ");
	return n.charAt(0).toUpperCase() + n.slice(1);
}
function md(e) {
	return e === "pseudo_table_id" ? "pseudo_table" : e;
}
function hd(e, t) {
	if (e?.status !== "resolved") return;
	let n = e.value;
	if (!(typeof n != "object" || !n)) return n[t];
}
function gd(e, t) {
	if (e?.status === "resolved") return e.field_sources?.[t] ?? e.source;
}
function _d(e) {
	if (e?.status !== "resolved") return [];
	let t = e.value;
	if (typeof t != "object" || !t || Array.isArray(t)) return [];
	let n = t.warnings;
	return Array.isArray(n) ? n.filter(Vu) : [];
}
function vd({ notes: e }) {
	return e.length === 0 ? null : /* @__PURE__ */ E(Q, {
		gap: 2,
		children: [/* @__PURE__ */ T(Z, {
			size: "xs",
			fw: 600,
			c: "dimmed",
			children: "Notes"
		}), e.map((e) => /* @__PURE__ */ T(Z, {
			size: "xs",
			c: "dimmed",
			children: e.message
		}, e.code))]
	});
}
function yd({ settings: e, task: t, overrides: n, reviewed: r, elements: i, pseudopotentialTables: a, disabled: o, onChange: s }) {
	let c = /* @__PURE__ */ new Map();
	for (let n of e) {
		let e = ed[n.group];
		if (e !== void 0 && !e.includes(t)) continue;
		let r = id[n.group] ?? n.group, i = {
			originalGroup: n.group,
			setting: n
		}, a = c.get(r);
		a === void 0 ? c.set(r, [i]) : a.push(i);
	}
	let l = [...rd.filter((e) => c.has(e)), ...[...c.keys()].filter((e) => !rd.includes(e))], u = typeof n.functional == "string" ? n.functional : void 0;
	return /* @__PURE__ */ T(w, { children: l.map((e) => {
		let t = c.get(e);
		if (t === void 0) return null;
		let l = [...new Set(t.map((e) => e.originalGroup))], d = new Map(l.map((e) => [e, r?.records[md(e)]])), f = [...d.values()].reduce((e, t) => t === void 0 ? e : e === void 0 || nd[t.status] > nd[e] ? t.status : e, void 0), p = l.flatMap((e) => _d(d.get(e)));
		return /* @__PURE__ */ E(ps.Item, {
			value: e,
			children: [/* @__PURE__ */ T(ps.Control, { children: /* @__PURE__ */ E(X, {
				gap: "xs",
				wrap: "nowrap",
				children: [f === void 0 ? null : /* @__PURE__ */ T(Zs, {
					size: "xs",
					circle: !0,
					color: td[f],
					"aria-hidden": "true"
				}), /* @__PURE__ */ T("span", { children: pd(e) })]
			}) }), /* @__PURE__ */ T(ps.Panel, { children: /* @__PURE__ */ E(Q, {
				gap: "sm",
				children: [/* @__PURE__ */ T(Ed, {
					group: e,
					groupedSettings: t,
					records: d,
					elements: i,
					pseudopotentialTables: a,
					functionalOverride: u,
					overrides: n,
					disabled: o,
					onChange: s
				}), /* @__PURE__ */ T(vd, { notes: p })]
			}) })]
		}, e);
	}) });
}
function bd({ entry: e, record: t, overrides: n, disabled: r, onChange: i }) {
	let { setting: a } = e;
	if (a.key === "k_grid") {
		let e = hd(t, "mesh"), o = Array.isArray(e) && e.length === 3 ? e : void 0;
		return /* @__PURE__ */ T(Dd, {
			value: n.k_grid,
			resolvedMesh: o,
			disabled: r,
			onChange: (e) => {
				i({ k_grid: e });
			}
		}, a.key);
	}
	return /* @__PURE__ */ T(Xu, {
		meta: a,
		value: n[a.key],
		resolvedValue: hd(t, a.key),
		source: gd(t, a.key),
		disabled: r,
		onChange: (e) => {
			i({ [a.key]: e });
		}
	}, a.key);
}
function xd({ record: e }) {
	if (e?.status !== "resolved") return null;
	let t = e.value;
	if (typeof t != "object" || !t) return null;
	let n = t;
	if (n.k_distance !== null && n.k_distance !== void 0) return null;
	let r = n.k_distance_interval;
	if (!Array.isArray(r) || r.length !== 2) return null;
	let [i, a] = r;
	return /* @__PURE__ */ E(Z, {
		size: "xs",
		c: "dimmed",
		children: [
			"This rung corresponds to Δk ∈ [",
			i.toFixed(3),
			", ",
			a.toFixed(3),
			"] Å⁻¹"
		]
	});
}
function Sd({ record: e }) {
	return e === void 0 ? null : e.status === "resolved" ? /* @__PURE__ */ E(Z, {
		size: "sm",
		c: "dimmed",
		children: [
			"Irreducible k-points: ",
			String(e.value),
			e.source ? /* @__PURE__ */ E(w, { children: [
				" ",
				"· ",
				/* @__PURE__ */ T(Bu, { source: e.source })
			] }) : null
		]
	}) : /* @__PURE__ */ T(Z, {
		size: "xs",
		c: e.status === "blocked" ? "red" : "dimmed",
		children: e.status === "blocked" ? `Irreducible k-points blocked — ${e.blocked_by ?? "an upstream field failed"}` : `Irreducible k-points unavailable — ${e.reason ?? "no reason given"}`
	});
}
function Cd({ groupedSettings: e, record: t, pseudopotentialTables: n, functionalOverride: r, disabled: i, onChange: a }) {
	return /* @__PURE__ */ T(dd, {
		tables: n,
		value: r,
		resolvedValue: t?.status === "resolved" && typeof t.value == "string" ? t.value : void 0,
		source: t?.status === "resolved" ? t.source : void 0,
		description: e[0]?.setting.description ?? "",
		disabled: i,
		onChange: a
	});
}
function wd({ groupedSettings: e, tableRecord: t, cutoffsRecord: n, elements: r, pseudopotentialTables: i, functionalOverride: a, overrides: o, disabled: s, onChange: c }) {
	let l = e.find((e) => e.originalGroup === "pseudo_table_id")?.setting;
	return /* @__PURE__ */ E(w, { children: [/* @__PURE__ */ T(ud, {
		tables: i,
		elements: r,
		functionalOverride: a,
		pinned: o.pseudo_table_id,
		resolvedTable: t?.status === "resolved" ? t.value : void 0,
		source: t?.status === "resolved" ? t.source : void 0,
		description: l?.description ?? "",
		disabled: s,
		onChange: c
	}), e.filter((e) => e.originalGroup === "cutoffs").map((e) => bd({
		entry: e,
		record: n,
		overrides: o,
		disabled: s,
		onChange: c
	}))] });
}
function Td({ groupedSettings: e, kSamplingRecord: t, nIrrKRecord: n, overrides: r, disabled: i, onChange: a }) {
	return /* @__PURE__ */ E(w, { children: [
		e.filter((e) => e.originalGroup === "k_sampling").map((e) => bd({
			entry: e,
			record: t,
			overrides: r,
			disabled: i,
			onChange: a
		})),
		/* @__PURE__ */ T(xd, { record: t }),
		/* @__PURE__ */ T(Sd, { record: n }),
		e.filter((e) => e.originalGroup === "n_irr_k").map((e) => bd({
			entry: e,
			record: n,
			overrides: r,
			disabled: i,
			onChange: a
		}))
	] });
}
function Ed({ group: e, groupedSettings: t, records: n, elements: r, pseudopotentialTables: i, functionalOverride: a, overrides: o, disabled: s, onChange: c }) {
	return e === "functional" ? /* @__PURE__ */ T(Cd, {
		groupedSettings: t,
		record: n.get("functional"),
		pseudopotentialTables: i,
		functionalOverride: a,
		disabled: s,
		onChange: c
	}) : e === "pseudo_table_id" ? /* @__PURE__ */ T(wd, {
		groupedSettings: t,
		tableRecord: n.get("pseudo_table_id"),
		cutoffsRecord: n.get("cutoffs"),
		elements: r,
		pseudopotentialTables: i,
		functionalOverride: a,
		overrides: o,
		disabled: s,
		onChange: c
	}) : e === "k_sampling" ? /* @__PURE__ */ T(Td, {
		groupedSettings: t,
		kSamplingRecord: n.get("k_sampling"),
		nIrrKRecord: n.get("n_irr_k"),
		overrides: o,
		disabled: s,
		onChange: c
	}) : /* @__PURE__ */ T(w, { children: t.map((e) => bd({
		entry: e,
		record: n.get(e.originalGroup),
		overrides: o,
		disabled: s,
		onChange: c
	})) });
}
function Dd({ value: e, resolvedMesh: t, disabled: n, onChange: r }) {
	let i = (Array.isArray(e) && e.length === 3 ? e : void 0) ?? t;
	return /* @__PURE__ */ T(pc, {
		legend: "K-point grid",
		children: /* @__PURE__ */ T(cu, {
			cols: 3,
			spacing: "xs",
			children: [
				"x",
				"y",
				"z"
			].map((e, t) => /* @__PURE__ */ T($l, {
				"aria-label": `K-point grid ${e}`,
				min: 1,
				max: 99,
				disabled: n,
				value: i?.[t] ?? "",
				placeholder: "Auto",
				onChange: (e) => {
					if (e === "") {
						r(void 0);
						return;
					}
					let n = Number(e);
					if (!Number.isInteger(n) || n < 1 || n > 99) return;
					let a = [...i ?? [
						1,
						1,
						1
					]];
					a[t] = n, r(a);
				}
			}, e))
		})
	});
}
//#endregion
//#region src/cards/AdvisorsCard.tsx
function Od({ kicker: e }) {
	let t = Gu();
	return /* @__PURE__ */ E(hi, {
		component: "section",
		id: "advisors-panel",
		"aria-label": "Goldilocks advisors",
		withBorder: !0,
		p: "md",
		className: "workbench-card card-advisors",
		children: [/* @__PURE__ */ E(X, {
			component: "header",
			className: "card-header",
			mb: "md",
			wrap: "nowrap",
			children: [/* @__PURE__ */ T(Z, {
				className: "card-kicker",
				children: e
			}), /* @__PURE__ */ T(Lu, {
				order: 2,
				children: "Advisors"
			})]
		}), /* @__PURE__ */ T("div", {
			className: "card-body",
			tabIndex: 0,
			children: t.capabilities === null ? /* @__PURE__ */ T(Z, {
				c: "dimmed",
				children: "Load a structure to configure a calculation."
			}) : /* @__PURE__ */ T(sd, {})
		})]
	});
}
//#endregion
//#region src/review/readableName.ts
function kd(e) {
	return e.replaceAll("_", " ").replace(/\b\w/g, (e) => e.toUpperCase());
}
//#endregion
//#region src/review/ScientificRecord.tsx
function Ad({ field: e }) {
	return e.status === "unavailable" ? /* @__PURE__ */ E(Z, {
		size: "sm",
		c: "dimmed",
		children: ["Unavailable -- ", e.reason ?? "no reason given"]
	}) : e.status === "blocked" ? /* @__PURE__ */ E(Z, {
		size: "sm",
		c: "red",
		children: ["Blocked -- ", e.blocked_by ?? "an upstream field failed"]
	}) : /* @__PURE__ */ E(Q, {
		gap: "xs",
		children: [
			/* @__PURE__ */ T(Zs, {
				color: "gray",
				variant: "light",
				style: { alignSelf: "flex-start" },
				children: /* @__PURE__ */ T(Bu, { source: e.source ?? "heuristic" })
			}),
			/* @__PURE__ */ T(Md, { value: e.value }),
			e.field_sources === void 0 || e.field_sources === null ? null : /* @__PURE__ */ T(jd, { sources: e.field_sources })
		]
	});
}
function jd({ sources: e }) {
	let t = Object.entries(e);
	return t.length === 0 ? null : /* @__PURE__ */ E($, {
		layout: "fixed",
		verticalSpacing: 4,
		children: [/* @__PURE__ */ T($.Caption, { children: "Per-field sources" }), /* @__PURE__ */ T($.Tbody, { children: t.map(([e, t]) => /* @__PURE__ */ E($.Tr, { children: [/* @__PURE__ */ T($.Th, {
			scope: "row",
			children: Pd(e)
		}), /* @__PURE__ */ T($.Td, { children: /* @__PURE__ */ T(Bu, { source: t }) })] }, e)) })]
	});
}
function Md({ value: e }) {
	if (e == null) return /* @__PURE__ */ T(Z, {
		size: "sm",
		c: "dimmed",
		children: "None"
	});
	if (typeof e == "boolean") return /* @__PURE__ */ T(Z, {
		size: "sm",
		children: e ? "Yes" : "No"
	});
	if (typeof e == "number" || typeof e == "string") return /* @__PURE__ */ T(Z, {
		size: "sm",
		children: String(e)
	});
	if (Array.isArray(e)) {
		let t = e;
		return t.length === 0 ? /* @__PURE__ */ T(Z, {
			size: "sm",
			c: "dimmed",
			children: "Empty"
		}) : t.every((e) => typeof e != "object" || !e) ? /* @__PURE__ */ T(Z, {
			size: "sm",
			children: t.map(String).join(", ")
		}) : /* @__PURE__ */ T(Q, {
			gap: "xs",
			children: t.map((e, t) => /* @__PURE__ */ T(hi, {
				withBorder: !0,
				p: "xs",
				children: /* @__PURE__ */ T(Md, { value: e })
			}, t))
		});
	}
	let t = Object.entries(e), n = t.find(([e]) => e === "warnings")?.[1], r = t.filter(([e]) => e !== "warnings");
	return r.length === 0 && !Array.isArray(n) ? /* @__PURE__ */ T(Z, {
		size: "sm",
		c: "dimmed",
		children: "None"
	}) : /* @__PURE__ */ E(Q, {
		gap: "xs",
		children: [r.length === 0 ? null : /* @__PURE__ */ T($, {
			layout: "fixed",
			verticalSpacing: 4,
			style: { overflowWrap: "anywhere" },
			children: /* @__PURE__ */ T($.Tbody, { children: r.map(([e, t]) => /* @__PURE__ */ E($.Tr, { children: [/* @__PURE__ */ T($.Th, {
				scope: "row",
				children: Pd(e)
			}), /* @__PURE__ */ T($.Td, { children: /* @__PURE__ */ T(Md, { value: t }) })] }, e)) })
		}), /* @__PURE__ */ T(Nd, { warnings: n })]
	});
}
function Nd({ warnings: e }) {
	return !Array.isArray(e) || e.length === 0 ? null : /* @__PURE__ */ T(Q, {
		component: "ul",
		gap: 4,
		m: 0,
		pl: "md",
		children: e.map((e, t) => /* @__PURE__ */ T(Z, {
			component: "li",
			size: "sm",
			children: Vu(e) ? e.message : String(e)
		}, t))
	});
}
function Pd(e) {
	return e.replaceAll("_", " ").replace(/\b\w/g, (e) => e.toUpperCase());
}
//#endregion
//#region src/review/RecordAccordionItem.tsx
var Fd = {
	resolved: "green",
	unavailable: "yellow",
	blocked: "red"
};
function Id({ name: e, field: t }) {
	return /* @__PURE__ */ E(ps.Item, {
		value: e,
		className: "record-card",
		children: [/* @__PURE__ */ T(ps.Control, { children: /* @__PURE__ */ E(X, {
			justify: "space-between",
			wrap: "nowrap",
			children: [/* @__PURE__ */ E(X, {
				gap: "xs",
				wrap: "nowrap",
				children: [/* @__PURE__ */ T(Zs, {
					size: "xs",
					circle: !0,
					color: Fd[t.status],
					"aria-hidden": "true"
				}), /* @__PURE__ */ T("span", { children: kd(e) })]
			}), /* @__PURE__ */ T(lc, { children: e })]
		}) }), /* @__PURE__ */ T(ps.Panel, { children: /* @__PURE__ */ T(Ad, { field: t }) })]
	});
}
//#endregion
//#region src/workspace/recordGroups.ts
function Ld(e, t) {
	return e === "pseudo_table" || e === "pseudopotentials" || t.settings.some((t) => t.group === e);
}
//#endregion
//#region src/analysis/AnalysisSection.tsx
function Rd() {
	let e = Wu(), t = Gu(), { capabilities: n, draft: r, inspection: i, reviewed: a } = t;
	if (n === null || r === null) return null;
	let o = t.operation === "inspect" || i === null, s = r.overrides, c = new Set(n.facts.map((e) => e.key)), l = Object.entries(a?.records ?? {}).filter(([e]) => !c.has(e) && !Ld(e, n));
	return /* @__PURE__ */ E(Q, {
		gap: "sm",
		children: [n.facts.length === 0 ? null : /* @__PURE__ */ T(Q, {
			gap: "sm",
			children: n.facts.map((t) => {
				let n = a?.records[t.key];
				return /* @__PURE__ */ E("div", { children: [/* @__PURE__ */ T(Xu, {
					meta: {
						key: t.key,
						type: t.type,
						enum: t.values ?? void 0,
						unit: null,
						description: t.description
					},
					value: s[t.key],
					resolvedValue: n?.status === "resolved" ? n.value : void 0,
					source: n?.status === "resolved" ? n.source : void 0,
					disabled: o,
					onChange: (n) => {
						e.dispatch({
							type: "draft.patch",
							overrides: { [t.key]: n }
						});
					}
				}), n === void 0 || n.status === "resolved" ? null : /* @__PURE__ */ T(Z, {
					size: "xs",
					c: n.status === "blocked" ? "red" : "dimmed",
					mt: 4,
					children: n.status === "blocked" ? `Blocked — ${n.blocked_by ?? "an upstream field failed"}` : `Unavailable — ${n.reason ?? "no reason given"}`
				})] }, t.key);
			})
		}), l.length === 0 ? null : /* @__PURE__ */ T(ps, {
			multiple: !0,
			transitionDuration: 0,
			classNames: { label: "workbench-accordion-label" },
			children: l.map(([e, t]) => /* @__PURE__ */ T(Id, {
				name: e,
				field: t
			}, e))
		})]
	});
}
//#endregion
//#region src/cards/AnalysisCard.tsx
function zd({ kicker: e }) {
	let t = Gu();
	return /* @__PURE__ */ E(hi, {
		component: "section",
		id: "analysis-panel",
		"aria-label": "Goldilocks analysis",
		withBorder: !0,
		p: "md",
		className: "workbench-card card-analysis",
		children: [/* @__PURE__ */ E(X, {
			component: "header",
			className: "card-header",
			mb: "md",
			wrap: "nowrap",
			children: [/* @__PURE__ */ T(Z, {
				className: "card-kicker",
				children: e
			}), /* @__PURE__ */ T(Lu, {
				order: 2,
				children: "Analysis"
			})]
		}), /* @__PURE__ */ T("div", {
			className: "card-body",
			tabIndex: 0,
			children: t.capabilities === null || t.inspection === null ? /* @__PURE__ */ T(Z, {
				c: "dimmed",
				children: "Load a structure to see its analysis."
			}) : /* @__PURE__ */ T(Rd, {})
		})]
	});
}
//#endregion
//#region node_modules/lucide-react/dist/esm/shared/src/utils/mergeClasses.mjs
var Bd = (...e) => e.filter((e, t, n) => !!e && e.trim() !== "" && n.indexOf(e) === t).join(" ").trim(), Vd = (e) => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), Hd = (e) => e.replace(/^([A-Z])|[\s-_]+(\w)/g, (e, t, n) => n ? n.toUpperCase() : t.toLowerCase()), Ud = (e) => {
	let t = Hd(e);
	return t.charAt(0).toUpperCase() + t.slice(1);
}, Wd = {
	xmlns: "http://www.w3.org/2000/svg",
	width: 24,
	height: 24,
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	strokeWidth: 2,
	strokeLinecap: "round",
	strokeLinejoin: "round"
}, Gd = (e) => {
	for (let t in e) if (t.startsWith("aria-") || t === "role" || t === "title") return !0;
	return !1;
}, Kd = s({}), qd = () => f(Kd), Jd = l(({ color: e, size: t, strokeWidth: n, absoluteStrokeWidth: r, className: i = "", children: a, iconNode: o, ...s }, l) => {
	let { size: u = 24, strokeWidth: d = 2, absoluteStrokeWidth: f = !1, color: p = "currentColor", className: m = "" } = qd() ?? {}, h = r ?? f ? Number(n ?? d) * 24 / Number(t ?? u) : n ?? d;
	return c("svg", {
		ref: l,
		...Wd,
		width: t ?? u ?? Wd.width,
		height: t ?? u ?? Wd.height,
		stroke: e ?? p,
		strokeWidth: h,
		className: Bd("lucide", m, i),
		...!a && !Gd(s) && { "aria-hidden": "true" },
		...s
	}, [...o.map(([e, t]) => c(e, t)), ...Array.isArray(a) ? a : [a]]);
}), Yd = (e, t) => {
	let n = l(({ className: n, ...r }, i) => c(Jd, {
		ref: i,
		iconNode: t,
		className: Bd(`lucide-${Vd(Ud(e))}`, `lucide-${e}`, n),
		...r
	}));
	return n.displayName = Ud(e), n;
}, Xd = Yd("atom", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "1",
		key: "41hilf"
	}],
	["path", {
		d: "M20.2 20.2c2.04-2.03.02-7.36-4.5-11.9-4.54-4.52-9.87-6.54-11.9-4.5-2.04 2.03-.02 7.36 4.5 11.9 4.54 4.52 9.87 6.54 11.9 4.5Z",
		key: "1l2ple"
	}],
	["path", {
		d: "M15.7 15.7c4.52-4.54 6.54-9.87 4.5-11.9-2.03-2.04-7.36-.02-11.9 4.5-4.52 4.54-6.54 9.87-4.5 11.9 2.03 2.04 7.36.02 11.9-4.5Z",
		key: "1wam0m"
	}]
]), Zd = Yd("download", [
	["path", {
		d: "M12 15V3",
		key: "m9g1x1"
	}],
	["path", {
		d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
		key: "ih7n3h"
	}],
	["path", {
		d: "m7 10 5 5 5-5",
		key: "brsn70"
	}]
]), Qd = Yd("moon", [["path", {
	d: "M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401",
	key: "kfwtm"
}]]), $d = Yd("rotate-cw", [["path", {
	d: "M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8",
	key: "1p45f6"
}], ["path", {
	d: "M21 3v5h-5",
	key: "1q7to0"
}]]), ef = Yd("sun", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "4",
		key: "4exip2"
	}],
	["path", {
		d: "M12 2v2",
		key: "tus03m"
	}],
	["path", {
		d: "M12 20v2",
		key: "1lh1kg"
	}],
	["path", {
		d: "m4.93 4.93 1.41 1.41",
		key: "149t6j"
	}],
	["path", {
		d: "m17.66 17.66 1.41 1.41",
		key: "ptbguv"
	}],
	["path", {
		d: "M2 12h2",
		key: "1t8f8n"
	}],
	["path", {
		d: "M20 12h2",
		key: "1q8mjw"
	}],
	["path", {
		d: "m6.34 17.66-1.41 1.41",
		key: "1m8zz5"
	}],
	["path", {
		d: "m19.07 4.93-1.41 1.41",
		key: "1shlcs"
	}]
]), tf = Yd("upload", [
	["path", {
		d: "M12 3v12",
		key: "1x0j5s"
	}],
	["path", {
		d: "m17 8-5-5-5 5",
		key: "7q97r8"
	}],
	["path", {
		d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
		key: "ih7n3h"
	}]
]), nf = Uint8Array, rf = Uint16Array, af = Int32Array, of = new nf([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	3,
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	0,
	0,
	0,
	0
]), sf = new nf([
	0,
	0,
	0,
	0,
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	9,
	10,
	10,
	11,
	11,
	12,
	12,
	13,
	13,
	0,
	0
]), cf = new nf([
	16,
	17,
	18,
	0,
	8,
	7,
	9,
	6,
	10,
	5,
	11,
	4,
	12,
	3,
	13,
	2,
	14,
	1,
	15
]), lf = function(e, t) {
	for (var n = new rf(31), r = 0; r < 31; ++r) n[r] = t += 1 << e[r - 1];
	for (var i = new af(n[30]), r = 1; r < 30; ++r) for (var a = n[r]; a < n[r + 1]; ++a) i[a] = a - n[r] << 5 | r;
	return {
		b: n,
		r: i
	};
}, uf = lf(of, 2), df = uf.b, ff = uf.r;
df[28] = 258, ff[258] = 28;
var pf = lf(sf, 0), mf = pf.b;
pf.r;
for (var hf = new rf(32768), gf = 0; gf < 32768; ++gf) {
	var _f = (gf & 43690) >> 1 | (gf & 21845) << 1;
	_f = (_f & 52428) >> 2 | (_f & 13107) << 2, _f = (_f & 61680) >> 4 | (_f & 3855) << 4, hf[gf] = ((_f & 65280) >> 8 | (_f & 255) << 8) >> 1;
}
for (var vf = (function(e, t, n) {
	for (var r = e.length, i = 0, a = new rf(t); i < r; ++i) e[i] && ++a[e[i] - 1];
	var o = new rf(t);
	for (i = 1; i < t; ++i) o[i] = o[i - 1] + a[i - 1] << 1;
	var s;
	if (n) {
		s = new rf(1 << t);
		var c = 15 - t;
		for (i = 0; i < r; ++i) if (e[i]) for (var l = i << 4 | e[i], u = t - e[i], d = o[e[i] - 1]++ << u, f = d | (1 << u) - 1; d <= f; ++d) s[hf[d] >> c] = l;
	} else for (s = new rf(r), i = 0; i < r; ++i) e[i] && (s[i] = hf[o[e[i] - 1]++] >> 15 - e[i]);
	return s;
}), yf = new nf(288), gf = 0; gf < 144; ++gf) yf[gf] = 8;
for (var gf = 144; gf < 256; ++gf) yf[gf] = 9;
for (var gf = 256; gf < 280; ++gf) yf[gf] = 7;
for (var gf = 280; gf < 288; ++gf) yf[gf] = 8;
for (var bf = new nf(32), gf = 0; gf < 32; ++gf) bf[gf] = 5;
var xf = /*#__PURE__*/ vf(yf, 9, 1), Sf = /*#__PURE__*/ vf(bf, 5, 1), Cf = function(e) {
	for (var t = e[0], n = 1; n < e.length; ++n) e[n] > t && (t = e[n]);
	return t;
}, wf = function(e, t, n) {
	var r = t / 8 | 0;
	return (e[r] | e[r + 1] << 8) >> (t & 7) & n;
}, Tf = function(e, t) {
	var n = t / 8 | 0;
	return (e[n] | e[n + 1] << 8 | e[n + 2] << 16) >> (t & 7);
}, Ef = function(e) {
	return (e + 7) / 8 | 0;
}, Df = function(e, t, n) {
	return (t == null || t < 0) && (t = 0), (n == null || n > e.length) && (n = e.length), new nf(e.subarray(t, n));
}, Of = [
	"unexpected EOF",
	"invalid block type",
	"invalid length/literal",
	"invalid distance",
	"stream finished",
	"no stream handler",
	,
	"no callback",
	"invalid UTF-8 data",
	"extra field too long",
	"date not in range 1980-2099",
	"filename too long",
	"stream finishing",
	"invalid zip data"
], kf = function(e, t, n) {
	var r = Error(t || Of[e]);
	if (r.code = e, Error.captureStackTrace && Error.captureStackTrace(r, kf), !n) throw r;
	return r;
}, Af = function(e, t, n, r) {
	var i = e.length, a = r ? r.length : 0;
	if (!i || t.f && !t.l) return n || new nf(0);
	var o = !n, s = o || t.i != 2, c = t.i;
	o && (n = new nf(i * 3));
	var l = function(e) {
		var t = n.length;
		if (e > t) {
			var r = new nf(Math.max(t * 2, e));
			r.set(n), n = r;
		}
	}, u = t.f || 0, d = t.p || 0, f = t.b || 0, p = t.l, m = t.d, h = t.m, g = t.n, _ = i * 8;
	do {
		if (!p) {
			u = wf(e, d, 1);
			var v = wf(e, d + 1, 3);
			if (d += 3, !v) {
				var y = Ef(d) + 4, b = e[y - 4] | e[y - 3] << 8, x = y + b;
				if (x > i) {
					c && kf(0);
					break;
				}
				s && l(f + b), n.set(e.subarray(y, x), f), t.b = f += b, t.p = d = x * 8, t.f = u;
				continue;
			}
			if (v == 1) p = xf, m = Sf, h = 9, g = 5;
			else if (v == 2) {
				var S = wf(e, d, 31) + 257, C = wf(e, d + 10, 15) + 4, w = S + wf(e, d + 5, 31) + 1;
				d += 14;
				for (var T = new nf(w), E = new nf(19), D = 0; D < C; ++D) E[cf[D]] = wf(e, d + D * 3, 7);
				d += C * 3;
				for (var O = Cf(E), k = (1 << O) - 1, ee = vf(E, O, 1), D = 0; D < w;) {
					var A = ee[wf(e, d, k)];
					d += A & 15;
					var y = A >> 4;
					if (y < 16) T[D++] = y;
					else {
						var j = 0, M = 0;
						for (y == 16 ? (M = 3 + wf(e, d, 3), d += 2, j = T[D - 1]) : y == 17 ? (M = 3 + wf(e, d, 7), d += 3) : y == 18 && (M = 11 + wf(e, d, 127), d += 7); M--;) T[D++] = j;
					}
				}
				var N = T.subarray(0, S), P = T.subarray(S);
				h = Cf(N), g = Cf(P), p = vf(N, h, 1), m = vf(P, g, 1);
			} else kf(1);
			if (d > _) {
				c && kf(0);
				break;
			}
		}
		s && l(f + 131072);
		for (var te = (1 << h) - 1, ne = (1 << g) - 1, F = d;; F = d) {
			var j = p[Tf(e, d) & te], I = j >> 4;
			if (d += j & 15, d > _) {
				c && kf(0);
				break;
			}
			if (j || kf(2), I < 256) n[f++] = I;
			else if (I == 256) {
				F = d, p = null;
				break;
			} else {
				var re = I - 254;
				if (I > 264) {
					var D = I - 257, L = of[D];
					re = wf(e, d, (1 << L) - 1) + df[D], d += L;
				}
				var R = m[Tf(e, d) & ne], z = R >> 4;
				R || kf(3), d += R & 15;
				var P = mf[z];
				if (z > 3) {
					var L = sf[z];
					P += Tf(e, d) & (1 << L) - 1, d += L;
				}
				if (d > _) {
					c && kf(0);
					break;
				}
				s && l(f + 131072);
				var ie = f + re;
				if (f < P) {
					var ae = a - P, oe = Math.min(P, ie);
					for (ae + f < 0 && kf(3); f < oe; ++f) n[f] = r[ae + f];
				}
				for (; f < ie; ++f) n[f] = n[f - P];
			}
		}
		t.l = p, t.p = F, t.b = f, t.f = u, p && (u = 1, t.m = h, t.d = m, t.n = g);
	} while (!u);
	return f != n.length && o ? Df(n, 0, f) : n.subarray(0, f);
}, jf = /*#__PURE__*/ new nf(0), Mf = function(e, t) {
	return e[t] | e[t + 1] << 8;
}, Nf = function(e, t) {
	return (e[t] | e[t + 1] << 8 | e[t + 2] << 16 | e[t + 3] << 24) >>> 0;
}, Pf = function(e, t) {
	return Nf(e, t) + Nf(e, t + 4) * 4294967296;
};
function Ff(e, t) {
	return Af(e, { i: 2 }, t && t.out, t && t.dictionary);
}
var If = typeof TextDecoder < "u" && /*#__PURE__*/ new TextDecoder();
try {
	If.decode(jf, { stream: !0 });
} catch {}
var Lf = function(e) {
	for (var t = "", n = 0;;) {
		var r = e[n++], i = (r > 127) + (r > 223) + (r > 239);
		if (n + i > e.length) return {
			s: t,
			r: Df(e, n - 1)
		};
		i ? i == 3 ? (r = ((r & 15) << 18 | (e[n++] & 63) << 12 | (e[n++] & 63) << 6 | e[n++] & 63) - 65536, t += String.fromCharCode(55296 | r >> 10, 56320 | r & 1023)) : i & 1 ? t += String.fromCharCode((r & 31) << 6 | e[n++] & 63) : t += String.fromCharCode((r & 15) << 12 | (e[n++] & 63) << 6 | e[n++] & 63) : t += String.fromCharCode(r);
	}
};
function Rf(e, t) {
	if (t) {
		for (var n = "", r = 0; r < e.length; r += 16384) n += String.fromCharCode.apply(null, e.subarray(r, r + 16384));
		return n;
	}
	if (If) return If.decode(e);
	var i = Lf(e), a = i.s, n = i.r;
	return n.length && kf(8), a;
}
var zf = function(e, t) {
	return t + 30 + Mf(e, t + 26) + Mf(e, t + 28);
}, Bf = function(e, t, n) {
	var r = Mf(e, t + 28), i = Rf(e.subarray(t + 46, t + 46 + r), !(Mf(e, t + 8) & 2048)), a = t + 46 + r, o = Nf(e, t + 20), s = n && o == 4294967295 ? Vf(e, a) : [
		o,
		Nf(e, t + 24),
		Nf(e, t + 42)
	], c = s[0], l = s[1], u = s[2];
	return [
		Mf(e, t + 10),
		c,
		l,
		i,
		a + Mf(e, t + 30) + Mf(e, t + 32),
		u
	];
}, Vf = function(e, t) {
	for (; Mf(e, t) != 1; t += 4 + Mf(e, t + 2));
	return [
		Pf(e, t + 12),
		Pf(e, t + 4),
		Pf(e, t + 20)
	];
};
function Hf(e, t) {
	for (var n = {}, r = e.length - 22; Nf(e, r) != 101010256; --r) (!r || e.length - r > 65558) && kf(13);
	var i = Mf(e, r + 8);
	if (!i) return {};
	var a = Nf(e, r + 16), o = a == 4294967295 || i == 65535;
	if (o) {
		var s = Nf(e, r - 12);
		o = Nf(e, s) == 101075792, o && (i = Nf(e, s + 32), a = Nf(e, s + 48));
	}
	for (var c = t && t.filter, l = 0; l < i; ++l) {
		var u = Bf(e, a, o), d = u[0], f = u[1], p = u[2], m = u[3], h = u[4], g = u[5], _ = zf(e, g);
		a = h, (!c || c({
			name: m,
			size: f,
			originalSize: p,
			compression: d
		})) && (d ? d == 8 ? n[m] = Ff(e.subarray(_, _ + f), { out: new nf(p) }) : kf(14, "unknown compression type " + d) : n[m] = Df(e, _, _ + f));
	}
	return n;
}
//#endregion
//#region src/review/artifacts.ts
async function Uf(e) {
	let t = Hf(new Uint8Array(await e.blob.arrayBuffer())), n = new TextDecoder("utf-8"), r = [], i = null;
	for (let [e, a] of Object.entries(t)) {
		let t = n.decode(a);
		e === "goldilocks.json" && (i = Wf(t)), r.push({
			path: e,
			content: t
		});
	}
	return {
		manifest: i,
		files: r
	};
}
function Wf(e) {
	try {
		let t = JSON.parse(e);
		return Gf(t) ? t : null;
	} catch {
		return null;
	}
}
function Gf(e) {
	return typeof e == "object" && !!e && "files" in e && typeof e.files == "object";
}
function Kf(e, t) {
	let n = e?.files[t];
	return n === void 0 ? void 0 : {
		sha256: n.sha256,
		size_bytes: n.size_bytes
	};
}
//#endregion
//#region src/review/GeneratedInputPreview.tsx
var qf = 352, Jf = 160, Yf = {
	ArrowUp: -32,
	ArrowDown: 32,
	Home: -Infinity,
	End: Infinity
};
function Xf({ path: e, content: t }) {
	let [n, r] = y(null), [i, a] = y(qf), o = v(null), s = v(null);
	function c(e) {
		if (e === null || o.current === e) return;
		o.current = e, e.style.height = "auto";
		let t = Math.max(Jf, e.scrollHeight), n = Math.min(qf, t);
		e.style.height = `${String(n)}px`, a(t), r(n);
	}
	function l(e) {
		r(Math.min(i, Math.max(Jf, e)));
	}
	function u(e) {
		let t = n ?? Math.min(qf, i), r = Yf[e.key];
		typeof r == "number" && (e.preventDefault(), l(t + r));
	}
	function d(e) {
		let t = s.current;
		t?.id === e.pointerId && l(t.startHeight + e.clientY - t.startY);
	}
	function f(e) {
		s.current?.id === e.pointerId && (s.current = null, e.currentTarget.hasPointerCapture(e.pointerId) && e.currentTarget.releasePointerCapture(e.pointerId));
	}
	let p = n ?? Math.min(qf, i);
	return /* @__PURE__ */ E(hi, {
		withBorder: !0,
		children: [/* @__PURE__ */ T(lc, {
			block: !0,
			role: "region",
			id: "generated-input-content",
			ref: c,
			h: n ?? void 0,
			"aria-label": `Generated input ${e}`,
			tabIndex: 0,
			children: t
		}, `${e}\0${t}`), /* @__PURE__ */ T("div", {
			className: "code-resizer",
			role: "separator",
			"aria-label": "Resize generated input",
			"aria-controls": "generated-input-content",
			"aria-orientation": "horizontal",
			"aria-valuemin": Jf,
			"aria-valuemax": Math.round(i),
			"aria-valuenow": Math.round(p),
			"aria-valuetext": p >= i ? "Full input file visible" : `${String(Math.round(p))} pixels high`,
			tabIndex: 0,
			title: "Drag or use arrow keys to resize the generated input",
			onKeyDown: u,
			onDoubleClick: () => {
				l(i);
			},
			onPointerDown: (e) => {
				e.button === 0 && (s.current = {
					id: e.pointerId,
					startHeight: p,
					startY: e.clientY
				}, e.currentTarget.setPointerCapture(e.pointerId), e.preventDefault());
			},
			onPointerMove: d,
			onPointerUp: f,
			onPointerCancel: f
		})]
	});
}
//#endregion
//#region src/review/GeneratedInputReview.tsx
var Zf = {
	input: 0,
	submission_script: 1,
	pseudopotential: 2,
	manifest: 3,
	readme: 4,
	citations: 4
};
function Qf(e, t) {
	let n = e?.files[t]?.role;
	return n === void 0 && t === "goldilocks.json" ? "manifest" : n;
}
function $f(e, t) {
	return [...e].sort((e, n) => {
		let r = Zf[Qf(t, e.path) ?? ""] ?? 5, i = Zf[Qf(t, n.path) ?? ""] ?? 5;
		return r === i ? e.path.localeCompare(n.path) : r - i;
	});
}
function ep({ archive: e }) {
	let t = rp(e);
	if (e === null) return /* @__PURE__ */ E("div", { children: [/* @__PURE__ */ T(Lu, {
		order: 3,
		children: "Generated inputs"
	}), /* @__PURE__ */ T(Z, {
		c: "dimmed",
		children: "The generated files will appear here automatically once a recommendation is ready."
	})] });
	if (t === null) return /* @__PURE__ */ E("div", { children: [/* @__PURE__ */ T(Lu, {
		order: 3,
		children: "Generated inputs"
	}), /* @__PURE__ */ T(Z, {
		c: "dimmed",
		children: "Reading the generated archive…"
	})] });
	let { manifest: n, files: r } = t;
	return r.length === 0 ? /* @__PURE__ */ E("div", { children: [/* @__PURE__ */ T(Lu, {
		order: 3,
		children: "Generated inputs"
	}), /* @__PURE__ */ T(Z, {
		c: "dimmed",
		children: "No generated input files."
	})] }) : /* @__PURE__ */ E("div", { children: [/* @__PURE__ */ E(X, {
		component: "header",
		justify: "space-between",
		mb: "xs",
		children: [/* @__PURE__ */ T(Lu, {
			order: 3,
			children: "Generated inputs"
		}), /* @__PURE__ */ E(Z, {
			size: "sm",
			c: "dimmed",
			children: [r.length, " files"]
		})]
	}), /* @__PURE__ */ T(ps, {
		multiple: !0,
		transitionDuration: 0,
		children: $f(r, n).map((e) => {
			let t = Qf(n, e.path), r = Kf(n, e.path);
			return /* @__PURE__ */ E(ps.Item, {
				value: e.path,
				children: [/* @__PURE__ */ T(ps.Control, { children: /* @__PURE__ */ E(X, {
					justify: "space-between",
					wrap: "nowrap",
					gap: "xs",
					children: [/* @__PURE__ */ T(Z, {
						size: "sm",
						fw: 600,
						style: { overflowWrap: "anywhere" },
						children: e.path
					}), r?.sha256 === void 0 ? null : /* @__PURE__ */ T(lc, { children: r.sha256.slice(0, 10) })]
				}) }), /* @__PURE__ */ T(ps.Panel, { children: t === "pseudopotential" ? /* @__PURE__ */ T(tp, {
					content: e.content,
					sizeBytes: r?.size_bytes,
					sha256: r?.sha256
				}) : /* @__PURE__ */ T(Xf, {
					path: e.path,
					content: e.content
				}) })]
			}, e.path);
		})
	})] });
}
function tp({ content: e, sizeBytes: t, sha256: n }) {
	let r = np(e);
	return /* @__PURE__ */ T($, { children: /* @__PURE__ */ E($.Tbody, { children: [
		r === null ? null : Object.entries(r).map(([e, t]) => /* @__PURE__ */ E($.Tr, { children: [/* @__PURE__ */ T($.Th, {
			scope: "row",
			children: kd(e)
		}), /* @__PURE__ */ T($.Td, {
			style: { overflowWrap: "anywhere" },
			children: t
		})] }, e)),
		/* @__PURE__ */ E($.Tr, { children: [/* @__PURE__ */ T($.Th, {
			scope: "row",
			children: "Size"
		}), /* @__PURE__ */ T($.Td, { children: t === void 0 ? "Unknown" : `${(t / 1024).toFixed(1)} KB` })] }),
		/* @__PURE__ */ E($.Tr, { children: [/* @__PURE__ */ T($.Th, {
			scope: "row",
			children: "SHA-256"
		}), /* @__PURE__ */ T($.Td, {
			style: { overflowWrap: "anywhere" },
			children: /* @__PURE__ */ T(lc, { children: n ?? "unlisted" })
		})] })
	] }) });
}
function np(e) {
	let t = /<PP_HEADER\b([^>]*)\/?>/i.exec(e)?.[1];
	if (t === void 0) return null;
	let n = {};
	for (let e of t.matchAll(/([\w.]+)\s*=\s*"([^"]*)"/g)) {
		let [, t, r] = e;
		t !== void 0 && r !== void 0 && (n[t] = r.trim());
	}
	return Object.keys(n).length === 0 ? null : n;
}
function rp(e) {
	let [t, n] = y(null);
	return p(() => {
		if (e === null) return;
		let t = !1;
		return Uf(e).then((r) => {
			t || n({
				archive: e,
				contents: r
			});
		}), () => {
			t = !0;
		};
	}, [e]), t?.archive === e ? t.contents : null;
}
//#endregion
//#region src/review/WarningsPanel.tsx
var ip = {
	error: "Errors",
	warning: "Warnings",
	info: "Notices"
};
function ap({ warnings: e }) {
	return e.length === 0 ? null : /* @__PURE__ */ T(Q, {
		gap: "sm",
		children: [
			"error",
			"warning",
			"info"
		].map((t) => {
			let n = e.filter((e) => e.level === t);
			return n.length === 0 ? null : /* @__PURE__ */ T(gs, {
				color: Hu[t],
				variant: "filled",
				autoContrast: !0,
				title: ip[t],
				role: "status",
				"aria-live": "polite",
				"aria-atomic": "true",
				children: /* @__PURE__ */ T(Q, {
					component: "ul",
					gap: "xs",
					m: 0,
					pl: "md",
					children: n.map((e) => /* @__PURE__ */ T(Z, {
						component: "li",
						size: "sm",
						children: e.message
					}, e.code))
				})
			}, t);
		})
	});
}
//#endregion
//#region src/cards/BundleCard.tsx
function op({ kicker: e }) {
	let t = Wu(), n = Gu(), r = n.reviewed;
	return /* @__PURE__ */ E(hi, {
		component: "section",
		id: "bundle-panel",
		"aria-label": "Bundle",
		"aria-busy": n.operation === "explain",
		withBorder: !0,
		p: "md",
		className: "workbench-card card-bundle",
		children: [/* @__PURE__ */ E(X, {
			component: "header",
			className: "card-header",
			mb: "md",
			wrap: "nowrap",
			children: [/* @__PURE__ */ T(Z, {
				className: "card-kicker",
				children: e
			}), /* @__PURE__ */ T(Lu, {
				order: 2,
				children: "Bundle"
			})]
		}), /* @__PURE__ */ T("div", {
			className: "card-body",
			tabIndex: 0,
			children: r === null ? /* @__PURE__ */ E(Q, {
				align: "center",
				justify: "center",
				mih: 160,
				role: n.operation === "explain" ? "status" : void 0,
				children: [
					n.operation === "explain" && /* @__PURE__ */ T(Bi, { size: "sm" }),
					/* @__PURE__ */ T(Z, {
						fw: 600,
						children: n.operation === "explain" ? "Computing recommendation" : "No recommendation yet"
					}),
					n.operation === "explain" ? null : /* @__PURE__ */ T(Z, {
						c: "dimmed",
						size: "sm",
						children: "Load a structure to generate input files."
					})
				]
			}) : /* @__PURE__ */ E(Q, {
				gap: "lg",
				children: [
					n.outOfDate && /* @__PURE__ */ T(gs, {
						role: "status",
						"aria-label": "Recommendation notice",
						"aria-live": "polite",
						"aria-atomic": "true",
						children: "Settings changed — recomputing the recommendation automatically."
					}),
					/* @__PURE__ */ E(X, {
						justify: "space-between",
						children: [/* @__PURE__ */ T(oc, {
							rightSection: /* @__PURE__ */ T(Zd, {
								"aria-hidden": "true",
								size: 14
							}),
							loading: n.operation === "download",
							disabled: n.outOfDate || n.operation !== null,
							onClick: () => void t.dispatch({ type: "review.download" }),
							children: "Download (.zip)"
						}), n.lastDownload === null || n.outOfDate ? null : /* @__PURE__ */ E(Z, {
							size: "sm",
							role: "status",
							"aria-label": "Archive status",
							"aria-live": "polite",
							children: [n.lastDownload.filename, " is ready"]
						})]
					}),
					/* @__PURE__ */ T(ep, { archive: n.outOfDate ? null : n.lastDownload }),
					/* @__PURE__ */ T(ap, { warnings: r.warnings })
				]
			})
		})]
	});
}
//#endregion
//#region src/advisors/MagneticOrderingsPanel.tsx
function sp() {
	let e = Wu(), t = Gu(), { inspection: n, magneticOrderings: r, magneticOrderingsOperation: i } = t, [a, o] = y(/* @__PURE__ */ new Set()), [s, c] = y(r);
	if (s !== r && (c(r), o(/* @__PURE__ */ new Set())), p(() => {
		n !== null && r === null && i === null && e.dispatch({ type: "magneticOrderings.list" });
	}, [
		n,
		r,
		i,
		e
	]), n === null) return null;
	let l = r?.candidates ?? [], u = i !== null;
	function d(e, t) {
		o((n) => {
			let r = new Set(n);
			return t ? r.add(e) : r.delete(e), r;
		});
	}
	return /* @__PURE__ */ E(Q, {
		gap: "sm",
		children: [
			/* @__PURE__ */ E(Q, {
				gap: 4,
				children: [/* @__PURE__ */ T(X, {
					justify: "flex-start",
					children: /* @__PURE__ */ T(oc, {
						size: "xs",
						variant: "light",
						miw: 160,
						loading: i === "rank",
						disabled: u || l.length === 0,
						onClick: () => void e.dispatch({ type: "magneticOrderings.rank" }),
						children: "Run mMACE"
					})
				}), /* @__PURE__ */ T(Z, {
					size: "xs",
					c: "dimmed",
					children: "Relaxes each candidate ordering with mMACE (a magnetic MLIP model) and ranks them by energy per atom."
				})]
			}),
			t.magneticOrderingsError === null ? null : /* @__PURE__ */ T(Z, {
				c: "red",
				size: "sm",
				role: "alert",
				children: t.magneticOrderingsError
			}),
			/* @__PURE__ */ T(ap, { warnings: r?.warnings ?? [] }),
			l.length === 0 ? /* @__PURE__ */ T(Z, {
				c: "dimmed",
				size: "sm",
				children: i === "list" ? "Listing candidates…" : "No candidates yet."
			}) : /* @__PURE__ */ E(w, { children: [/* @__PURE__ */ T($.ScrollContainer, {
				minWidth: 420,
				children: /* @__PURE__ */ E($, {
					verticalSpacing: 4,
					children: [
						/* @__PURE__ */ T($.Caption, { children: r?.ranked ? "Ranked by mMACE-relaxed energy per atom" : "Not yet ranked" }),
						/* @__PURE__ */ T($.Thead, { children: /* @__PURE__ */ E($.Tr, { children: [
							/* @__PURE__ */ T($.Th, {
								style: { width: "2.5rem" },
								children: /* @__PURE__ */ T(fi, { children: "Select for download" })
							}),
							/* @__PURE__ */ T($.Th, { children: "Ordering" }),
							/* @__PURE__ */ T($.Th, { children: "Atoms" }),
							/* @__PURE__ */ T($.Th, { children: "E/atom (eV)" }),
							/* @__PURE__ */ T($.Th, { children: "Status" })
						] }) }),
						/* @__PURE__ */ T($.Tbody, { children: l.map((e) => /* @__PURE__ */ E($.Tr, { children: [
							/* @__PURE__ */ T($.Td, { children: /* @__PURE__ */ T(Js, {
								"aria-label": `Select ${e.label} for download`,
								checked: a.has(e.label),
								onChange: (t) => {
									d(e.label, t.currentTarget.checked);
								}
							}) }),
							/* @__PURE__ */ T($.Td, { children: /* @__PURE__ */ E(X, {
								gap: 4,
								wrap: "nowrap",
								children: [/* @__PURE__ */ T(Z, {
									size: "sm",
									children: e.label
								}), e.is_recommended ? /* @__PURE__ */ T(Zs, {
									size: "xs",
									color: "teal",
									children: "Recommended"
								}) : null]
							}) }),
							/* @__PURE__ */ T($.Td, { children: e.natoms }),
							/* @__PURE__ */ T($.Td, { children: e.energy_per_atom_ev === null ? "—" : e.energy_per_atom_ev.toFixed(4) }),
							/* @__PURE__ */ T($.Td, { children: e.status ?? "—" })
						] }, e.label)) })
					]
				})
			}), /* @__PURE__ */ T(X, {
				justify: "flex-end",
				children: /* @__PURE__ */ E(oc, {
					size: "xs",
					rightSection: /* @__PURE__ */ T(Zd, {
						"aria-hidden": "true",
						size: 14
					}),
					loading: i === "download",
					disabled: u || a.size === 0,
					onClick: () => void e.dispatch({
						type: "magneticOrderings.downloadSelected",
						labels: [...a]
					}),
					children: [
						"Download selected (",
						a.size,
						")"
					]
				})
			})] })
		]
	});
}
//#endregion
//#region src/cards/MagneticOrderingsCard.tsx
function cp({ kicker: e }) {
	return /* @__PURE__ */ E(hi, {
		component: "section",
		id: "magnetic-orderings-panel",
		"aria-label": "Magnetic orderings",
		withBorder: !0,
		p: "md",
		className: "workbench-card card-magnetic-orderings",
		children: [/* @__PURE__ */ E(X, {
			component: "header",
			className: "card-header",
			mb: "md",
			wrap: "nowrap",
			children: [/* @__PURE__ */ T(Z, {
				className: "card-kicker",
				children: e
			}), /* @__PURE__ */ T(Lu, {
				order: 2,
				children: "Magnetic Orderings"
			})]
		}), /* @__PURE__ */ T("div", {
			className: "card-body",
			tabIndex: 0,
			children: /* @__PURE__ */ T(sp, {})
		})]
	});
}
//#endregion
//#region src/controls/StructureSourceControls.tsx
function lp({ source: e, inspection: t, inspecting: n, onOpen: r }) {
	let i = v(null), a = v(0), [o, s] = y(!1), [c, l] = y(null);
	async function u(e) {
		let t = ++a.current;
		if (l(null), e.size > 5242880) {
			l("Structure files must be 5 MB or smaller.");
			return;
		}
		if (e.size === 0) {
			l("The selected structure file is empty.");
			return;
		}
		try {
			let n = await e.text();
			if (t !== a.current) return;
			await r({
				structure_content: n,
				structure_name: e.name,
				structure_format: dp(e.name)
			});
		} catch {
			t === a.current && l("The selected file could not be read.");
		}
	}
	function d(e) {
		i.current?.(), e !== null && u(e);
	}
	function f(e) {
		e.preventDefault(), s(!1);
		let t = e.dataTransfer.files[0];
		t !== void 0 && u(t);
	}
	let p = "CIF or POSCAR · 5 MB maximum file size";
	e !== null && (p = "Inspecting structure"), t !== null && (p = `${String(t.structure.site_count)} sites · parsed`);
	let m = {
		onDragEnter: (e) => {
			e.preventDefault(), s(!0);
		},
		onDragOver: (e) => {
			e.preventDefault();
		},
		onDragLeave: () => {
			s(!1);
		},
		onDrop: f,
		"aria-busy": n,
		bg: o ? "var(--mantine-primary-color-light)" : "var(--mantine-color-body)"
	}, h = /* @__PURE__ */ T(mc, {
		resetRef: i,
		onChange: d,
		disabled: n,
		children: (t) => /* @__PURE__ */ T(oc, {
			...t,
			variant: "subtle",
			type: "button",
			"aria-describedby": "structure-source-help",
			"aria-label": e === null ? "Choose a CIF or POSCAR structure" : "Replace structure file",
			disabled: n,
			children: e === null ? "Browse files" : "Replace file"
		})
	});
	return /* @__PURE__ */ E(w, { children: [e === null ? /* @__PURE__ */ T(hi, {
		withBorder: !0,
		p: "md",
		...m,
		children: /* @__PURE__ */ E(Q, {
			align: "center",
			gap: "xs",
			children: [
				/* @__PURE__ */ T(tf, {
					"aria-hidden": "true",
					size: 18
				}),
				/* @__PURE__ */ T(Z, {
					fw: 600,
					truncate: !0,
					w: "100%",
					ta: "center",
					children: "Drop a structure"
				}),
				/* @__PURE__ */ T(Z, {
					id: "structure-source-help",
					c: "dimmed",
					size: "sm",
					ta: "center",
					children: p
				}),
				h
			]
		})
	}) : /* @__PURE__ */ T(hi, {
		withBorder: !0,
		p: "xs",
		...m,
		children: /* @__PURE__ */ E(Q, {
			gap: 4,
			children: [
				/* @__PURE__ */ E(X, {
					gap: "xs",
					wrap: "nowrap",
					style: { minWidth: 0 },
					children: [n ? /* @__PURE__ */ T(Bi, {
						size: "xs",
						"aria-hidden": "true"
					}) : /* @__PURE__ */ T(tf, {
						"aria-hidden": "true",
						size: 16
					}), /* @__PURE__ */ T(Z, {
						fw: 600,
						truncate: !0,
						children: e.structure_name
					})]
				}),
				/* @__PURE__ */ E(X, {
					justify: "space-between",
					wrap: "nowrap",
					gap: "xs",
					children: [/* @__PURE__ */ T(Z, {
						id: "structure-source-help",
						c: "dimmed",
						size: "sm",
						truncate: !0,
						children: p
					}), h]
				}),
				t === null ? null : /* @__PURE__ */ T(up, { inspection: t })
			]
		})
	}), c === null ? null : /* @__PURE__ */ T(Z, {
		c: "red",
		size: "sm",
		role: "alert",
		children: c
	})] });
}
function up({ inspection: e }) {
	let t = e.structure, n = [...new Set(t.sites.flatMap((e) => e.species.map((e) => e.symbol)))], r = t.periodicity.every(Boolean) ? "3D" : "Partial";
	return /* @__PURE__ */ E(Z, {
		size: "sm",
		c: "dimmed",
		truncate: !0,
		"aria-label": "Inspected structure summary",
		children: [
			t.formula,
			" · ",
			n.join(" "),
			" ·",
			" ",
			t.lattice.volume_angstrom3.toFixed(1),
			" Å³ · ",
			r
		]
	});
}
function dp(e) {
	return e.toLowerCase().endsWith(".cif") ? "cif" : "poscar";
}
//#endregion
//#region src/viewer/StructureFallback.tsx
function fp({ structure: e, onRetry: t, containerRef: n, hidden: r = !1 }) {
	let i = e.site_count === 1 ? "1 atomic site" : `${String(e.site_count)} atomic sites`;
	return /* @__PURE__ */ E(gs, {
		ref: n,
		title: "3D structure preview unavailable",
		pos: "absolute",
		top: "25%",
		left: "10%",
		right: "10%",
		style: { zIndex: 5 },
		hidden: r,
		role: "status",
		"aria-live": "polite",
		children: [
			/* @__PURE__ */ E(Z, { children: [
				e.reduced_formula,
				" · ",
				i
			] }),
			/* @__PURE__ */ T(Z, {
				size: "sm",
				mt: "sm",
				children: "The parsed structure and recommendation remain available without the interactive preview."
			}),
			/* @__PURE__ */ T(oc, {
				mt: "md",
				variant: "light",
				onClick: t,
				children: "Retry 3D preview"
			})
		]
	});
}
//#endregion
//#region src/viewer/structureViewer.ts
var pp, mp, hp = async (t, n) => {
	n.throwIfAborted();
	let { createViewer: r } = await import("./3Dmol-BIKt0Ru5.js").then((t) => /* @__PURE__ */ e(t.default, 1));
	if (n.throwIfAborted(), pp === void 0) {
		let e = document.createElement("div");
		e.style.cssText = "position:relative;width:100%;height:100%", t.append(e);
		try {
			pp = {
				viewer: r(e, { antialias: !0 }),
				surface: e
			};
		} catch (t) {
			throw e.remove(), t;
		}
	}
	let { viewer: i, surface: a } = pp, o = Symbol();
	return mp = o, t.append(a), i.resize(), {
		show(e) {
			if (mp !== o) return;
			i.clear();
			let t = i.addModel(e, "cif");
			i.setStyle({}, {
				sphere: {
					scale: .3,
					colorscheme: "Jmol"
				},
				stick: {
					radius: .12,
					colorscheme: "Jmol"
				}
			});
			let n = getComputedStyle(document.documentElement);
			i.addUnitCell(t, { box: {
				color: n.getPropertyValue("--mantine-color-gray-6").trim(),
				linewidth: 1.5
			} }), i.zoomTo(), i.render();
		},
		refreshTheme() {
			if (mp !== o) return;
			let e = getComputedStyle(document.documentElement).getPropertyValue("--mantine-color-body").trim();
			i.setBackgroundColor(e, 1);
		},
		dispose() {
			mp === o && (mp = void 0, i.clear(), a.remove());
		}
	};
}, gp = [
	"a",
	"b",
	"c"
];
function _p({ inspection: e, createViewer: t = hp }) {
	let n = v(null), r = v(null), i = v(e.canonical_cif), a = v(null), [o, s] = y(0), c = Bt("light"), [l, u] = y(!1);
	p(() => {
		let e = n.current;
		if (e === null) return;
		let o = new AbortController();
		return (async () => {
			try {
				let n = await t(e, o.signal);
				if (o.signal.aborted) {
					n.dispose();
					return;
				}
				r.current = n, n.refreshTheme(), n.show(i.current), a.current !== null && (a.current.hidden = !0);
			} catch {
				!o.signal.aborted && a.current !== null && (a.current.hidden = !1);
			}
		})(), () => {
			o.abort(), r.current?.dispose(), r.current = null;
		};
	}, [t, o]), p(() => {
		if (i.current = e.canonical_cif, r.current !== null) try {
			r.current.show(e.canonical_cif), a.current !== null && (a.current.hidden = !0);
		} catch {
			a.current !== null && (a.current.hidden = !1);
		}
	}, [e.canonical_cif]), p(() => {
		r.current?.refreshTheme();
	}, [c]);
	let d = e.structure.lattice, f = e.structure.sites.some((e) => e.species.length !== 1 || e.species.some((e) => e.occupancy !== 1));
	return /* @__PURE__ */ E(Y, {
		component: "section",
		"aria-label": "Crystal structure viewer",
		style: {
			display: "flex",
			flexDirection: "column"
		},
		w: "100%",
		h: "100%",
		children: [
			/* @__PURE__ */ E(Y, {
				pos: "relative",
				style: {
					flex: 1,
					minHeight: 0
				},
				children: [
					/* @__PURE__ */ T(Y, {
						pos: "absolute",
						inset: 0,
						ref: n
					}),
					/* @__PURE__ */ T(fp, {
						structure: e.structure,
						containerRef: a,
						hidden: !0,
						onRetry: () => {
							s((e) => e + 1);
						}
					}),
					/* @__PURE__ */ E(X, {
						pos: "absolute",
						top: 10,
						left: 10,
						align: "baseline",
						gap: 6,
						children: [/* @__PURE__ */ T(Lu, {
							order: 3,
							children: e.structure.reduced_formula
						}), /* @__PURE__ */ E(Z, {
							size: "xs",
							c: "dimmed",
							children: [e.structure.site_count, " atomic sites"]
						})]
					})
				]
			}),
			/* @__PURE__ */ E(Q, {
				gap: 6,
				mt: 6,
				children: [f ? /* @__PURE__ */ T(Z, {
					size: "xs",
					c: "dimmed",
					role: "note",
					children: "Mixed or partial occupancy: this 3D preview is an approximation. Inspect the canonical site details for the exact species and occupancies."
				}) : null, /* @__PURE__ */ T(oc, {
					size: "compact-sm",
					fullWidth: !0,
					styles: { label: { whiteSpace: "normal" } },
					onClick: () => {
						u(!0);
					},
					children: "Inspect lattice, sites and occupancies"
				})]
			}),
			/* @__PURE__ */ T(Rc, {
				opened: l,
				onClose: () => {
					u(!1);
				},
				title: "Lattice, sites and occupancies",
				size: "lg",
				closeButtonProps: { "aria-label": "Close canonical site details" },
				children: l ? /* @__PURE__ */ E(Q, { children: [
					/* @__PURE__ */ T(Z, {
						size: "sm",
						children: "Canonical inspection data. Occupancies are fractions of each site; coordinates are fractional lattice coordinates."
					}),
					/* @__PURE__ */ E(hi, {
						component: "section",
						"aria-label": "Lattice parameters",
						p: "sm",
						withBorder: !0,
						children: [/* @__PURE__ */ T(Lu, {
							order: 4,
							mb: "xs",
							children: "Lattice parameters"
						}), /* @__PURE__ */ E(cu, {
							component: "dl",
							cols: 4,
							spacing: "md",
							m: 0,
							children: [d.lengths_angstrom.map((e, t) => /* @__PURE__ */ E("div", { children: [/* @__PURE__ */ T("dt", { children: gp[t] }), /* @__PURE__ */ E("dd", { children: [e.toFixed(3), " Å"] })] }, t)), /* @__PURE__ */ E("div", { children: [/* @__PURE__ */ T("dt", { children: "V" }), /* @__PURE__ */ E("dd", { children: [d.volume_angstrom3.toFixed(2), " Å³"] })] })]
						})]
					}),
					e.structure.sites.map((e, t) => /* @__PURE__ */ E(hi, {
						component: "section",
						"aria-label": `Site ${String(t + 1)}`,
						p: "sm",
						withBorder: !0,
						children: [
							/* @__PURE__ */ E(Lu, {
								order: 3,
								children: ["Site ", t + 1]
							}),
							/* @__PURE__ */ E(Z, {
								size: "sm",
								style: { overflowWrap: "anywhere" },
								children: [
									"Fractional coordinates:",
									" ",
									e.fractional_coordinates.join(", ")
								]
							}),
							/* @__PURE__ */ E($, {
								layout: "fixed",
								style: { overflowWrap: "anywhere" },
								children: [/* @__PURE__ */ T($.Thead, { children: /* @__PURE__ */ E($.Tr, { children: [
									/* @__PURE__ */ T($.Th, {
										scope: "col",
										children: "Species"
									}),
									/* @__PURE__ */ T($.Th, {
										scope: "col",
										children: "Element"
									}),
									/* @__PURE__ */ T($.Th, {
										scope: "col",
										children: "Occupancy"
									})
								] }) }), /* @__PURE__ */ T($.Tbody, { children: e.species.map((e, t) => /* @__PURE__ */ E($.Tr, { children: [
									/* @__PURE__ */ T($.Th, {
										scope: "row",
										children: e.label
									}),
									/* @__PURE__ */ T($.Td, { children: e.symbol }),
									/* @__PURE__ */ T($.Td, { children: e.occupancy })
								] }, t)) })]
							})
						]
					}, t))
				] }) : null
			})
		]
	});
}
//#endregion
//#region src/cards/StructureCard.tsx
function vp({ kicker: e }) {
	let t = Wu(), n = Gu();
	return /* @__PURE__ */ E(hi, {
		component: "section",
		id: "structure-panel",
		"aria-label": "Structure workspace",
		withBorder: !0,
		p: "md",
		className: "workbench-card card-structure",
		children: [/* @__PURE__ */ E(X, {
			component: "header",
			className: "card-header",
			mb: "md",
			wrap: "nowrap",
			children: [/* @__PURE__ */ T(Z, {
				className: "card-kicker",
				children: e
			}), /* @__PURE__ */ T(Lu, {
				order: 2,
				children: "Structure Setup"
			})]
		}), /* @__PURE__ */ E("div", {
			className: "card-body",
			tabIndex: 0,
			children: [
				/* @__PURE__ */ T(lp, {
					source: n.structureInput,
					inspection: n.inspection,
					inspecting: n.operation === "inspect",
					onOpen: (e) => t.dispatch({
						type: "source.open",
						input: e
					})
				}),
				/* @__PURE__ */ T(od, {}),
				/* @__PURE__ */ T("div", {
					className: "structure-stage",
					children: n.inspection === null ? /* @__PURE__ */ T(yp, {
						loading: n.capabilities === null || n.operation === "inspect",
						label: n.capabilities === null ? "Loading Workbench" : void 0
					}) : /* @__PURE__ */ T(_p, { inspection: n.inspection })
				})
			]
		})]
	});
}
function yp({ loading: e, label: t = e ? "Reading structure" : "No structure selected" }) {
	return /* @__PURE__ */ E(Q, {
		align: "center",
		justify: "center",
		h: "100%",
		p: "xl",
		gap: "xl",
		role: e ? "status" : void 0,
		children: [e ? /* @__PURE__ */ T(Bi, {
			size: "xl",
			"aria-hidden": "true"
		}) : /* @__PURE__ */ T(Xd, {
			size: 96,
			strokeWidth: 1,
			"aria-hidden": "true"
		}), /* @__PURE__ */ T(Lu, {
			order: 3,
			ta: "center",
			children: t
		})]
	});
}
//#endregion
//#region src/layout/AppHeader.tsx
function bp({ theme: e, onToggleTheme: t }) {
	return /* @__PURE__ */ E(X, {
		component: "header",
		justify: "space-between",
		wrap: "nowrap",
		px: "md",
		className: "app-header",
		children: [/* @__PURE__ */ E(X, {
			gap: "xs",
			wrap: "nowrap",
			children: [/* @__PURE__ */ T("img", {
				src: "/brand/goldilocks-logo.png",
				alt: "",
				width: 40,
				height: 40
			}), /* @__PURE__ */ E(Q, {
				gap: 0,
				children: [/* @__PURE__ */ T(Z, {
					style: {
						fontSize: "var(--mantine-h2-font-size)",
						fontWeight: "var(--mantine-h2-font-weight)",
						color: "#ffffff",
						lineHeight: 1.1
					},
					children: "Goldilocks"
				}), /* @__PURE__ */ T(Z, {
					style: {
						fontSize: "0.75rem",
						fontStyle: "italic",
						color: "rgba(255, 255, 255, 0.7)",
						lineHeight: 1.1
					},
					children: "Towards Greener Computation"
				})]
			})]
		}), /* @__PURE__ */ T(Ji, {
			variant: "subtle",
			className: "app-header-toggle",
			style: { color: "rgba(255, 255, 255, 0.85)" },
			"aria-label": e === "light" ? "Switch to dark mode" : "Switch to light mode",
			title: e === "light" ? "Dark mode" : "Light mode",
			onClick: t,
			children: T(e === "light" ? ef : Qd, {
				"aria-hidden": "true",
				size: 17
			})
		})]
	});
}
//#endregion
//#region src/status/FailureBanner.tsx
function xp({ failure: e, retryAvailable: t, dismissAvailable: n, onRetry: r, onDismiss: i }) {
	return /* @__PURE__ */ T(gs, {
		color: "red",
		title: Sp[e.kind] ?? "Calculation failed",
		withCloseButton: n,
		closeButtonLabel: "Dismiss error",
		styles: { closeButton: {
			width: 44,
			height: 44
		} },
		onClose: i,
		role: "alert",
		children: /* @__PURE__ */ E(X, {
			justify: "space-between",
			children: [/* @__PURE__ */ T(Z, {
				flex: 1,
				children: e.message
			}), t ? /* @__PURE__ */ T(oc, {
				color: "red",
				variant: "light",
				onClick: r,
				leftSection: /* @__PURE__ */ T($d, {
					"aria-hidden": "true",
					size: 15
				}),
				children: "Retry"
			}) : null]
		})
	});
}
var Sp = {
	invalid_request: "Check the request",
	invalid_setting: "Check your overrides",
	advice_incomplete: "Recommendation incomplete",
	invalid_hpc_profile: "Check the HPC profile",
	invalid_structure: "Check the structure",
	assets_unavailable: "Runtime assets unavailable",
	asset_not_installed: "Runtime assets unavailable",
	asset_corrupt: "Runtime assets unavailable",
	pseudo_import_error: "Pseudopotential import failed",
	generation_error: "Could not generate input files",
	submission_error: "Could not generate the submission script",
	network_error: "Cannot reach Core",
	invalid_response: "Unexpected server response",
	http_error: "Request failed",
	incompatible_vocabulary: "Frontend/backend version mismatch"
};
//#endregion
//#region src/status/OperationStatus.tsx
function Cp({ operation: e, hasFailure: t }) {
	return /* @__PURE__ */ T(fi, {
		role: "status",
		"aria-label": "Workbench status",
		"aria-live": "polite",
		"aria-atomic": "true",
		children: Tp(e, t)
	});
}
var wp = {
	capabilities: "Loading capabilities",
	inspect: "Inspecting structure",
	explain: "Computing recommendation",
	download: "Generating input files"
};
function Tp(e, t) {
	return t ? "Needs attention" : e === null ? "Ready" : wp[e];
}
//#endregion
//#region src/theme.ts
var Ep = nt({ key: "goldilocks-theme" }), Dp = pn({
	primaryColor: "blue",
	primaryShade: 6,
	autoContrast: !0,
	colors: { blue: [
		"#f0f7ff",
		"#dbeafe",
		"#bfdbfe",
		"#93c5fd",
		"#60a5fa",
		"#3b82f6",
		"#0071e3",
		"#005bb8",
		"#004a94",
		"#003970"
	] },
	fontFamily: "-apple-system, BlinkMacSystemFont, Inter, \"Avenir Next\", \"Segoe UI\", ui-sans-serif, system-ui, sans-serif",
	fontFamilyMonospace: "\"IBM Plex Mono\", \"SFMono-Regular\", Consolas, monospace",
	defaultRadius: "lg",
	shadows: {
		xs: "0 1px 2px rgba(0, 0, 0, 0.04)",
		sm: "0 2px 6px rgba(0, 0, 0, 0.05)",
		md: "0 6px 16px rgba(0, 0, 0, 0.07)",
		lg: "0 16px 32px -12px rgba(0, 0, 0, 0.16)",
		xl: "0 24px 48px -16px rgba(0, 0, 0, 0.2)"
	},
	respectReducedMotion: !0,
	components: {
		Button: oc.extend({
			defaultProps: { radius: "xl" },
			styles: { root: { minHeight: 44 } }
		}),
		ActionIcon: Ji.extend({ defaultProps: {
			size: 44,
			radius: "xl"
		} }),
		Input: Qo.extend({ styles: { input: { minHeight: 44 } } }),
		NativeSelect: Hc.extend({ defaultProps: { size: "md" } }),
		NumberInput: $l.extend({ defaultProps: {
			size: "md",
			role: "spinbutton",
			clampBehavior: "none"
		} }),
		Checkbox: Js.extend({
			defaultProps: { size: "xs" },
			styles: { body: {
				minHeight: 44,
				alignItems: "center"
			} }
		})
	}
}), Op = 400, kp = 150;
function Ap(e, t) {
	let { draft: n, structureInput: r, operation: i, outOfDate: a, reviewed: o, lastDownload: s, failureOperation: c } = t;
	p(() => {
		if (n === null || r === null || i !== null || c === "explain" || o !== null && !a) return;
		let t = setTimeout(() => {
			e.dispatch({ type: "review.compute" });
		}, Op);
		return () => {
			clearTimeout(t);
		};
	}, [
		e,
		n,
		r,
		i,
		a,
		o,
		c
	]), p(() => {
		if (i !== null || c === "download" || o === null || a || s !== null) return;
		let t = setTimeout(() => {
			e.dispatch({ type: "review.refreshArchive" });
		}, kp);
		return () => {
			clearTimeout(t);
		};
	}, [
		e,
		i,
		a,
		o,
		s,
		c
	]);
}
//#endregion
//#region src/App.tsx
function jp() {
	return /* @__PURE__ */ T(fn, {
		theme: Dp,
		colorSchemeManager: Ep,
		defaultColorScheme: "light",
		children: /* @__PURE__ */ T(Np, {})
	});
}
function Mp() {
	let e = Wu(), t = Gu();
	Ap(e, t);
	let n = t.reviewed?.records.is_magnetic?.value === "magnetic", r = n ? 5 : 4;
	return /* @__PURE__ */ E(w, { children: [
		/* @__PURE__ */ T(Cp, {
			operation: t.operation,
			hasFailure: t.failure !== null
		}),
		t.failure === null ? null : /* @__PURE__ */ T(xp, {
			failure: t.failure,
			retryAvailable: t.failure.retryable || t.failureOperation === "capabilities",
			dismissAvailable: t.capabilities !== null,
			onRetry: () => {
				e.dispatch({ type: "failure.retry" });
			},
			onDismiss: () => {
				e.dispatch({ type: "failure.dismiss" });
			}
		}),
		/* @__PURE__ */ E("main", {
			className: "workbench-grid",
			"aria-labelledby": "workbench-title",
			style: { "--workbench-columns": r },
			children: [
				/* @__PURE__ */ T(fi, { children: /* @__PURE__ */ T("h1", {
					id: "workbench-title",
					children: "Goldilocks SCF setup"
				}) }),
				/* @__PURE__ */ T(vp, { kicker: "01" }),
				/* @__PURE__ */ T(zd, { kicker: "02" }),
				/* @__PURE__ */ T(Od, { kicker: "03" }),
				n ? /* @__PURE__ */ T(cp, { kicker: "04" }) : null,
				/* @__PURE__ */ T(op, { kicker: n ? "05" : "04" })
			]
		})
	] });
}
function Np() {
	let e = Bt("light"), { toggleColorScheme: t } = Lt();
	return p(() => {
		document.querySelector("meta[name=\"theme-color\"]")?.setAttribute("content", e === "light" ? "#ffffff" : "#242424");
	}, [e]), /* @__PURE__ */ E(w, { children: [/* @__PURE__ */ T(bp, {
		theme: e,
		onToggleTheme: t
	}), /* @__PURE__ */ T(Mp, {})] });
}
//#endregion
//#region src/workspace/WorkspaceProvider.tsx
function Pp({ workspace: e, children: t }) {
	return p(() => {
		e.dispatch({ type: "workspace.start" });
	}, [e]), /* @__PURE__ */ T(Uu.Provider, {
		value: e,
		children: t
	});
}
//#endregion
//#region node_modules/zustand/esm/vanilla.mjs
var Fp = (e) => {
	let t, n = /* @__PURE__ */ new Set(), r = (e, r) => {
		let i = typeof e == "function" ? e(t) : e;
		if (!Object.is(i, t)) {
			let e = t;
			t = r ?? (typeof i != "object" || !i) ? i : Object.assign({}, t, i), n.forEach((n) => n(t, e));
		}
	}, i = () => t, a = {
		setState: r,
		getState: i,
		getInitialState: () => o,
		subscribe: (e) => (n.add(e), () => n.delete(e))
	}, o = t = e(r, i, a);
	return a;
}, Ip = ((e) => e ? Fp(e) : Fp), Lp = "1", Rp = class extends Error {
	kind;
	retryable;
	details;
	status;
	rawResponse;
	constructor(e, t, n, r = {}, i = null, a) {
		super(t), this.kind = e, this.retryable = n, this.details = r, this.status = i, this.rawResponse = a, this.name = "CoreFailure";
	}
}, zp = class {
	fetcher;
	baseUrl;
	constructor(e = "", t = globalThis.fetch.bind(globalThis)) {
		this.fetcher = t, this.baseUrl = e.replace(/\/$/, "");
	}
	async capabilities() {
		let e = await Bp(await this.request("/capabilities", {
			headers: { Accept: "application/json" },
			method: "GET"
		}));
		if (e.vocabulary_version !== Lp) throw new Rp("incompatible_vocabulary", `Goldilocks Core reports vocabulary_version ${e.vocabulary_version}, but this Workbench build expects ${Lp}. The frontend and backend were built against different contracts -- regenerate the Workbench's API types against this server.`, !1, { serverVocabularyVersion: e.vocabulary_version });
		return e;
	}
	async inspectStructure(e) {
		return Vp(await this.request("/inspect", {
			body: JSON.stringify(e),
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json"
			},
			method: "POST"
		}));
	}
	async explain(e) {
		return Bp(await this.request("/explain", {
			body: JSON.stringify(e),
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json"
			},
			method: "POST"
		}));
	}
	async magneticOrderings(e) {
		return Bp(await this.request("/magnetic-orderings", {
			body: JSON.stringify(e),
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json"
			},
			method: "POST"
		}));
	}
	async run(e) {
		return Bp(await this.request("/run", {
			body: JSON.stringify({
				...e,
				respond_with: "json"
			}),
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json"
			},
			method: "POST"
		}));
	}
	async runArchive(e) {
		return Kp(await this.request("/run", {
			body: JSON.stringify({
				...e,
				respond_with: "archive"
			}),
			headers: {
				Accept: "application/zip",
				"Content-Type": "application/json"
			},
			method: "POST"
		}), e);
	}
	async request(e, t) {
		let n;
		try {
			n = await this.fetcher(`${this.baseUrl}${e}`, t);
		} catch (e) {
			throw new Rp("network_error", e instanceof Error ? `Cannot reach Goldilocks Core: ${e.message}` : "Cannot reach Goldilocks Core.", !0);
		}
		return await Up(n), n;
	}
};
async function Bp(e) {
	if (!(e.headers.get("content-type") ?? "").toLowerCase().startsWith("application/json")) {
		let t = await Wp(e);
		throw Jp(e.status, "returned an invalid JSON response", t);
	}
	try {
		return await e.json();
	} catch {
		throw Jp(e.status, "returned unreadable JSON");
	}
}
async function Vp(e) {
	let t = await Bp(e);
	return Hp(t, e.status), t;
}
function Hp(e, t) {
	if (typeof e != "object" || !e || !("schema_version" in e) || e.schema_version !== 1) throw Jp(t, "returned an incompatible schema version", e);
}
async function Up(e) {
	if (e.ok) return;
	let t = await Wp(e);
	if (Gp(t)) {
		let { error: n } = t;
		throw new Rp(n.kind, n.message, e.status >= 500, n.details ?? {}, e.status, t);
	}
	throw new Rp("http_error", `The Goldilocks Core server rejected the request (${String(e.status)}).`, e.status >= 500, { status: e.status }, e.status, t);
}
async function Wp(e) {
	let t = await e.text();
	try {
		return JSON.parse(t);
	} catch {
		return t;
	}
}
function Gp(e) {
	if (typeof e != "object" || !e || !("error" in e)) return !1;
	let t = e.error;
	return typeof t == "object" && !!t && "kind" in t && typeof t.kind == "string" && "message" in t && typeof t.message == "string";
}
async function Kp(e, t) {
	if (!(e.headers.get("content-type") ?? "").toLowerCase().startsWith("application/zip")) throw Jp(e.status, "returned an invalid archive response");
	let n;
	try {
		n = await e.blob();
	} catch {
		throw Jp(e.status, "returned unreadable archive data");
	}
	return {
		blob: n,
		filename: `${qp(t)}.zip`
	};
}
function qp(e) {
	let t = e.structure_name.replace(/[^a-zA-Z0-9._-]+/g, "_"), n = e.task;
	return t.length > 0 ? `${t}-${n}` : `goldilocks-${n}`;
}
function Jp(e, t, n) {
	return new Rp("invalid_response", `Goldilocks Core ${t}.`, !1, {}, e, n);
}
//#endregion
//#region src/workspace/workspace.ts
var Yp = {
	capabilities: null,
	structureInput: null,
	attemptedStructureInput: null,
	inspection: null,
	draft: null,
	reviewed: null,
	outOfDate: !1,
	lastDownload: null,
	operation: null,
	failure: null,
	failureOperation: null,
	magneticOrderings: null,
	magneticOrderingsOperation: null,
	magneticOrderingsError: null
};
function Xp(e) {
	return {
		code: e.codes[0]?.id ?? "quantum_espresso",
		task: e.tasks[0]?.id ?? "scf_single_point",
		hpc: null,
		overrides: {},
		fetchMissing: !1
	};
}
function Zp(e, t) {
	return {
		structure_content: e.structure_content,
		structure_name: e.structure_name,
		...e.structure_format ? { structure_format: e.structure_format } : {},
		code: t.code,
		task: t.task,
		hpc: t.hpc,
		overrides: t.overrides,
		fetch_missing: t.fetchMissing
	};
}
function Qp(e, t) {
	return {
		structure_content: e.structure_content,
		structure_name: e.structure_name,
		...e.structure_format ? { structure_format: e.structure_format } : {},
		rank_with_mmace: t
	};
}
function $p(e) {
	return e instanceof Rp ? e.message : "Cannot reach Goldilocks Core.";
}
function em(e, t) {
	let n = {
		...e,
		...t
	};
	return Object.fromEntries(Object.entries(n).filter(([, e]) => e !== void 0));
}
function tm(e, t = nm) {
	let n = Ip(() => Yp), r = null, i = null, a = 0;
	function o(e) {
		let t = { operation: e };
		return r = t, n.setState({
			operation: e,
			failure: null,
			failureOperation: null
		}), t;
	}
	function s(e, t = {}) {
		r === e && (r = null, n.setState({
			...t,
			operation: null
		}));
	}
	function c(e, t) {
		if (r === e) {
			if (!(t instanceof Rp)) throw s(e), t;
			s(e, {
				failure: t,
				failureOperation: e.operation
			});
		}
	}
	function l() {
		if (n.getState().capabilities !== null) return Promise.resolve();
		if (i !== null) return i.promise;
		let t = o("capabilities"), r = e.capabilities().then((e) => {
			i?.owner === t && (i = null), s(t, {
				capabilities: e,
				draft: Xp(e)
			});
		}, (e) => {
			i?.owner === t && (i = null), c(t, e);
		});
		return i = {
			owner: t,
			promise: r
		}, r;
	}
	async function u(t) {
		let i = n.getState().capabilities;
		if (i === null) return;
		let l = o("inspect");
		n.setState({ attemptedStructureInput: t });
		try {
			let n = await e.inspectStructure(t);
			if (r !== l) return;
			a = 0, s(l, {
				structureInput: t,
				attemptedStructureInput: null,
				inspection: n,
				draft: Xp(i),
				reviewed: null,
				outOfDate: !1,
				lastDownload: null,
				magneticOrderings: null,
				magneticOrderingsOperation: null,
				magneticOrderingsError: null
			});
		} catch (e) {
			c(l, e);
		}
	}
	function d(e) {
		let t = n.getState(), r = t.draft;
		if (r === null || t.operation === "inspect") return;
		a += 1;
		let i = {
			...r,
			..."code" in e ? { code: e.code } : {},
			..."task" in e ? { task: e.task } : {},
			..."hpc" in e ? { hpc: e.hpc } : {},
			overrides: e.overrides === void 0 ? r.overrides : em(r.overrides, e.overrides)
		};
		n.setState({
			draft: i,
			outOfDate: t.reviewed !== null,
			failure: null,
			failureOperation: null
		});
	}
	async function f() {
		let t = n.getState();
		if (t.structureInput === null || t.draft === null || t.operation !== null) return;
		let r = a, i = Zp(t.structureInput, t.draft), l = o("explain");
		try {
			s(l, {
				reviewed: await e.explain(i),
				outOfDate: r !== a,
				lastDownload: null
			});
		} catch (e) {
			c(l, e);
		}
	}
	async function p() {
		let t = n.getState();
		if (t.structureInput === null || t.draft === null || t.reviewed === null || t.outOfDate || t.operation !== null) return null;
		let r = a, i = Zp(t.structureInput, t.draft), l = o("download");
		try {
			let t = await e.runArchive(i), n = r !== a;
			return s(l, {
				lastDownload: t,
				outOfDate: n
			}), n ? null : t;
		} catch (e) {
			return c(l, e), null;
		}
	}
	async function m() {
		let e = n.getState();
		if (e.outOfDate) return;
		let r = e.lastDownload ?? await p();
		r !== null && t(r);
	}
	async function h(t) {
		let r = n.getState();
		if (r.structureInput === null || r.magneticOrderingsOperation !== null) return;
		let i = Qp(r.structureInput, t);
		n.setState({
			magneticOrderingsOperation: t ? "rank" : "list",
			magneticOrderingsError: null
		});
		try {
			let t = await e.magneticOrderings(i);
			n.setState({
				magneticOrderings: t,
				magneticOrderingsOperation: null
			});
		} catch (e) {
			n.setState({
				magneticOrderingsOperation: null,
				magneticOrderingsError: $p(e)
			});
		}
	}
	async function g(r) {
		let i = n.getState(), { structureInput: a, draft: o, magneticOrderings: s } = i;
		if (a !== null && o !== null && s !== null && i.magneticOrderingsOperation === null && r.length !== 0) {
			n.setState({
				magneticOrderingsOperation: "download",
				magneticOrderingsError: null
			});
			try {
				let i = s.candidates.filter((e) => r.includes(e.label)), c = await Promise.all(i.map((t) => e.runArchive({
					structure_content: t.structure_content,
					structure_name: `${a.structure_name}-${t.label}`,
					structure_format: t.structure_format,
					code: o.code,
					task: o.task,
					hpc: o.hpc,
					overrides: {
						...o.overrides,
						...t.overrides
					},
					fetch_missing: o.fetchMissing
				})));
				for (let e of c) t(e);
				n.setState({ magneticOrderingsOperation: null });
			} catch (e) {
				n.setState({
					magneticOrderingsOperation: null,
					magneticOrderingsError: $p(e)
				});
			}
		}
	}
	async function _() {
		let { failureOperation: e, attemptedStructureInput: t } = n.getState();
		switch (e) {
			case "capabilities": return l();
			case "inspect":
				t !== null && await u(t);
				return;
			case "explain": return f();
			case "download": return m();
			case null: return;
		}
	}
	async function v() {
		let e = n.getState().capabilities, t = i !== null && r === i.owner ? i : null;
		a = 0, t === null && (r = null, i = null), n.setState({
			...Yp,
			capabilities: e,
			operation: t?.owner.operation ?? null
		}, !0), e === null && t === null && await l();
	}
	async function y(e) {
		switch (e.type) {
			case "workspace.start":
				await l();
				return;
			case "source.open":
				await u(e.input);
				return;
			case "draft.patch":
				d(e);
				return;
			case "review.compute":
				await f();
				return;
			case "review.refreshArchive":
				await p();
				return;
			case "review.download":
				await m();
				return;
			case "magneticOrderings.list":
				await h(!1);
				return;
			case "magneticOrderings.rank":
				await h(!0);
				return;
			case "magneticOrderings.downloadSelected":
				await g(e.labels);
				return;
			case "failure.retry": return _();
			case "failure.dismiss":
				if (n.getState().capabilities === null) return;
				n.setState({
					attemptedStructureInput: null,
					failure: null,
					failureOperation: null
				});
				return;
			case "workspace.reset": return v();
		}
	}
	return {
		getSnapshot: n.getState,
		subscribe(e) {
			return n.subscribe(e);
		},
		dispatch: y
	};
}
function nm(e) {
	let t = URL.createObjectURL(e.blob), n = document.createElement("a");
	n.href = t, n.download = e.filename, n.hidden = !0, document.body.append(n), n.click(), n.remove(), URL.revokeObjectURL(t);
}
//#endregion
export { jp as App, od as CalculationContextControls, zp as HttpCoreClient, fn as MantineProvider, Mp as WorkbenchContent, Pp as WorkspaceProvider, Ep as colorSchemeManager, tm as createWorkspace, Wu as useWorkspace, Gu as useWorkspaceSnapshot, Dp as workbenchTheme };
