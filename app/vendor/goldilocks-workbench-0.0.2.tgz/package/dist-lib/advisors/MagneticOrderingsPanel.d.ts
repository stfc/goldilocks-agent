/** #87 layer 4: lists candidate magnetic orderings (FM plus any AFM
 * candidates enumerate_magnetic_orderings finds) for the currently
 * inspected structure, with an opt-in "Rank with mMACE" pass and a
 * multi-select bundle download -- see workspace.ts's
 * `magneticOrderings.*` actions for the request/response plumbing.
 * Rendered inside `MagneticOrderingsCard`, which owns the heading --
 * this component starts directly with its content. */
export declare function MagneticOrderingsPanel(): import('react').JSX.Element | null;
