import { WorkspaceOperation } from '../workspace/workspace';
export declare function OperationStatus({ operation, hasFailure, }: {
    readonly operation: WorkspaceOperation | null;
    readonly hasFailure: boolean;
}): import('react').JSX.Element;
