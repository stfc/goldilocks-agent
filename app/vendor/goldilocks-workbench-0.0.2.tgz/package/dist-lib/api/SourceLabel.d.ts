import { Source } from './coreClient';
/** Its own file (not `sourceNames.ts`, which stays a plain constant) so
 * a plain-string consumer (e.g. an `aria-label`) can still read
 * `SOURCE_NAMES.ml` directly without pulling in JSX, and this file
 * -- which does export a component -- never mixes that with a
 * non-component export (`react-refresh/only-export-components`). */
export declare function SourceLabel({ source }: {
    readonly source: Source;
}): import('react').JSX.Element;
