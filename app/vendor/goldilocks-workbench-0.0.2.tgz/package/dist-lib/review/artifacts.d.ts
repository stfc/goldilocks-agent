import { ArchiveDownload } from '../api/coreClient';
/** Mirrors `goldilocks.json`'s shape, written by `bundle.py`'s
 * `bundle_files` -- the manifest v1's combined /compute response used
 * to hand back as JSON is now only ever found inside the downloaded
 * archive itself (v2's `/run` never returns JSON and a file's bytes in
 * the same response). */
export interface InputManifest {
    readonly schema_version: number;
    readonly records: Readonly<Record<string, unknown>>;
    readonly warnings: readonly unknown[];
    readonly citations: readonly string[];
    readonly files: Readonly<Record<string, {
        readonly role: string;
        readonly sha256: string;
        readonly size_bytes: number;
    }>>;
}
export interface ArchiveFile {
    readonly path: string;
    readonly content: string;
}
export interface ArchiveContents {
    readonly manifest: InputManifest | null;
    readonly files: readonly ArchiveFile[];
}
/** Unzips a downloaded archive client-side to recover per-file text and
 * `goldilocks.json`'s manifest -- purely a presentation concern (the
 * API client only ever hands back the raw zip bytes it was given). */
export declare function unzipArchive(archive: ArchiveDownload): Promise<ArchiveContents>;
export declare function artifactMetadata(manifest: InputManifest | null, filename: string): {
    sha256: string | undefined;
    size_bytes: number | undefined;
} | undefined;
