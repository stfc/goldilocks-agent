import { ResolvedField } from '../api/coreClient';
/** One resolved record as a collapsed-by-default accordion item --
 * status dot + human name in the always-visible control, full detail
 * (value, source, per-field sources) behind the expand. Used by
 * AnalysisSection for its read-only records; the Advisors card
 * (CalculationForm's SettingsGroupItems) has its own bespoke inline
 * Accordion instead of this component -- a follow-up could unify the
 * two, but that's out of scope here. */
export declare function RecordAccordionItem({ name, field, }: {
    readonly name: string;
    readonly field: ResolvedField;
}): import('react').JSX.Element;
