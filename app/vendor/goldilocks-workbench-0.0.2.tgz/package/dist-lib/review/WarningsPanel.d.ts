import { AdvisorWarning } from '../api/coreClient';
export declare function WarningsPanel({ warnings, }: {
    readonly warnings: readonly AdvisorWarning[];
}): import('react').JSX.Element | null;
