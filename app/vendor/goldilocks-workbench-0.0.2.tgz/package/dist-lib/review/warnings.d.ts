import { AdvisorWarning } from '../api/coreClient';
export declare function isAdvisorWarning(value: unknown): value is AdvisorWarning;
export declare const WARNING_LEVEL_COLORS: Readonly<Record<AdvisorWarning["level"], string>>;
