export declare function readableName(value: string): string;
