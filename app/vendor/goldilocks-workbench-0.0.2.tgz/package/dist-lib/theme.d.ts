export type Theme = "light" | "dark";
export declare const colorSchemeManager: import('@mantine/core').MantineColorSchemeManager;
export declare const workbenchTheme: {
    focusRing?: "auto" | "always" | "never";
    scale?: number;
    fontSmoothing?: boolean;
    white?: string;
    black?: string;
    colors?: {
        [x: string & {}]: import('@mantine/core').MantineColorsTuple | undefined;
        blue?: import('@mantine/core').MantineColorsTuple;
        cyan?: import('@mantine/core').MantineColorsTuple;
        gray?: import('@mantine/core').MantineColorsTuple;
        green?: import('@mantine/core').MantineColorsTuple;
        indigo?: import('@mantine/core').MantineColorsTuple;
        lime?: import('@mantine/core').MantineColorsTuple;
        orange?: import('@mantine/core').MantineColorsTuple;
        pink?: import('@mantine/core').MantineColorsTuple;
        red?: import('@mantine/core').MantineColorsTuple;
        teal?: import('@mantine/core').MantineColorsTuple;
        violet?: import('@mantine/core').MantineColorsTuple;
        yellow?: import('@mantine/core').MantineColorsTuple;
        dark?: import('@mantine/core').MantineColorsTuple;
        grape?: import('@mantine/core').MantineColorsTuple;
    };
    primaryShade?: import('@mantine/core').MantineColorShade | {
        light?: import('@mantine/core').MantineColorShade;
        dark?: import('@mantine/core').MantineColorShade;
    };
    primaryColor?: string;
    variantColorResolver?: import('@mantine/core').VariantColorsResolver;
    autoContrast?: boolean;
    luminanceThreshold?: number;
    fontFamily?: string;
    fontFamilyMonospace?: string;
    headings?: {
        fontFamily?: string;
        fontWeight?: string;
        textWrap?: "wrap" | "nowrap" | "balance" | "pretty" | "stable";
        sizes?: {
            h1?: {
                fontSize?: string;
                fontWeight?: string;
                lineHeight?: string;
            };
            h2?: {
                fontSize?: string;
                fontWeight?: string;
                lineHeight?: string;
            };
            h3?: {
                fontSize?: string;
                fontWeight?: string;
                lineHeight?: string;
            };
            h4?: {
                fontSize?: string;
                fontWeight?: string;
                lineHeight?: string;
            };
            h5?: {
                fontSize?: string;
                fontWeight?: string;
                lineHeight?: string;
            };
            h6?: {
                fontSize?: string;
                fontWeight?: string;
                lineHeight?: string;
            };
        };
    };
    radius?: {
        [x: string & {}]: string | undefined;
        xs?: string;
        sm?: string;
        md?: string;
        lg?: string;
        xl?: string;
    };
    defaultRadius?: import('@mantine/core').MantineRadius;
    spacing?: {
        [x: number]: string | undefined;
        [x: string & {}]: string | undefined;
        xs?: string;
        sm?: string;
        md?: string;
        lg?: string;
        xl?: string;
    };
    fontSizes?: {
        [x: string & {}]: string | undefined;
        xs?: string;
        sm?: string;
        md?: string;
        lg?: string;
        xl?: string;
    };
    lineHeights?: {
        [x: string & {}]: string | undefined;
        xs?: string;
        sm?: string;
        md?: string;
        lg?: string;
        xl?: string;
    };
    fontWeights?: {
        [x: string & {}]: string | undefined;
        bold?: string;
        regular?: string;
        medium?: string;
    };
    breakpoints?: {
        [x: string & {}]: string | undefined;
        xs?: string;
        sm?: string;
        md?: string;
        lg?: string;
        xl?: string;
    };
    shadows?: {
        [x: string & {}]: string | undefined;
        xs?: string;
        sm?: string;
        md?: string;
        lg?: string;
        xl?: string;
    };
    respectReducedMotion?: boolean;
    cursorType?: "default" | "pointer";
    defaultGradient?: {
        from?: string;
        to?: string;
        deg?: number;
    };
    activeClassName?: string;
    focusClassName?: string;
    components?: {
        [x: string]: {
            classNames?: any;
            styles?: any;
            vars?: any;
            defaultProps?: any;
        } | undefined;
    };
    other?: {
        [x: string]: any;
    };
};
