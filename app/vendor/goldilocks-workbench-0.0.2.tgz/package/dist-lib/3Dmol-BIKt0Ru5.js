import { t as __commonJSMin } from "./rolldown-runtime-DtPi1Y-2.js";
//#region node_modules/3dmol/build/3Dmol.js
var require__3Dmol = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(e, t) {
		typeof exports == "object" && typeof module == "object" ? module.exports = t() : typeof define == "function" && define.amd ? define([], t) : typeof exports == "object" ? exports["3Dmol"] = t() : e["3Dmol"] = t();
	})(exports, () => (() => {
		var __webpack_modules__ = {
			"./node_modules/iobuffer/lib-esm/IOBuffer.js"(e, t, n) {
				n.r(t), n.d(t, { IOBuffer: () => s });
				var r = n("./node_modules/iobuffer/lib-esm/text.js");
				let i = 8192, a = (() => {
					let e = /* @__PURE__ */ new Uint8Array(4), t = new Uint32Array(e.buffer);
					return !((t[0] = 1) & e[0]);
				})(), o = {
					int8: globalThis.Int8Array,
					uint8: globalThis.Uint8Array,
					int16: globalThis.Int16Array,
					uint16: globalThis.Uint16Array,
					int32: globalThis.Int32Array,
					uint32: globalThis.Uint32Array,
					uint64: globalThis.BigUint64Array,
					int64: globalThis.BigInt64Array,
					float32: globalThis.Float32Array,
					float64: globalThis.Float64Array
				};
				class s {
					buffer;
					byteLength;
					byteOffset;
					length;
					offset;
					lastWrittenByte;
					littleEndian;
					_data;
					_mark;
					_marks;
					constructor(e = 8192, t = {}) {
						let n = !1;
						typeof e == "number" ? e = new ArrayBuffer(e) : (n = !0, this.lastWrittenByte = e.byteLength);
						let r = t.offset ? t.offset >>> 0 : 0, i = e.byteLength - r, a = r;
						(ArrayBuffer.isView(e) || e instanceof s) && (e.byteLength !== e.buffer.byteLength && (a = e.byteOffset + r), e = e.buffer), this.lastWrittenByte = n ? i : 0, this.buffer = e, this.length = i, this.byteLength = i, this.byteOffset = a, this.offset = 0, this.littleEndian = !0, this._data = new DataView(this.buffer, a, i), this._mark = 0, this._marks = [];
					}
					available(e = 1) {
						return this.offset + e <= this.length;
					}
					isLittleEndian() {
						return this.littleEndian;
					}
					setLittleEndian() {
						return this.littleEndian = !0, this;
					}
					isBigEndian() {
						return !this.littleEndian;
					}
					setBigEndian() {
						return this.littleEndian = !1, this;
					}
					skip(e = 1) {
						return this.offset += e, this;
					}
					back(e = 1) {
						return this.offset -= e, this;
					}
					seek(e) {
						return this.offset = e, this;
					}
					mark() {
						return this._mark = this.offset, this;
					}
					reset() {
						return this.offset = this._mark, this;
					}
					pushMark() {
						return this._marks.push(this.offset), this;
					}
					popMark() {
						let e = this._marks.pop();
						if (e === void 0) throw Error("Mark stack empty");
						return this.seek(e), this;
					}
					rewind() {
						return this.offset = 0, this;
					}
					ensureAvailable(e = 1) {
						if (!this.available(e)) {
							let t = (this.offset + e) * 2, n = new Uint8Array(t);
							n.set(new Uint8Array(this.buffer)), this.buffer = n.buffer, this.length = t, this.byteLength = t, this._data = new DataView(this.buffer);
						}
						return this;
					}
					readBoolean() {
						return this.readUint8() !== 0;
					}
					readInt8() {
						return this._data.getInt8(this.offset++);
					}
					readUint8() {
						return this._data.getUint8(this.offset++);
					}
					readByte() {
						return this.readUint8();
					}
					readBytes(e = 1) {
						return this.readArray(e, "uint8");
					}
					readArray(e, t) {
						let n = o[t].BYTES_PER_ELEMENT * e, r = this.byteOffset + this.offset, i = this.buffer.slice(r, r + n);
						if (this.littleEndian === a && t !== "uint8" && t !== "int8") {
							let e = new Uint8Array(this.buffer.slice(r, r + n));
							e.reverse();
							let i = new o[t](e.buffer);
							return this.offset += n, i.reverse(), i;
						}
						let s = new o[t](i);
						return this.offset += n, s;
					}
					readInt16() {
						let e = this._data.getInt16(this.offset, this.littleEndian);
						return this.offset += 2, e;
					}
					readUint16() {
						let e = this._data.getUint16(this.offset, this.littleEndian);
						return this.offset += 2, e;
					}
					readInt32() {
						let e = this._data.getInt32(this.offset, this.littleEndian);
						return this.offset += 4, e;
					}
					readUint32() {
						let e = this._data.getUint32(this.offset, this.littleEndian);
						return this.offset += 4, e;
					}
					readFloat32() {
						let e = this._data.getFloat32(this.offset, this.littleEndian);
						return this.offset += 4, e;
					}
					readFloat64() {
						let e = this._data.getFloat64(this.offset, this.littleEndian);
						return this.offset += 8, e;
					}
					readBigInt64() {
						let e = this._data.getBigInt64(this.offset, this.littleEndian);
						return this.offset += 8, e;
					}
					readBigUint64() {
						let e = this._data.getBigUint64(this.offset, this.littleEndian);
						return this.offset += 8, e;
					}
					readChar() {
						return String.fromCharCode(this.readInt8());
					}
					readChars(e = 1) {
						let t = "";
						for (let n = 0; n < e; n++) t += this.readChar();
						return t;
					}
					readUtf8(e = 1) {
						return (0, r.decode)(this.readBytes(e));
					}
					decodeText(e = 1, t = "utf8") {
						return (0, r.decode)(this.readBytes(e), t);
					}
					writeBoolean(e) {
						return this.writeUint8(e ? 255 : 0), this;
					}
					writeInt8(e) {
						return this.ensureAvailable(1), this._data.setInt8(this.offset++, e), this._updateLastWrittenByte(), this;
					}
					writeUint8(e) {
						return this.ensureAvailable(1), this._data.setUint8(this.offset++, e), this._updateLastWrittenByte(), this;
					}
					writeByte(e) {
						return this.writeUint8(e);
					}
					writeBytes(e) {
						this.ensureAvailable(e.length);
						for (let t = 0; t < e.length; t++) this._data.setUint8(this.offset++, e[t]);
						return this._updateLastWrittenByte(), this;
					}
					writeInt16(e) {
						return this.ensureAvailable(2), this._data.setInt16(this.offset, e, this.littleEndian), this.offset += 2, this._updateLastWrittenByte(), this;
					}
					writeUint16(e) {
						return this.ensureAvailable(2), this._data.setUint16(this.offset, e, this.littleEndian), this.offset += 2, this._updateLastWrittenByte(), this;
					}
					writeInt32(e) {
						return this.ensureAvailable(4), this._data.setInt32(this.offset, e, this.littleEndian), this.offset += 4, this._updateLastWrittenByte(), this;
					}
					writeUint32(e) {
						return this.ensureAvailable(4), this._data.setUint32(this.offset, e, this.littleEndian), this.offset += 4, this._updateLastWrittenByte(), this;
					}
					writeFloat32(e) {
						return this.ensureAvailable(4), this._data.setFloat32(this.offset, e, this.littleEndian), this.offset += 4, this._updateLastWrittenByte(), this;
					}
					writeFloat64(e) {
						return this.ensureAvailable(8), this._data.setFloat64(this.offset, e, this.littleEndian), this.offset += 8, this._updateLastWrittenByte(), this;
					}
					writeBigInt64(e) {
						return this.ensureAvailable(8), this._data.setBigInt64(this.offset, e, this.littleEndian), this.offset += 8, this._updateLastWrittenByte(), this;
					}
					writeBigUint64(e) {
						return this.ensureAvailable(8), this._data.setBigUint64(this.offset, e, this.littleEndian), this.offset += 8, this._updateLastWrittenByte(), this;
					}
					writeChar(e) {
						return this.writeUint8(e.charCodeAt(0));
					}
					writeChars(e) {
						for (let t = 0; t < e.length; t++) this.writeUint8(e.charCodeAt(t));
						return this;
					}
					writeUtf8(e) {
						return this.writeBytes((0, r.encode)(e));
					}
					toArray() {
						return new Uint8Array(this.buffer, this.byteOffset, this.lastWrittenByte);
					}
					getWrittenByteLength() {
						return this.lastWrittenByte - this.byteOffset;
					}
					_updateLastWrittenByte() {
						this.offset > this.lastWrittenByte && (this.lastWrittenByte = this.offset);
					}
				}
			},
			"./node_modules/iobuffer/lib-esm/text.js"(e, t, n) {
				n.r(t), n.d(t, {
					decode: () => r,
					encode: () => a
				});
				function r(e, t = "utf8") {
					return new TextDecoder(t).decode(e);
				}
				let i = new TextEncoder();
				function a(e) {
					return i.encode(e);
				}
			},
			"./node_modules/netcdfjs/lib-esm/data.js"(e, t, n) {
				n.r(t), n.d(t, {
					nonRecord: () => i,
					record: () => a
				});
				var r = n("./node_modules/netcdfjs/lib-esm/types.js");
				function i(e, t) {
					let n = (0, r.str2num)(t.type), i = t.size / (0, r.num2bytes)(n), a = Array(i);
					for (let t = 0; t < i; t++) a[t] = (0, r.readType)(e, n, 1);
					return a;
				}
				function a(e, t, n) {
					let i = (0, r.str2num)(t.type), a = t.size ? t.size / (0, r.num2bytes)(i) : 1, o = n.length, s = Array(o), c = n.recordStep;
					if (c) for (let t = 0; t < o; t++) {
						let n = e.offset;
						s[t] = (0, r.readType)(e, i, a), e.seek(n + c);
					}
					else throw Error("recordDimension.recordStep is undefined");
					return s;
				}
			},
			"./node_modules/netcdfjs/lib-esm/header.js"(e, t, n) {
				n.r(t), n.d(t, { header: () => u });
				var r = n("./node_modules/netcdfjs/lib-esm/types.js"), i = n("./node_modules/netcdfjs/lib-esm/utils.js");
				let a = 0, o = 10, s = 11, c = 12, l = 0;
				function u(e, t) {
					let n = { version: t }, r = { length: e.readUint32() }, i = d(e);
					Array.isArray(i) || (r.id = i.recordId, r.name = i.recordName, n.dimensions = i.dimensions), n.globalAttributes = f(e);
					let a = p(e, r?.id, t);
					return Array.isArray(a) || (n.variables = a.variables, r.recordStep = a.recordStep), n.recordDimension = r, n;
				}
				function d(e) {
					let t = {}, n, r, a = e.readUint32(), o;
					if (a === 0) return (0, i.notNetcdf)(e.readUint32() !== 0, "wrong empty tag for list of dimensions"), [];
					{
						(0, i.notNetcdf)(a !== 10, "wrong tag for list of dimensions");
						let t = e.readUint32();
						o = Array(t);
						for (let a = 0; a < t; a++) {
							let t = (0, i.readName)(e), s = e.readUint32();
							s === 0 && (n = a, r = t), o[a] = {
								name: t,
								size: s
							};
						}
					}
					return n !== void 0 && (t.recordId = n), r !== void 0 && (t.recordName = r), t.dimensions = o, t;
				}
				function f(e) {
					let t = e.readUint32(), n;
					if (t === 0) return (0, i.notNetcdf)(e.readUint32() !== 0, "wrong empty tag for list of attributes"), [];
					{
						(0, i.notNetcdf)(t !== 12, "wrong tag for list of attributes");
						let a = e.readUint32();
						n = Array(a);
						for (let t = 0; t < a; t++) {
							let a = (0, i.readName)(e), o = e.readUint32();
							(0, i.notNetcdf)(o < 1 || o > 6, `non valid type ${o}`);
							let s = e.readUint32(), c = (0, r.readType)(e, o, s);
							(0, i.padding)(e), n[t] = {
								name: a,
								type: (0, r.num2str)(o),
								value: c
							};
						}
					}
					return n;
				}
				function p(e, t, n) {
					let a = e.readUint32(), o = 0, s;
					if (a === 0) return (0, i.notNetcdf)(e.readUint32() !== 0, "wrong empty tag for list of variables"), [];
					{
						(0, i.notNetcdf)(a !== 11, "wrong tag for list of variables");
						let c = e.readUint32();
						s = Array(c);
						for (let a = 0; a < c; a++) {
							let c = (0, i.readName)(e), l = e.readUint32(), u = Array(l);
							for (let t = 0; t < l; t++) u[t] = e.readUint32();
							let d = f(e), p = e.readUint32();
							(0, i.notNetcdf)(p < 1 && p > 6, `non valid type ${p}`);
							let m = e.readUint32(), h = e.readUint32();
							n === 2 && ((0, i.notNetcdf)(h > 0, "offsets larger than 4GB not supported"), h = e.readUint32());
							let g = !1;
							t !== void 0 && u[0] === t && (o += m, g = !0), s[a] = {
								name: c,
								dimensions: u,
								attributes: d,
								type: (0, r.num2str)(p),
								size: m,
								offset: h,
								record: g
							};
						}
					}
					return {
						variables: s,
						recordStep: o
					};
				}
			},
			"./node_modules/netcdfjs/lib-esm/index.js"(e, t, n) {
				n.r(t), n.d(t, { NetCDFReader: () => r.NetCDFReader });
				var r = n("./node_modules/netcdfjs/lib-esm/parser.js");
			},
			"./node_modules/netcdfjs/lib-esm/parser.js"(e, t, n) {
				n.r(t), n.d(t, { NetCDFReader: () => c });
				var r = n("./node_modules/iobuffer/lib-esm/IOBuffer.js"), i = n("./node_modules/netcdfjs/lib-esm/data.js"), a = n("./node_modules/netcdfjs/lib-esm/header.js"), o = n("./node_modules/netcdfjs/lib-esm/toString.js"), s = n("./node_modules/netcdfjs/lib-esm/utils.js");
				class c {
					constructor(e) {
						this.toString = o.toString;
						let t = new r.IOBuffer(e);
						t.setBigEndian(), (0, s.notNetcdf)(t.readChars(3) !== "CDF", "should start with CDF");
						let n = t.readByte();
						(0, s.notNetcdf)(n > 2, "unknown version"), this.header = (0, a.header)(t, n), this.buffer = t;
					}
					get version() {
						return this.header.version === 1 ? "classic format" : "64-bit offset format";
					}
					get recordDimension() {
						return this.header.recordDimension;
					}
					get dimensions() {
						return this.header.dimensions;
					}
					get globalAttributes() {
						return this.header.globalAttributes;
					}
					getAttribute(e) {
						let t = this.globalAttributes.find((t) => t.name === e);
						return t ? t.value : null;
					}
					getDataVariableAsString(e) {
						let t = this.getDataVariable(e);
						return t ? t.join("") : null;
					}
					get variables() {
						return this.header.variables;
					}
					getDataVariable(e) {
						let t;
						if (t = typeof e == "string" ? this.header.variables.find((t) => t.name === e) : e, t === void 0) throw Error("Not a valid NetCDF v3.x file: variable not found");
						return this.buffer.seek(t.offset), t.record ? (0, i.record)(this.buffer, t, this.header.recordDimension) : (0, i.nonRecord)(this.buffer, t);
					}
					dataVariableExists(e) {
						return this.header.variables.find((t) => t.name === e) !== void 0;
					}
					attributeExists(e) {
						return this.globalAttributes.find((t) => t.name === e) !== void 0;
					}
				}
			},
			"./node_modules/netcdfjs/lib-esm/toString.js"(e, t, n) {
				n.r(t), n.d(t, { toString: () => r });
				function r() {
					let e = [];
					e.push("DIMENSIONS");
					for (let t of this.dimensions) e.push(`  ${t.name.padEnd(30)} = size: ${t.size}`);
					e.push(""), e.push("GLOBAL ATTRIBUTES");
					for (let t of this.globalAttributes) e.push(`  ${t.name.padEnd(30)} = ${t.value}`);
					let t = JSON.parse(JSON.stringify(this.variables));
					e.push(""), e.push("VARIABLES:");
					for (let n of t) {
						n.value = this.getDataVariable(n);
						let t = JSON.stringify(n.value);
						t.length > 50 && (t = t.substring(0, 50)), isNaN(n.value.length) || (t += ` (length: ${n.value.length})`), e.push(`  ${n.name.padEnd(30)} = ${t}`);
					}
					return e.join("\n");
				}
			},
			"./node_modules/netcdfjs/lib-esm/types.js"(e, t, n) {
				n.r(t), n.d(t, {
					num2bytes: () => a,
					num2str: () => i,
					readType: () => c,
					str2num: () => o
				});
				let r = {
					BYTE: 1,
					CHAR: 2,
					SHORT: 3,
					INT: 4,
					FLOAT: 5,
					DOUBLE: 6
				};
				function i(e) {
					switch (Number(e)) {
						case r.BYTE: return "byte";
						case r.CHAR: return "char";
						case r.SHORT: return "short";
						case r.INT: return "int";
						case r.FLOAT: return "float";
						case r.DOUBLE: return "double";
						default: return "undefined";
					}
				}
				function a(e) {
					switch (Number(e)) {
						case r.BYTE: return 1;
						case r.CHAR: return 1;
						case r.SHORT: return 2;
						case r.INT: return 4;
						case r.FLOAT: return 4;
						case r.DOUBLE: return 8;
						default: return -1;
					}
				}
				function o(e) {
					switch (String(e)) {
						case "byte": return r.BYTE;
						case "char": return r.CHAR;
						case "short": return r.SHORT;
						case "int": return r.INT;
						case "float": return r.FLOAT;
						case "double": return r.DOUBLE;
						/* istanbul ignore next */
						default: return -1;
					}
				}
				function s(e, t) {
					if (e !== 1) {
						let n = Array(e);
						for (let r = 0; r < e; r++) n[r] = t();
						return n;
					}
					return t();
				}
				function c(e, t, n) {
					switch (t) {
						case r.BYTE: return Array.from(e.readBytes(n));
						case r.CHAR: return l(e.readChars(n));
						case r.SHORT: return s(n, e.readInt16.bind(e));
						case r.INT: return s(n, e.readInt32.bind(e));
						case r.FLOAT: return s(n, e.readFloat32.bind(e));
						case r.DOUBLE: return s(n, e.readFloat64.bind(e));
						default: throw Error(`non valid type ${t}`);
					}
				}
				function l(e) {
					return e.charCodeAt(e.length - 1) === 0 ? e.substring(0, e.length - 1) : e;
				}
			},
			"./node_modules/netcdfjs/lib-esm/utils.js"(e, t, n) {
				n.r(t), n.d(t, {
					notNetcdf: () => r,
					padding: () => i,
					readName: () => a
				});
				function r(e, t) {
					if (e) throw TypeError(`Not a valid NetCDF v3.x file: ${t}`);
				}
				function i(e) {
					e.offset % 4 != 0 && e.skip(4 - e.offset % 4);
				}
				function a(e) {
					let t = e.readUint32(), n = e.readChars(t);
					return i(e), n;
				}
			},
			"./node_modules/pako/dist/pako.esm.mjs"(e, t, n) {
				n.r(t), n.d(t, {
					Deflate: () => ri,
					Inflate: () => si,
					constants: () => di,
					default: () => fi,
					deflate: () => ii,
					deflateRaw: () => ai,
					gzip: () => oi,
					inflate: () => ci,
					inflateRaw: () => li,
					ungzip: () => ui
				});
				let r = 4, i = 0, a = 1, o = 2;
				function s(e) {
					let t = e.length;
					for (; --t >= 0;) e[t] = 0;
				}
				let c = 0, l = 1, u = 2, d = 3, f = 258, p = 29, m = 256, h = 286, g = 30, _ = 19, v = 573, y = 15, b = 16, x = 7, S = 256, C = 16, w = 17, T = 18, E = new Uint8Array([
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					1,
					1,
					1,
					1,
					2,
					2,
					2,
					2,
					3,
					3,
					3,
					3,
					4,
					4,
					4,
					4,
					5,
					5,
					5,
					5,
					0
				]), D = new Uint8Array([
					0,
					0,
					0,
					0,
					1,
					1,
					2,
					2,
					3,
					3,
					4,
					4,
					5,
					5,
					6,
					6,
					7,
					7,
					8,
					8,
					9,
					9,
					10,
					10,
					11,
					11,
					12,
					12,
					13,
					13
				]), O = new Uint8Array([
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					2,
					3,
					7
				]), k = new Uint8Array([
					16,
					17,
					18,
					0,
					8,
					7,
					9,
					6,
					10,
					5,
					11,
					4,
					12,
					3,
					13,
					2,
					14,
					1,
					15
				]), A = 512, j = Array(576);
				s(j);
				let M = Array(60);
				s(M);
				let N = Array(512);
				s(N);
				let P = Array(256);
				s(P);
				let F = Array(29);
				s(F);
				let I = Array(30);
				s(I);
				function L(e, t, n, r, i) {
					this.static_tree = e, this.extra_bits = t, this.extra_base = n, this.elems = r, this.max_length = i, this.has_stree = e && e.length;
				}
				let R, z, B;
				function V(e, t) {
					this.dyn_tree = e, this.max_code = 0, this.stat_desc = t;
				}
				let H = (e) => e < 256 ? N[e] : N[256 + (e >>> 7)], U = (e, t) => {
					e.pending_buf[e.pending++] = t & 255, e.pending_buf[e.pending++] = t >>> 8 & 255;
				}, W = (e, t, n) => {
					e.bi_valid > 16 - n ? (e.bi_buf |= t << e.bi_valid & 65535, U(e, e.bi_buf), e.bi_buf = t >> 16 - e.bi_valid, e.bi_valid += n - 16) : (e.bi_buf |= t << e.bi_valid & 65535, e.bi_valid += n);
				}, G = (e, t, n) => {
					W(e, n[t * 2], n[t * 2 + 1]);
				}, ee = (e, t) => {
					let n = 0;
					do
						n |= e & 1, e >>>= 1, n <<= 1;
					while (--t > 0);
					return n >>> 1;
				}, te = (e) => {
					e.bi_valid === 16 ? (U(e, e.bi_buf), e.bi_buf = 0, e.bi_valid = 0) : e.bi_valid >= 8 && (e.pending_buf[e.pending++] = e.bi_buf & 255, e.bi_buf >>= 8, e.bi_valid -= 8);
				}, ne = (e, t) => {
					let n = t.dyn_tree, r = t.max_code, i = t.stat_desc.static_tree, a = t.stat_desc.has_stree, o = t.stat_desc.extra_bits, s = t.stat_desc.extra_base, c = t.stat_desc.max_length, l, u, d, f, p, m, h = 0;
					for (f = 0; f <= 15; f++) e.bl_count[f] = 0;
					for (n[e.heap[e.heap_max] * 2 + 1] = 0, l = e.heap_max + 1; l < 573; l++) u = e.heap[l], f = n[n[u * 2 + 1] * 2 + 1] + 1, f > c && (f = c, h++), n[u * 2 + 1] = f, !(u > r) && (e.bl_count[f]++, p = 0, u >= s && (p = o[u - s]), m = n[u * 2], e.opt_len += m * (f + p), a && (e.static_len += m * (i[u * 2 + 1] + p)));
					if (h !== 0) {
						do {
							for (f = c - 1; e.bl_count[f] === 0;) f--;
							e.bl_count[f]--, e.bl_count[f + 1] += 2, e.bl_count[c]--, h -= 2;
						} while (h > 0);
						for (f = c; f !== 0; f--) for (u = e.bl_count[f]; u !== 0;) d = e.heap[--l], !(d > r) && (n[d * 2 + 1] !== f && (e.opt_len += (f - n[d * 2 + 1]) * n[d * 2], n[d * 2 + 1] = f), u--);
					}
				}, re = (e, t, n) => {
					let r = Array(16), i = 0, a, o;
					for (a = 1; a <= 15; a++) i = i + n[a - 1] << 1, r[a] = i;
					for (o = 0; o <= t; o++) {
						let t = e[o * 2 + 1];
						t !== 0 && (e[o * 2] = ee(r[t]++, t));
					}
				}, ie = () => {
					let e, t, n, r, i, a = Array(16);
					for (n = 0, r = 0; r < 28; r++) for (F[r] = n, e = 0; e < 1 << E[r]; e++) P[n++] = r;
					for (P[n - 1] = r, i = 0, r = 0; r < 16; r++) for (I[r] = i, e = 0; e < 1 << D[r]; e++) N[i++] = r;
					for (i >>= 7; r < 30; r++) for (I[r] = i << 7, e = 0; e < 1 << D[r] - 7; e++) N[256 + i++] = r;
					for (t = 0; t <= 15; t++) a[t] = 0;
					for (e = 0; e <= 143;) j[e * 2 + 1] = 8, e++, a[8]++;
					for (; e <= 255;) j[e * 2 + 1] = 9, e++, a[9]++;
					for (; e <= 279;) j[e * 2 + 1] = 7, e++, a[7]++;
					for (; e <= 287;) j[e * 2 + 1] = 8, e++, a[8]++;
					for (re(j, 287, a), e = 0; e < 30; e++) M[e * 2 + 1] = 5, M[e * 2] = ee(e, 5);
					R = new L(j, E, 257, 286, 15), z = new L(M, D, 0, 30, 15), B = new L([], O, 0, 19, 7);
				}, K = (e) => {
					let t;
					for (t = 0; t < 286; t++) e.dyn_ltree[t * 2] = 0;
					for (t = 0; t < 30; t++) e.dyn_dtree[t * 2] = 0;
					for (t = 0; t < 19; t++) e.bl_tree[t * 2] = 0;
					e.dyn_ltree[512] = 1, e.opt_len = e.static_len = 0, e.sym_next = e.matches = 0;
				}, ae = (e) => {
					e.bi_valid > 8 ? U(e, e.bi_buf) : e.bi_valid > 0 && (e.pending_buf[e.pending++] = e.bi_buf), e.bi_buf = 0, e.bi_valid = 0;
				}, oe = (e, t, n, r) => {
					let i = t * 2, a = n * 2;
					return e[i] < e[a] || e[i] === e[a] && r[t] <= r[n];
				}, q = (e, t, n) => {
					let r = e.heap[n], i = n << 1;
					for (; i <= e.heap_len && (i < e.heap_len && oe(t, e.heap[i + 1], e.heap[i], e.depth) && i++, !oe(t, r, e.heap[i], e.depth));) e.heap[n] = e.heap[i], n = i, i <<= 1;
					e.heap[n] = r;
				}, J = (e, t, n) => {
					let r, i, a = 0, o, s;
					if (e.sym_next !== 0) do
						r = e.pending_buf[e.sym_buf + a++] & 255, r += (e.pending_buf[e.sym_buf + a++] & 255) << 8, i = e.pending_buf[e.sym_buf + a++], r === 0 ? G(e, i, t) : (o = P[i], G(e, o + 256 + 1, t), s = E[o], s !== 0 && (i -= F[o], W(e, i, s)), r--, o = H(r), G(e, o, n), s = D[o], s !== 0 && (r -= I[o], W(e, r, s)));
					while (a < e.sym_next);
					G(e, 256, t);
				}, Y = (e, t) => {
					let n = t.dyn_tree, r = t.stat_desc.static_tree, i = t.stat_desc.has_stree, a = t.stat_desc.elems, o, s, c = -1, l;
					for (e.heap_len = 0, e.heap_max = 573, o = 0; o < a; o++) n[o * 2] === 0 ? n[o * 2 + 1] = 0 : (e.heap[++e.heap_len] = c = o, e.depth[o] = 0);
					for (; e.heap_len < 2;) l = e.heap[++e.heap_len] = c < 2 ? ++c : 0, n[l * 2] = 1, e.depth[l] = 0, e.opt_len--, i && (e.static_len -= r[l * 2 + 1]);
					for (t.max_code = c, o = e.heap_len >> 1; o >= 1; o--) q(e, n, o);
					l = a;
					do
						o = e.heap[1], e.heap[1] = e.heap[e.heap_len--], q(e, n, 1), s = e.heap[1], e.heap[--e.heap_max] = o, e.heap[--e.heap_max] = s, n[l * 2] = n[o * 2] + n[s * 2], e.depth[l] = (e.depth[o] >= e.depth[s] ? e.depth[o] : e.depth[s]) + 1, n[o * 2 + 1] = n[s * 2 + 1] = l, e.heap[1] = l++, q(e, n, 1);
					while (e.heap_len >= 2);
					e.heap[--e.heap_max] = e.heap[1], ne(e, t), re(n, c, e.bl_count);
				}, se = (e, t, n) => {
					let r, i = -1, a, o = t[1], s = 0, c = 7, l = 4;
					for (o === 0 && (c = 138, l = 3), t[(n + 1) * 2 + 1] = 65535, r = 0; r <= n; r++) a = o, o = t[(r + 1) * 2 + 1], !(++s < c && a === o) && (s < l ? e.bl_tree[a * 2] += s : a === 0 ? s <= 10 ? e.bl_tree[34]++ : e.bl_tree[36]++ : (a !== i && e.bl_tree[a * 2]++, e.bl_tree[32]++), s = 0, i = a, o === 0 ? (c = 138, l = 3) : a === o ? (c = 6, l = 3) : (c = 7, l = 4));
				}, ce = (e, t, n) => {
					let r, i = -1, a, o = t[1], s = 0, c = 7, l = 4;
					for (o === 0 && (c = 138, l = 3), r = 0; r <= n; r++) if (a = o, o = t[(r + 1) * 2 + 1], !(++s < c && a === o)) {
						if (s < l) do
							G(e, a, e.bl_tree);
						while (--s !== 0);
						else a === 0 ? s <= 10 ? (G(e, 17, e.bl_tree), W(e, s - 3, 3)) : (G(e, 18, e.bl_tree), W(e, s - 11, 7)) : (a !== i && (G(e, a, e.bl_tree), s--), G(e, 16, e.bl_tree), W(e, s - 3, 2));
						s = 0, i = a, o === 0 ? (c = 138, l = 3) : a === o ? (c = 6, l = 3) : (c = 7, l = 4);
					}
				}, X = (e) => {
					let t;
					for (se(e, e.dyn_ltree, e.l_desc.max_code), se(e, e.dyn_dtree, e.d_desc.max_code), Y(e, e.bl_desc), t = 18; t >= 3 && e.bl_tree[k[t] * 2 + 1] === 0; t--);
					return e.opt_len += 3 * (t + 1) + 5 + 5 + 4, t;
				}, le = (e, t, n, r) => {
					let i;
					for (W(e, t - 257, 5), W(e, n - 1, 5), W(e, r - 4, 4), i = 0; i < r; i++) W(e, e.bl_tree[k[i] * 2 + 1], 3);
					ce(e, e.dyn_ltree, t - 1), ce(e, e.dyn_dtree, n - 1);
				}, Z = (e) => {
					let t = 4093624447, n;
					for (n = 0; n <= 31; n++, t >>>= 1) if (t & 1 && e.dyn_ltree[n * 2] !== 0) return 0;
					if (e.dyn_ltree[18] !== 0 || e.dyn_ltree[20] !== 0 || e.dyn_ltree[26] !== 0) return 1;
					for (n = 32; n < 256; n++) if (e.dyn_ltree[n * 2] !== 0) return 1;
					return 0;
				}, Q = !1, ue = (e) => {
					Q ||= (ie(), !0), e.l_desc = new V(e.dyn_ltree, R), e.d_desc = new V(e.dyn_dtree, z), e.bl_desc = new V(e.bl_tree, B), e.bi_buf = 0, e.bi_valid = 0, K(e);
				}, de = (e, t, n, r) => {
					W(e, 0 + +!!r, 3), ae(e), U(e, n), U(e, ~n), n && e.pending_buf.set(e.window.subarray(t, t + n), e.pending), e.pending += n;
				};
				var $ = {
					_tr_init: ue,
					_tr_stored_block: de,
					_tr_flush_block: (e, t, n, r) => {
						let i, a, o = 0;
						e.level > 0 ? (e.strm.data_type === 2 && (e.strm.data_type = Z(e)), Y(e, e.l_desc), Y(e, e.d_desc), o = X(e), i = e.opt_len + 3 + 7 >>> 3, a = e.static_len + 3 + 7 >>> 3, a <= i && (i = a)) : i = a = n + 5, n + 4 <= i && t !== -1 ? de(e, t, n, r) : e.strategy === 4 || a === i ? (W(e, 2 + +!!r, 3), J(e, j, M)) : (W(e, 4 + +!!r, 3), le(e, e.l_desc.max_code + 1, e.d_desc.max_code + 1, o + 1), J(e, e.dyn_ltree, e.dyn_dtree)), K(e), r && ae(e);
					},
					_tr_tally: (e, t, n) => (e.pending_buf[e.sym_buf + e.sym_next++] = t, e.pending_buf[e.sym_buf + e.sym_next++] = t >> 8, e.pending_buf[e.sym_buf + e.sym_next++] = n, t === 0 ? e.dyn_ltree[n * 2]++ : (e.matches++, t--, e.dyn_ltree[(P[n] + 256 + 1) * 2]++, e.dyn_dtree[H(t) * 2]++), e.sym_next === e.sym_end),
					_tr_align: (e) => {
						W(e, 2, 3), G(e, 256, j), te(e);
					}
				}, fe = (e, t, n, r) => {
					let i = e & 65535 | 0, a = e >>> 16 & 65535 | 0, o = 0;
					for (; n !== 0;) {
						o = n > 2e3 ? 2e3 : n, n -= o;
						do
							i = i + t[r++] | 0, a = a + i | 0;
						while (--o);
						i %= 65521, a %= 65521;
					}
					return i | a << 16 | 0;
				};
				let pe = new Uint32Array((() => {
					let e, t = [];
					for (var n = 0; n < 256; n++) {
						e = n;
						for (var r = 0; r < 8; r++) e = e & 1 ? 3988292384 ^ e >>> 1 : e >>> 1;
						t[n] = e;
					}
					return t;
				})());
				var me = (e, t, n, r) => {
					let i = pe, a = r + n;
					e ^= -1;
					for (let n = r; n < a; n++) e = e >>> 8 ^ i[(e ^ t[n]) & 255];
					return e ^ -1;
				}, he = {
					2: "need dictionary",
					1: "stream end",
					0: "",
					"-1": "file error",
					"-2": "stream error",
					"-3": "data error",
					"-4": "insufficient memory",
					"-5": "buffer error",
					"-6": "incompatible version"
				}, ge = {
					Z_NO_FLUSH: 0,
					Z_PARTIAL_FLUSH: 1,
					Z_SYNC_FLUSH: 2,
					Z_FULL_FLUSH: 3,
					Z_FINISH: 4,
					Z_BLOCK: 5,
					Z_TREES: 6,
					Z_OK: 0,
					Z_STREAM_END: 1,
					Z_NEED_DICT: 2,
					Z_ERRNO: -1,
					Z_STREAM_ERROR: -2,
					Z_DATA_ERROR: -3,
					Z_MEM_ERROR: -4,
					Z_BUF_ERROR: -5,
					Z_NO_COMPRESSION: 0,
					Z_BEST_SPEED: 1,
					Z_BEST_COMPRESSION: 9,
					Z_DEFAULT_COMPRESSION: -1,
					Z_FILTERED: 1,
					Z_HUFFMAN_ONLY: 2,
					Z_RLE: 3,
					Z_FIXED: 4,
					Z_DEFAULT_STRATEGY: 0,
					Z_BINARY: 0,
					Z_TEXT: 1,
					Z_UNKNOWN: 2,
					Z_DEFLATED: 8
				};
				let { _tr_init: _e, _tr_stored_block: ve, _tr_flush_block: ye, _tr_tally: be, _tr_align: xe } = $, { Z_NO_FLUSH: Se, Z_PARTIAL_FLUSH: Ce, Z_FULL_FLUSH: we, Z_FINISH: Te, Z_BLOCK: Ee, Z_OK: De, Z_STREAM_END: Oe, Z_STREAM_ERROR: ke, Z_DATA_ERROR: Ae, Z_BUF_ERROR: je, Z_DEFAULT_COMPRESSION: Me, Z_FILTERED: Ne, Z_HUFFMAN_ONLY: Pe, Z_RLE: Fe, Z_FIXED: Ie, Z_DEFAULT_STRATEGY: Le, Z_UNKNOWN: Re, Z_DEFLATED: ze } = ge, Be = 9, Ve = 15, He = 8, Ue = 29, We = 256, Ge = 286, Ke = 30, qe = 19, Je = 573, Ye = 15, Xe = 3, Ze = 258, Qe = 262, $e = 32, et = 42, tt = 57, nt = 69, rt = 73, it = 91, at = 103, ot = 113, st = 666, ct = 1, lt = 2, ut = 3, dt = 4, ft = 3, pt = (e, t) => (e.msg = he[t], t), mt = (e) => e * 2 - (e > 4 ? 9 : 0), ht = (e) => {
					let t = e.length;
					for (; --t >= 0;) e[t] = 0;
				}, gt = (e) => {
					let t, n, r, i = e.w_size;
					t = e.hash_size, r = t;
					do
						n = e.head[--r], e.head[r] = n >= i ? n - i : 0;
					while (--t);
					t = i, r = t;
					do
						n = e.prev[--r], e.prev[r] = n >= i ? n - i : 0;
					while (--t);
				}, _t = (e, t, n) => (t << e.hash_shift ^ n) & e.hash_mask, vt = (e) => {
					let t = e.state, n = t.pending;
					n > e.avail_out && (n = e.avail_out), n !== 0 && (e.output.set(t.pending_buf.subarray(t.pending_out, t.pending_out + n), e.next_out), e.next_out += n, t.pending_out += n, e.total_out += n, e.avail_out -= n, t.pending -= n, t.pending === 0 && (t.pending_out = 0));
				}, yt = (e, t) => {
					ye(e, e.block_start >= 0 ? e.block_start : -1, e.strstart - e.block_start, t), e.block_start = e.strstart, vt(e.strm);
				}, bt = (e, t) => {
					e.pending_buf[e.pending++] = t;
				}, xt = (e, t) => {
					e.pending_buf[e.pending++] = t >>> 8 & 255, e.pending_buf[e.pending++] = t & 255;
				}, St = (e, t, n, r) => {
					let i = e.avail_in;
					return i > r && (i = r), i === 0 ? 0 : (e.avail_in -= i, t.set(e.input.subarray(e.next_in, e.next_in + i), n), e.state.wrap === 1 ? e.adler = fe(e.adler, t, i, n) : e.state.wrap === 2 && (e.adler = me(e.adler, t, i, n)), e.next_in += i, e.total_in += i, i);
				}, Ct = (e, t) => {
					let n = e.max_chain_length, r = e.strstart, i, a, o = e.prev_length, s = e.nice_match, c = e.strstart > e.w_size - 262 ? e.strstart - (e.w_size - 262) : 0, l = e.window, u = e.w_mask, d = e.prev, f = e.strstart + 258, p = l[r + o - 1], m = l[r + o];
					e.prev_length >= e.good_match && (n >>= 2), s > e.lookahead && (s = e.lookahead);
					do
						if (i = t, l[i + o] === m && l[i + o - 1] === p && l[i] === l[r] && l[++i] === l[r + 1]) {
							r += 2, i++;
							do							;
while (l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && r < f);
							if (a = 258 - (f - r), r = f - 258, a > o) {
								if (e.match_start = t, o = a, a >= s) break;
								p = l[r + o - 1], m = l[r + o];
							}
						}
					while ((t = d[t & u]) > c && --n !== 0);
					return o <= e.lookahead ? o : e.lookahead;
				}, wt = (e) => {
					let t = e.w_size, n, r, i;
					do {
						if (r = e.window_size - e.lookahead - e.strstart, e.strstart >= t + (t - 262) && (e.window.set(e.window.subarray(t, t + t - r), 0), e.match_start -= t, e.strstart -= t, e.block_start -= t, e.insert > e.strstart && (e.insert = e.strstart), gt(e), r += t), e.strm.avail_in === 0) break;
						if (n = St(e.strm, e.window, e.strstart + e.lookahead, r), e.lookahead += n, e.lookahead + e.insert >= 3) for (i = e.strstart - e.insert, e.ins_h = e.window[i], e.ins_h = _t(e, e.ins_h, e.window[i + 1]); e.insert && (e.ins_h = _t(e, e.ins_h, e.window[i + 3 - 1]), e.prev[i & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = i, i++, e.insert--, !(e.lookahead + e.insert < 3)););
					} while (e.lookahead < 262 && e.strm.avail_in !== 0);
				}, Tt = (e, t) => {
					let n = e.pending_buf_size - 5 > e.w_size ? e.w_size : e.pending_buf_size - 5, r, i, a, o = 0, s = e.strm.avail_in;
					do {
						if (r = 65535, a = e.bi_valid + 42 >> 3, e.strm.avail_out < a || (a = e.strm.avail_out - a, i = e.strstart - e.block_start, r > i + e.strm.avail_in && (r = i + e.strm.avail_in), r > a && (r = a), r < n && (r === 0 && t !== Te || t === Se || r !== i + e.strm.avail_in))) break;
						o = +(t === Te && r === i + e.strm.avail_in), ve(e, 0, 0, o), e.pending_buf[e.pending - 4] = r, e.pending_buf[e.pending - 3] = r >> 8, e.pending_buf[e.pending - 2] = ~r, e.pending_buf[e.pending - 1] = ~r >> 8, vt(e.strm), i && (i > r && (i = r), e.strm.output.set(e.window.subarray(e.block_start, e.block_start + i), e.strm.next_out), e.strm.next_out += i, e.strm.avail_out -= i, e.strm.total_out += i, e.block_start += i, r -= i), r && (St(e.strm, e.strm.output, e.strm.next_out, r), e.strm.next_out += r, e.strm.avail_out -= r, e.strm.total_out += r);
					} while (o === 0);
					return s -= e.strm.avail_in, s && (s >= e.w_size ? (e.matches = 2, e.window.set(e.strm.input.subarray(e.strm.next_in - e.w_size, e.strm.next_in), 0), e.strstart = e.w_size, e.insert = e.strstart) : (e.window_size - e.strstart <= s && (e.strstart -= e.w_size, e.window.set(e.window.subarray(e.w_size, e.w_size + e.strstart), 0), e.matches < 2 && e.matches++, e.insert > e.strstart && (e.insert = e.strstart)), e.window.set(e.strm.input.subarray(e.strm.next_in - s, e.strm.next_in), e.strstart), e.strstart += s, e.insert += s > e.w_size - e.insert ? e.w_size - e.insert : s), e.block_start = e.strstart), e.high_water < e.strstart && (e.high_water = e.strstart), o ? 4 : t !== Se && t !== Te && e.strm.avail_in === 0 && e.strstart === e.block_start ? 2 : (a = e.window_size - e.strstart, e.strm.avail_in > a && e.block_start >= e.w_size && (e.block_start -= e.w_size, e.strstart -= e.w_size, e.window.set(e.window.subarray(e.w_size, e.w_size + e.strstart), 0), e.matches < 2 && e.matches++, a += e.w_size, e.insert > e.strstart && (e.insert = e.strstart)), a > e.strm.avail_in && (a = e.strm.avail_in), a && (St(e.strm, e.window, e.strstart, a), e.strstart += a, e.insert += a > e.w_size - e.insert ? e.w_size - e.insert : a), e.high_water < e.strstart && (e.high_water = e.strstart), a = e.bi_valid + 42 >> 3, a = e.pending_buf_size - a > 65535 ? 65535 : e.pending_buf_size - a, n = a > e.w_size ? e.w_size : a, i = e.strstart - e.block_start, (i >= n || (i || t === Te) && t !== Se && e.strm.avail_in === 0 && i <= a) && (r = i > a ? a : i, o = +(t === Te && e.strm.avail_in === 0 && r === i), ve(e, e.block_start, r, o), e.block_start += r, vt(e.strm)), o ? 3 : 1);
				}, Et = (e, t) => {
					let n, r;
					for (;;) {
						if (e.lookahead < 262) {
							if (wt(e), e.lookahead < 262 && t === Se) return 1;
							if (e.lookahead === 0) break;
						}
						if (n = 0, e.lookahead >= 3 && (e.ins_h = _t(e, e.ins_h, e.window[e.strstart + 3 - 1]), n = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart), n !== 0 && e.strstart - n <= e.w_size - 262 && (e.match_length = Ct(e, n)), e.match_length >= 3) {
							if (r = be(e, e.strstart - e.match_start, e.match_length - 3), e.lookahead -= e.match_length, e.match_length <= e.max_lazy_match && e.lookahead >= 3) {
								e.match_length--;
								do
									e.strstart++, e.ins_h = _t(e, e.ins_h, e.window[e.strstart + 3 - 1]), n = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart;
								while (--e.match_length !== 0);
								e.strstart++;
							} else e.strstart += e.match_length, e.match_length = 0, e.ins_h = e.window[e.strstart], e.ins_h = _t(e, e.ins_h, e.window[e.strstart + 1]);
						} else r = be(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++;
						if (r && (yt(e, !1), e.strm.avail_out === 0)) return 1;
					}
					return e.insert = e.strstart < 2 ? e.strstart : 2, t === Te ? (yt(e, !0), e.strm.avail_out === 0 ? 3 : 4) : e.sym_next && (yt(e, !1), e.strm.avail_out === 0) ? 1 : 2;
				}, Dt = (e, t) => {
					let n, r, i;
					for (;;) {
						if (e.lookahead < 262) {
							if (wt(e), e.lookahead < 262 && t === Se) return 1;
							if (e.lookahead === 0) break;
						}
						if (n = 0, e.lookahead >= 3 && (e.ins_h = _t(e, e.ins_h, e.window[e.strstart + 3 - 1]), n = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart), e.prev_length = e.match_length, e.prev_match = e.match_start, e.match_length = 2, n !== 0 && e.prev_length < e.max_lazy_match && e.strstart - n <= e.w_size - 262 && (e.match_length = Ct(e, n), e.match_length <= 5 && (e.strategy === Ne || e.match_length === 3 && e.strstart - e.match_start > 4096) && (e.match_length = 2)), e.prev_length >= 3 && e.match_length <= e.prev_length) {
							i = e.strstart + e.lookahead - 3, r = be(e, e.strstart - 1 - e.prev_match, e.prev_length - 3), e.lookahead -= e.prev_length - 1, e.prev_length -= 2;
							do
								++e.strstart <= i && (e.ins_h = _t(e, e.ins_h, e.window[e.strstart + 3 - 1]), n = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart);
							while (--e.prev_length !== 0);
							if (e.match_available = 0, e.match_length = 2, e.strstart++, r && (yt(e, !1), e.strm.avail_out === 0)) return 1;
						} else if (e.match_available) {
							if (r = be(e, 0, e.window[e.strstart - 1]), r && yt(e, !1), e.strstart++, e.lookahead--, e.strm.avail_out === 0) return 1;
						} else e.match_available = 1, e.strstart++, e.lookahead--;
					}
					return e.match_available &&= (r = be(e, 0, e.window[e.strstart - 1]), 0), e.insert = e.strstart < 2 ? e.strstart : 2, t === Te ? (yt(e, !0), e.strm.avail_out === 0 ? 3 : 4) : e.sym_next && (yt(e, !1), e.strm.avail_out === 0) ? 1 : 2;
				}, Ot = (e, t) => {
					let n, r, i, a, o = e.window;
					for (;;) {
						if (e.lookahead <= 258) {
							if (wt(e), e.lookahead <= 258 && t === Se) return 1;
							if (e.lookahead === 0) break;
						}
						if (e.match_length = 0, e.lookahead >= 3 && e.strstart > 0 && (i = e.strstart - 1, r = o[i], r === o[++i] && r === o[++i] && r === o[++i])) {
							a = e.strstart + 258;
							do							;
while (r === o[++i] && r === o[++i] && r === o[++i] && r === o[++i] && r === o[++i] && r === o[++i] && r === o[++i] && r === o[++i] && i < a);
							e.match_length = 258 - (a - i), e.match_length > e.lookahead && (e.match_length = e.lookahead);
						}
						if (e.match_length >= 3 ? (n = be(e, 1, e.match_length - 3), e.lookahead -= e.match_length, e.strstart += e.match_length, e.match_length = 0) : (n = be(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++), n && (yt(e, !1), e.strm.avail_out === 0)) return 1;
					}
					return e.insert = 0, t === Te ? (yt(e, !0), e.strm.avail_out === 0 ? 3 : 4) : e.sym_next && (yt(e, !1), e.strm.avail_out === 0) ? 1 : 2;
				}, kt = (e, t) => {
					let n;
					for (;;) {
						if (e.lookahead === 0 && (wt(e), e.lookahead === 0)) {
							if (t === Se) return 1;
							break;
						}
						if (e.match_length = 0, n = be(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++, n && (yt(e, !1), e.strm.avail_out === 0)) return 1;
					}
					return e.insert = 0, t === Te ? (yt(e, !0), e.strm.avail_out === 0 ? 3 : 4) : e.sym_next && (yt(e, !1), e.strm.avail_out === 0) ? 1 : 2;
				};
				function At(e, t, n, r, i) {
					this.good_length = e, this.max_lazy = t, this.nice_length = n, this.max_chain = r, this.func = i;
				}
				let jt = [
					new At(0, 0, 0, 0, Tt),
					new At(4, 4, 8, 4, Et),
					new At(4, 5, 16, 8, Et),
					new At(4, 6, 32, 32, Et),
					new At(4, 4, 16, 16, Dt),
					new At(8, 16, 32, 32, Dt),
					new At(8, 16, 128, 128, Dt),
					new At(8, 32, 128, 256, Dt),
					new At(32, 128, 258, 1024, Dt),
					new At(32, 258, 258, 4096, Dt)
				], Mt = (e) => {
					e.window_size = 2 * e.w_size, ht(e.head), e.max_lazy_match = jt[e.level].max_lazy, e.good_match = jt[e.level].good_length, e.nice_match = jt[e.level].nice_length, e.max_chain_length = jt[e.level].max_chain, e.strstart = 0, e.block_start = 0, e.lookahead = 0, e.insert = 0, e.match_length = e.prev_length = 2, e.match_available = 0, e.ins_h = 0;
				};
				function Nt() {
					this.strm = null, this.status = 0, this.pending_buf = null, this.pending_buf_size = 0, this.pending_out = 0, this.pending = 0, this.wrap = 0, this.gzhead = null, this.gzindex = 0, this.method = ze, this.last_flush = -1, this.w_size = 0, this.w_bits = 0, this.w_mask = 0, this.window = null, this.window_size = 0, this.prev = null, this.head = null, this.ins_h = 0, this.hash_size = 0, this.hash_bits = 0, this.hash_mask = 0, this.hash_shift = 0, this.block_start = 0, this.match_length = 0, this.prev_match = 0, this.match_available = 0, this.strstart = 0, this.match_start = 0, this.lookahead = 0, this.prev_length = 0, this.max_chain_length = 0, this.max_lazy_match = 0, this.level = 0, this.strategy = 0, this.good_match = 0, this.nice_match = 0, this.dyn_ltree = /* @__PURE__ */ new Uint16Array(1146), this.dyn_dtree = /* @__PURE__ */ new Uint16Array(122), this.bl_tree = /* @__PURE__ */ new Uint16Array(78), ht(this.dyn_ltree), ht(this.dyn_dtree), ht(this.bl_tree), this.l_desc = null, this.d_desc = null, this.bl_desc = null, this.bl_count = /* @__PURE__ */ new Uint16Array(16), this.heap = /* @__PURE__ */ new Uint16Array(573), ht(this.heap), this.heap_len = 0, this.heap_max = 0, this.depth = /* @__PURE__ */ new Uint16Array(573), ht(this.depth), this.sym_buf = 0, this.lit_bufsize = 0, this.sym_next = 0, this.sym_end = 0, this.opt_len = 0, this.static_len = 0, this.matches = 0, this.insert = 0, this.bi_buf = 0, this.bi_valid = 0;
				}
				let Pt = (e) => {
					if (!e) return 1;
					let t = e.state;
					return +(!t || t.strm !== e || t.status !== 42 && t.status !== 57 && t.status !== 69 && t.status !== 73 && t.status !== 91 && t.status !== 103 && t.status !== 113 && t.status !== 666);
				}, Ft = (e) => {
					if (Pt(e)) return pt(e, ke);
					e.total_in = e.total_out = 0, e.data_type = Re;
					let t = e.state;
					return t.pending = 0, t.pending_out = 0, t.wrap < 0 && (t.wrap = -t.wrap), t.status = t.wrap === 2 ? 57 : t.wrap ? 42 : 113, e.adler = t.wrap === 2 ? 0 : 1, t.last_flush = -2, _e(t), De;
				}, It = (e) => {
					let t = Ft(e);
					return t === De && Mt(e.state), t;
				}, Lt = (e, t) => Pt(e) || e.state.wrap !== 2 ? ke : (e.state.gzhead = t, De), Rt = (e, t, n, r, i, a) => {
					if (!e) return ke;
					let o = 1;
					if (t === Me && (t = 6), r < 0 ? (o = 0, r = -r) : r > 15 && (o = 2, r -= 16), i < 1 || i > 9 || n !== ze || r < 8 || r > 15 || t < 0 || t > 9 || a < 0 || a > Ie || r === 8 && o !== 1) return pt(e, ke);
					r === 8 && (r = 9);
					let s = new Nt();
					return e.state = s, s.strm = e, s.status = 42, s.wrap = o, s.gzhead = null, s.w_bits = r, s.w_size = 1 << s.w_bits, s.w_mask = s.w_size - 1, s.hash_bits = i + 7, s.hash_size = 1 << s.hash_bits, s.hash_mask = s.hash_size - 1, s.hash_shift = ~~((s.hash_bits + 3 - 1) / 3), s.window = new Uint8Array(s.w_size * 2), s.head = new Uint16Array(s.hash_size), s.prev = new Uint16Array(s.w_size), s.lit_bufsize = 1 << i + 6, s.pending_buf_size = s.lit_bufsize * 4, s.pending_buf = new Uint8Array(s.pending_buf_size), s.sym_buf = s.lit_bufsize, s.sym_end = (s.lit_bufsize - 1) * 3, s.level = t, s.strategy = a, s.method = n, It(e);
				};
				var zt = {
					deflateInit: (e, t) => Rt(e, t, ze, 15, 8, Le),
					deflateInit2: Rt,
					deflateReset: It,
					deflateResetKeep: Ft,
					deflateSetHeader: Lt,
					deflate: (e, t) => {
						if (Pt(e) || t > Ee || t < 0) return e ? pt(e, ke) : ke;
						let n = e.state;
						if (!e.output || e.avail_in !== 0 && !e.input || n.status === 666 && t !== Te) return pt(e, e.avail_out === 0 ? je : ke);
						let r = n.last_flush;
						if (n.last_flush = t, n.pending !== 0) {
							if (vt(e), e.avail_out === 0) return n.last_flush = -1, De;
						} else if (e.avail_in === 0 && mt(t) <= mt(r) && t !== Te) return pt(e, je);
						if (n.status === 666 && e.avail_in !== 0) return pt(e, je);
						if (n.status === 42 && n.wrap === 0 && (n.status = 113), n.status === 42) {
							let t = ze + (n.w_bits - 8 << 4) << 8, r = -1;
							if (r = n.strategy >= Pe || n.level < 2 ? 0 : n.level < 6 ? 1 : n.level === 6 ? 2 : 3, t |= r << 6, n.strstart !== 0 && (t |= 32), t += 31 - t % 31, xt(n, t), n.strstart !== 0 && (xt(n, e.adler >>> 16), xt(n, e.adler & 65535)), e.adler = 1, n.status = 113, vt(e), n.pending !== 0) return n.last_flush = -1, De;
						}
						if (n.status === 57) {
							if (e.adler = 0, bt(n, 31), bt(n, 139), bt(n, 8), n.gzhead) bt(n, +!!n.gzhead.text + (n.gzhead.hcrc ? 2 : 0) + (n.gzhead.extra ? 4 : 0) + (n.gzhead.name ? 8 : 0) + (n.gzhead.comment ? 16 : 0)), bt(n, n.gzhead.time & 255), bt(n, n.gzhead.time >> 8 & 255), bt(n, n.gzhead.time >> 16 & 255), bt(n, n.gzhead.time >> 24 & 255), bt(n, n.level === 9 ? 2 : n.strategy >= Pe || n.level < 2 ? 4 : 0), bt(n, n.gzhead.os & 255), n.gzhead.extra && n.gzhead.extra.length && (bt(n, n.gzhead.extra.length & 255), bt(n, n.gzhead.extra.length >> 8 & 255)), n.gzhead.hcrc && (e.adler = me(e.adler, n.pending_buf, n.pending, 0)), n.gzindex = 0, n.status = 69;
							else if (bt(n, 0), bt(n, 0), bt(n, 0), bt(n, 0), bt(n, 0), bt(n, n.level === 9 ? 2 : n.strategy >= Pe || n.level < 2 ? 4 : 0), bt(n, 3), n.status = 113, vt(e), n.pending !== 0) return n.last_flush = -1, De;
						}
						if (n.status === 69) {
							if (n.gzhead.extra) {
								let t = n.pending, r = (n.gzhead.extra.length & 65535) - n.gzindex;
								for (; n.pending + r > n.pending_buf_size;) {
									let i = n.pending_buf_size - n.pending;
									if (n.pending_buf.set(n.gzhead.extra.subarray(n.gzindex, n.gzindex + i), n.pending), n.pending = n.pending_buf_size, n.gzhead.hcrc && n.pending > t && (e.adler = me(e.adler, n.pending_buf, n.pending - t, t)), n.gzindex += i, vt(e), n.pending !== 0) return n.last_flush = -1, De;
									t = 0, r -= i;
								}
								let i = new Uint8Array(n.gzhead.extra);
								n.pending_buf.set(i.subarray(n.gzindex, n.gzindex + r), n.pending), n.pending += r, n.gzhead.hcrc && n.pending > t && (e.adler = me(e.adler, n.pending_buf, n.pending - t, t)), n.gzindex = 0;
							}
							n.status = 73;
						}
						if (n.status === 73) {
							if (n.gzhead.name) {
								let t = n.pending, r;
								do {
									if (n.pending === n.pending_buf_size) {
										if (n.gzhead.hcrc && n.pending > t && (e.adler = me(e.adler, n.pending_buf, n.pending - t, t)), vt(e), n.pending !== 0) return n.last_flush = -1, De;
										t = 0;
									}
									r = n.gzindex < n.gzhead.name.length ? n.gzhead.name.charCodeAt(n.gzindex++) & 255 : 0, bt(n, r);
								} while (r !== 0);
								n.gzhead.hcrc && n.pending > t && (e.adler = me(e.adler, n.pending_buf, n.pending - t, t)), n.gzindex = 0;
							}
							n.status = 91;
						}
						if (n.status === 91) {
							if (n.gzhead.comment) {
								let t = n.pending, r;
								do {
									if (n.pending === n.pending_buf_size) {
										if (n.gzhead.hcrc && n.pending > t && (e.adler = me(e.adler, n.pending_buf, n.pending - t, t)), vt(e), n.pending !== 0) return n.last_flush = -1, De;
										t = 0;
									}
									r = n.gzindex < n.gzhead.comment.length ? n.gzhead.comment.charCodeAt(n.gzindex++) & 255 : 0, bt(n, r);
								} while (r !== 0);
								n.gzhead.hcrc && n.pending > t && (e.adler = me(e.adler, n.pending_buf, n.pending - t, t));
							}
							n.status = 103;
						}
						if (n.status === 103) {
							if (n.gzhead.hcrc) {
								if (n.pending + 2 > n.pending_buf_size && (vt(e), n.pending !== 0)) return n.last_flush = -1, De;
								bt(n, e.adler & 255), bt(n, e.adler >> 8 & 255), e.adler = 0;
							}
							if (n.status = 113, vt(e), n.pending !== 0) return n.last_flush = -1, De;
						}
						if (e.avail_in !== 0 || n.lookahead !== 0 || t !== Se && n.status !== 666) {
							let r = n.level === 0 ? Tt(n, t) : n.strategy === Pe ? kt(n, t) : n.strategy === Fe ? Ot(n, t) : jt[n.level].func(n, t);
							if ((r === 3 || r === 4) && (n.status = 666), r === 1 || r === 3) return e.avail_out === 0 && (n.last_flush = -1), De;
							if (r === 2 && (t === Ce ? xe(n) : t !== Ee && (ve(n, 0, 0, !1), t === we && (ht(n.head), n.lookahead === 0 && (n.strstart = 0, n.block_start = 0, n.insert = 0))), vt(e), e.avail_out === 0)) return n.last_flush = -1, De;
						}
						return t === Te ? n.wrap <= 0 ? Oe : (n.wrap === 2 ? (bt(n, e.adler & 255), bt(n, e.adler >> 8 & 255), bt(n, e.adler >> 16 & 255), bt(n, e.adler >> 24 & 255), bt(n, e.total_in & 255), bt(n, e.total_in >> 8 & 255), bt(n, e.total_in >> 16 & 255), bt(n, e.total_in >> 24 & 255)) : (xt(n, e.adler >>> 16), xt(n, e.adler & 65535)), vt(e), n.wrap > 0 && (n.wrap = -n.wrap), n.pending === 0 ? Oe : De) : De;
					},
					deflateEnd: (e) => {
						if (Pt(e)) return ke;
						let t = e.state.status;
						return e.state = null, t === 113 ? pt(e, Ae) : De;
					},
					deflateSetDictionary: (e, t) => {
						let n = t.length;
						if (Pt(e)) return ke;
						let r = e.state, i = r.wrap;
						if (i === 2 || i === 1 && r.status !== 42 || r.lookahead) return ke;
						if (i === 1 && (e.adler = fe(e.adler, t, n, 0)), r.wrap = 0, n >= r.w_size) {
							i === 0 && (ht(r.head), r.strstart = 0, r.block_start = 0, r.insert = 0);
							let e = new Uint8Array(r.w_size);
							e.set(t.subarray(n - r.w_size, n), 0), t = e, n = r.w_size;
						}
						let a = e.avail_in, o = e.next_in, s = e.input;
						for (e.avail_in = n, e.next_in = 0, e.input = t, wt(r); r.lookahead >= 3;) {
							let e = r.strstart, t = r.lookahead - 2;
							do
								r.ins_h = _t(r, r.ins_h, r.window[e + 3 - 1]), r.prev[e & r.w_mask] = r.head[r.ins_h], r.head[r.ins_h] = e, e++;
							while (--t);
							r.strstart = e, r.lookahead = 2, wt(r);
						}
						return r.strstart += r.lookahead, r.block_start = r.strstart, r.insert = r.lookahead, r.lookahead = 0, r.match_length = r.prev_length = 2, r.match_available = 0, e.next_in = o, e.input = s, e.avail_in = a, r.wrap = i, De;
					},
					deflateInfo: "pako deflate (from Nodeca project)"
				};
				let Bt = (e, t) => Object.prototype.hasOwnProperty.call(e, t);
				var Vt = {
					assign: function(e) {
						let t = Array.prototype.slice.call(arguments, 1);
						for (; t.length;) {
							let n = t.shift();
							if (n) {
								if (typeof n != "object") throw TypeError(n + "must be non-object");
								for (let t in n) Bt(n, t) && (e[t] = n[t]);
							}
						}
						return e;
					},
					flattenChunks: (e) => {
						let t = 0;
						for (let n = 0, r = e.length; n < r; n++) t += e[n].length;
						let n = new Uint8Array(t);
						for (let t = 0, r = 0, i = e.length; t < i; t++) {
							let i = e[t];
							n.set(i, r), r += i.length;
						}
						return n;
					}
				};
				let Ht = !0;
				try {
					String.fromCharCode.apply(null, /* @__PURE__ */ new Uint8Array(1));
				} catch {
					Ht = !1;
				}
				let Ut = /* @__PURE__ */ new Uint8Array(256);
				for (let e = 0; e < 256; e++) Ut[e] = e >= 252 ? 6 : e >= 248 ? 5 : e >= 240 ? 4 : e >= 224 ? 3 : e >= 192 ? 2 : 1;
				Ut[254] = Ut[254] = 1;
				var Wt = (e) => {
					if (typeof TextEncoder == "function" && TextEncoder.prototype.encode) return new TextEncoder().encode(e);
					let t, n, r, i, a, o = e.length, s = 0;
					for (i = 0; i < o; i++) n = e.charCodeAt(i), (n & 64512) == 55296 && i + 1 < o && (r = e.charCodeAt(i + 1), (r & 64512) == 56320 && (n = 65536 + (n - 55296 << 10) + (r - 56320), i++)), s += n < 128 ? 1 : n < 2048 ? 2 : n < 65536 ? 3 : 4;
					for (t = new Uint8Array(s), a = 0, i = 0; a < s; i++) n = e.charCodeAt(i), (n & 64512) == 55296 && i + 1 < o && (r = e.charCodeAt(i + 1), (r & 64512) == 56320 && (n = 65536 + (n - 55296 << 10) + (r - 56320), i++)), n < 128 ? t[a++] = n : n < 2048 ? (t[a++] = 192 | n >>> 6, t[a++] = 128 | n & 63) : n < 65536 ? (t[a++] = 224 | n >>> 12, t[a++] = 128 | n >>> 6 & 63, t[a++] = 128 | n & 63) : (t[a++] = 240 | n >>> 18, t[a++] = 128 | n >>> 12 & 63, t[a++] = 128 | n >>> 6 & 63, t[a++] = 128 | n & 63);
					return t;
				};
				let Gt = (e, t) => {
					if (t < 65534 && e.subarray && Ht) return String.fromCharCode.apply(null, e.length === t ? e : e.subarray(0, t));
					let n = "";
					for (let r = 0; r < t; r++) n += String.fromCharCode(e[r]);
					return n;
				};
				var Kt = {
					string2buf: Wt,
					buf2string: (e, t) => {
						let n = t || e.length;
						if (typeof TextDecoder == "function" && TextDecoder.prototype.decode) return new TextDecoder().decode(e.subarray(0, t));
						let r, i, a = Array(n * 2);
						for (i = 0, r = 0; r < n;) {
							let t = e[r++];
							if (t < 128) {
								a[i++] = t;
								continue;
							}
							let o = Ut[t];
							if (o > 4) {
								a[i++] = 65533, r += o - 1;
								continue;
							}
							for (t &= o === 2 ? 31 : o === 3 ? 15 : 7; o > 1 && r < n;) t = t << 6 | e[r++] & 63, o--;
							if (o > 1) {
								a[i++] = 65533;
								continue;
							}
							t < 65536 ? a[i++] = t : (t -= 65536, a[i++] = 55296 | t >> 10 & 1023, a[i++] = 56320 | t & 1023);
						}
						return Gt(a, i);
					},
					utf8border: (e, t) => {
						t ||= e.length, t > e.length && (t = e.length);
						let n = t - 1;
						for (; n >= 0 && (e[n] & 192) == 128;) n--;
						return n < 0 || n === 0 ? t : n + Ut[e[n]] > t ? n : t;
					}
				};
				function qt() {
					this.input = null, this.next_in = 0, this.avail_in = 0, this.total_in = 0, this.output = null, this.next_out = 0, this.avail_out = 0, this.total_out = 0, this.msg = "", this.state = null, this.data_type = 2, this.adler = 0;
				}
				var Jt = qt;
				let Yt = Object.prototype.toString, { Z_NO_FLUSH: Xt, Z_SYNC_FLUSH: Zt, Z_FULL_FLUSH: Qt, Z_FINISH: $t, Z_OK: en, Z_STREAM_END: tn, Z_DEFAULT_COMPRESSION: nn, Z_DEFAULT_STRATEGY: rn, Z_DEFLATED: an } = ge;
				function on(e) {
					this.options = Vt.assign({
						level: nn,
						method: an,
						chunkSize: 16384,
						windowBits: 15,
						memLevel: 8,
						strategy: rn
					}, e || {});
					let t = this.options;
					t.raw && t.windowBits > 0 ? t.windowBits = -t.windowBits : t.gzip && t.windowBits > 0 && t.windowBits < 16 && (t.windowBits += 16), this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new Jt(), this.strm.avail_out = 0;
					let n = zt.deflateInit2(this.strm, t.level, t.method, t.windowBits, t.memLevel, t.strategy);
					if (n !== en) throw Error(he[n]);
					if (t.header && zt.deflateSetHeader(this.strm, t.header), t.dictionary) {
						let e;
						if (e = typeof t.dictionary == "string" ? Kt.string2buf(t.dictionary) : Yt.call(t.dictionary) === "[object ArrayBuffer]" ? new Uint8Array(t.dictionary) : t.dictionary, n = zt.deflateSetDictionary(this.strm, e), n !== en) throw Error(he[n]);
						this._dict_set = !0;
					}
				}
				on.prototype.push = function(e, t) {
					let n = this.strm, r = this.options.chunkSize, i, a;
					if (this.ended) return !1;
					for (a = t === ~~t ? t : t === !0 ? $t : Xt, n.input = typeof e == "string" ? Kt.string2buf(e) : Yt.call(e) === "[object ArrayBuffer]" ? new Uint8Array(e) : e, n.next_in = 0, n.avail_in = n.input.length;;) {
						if (n.avail_out === 0 && (n.output = new Uint8Array(r), n.next_out = 0, n.avail_out = r), (a === Zt || a === Qt) && n.avail_out <= 6) {
							this.onData(n.output.subarray(0, n.next_out)), n.avail_out = 0;
							continue;
						}
						if (i = zt.deflate(n, a), i === tn) return n.next_out > 0 && this.onData(n.output.subarray(0, n.next_out)), i = zt.deflateEnd(this.strm), this.onEnd(i), this.ended = !0, i === en;
						if (n.avail_out === 0) {
							this.onData(n.output);
							continue;
						}
						if (a > 0 && n.next_out > 0) {
							this.onData(n.output.subarray(0, n.next_out)), n.avail_out = 0;
							continue;
						}
						if (n.avail_in === 0) break;
					}
					return !0;
				}, on.prototype.onData = function(e) {
					this.chunks.push(e);
				}, on.prototype.onEnd = function(e) {
					e === en && (this.result = Vt.flattenChunks(this.chunks)), this.chunks = [], this.err = e, this.msg = this.strm.msg;
				};
				function sn(e, t) {
					let n = new on(t);
					if (n.push(e, !0), n.err) throw n.msg || he[n.err];
					return n.result;
				}
				function cn(e, t) {
					return t ||= {}, t.raw = !0, sn(e, t);
				}
				function ln(e, t) {
					return t ||= {}, t.gzip = !0, sn(e, t);
				}
				var un = {
					Deflate: on,
					deflate: sn,
					deflateRaw: cn,
					gzip: ln,
					constants: ge
				};
				let dn = 16209, fn = 16191;
				var pn = function(e, t) {
					let n, r, i, a, o, s, c, l, u, d, f, p, m, h, g, _, v, y, b, x, S, C, w, T, E = e.state;
					n = e.next_in, w = e.input, r = n + (e.avail_in - 5), i = e.next_out, T = e.output, a = i - (t - e.avail_out), o = i + (e.avail_out - 257), s = E.dmax, c = E.wsize, l = E.whave, u = E.wnext, d = E.window, f = E.hold, p = E.bits, m = E.lencode, h = E.distcode, g = (1 << E.lenbits) - 1, _ = (1 << E.distbits) - 1;
					top: do {
						p < 15 && (f += w[n++] << p, p += 8, f += w[n++] << p, p += 8), v = m[f & g];
						dolen: for (;;) {
							if (y = v >>> 24, f >>>= y, p -= y, y = v >>> 16 & 255, y === 0) T[i++] = v & 65535;
							else if (y & 16) {
								b = v & 65535, y &= 15, y && (p < y && (f += w[n++] << p, p += 8), b += f & (1 << y) - 1, f >>>= y, p -= y), p < 15 && (f += w[n++] << p, p += 8, f += w[n++] << p, p += 8), v = h[f & _];
								dodist: for (;;) {
									if (y = v >>> 24, f >>>= y, p -= y, y = v >>> 16 & 255, y & 16) {
										if (x = v & 65535, y &= 15, p < y && (f += w[n++] << p, p += 8, p < y && (f += w[n++] << p, p += 8)), x += f & (1 << y) - 1, x > s) {
											e.msg = "invalid distance too far back", E.mode = dn;
											break top;
										}
										if (f >>>= y, p -= y, y = i - a, x > y) {
											if (y = x - y, y > l && E.sane) {
												e.msg = "invalid distance too far back", E.mode = dn;
												break top;
											}
											if (S = 0, C = d, u === 0) {
												if (S += c - y, y < b) {
													b -= y;
													do
														T[i++] = d[S++];
													while (--y);
													S = i - x, C = T;
												}
											} else if (u < y) {
												if (S += c + u - y, y -= u, y < b) {
													b -= y;
													do
														T[i++] = d[S++];
													while (--y);
													if (S = 0, u < b) {
														y = u, b -= y;
														do
															T[i++] = d[S++];
														while (--y);
														S = i - x, C = T;
													}
												}
											} else if (S += u - y, y < b) {
												b -= y;
												do
													T[i++] = d[S++];
												while (--y);
												S = i - x, C = T;
											}
											for (; b > 2;) T[i++] = C[S++], T[i++] = C[S++], T[i++] = C[S++], b -= 3;
											b && (T[i++] = C[S++], b > 1 && (T[i++] = C[S++]));
										} else {
											S = i - x;
											do
												T[i++] = T[S++], T[i++] = T[S++], T[i++] = T[S++], b -= 3;
											while (b > 2);
											b && (T[i++] = T[S++], b > 1 && (T[i++] = T[S++]));
										}
									} else if (y & 64) {
										e.msg = "invalid distance code", E.mode = dn;
										break top;
									} else {
										v = h[(v & 65535) + (f & (1 << y) - 1)];
										continue dodist;
									}
									break;
								}
							} else if (!(y & 64)) {
								v = m[(v & 65535) + (f & (1 << y) - 1)];
								continue dolen;
							} else if (y & 32) {
								E.mode = 16191;
								break top;
							} else {
								e.msg = "invalid literal/length code", E.mode = dn;
								break top;
							}
							break;
						}
					} while (n < r && i < o);
					b = p >> 3, n -= b, p -= b << 3, f &= (1 << p) - 1, e.next_in = n, e.next_out = i, e.avail_in = n < r ? 5 + (r - n) : 5 - (n - r), e.avail_out = i < o ? 257 + (o - i) : 257 - (i - o), E.hold = f, E.bits = p;
				};
				let mn = 15, hn = 852, gn = 592, _n = 0, vn = 1, yn = 2, bn = new Uint16Array([
					3,
					4,
					5,
					6,
					7,
					8,
					9,
					10,
					11,
					13,
					15,
					17,
					19,
					23,
					27,
					31,
					35,
					43,
					51,
					59,
					67,
					83,
					99,
					115,
					131,
					163,
					195,
					227,
					258,
					0,
					0
				]), xn = new Uint8Array([
					16,
					16,
					16,
					16,
					16,
					16,
					16,
					16,
					17,
					17,
					17,
					17,
					18,
					18,
					18,
					18,
					19,
					19,
					19,
					19,
					20,
					20,
					20,
					20,
					21,
					21,
					21,
					21,
					16,
					72,
					78
				]), Sn = new Uint16Array([
					1,
					2,
					3,
					4,
					5,
					7,
					9,
					13,
					17,
					25,
					33,
					49,
					65,
					97,
					129,
					193,
					257,
					385,
					513,
					769,
					1025,
					1537,
					2049,
					3073,
					4097,
					6145,
					8193,
					12289,
					16385,
					24577,
					0,
					0
				]), Cn = new Uint8Array([
					16,
					16,
					16,
					16,
					17,
					17,
					18,
					18,
					19,
					19,
					20,
					20,
					21,
					21,
					22,
					22,
					23,
					23,
					24,
					24,
					25,
					25,
					26,
					26,
					27,
					27,
					28,
					28,
					29,
					29,
					64,
					64
				]);
				var wn = (e, t, n, r, i, a, o, s) => {
					let c = s.bits, l = 0, u = 0, d = 0, f = 0, p = 0, m = 0, h = 0, g = 0, _ = 0, v = 0, y, b, x, S, C, w = null, T, E = /* @__PURE__ */ new Uint16Array(16), D = /* @__PURE__ */ new Uint16Array(16), O = null, k, A, j;
					for (l = 0; l <= 15; l++) E[l] = 0;
					for (u = 0; u < r; u++) E[t[n + u]]++;
					for (p = c, f = 15; f >= 1 && E[f] === 0; f--);
					if (p > f && (p = f), f === 0) return i[a++] = 20971520, i[a++] = 20971520, s.bits = 1, 0;
					for (d = 1; d < f && E[d] === 0; d++);
					for (p < d && (p = d), g = 1, l = 1; l <= 15; l++) if (g <<= 1, g -= E[l], g < 0) return -1;
					if (g > 0 && (e === 0 || f !== 1)) return -1;
					for (D[1] = 0, l = 1; l < 15; l++) D[l + 1] = D[l] + E[l];
					for (u = 0; u < r; u++) t[n + u] !== 0 && (o[D[t[n + u]]++] = u);
					if (e === 0 ? (w = O = o, T = 20) : e === 1 ? (w = bn, O = xn, T = 257) : (w = Sn, O = Cn, T = 0), v = 0, u = 0, l = d, C = a, m = p, h = 0, x = -1, _ = 1 << p, S = _ - 1, e === 1 && _ > 852 || e === 2 && _ > 592) return 1;
					for (;;) {
						k = l - h, o[u] + 1 < T ? (A = 0, j = o[u]) : o[u] >= T ? (A = O[o[u] - T], j = w[o[u] - T]) : (A = 96, j = 0), y = 1 << l - h, b = 1 << m, d = b;
						do
							b -= y, i[C + (v >> h) + b] = k << 24 | A << 16 | j | 0;
						while (b !== 0);
						for (y = 1 << l - 1; v & y;) y >>= 1;
						if (y === 0 ? v = 0 : (v &= y - 1, v += y), u++, --E[l] === 0) {
							if (l === f) break;
							l = t[n + o[u]];
						}
						if (l > p && (v & S) !== x) {
							for (h === 0 && (h = p), C += d, m = l - h, g = 1 << m; m + h < f && (g -= E[m + h], !(g <= 0));) m++, g <<= 1;
							if (_ += 1 << m, e === 1 && _ > 852 || e === 2 && _ > 592) return 1;
							x = v & S, i[x] = p << 24 | m << 16 | C - a | 0;
						}
					}
					return v !== 0 && (i[C + v] = l - h << 24 | 4194304), s.bits = p, 0;
				};
				let Tn = 0, En = 1, Dn = 2, { Z_FINISH: On, Z_BLOCK: kn, Z_TREES: An, Z_OK: jn, Z_STREAM_END: Mn, Z_NEED_DICT: Nn, Z_STREAM_ERROR: Pn, Z_DATA_ERROR: Fn, Z_MEM_ERROR: In, Z_BUF_ERROR: Ln, Z_DEFLATED: Rn } = ge, zn = 16180, Bn = 16181, Vn = 16182, Hn = 16183, Un = 16184, Wn = 16185, Gn = 16186, Kn = 16187, qn = 16188, Jn = 16189, Yn = 16190, Xn = 16191, Zn = 16192, Qn = 16193, $n = 16194, er = 16195, tr = 16196, nr = 16197, rr = 16198, ir = 16199, ar = 16200, or = 16201, sr = 16202, cr = 16203, lr = 16204, ur = 16205, dr = 16206, fr = 16207, pr = 16208, mr = 16209, hr = 16210, gr = 16211, _r = 852, vr = 592, yr = 15, br = (e) => (e >>> 24 & 255) + (e >>> 8 & 65280) + ((e & 65280) << 8) + ((e & 255) << 24);
				function xr() {
					this.strm = null, this.mode = 0, this.last = !1, this.wrap = 0, this.havedict = !1, this.flags = 0, this.dmax = 0, this.check = 0, this.total = 0, this.head = null, this.wbits = 0, this.wsize = 0, this.whave = 0, this.wnext = 0, this.window = null, this.hold = 0, this.bits = 0, this.length = 0, this.offset = 0, this.extra = 0, this.lencode = null, this.distcode = null, this.lenbits = 0, this.distbits = 0, this.ncode = 0, this.nlen = 0, this.ndist = 0, this.have = 0, this.next = null, this.lens = /* @__PURE__ */ new Uint16Array(320), this.work = /* @__PURE__ */ new Uint16Array(288), this.lendyn = null, this.distdyn = null, this.sane = 0, this.back = 0, this.was = 0;
				}
				let Sr = (e) => {
					if (!e) return 1;
					let t = e.state;
					return +(!t || t.strm !== e || t.mode < zn || t.mode > gr);
				}, Cr = (e) => {
					if (Sr(e)) return Pn;
					let t = e.state;
					return e.total_in = e.total_out = t.total = 0, e.msg = "", t.wrap && (e.adler = t.wrap & 1), t.mode = zn, t.last = 0, t.havedict = 0, t.flags = -1, t.dmax = 32768, t.head = null, t.hold = 0, t.bits = 0, t.lencode = t.lendyn = /* @__PURE__ */ new Int32Array(852), t.distcode = t.distdyn = /* @__PURE__ */ new Int32Array(592), t.sane = 1, t.back = -1, jn;
				}, wr = (e) => {
					if (Sr(e)) return Pn;
					let t = e.state;
					return t.wsize = 0, t.whave = 0, t.wnext = 0, Cr(e);
				}, Tr = (e, t) => {
					let n;
					if (Sr(e)) return Pn;
					let r = e.state;
					return t < 0 ? (n = 0, t = -t) : (n = (t >> 4) + 5, t < 48 && (t &= 15)), t && (t < 8 || t > 15) ? Pn : (r.window !== null && r.wbits !== t && (r.window = null), r.wrap = n, r.wbits = t, wr(e));
				}, Er = (e, t) => {
					if (!e) return Pn;
					let n = new xr();
					e.state = n, n.strm = e, n.window = null, n.mode = zn;
					let r = Tr(e, t);
					return r !== jn && (e.state = null), r;
				}, Dr = (e) => Er(e, 15), Or = !0, kr, Ar, jr = (e) => {
					if (Or) {
						kr = /* @__PURE__ */ new Int32Array(512), Ar = /* @__PURE__ */ new Int32Array(32);
						let t = 0;
						for (; t < 144;) e.lens[t++] = 8;
						for (; t < 256;) e.lens[t++] = 9;
						for (; t < 280;) e.lens[t++] = 7;
						for (; t < 288;) e.lens[t++] = 8;
						for (wn(1, e.lens, 0, 288, kr, 0, e.work, { bits: 9 }), t = 0; t < 32;) e.lens[t++] = 5;
						wn(2, e.lens, 0, 32, Ar, 0, e.work, { bits: 5 }), Or = !1;
					}
					e.lencode = kr, e.lenbits = 9, e.distcode = Ar, e.distbits = 5;
				}, Mr = (e, t, n, r) => {
					let i, a = e.state;
					return a.window === null && (a.wsize = 1 << a.wbits, a.wnext = 0, a.whave = 0, a.window = new Uint8Array(a.wsize)), r >= a.wsize ? (a.window.set(t.subarray(n - a.wsize, n), 0), a.wnext = 0, a.whave = a.wsize) : (i = a.wsize - a.wnext, i > r && (i = r), a.window.set(t.subarray(n - r, n - r + i), a.wnext), r -= i, r ? (a.window.set(t.subarray(n - r, n), 0), a.wnext = r, a.whave = a.wsize) : (a.wnext += i, a.wnext === a.wsize && (a.wnext = 0), a.whave < a.wsize && (a.whave += i))), 0;
				};
				var Nr = {
					inflateReset: wr,
					inflateReset2: Tr,
					inflateResetKeep: Cr,
					inflateInit: Dr,
					inflateInit2: Er,
					inflate: (e, t) => {
						let n, r, i, a, o, s, c, l, u, d, f, p, m, h, g = 0, _, v, y, b, x, S, C, w, T = /* @__PURE__ */ new Uint8Array(4), E, D, O = new Uint8Array([
							16,
							17,
							18,
							0,
							8,
							7,
							9,
							6,
							10,
							5,
							11,
							4,
							12,
							3,
							13,
							2,
							14,
							1,
							15
						]);
						if (Sr(e) || !e.output || !e.input && e.avail_in !== 0) return Pn;
						n = e.state, n.mode === Xn && (n.mode = Zn), o = e.next_out, i = e.output, c = e.avail_out, a = e.next_in, r = e.input, s = e.avail_in, l = n.hold, u = n.bits, d = s, f = c, w = jn;
						inf_leave: for (;;) switch (n.mode) {
							case zn:
								if (n.wrap === 0) {
									n.mode = Zn;
									break;
								}
								for (; u < 16;) {
									if (s === 0) break inf_leave;
									s--, l += r[a++] << u, u += 8;
								}
								if (n.wrap & 2 && l === 35615) {
									n.wbits === 0 && (n.wbits = 15), n.check = 0, T[0] = l & 255, T[1] = l >>> 8 & 255, n.check = me(n.check, T, 2, 0), l = 0, u = 0, n.mode = Bn;
									break;
								}
								if (n.head && (n.head.done = !1), !(n.wrap & 1) || (((l & 255) << 8) + (l >> 8)) % 31) {
									e.msg = "incorrect header check", n.mode = mr;
									break;
								}
								if ((l & 15) !== Rn) {
									e.msg = "unknown compression method", n.mode = mr;
									break;
								}
								if (l >>>= 4, u -= 4, C = (l & 15) + 8, n.wbits === 0 && (n.wbits = C), C > 15 || C > n.wbits) {
									e.msg = "invalid window size", n.mode = mr;
									break;
								}
								n.dmax = 1 << n.wbits, n.flags = 0, e.adler = n.check = 1, n.mode = l & 512 ? Jn : Xn, l = 0, u = 0;
								break;
							case Bn:
								for (; u < 16;) {
									if (s === 0) break inf_leave;
									s--, l += r[a++] << u, u += 8;
								}
								if (n.flags = l, (n.flags & 255) !== Rn) {
									e.msg = "unknown compression method", n.mode = mr;
									break;
								}
								if (n.flags & 57344) {
									e.msg = "unknown header flags set", n.mode = mr;
									break;
								}
								n.head && (n.head.text = l >> 8 & 1), n.flags & 512 && n.wrap & 4 && (T[0] = l & 255, T[1] = l >>> 8 & 255, n.check = me(n.check, T, 2, 0)), l = 0, u = 0, n.mode = Vn;
							case Vn:
								for (; u < 32;) {
									if (s === 0) break inf_leave;
									s--, l += r[a++] << u, u += 8;
								}
								n.head && (n.head.time = l), n.flags & 512 && n.wrap & 4 && (T[0] = l & 255, T[1] = l >>> 8 & 255, T[2] = l >>> 16 & 255, T[3] = l >>> 24 & 255, n.check = me(n.check, T, 4, 0)), l = 0, u = 0, n.mode = Hn;
							case Hn:
								for (; u < 16;) {
									if (s === 0) break inf_leave;
									s--, l += r[a++] << u, u += 8;
								}
								n.head && (n.head.xflags = l & 255, n.head.os = l >> 8), n.flags & 512 && n.wrap & 4 && (T[0] = l & 255, T[1] = l >>> 8 & 255, n.check = me(n.check, T, 2, 0)), l = 0, u = 0, n.mode = Un;
							case Un:
								if (n.flags & 1024) {
									for (; u < 16;) {
										if (s === 0) break inf_leave;
										s--, l += r[a++] << u, u += 8;
									}
									n.length = l, n.head && (n.head.extra_len = l), n.flags & 512 && n.wrap & 4 && (T[0] = l & 255, T[1] = l >>> 8 & 255, n.check = me(n.check, T, 2, 0)), l = 0, u = 0;
								} else n.head && (n.head.extra = null);
								n.mode = Wn;
							case Wn:
								if (n.flags & 1024 && (p = n.length, p > s && (p = s), p && (n.head && (C = n.head.extra_len - n.length, n.head.extra || (n.head.extra = new Uint8Array(n.head.extra_len)), n.head.extra.set(r.subarray(a, a + p), C)), n.flags & 512 && n.wrap & 4 && (n.check = me(n.check, r, p, a)), s -= p, a += p, n.length -= p), n.length)) break inf_leave;
								n.length = 0, n.mode = Gn;
							case Gn:
								if (n.flags & 2048) {
									if (s === 0) break inf_leave;
									p = 0;
									do
										C = r[a + p++], n.head && C && n.length < 65536 && (n.head.name += String.fromCharCode(C));
									while (C && p < s);
									if (n.flags & 512 && n.wrap & 4 && (n.check = me(n.check, r, p, a)), s -= p, a += p, C) break inf_leave;
								} else n.head && (n.head.name = null);
								n.length = 0, n.mode = Kn;
							case Kn:
								if (n.flags & 4096) {
									if (s === 0) break inf_leave;
									p = 0;
									do
										C = r[a + p++], n.head && C && n.length < 65536 && (n.head.comment += String.fromCharCode(C));
									while (C && p < s);
									if (n.flags & 512 && n.wrap & 4 && (n.check = me(n.check, r, p, a)), s -= p, a += p, C) break inf_leave;
								} else n.head && (n.head.comment = null);
								n.mode = qn;
							case qn:
								if (n.flags & 512) {
									for (; u < 16;) {
										if (s === 0) break inf_leave;
										s--, l += r[a++] << u, u += 8;
									}
									if (n.wrap & 4 && l !== (n.check & 65535)) {
										e.msg = "header crc mismatch", n.mode = mr;
										break;
									}
									l = 0, u = 0;
								}
								n.head && (n.head.hcrc = n.flags >> 9 & 1, n.head.done = !0), e.adler = n.check = 0, n.mode = Xn;
								break;
							case Jn:
								for (; u < 32;) {
									if (s === 0) break inf_leave;
									s--, l += r[a++] << u, u += 8;
								}
								e.adler = n.check = br(l), l = 0, u = 0, n.mode = Yn;
							case Yn:
								if (n.havedict === 0) return e.next_out = o, e.avail_out = c, e.next_in = a, e.avail_in = s, n.hold = l, n.bits = u, Nn;
								e.adler = n.check = 1, n.mode = Xn;
							case Xn: if (t === kn || t === An) break inf_leave;
							case Zn:
								if (n.last) {
									l >>>= u & 7, u -= u & 7, n.mode = dr;
									break;
								}
								for (; u < 3;) {
									if (s === 0) break inf_leave;
									s--, l += r[a++] << u, u += 8;
								}
								switch (n.last = l & 1, l >>>= 1, --u, l & 3) {
									case 0:
										n.mode = Qn;
										break;
									case 1:
										if (jr(n), n.mode = ir, t === An) {
											l >>>= 2, u -= 2;
											break inf_leave;
										}
										break;
									case 2:
										n.mode = tr;
										break;
									case 3: e.msg = "invalid block type", n.mode = mr;
								}
								l >>>= 2, u -= 2;
								break;
							case Qn:
								for (l >>>= u & 7, u -= u & 7; u < 32;) {
									if (s === 0) break inf_leave;
									s--, l += r[a++] << u, u += 8;
								}
								if ((l & 65535) != (l >>> 16 ^ 65535)) {
									e.msg = "invalid stored block lengths", n.mode = mr;
									break;
								}
								if (n.length = l & 65535, l = 0, u = 0, n.mode = $n, t === An) break inf_leave;
							case $n: n.mode = er;
							case er:
								if (p = n.length, p) {
									if (p > s && (p = s), p > c && (p = c), p === 0) break inf_leave;
									i.set(r.subarray(a, a + p), o), s -= p, a += p, c -= p, o += p, n.length -= p;
									break;
								}
								n.mode = Xn;
								break;
							case tr:
								for (; u < 14;) {
									if (s === 0) break inf_leave;
									s--, l += r[a++] << u, u += 8;
								}
								if (n.nlen = (l & 31) + 257, l >>>= 5, u -= 5, n.ndist = (l & 31) + 1, l >>>= 5, u -= 5, n.ncode = (l & 15) + 4, l >>>= 4, u -= 4, n.nlen > 286 || n.ndist > 30) {
									e.msg = "too many length or distance symbols", n.mode = mr;
									break;
								}
								n.have = 0, n.mode = nr;
							case nr:
								for (; n.have < n.ncode;) {
									for (; u < 3;) {
										if (s === 0) break inf_leave;
										s--, l += r[a++] << u, u += 8;
									}
									n.lens[O[n.have++]] = l & 7, l >>>= 3, u -= 3;
								}
								for (; n.have < 19;) n.lens[O[n.have++]] = 0;
								if (n.lencode = n.lendyn, n.lenbits = 7, E = { bits: n.lenbits }, w = wn(0, n.lens, 0, 19, n.lencode, 0, n.work, E), n.lenbits = E.bits, w) {
									e.msg = "invalid code lengths set", n.mode = mr;
									break;
								}
								n.have = 0, n.mode = rr;
							case rr:
								for (; n.have < n.nlen + n.ndist;) {
									for (; g = n.lencode[l & (1 << n.lenbits) - 1], _ = g >>> 24, v = g >>> 16 & 255, y = g & 65535, !(_ <= u);) {
										if (s === 0) break inf_leave;
										s--, l += r[a++] << u, u += 8;
									}
									if (y < 16) l >>>= _, u -= _, n.lens[n.have++] = y;
									else {
										if (y === 16) {
											for (D = _ + 2; u < D;) {
												if (s === 0) break inf_leave;
												s--, l += r[a++] << u, u += 8;
											}
											if (l >>>= _, u -= _, n.have === 0) {
												e.msg = "invalid bit length repeat", n.mode = mr;
												break;
											}
											C = n.lens[n.have - 1], p = 3 + (l & 3), l >>>= 2, u -= 2;
										} else if (y === 17) {
											for (D = _ + 3; u < D;) {
												if (s === 0) break inf_leave;
												s--, l += r[a++] << u, u += 8;
											}
											l >>>= _, u -= _, C = 0, p = 3 + (l & 7), l >>>= 3, u -= 3;
										} else {
											for (D = _ + 7; u < D;) {
												if (s === 0) break inf_leave;
												s--, l += r[a++] << u, u += 8;
											}
											l >>>= _, u -= _, C = 0, p = 11 + (l & 127), l >>>= 7, u -= 7;
										}
										if (n.have + p > n.nlen + n.ndist) {
											e.msg = "invalid bit length repeat", n.mode = mr;
											break;
										}
										for (; p--;) n.lens[n.have++] = C;
									}
								}
								if (n.mode === mr) break;
								if (n.lens[256] === 0) {
									e.msg = "invalid code -- missing end-of-block", n.mode = mr;
									break;
								}
								if (n.lenbits = 9, E = { bits: n.lenbits }, w = wn(1, n.lens, 0, n.nlen, n.lencode, 0, n.work, E), n.lenbits = E.bits, w) {
									e.msg = "invalid literal/lengths set", n.mode = mr;
									break;
								}
								if (n.distbits = 6, n.distcode = n.distdyn, E = { bits: n.distbits }, w = wn(2, n.lens, n.nlen, n.ndist, n.distcode, 0, n.work, E), n.distbits = E.bits, w) {
									e.msg = "invalid distances set", n.mode = mr;
									break;
								}
								if (n.mode = ir, t === An) break inf_leave;
							case ir: n.mode = ar;
							case ar:
								if (s >= 6 && c >= 258) {
									e.next_out = o, e.avail_out = c, e.next_in = a, e.avail_in = s, n.hold = l, n.bits = u, pn(e, f), o = e.next_out, i = e.output, c = e.avail_out, a = e.next_in, r = e.input, s = e.avail_in, l = n.hold, u = n.bits, n.mode === Xn && (n.back = -1);
									break;
								}
								for (n.back = 0; g = n.lencode[l & (1 << n.lenbits) - 1], _ = g >>> 24, v = g >>> 16 & 255, y = g & 65535, !(_ <= u);) {
									if (s === 0) break inf_leave;
									s--, l += r[a++] << u, u += 8;
								}
								if (v && !(v & 240)) {
									for (b = _, x = v, S = y; g = n.lencode[S + ((l & (1 << b + x) - 1) >> b)], _ = g >>> 24, v = g >>> 16 & 255, y = g & 65535, !(b + _ <= u);) {
										if (s === 0) break inf_leave;
										s--, l += r[a++] << u, u += 8;
									}
									l >>>= b, u -= b, n.back += b;
								}
								if (l >>>= _, u -= _, n.back += _, n.length = y, v === 0) {
									n.mode = ur;
									break;
								}
								if (v & 32) {
									n.back = -1, n.mode = Xn;
									break;
								}
								if (v & 64) {
									e.msg = "invalid literal/length code", n.mode = mr;
									break;
								}
								n.extra = v & 15, n.mode = or;
							case or:
								if (n.extra) {
									for (D = n.extra; u < D;) {
										if (s === 0) break inf_leave;
										s--, l += r[a++] << u, u += 8;
									}
									n.length += l & (1 << n.extra) - 1, l >>>= n.extra, u -= n.extra, n.back += n.extra;
								}
								n.was = n.length, n.mode = sr;
							case sr:
								for (; g = n.distcode[l & (1 << n.distbits) - 1], _ = g >>> 24, v = g >>> 16 & 255, y = g & 65535, !(_ <= u);) {
									if (s === 0) break inf_leave;
									s--, l += r[a++] << u, u += 8;
								}
								if (!(v & 240)) {
									for (b = _, x = v, S = y; g = n.distcode[S + ((l & (1 << b + x) - 1) >> b)], _ = g >>> 24, v = g >>> 16 & 255, y = g & 65535, !(b + _ <= u);) {
										if (s === 0) break inf_leave;
										s--, l += r[a++] << u, u += 8;
									}
									l >>>= b, u -= b, n.back += b;
								}
								if (l >>>= _, u -= _, n.back += _, v & 64) {
									e.msg = "invalid distance code", n.mode = mr;
									break;
								}
								n.offset = y, n.extra = v & 15, n.mode = cr;
							case cr:
								if (n.extra) {
									for (D = n.extra; u < D;) {
										if (s === 0) break inf_leave;
										s--, l += r[a++] << u, u += 8;
									}
									n.offset += l & (1 << n.extra) - 1, l >>>= n.extra, u -= n.extra, n.back += n.extra;
								}
								if (n.offset > n.dmax) {
									e.msg = "invalid distance too far back", n.mode = mr;
									break;
								}
								n.mode = lr;
							case lr:
								if (c === 0) break inf_leave;
								if (p = f - c, n.offset > p) {
									if (p = n.offset - p, p > n.whave && n.sane) {
										e.msg = "invalid distance too far back", n.mode = mr;
										break;
									}
									p > n.wnext ? (p -= n.wnext, m = n.wsize - p) : m = n.wnext - p, p > n.length && (p = n.length), h = n.window;
								} else h = i, m = o - n.offset, p = n.length;
								p > c && (p = c), c -= p, n.length -= p;
								do
									i[o++] = h[m++];
								while (--p);
								n.length === 0 && (n.mode = ar);
								break;
							case ur:
								if (c === 0) break inf_leave;
								i[o++] = n.length, c--, n.mode = ar;
								break;
							case dr:
								if (n.wrap) {
									for (; u < 32;) {
										if (s === 0) break inf_leave;
										s--, l |= r[a++] << u, u += 8;
									}
									if (f -= c, e.total_out += f, n.total += f, n.wrap & 4 && f && (e.adler = n.check = n.flags ? me(n.check, i, f, o - f) : fe(n.check, i, f, o - f)), f = c, n.wrap & 4 && (n.flags ? l : br(l)) !== n.check) {
										e.msg = "incorrect data check", n.mode = mr;
										break;
									}
									l = 0, u = 0;
								}
								n.mode = fr;
							case fr:
								if (n.wrap && n.flags) {
									for (; u < 32;) {
										if (s === 0) break inf_leave;
										s--, l += r[a++] << u, u += 8;
									}
									if (n.wrap & 4 && l !== (n.total & 4294967295)) {
										e.msg = "incorrect length check", n.mode = mr;
										break;
									}
									l = 0, u = 0;
								}
								n.mode = pr;
							case pr:
								w = Mn;
								break inf_leave;
							case mr:
								w = Fn;
								break inf_leave;
							case hr: return In;
							case gr:
							default: return Pn;
						}
						return e.next_out = o, e.avail_out = c, e.next_in = a, e.avail_in = s, n.hold = l, n.bits = u, (n.wsize || f !== e.avail_out && n.mode < mr && (n.mode < dr || t !== On)) && Mr(e, e.output, e.next_out, f - e.avail_out), d -= e.avail_in, f -= e.avail_out, e.total_in += d, e.total_out += f, n.total += f, n.wrap & 4 && f && (e.adler = n.check = n.flags ? me(n.check, i, f, e.next_out - f) : fe(n.check, i, f, e.next_out - f)), e.data_type = n.bits + (n.last ? 64 : 0) + (n.mode === Xn ? 128 : 0) + (n.mode === ir || n.mode === $n ? 256 : 0), (d === 0 && f === 0 || t === On) && w === jn && (w = Ln), w;
					},
					inflateEnd: (e) => {
						if (Sr(e)) return Pn;
						let t = e.state;
						return t.window &&= null, e.state = null, jn;
					},
					inflateGetHeader: (e, t) => {
						if (Sr(e)) return Pn;
						let n = e.state;
						return n.wrap & 2 ? (n.head = t, t.done = !1, jn) : Pn;
					},
					inflateSetDictionary: (e, t) => {
						let n = t.length, r, i, a;
						return Sr(e) || (r = e.state, r.wrap !== 0 && r.mode !== Yn) ? Pn : r.mode === Yn && (i = 1, i = fe(i, t, n, 0), i !== r.check) ? Fn : (a = Mr(e, t, n, n), a ? (r.mode = hr, In) : (r.havedict = 1, jn));
					},
					inflateInfo: "pako inflate (from Nodeca project)"
				};
				function Pr() {
					this.text = 0, this.time = 0, this.xflags = 0, this.os = 0, this.extra = null, this.extra_len = 0, this.name = "", this.comment = "", this.hcrc = 0, this.done = !1;
				}
				var Fr = Pr;
				let Ir = Object.prototype.toString, { Z_NO_FLUSH: Lr, Z_FINISH: Rr, Z_OK: zr, Z_STREAM_END: Br, Z_NEED_DICT: Vr, Z_STREAM_ERROR: Hr, Z_DATA_ERROR: Ur, Z_MEM_ERROR: Wr } = ge;
				function Gr(e) {
					this.options = Vt.assign({
						chunkSize: 65536,
						windowBits: 15,
						to: ""
					}, e || {});
					let t = this.options;
					t.raw && t.windowBits >= 0 && t.windowBits < 16 && (t.windowBits = -t.windowBits, t.windowBits === 0 && (t.windowBits = -15)), t.windowBits >= 0 && t.windowBits < 16 && !(e && e.windowBits) && (t.windowBits += 32), t.windowBits > 15 && t.windowBits < 48 && (t.windowBits & 15 || (t.windowBits |= 15)), this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new Jt(), this.strm.avail_out = 0;
					let n = Nr.inflateInit2(this.strm, t.windowBits);
					if (n !== zr || (this.header = new Fr(), Nr.inflateGetHeader(this.strm, this.header), t.dictionary && (typeof t.dictionary == "string" ? t.dictionary = Kt.string2buf(t.dictionary) : Ir.call(t.dictionary) === "[object ArrayBuffer]" && (t.dictionary = new Uint8Array(t.dictionary)), t.raw && (n = Nr.inflateSetDictionary(this.strm, t.dictionary), n !== zr)))) throw Error(he[n]);
				}
				Gr.prototype.push = function(e, t) {
					let n = this.strm, r = this.options.chunkSize, i = this.options.dictionary, a, o, s;
					if (this.ended) return !1;
					for (o = t === ~~t ? t : t === !0 ? Rr : Lr, n.input = Ir.call(e) === "[object ArrayBuffer]" ? new Uint8Array(e) : e, n.next_in = 0, n.avail_in = n.input.length;;) {
						for (n.avail_out === 0 && (n.output = new Uint8Array(r), n.next_out = 0, n.avail_out = r), a = Nr.inflate(n, o), a === Vr && i && (a = Nr.inflateSetDictionary(n, i), a === zr ? a = Nr.inflate(n, o) : a === Ur && (a = Vr)); n.avail_in > 0 && a === Br && n.state.wrap > 0 && e[n.next_in] !== 0;) Nr.inflateReset(n), a = Nr.inflate(n, o);
						switch (a) {
							case Hr:
							case Ur:
							case Vr:
							case Wr: return this.onEnd(a), this.ended = !0, !1;
						}
						if (s = n.avail_out, n.next_out && (n.avail_out === 0 || a === Br)) {
							if (this.options.to === "string") {
								let e = Kt.utf8border(n.output, n.next_out), t = n.next_out - e, i = Kt.buf2string(n.output, e);
								n.next_out = t, n.avail_out = r - t, t && n.output.set(n.output.subarray(e, e + t), 0), this.onData(i);
							} else this.onData(n.output.length === n.next_out ? n.output : n.output.subarray(0, n.next_out));
						}
						if (a !== zr || s !== 0) {
							if (a === Br) return a = Nr.inflateEnd(this.strm), this.onEnd(a), this.ended = !0, !0;
							if (n.avail_in === 0) break;
						}
					}
					return !0;
				}, Gr.prototype.onData = function(e) {
					this.chunks.push(e);
				}, Gr.prototype.onEnd = function(e) {
					e === zr && (this.result = this.options.to === "string" ? this.chunks.join("") : Vt.flattenChunks(this.chunks)), this.chunks = [], this.err = e, this.msg = this.strm.msg;
				};
				function Kr(e, t) {
					let n = new Gr(t);
					if (n.push(e), n.err) throw n.msg || he[n.err];
					return n.result;
				}
				function qr(e, t) {
					return t ||= {}, t.raw = !0, Kr(e, t);
				}
				var Jr = {
					Inflate: Gr,
					inflate: Kr,
					inflateRaw: qr,
					ungzip: Kr,
					constants: ge
				};
				let { Deflate: Yr, deflate: Xr, deflateRaw: Zr, gzip: Qr } = un, { Inflate: $r, inflate: ei, inflateRaw: ti, ungzip: ni } = Jr;
				var ri = Yr, ii = Xr, ai = Zr, oi = Qr, si = $r, ci = ei, li = ti, ui = ni, di = ge, fi = {
					Deflate: ri,
					deflate: ii,
					deflateRaw: ai,
					gzip: oi,
					Inflate: si,
					inflate: ci,
					inflateRaw: li,
					ungzip: ui,
					constants: di
				};
			},
			"./node_modules/upng-js/UPNG.js"(e, t, n) {
				(function() {
					var t = {}, r;
					e.exports = t, r = n("./node_modules/upng-js/node_modules/pako/index.js"), (function(e, t) {
						e.toRGBA8 = function(t) {
							var n = t.width, r = t.height;
							if (t.tabs.acTL == null) return [e.toRGBA8.decodeImage(t.data, n, r, t).buffer];
							var i = [];
							t.frames[0].data ?? (t.frames[0].data = t.data);
							for (var a, o = new Uint8Array(n * r * 4), s = 0; s < t.frames.length; s++) {
								var c = t.frames[s], l = c.rect.x, u = c.rect.y, d = c.rect.width, f = c.rect.height, p = e.toRGBA8.decodeImage(c.data, d, f, t);
								if (s == 0 ? a = p : c.blend == 0 ? e._copyTile(p, d, f, a, n, r, l, u, 0) : c.blend == 1 && e._copyTile(p, d, f, a, n, r, l, u, 1), i.push(a.buffer), a = a.slice(0), c.dispose != 0) {
									if (c.dispose == 1) e._copyTile(o, d, f, a, n, r, l, u, 0);
									else if (c.dispose == 2) {
										for (var m = s - 1; t.frames[m].dispose == 2;) m--;
										a = new Uint8Array(i[m]).slice(0);
									}
								}
							}
							return i;
						}, e.toRGBA8.decodeImage = function(t, n, r, i) {
							var a = n * r, o = e.decode._getBPP(i), s = Math.ceil(n * o / 8), c = new Uint8Array(a * 4), l = new Uint32Array(c.buffer), u = i.ctype, d = i.depth, f = e._bin.readUshort;
							if (u == 6) {
								var p = a << 2;
								if (d == 8) for (var m = 0; m < p; m++) c[m] = t[m];
								if (d == 16) for (var m = 0; m < p; m++) c[m] = t[m << 1];
							} else if (u == 2) {
								var h = i.tabs.tRNS, g = -1, _ = -1, v = -1;
								if (h && (g = h[0], _ = h[1], v = h[2]), d == 8) for (var m = 0; m < a; m++) {
									var y = m << 2, b = m * 3;
									c[y] = t[b], c[y + 1] = t[b + 1], c[y + 2] = t[b + 2], c[y + 3] = 255, g != -1 && t[b] == g && t[b + 1] == _ && t[b + 2] == v && (c[y + 3] = 0);
								}
								if (d == 16) for (var m = 0; m < a; m++) {
									var y = m << 2, b = m * 6;
									c[y] = t[b], c[y + 1] = t[b + 2], c[y + 2] = t[b + 4], c[y + 3] = 255, g != -1 && f(t, b) == g && f(t, b + 2) == _ && f(t, b + 4) == v && (c[y + 3] = 0);
								}
							} else if (u == 3) {
								var x = i.tabs.PLTE, S = i.tabs.tRNS, C = S ? S.length : 0;
								if (d == 1) for (var w = 0; w < r; w++) for (var T = w * s, E = w * n, m = 0; m < n; m++) {
									var y = E + m << 2, D = t[T + (m >> 3)] >> 7 - ((m & 7) << 0) & 1, O = 3 * D;
									c[y] = x[O], c[y + 1] = x[O + 1], c[y + 2] = x[O + 2], c[y + 3] = D < C ? S[D] : 255;
								}
								if (d == 2) for (var w = 0; w < r; w++) for (var T = w * s, E = w * n, m = 0; m < n; m++) {
									var y = E + m << 2, D = t[T + (m >> 2)] >> 6 - ((m & 3) << 1) & 3, O = 3 * D;
									c[y] = x[O], c[y + 1] = x[O + 1], c[y + 2] = x[O + 2], c[y + 3] = D < C ? S[D] : 255;
								}
								if (d == 4) for (var w = 0; w < r; w++) for (var T = w * s, E = w * n, m = 0; m < n; m++) {
									var y = E + m << 2, D = t[T + (m >> 1)] >> 4 - ((m & 1) << 2) & 15, O = 3 * D;
									c[y] = x[O], c[y + 1] = x[O + 1], c[y + 2] = x[O + 2], c[y + 3] = D < C ? S[D] : 255;
								}
								if (d == 8) for (var m = 0; m < a; m++) {
									var y = m << 2, D = t[m], O = 3 * D;
									c[y] = x[O], c[y + 1] = x[O + 1], c[y + 2] = x[O + 2], c[y + 3] = D < C ? S[D] : 255;
								}
							} else if (u == 4) {
								if (d == 8) for (var m = 0; m < a; m++) {
									var y = m << 2, k = m << 1, A = t[k];
									c[y] = A, c[y + 1] = A, c[y + 2] = A, c[y + 3] = t[k + 1];
								}
								if (d == 16) for (var m = 0; m < a; m++) {
									var y = m << 2, k = m << 2, A = t[k];
									c[y] = A, c[y + 1] = A, c[y + 2] = A, c[y + 3] = t[k + 2];
								}
							} else if (u == 0) {
								var g = i.tabs.tRNS ? i.tabs.tRNS : -1;
								if (d == 1) for (var m = 0; m < a; m++) {
									var A = 255 * (t[m >> 3] >> 7 - (m & 7) & 1), j = A == g * 255 ? 0 : 255;
									l[m] = j << 24 | A << 16 | A << 8 | A;
								}
								if (d == 2) for (var m = 0; m < a; m++) {
									var A = 85 * (t[m >> 2] >> 6 - ((m & 3) << 1) & 3), j = A == g * 85 ? 0 : 255;
									l[m] = j << 24 | A << 16 | A << 8 | A;
								}
								if (d == 4) for (var m = 0; m < a; m++) {
									var A = 17 * (t[m >> 1] >> 4 - ((m & 1) << 2) & 15), j = A == g * 17 ? 0 : 255;
									l[m] = j << 24 | A << 16 | A << 8 | A;
								}
								if (d == 8) for (var m = 0; m < a; m++) {
									var A = t[m], j = A == g ? 0 : 255;
									l[m] = j << 24 | A << 16 | A << 8 | A;
								}
								if (d == 16) for (var m = 0; m < a; m++) {
									var A = t[m << 1], j = f(t, m << 1) == g ? 0 : 255;
									l[m] = j << 24 | A << 16 | A << 8 | A;
								}
							}
							return c;
						}, e.decode = function(t) {
							for (var n = new Uint8Array(t), r = 8, i = e._bin, a = i.readUshort, o = i.readUint, s = {
								tabs: {},
								frames: []
							}, c = new Uint8Array(n.length), l = 0, u, d = 0, f = [
								137,
								80,
								78,
								71,
								13,
								10,
								26,
								10
							], p = 0; p < 8; p++) if (n[p] != f[p]) throw "The input is not a PNG file!";
							for (; r < n.length;) {
								var m = i.readUint(n, r);
								r += 4;
								var h = i.readASCII(n, r, 4);
								if (r += 4, h == "IHDR") e.decode._IHDR(n, r, s);
								else if (h == "IDAT") {
									for (var p = 0; p < m; p++) c[l + p] = n[r + p];
									l += m;
								} else if (h == "acTL") s.tabs[h] = {
									num_frames: o(n, r),
									num_plays: o(n, r + 4)
								}, u = new Uint8Array(n.length);
								else if (h == "fcTL") {
									if (d != 0) {
										var g = s.frames[s.frames.length - 1];
										g.data = e.decode._decompress(s, u.slice(0, d), g.rect.width, g.rect.height), d = 0;
									}
									var _ = {
										x: o(n, r + 12),
										y: o(n, r + 16),
										width: o(n, r + 4),
										height: o(n, r + 8)
									}, v = a(n, r + 22);
									v = a(n, r + 20) / (v == 0 ? 100 : v);
									var y = {
										rect: _,
										delay: Math.round(v * 1e3),
										dispose: n[r + 24],
										blend: n[r + 25]
									};
									s.frames.push(y);
								} else if (h == "fdAT") {
									for (var p = 0; p < m - 4; p++) u[d + p] = n[r + p + 4];
									d += m - 4;
								} else if (h == "pHYs") s.tabs[h] = [
									i.readUint(n, r),
									i.readUint(n, r + 4),
									n[r + 8]
								];
								else if (h == "cHRM") {
									s.tabs[h] = [];
									for (var p = 0; p < 8; p++) s.tabs[h].push(i.readUint(n, r + p * 4));
								} else if (h == "tEXt") {
									s.tabs[h] ?? (s.tabs[h] = {});
									var b = i.nextZero(n, r), x = i.readASCII(n, r, b - r), S = i.readASCII(n, b + 1, r + m - b - 1);
									s.tabs[h][x] = S;
								} else if (h == "iTXt") {
									s.tabs[h] ?? (s.tabs[h] = {});
									var b = 0, C = r;
									b = i.nextZero(n, C);
									var x = i.readASCII(n, C, b - C);
									C = b + 1;
									var w = n[C], T = n[C + 1];
									C += 2, b = i.nextZero(n, C);
									var E = i.readASCII(n, C, b - C);
									C = b + 1, b = i.nextZero(n, C);
									var D = i.readUTF8(n, C, b - C);
									C = b + 1;
									var S = i.readUTF8(n, C, m - (C - r));
									s.tabs[h][x] = S;
								} else if (h == "PLTE") s.tabs[h] = i.readBytes(n, r, m);
								else if (h == "hIST") {
									var O = s.tabs.PLTE.length / 3;
									s.tabs[h] = [];
									for (var p = 0; p < O; p++) s.tabs[h].push(a(n, r + p * 2));
								} else if (h == "tRNS") s.ctype == 3 ? s.tabs[h] = i.readBytes(n, r, m) : s.ctype == 0 ? s.tabs[h] = a(n, r) : s.ctype == 2 && (s.tabs[h] = [
									a(n, r),
									a(n, r + 2),
									a(n, r + 4)
								]);
								else if (h == "gAMA") s.tabs[h] = i.readUint(n, r) / 1e5;
								else if (h == "sRGB") s.tabs[h] = n[r];
								else if (h == "bKGD") s.ctype == 0 || s.ctype == 4 ? s.tabs[h] = [a(n, r)] : s.ctype == 2 || s.ctype == 6 ? s.tabs[h] = [
									a(n, r),
									a(n, r + 2),
									a(n, r + 4)
								] : s.ctype == 3 && (s.tabs[h] = n[r]);
								else if (h == "IEND") {
									if (d != 0) {
										var g = s.frames[s.frames.length - 1];
										g.data = e.decode._decompress(s, u.slice(0, d), g.rect.width, g.rect.height), d = 0;
									}
									s.data = e.decode._decompress(s, c, s.width, s.height);
									break;
								}
								r += m;
								var k = i.readUint(n, r);
								r += 4;
							}
							return delete s.compress, delete s.interlace, delete s.filter, s;
						}, e.decode._decompress = function(t, n, r, i) {
							return t.compress == 0 && (n = e.decode._inflate(n)), t.interlace == 0 ? n = e.decode._filterZero(n, t, 0, r, i) : t.interlace == 1 && (n = e.decode._readInterlace(n, t)), n;
						}, e.decode._inflate = function(e) {
							return t.inflate(e);
						}, e.decode._readInterlace = function(t, n) {
							for (var r = n.width, i = n.height, a = e.decode._getBPP(n), o = a >> 3, s = Math.ceil(r * a / 8), c = new Uint8Array(i * s), l = 0, u = [
								0,
								0,
								4,
								0,
								2,
								0,
								1
							], d = [
								0,
								4,
								0,
								2,
								0,
								1,
								0
							], f = [
								8,
								8,
								8,
								4,
								4,
								2,
								2
							], p = [
								8,
								8,
								4,
								4,
								2,
								2,
								1
							], m = 0; m < 7;) {
								for (var h = f[m], g = p[m], _ = 0, v = 0, y = u[m]; y < i;) y += h, v++;
								for (var b = d[m]; b < r;) b += g, _++;
								var x = Math.ceil(_ * a / 8);
								e.decode._filterZero(t, n, l, _, v);
								for (var S = 0, C = u[m]; C < i;) {
									for (var w = d[m], T = l + S * x << 3; w < r;) {
										if (a == 1) {
											var E = t[T >> 3];
											E = E >> 7 - (T & 7) & 1, c[C * s + (w >> 3)] |= E << 7 - ((w & 3) << 0);
										}
										if (a == 2) {
											var E = t[T >> 3];
											E = E >> 6 - (T & 7) & 3, c[C * s + (w >> 2)] |= E << 6 - ((w & 3) << 1);
										}
										if (a == 4) {
											var E = t[T >> 3];
											E = E >> 4 - (T & 7) & 15, c[C * s + (w >> 1)] |= E << 4 - ((w & 1) << 2);
										}
										if (a >= 8) for (var D = C * s + w * o, O = 0; O < o; O++) c[D + O] = t[(T >> 3) + O];
										T += a, w += g;
									}
									S++, C += h;
								}
								_ * v != 0 && (l += v * (1 + x)), m += 1;
							}
							return c;
						}, e.decode._getBPP = function(e) {
							return [
								1,
								null,
								3,
								1,
								2,
								null,
								4
							][e.ctype] * e.depth;
						}, e.decode._filterZero = function(t, n, r, i, a) {
							var o = e.decode._getBPP(n), s = Math.ceil(i * o / 8), c = e.decode._paeth;
							o = Math.ceil(o / 8);
							for (var l = 0; l < a; l++) {
								var u = r + l * s, d = u + l + 1, f = t[d - 1];
								if (f == 0) for (var p = 0; p < s; p++) t[u + p] = t[d + p];
								else if (f == 1) {
									for (var p = 0; p < o; p++) t[u + p] = t[d + p];
									for (var p = o; p < s; p++) t[u + p] = t[d + p] + t[u + p - o] & 255;
								} else if (l == 0) {
									for (var p = 0; p < o; p++) t[u + p] = t[d + p];
									if (f == 2) for (var p = o; p < s; p++) t[u + p] = t[d + p] & 255;
									if (f == 3) for (var p = o; p < s; p++) t[u + p] = t[d + p] + (t[u + p - o] >> 1) & 255;
									if (f == 4) for (var p = o; p < s; p++) t[u + p] = t[d + p] + c(t[u + p - o], 0, 0) & 255;
								} else {
									if (f == 2) for (var p = 0; p < s; p++) t[u + p] = t[d + p] + t[u + p - s] & 255;
									if (f == 3) {
										for (var p = 0; p < o; p++) t[u + p] = t[d + p] + (t[u + p - s] >> 1) & 255;
										for (var p = o; p < s; p++) t[u + p] = t[d + p] + (t[u + p - s] + t[u + p - o] >> 1) & 255;
									}
									if (f == 4) {
										for (var p = 0; p < o; p++) t[u + p] = t[d + p] + c(0, t[u + p - s], 0) & 255;
										for (var p = o; p < s; p++) t[u + p] = t[d + p] + c(t[u + p - o], t[u + p - s], t[u + p - o - s]) & 255;
									}
								}
							}
							return t;
						}, e.decode._paeth = function(e, t, n) {
							var r = e + t - n, i = Math.abs(r - e), a = Math.abs(r - t), o = Math.abs(r - n);
							return i <= a && i <= o ? e : a <= o ? t : n;
						}, e.decode._IHDR = function(t, n, r) {
							var i = e._bin;
							r.width = i.readUint(t, n), n += 4, r.height = i.readUint(t, n), n += 4, r.depth = t[n], n++, r.ctype = t[n], n++, r.compress = t[n], n++, r.filter = t[n], n++, r.interlace = t[n], n++;
						}, e._bin = {
							nextZero: function(e, t) {
								for (; e[t] != 0;) t++;
								return t;
							},
							readUshort: function(e, t) {
								return e[t] << 8 | e[t + 1];
							},
							writeUshort: function(e, t, n) {
								e[t] = n >> 8 & 255, e[t + 1] = n & 255;
							},
							readUint: function(e, t) {
								return e[t] * 16777216 + (e[t + 1] << 16 | e[t + 2] << 8 | e[t + 3]);
							},
							writeUint: function(e, t, n) {
								e[t] = n >> 24 & 255, e[t + 1] = n >> 16 & 255, e[t + 2] = n >> 8 & 255, e[t + 3] = n & 255;
							},
							readASCII: function(e, t, n) {
								for (var r = "", i = 0; i < n; i++) r += String.fromCharCode(e[t + i]);
								return r;
							},
							writeASCII: function(e, t, n) {
								for (var r = 0; r < n.length; r++) e[t + r] = n.charCodeAt(r);
							},
							readBytes: function(e, t, n) {
								for (var r = [], i = 0; i < n; i++) r.push(e[t + i]);
								return r;
							},
							pad: function(e) {
								return e.length < 2 ? "0" + e : e;
							},
							readUTF8: function(t, n, r) {
								for (var i = "", a, o = 0; o < r; o++) i += "%" + e._bin.pad(t[n + o].toString(16));
								try {
									a = decodeURIComponent(i);
								} catch {
									return e._bin.readASCII(t, n, r);
								}
								return a;
							}
						}, e._copyTile = function(e, t, n, r, i, a, o, s, c) {
							for (var l = Math.min(t, i), u = Math.min(n, a), d = 0, f = 0, p = 0; p < u; p++) for (var m = 0; m < l; m++) if (o >= 0 && s >= 0 ? (d = p * t + m << 2, f = (s + p) * i + o + m << 2) : (d = (-s + p) * t - o + m << 2, f = p * i + m << 2), c == 0) r[f] = e[d], r[f + 1] = e[d + 1], r[f + 2] = e[d + 2], r[f + 3] = e[d + 3];
							else if (c == 1) {
								var h = e[d + 3] * (1 / 255), g = e[d] * h, _ = e[d + 1] * h, v = e[d + 2] * h, y = r[f + 3] * (1 / 255), b = r[f] * y, x = r[f + 1] * y, S = r[f + 2] * y, C = 1 - h, w = h + y * C, T = w == 0 ? 0 : 1 / w;
								r[f + 3] = 255 * w, r[f + 0] = (g + b * C) * T, r[f + 1] = (_ + x * C) * T, r[f + 2] = (v + S * C) * T;
							} else if (c == 2) {
								var h = e[d + 3], g = e[d], _ = e[d + 1], v = e[d + 2], y = r[f + 3], b = r[f], x = r[f + 1], S = r[f + 2];
								h == y && g == b && _ == x && v == S ? (r[f] = 0, r[f + 1] = 0, r[f + 2] = 0, r[f + 3] = 0) : (r[f] = g, r[f + 1] = _, r[f + 2] = v, r[f + 3] = h);
							} else if (c == 3) {
								var h = e[d + 3], g = e[d], _ = e[d + 1], v = e[d + 2], y = r[f + 3], b = r[f], x = r[f + 1], S = r[f + 2];
								if (h == y && g == b && _ == x && v == S) continue;
								if (h < 220 && y > 20) return !1;
							}
							return !0;
						}, e.encode = function(t, n, r, i, a, o) {
							i ??= 0, o ??= !1;
							for (var s = new Uint8Array(t[0].byteLength * t.length + 100), c = [
								137,
								80,
								78,
								71,
								13,
								10,
								26,
								10
							], l = 0; l < 8; l++) s[l] = c[l];
							var u = 8, d = e._bin, f = e.crc.crc, p = d.writeUint, m = d.writeUshort, h = d.writeASCII, g = e.encode.compressPNG(t, n, r, i, o);
							p(s, u, 13), u += 4, h(s, u, "IHDR"), u += 4, p(s, u, n), u += 4, p(s, u, r), u += 4, s[u] = g.depth, u++, s[u] = g.ctype, u++, s[u] = 0, u++, s[u] = 0, u++, s[u] = 0, u++, p(s, u, f(s, u - 17, 17)), u += 4, p(s, u, 1), u += 4, h(s, u, "sRGB"), u += 4, s[u] = 1, u++, p(s, u, f(s, u - 5, 5)), u += 4;
							var _ = t.length > 1;
							if (_ && (p(s, u, 8), u += 4, h(s, u, "acTL"), u += 4, p(s, u, t.length), u += 4, p(s, u, 0), u += 4, p(s, u, f(s, u - 12, 12)), u += 4), g.ctype == 3) {
								var v = g.plte.length;
								p(s, u, v * 3), u += 4, h(s, u, "PLTE"), u += 4;
								for (var l = 0; l < v; l++) {
									var y = l * 3, b = g.plte[l], x = b & 255, S = b >> 8 & 255, C = b >> 16 & 255;
									s[u + y + 0] = x, s[u + y + 1] = S, s[u + y + 2] = C;
								}
								if (u += v * 3, p(s, u, f(s, u - v * 3 - 4, v * 3 + 4)), u += 4, g.gotAlpha) {
									p(s, u, v), u += 4, h(s, u, "tRNS"), u += 4;
									for (var l = 0; l < v; l++) s[u + l] = g.plte[l] >> 24 & 255;
									u += v, p(s, u, f(s, u - v - 4, v + 4)), u += 4;
								}
							}
							for (var w = 0, T = 0; T < g.frames.length; T++) {
								var E = g.frames[T];
								_ && (p(s, u, 26), u += 4, h(s, u, "fcTL"), u += 4, p(s, u, w++), u += 4, p(s, u, E.rect.width), u += 4, p(s, u, E.rect.height), u += 4, p(s, u, E.rect.x), u += 4, p(s, u, E.rect.y), u += 4, m(s, u, a[T]), u += 2, m(s, u, 1e3), u += 2, s[u] = E.dispose, u++, s[u] = E.blend, u++, p(s, u, f(s, u - 30, 30)), u += 4);
								var D = E.cimg, v = D.length;
								p(s, u, v + (T == 0 ? 0 : 4)), u += 4;
								var O = u;
								h(s, u, T == 0 ? "IDAT" : "fdAT"), u += 4, T != 0 && (p(s, u, w++), u += 4);
								for (var l = 0; l < v; l++) s[u + l] = D[l];
								u += v, p(s, u, f(s, O, u - O)), u += 4;
							}
							return p(s, u, 0), u += 4, h(s, u, "IEND"), u += 4, p(s, u, f(s, u - 4, 4)), u += 4, s.buffer.slice(0, u);
						}, e.encode.compressPNG = function(t, n, r, i, a) {
							for (var o = e.encode.compress(t, n, r, i, !1, a), s = 0; s < t.length; s++) {
								var c = o.frames[s], l = c.rect.width, u = c.rect.height, d = c.bpl, f = c.bpp, p = new Uint8Array(u * d + u);
								c.cimg = e.encode._filterZero(c.img, u, f, d, p);
							}
							return o;
						}, e.encode.compress = function(t, n, r, i, a, o) {
							o ??= !1;
							for (var s = 6, c = 8, l = 4, u = 255, d = 0; d < t.length; d++) for (var f = new Uint8Array(t[d]), p = f.length, m = 0; m < p; m += 4) u &= f[m + 3];
							var h = u != 255, g = {}, _ = [];
							if (t.length != 0 && (g[0] = 0, _.push(0), i != 0 && i--), i != 0) {
								var v = e.quantize(t, i, a);
								t = v.bufs;
								for (var m = 0; m < v.plte.length; m++) {
									var y = v.plte[m].est.rgba;
									g[y] ?? (g[y] = _.length, _.push(y));
								}
							} else for (var d = 0; d < t.length; d++) for (var b = new Uint32Array(t[d]), p = b.length, m = 0; m < p; m++) {
								var y = b[m];
								if ((m < n || y != b[m - 1] && y != b[m - n]) && g[y] == null && (g[y] = _.length, _.push(y), _.length >= 300)) break;
							}
							var x = h ? a : !1, S = _.length;
							S <= 256 && o == 0 && (c = S <= 2 ? 1 : S <= 4 ? 2 : S <= 16 ? 4 : 8, a && (c = 8), h = !0);
							for (var C = [], d = 0; d < t.length; d++) {
								var w = new Uint8Array(t[d]), T = new Uint32Array(w.buffer), E = 0, D = 0, O = n, k = r, A = 0;
								if (d != 0 && !x) {
									for (var j = a || d == 1 || C[C.length - 2].dispose == 2 ? 1 : 2, M = 0, N = 1e9, P = 0; P < j; P++) {
										for (var F = new Uint8Array(t[d - 1 - P]), I = new Uint32Array(t[d - 1 - P]), L = n, R = r, z = -1, B = -1, V = 0; V < r; V++) for (var H = 0; H < n; H++) {
											var m = V * n + H;
											T[m] != I[m] && (H < L && (L = H), H > z && (z = H), V < R && (R = V), V > B && (B = V));
										}
										var U = z == -1 ? 1 : (z - L + 1) * (B - R + 1);
										U < N && (N = U, M = P, z == -1 ? (E = D = 0, O = k = 1) : (E = L, D = R, O = z - L + 1, k = B - R + 1));
									}
									var F = new Uint8Array(t[d - 1 - M]);
									M == 1 && (C[C.length - 1].dispose = 2);
									var W = new Uint8Array(O * k * 4), G = new Uint32Array(W.buffer);
									e._copyTile(F, n, r, W, O, k, -E, -D, 0), e._copyTile(w, n, r, W, O, k, -E, -D, 3) ? (e._copyTile(w, n, r, W, O, k, -E, -D, 2), A = 1) : (e._copyTile(w, n, r, W, O, k, -E, -D, 0), A = 0), w = W, T = new Uint32Array(w.buffer);
								}
								var ee = 4 * O;
								if (S <= 256 && o == 0) {
									ee = Math.ceil(c * O / 8);
									for (var W = new Uint8Array(ee * k), V = 0; V < k; V++) {
										var m = V * ee, te = V * O;
										if (c == 8) for (var H = 0; H < O; H++) W[m + H] = g[T[te + H]];
										else if (c == 4) for (var H = 0; H < O; H++) W[m + (H >> 1)] |= g[T[te + H]] << 4 - (H & 1) * 4;
										else if (c == 2) for (var H = 0; H < O; H++) W[m + (H >> 2)] |= g[T[te + H]] << 6 - (H & 3) * 2;
										else if (c == 1) for (var H = 0; H < O; H++) W[m + (H >> 3)] |= g[T[te + H]] << 7 - (H & 7) * 1;
									}
									w = W, s = 3, l = 1;
								} else if (h == 0 && t.length == 1) {
									for (var W = new Uint8Array(O * k * 3), ne = O * k, m = 0; m < ne; m++) {
										var re = m * 3, ie = m * 4;
										W[re] = w[ie], W[re + 1] = w[ie + 1], W[re + 2] = w[ie + 2];
									}
									w = W, s = 2, l = 3, ee = 3 * O;
								}
								C.push({
									rect: {
										x: E,
										y: D,
										width: O,
										height: k
									},
									img: w,
									bpl: ee,
									bpp: l,
									blend: A,
									dispose: +!!x
								});
							}
							return {
								ctype: s,
								depth: c,
								plte: _,
								gotAlpha: h,
								frames: C
							};
						}, e.encode._filterZero = function(n, r, i, a, o) {
							for (var s = [], c = 0; c < 5; c++) if (!(r * a > 5e5 && (c == 2 || c == 3 || c == 4))) {
								for (var l = 0; l < r; l++) e.encode._filterLine(o, n, l, a, i, c);
								if (s.push(t.deflate(o)), i == 1) break;
							}
							for (var u, d = 1e9, f = 0; f < s.length; f++) s[f].length < d && (u = f, d = s[f].length);
							return s[u];
						}, e.encode._filterLine = function(t, n, r, i, a, o) {
							var s = r * i, c = s + r, l = e.decode._paeth;
							if (t[c] = o, c++, o == 0) for (var u = 0; u < i; u++) t[c + u] = n[s + u];
							else if (o == 1) {
								for (var u = 0; u < a; u++) t[c + u] = n[s + u];
								for (var u = a; u < i; u++) t[c + u] = n[s + u] - n[s + u - a] + 256 & 255;
							} else if (r == 0) {
								for (var u = 0; u < a; u++) t[c + u] = n[s + u];
								if (o == 2) for (var u = a; u < i; u++) t[c + u] = n[s + u];
								if (o == 3) for (var u = a; u < i; u++) t[c + u] = n[s + u] - (n[s + u - a] >> 1) + 256 & 255;
								if (o == 4) for (var u = a; u < i; u++) t[c + u] = n[s + u] - l(n[s + u - a], 0, 0) + 256 & 255;
							} else {
								if (o == 2) for (var u = 0; u < i; u++) t[c + u] = n[s + u] + 256 - n[s + u - i] & 255;
								if (o == 3) {
									for (var u = 0; u < a; u++) t[c + u] = n[s + u] + 256 - (n[s + u - i] >> 1) & 255;
									for (var u = a; u < i; u++) t[c + u] = n[s + u] + 256 - (n[s + u - i] + n[s + u - a] >> 1) & 255;
								}
								if (o == 4) {
									for (var u = 0; u < a; u++) t[c + u] = n[s + u] + 256 - l(0, n[s + u - i], 0) & 255;
									for (var u = a; u < i; u++) t[c + u] = n[s + u] + 256 - l(n[s + u - a], n[s + u - i], n[s + u - a - i]) & 255;
								}
							}
						}, e.crc = {
							table: (function() {
								for (var e = /* @__PURE__ */ new Uint32Array(256), t = 0; t < 256; t++) {
									for (var n = t, r = 0; r < 8; r++) n & 1 ? n = 3988292384 ^ n >>> 1 : n >>>= 1;
									e[t] = n;
								}
								return e;
							})(),
							update: function(t, n, r, i) {
								for (var a = 0; a < i; a++) t = e.crc.table[(t ^ n[r + a]) & 255] ^ t >>> 8;
								return t;
							},
							crc: function(t, n, r) {
								return e.crc.update(4294967295, t, n, r) ^ 4294967295;
							}
						}, e.quantize = function(t, n, r) {
							for (var i = [], a = 0, o = 0; o < t.length; o++) i.push(e.encode.alphaMul(new Uint8Array(t[o]), r)), a += t[o].byteLength;
							for (var s = new Uint8Array(a), c = new Uint32Array(s.buffer), l = 0, o = 0; o < i.length; o++) {
								for (var u = i[o], d = u.length, f = 0; f < d; f++) s[l + f] = u[f];
								l += d;
							}
							var p = {
								i0: 0,
								i1: s.length,
								bst: null,
								est: null,
								tdst: 0,
								left: null,
								right: null
							};
							p.bst = e.quantize.stats(s, p.i0, p.i1), p.est = e.quantize.estats(p.bst);
							for (var m = [p]; m.length < n;) {
								for (var h = 0, g = 0, o = 0; o < m.length; o++) m[o].est.L > h && (h = m[o].est.L, g = o);
								if (h < .001) break;
								var _ = m[g], v = e.quantize.splitPixels(s, c, _.i0, _.i1, _.est.e, _.est.eMq255), y = {
									i0: _.i0,
									i1: v,
									bst: null,
									est: null,
									tdst: 0,
									left: null,
									right: null
								};
								y.bst = e.quantize.stats(s, y.i0, y.i1), y.est = e.quantize.estats(y.bst);
								var b = {
									i0: v,
									i1: _.i1,
									bst: null,
									est: null,
									tdst: 0,
									left: null,
									right: null
								};
								b.bst = {
									R: [],
									m: [],
									N: _.bst.N - y.bst.N
								};
								for (var o = 0; o < 16; o++) b.bst.R[o] = _.bst.R[o] - y.bst.R[o];
								for (var o = 0; o < 4; o++) b.bst.m[o] = _.bst.m[o] - y.bst.m[o];
								b.est = e.quantize.estats(b.bst), _.left = y, _.right = b, m[g] = y, m.push(b);
							}
							m.sort(function(e, t) {
								return t.bst.N - e.bst.N;
							});
							for (var x = 0; x < i.length; x++) {
								for (var S = e.quantize.planeDst, C = new Uint8Array(i[x].buffer), w = new Uint32Array(i[x].buffer), T = C.length, E = [], D = 0, o = 0; o < T; o += 4) {
									for (var O = C[o] * (1 / 255), k = C[o + 1] * (1 / 255), A = C[o + 2] * (1 / 255), j = C[o + 3] * (1 / 255), M = p; M.left;) M = S(M.est, O, k, A, j) <= 0 ? M.left : M.right;
									w[o >> 2] = M.est.rgba;
								}
								i[x] = w.buffer;
							}
							return {
								bufs: i,
								plte: m
							};
						}, e.quantize.getNearest = function(t, n, r, i, a) {
							if (t.left == null) return t.tdst = e.quantize.dist(t.est.q, n, r, i, a), t;
							var o = e.quantize.planeDst(t.est, n, r, i, a), s = t.left, c = t.right;
							o > 0 && (s = t.right, c = t.left);
							var l = e.quantize.getNearest(s, n, r, i, a);
							if (l.tdst <= o * o) return l;
							var u = e.quantize.getNearest(c, n, r, i, a);
							return u.tdst < l.tdst ? u : l;
						}, e.quantize.planeDst = function(e, t, n, r, i) {
							var a = e.e;
							return a[0] * t + a[1] * n + a[2] * r + a[3] * i - e.eMq;
						}, e.quantize.dist = function(e, t, n, r, i) {
							var a = t - e[0], o = n - e[1], s = r - e[2], c = i - e[3];
							return a * a + o * o + s * s + c * c;
						}, e.quantize.splitPixels = function(t, n, r, i, a, o) {
							var s = e.quantize.vecDot;
							i -= 4;
							for (var c = 0; r < i;) {
								for (; s(t, r, a) <= o;) r += 4;
								for (; s(t, i, a) > o;) i -= 4;
								if (r >= i) break;
								var l = n[r >> 2];
								n[r >> 2] = n[i >> 2], n[i >> 2] = l, r += 4, i -= 4;
							}
							for (; s(t, r, a) > o;) r -= 4;
							return r + 4;
						}, e.quantize.vecDot = function(e, t, n) {
							return e[t] * n[0] + e[t + 1] * n[1] + e[t + 2] * n[2] + e[t + 3] * n[3];
						}, e.quantize.stats = function(e, t, n) {
							for (var r = [
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								0
							], i = [
								0,
								0,
								0,
								0
							], a = n - t >> 2, o = t; o < n; o += 4) {
								var s = e[o] * (1 / 255), c = e[o + 1] * (1 / 255), l = e[o + 2] * (1 / 255), u = e[o + 3] * (1 / 255);
								i[0] += s, i[1] += c, i[2] += l, i[3] += u, r[0] += s * s, r[1] += s * c, r[2] += s * l, r[3] += s * u, r[5] += c * c, r[6] += c * l, r[7] += c * u, r[10] += l * l, r[11] += l * u, r[15] += u * u;
							}
							return r[4] = r[1], r[8] = r[2], r[12] = r[3], r[9] = r[6], r[13] = r[7], r[14] = r[11], {
								R: r,
								m: i,
								N: a
							};
						}, e.quantize.estats = function(t) {
							var n = t.R, r = t.m, i = t.N, a = r[0], o = r[1], s = r[2], c = r[3], l = i == 0 ? 0 : 1 / i, u = [
								n[0] - a * a * l,
								n[1] - a * o * l,
								n[2] - a * s * l,
								n[3] - a * c * l,
								n[4] - o * a * l,
								n[5] - o * o * l,
								n[6] - o * s * l,
								n[7] - o * c * l,
								n[8] - s * a * l,
								n[9] - s * o * l,
								n[10] - s * s * l,
								n[11] - s * c * l,
								n[12] - c * a * l,
								n[13] - c * o * l,
								n[14] - c * s * l,
								n[15] - c * c * l
							], d = u, f = e.M4, p = [
								.5,
								.5,
								.5,
								.5
							], m = 0, h = 0;
							if (i != 0) for (var g = 0; g < 10 && (p = f.multVec(d, p), h = Math.sqrt(f.dot(p, p)), p = f.sml(1 / h, p), !(Math.abs(h - m) < 1e-9)); g++) m = h;
							var _ = [
								a * l,
								o * l,
								s * l,
								c * l
							], v = f.dot(f.sml(255, _), p), y = _[3] < .001 ? 0 : 1 / _[3];
							return {
								Cov: u,
								q: _,
								e: p,
								L: m,
								eMq255: v,
								eMq: f.dot(p, _),
								rgba: (Math.round(255 * _[3]) << 24 | Math.round(255 * _[2] * y) << 16 | Math.round(255 * _[1] * y) << 8 | Math.round(255 * _[0] * y) << 0) >>> 0
							};
						}, e.M4 = {
							multVec: function(e, t) {
								return [
									e[0] * t[0] + e[1] * t[1] + e[2] * t[2] + e[3] * t[3],
									e[4] * t[0] + e[5] * t[1] + e[6] * t[2] + e[7] * t[3],
									e[8] * t[0] + e[9] * t[1] + e[10] * t[2] + e[11] * t[3],
									e[12] * t[0] + e[13] * t[1] + e[14] * t[2] + e[15] * t[3]
								];
							},
							dot: function(e, t) {
								return e[0] * t[0] + e[1] * t[1] + e[2] * t[2] + e[3] * t[3];
							},
							sml: function(e, t) {
								return [
									e * t[0],
									e * t[1],
									e * t[2],
									e * t[3]
								];
							}
						}, e.encode.alphaMul = function(e, t) {
							for (var n = new Uint8Array(e.length), r = e.length >> 2, i = 0; i < r; i++) {
								var a = i << 2, o = e[a + 3];
								t && (o = o < 128 ? 0 : 255);
								var s = 1 / 255 * o;
								n[a + 0] = e[a + 0] * s, n[a + 1] = e[a + 1] * s, n[a + 2] = e[a + 2] * s, n[a + 3] = o;
							}
							return n;
						};
					})(t, r);
				})();
			},
			"./node_modules/upng-js/node_modules/pako/index.js"(e, t, n) {
				var r = n("./node_modules/upng-js/node_modules/pako/lib/utils/common.js").assign, i = n("./node_modules/upng-js/node_modules/pako/lib/deflate.js"), a = n("./node_modules/upng-js/node_modules/pako/lib/inflate.js"), o = n("./node_modules/upng-js/node_modules/pako/lib/zlib/constants.js"), s = {};
				r(s, i, a, o), e.exports = s;
			},
			"./node_modules/upng-js/node_modules/pako/lib/deflate.js"(e, t, n) {
				var r = n("./node_modules/upng-js/node_modules/pako/lib/zlib/deflate.js"), i = n("./node_modules/upng-js/node_modules/pako/lib/utils/common.js"), a = n("./node_modules/upng-js/node_modules/pako/lib/utils/strings.js"), o = n("./node_modules/upng-js/node_modules/pako/lib/zlib/messages.js"), s = n("./node_modules/upng-js/node_modules/pako/lib/zlib/zstream.js"), c = Object.prototype.toString, l = 0, u = 4, d = 0, f = 1, p = 2, m = -1, h = 0, g = 8;
				function _(e) {
					if (!(this instanceof _)) return new _(e);
					this.options = i.assign({
						level: m,
						method: g,
						chunkSize: 16384,
						windowBits: 15,
						memLevel: 8,
						strategy: h,
						to: ""
					}, e || {});
					var t = this.options;
					t.raw && t.windowBits > 0 ? t.windowBits = -t.windowBits : t.gzip && t.windowBits > 0 && t.windowBits < 16 && (t.windowBits += 16), this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new s(), this.strm.avail_out = 0;
					var n = r.deflateInit2(this.strm, t.level, t.method, t.windowBits, t.memLevel, t.strategy);
					if (n !== d) throw Error(o[n]);
					if (t.header && r.deflateSetHeader(this.strm, t.header), t.dictionary) {
						var l = typeof t.dictionary == "string" ? a.string2buf(t.dictionary) : c.call(t.dictionary) === "[object ArrayBuffer]" ? new Uint8Array(t.dictionary) : t.dictionary;
						if (n = r.deflateSetDictionary(this.strm, l), n !== d) throw Error(o[n]);
						this._dict_set = !0;
					}
				}
				_.prototype.push = function(e, t) {
					var n = this.strm, o = this.options.chunkSize, s, m;
					if (this.ended) return !1;
					m = t === ~~t ? t : t === !0 ? u : l, n.input = typeof e == "string" ? a.string2buf(e) : c.call(e) === "[object ArrayBuffer]" ? new Uint8Array(e) : e, n.next_in = 0, n.avail_in = n.input.length;
					do {
						if (n.avail_out === 0 && (n.output = new i.Buf8(o), n.next_out = 0, n.avail_out = o), s = r.deflate(n, m), s !== f && s !== d) return this.onEnd(s), this.ended = !0, !1;
						(n.avail_out === 0 || n.avail_in === 0 && (m === u || m === p)) && (this.options.to === "string" ? this.onData(a.buf2binstring(i.shrinkBuf(n.output, n.next_out))) : this.onData(i.shrinkBuf(n.output, n.next_out)));
					} while ((n.avail_in > 0 || n.avail_out === 0) && s !== f);
					return m === u ? (s = r.deflateEnd(this.strm), this.onEnd(s), this.ended = !0, s === d) : m !== p || (this.onEnd(d), n.avail_out = 0, !0);
				}, _.prototype.onData = function(e) {
					this.chunks.push(e);
				}, _.prototype.onEnd = function(e) {
					e === d && (this.result = this.options.to === "string" ? this.chunks.join("") : i.flattenChunks(this.chunks)), this.chunks = [], this.err = e, this.msg = this.strm.msg;
				};
				function v(e, t) {
					var n = new _(t);
					if (n.push(e, !0), n.err) throw n.msg || o[n.err];
					return n.result;
				}
				function y(e, t) {
					return t ||= {}, t.raw = !0, v(e, t);
				}
				function b(e, t) {
					return t ||= {}, t.gzip = !0, v(e, t);
				}
				t.Deflate = _, t.deflate = v, t.deflateRaw = y, t.gzip = b;
			},
			"./node_modules/upng-js/node_modules/pako/lib/inflate.js"(e, t, n) {
				var r = n("./node_modules/upng-js/node_modules/pako/lib/zlib/inflate.js"), i = n("./node_modules/upng-js/node_modules/pako/lib/utils/common.js"), a = n("./node_modules/upng-js/node_modules/pako/lib/utils/strings.js"), o = n("./node_modules/upng-js/node_modules/pako/lib/zlib/constants.js"), s = n("./node_modules/upng-js/node_modules/pako/lib/zlib/messages.js"), c = n("./node_modules/upng-js/node_modules/pako/lib/zlib/zstream.js"), l = n("./node_modules/upng-js/node_modules/pako/lib/zlib/gzheader.js"), u = Object.prototype.toString;
				function d(e) {
					if (!(this instanceof d)) return new d(e);
					this.options = i.assign({
						chunkSize: 16384,
						windowBits: 0,
						to: ""
					}, e || {});
					var t = this.options;
					t.raw && t.windowBits >= 0 && t.windowBits < 16 && (t.windowBits = -t.windowBits, t.windowBits === 0 && (t.windowBits = -15)), t.windowBits >= 0 && t.windowBits < 16 && !(e && e.windowBits) && (t.windowBits += 32), t.windowBits > 15 && t.windowBits < 48 && (t.windowBits & 15 || (t.windowBits |= 15)), this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new c(), this.strm.avail_out = 0;
					var n = r.inflateInit2(this.strm, t.windowBits);
					if (n !== o.Z_OK || (this.header = new l(), r.inflateGetHeader(this.strm, this.header), t.dictionary && (typeof t.dictionary == "string" ? t.dictionary = a.string2buf(t.dictionary) : u.call(t.dictionary) === "[object ArrayBuffer]" && (t.dictionary = new Uint8Array(t.dictionary)), t.raw && (n = r.inflateSetDictionary(this.strm, t.dictionary), n !== o.Z_OK)))) throw Error(s[n]);
				}
				d.prototype.push = function(e, t) {
					var n = this.strm, s = this.options.chunkSize, c = this.options.dictionary, l, d, f, p, m, h = !1;
					if (this.ended) return !1;
					d = t === ~~t ? t : t === !0 ? o.Z_FINISH : o.Z_NO_FLUSH, n.input = typeof e == "string" ? a.binstring2buf(e) : u.call(e) === "[object ArrayBuffer]" ? new Uint8Array(e) : e, n.next_in = 0, n.avail_in = n.input.length;
					do {
						if (n.avail_out === 0 && (n.output = new i.Buf8(s), n.next_out = 0, n.avail_out = s), l = r.inflate(n, o.Z_NO_FLUSH), l === o.Z_NEED_DICT && c && (l = r.inflateSetDictionary(this.strm, c)), l === o.Z_BUF_ERROR && h === !0 && (l = o.Z_OK, h = !1), l !== o.Z_STREAM_END && l !== o.Z_OK) return this.onEnd(l), this.ended = !0, !1;
						n.next_out && (n.avail_out === 0 || l === o.Z_STREAM_END || n.avail_in === 0 && (d === o.Z_FINISH || d === o.Z_SYNC_FLUSH)) && (this.options.to === "string" ? (f = a.utf8border(n.output, n.next_out), p = n.next_out - f, m = a.buf2string(n.output, f), n.next_out = p, n.avail_out = s - p, p && i.arraySet(n.output, n.output, f, p, 0), this.onData(m)) : this.onData(i.shrinkBuf(n.output, n.next_out))), n.avail_in === 0 && n.avail_out === 0 && (h = !0);
					} while ((n.avail_in > 0 || n.avail_out === 0) && l !== o.Z_STREAM_END);
					return l === o.Z_STREAM_END && (d = o.Z_FINISH), d === o.Z_FINISH ? (l = r.inflateEnd(this.strm), this.onEnd(l), this.ended = !0, l === o.Z_OK) : d !== o.Z_SYNC_FLUSH || (this.onEnd(o.Z_OK), n.avail_out = 0, !0);
				}, d.prototype.onData = function(e) {
					this.chunks.push(e);
				}, d.prototype.onEnd = function(e) {
					e === o.Z_OK && (this.result = this.options.to === "string" ? this.chunks.join("") : i.flattenChunks(this.chunks)), this.chunks = [], this.err = e, this.msg = this.strm.msg;
				};
				function f(e, t) {
					var n = new d(t);
					if (n.push(e, !0), n.err) throw n.msg || s[n.err];
					return n.result;
				}
				function p(e, t) {
					return t ||= {}, t.raw = !0, f(e, t);
				}
				t.Inflate = d, t.inflate = f, t.inflateRaw = p, t.ungzip = f;
			},
			"./node_modules/upng-js/node_modules/pako/lib/utils/common.js"(e, t) {
				var n = typeof Uint8Array < "u" && typeof Uint16Array < "u" && typeof Int32Array < "u";
				function r(e, t) {
					return Object.prototype.hasOwnProperty.call(e, t);
				}
				t.assign = function(e) {
					for (var t = Array.prototype.slice.call(arguments, 1); t.length;) {
						var n = t.shift();
						if (n) {
							if (typeof n != "object") throw TypeError(n + "must be non-object");
							for (var i in n) r(n, i) && (e[i] = n[i]);
						}
					}
					return e;
				}, t.shrinkBuf = function(e, t) {
					return e.length === t ? e : e.subarray ? e.subarray(0, t) : (e.length = t, e);
				};
				var i = {
					arraySet: function(e, t, n, r, i) {
						if (t.subarray && e.subarray) {
							e.set(t.subarray(n, n + r), i);
							return;
						}
						for (var a = 0; a < r; a++) e[i + a] = t[n + a];
					},
					flattenChunks: function(e) {
						var t, n, r = 0, i, a, o;
						for (t = 0, n = e.length; t < n; t++) r += e[t].length;
						for (o = new Uint8Array(r), i = 0, t = 0, n = e.length; t < n; t++) a = e[t], o.set(a, i), i += a.length;
						return o;
					}
				}, a = {
					arraySet: function(e, t, n, r, i) {
						for (var a = 0; a < r; a++) e[i + a] = t[n + a];
					},
					flattenChunks: function(e) {
						return [].concat.apply([], e);
					}
				};
				t.setTyped = function(e) {
					e ? (t.Buf8 = Uint8Array, t.Buf16 = Uint16Array, t.Buf32 = Int32Array, t.assign(t, i)) : (t.Buf8 = Array, t.Buf16 = Array, t.Buf32 = Array, t.assign(t, a));
				}, t.setTyped(n);
			},
			"./node_modules/upng-js/node_modules/pako/lib/utils/strings.js"(e, t, n) {
				var r = n("./node_modules/upng-js/node_modules/pako/lib/utils/common.js"), i = !0, a = !0;
				try {
					String.fromCharCode.apply(null, [0]);
				} catch {
					i = !1;
				}
				try {
					String.fromCharCode.apply(null, /* @__PURE__ */ new Uint8Array(1));
				} catch {
					a = !1;
				}
				for (var o = new r.Buf8(256), s = 0; s < 256; s++) o[s] = s >= 252 ? 6 : s >= 248 ? 5 : s >= 240 ? 4 : s >= 224 ? 3 : s >= 192 ? 2 : 1;
				o[254] = o[254] = 1, t.string2buf = function(e) {
					var t, n, i, a, o, s = e.length, c = 0;
					for (a = 0; a < s; a++) n = e.charCodeAt(a), (n & 64512) == 55296 && a + 1 < s && (i = e.charCodeAt(a + 1), (i & 64512) == 56320 && (n = 65536 + (n - 55296 << 10) + (i - 56320), a++)), c += n < 128 ? 1 : n < 2048 ? 2 : n < 65536 ? 3 : 4;
					for (t = new r.Buf8(c), o = 0, a = 0; o < c; a++) n = e.charCodeAt(a), (n & 64512) == 55296 && a + 1 < s && (i = e.charCodeAt(a + 1), (i & 64512) == 56320 && (n = 65536 + (n - 55296 << 10) + (i - 56320), a++)), n < 128 ? t[o++] = n : n < 2048 ? (t[o++] = 192 | n >>> 6, t[o++] = 128 | n & 63) : n < 65536 ? (t[o++] = 224 | n >>> 12, t[o++] = 128 | n >>> 6 & 63, t[o++] = 128 | n & 63) : (t[o++] = 240 | n >>> 18, t[o++] = 128 | n >>> 12 & 63, t[o++] = 128 | n >>> 6 & 63, t[o++] = 128 | n & 63);
					return t;
				};
				function c(e, t) {
					if (t < 65534 && (e.subarray && a || !e.subarray && i)) return String.fromCharCode.apply(null, r.shrinkBuf(e, t));
					for (var n = "", o = 0; o < t; o++) n += String.fromCharCode(e[o]);
					return n;
				}
				t.buf2binstring = function(e) {
					return c(e, e.length);
				}, t.binstring2buf = function(e) {
					for (var t = new r.Buf8(e.length), n = 0, i = t.length; n < i; n++) t[n] = e.charCodeAt(n);
					return t;
				}, t.buf2string = function(e, t) {
					var n, r, i, a, s = t || e.length, l = Array(s * 2);
					for (r = 0, n = 0; n < s;) {
						if (i = e[n++], i < 128) {
							l[r++] = i;
							continue;
						}
						if (a = o[i], a > 4) {
							l[r++] = 65533, n += a - 1;
							continue;
						}
						for (i &= a === 2 ? 31 : a === 3 ? 15 : 7; a > 1 && n < s;) i = i << 6 | e[n++] & 63, a--;
						if (a > 1) {
							l[r++] = 65533;
							continue;
						}
						i < 65536 ? l[r++] = i : (i -= 65536, l[r++] = 55296 | i >> 10 & 1023, l[r++] = 56320 | i & 1023);
					}
					return c(l, r);
				}, t.utf8border = function(e, t) {
					var n;
					for (t ||= e.length, t > e.length && (t = e.length), n = t - 1; n >= 0 && (e[n] & 192) == 128;) n--;
					return n < 0 || n === 0 ? t : n + o[e[n]] > t ? n : t;
				};
			},
			"./node_modules/upng-js/node_modules/pako/lib/zlib/adler32.js"(e) {
				function t(e, t, n, r) {
					for (var i = e & 65535 | 0, a = e >>> 16 & 65535 | 0, o = 0; n !== 0;) {
						o = n > 2e3 ? 2e3 : n, n -= o;
						do
							i = i + t[r++] | 0, a = a + i | 0;
						while (--o);
						i %= 65521, a %= 65521;
					}
					return i | a << 16 | 0;
				}
				e.exports = t;
			},
			"./node_modules/upng-js/node_modules/pako/lib/zlib/constants.js"(e) {
				e.exports = {
					Z_NO_FLUSH: 0,
					Z_PARTIAL_FLUSH: 1,
					Z_SYNC_FLUSH: 2,
					Z_FULL_FLUSH: 3,
					Z_FINISH: 4,
					Z_BLOCK: 5,
					Z_TREES: 6,
					Z_OK: 0,
					Z_STREAM_END: 1,
					Z_NEED_DICT: 2,
					Z_ERRNO: -1,
					Z_STREAM_ERROR: -2,
					Z_DATA_ERROR: -3,
					Z_BUF_ERROR: -5,
					Z_NO_COMPRESSION: 0,
					Z_BEST_SPEED: 1,
					Z_BEST_COMPRESSION: 9,
					Z_DEFAULT_COMPRESSION: -1,
					Z_FILTERED: 1,
					Z_HUFFMAN_ONLY: 2,
					Z_RLE: 3,
					Z_FIXED: 4,
					Z_DEFAULT_STRATEGY: 0,
					Z_BINARY: 0,
					Z_TEXT: 1,
					Z_UNKNOWN: 2,
					Z_DEFLATED: 8
				};
			},
			"./node_modules/upng-js/node_modules/pako/lib/zlib/crc32.js"(e) {
				function t() {
					for (var e, t = [], n = 0; n < 256; n++) {
						e = n;
						for (var r = 0; r < 8; r++) e = e & 1 ? 3988292384 ^ e >>> 1 : e >>> 1;
						t[n] = e;
					}
					return t;
				}
				var n = t();
				function r(e, t, r, i) {
					var a = n, o = i + r;
					e ^= -1;
					for (var s = i; s < o; s++) e = e >>> 8 ^ a[(e ^ t[s]) & 255];
					return e ^ -1;
				}
				e.exports = r;
			},
			"./node_modules/upng-js/node_modules/pako/lib/zlib/deflate.js"(e, t, n) {
				var r = n("./node_modules/upng-js/node_modules/pako/lib/utils/common.js"), i = n("./node_modules/upng-js/node_modules/pako/lib/zlib/trees.js"), a = n("./node_modules/upng-js/node_modules/pako/lib/zlib/adler32.js"), o = n("./node_modules/upng-js/node_modules/pako/lib/zlib/crc32.js"), s = n("./node_modules/upng-js/node_modules/pako/lib/zlib/messages.js"), c = 0, l = 1, u = 3, d = 4, f = 5, p = 0, m = 1, h = -2, g = -3, _ = -5, v = -1, y = 1, b = 2, x = 3, S = 4, C = 0, w = 2, T = 8, E = 9, D = 15, O = 8, k = 286, A = 30, j = 19, M = 2 * k + 1, N = 15, P = 3, F = 258, I = F + P + 1, L = 32, R = 42, z = 69, B = 73, V = 91, H = 103, U = 113, W = 666, G = 1, ee = 2, te = 3, ne = 4, re = 3;
				function ie(e, t) {
					return e.msg = s[t], t;
				}
				function K(e) {
					return (e << 1) - (e > 4 ? 9 : 0);
				}
				function ae(e) {
					for (var t = e.length; --t >= 0;) e[t] = 0;
				}
				function oe(e) {
					var t = e.state, n = t.pending;
					n > e.avail_out && (n = e.avail_out), n !== 0 && (r.arraySet(e.output, t.pending_buf, t.pending_out, n, e.next_out), e.next_out += n, t.pending_out += n, e.total_out += n, e.avail_out -= n, t.pending -= n, t.pending === 0 && (t.pending_out = 0));
				}
				function q(e, t) {
					i._tr_flush_block(e, e.block_start >= 0 ? e.block_start : -1, e.strstart - e.block_start, t), e.block_start = e.strstart, oe(e.strm);
				}
				function J(e, t) {
					e.pending_buf[e.pending++] = t;
				}
				function Y(e, t) {
					e.pending_buf[e.pending++] = t >>> 8 & 255, e.pending_buf[e.pending++] = t & 255;
				}
				function se(e, t, n, i) {
					var s = e.avail_in;
					return s > i && (s = i), s === 0 ? 0 : (e.avail_in -= s, r.arraySet(t, e.input, e.next_in, s, n), e.state.wrap === 1 ? e.adler = a(e.adler, t, s, n) : e.state.wrap === 2 && (e.adler = o(e.adler, t, s, n)), e.next_in += s, e.total_in += s, s);
				}
				function ce(e, t) {
					var n = e.max_chain_length, r = e.strstart, i, a, o = e.prev_length, s = e.nice_match, c = e.strstart > e.w_size - I ? e.strstart - (e.w_size - I) : 0, l = e.window, u = e.w_mask, d = e.prev, f = e.strstart + F, p = l[r + o - 1], m = l[r + o];
					e.prev_length >= e.good_match && (n >>= 2), s > e.lookahead && (s = e.lookahead);
					do
						if (i = t, l[i + o] === m && l[i + o - 1] === p && l[i] === l[r] && l[++i] === l[r + 1]) {
							r += 2, i++;
							do							;
while (l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && r < f);
							if (a = F - (f - r), r = f - F, a > o) {
								if (e.match_start = t, o = a, a >= s) break;
								p = l[r + o - 1], m = l[r + o];
							}
						}
					while ((t = d[t & u]) > c && --n !== 0);
					return o <= e.lookahead ? o : e.lookahead;
				}
				function X(e) {
					var t = e.w_size, n, i, a, o, s;
					do {
						if (o = e.window_size - e.lookahead - e.strstart, e.strstart >= t + (t - I)) {
							r.arraySet(e.window, e.window, t, t, 0), e.match_start -= t, e.strstart -= t, e.block_start -= t, i = e.hash_size, n = i;
							do
								a = e.head[--n], e.head[n] = a >= t ? a - t : 0;
							while (--i);
							i = t, n = i;
							do
								a = e.prev[--n], e.prev[n] = a >= t ? a - t : 0;
							while (--i);
							o += t;
						}
						if (e.strm.avail_in === 0) break;
						if (i = se(e.strm, e.window, e.strstart + e.lookahead, o), e.lookahead += i, e.lookahead + e.insert >= P) for (s = e.strstart - e.insert, e.ins_h = e.window[s], e.ins_h = (e.ins_h << e.hash_shift ^ e.window[s + 1]) & e.hash_mask; e.insert && (e.ins_h = (e.ins_h << e.hash_shift ^ e.window[s + P - 1]) & e.hash_mask, e.prev[s & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = s, s++, e.insert--, !(e.lookahead + e.insert < P)););
					} while (e.lookahead < I && e.strm.avail_in !== 0);
				}
				function le(e, t) {
					var n = 65535;
					for (n > e.pending_buf_size - 5 && (n = e.pending_buf_size - 5);;) {
						if (e.lookahead <= 1) {
							if (X(e), e.lookahead === 0 && t === c) return G;
							if (e.lookahead === 0) break;
						}
						e.strstart += e.lookahead, e.lookahead = 0;
						var r = e.block_start + n;
						if ((e.strstart === 0 || e.strstart >= r) && (e.lookahead = e.strstart - r, e.strstart = r, q(e, !1), e.strm.avail_out === 0) || e.strstart - e.block_start >= e.w_size - I && (q(e, !1), e.strm.avail_out === 0)) return G;
					}
					return e.insert = 0, t === d ? (q(e, !0), e.strm.avail_out === 0 ? te : ne) : (e.strstart > e.block_start && (q(e, !1), e.strm.avail_out), G);
				}
				function Z(e, t) {
					for (var n, r;;) {
						if (e.lookahead < I) {
							if (X(e), e.lookahead < I && t === c) return G;
							if (e.lookahead === 0) break;
						}
						if (n = 0, e.lookahead >= P && (e.ins_h = (e.ins_h << e.hash_shift ^ e.window[e.strstart + P - 1]) & e.hash_mask, n = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart), n !== 0 && e.strstart - n <= e.w_size - I && (e.match_length = ce(e, n)), e.match_length >= P) {
							if (r = i._tr_tally(e, e.strstart - e.match_start, e.match_length - P), e.lookahead -= e.match_length, e.match_length <= e.max_lazy_match && e.lookahead >= P) {
								e.match_length--;
								do
									e.strstart++, e.ins_h = (e.ins_h << e.hash_shift ^ e.window[e.strstart + P - 1]) & e.hash_mask, n = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart;
								while (--e.match_length !== 0);
								e.strstart++;
							} else e.strstart += e.match_length, e.match_length = 0, e.ins_h = e.window[e.strstart], e.ins_h = (e.ins_h << e.hash_shift ^ e.window[e.strstart + 1]) & e.hash_mask;
						} else r = i._tr_tally(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++;
						if (r && (q(e, !1), e.strm.avail_out === 0)) return G;
					}
					return e.insert = e.strstart < P - 1 ? e.strstart : P - 1, t === d ? (q(e, !0), e.strm.avail_out === 0 ? te : ne) : e.last_lit && (q(e, !1), e.strm.avail_out === 0) ? G : ee;
				}
				function Q(e, t) {
					for (var n, r, a;;) {
						if (e.lookahead < I) {
							if (X(e), e.lookahead < I && t === c) return G;
							if (e.lookahead === 0) break;
						}
						if (n = 0, e.lookahead >= P && (e.ins_h = (e.ins_h << e.hash_shift ^ e.window[e.strstart + P - 1]) & e.hash_mask, n = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart), e.prev_length = e.match_length, e.prev_match = e.match_start, e.match_length = P - 1, n !== 0 && e.prev_length < e.max_lazy_match && e.strstart - n <= e.w_size - I && (e.match_length = ce(e, n), e.match_length <= 5 && (e.strategy === y || e.match_length === P && e.strstart - e.match_start > 4096) && (e.match_length = P - 1)), e.prev_length >= P && e.match_length <= e.prev_length) {
							a = e.strstart + e.lookahead - P, r = i._tr_tally(e, e.strstart - 1 - e.prev_match, e.prev_length - P), e.lookahead -= e.prev_length - 1, e.prev_length -= 2;
							do
								++e.strstart <= a && (e.ins_h = (e.ins_h << e.hash_shift ^ e.window[e.strstart + P - 1]) & e.hash_mask, n = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart);
							while (--e.prev_length !== 0);
							if (e.match_available = 0, e.match_length = P - 1, e.strstart++, r && (q(e, !1), e.strm.avail_out === 0)) return G;
						} else if (e.match_available) {
							if (r = i._tr_tally(e, 0, e.window[e.strstart - 1]), r && q(e, !1), e.strstart++, e.lookahead--, e.strm.avail_out === 0) return G;
						} else e.match_available = 1, e.strstart++, e.lookahead--;
					}
					return e.match_available &&= (r = i._tr_tally(e, 0, e.window[e.strstart - 1]), 0), e.insert = e.strstart < P - 1 ? e.strstart : P - 1, t === d ? (q(e, !0), e.strm.avail_out === 0 ? te : ne) : e.last_lit && (q(e, !1), e.strm.avail_out === 0) ? G : ee;
				}
				function ue(e, t) {
					for (var n, r, a, o, s = e.window;;) {
						if (e.lookahead <= F) {
							if (X(e), e.lookahead <= F && t === c) return G;
							if (e.lookahead === 0) break;
						}
						if (e.match_length = 0, e.lookahead >= P && e.strstart > 0 && (a = e.strstart - 1, r = s[a], r === s[++a] && r === s[++a] && r === s[++a])) {
							o = e.strstart + F;
							do							;
while (r === s[++a] && r === s[++a] && r === s[++a] && r === s[++a] && r === s[++a] && r === s[++a] && r === s[++a] && r === s[++a] && a < o);
							e.match_length = F - (o - a), e.match_length > e.lookahead && (e.match_length = e.lookahead);
						}
						if (e.match_length >= P ? (n = i._tr_tally(e, 1, e.match_length - P), e.lookahead -= e.match_length, e.strstart += e.match_length, e.match_length = 0) : (n = i._tr_tally(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++), n && (q(e, !1), e.strm.avail_out === 0)) return G;
					}
					return e.insert = 0, t === d ? (q(e, !0), e.strm.avail_out === 0 ? te : ne) : e.last_lit && (q(e, !1), e.strm.avail_out === 0) ? G : ee;
				}
				function de(e, t) {
					for (var n;;) {
						if (e.lookahead === 0 && (X(e), e.lookahead === 0)) {
							if (t === c) return G;
							break;
						}
						if (e.match_length = 0, n = i._tr_tally(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++, n && (q(e, !1), e.strm.avail_out === 0)) return G;
					}
					return e.insert = 0, t === d ? (q(e, !0), e.strm.avail_out === 0 ? te : ne) : e.last_lit && (q(e, !1), e.strm.avail_out === 0) ? G : ee;
				}
				function $(e, t, n, r, i) {
					this.good_length = e, this.max_lazy = t, this.nice_length = n, this.max_chain = r, this.func = i;
				}
				var fe = [
					new $(0, 0, 0, 0, le),
					new $(4, 4, 8, 4, Z),
					new $(4, 5, 16, 8, Z),
					new $(4, 6, 32, 32, Z),
					new $(4, 4, 16, 16, Q),
					new $(8, 16, 32, 32, Q),
					new $(8, 16, 128, 128, Q),
					new $(8, 32, 128, 256, Q),
					new $(32, 128, 258, 1024, Q),
					new $(32, 258, 258, 4096, Q)
				];
				function pe(e) {
					e.window_size = 2 * e.w_size, ae(e.head), e.max_lazy_match = fe[e.level].max_lazy, e.good_match = fe[e.level].good_length, e.nice_match = fe[e.level].nice_length, e.max_chain_length = fe[e.level].max_chain, e.strstart = 0, e.block_start = 0, e.lookahead = 0, e.insert = 0, e.match_length = e.prev_length = P - 1, e.match_available = 0, e.ins_h = 0;
				}
				function me() {
					this.strm = null, this.status = 0, this.pending_buf = null, this.pending_buf_size = 0, this.pending_out = 0, this.pending = 0, this.wrap = 0, this.gzhead = null, this.gzindex = 0, this.method = T, this.last_flush = -1, this.w_size = 0, this.w_bits = 0, this.w_mask = 0, this.window = null, this.window_size = 0, this.prev = null, this.head = null, this.ins_h = 0, this.hash_size = 0, this.hash_bits = 0, this.hash_mask = 0, this.hash_shift = 0, this.block_start = 0, this.match_length = 0, this.prev_match = 0, this.match_available = 0, this.strstart = 0, this.match_start = 0, this.lookahead = 0, this.prev_length = 0, this.max_chain_length = 0, this.max_lazy_match = 0, this.level = 0, this.strategy = 0, this.good_match = 0, this.nice_match = 0, this.dyn_ltree = new r.Buf16(M * 2), this.dyn_dtree = new r.Buf16((2 * A + 1) * 2), this.bl_tree = new r.Buf16((2 * j + 1) * 2), ae(this.dyn_ltree), ae(this.dyn_dtree), ae(this.bl_tree), this.l_desc = null, this.d_desc = null, this.bl_desc = null, this.bl_count = new r.Buf16(N + 1), this.heap = new r.Buf16(2 * k + 1), ae(this.heap), this.heap_len = 0, this.heap_max = 0, this.depth = new r.Buf16(2 * k + 1), ae(this.depth), this.l_buf = 0, this.lit_bufsize = 0, this.last_lit = 0, this.d_buf = 0, this.opt_len = 0, this.static_len = 0, this.matches = 0, this.insert = 0, this.bi_buf = 0, this.bi_valid = 0;
				}
				function he(e) {
					var t;
					return !e || !e.state ? ie(e, h) : (e.total_in = e.total_out = 0, e.data_type = w, t = e.state, t.pending = 0, t.pending_out = 0, t.wrap < 0 && (t.wrap = -t.wrap), t.status = t.wrap ? R : U, e.adler = t.wrap === 2 ? 0 : 1, t.last_flush = c, i._tr_init(t), p);
				}
				function ge(e) {
					var t = he(e);
					return t === p && pe(e.state), t;
				}
				function _e(e, t) {
					return !e || !e.state || e.state.wrap !== 2 ? h : (e.state.gzhead = t, p);
				}
				function ve(e, t, n, i, a, o) {
					if (!e) return h;
					var s = 1;
					if (t === v && (t = 6), i < 0 ? (s = 0, i = -i) : i > 15 && (s = 2, i -= 16), a < 1 || a > E || n !== T || i < 8 || i > 15 || t < 0 || t > 9 || o < 0 || o > S) return ie(e, h);
					i === 8 && (i = 9);
					var c = new me();
					return e.state = c, c.strm = e, c.wrap = s, c.gzhead = null, c.w_bits = i, c.w_size = 1 << c.w_bits, c.w_mask = c.w_size - 1, c.hash_bits = a + 7, c.hash_size = 1 << c.hash_bits, c.hash_mask = c.hash_size - 1, c.hash_shift = ~~((c.hash_bits + P - 1) / P), c.window = new r.Buf8(c.w_size * 2), c.head = new r.Buf16(c.hash_size), c.prev = new r.Buf16(c.w_size), c.lit_bufsize = 1 << a + 6, c.pending_buf_size = c.lit_bufsize * 4, c.pending_buf = new r.Buf8(c.pending_buf_size), c.d_buf = 1 * c.lit_bufsize, c.l_buf = 3 * c.lit_bufsize, c.level = t, c.strategy = o, c.method = n, ge(e);
				}
				function ye(e, t) {
					return ve(e, t, T, D, O, C);
				}
				function be(e, t) {
					var n, r, a, s;
					if (!e || !e.state || t > f || t < 0) return e ? ie(e, h) : h;
					if (r = e.state, !e.output || !e.input && e.avail_in !== 0 || r.status === W && t !== d) return ie(e, e.avail_out === 0 ? _ : h);
					if (r.strm = e, n = r.last_flush, r.last_flush = t, r.status === R) {
						if (r.wrap === 2) e.adler = 0, J(r, 31), J(r, 139), J(r, 8), r.gzhead ? (J(r, +!!r.gzhead.text + (r.gzhead.hcrc ? 2 : 0) + (r.gzhead.extra ? 4 : 0) + (r.gzhead.name ? 8 : 0) + (r.gzhead.comment ? 16 : 0)), J(r, r.gzhead.time & 255), J(r, r.gzhead.time >> 8 & 255), J(r, r.gzhead.time >> 16 & 255), J(r, r.gzhead.time >> 24 & 255), J(r, r.level === 9 ? 2 : r.strategy >= b || r.level < 2 ? 4 : 0), J(r, r.gzhead.os & 255), r.gzhead.extra && r.gzhead.extra.length && (J(r, r.gzhead.extra.length & 255), J(r, r.gzhead.extra.length >> 8 & 255)), r.gzhead.hcrc && (e.adler = o(e.adler, r.pending_buf, r.pending, 0)), r.gzindex = 0, r.status = z) : (J(r, 0), J(r, 0), J(r, 0), J(r, 0), J(r, 0), J(r, r.level === 9 ? 2 : r.strategy >= b || r.level < 2 ? 4 : 0), J(r, re), r.status = U);
						else {
							var g = T + (r.w_bits - 8 << 4) << 8, v = -1;
							v = r.strategy >= b || r.level < 2 ? 0 : r.level < 6 ? 1 : r.level === 6 ? 2 : 3, g |= v << 6, r.strstart !== 0 && (g |= L), g += 31 - g % 31, r.status = U, Y(r, g), r.strstart !== 0 && (Y(r, e.adler >>> 16), Y(r, e.adler & 65535)), e.adler = 1;
						}
					}
					if (r.status === z) {
						if (r.gzhead.extra) {
							for (a = r.pending; r.gzindex < (r.gzhead.extra.length & 65535) && !(r.pending === r.pending_buf_size && (r.gzhead.hcrc && r.pending > a && (e.adler = o(e.adler, r.pending_buf, r.pending - a, a)), oe(e), a = r.pending, r.pending === r.pending_buf_size));) J(r, r.gzhead.extra[r.gzindex] & 255), r.gzindex++;
							r.gzhead.hcrc && r.pending > a && (e.adler = o(e.adler, r.pending_buf, r.pending - a, a)), r.gzindex === r.gzhead.extra.length && (r.gzindex = 0, r.status = B);
						} else r.status = B;
					}
					if (r.status === B) {
						if (r.gzhead.name) {
							a = r.pending;
							do {
								if (r.pending === r.pending_buf_size && (r.gzhead.hcrc && r.pending > a && (e.adler = o(e.adler, r.pending_buf, r.pending - a, a)), oe(e), a = r.pending, r.pending === r.pending_buf_size)) {
									s = 1;
									break;
								}
								s = r.gzindex < r.gzhead.name.length ? r.gzhead.name.charCodeAt(r.gzindex++) & 255 : 0, J(r, s);
							} while (s !== 0);
							r.gzhead.hcrc && r.pending > a && (e.adler = o(e.adler, r.pending_buf, r.pending - a, a)), s === 0 && (r.gzindex = 0, r.status = V);
						} else r.status = V;
					}
					if (r.status === V) {
						if (r.gzhead.comment) {
							a = r.pending;
							do {
								if (r.pending === r.pending_buf_size && (r.gzhead.hcrc && r.pending > a && (e.adler = o(e.adler, r.pending_buf, r.pending - a, a)), oe(e), a = r.pending, r.pending === r.pending_buf_size)) {
									s = 1;
									break;
								}
								s = r.gzindex < r.gzhead.comment.length ? r.gzhead.comment.charCodeAt(r.gzindex++) & 255 : 0, J(r, s);
							} while (s !== 0);
							r.gzhead.hcrc && r.pending > a && (e.adler = o(e.adler, r.pending_buf, r.pending - a, a)), s === 0 && (r.status = H);
						} else r.status = H;
					}
					if (r.status === H && (r.gzhead.hcrc ? (r.pending + 2 > r.pending_buf_size && oe(e), r.pending + 2 <= r.pending_buf_size && (J(r, e.adler & 255), J(r, e.adler >> 8 & 255), e.adler = 0, r.status = U)) : r.status = U), r.pending !== 0) {
						if (oe(e), e.avail_out === 0) return r.last_flush = -1, p;
					} else if (e.avail_in === 0 && K(t) <= K(n) && t !== d) return ie(e, _);
					if (r.status === W && e.avail_in !== 0) return ie(e, _);
					if (e.avail_in !== 0 || r.lookahead !== 0 || t !== c && r.status !== W) {
						var y = r.strategy === b ? de(r, t) : r.strategy === x ? ue(r, t) : fe[r.level].func(r, t);
						if ((y === te || y === ne) && (r.status = W), y === G || y === te) return e.avail_out === 0 && (r.last_flush = -1), p;
						if (y === ee && (t === l ? i._tr_align(r) : t !== f && (i._tr_stored_block(r, 0, 0, !1), t === u && (ae(r.head), r.lookahead === 0 && (r.strstart = 0, r.block_start = 0, r.insert = 0))), oe(e), e.avail_out === 0)) return r.last_flush = -1, p;
					}
					return t === d ? r.wrap <= 0 ? m : (r.wrap === 2 ? (J(r, e.adler & 255), J(r, e.adler >> 8 & 255), J(r, e.adler >> 16 & 255), J(r, e.adler >> 24 & 255), J(r, e.total_in & 255), J(r, e.total_in >> 8 & 255), J(r, e.total_in >> 16 & 255), J(r, e.total_in >> 24 & 255)) : (Y(r, e.adler >>> 16), Y(r, e.adler & 65535)), oe(e), r.wrap > 0 && (r.wrap = -r.wrap), r.pending === 0 ? m : p) : p;
				}
				function xe(e) {
					var t;
					return !e || !e.state ? h : (t = e.state.status, t !== R && t !== z && t !== B && t !== V && t !== H && t !== U && t !== W ? ie(e, h) : (e.state = null, t === U ? ie(e, g) : p));
				}
				function Se(e, t) {
					var n = t.length, i, o, s, c, l, u, d, f;
					if (!e || !e.state || (i = e.state, c = i.wrap, c === 2 || c === 1 && i.status !== R || i.lookahead)) return h;
					for (c === 1 && (e.adler = a(e.adler, t, n, 0)), i.wrap = 0, n >= i.w_size && (c === 0 && (ae(i.head), i.strstart = 0, i.block_start = 0, i.insert = 0), f = new r.Buf8(i.w_size), r.arraySet(f, t, n - i.w_size, i.w_size, 0), t = f, n = i.w_size), l = e.avail_in, u = e.next_in, d = e.input, e.avail_in = n, e.next_in = 0, e.input = t, X(i); i.lookahead >= P;) {
						o = i.strstart, s = i.lookahead - (P - 1);
						do
							i.ins_h = (i.ins_h << i.hash_shift ^ i.window[o + P - 1]) & i.hash_mask, i.prev[o & i.w_mask] = i.head[i.ins_h], i.head[i.ins_h] = o, o++;
						while (--s);
						i.strstart = o, i.lookahead = P - 1, X(i);
					}
					return i.strstart += i.lookahead, i.block_start = i.strstart, i.insert = i.lookahead, i.lookahead = 0, i.match_length = i.prev_length = P - 1, i.match_available = 0, e.next_in = u, e.input = d, e.avail_in = l, i.wrap = c, p;
				}
				t.deflateInit = ye, t.deflateInit2 = ve, t.deflateReset = ge, t.deflateResetKeep = he, t.deflateSetHeader = _e, t.deflate = be, t.deflateEnd = xe, t.deflateSetDictionary = Se, t.deflateInfo = "pako deflate (from Nodeca project)";
			},
			"./node_modules/upng-js/node_modules/pako/lib/zlib/gzheader.js"(e) {
				function t() {
					this.text = 0, this.time = 0, this.xflags = 0, this.os = 0, this.extra = null, this.extra_len = 0, this.name = "", this.comment = "", this.hcrc = 0, this.done = !1;
				}
				e.exports = t;
			},
			"./node_modules/upng-js/node_modules/pako/lib/zlib/inffast.js"(e) {
				var t = 30, n = 12;
				e.exports = function(e, t) {
					var n = e.state, r = e.next_in, i, a, o, s, c, l, u, d, f, p, m, h, g, _, v, y, b, x, S, C, w, T = e.input, E;
					i = r + (e.avail_in - 5), a = e.next_out, E = e.output, o = a - (t - e.avail_out), s = a + (e.avail_out - 257), c = n.dmax, l = n.wsize, u = n.whave, d = n.wnext, f = n.window, p = n.hold, m = n.bits, h = n.lencode, g = n.distcode, _ = (1 << n.lenbits) - 1, v = (1 << n.distbits) - 1;
					top: do {
						m < 15 && (p += T[r++] << m, m += 8, p += T[r++] << m, m += 8), y = h[p & _];
						dolen: for (;;) {
							if (b = y >>> 24, p >>>= b, m -= b, b = y >>> 16 & 255, b === 0) E[a++] = y & 65535;
							else if (b & 16) {
								x = y & 65535, b &= 15, b && (m < b && (p += T[r++] << m, m += 8), x += p & (1 << b) - 1, p >>>= b, m -= b), m < 15 && (p += T[r++] << m, m += 8, p += T[r++] << m, m += 8), y = g[p & v];
								dodist: for (;;) {
									if (b = y >>> 24, p >>>= b, m -= b, b = y >>> 16 & 255, b & 16) {
										if (S = y & 65535, b &= 15, m < b && (p += T[r++] << m, m += 8, m < b && (p += T[r++] << m, m += 8)), S += p & (1 << b) - 1, S > c) {
											e.msg = "invalid distance too far back", n.mode = 30;
											break top;
										}
										if (p >>>= b, m -= b, b = a - o, S > b) {
											if (b = S - b, b > u && n.sane) {
												e.msg = "invalid distance too far back", n.mode = 30;
												break top;
											}
											if (C = 0, w = f, d === 0) {
												if (C += l - b, b < x) {
													x -= b;
													do
														E[a++] = f[C++];
													while (--b);
													C = a - S, w = E;
												}
											} else if (d < b) {
												if (C += l + d - b, b -= d, b < x) {
													x -= b;
													do
														E[a++] = f[C++];
													while (--b);
													if (C = 0, d < x) {
														b = d, x -= b;
														do
															E[a++] = f[C++];
														while (--b);
														C = a - S, w = E;
													}
												}
											} else if (C += d - b, b < x) {
												x -= b;
												do
													E[a++] = f[C++];
												while (--b);
												C = a - S, w = E;
											}
											for (; x > 2;) E[a++] = w[C++], E[a++] = w[C++], E[a++] = w[C++], x -= 3;
											x && (E[a++] = w[C++], x > 1 && (E[a++] = w[C++]));
										} else {
											C = a - S;
											do
												E[a++] = E[C++], E[a++] = E[C++], E[a++] = E[C++], x -= 3;
											while (x > 2);
											x && (E[a++] = E[C++], x > 1 && (E[a++] = E[C++]));
										}
									} else if (b & 64) {
										e.msg = "invalid distance code", n.mode = 30;
										break top;
									} else {
										y = g[(y & 65535) + (p & (1 << b) - 1)];
										continue dodist;
									}
									break;
								}
							} else if (!(b & 64)) {
								y = h[(y & 65535) + (p & (1 << b) - 1)];
								continue dolen;
							} else if (b & 32) {
								n.mode = 12;
								break top;
							} else {
								e.msg = "invalid literal/length code", n.mode = 30;
								break top;
							}
							break;
						}
					} while (r < i && a < s);
					x = m >> 3, r -= x, m -= x << 3, p &= (1 << m) - 1, e.next_in = r, e.next_out = a, e.avail_in = r < i ? 5 + (i - r) : 5 - (r - i), e.avail_out = a < s ? 257 + (s - a) : 257 - (a - s), n.hold = p, n.bits = m;
				};
			},
			"./node_modules/upng-js/node_modules/pako/lib/zlib/inflate.js"(e, t, n) {
				var r = n("./node_modules/upng-js/node_modules/pako/lib/utils/common.js"), i = n("./node_modules/upng-js/node_modules/pako/lib/zlib/adler32.js"), a = n("./node_modules/upng-js/node_modules/pako/lib/zlib/crc32.js"), o = n("./node_modules/upng-js/node_modules/pako/lib/zlib/inffast.js"), s = n("./node_modules/upng-js/node_modules/pako/lib/zlib/inftrees.js"), c = 0, l = 1, u = 2, d = 4, f = 5, p = 6, m = 0, h = 1, g = 2, _ = -2, v = -3, y = -4, b = -5, x = 8, S = 1, C = 2, w = 3, T = 4, E = 5, D = 6, O = 7, k = 8, A = 9, j = 10, M = 11, N = 12, P = 13, F = 14, I = 15, L = 16, R = 17, z = 18, B = 19, V = 20, H = 21, U = 22, W = 23, G = 24, ee = 25, te = 26, ne = 27, re = 28, ie = 29, K = 30, ae = 31, oe = 32, q = 852, J = 592, Y = 15;
				function se(e) {
					return (e >>> 24 & 255) + (e >>> 8 & 65280) + ((e & 65280) << 8) + ((e & 255) << 24);
				}
				function ce() {
					this.mode = 0, this.last = !1, this.wrap = 0, this.havedict = !1, this.flags = 0, this.dmax = 0, this.check = 0, this.total = 0, this.head = null, this.wbits = 0, this.wsize = 0, this.whave = 0, this.wnext = 0, this.window = null, this.hold = 0, this.bits = 0, this.length = 0, this.offset = 0, this.extra = 0, this.lencode = null, this.distcode = null, this.lenbits = 0, this.distbits = 0, this.ncode = 0, this.nlen = 0, this.ndist = 0, this.have = 0, this.next = null, this.lens = new r.Buf16(320), this.work = new r.Buf16(288), this.lendyn = null, this.distdyn = null, this.sane = 0, this.back = 0, this.was = 0;
				}
				function X(e) {
					var t;
					return !e || !e.state ? _ : (t = e.state, e.total_in = e.total_out = t.total = 0, e.msg = "", t.wrap && (e.adler = t.wrap & 1), t.mode = S, t.last = 0, t.havedict = 0, t.dmax = 32768, t.head = null, t.hold = 0, t.bits = 0, t.lencode = t.lendyn = new r.Buf32(q), t.distcode = t.distdyn = new r.Buf32(J), t.sane = 1, t.back = -1, m);
				}
				function le(e) {
					var t;
					return !e || !e.state ? _ : (t = e.state, t.wsize = 0, t.whave = 0, t.wnext = 0, X(e));
				}
				function Z(e, t) {
					var n, r;
					return !e || !e.state || (r = e.state, t < 0 ? (n = 0, t = -t) : (n = (t >> 4) + 1, t < 48 && (t &= 15)), t && (t < 8 || t > 15)) ? _ : (r.window !== null && r.wbits !== t && (r.window = null), r.wrap = n, r.wbits = t, le(e));
				}
				function Q(e, t) {
					var n, r;
					return e ? (r = new ce(), e.state = r, r.window = null, n = Z(e, t), n !== m && (e.state = null), n) : _;
				}
				function ue(e) {
					return Q(e, Y);
				}
				var de = !0, $, fe;
				function pe(e) {
					if (de) {
						var t;
						for ($ = new r.Buf32(512), fe = new r.Buf32(32), t = 0; t < 144;) e.lens[t++] = 8;
						for (; t < 256;) e.lens[t++] = 9;
						for (; t < 280;) e.lens[t++] = 7;
						for (; t < 288;) e.lens[t++] = 8;
						for (s(l, e.lens, 0, 288, $, 0, e.work, { bits: 9 }), t = 0; t < 32;) e.lens[t++] = 5;
						s(u, e.lens, 0, 32, fe, 0, e.work, { bits: 5 }), de = !1;
					}
					e.lencode = $, e.lenbits = 9, e.distcode = fe, e.distbits = 5;
				}
				function me(e, t, n, i) {
					var a, o = e.state;
					return o.window === null && (o.wsize = 1 << o.wbits, o.wnext = 0, o.whave = 0, o.window = new r.Buf8(o.wsize)), i >= o.wsize ? (r.arraySet(o.window, t, n - o.wsize, o.wsize, 0), o.wnext = 0, o.whave = o.wsize) : (a = o.wsize - o.wnext, a > i && (a = i), r.arraySet(o.window, t, n - i, a, o.wnext), i -= a, i ? (r.arraySet(o.window, t, n - i, i, 0), o.wnext = i, o.whave = o.wsize) : (o.wnext += a, o.wnext === o.wsize && (o.wnext = 0), o.whave < o.wsize && (o.whave += a))), 0;
				}
				function he(e, t) {
					var n, q, J, Y, ce, X, le, Z, Q, ue, de, $, fe, he, ge = 0, _e, ve, ye, be, xe, Se, Ce, we, Te = new r.Buf8(4), Ee, De, Oe = [
						16,
						17,
						18,
						0,
						8,
						7,
						9,
						6,
						10,
						5,
						11,
						4,
						12,
						3,
						13,
						2,
						14,
						1,
						15
					];
					if (!e || !e.state || !e.output || !e.input && e.avail_in !== 0) return _;
					n = e.state, n.mode === N && (n.mode = P), ce = e.next_out, J = e.output, le = e.avail_out, Y = e.next_in, q = e.input, X = e.avail_in, Z = n.hold, Q = n.bits, ue = X, de = le, we = m;
					inf_leave: for (;;) switch (n.mode) {
						case S:
							if (n.wrap === 0) {
								n.mode = P;
								break;
							}
							for (; Q < 16;) {
								if (X === 0) break inf_leave;
								X--, Z += q[Y++] << Q, Q += 8;
							}
							if (n.wrap & 2 && Z === 35615) {
								n.check = 0, Te[0] = Z & 255, Te[1] = Z >>> 8 & 255, n.check = a(n.check, Te, 2, 0), Z = 0, Q = 0, n.mode = C;
								break;
							}
							if (n.flags = 0, n.head && (n.head.done = !1), !(n.wrap & 1) || (((Z & 255) << 8) + (Z >> 8)) % 31) {
								e.msg = "incorrect header check", n.mode = K;
								break;
							}
							if ((Z & 15) !== x) {
								e.msg = "unknown compression method", n.mode = K;
								break;
							}
							if (Z >>>= 4, Q -= 4, Ce = (Z & 15) + 8, n.wbits === 0) n.wbits = Ce;
							else if (Ce > n.wbits) {
								e.msg = "invalid window size", n.mode = K;
								break;
							}
							n.dmax = 1 << Ce, e.adler = n.check = 1, n.mode = Z & 512 ? j : N, Z = 0, Q = 0;
							break;
						case C:
							for (; Q < 16;) {
								if (X === 0) break inf_leave;
								X--, Z += q[Y++] << Q, Q += 8;
							}
							if (n.flags = Z, (n.flags & 255) !== x) {
								e.msg = "unknown compression method", n.mode = K;
								break;
							}
							if (n.flags & 57344) {
								e.msg = "unknown header flags set", n.mode = K;
								break;
							}
							n.head && (n.head.text = Z >> 8 & 1), n.flags & 512 && (Te[0] = Z & 255, Te[1] = Z >>> 8 & 255, n.check = a(n.check, Te, 2, 0)), Z = 0, Q = 0, n.mode = w;
						case w:
							for (; Q < 32;) {
								if (X === 0) break inf_leave;
								X--, Z += q[Y++] << Q, Q += 8;
							}
							n.head && (n.head.time = Z), n.flags & 512 && (Te[0] = Z & 255, Te[1] = Z >>> 8 & 255, Te[2] = Z >>> 16 & 255, Te[3] = Z >>> 24 & 255, n.check = a(n.check, Te, 4, 0)), Z = 0, Q = 0, n.mode = T;
						case T:
							for (; Q < 16;) {
								if (X === 0) break inf_leave;
								X--, Z += q[Y++] << Q, Q += 8;
							}
							n.head && (n.head.xflags = Z & 255, n.head.os = Z >> 8), n.flags & 512 && (Te[0] = Z & 255, Te[1] = Z >>> 8 & 255, n.check = a(n.check, Te, 2, 0)), Z = 0, Q = 0, n.mode = E;
						case E:
							if (n.flags & 1024) {
								for (; Q < 16;) {
									if (X === 0) break inf_leave;
									X--, Z += q[Y++] << Q, Q += 8;
								}
								n.length = Z, n.head && (n.head.extra_len = Z), n.flags & 512 && (Te[0] = Z & 255, Te[1] = Z >>> 8 & 255, n.check = a(n.check, Te, 2, 0)), Z = 0, Q = 0;
							} else n.head && (n.head.extra = null);
							n.mode = D;
						case D:
							if (n.flags & 1024 && ($ = n.length, $ > X && ($ = X), $ && (n.head && (Ce = n.head.extra_len - n.length, n.head.extra || (n.head.extra = Array(n.head.extra_len)), r.arraySet(n.head.extra, q, Y, $, Ce)), n.flags & 512 && (n.check = a(n.check, q, $, Y)), X -= $, Y += $, n.length -= $), n.length)) break inf_leave;
							n.length = 0, n.mode = O;
						case O:
							if (n.flags & 2048) {
								if (X === 0) break inf_leave;
								$ = 0;
								do
									Ce = q[Y + $++], n.head && Ce && n.length < 65536 && (n.head.name += String.fromCharCode(Ce));
								while (Ce && $ < X);
								if (n.flags & 512 && (n.check = a(n.check, q, $, Y)), X -= $, Y += $, Ce) break inf_leave;
							} else n.head && (n.head.name = null);
							n.length = 0, n.mode = k;
						case k:
							if (n.flags & 4096) {
								if (X === 0) break inf_leave;
								$ = 0;
								do
									Ce = q[Y + $++], n.head && Ce && n.length < 65536 && (n.head.comment += String.fromCharCode(Ce));
								while (Ce && $ < X);
								if (n.flags & 512 && (n.check = a(n.check, q, $, Y)), X -= $, Y += $, Ce) break inf_leave;
							} else n.head && (n.head.comment = null);
							n.mode = A;
						case A:
							if (n.flags & 512) {
								for (; Q < 16;) {
									if (X === 0) break inf_leave;
									X--, Z += q[Y++] << Q, Q += 8;
								}
								if (Z !== (n.check & 65535)) {
									e.msg = "header crc mismatch", n.mode = K;
									break;
								}
								Z = 0, Q = 0;
							}
							n.head && (n.head.hcrc = n.flags >> 9 & 1, n.head.done = !0), e.adler = n.check = 0, n.mode = N;
							break;
						case j:
							for (; Q < 32;) {
								if (X === 0) break inf_leave;
								X--, Z += q[Y++] << Q, Q += 8;
							}
							e.adler = n.check = se(Z), Z = 0, Q = 0, n.mode = M;
						case M:
							if (n.havedict === 0) return e.next_out = ce, e.avail_out = le, e.next_in = Y, e.avail_in = X, n.hold = Z, n.bits = Q, g;
							e.adler = n.check = 1, n.mode = N;
						case N: if (t === f || t === p) break inf_leave;
						case P:
							if (n.last) {
								Z >>>= Q & 7, Q -= Q & 7, n.mode = ne;
								break;
							}
							for (; Q < 3;) {
								if (X === 0) break inf_leave;
								X--, Z += q[Y++] << Q, Q += 8;
							}
							switch (n.last = Z & 1, Z >>>= 1, --Q, Z & 3) {
								case 0:
									n.mode = F;
									break;
								case 1:
									if (pe(n), n.mode = V, t === p) {
										Z >>>= 2, Q -= 2;
										break inf_leave;
									}
									break;
								case 2:
									n.mode = R;
									break;
								case 3: e.msg = "invalid block type", n.mode = K;
							}
							Z >>>= 2, Q -= 2;
							break;
						case F:
							for (Z >>>= Q & 7, Q -= Q & 7; Q < 32;) {
								if (X === 0) break inf_leave;
								X--, Z += q[Y++] << Q, Q += 8;
							}
							if ((Z & 65535) != (Z >>> 16 ^ 65535)) {
								e.msg = "invalid stored block lengths", n.mode = K;
								break;
							}
							if (n.length = Z & 65535, Z = 0, Q = 0, n.mode = I, t === p) break inf_leave;
						case I: n.mode = L;
						case L:
							if ($ = n.length, $) {
								if ($ > X && ($ = X), $ > le && ($ = le), $ === 0) break inf_leave;
								r.arraySet(J, q, Y, $, ce), X -= $, Y += $, le -= $, ce += $, n.length -= $;
								break;
							}
							n.mode = N;
							break;
						case R:
							for (; Q < 14;) {
								if (X === 0) break inf_leave;
								X--, Z += q[Y++] << Q, Q += 8;
							}
							if (n.nlen = (Z & 31) + 257, Z >>>= 5, Q -= 5, n.ndist = (Z & 31) + 1, Z >>>= 5, Q -= 5, n.ncode = (Z & 15) + 4, Z >>>= 4, Q -= 4, n.nlen > 286 || n.ndist > 30) {
								e.msg = "too many length or distance symbols", n.mode = K;
								break;
							}
							n.have = 0, n.mode = z;
						case z:
							for (; n.have < n.ncode;) {
								for (; Q < 3;) {
									if (X === 0) break inf_leave;
									X--, Z += q[Y++] << Q, Q += 8;
								}
								n.lens[Oe[n.have++]] = Z & 7, Z >>>= 3, Q -= 3;
							}
							for (; n.have < 19;) n.lens[Oe[n.have++]] = 0;
							if (n.lencode = n.lendyn, n.lenbits = 7, Ee = { bits: n.lenbits }, we = s(c, n.lens, 0, 19, n.lencode, 0, n.work, Ee), n.lenbits = Ee.bits, we) {
								e.msg = "invalid code lengths set", n.mode = K;
								break;
							}
							n.have = 0, n.mode = B;
						case B:
							for (; n.have < n.nlen + n.ndist;) {
								for (; ge = n.lencode[Z & (1 << n.lenbits) - 1], _e = ge >>> 24, ve = ge >>> 16 & 255, ye = ge & 65535, !(_e <= Q);) {
									if (X === 0) break inf_leave;
									X--, Z += q[Y++] << Q, Q += 8;
								}
								if (ye < 16) Z >>>= _e, Q -= _e, n.lens[n.have++] = ye;
								else {
									if (ye === 16) {
										for (De = _e + 2; Q < De;) {
											if (X === 0) break inf_leave;
											X--, Z += q[Y++] << Q, Q += 8;
										}
										if (Z >>>= _e, Q -= _e, n.have === 0) {
											e.msg = "invalid bit length repeat", n.mode = K;
											break;
										}
										Ce = n.lens[n.have - 1], $ = 3 + (Z & 3), Z >>>= 2, Q -= 2;
									} else if (ye === 17) {
										for (De = _e + 3; Q < De;) {
											if (X === 0) break inf_leave;
											X--, Z += q[Y++] << Q, Q += 8;
										}
										Z >>>= _e, Q -= _e, Ce = 0, $ = 3 + (Z & 7), Z >>>= 3, Q -= 3;
									} else {
										for (De = _e + 7; Q < De;) {
											if (X === 0) break inf_leave;
											X--, Z += q[Y++] << Q, Q += 8;
										}
										Z >>>= _e, Q -= _e, Ce = 0, $ = 11 + (Z & 127), Z >>>= 7, Q -= 7;
									}
									if (n.have + $ > n.nlen + n.ndist) {
										e.msg = "invalid bit length repeat", n.mode = K;
										break;
									}
									for (; $--;) n.lens[n.have++] = Ce;
								}
							}
							if (n.mode === K) break;
							if (n.lens[256] === 0) {
								e.msg = "invalid code -- missing end-of-block", n.mode = K;
								break;
							}
							if (n.lenbits = 9, Ee = { bits: n.lenbits }, we = s(l, n.lens, 0, n.nlen, n.lencode, 0, n.work, Ee), n.lenbits = Ee.bits, we) {
								e.msg = "invalid literal/lengths set", n.mode = K;
								break;
							}
							if (n.distbits = 6, n.distcode = n.distdyn, Ee = { bits: n.distbits }, we = s(u, n.lens, n.nlen, n.ndist, n.distcode, 0, n.work, Ee), n.distbits = Ee.bits, we) {
								e.msg = "invalid distances set", n.mode = K;
								break;
							}
							if (n.mode = V, t === p) break inf_leave;
						case V: n.mode = H;
						case H:
							if (X >= 6 && le >= 258) {
								e.next_out = ce, e.avail_out = le, e.next_in = Y, e.avail_in = X, n.hold = Z, n.bits = Q, o(e, de), ce = e.next_out, J = e.output, le = e.avail_out, Y = e.next_in, q = e.input, X = e.avail_in, Z = n.hold, Q = n.bits, n.mode === N && (n.back = -1);
								break;
							}
							for (n.back = 0; ge = n.lencode[Z & (1 << n.lenbits) - 1], _e = ge >>> 24, ve = ge >>> 16 & 255, ye = ge & 65535, !(_e <= Q);) {
								if (X === 0) break inf_leave;
								X--, Z += q[Y++] << Q, Q += 8;
							}
							if (ve && !(ve & 240)) {
								for (be = _e, xe = ve, Se = ye; ge = n.lencode[Se + ((Z & (1 << be + xe) - 1) >> be)], _e = ge >>> 24, ve = ge >>> 16 & 255, ye = ge & 65535, !(be + _e <= Q);) {
									if (X === 0) break inf_leave;
									X--, Z += q[Y++] << Q, Q += 8;
								}
								Z >>>= be, Q -= be, n.back += be;
							}
							if (Z >>>= _e, Q -= _e, n.back += _e, n.length = ye, ve === 0) {
								n.mode = te;
								break;
							}
							if (ve & 32) {
								n.back = -1, n.mode = N;
								break;
							}
							if (ve & 64) {
								e.msg = "invalid literal/length code", n.mode = K;
								break;
							}
							n.extra = ve & 15, n.mode = U;
						case U:
							if (n.extra) {
								for (De = n.extra; Q < De;) {
									if (X === 0) break inf_leave;
									X--, Z += q[Y++] << Q, Q += 8;
								}
								n.length += Z & (1 << n.extra) - 1, Z >>>= n.extra, Q -= n.extra, n.back += n.extra;
							}
							n.was = n.length, n.mode = W;
						case W:
							for (; ge = n.distcode[Z & (1 << n.distbits) - 1], _e = ge >>> 24, ve = ge >>> 16 & 255, ye = ge & 65535, !(_e <= Q);) {
								if (X === 0) break inf_leave;
								X--, Z += q[Y++] << Q, Q += 8;
							}
							if (!(ve & 240)) {
								for (be = _e, xe = ve, Se = ye; ge = n.distcode[Se + ((Z & (1 << be + xe) - 1) >> be)], _e = ge >>> 24, ve = ge >>> 16 & 255, ye = ge & 65535, !(be + _e <= Q);) {
									if (X === 0) break inf_leave;
									X--, Z += q[Y++] << Q, Q += 8;
								}
								Z >>>= be, Q -= be, n.back += be;
							}
							if (Z >>>= _e, Q -= _e, n.back += _e, ve & 64) {
								e.msg = "invalid distance code", n.mode = K;
								break;
							}
							n.offset = ye, n.extra = ve & 15, n.mode = G;
						case G:
							if (n.extra) {
								for (De = n.extra; Q < De;) {
									if (X === 0) break inf_leave;
									X--, Z += q[Y++] << Q, Q += 8;
								}
								n.offset += Z & (1 << n.extra) - 1, Z >>>= n.extra, Q -= n.extra, n.back += n.extra;
							}
							if (n.offset > n.dmax) {
								e.msg = "invalid distance too far back", n.mode = K;
								break;
							}
							n.mode = ee;
						case ee:
							if (le === 0) break inf_leave;
							if ($ = de - le, n.offset > $) {
								if ($ = n.offset - $, $ > n.whave && n.sane) {
									e.msg = "invalid distance too far back", n.mode = K;
									break;
								}
								$ > n.wnext ? ($ -= n.wnext, fe = n.wsize - $) : fe = n.wnext - $, $ > n.length && ($ = n.length), he = n.window;
							} else he = J, fe = ce - n.offset, $ = n.length;
							$ > le && ($ = le), le -= $, n.length -= $;
							do
								J[ce++] = he[fe++];
							while (--$);
							n.length === 0 && (n.mode = H);
							break;
						case te:
							if (le === 0) break inf_leave;
							J[ce++] = n.length, le--, n.mode = H;
							break;
						case ne:
							if (n.wrap) {
								for (; Q < 32;) {
									if (X === 0) break inf_leave;
									X--, Z |= q[Y++] << Q, Q += 8;
								}
								if (de -= le, e.total_out += de, n.total += de, de && (e.adler = n.check = n.flags ? a(n.check, J, de, ce - de) : i(n.check, J, de, ce - de)), de = le, (n.flags ? Z : se(Z)) !== n.check) {
									e.msg = "incorrect data check", n.mode = K;
									break;
								}
								Z = 0, Q = 0;
							}
							n.mode = re;
						case re:
							if (n.wrap && n.flags) {
								for (; Q < 32;) {
									if (X === 0) break inf_leave;
									X--, Z += q[Y++] << Q, Q += 8;
								}
								if (Z !== (n.total & 4294967295)) {
									e.msg = "incorrect length check", n.mode = K;
									break;
								}
								Z = 0, Q = 0;
							}
							n.mode = ie;
						case ie:
							we = h;
							break inf_leave;
						case K:
							we = v;
							break inf_leave;
						case ae: return y;
						case oe:
						default: return _;
					}
					return e.next_out = ce, e.avail_out = le, e.next_in = Y, e.avail_in = X, n.hold = Z, n.bits = Q, (n.wsize || de !== e.avail_out && n.mode < K && (n.mode < ne || t !== d)) && me(e, e.output, e.next_out, de - e.avail_out) ? (n.mode = ae, y) : (ue -= e.avail_in, de -= e.avail_out, e.total_in += ue, e.total_out += de, n.total += de, n.wrap && de && (e.adler = n.check = n.flags ? a(n.check, J, de, e.next_out - de) : i(n.check, J, de, e.next_out - de)), e.data_type = n.bits + (n.last ? 64 : 0) + (n.mode === N ? 128 : 0) + (n.mode === V || n.mode === I ? 256 : 0), (ue === 0 && de === 0 || t === d) && we === m && (we = b), we);
				}
				function ge(e) {
					if (!e || !e.state) return _;
					var t = e.state;
					return t.window &&= null, e.state = null, m;
				}
				function _e(e, t) {
					var n;
					return !e || !e.state || (n = e.state, !(n.wrap & 2)) ? _ : (n.head = t, t.done = !1, m);
				}
				function ve(e, t) {
					var n = t.length, r, a, o;
					return !e || !e.state || (r = e.state, r.wrap !== 0 && r.mode !== M) ? _ : r.mode === M && (a = 1, a = i(a, t, n, 0), a !== r.check) ? v : (o = me(e, t, n, n), o ? (r.mode = ae, y) : (r.havedict = 1, m));
				}
				t.inflateReset = le, t.inflateReset2 = Z, t.inflateResetKeep = X, t.inflateInit = ue, t.inflateInit2 = Q, t.inflate = he, t.inflateEnd = ge, t.inflateGetHeader = _e, t.inflateSetDictionary = ve, t.inflateInfo = "pako inflate (from Nodeca project)";
			},
			"./node_modules/upng-js/node_modules/pako/lib/zlib/inftrees.js"(e, t, n) {
				var r = n("./node_modules/upng-js/node_modules/pako/lib/utils/common.js"), i = 15, a = 852, o = 592, s = 0, c = 1, l = 2, u = [
					3,
					4,
					5,
					6,
					7,
					8,
					9,
					10,
					11,
					13,
					15,
					17,
					19,
					23,
					27,
					31,
					35,
					43,
					51,
					59,
					67,
					83,
					99,
					115,
					131,
					163,
					195,
					227,
					258,
					0,
					0
				], d = [
					16,
					16,
					16,
					16,
					16,
					16,
					16,
					16,
					17,
					17,
					17,
					17,
					18,
					18,
					18,
					18,
					19,
					19,
					19,
					19,
					20,
					20,
					20,
					20,
					21,
					21,
					21,
					21,
					16,
					72,
					78
				], f = [
					1,
					2,
					3,
					4,
					5,
					7,
					9,
					13,
					17,
					25,
					33,
					49,
					65,
					97,
					129,
					193,
					257,
					385,
					513,
					769,
					1025,
					1537,
					2049,
					3073,
					4097,
					6145,
					8193,
					12289,
					16385,
					24577,
					0,
					0
				], p = [
					16,
					16,
					16,
					16,
					17,
					17,
					18,
					18,
					19,
					19,
					20,
					20,
					21,
					21,
					22,
					22,
					23,
					23,
					24,
					24,
					25,
					25,
					26,
					26,
					27,
					27,
					28,
					28,
					29,
					29,
					64,
					64
				];
				e.exports = function(e, t, n, m, h, g, _, v) {
					var y = v.bits, b = 0, x = 0, S = 0, C = 0, w = 0, T = 0, E = 0, D = 0, O = 0, k = 0, A, j, M, N, P, F = null, I = 0, L, R = new r.Buf16(i + 1), z = new r.Buf16(i + 1), B = null, V = 0, H, U, W;
					for (b = 0; b <= i; b++) R[b] = 0;
					for (x = 0; x < m; x++) R[t[n + x]]++;
					for (w = y, C = i; C >= 1 && R[C] === 0; C--);
					if (w > C && (w = C), C === 0) return h[g++] = 20971520, h[g++] = 20971520, v.bits = 1, 0;
					for (S = 1; S < C && R[S] === 0; S++);
					for (w < S && (w = S), D = 1, b = 1; b <= i; b++) if (D <<= 1, D -= R[b], D < 0) return -1;
					if (D > 0 && (e === s || C !== 1)) return -1;
					for (z[1] = 0, b = 1; b < i; b++) z[b + 1] = z[b] + R[b];
					for (x = 0; x < m; x++) t[n + x] !== 0 && (_[z[t[n + x]]++] = x);
					if (e === s ? (F = B = _, L = 19) : e === c ? (F = u, I -= 257, B = d, V -= 257, L = 256) : (F = f, B = p, L = -1), k = 0, x = 0, b = S, P = g, T = w, E = 0, M = -1, O = 1 << w, N = O - 1, e === c && O > a || e === l && O > o) return 1;
					for (;;) {
						H = b - E, _[x] < L ? (U = 0, W = _[x]) : _[x] > L ? (U = B[V + _[x]], W = F[I + _[x]]) : (U = 96, W = 0), A = 1 << b - E, j = 1 << T, S = j;
						do
							j -= A, h[P + (k >> E) + j] = H << 24 | U << 16 | W | 0;
						while (j !== 0);
						for (A = 1 << b - 1; k & A;) A >>= 1;
						if (A === 0 ? k = 0 : (k &= A - 1, k += A), x++, --R[b] === 0) {
							if (b === C) break;
							b = t[n + _[x]];
						}
						if (b > w && (k & N) !== M) {
							for (E === 0 && (E = w), P += S, T = b - E, D = 1 << T; T + E < C && (D -= R[T + E], !(D <= 0));) T++, D <<= 1;
							if (O += 1 << T, e === c && O > a || e === l && O > o) return 1;
							M = k & N, h[M] = w << 24 | T << 16 | P - g | 0;
						}
					}
					return k !== 0 && (h[P + k] = b - E << 24 | 4194304), v.bits = w, 0;
				};
			},
			"./node_modules/upng-js/node_modules/pako/lib/zlib/messages.js"(e) {
				e.exports = {
					2: "need dictionary",
					1: "stream end",
					0: "",
					"-1": "file error",
					"-2": "stream error",
					"-3": "data error",
					"-4": "insufficient memory",
					"-5": "buffer error",
					"-6": "incompatible version"
				};
			},
			"./node_modules/upng-js/node_modules/pako/lib/zlib/trees.js"(e, t, n) {
				var r = n("./node_modules/upng-js/node_modules/pako/lib/utils/common.js"), i = 4, a = 0, o = 1, s = 2;
				function c(e) {
					for (var t = e.length; --t >= 0;) e[t] = 0;
				}
				var l = 0, u = 1, d = 2, f = 3, p = 258, m = 29, h = 256, g = h + 1 + m, _ = 30, v = 19, y = 2 * g + 1, b = 15, x = 16, S = 7, C = 256, w = 16, T = 17, E = 18, D = [
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					1,
					1,
					1,
					1,
					2,
					2,
					2,
					2,
					3,
					3,
					3,
					3,
					4,
					4,
					4,
					4,
					5,
					5,
					5,
					5,
					0
				], O = [
					0,
					0,
					0,
					0,
					1,
					1,
					2,
					2,
					3,
					3,
					4,
					4,
					5,
					5,
					6,
					6,
					7,
					7,
					8,
					8,
					9,
					9,
					10,
					10,
					11,
					11,
					12,
					12,
					13,
					13
				], k = [
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					2,
					3,
					7
				], A = [
					16,
					17,
					18,
					0,
					8,
					7,
					9,
					6,
					10,
					5,
					11,
					4,
					12,
					3,
					13,
					2,
					14,
					1,
					15
				], j = 512, M = Array((g + 2) * 2);
				c(M);
				var N = Array(_ * 2);
				c(N);
				var P = Array(j);
				c(P);
				var F = Array(p - f + 1);
				c(F);
				var I = Array(m);
				c(I);
				var L = Array(_);
				c(L);
				function R(e, t, n, r, i) {
					this.static_tree = e, this.extra_bits = t, this.extra_base = n, this.elems = r, this.max_length = i, this.has_stree = e && e.length;
				}
				var z, B, V;
				function H(e, t) {
					this.dyn_tree = e, this.max_code = 0, this.stat_desc = t;
				}
				function U(e) {
					return e < 256 ? P[e] : P[256 + (e >>> 7)];
				}
				function W(e, t) {
					e.pending_buf[e.pending++] = t & 255, e.pending_buf[e.pending++] = t >>> 8 & 255;
				}
				function G(e, t, n) {
					e.bi_valid > x - n ? (e.bi_buf |= t << e.bi_valid & 65535, W(e, e.bi_buf), e.bi_buf = t >> x - e.bi_valid, e.bi_valid += n - x) : (e.bi_buf |= t << e.bi_valid & 65535, e.bi_valid += n);
				}
				function ee(e, t, n) {
					G(e, n[t * 2], n[t * 2 + 1]);
				}
				function te(e, t) {
					var n = 0;
					do
						n |= e & 1, e >>>= 1, n <<= 1;
					while (--t > 0);
					return n >>> 1;
				}
				function ne(e) {
					e.bi_valid === 16 ? (W(e, e.bi_buf), e.bi_buf = 0, e.bi_valid = 0) : e.bi_valid >= 8 && (e.pending_buf[e.pending++] = e.bi_buf & 255, e.bi_buf >>= 8, e.bi_valid -= 8);
				}
				function re(e, t) {
					var n = t.dyn_tree, r = t.max_code, i = t.stat_desc.static_tree, a = t.stat_desc.has_stree, o = t.stat_desc.extra_bits, s = t.stat_desc.extra_base, c = t.stat_desc.max_length, l, u, d, f, p, m, h = 0;
					for (f = 0; f <= b; f++) e.bl_count[f] = 0;
					for (n[e.heap[e.heap_max] * 2 + 1] = 0, l = e.heap_max + 1; l < y; l++) u = e.heap[l], f = n[n[u * 2 + 1] * 2 + 1] + 1, f > c && (f = c, h++), n[u * 2 + 1] = f, !(u > r) && (e.bl_count[f]++, p = 0, u >= s && (p = o[u - s]), m = n[u * 2], e.opt_len += m * (f + p), a && (e.static_len += m * (i[u * 2 + 1] + p)));
					if (h !== 0) {
						do {
							for (f = c - 1; e.bl_count[f] === 0;) f--;
							e.bl_count[f]--, e.bl_count[f + 1] += 2, e.bl_count[c]--, h -= 2;
						} while (h > 0);
						for (f = c; f !== 0; f--) for (u = e.bl_count[f]; u !== 0;) d = e.heap[--l], !(d > r) && (n[d * 2 + 1] !== f && (e.opt_len += (f - n[d * 2 + 1]) * n[d * 2], n[d * 2 + 1] = f), u--);
					}
				}
				function ie(e, t, n) {
					var r = Array(b + 1), i = 0, a, o;
					for (a = 1; a <= b; a++) r[a] = i = i + n[a - 1] << 1;
					for (o = 0; o <= t; o++) {
						var s = e[o * 2 + 1];
						s !== 0 && (e[o * 2] = te(r[s]++, s));
					}
				}
				function K() {
					var e, t, n, r, i, a = Array(b + 1);
					for (n = 0, r = 0; r < m - 1; r++) for (I[r] = n, e = 0; e < 1 << D[r]; e++) F[n++] = r;
					for (F[n - 1] = r, i = 0, r = 0; r < 16; r++) for (L[r] = i, e = 0; e < 1 << O[r]; e++) P[i++] = r;
					for (i >>= 7; r < _; r++) for (L[r] = i << 7, e = 0; e < 1 << O[r] - 7; e++) P[256 + i++] = r;
					for (t = 0; t <= b; t++) a[t] = 0;
					for (e = 0; e <= 143;) M[e * 2 + 1] = 8, e++, a[8]++;
					for (; e <= 255;) M[e * 2 + 1] = 9, e++, a[9]++;
					for (; e <= 279;) M[e * 2 + 1] = 7, e++, a[7]++;
					for (; e <= 287;) M[e * 2 + 1] = 8, e++, a[8]++;
					for (ie(M, g + 1, a), e = 0; e < _; e++) N[e * 2 + 1] = 5, N[e * 2] = te(e, 5);
					z = new R(M, D, h + 1, g, b), B = new R(N, O, 0, _, b), V = new R([], k, 0, v, S);
				}
				function ae(e) {
					var t;
					for (t = 0; t < g; t++) e.dyn_ltree[t * 2] = 0;
					for (t = 0; t < _; t++) e.dyn_dtree[t * 2] = 0;
					for (t = 0; t < v; t++) e.bl_tree[t * 2] = 0;
					e.dyn_ltree[C * 2] = 1, e.opt_len = e.static_len = 0, e.last_lit = e.matches = 0;
				}
				function oe(e) {
					e.bi_valid > 8 ? W(e, e.bi_buf) : e.bi_valid > 0 && (e.pending_buf[e.pending++] = e.bi_buf), e.bi_buf = 0, e.bi_valid = 0;
				}
				function q(e, t, n, i) {
					oe(e), i && (W(e, n), W(e, ~n)), r.arraySet(e.pending_buf, e.window, t, n, e.pending), e.pending += n;
				}
				function J(e, t, n, r) {
					var i = t * 2, a = n * 2;
					return e[i] < e[a] || e[i] === e[a] && r[t] <= r[n];
				}
				function Y(e, t, n) {
					for (var r = e.heap[n], i = n << 1; i <= e.heap_len && (i < e.heap_len && J(t, e.heap[i + 1], e.heap[i], e.depth) && i++, !J(t, r, e.heap[i], e.depth));) e.heap[n] = e.heap[i], n = i, i <<= 1;
					e.heap[n] = r;
				}
				function se(e, t, n) {
					var r, i, a = 0, o, s;
					if (e.last_lit !== 0) do
						r = e.pending_buf[e.d_buf + a * 2] << 8 | e.pending_buf[e.d_buf + a * 2 + 1], i = e.pending_buf[e.l_buf + a], a++, r === 0 ? ee(e, i, t) : (o = F[i], ee(e, o + h + 1, t), s = D[o], s !== 0 && (i -= I[o], G(e, i, s)), r--, o = U(r), ee(e, o, n), s = O[o], s !== 0 && (r -= L[o], G(e, r, s)));
					while (a < e.last_lit);
					ee(e, C, t);
				}
				function ce(e, t) {
					var n = t.dyn_tree, r = t.stat_desc.static_tree, i = t.stat_desc.has_stree, a = t.stat_desc.elems, o, s, c = -1, l;
					for (e.heap_len = 0, e.heap_max = y, o = 0; o < a; o++) n[o * 2] === 0 ? n[o * 2 + 1] = 0 : (e.heap[++e.heap_len] = c = o, e.depth[o] = 0);
					for (; e.heap_len < 2;) l = e.heap[++e.heap_len] = c < 2 ? ++c : 0, n[l * 2] = 1, e.depth[l] = 0, e.opt_len--, i && (e.static_len -= r[l * 2 + 1]);
					for (t.max_code = c, o = e.heap_len >> 1; o >= 1; o--) Y(e, n, o);
					l = a;
					do
						o = e.heap[1], e.heap[1] = e.heap[e.heap_len--], Y(e, n, 1), s = e.heap[1], e.heap[--e.heap_max] = o, e.heap[--e.heap_max] = s, n[l * 2] = n[o * 2] + n[s * 2], e.depth[l] = (e.depth[o] >= e.depth[s] ? e.depth[o] : e.depth[s]) + 1, n[o * 2 + 1] = n[s * 2 + 1] = l, e.heap[1] = l++, Y(e, n, 1);
					while (e.heap_len >= 2);
					e.heap[--e.heap_max] = e.heap[1], re(e, t), ie(n, c, e.bl_count);
				}
				function X(e, t, n) {
					var r, i = -1, a, o = t[1], s = 0, c = 7, l = 4;
					for (o === 0 && (c = 138, l = 3), t[(n + 1) * 2 + 1] = 65535, r = 0; r <= n; r++) a = o, o = t[(r + 1) * 2 + 1], !(++s < c && a === o) && (s < l ? e.bl_tree[a * 2] += s : a === 0 ? s <= 10 ? e.bl_tree[T * 2]++ : e.bl_tree[E * 2]++ : (a !== i && e.bl_tree[a * 2]++, e.bl_tree[w * 2]++), s = 0, i = a, o === 0 ? (c = 138, l = 3) : a === o ? (c = 6, l = 3) : (c = 7, l = 4));
				}
				function le(e, t, n) {
					var r, i = -1, a, o = t[1], s = 0, c = 7, l = 4;
					for (o === 0 && (c = 138, l = 3), r = 0; r <= n; r++) if (a = o, o = t[(r + 1) * 2 + 1], !(++s < c && a === o)) {
						if (s < l) do
							ee(e, a, e.bl_tree);
						while (--s !== 0);
						else a === 0 ? s <= 10 ? (ee(e, T, e.bl_tree), G(e, s - 3, 3)) : (ee(e, E, e.bl_tree), G(e, s - 11, 7)) : (a !== i && (ee(e, a, e.bl_tree), s--), ee(e, w, e.bl_tree), G(e, s - 3, 2));
						s = 0, i = a, o === 0 ? (c = 138, l = 3) : a === o ? (c = 6, l = 3) : (c = 7, l = 4);
					}
				}
				function Z(e) {
					var t;
					for (X(e, e.dyn_ltree, e.l_desc.max_code), X(e, e.dyn_dtree, e.d_desc.max_code), ce(e, e.bl_desc), t = v - 1; t >= 3 && e.bl_tree[A[t] * 2 + 1] === 0; t--);
					return e.opt_len += 3 * (t + 1) + 5 + 5 + 4, t;
				}
				function Q(e, t, n, r) {
					var i;
					for (G(e, t - 257, 5), G(e, n - 1, 5), G(e, r - 4, 4), i = 0; i < r; i++) G(e, e.bl_tree[A[i] * 2 + 1], 3);
					le(e, e.dyn_ltree, t - 1), le(e, e.dyn_dtree, n - 1);
				}
				function ue(e) {
					var t = 4093624447, n;
					for (n = 0; n <= 31; n++, t >>>= 1) if (t & 1 && e.dyn_ltree[n * 2] !== 0) return a;
					if (e.dyn_ltree[18] !== 0 || e.dyn_ltree[20] !== 0 || e.dyn_ltree[26] !== 0) return o;
					for (n = 32; n < h; n++) if (e.dyn_ltree[n * 2] !== 0) return o;
					return a;
				}
				var de = !1;
				function $(e) {
					de ||= (K(), !0), e.l_desc = new H(e.dyn_ltree, z), e.d_desc = new H(e.dyn_dtree, B), e.bl_desc = new H(e.bl_tree, V), e.bi_buf = 0, e.bi_valid = 0, ae(e);
				}
				function fe(e, t, n, r) {
					G(e, (l << 1) + +!!r, 3), q(e, t, n, !0);
				}
				function pe(e) {
					G(e, u << 1, 3), ee(e, C, M), ne(e);
				}
				function me(e, t, n, r) {
					var a, o, c = 0;
					e.level > 0 ? (e.strm.data_type === s && (e.strm.data_type = ue(e)), ce(e, e.l_desc), ce(e, e.d_desc), c = Z(e), a = e.opt_len + 3 + 7 >>> 3, o = e.static_len + 3 + 7 >>> 3, o <= a && (a = o)) : a = o = n + 5, n + 4 <= a && t !== -1 ? fe(e, t, n, r) : e.strategy === i || o === a ? (G(e, (u << 1) + +!!r, 3), se(e, M, N)) : (G(e, (d << 1) + +!!r, 3), Q(e, e.l_desc.max_code + 1, e.d_desc.max_code + 1, c + 1), se(e, e.dyn_ltree, e.dyn_dtree)), ae(e), r && oe(e);
				}
				function he(e, t, n) {
					return e.pending_buf[e.d_buf + e.last_lit * 2] = t >>> 8 & 255, e.pending_buf[e.d_buf + e.last_lit * 2 + 1] = t & 255, e.pending_buf[e.l_buf + e.last_lit] = n & 255, e.last_lit++, t === 0 ? e.dyn_ltree[n * 2]++ : (e.matches++, t--, e.dyn_ltree[(F[n] + h + 1) * 2]++, e.dyn_dtree[U(t) * 2]++), e.last_lit === e.lit_bufsize - 1;
				}
				t._tr_init = $, t._tr_stored_block = fe, t._tr_flush_block = me, t._tr_tally = he, t._tr_align = pe;
			},
			"./node_modules/upng-js/node_modules/pako/lib/zlib/zstream.js"(e) {
				function t() {
					this.input = null, this.next_in = 0, this.avail_in = 0, this.total_in = 0, this.output = null, this.next_out = 0, this.avail_out = 0, this.total_out = 0, this.msg = "", this.state = null, this.data_type = 2, this.adler = 0;
				}
				e.exports = t;
			},
			"./src/3Dmol.ts"(e, t, n) {
				n.r(t), n.d(t, {
					CAP: () => o.CAP,
					CC: () => i.CC,
					CONTEXTS_PER_VIEWPORT: () => l.CONTEXTS_PER_VIEWPORT,
					Color: () => i.Color,
					CustomLinear: () => u.CustomLinear,
					Cylinder: () => b.Cylinder,
					GLDraw: () => o.GLDraw,
					GLModel: () => s.GLModel,
					GLShape: () => c.GLShape,
					GLViewer: () => l.GLViewer,
					GLVolumetricRender: () => v.GLVolumetricRender,
					Gradient: () => u.Gradient,
					GradientType: () => u.GradientType,
					Label: () => d.Label,
					LabelCount: () => d.LabelCount,
					MarchingCube: () => m.MarchingCube,
					MarchingCubeInitializer: () => m.MarchingCubeInitializer,
					Matrix3: () => y.Matrix3,
					Matrix4: () => y.Matrix4,
					Parsers: () => f.Parsers,
					PausableTimer: () => g.PausableTimer,
					PointGrid: () => m.PointGrid,
					ProteinSurface: () => m.ProteinSurface,
					Quaternion: () => y.Quaternion,
					ROYGB: () => u.ROYGB,
					RWB: () => u.RWB,
					Ray: () => y.Ray,
					Sinebow: () => u.Sinebow,
					Sphere: () => b.Sphere,
					SurfaceType: () => m.SurfaceType,
					Triangle: () => b.Triangle,
					Vector2: () => y.Vector2,
					Vector3: () => y.Vector3,
					VolumeData: () => _.VolumeData,
					adjustVolumeStyle: () => g.adjustVolumeStyle,
					applyPartialCharges: () => p.applyPartialCharges,
					autoinit: () => r.autoinit,
					autoload: () => r.autoload,
					base64ToArray: () => g.base64ToArray,
					bondLength: () => f.bondLength,
					builtinColorSchemes: () => i.builtinColorSchemes,
					builtinGradients: () => u.builtinGradients,
					chains: () => i.chains,
					clamp: () => y.clamp,
					conversionMatrix3: () => y.conversionMatrix3,
					createStereoViewer: () => l.createStereoViewer,
					createViewer: () => l.createViewer,
					createViewerGrid: () => l.createViewerGrid,
					deepCopy: () => g.deepCopy,
					degToRad: () => y.degToRad,
					download: () => g.download,
					drawCartoon: () => a.drawCartoon,
					elementColors: () => i.elementColors,
					extend: () => g.extend,
					get: () => g.get,
					getAtomProperty: () => g.getAtomProperty,
					getColorFromStyle: () => g.getColorFromStyle,
					getElement: () => g.getElement,
					getExtent: () => g.getExtent,
					getGradient: () => u.getGradient,
					getPropertyRange: () => g.getPropertyRange,
					getbin: () => g.getbin,
					htmlColors: () => i.htmlColors,
					inflateString: () => g.inflateString,
					isEmptyObject: () => g.isEmptyObject,
					isNumeric: () => g.isNumeric,
					makeFunction: () => g.makeFunction,
					mergeGeos: () => g.mergeGeos,
					normalizeValue: () => u.normalizeValue,
					partialCharges: () => p.partialCharges,
					processing_autoinit: () => r.processing_autoinit,
					residues: () => i.residues,
					setBondLength: () => f.setBondLength,
					setSyncSurface: () => m.setSyncSurface,
					specStringToObject: () => g.specStringToObject,
					splitMesh: () => c.splitMesh,
					ssColors: () => i.ssColors,
					subdivide_spline: () => a.subdivide_spline,
					syncSurface: () => m.syncSurface,
					viewers: () => r.viewers
				});
				var r = n("./src/autoload.ts"), i = n("./src/colors.ts"), a = n("./src/glcartoon.ts"), o = n("./src/GLDraw.ts"), s = n("./src/GLModel.ts"), c = n("./src/GLShape.ts"), l = n("./src/GLViewer.ts"), u = n("./src/Gradient.ts"), d = n("./src/Label.ts"), f = n("./src/parsers/index.ts"), p = n("./src/partialCharges.ts"), m = n("./src/ProteinSurface4.ts"), h = n("./src/specs.ts"), g = n("./src/utilities.ts"), _ = n("./src/VolumeData.ts"), v = n("./src/VolumetricRender.ts"), y = n("./src/WebGL/math/index.ts"), b = n("./src/WebGL/shapes/index.ts");
			},
			"./src/GLDraw.ts"(e, t, n) {
				n.r(t), n.d(t, {
					CAP: () => i,
					GLDraw: () => a
				});
				var r = n("./src/WebGL/math/index.ts"), i;
				(function(e) {
					e[e.NONE = 0] = "NONE", e[e.FLAT = 1] = "FLAT", e[e.ROUND = 2] = "ROUND";
				})(i ||= {});
				var a;
				(function(e) {
					function t(e, t, n) {
						var r = Math.hypot(e, t), i, a, o, s, c;
						r < 1e-4 ? (a = 0, o = 1) : (a = -e / r, o = t / r), t = -a * e + o * t, i = Math.hypot(t, n), i < 1e-4 ? (s = 0, c = 1) : (s = n / i, c = t / i);
						var l = /* @__PURE__ */ new Float32Array(9);
						return l[0] = o, l[1] = a, l[2] = 0, l[3] = -a * c, l[4] = o * c, l[5] = s, l[6] = a * s, l[7] = -o * s, l[8] = c, l;
					}
					class n {
						constructor() {
							this.cache = {};
							let e = [], t = 4, n = 16, i = 2, a = 2 ** i, o = 16 / a, s;
							for (e[0] = new r.Vector3(-1, 0, 0), e[o] = new r.Vector3(0, 0, 1), e[o * 2] = new r.Vector3(1, 0, 0), e[o * 3] = new r.Vector3(0, 0, -1), i = 3; i <= 4; i++) {
								for (a = 2 ** (i - 1), o = 16 / a, s = 0; s < a - 1; s++) e[o / 2 + s * o] = e[s * o].clone().add(e[(s + 1) * o]).normalize();
								s = a - 1, e[o / 2 + s * o] = e[s * o].clone().add(e[0]).normalize();
							}
							this.basisVectors = e;
						}
						getVerticesForRadius(e, t, n) {
							if (this.cache !== void 0 && this.cache[e] !== void 0 && this.cache[e][t + n] !== void 0) return this.cache[e][t + n];
							for (var a = this.basisVectors.length, o = [], s = [], c, l = 0; l < a; l++) o.push(this.basisVectors[l].clone().multiplyScalar(e)), o.push(this.basisVectors[l].clone().multiplyScalar(e)), c = this.basisVectors[l].clone().normalize(), s.push(c), s.push(c);
							var u = [], d = 10, f = a;
							if (d % 2 != 0 || !d) return console.error("heightSegments must be even"), null;
							var p = 0, m = Math.PI * 2, h = 0, g = Math.PI, _, v, y = !1, b = !1;
							for (v = 0; v <= d; v++) {
								y = v === 0 || v === d, b = v === d / 2;
								var x = [], S = [];
								for (_ = 0; _ <= f; _++) {
									if (b) {
										var C = _ < f ? 2 * _ : 0;
										S.push(C + 1), x.push(C);
										continue;
									}
									var w = _ / f, T = v / d;
									if (!y || _ === 0) {
										if (_ < f) {
											var E = new r.Vector3();
											E.x = -e * Math.cos(p + w * m) * Math.sin(h + T * g), E.y = t == 1 ? 0 : e * Math.cos(h + T * g), E.z = e * Math.sin(p + w * m) * Math.sin(h + T * g), Math.abs(E.x) < 1e-5 && (E.x = 0), Math.abs(E.y) < 1e-5 && (E.y = 0), Math.abs(E.z) < 1e-5 && (E.z = 0), t == i.FLAT ? (c = new r.Vector3(0, Math.cos(h + T * g), 0), c.normalize()) : (c = new r.Vector3(E.x, E.y, E.z), c.normalize()), o.push(E), s.push(c), x.push(o.length - 1);
										} else x.push(o.length - f);
									} else y && x.push(o.length - 1);
								}
								b && u.push(S), u.push(x);
							}
							var D = {
								vertices: o,
								normals: s,
								verticesRows: u,
								w: f,
								h: d
							};
							return e in this.cache || (this.cache[e] = {}), this.cache[e][t + n] = D, D;
						}
					}
					var a = new n();
					function o(e, n, r, o, s, c = 0, l = 0) {
						if (!n || !r) return;
						let u = function(e) {
							if (typeof e == "string") {
								let t = e;
								return t.toLowerCase() == "flat" ? i.FLAT : t.toLowerCase() == "round" ? i.ROUND : i.NONE;
							}
							return e;
						};
						c = u(c), l = u(l);
						var d = l || c;
						s ||= {
							r: 0,
							g: 0,
							b: 0
						};
						var f = t(r.x - n.x, r.y - n.y, r.z - n.z), p = a.getVerticesForRadius(o, l, "to"), m = p.w, h = p.h, g = d ? h * m + 2 : 2 * m, _ = e.updateGeoGroup(g), v = p.vertices, y = p.normals, b = p.verticesRows, x = b[h / 2], S = b[h / 2 + 1], C = _.vertices, w, T, E, D, O, k, A = _.vertexArray, j = _.normalArray, M = _.colorArray, N = _.faceArray;
						for (E = 0; E < m; ++E) {
							var P = 2 * E;
							D = f[0] * v[P].x + f[3] * v[P].y + f[6] * v[P].z, O = f[1] * v[P].x + f[4] * v[P].y + f[7] * v[P].z, k = f[5] * v[P].y + f[8] * v[P].z, w = 3 * (C + P), T = _.faceidx, A[w] = D + n.x, A[w + 1] = O + n.y, A[w + 2] = k + n.z, A[w + 3] = D + r.x, A[w + 4] = O + r.y, A[w + 5] = k + r.z, j[w] = D, j[w + 3] = D, j[w + 1] = O, j[w + 4] = O, j[w + 2] = k, j[w + 5] = k, M[w] = s.r, M[w + 3] = s.r, M[w + 1] = s.g, M[w + 4] = s.g, M[w + 2] = s.b, M[w + 5] = s.b, N[T] = S[E] + C, N[T + 1] = S[E + 1] + C, N[T + 2] = x[E] + C, N[T + 3] = x[E] + C, N[T + 4] = S[E + 1] + C, N[T + 5] = x[E + 1] + C, _.faceidx += 6;
						}
						if (d) {
							var F = l ? 0 : h / 2, I = c ? h + 1 : h / 2 + 1, L, R, z, B, V, H, U, W, G, ee, te, ne, re, ie, K, ae, oe, q, J, Y, se, ce, X, le, Z, Q, ue, de, $, fe, pe, me;
							for (O = F; O < I; O++) if (O !== h / 2) {
								var he = O <= h / 2 ? r : n, ge = a.getVerticesForRadius(o, l, "to"), _e = a.getVerticesForRadius(o, c, "from");
								for (he === r ? (v = ge.vertices, y = ge.normals, b = ge.verticesRows) : he == n && (v = _e.vertices, y = _e.normals, b = _e.verticesRows), D = 0; D < m; D++) T = _.faceidx, L = b[O][D + 1], $ = (L + C) * 3, R = b[O][D], fe = (R + C) * 3, z = b[O + 1][D], pe = (z + C) * 3, B = b[O + 1][D + 1], me = (B + C) * 3, V = f[0] * v[L].x + f[3] * v[L].y + f[6] * v[L].z, H = f[0] * v[R].x + f[3] * v[R].y + f[6] * v[R].z, U = f[0] * v[z].x + f[3] * v[z].y + f[6] * v[z].z, W = f[0] * v[B].x + f[3] * v[B].y + f[6] * v[B].z, G = f[1] * v[L].x + f[4] * v[L].y + f[7] * v[L].z, ee = f[1] * v[R].x + f[4] * v[R].y + f[7] * v[R].z, te = f[1] * v[z].x + f[4] * v[z].y + f[7] * v[z].z, ne = f[1] * v[B].x + f[4] * v[B].y + f[7] * v[B].z, re = f[5] * v[L].y + f[8] * v[L].z, ie = f[5] * v[R].y + f[8] * v[R].z, K = f[5] * v[z].y + f[8] * v[z].z, ae = f[5] * v[B].y + f[8] * v[B].z, A[$] = V + he.x, A[fe] = H + he.x, A[pe] = U + he.x, A[me] = W + he.x, A[$ + 1] = G + he.y, A[fe + 1] = ee + he.y, A[pe + 1] = te + he.y, A[me + 1] = ne + he.y, A[$ + 2] = re + he.z, A[fe + 2] = ie + he.z, A[pe + 2] = K + he.z, A[me + 2] = ae + he.z, M[$] = s.r, M[fe] = s.r, M[pe] = s.r, M[me] = s.r, M[$ + 1] = s.g, M[fe + 1] = s.g, M[pe + 1] = s.g, M[me + 1] = s.g, M[$ + 2] = s.b, M[fe + 2] = s.b, M[pe + 2] = s.b, M[me + 2] = s.b, oe = f[0] * y[L].x + f[3] * y[L].y + f[6] * y[L].z, q = f[0] * y[R].x + f[3] * y[R].y + f[6] * y[R].z, J = f[0] * y[z].x + f[3] * y[z].y + f[6] * y[z].z, Y = f[0] * y[B].x + f[3] * y[B].y + f[6] * y[B].z, se = f[1] * y[L].x + f[4] * y[L].y + f[7] * y[L].z, ce = f[1] * y[R].x + f[4] * y[R].y + f[7] * y[R].z, X = f[1] * y[z].x + f[4] * y[z].y + f[7] * y[z].z, le = f[1] * y[B].x + f[4] * y[B].y + f[7] * y[B].z, Z = f[5] * y[L].y + f[8] * y[L].z, Q = f[5] * y[R].y + f[8] * y[R].z, ue = f[5] * y[z].y + f[8] * y[z].z, de = f[5] * y[B].y + f[8] * y[B].z, O === 0 ? (j[$] = oe, j[pe] = J, j[me] = Y, j[$ + 1] = se, j[pe + 1] = X, j[me + 1] = le, j[$ + 2] = Z, j[pe + 2] = ue, j[me + 2] = de, N[T] = L + C, N[T + 1] = z + C, N[T + 2] = B + C, _.faceidx += 3) : O === I - 1 ? (j[$] = oe, j[fe] = q, j[pe] = J, j[$ + 1] = se, j[fe + 1] = ce, j[pe + 1] = X, j[$ + 2] = Z, j[fe + 2] = Q, j[pe + 2] = ue, N[T] = L + C, N[T + 1] = R + C, N[T + 2] = z + C, _.faceidx += 3) : (j[$] = oe, j[fe] = q, j[me] = Y, j[$ + 1] = se, j[fe + 1] = ce, j[me + 1] = le, j[$ + 2] = Z, j[fe + 2] = Q, j[me + 2] = de, j[fe] = q, j[pe] = J, j[me] = Y, j[fe + 1] = ce, j[pe + 1] = X, j[me + 1] = le, j[fe + 2] = Q, j[pe + 2] = ue, j[me + 2] = de, N[T] = L + C, N[T + 1] = R + C, N[T + 2] = B + C, N[T + 3] = R + C, N[T + 4] = z + C, N[T + 5] = B + C, _.faceidx += 6);
							}
						}
						_.vertices += g;
					}
					e.drawCylinder = o;
					function s(e, n, i, o, s) {
						if (!n || !i) return;
						s ||= {
							r: 0,
							g: 0,
							b: 0
						};
						let c = new r.Vector3(i.x - n.x, i.y - n.y, i.z - n.z);
						var l = t(c.x, c.y, c.z);
						c = c.normalize();
						var u = a.basisVectors.length, d = a.basisVectors, f = u + 2, p = e.updateGeoGroup(f), m = p.vertices, h, g, _, v, y, b, x = p.vertexArray, S = p.normalArray, C = p.colorArray, w = p.faceArray;
						for (h = m * 3, x[h] = n.x, x[h + 1] = n.y, x[h + 2] = n.z, S[h] = -c.x, S[h + 1] = -c.y, S[h + 2] = -c.z, C[h] = s.r, C[h + 1] = s.g, C[h + 2] = s.b, x[h + 3] = i.x, x[h + 4] = i.y, x[h + 5] = i.z, S[h + 3] = c.x, S[h + 4] = c.y, S[h + 5] = c.z, C[h + 3] = s.r, C[h + 4] = s.g, C[h + 5] = s.b, h += 6, _ = 0; _ < u; ++_) {
							var T = d[_].clone();
							T.multiplyScalar(o), v = l[0] * T.x + l[3] * T.y + l[6] * T.z, y = l[1] * T.x + l[4] * T.y + l[7] * T.z, b = l[5] * T.y + l[8] * T.z, x[h] = v + n.x, x[h + 1] = y + n.y, x[h + 2] = b + n.z, S[h] = v, S[h + 1] = y, S[h + 2] = b, C[h] = s.r, C[h + 1] = s.g, C[h + 2] = s.b, h += 3;
						}
						for (p.vertices += u + 2, g = p.faceidx, _ = 0; _ < u; _++) {
							var E = m + 2 + _, D = m + 2 + (_ + 1) % u;
							w[g] = E, w[g + 1] = D, w[g + 2] = m, g += 3, w[g] = E, w[g + 1] = D, w[g + 2] = m + 1, g += 3;
						}
						p.faceidx += 6 * u;
					}
					e.drawCone = s;
					class c {
						constructor() {
							this.cache = /* @__PURE__ */ new Map();
						}
						getVerticesForRadius(e, t) {
							t ||= 2, this.cache.has(t) || this.cache.set(t, /* @__PURE__ */ new Map());
							let n = this.cache.get(t);
							if (n.has(e)) return n.get(e);
							var i = {
								vertices: [],
								verticesRows: [],
								normals: []
							}, a = 16 * t, o = 10 * t;
							e < 1 && (a = 10 * t, o = 8 * t);
							var s = 0, c = Math.PI * 2, l = 0, u = Math.PI, d, f;
							for (f = 0; f <= o; f++) {
								let t = [];
								for (d = 0; d <= a; d++) {
									let n = d / a, m = f / o, h = -e * Math.cos(s + n * c) * Math.sin(l + m * u), g = e * Math.cos(l + m * u), _ = e * Math.sin(s + n * c) * Math.sin(l + m * u);
									var p = new r.Vector3(h, g, _);
									p.normalize(), i.vertices.push({
										x: h,
										y: g,
										z: _
									}), i.normals.push(p), t.push(i.vertices.length - 1);
								}
								i.verticesRows.push(t);
							}
							return n.set(e, i), i;
						}
					}
					var l = new c();
					function u(e, t, n, r, i) {
						var a = l.getVerticesForRadius(n, i), o = a.vertices, s = a.normals, c = e.updateGeoGroup(o.length), u = c.vertices, d = c.vertexArray, f = c.colorArray, p = c.faceArray, m = c.lineArray, h = c.normalArray;
						for (let e = 0, n = o.length; e < n; ++e) {
							let n = 3 * (u + e), i = o[e];
							d[n] = i.x + t.x, d[n + 1] = i.y + t.y, d[n + 2] = i.z + t.z, f[n] = r.r, f[n + 1] = r.g, f[n + 2] = r.b;
						}
						c.vertices += o.length;
						let g = a.verticesRows, _ = g.length - 1;
						for (let e = 0; e < _; e++) {
							let t = g[e].length - 1;
							for (let r = 0; r < t; r++) {
								let t = c.faceidx, i = c.lineidx, a = g[e][r + 1] + u, l = a * 3, d = g[e][r] + u, f = d * 3, _ = g[e + 1][r] + u, v = _ * 3, y = g[e + 1][r + 1] + u, b = y * 3, x = s[a - u], S = s[d - u], C = s[_ - u], w = s[y - u];
								Math.abs(o[a - u].y) === n ? (h[l] = x.x, h[v] = C.x, h[b] = w.x, h[l + 1] = x.y, h[v + 1] = C.y, h[b + 1] = w.y, h[l + 2] = x.z, h[v + 2] = C.z, h[b + 2] = w.z, p[t] = a, p[t + 1] = _, p[t + 2] = y, m[i] = a, m[i + 1] = _, m[i + 2] = a, m[i + 3] = y, m[i + 4] = _, m[i + 5] = y, c.faceidx += 3, c.lineidx += 6) : Math.abs(o[_ - u].y) === n ? (h[l] = x.x, h[f] = S.x, h[v] = C.x, h[l + 1] = x.y, h[f + 1] = S.y, h[v + 1] = C.y, h[l + 2] = x.z, h[f + 2] = S.z, h[v + 2] = C.z, p[t] = a, p[t + 1] = d, p[t + 2] = _, m[i] = a, m[i + 1] = d, m[i + 2] = a, m[i + 3] = _, m[i + 4] = d, m[i + 5] = _, c.faceidx += 3, c.lineidx += 6) : (h[l] = x.x, h[f] = S.x, h[b] = w.x, h[l + 1] = x.y, h[f + 1] = S.y, h[b + 1] = w.y, h[l + 2] = x.z, h[f + 2] = S.z, h[b + 2] = w.z, h[f] = S.x, h[v] = C.x, h[b] = w.x, h[f + 1] = S.y, h[v + 1] = C.y, h[b + 1] = w.y, h[f + 2] = S.z, h[v + 2] = C.z, h[b + 2] = w.z, p[t] = a, p[t + 1] = d, p[t + 2] = y, p[t + 3] = d, p[t + 4] = _, p[t + 5] = y, m[i] = a, m[i + 1] = d, m[i + 2] = a, m[i + 3] = y, m[i + 4] = d, m[i + 5] = _, m[i + 6] = _, m[i + 7] = y, c.faceidx += 6, c.lineidx += 8);
							}
						}
					}
					e.drawSphere = u;
					function d(e, t, n, i, a, o, s = 16, c = 4) {
						let l = new r.Vector3(n.x, n.y, n.z), u = Math.sqrt(l.x * l.x + l.y * l.y + l.z * l.z);
						if (u < 1e-4) return;
						l.multiplyScalar(1 / u);
						let d = new r.Vector3(0, 1, 0);
						Math.abs(l.x * d.x + l.y * d.y + l.z * d.z) > .9 && (d = new r.Vector3(1, 0, 0));
						let f = new r.Vector3();
						f.crossVectors(l, d).normalize();
						let p = new r.Vector3();
						p.crossVectors(f, l).normalize();
						let m = (s + 1) * (c + 1), h = e.updateGeoGroup(m), g = h.vertices, _ = h.vertexArray, v = h.colorArray, y = h.normalArray, b = h.faceArray, x = h.lineArray;
						for (let e = 0; e <= s; e++) {
							let n = e / s * 2 * Math.PI, r = Math.cos(n), u = Math.sin(n), d = r * f.x + u * p.x, m = r * f.y + u * p.y, h = r * f.z + u * p.z, b = t.x + i * d, x = t.y + i * m, S = t.z + i * h;
							for (let t = 0; t <= c; t++) {
								let n = t / c * 2 * Math.PI, r = Math.cos(n), i = Math.sin(n), s = r * d + i * l.x, u = r * m + i * l.y, f = r * h + i * l.z, p = 3 * (g + (e * (c + 1) + t));
								_[p] = b + a * s, _[p + 1] = x + a * u, _[p + 2] = S + a * f, y[p] = s, y[p + 1] = u, y[p + 2] = f, v[p] = o.r, v[p + 1] = o.g, v[p + 2] = o.b;
							}
						}
						h.vertices += m;
						for (let e = 0; e < s; e++) for (let t = 0; t < c; t++) {
							let n = g + e * (c + 1) + t, r = g + e * (c + 1) + (t + 1), i = g + (e + 1) * (c + 1) + (t + 1), a = g + (e + 1) * (c + 1) + t, o = h.faceidx;
							b[o] = n, b[o + 1] = r, b[o + 2] = a, b[o + 3] = r, b[o + 4] = i, b[o + 5] = a, h.faceidx += 6;
							let s = h.lineidx;
							x[s] = n, x[s + 1] = r, x[s + 2] = n, x[s + 3] = a, x[s + 4] = r, x[s + 5] = i, x[s + 6] = i, x[s + 7] = a, h.lineidx += 8;
						}
					}
					e.drawTorus = d;
				})(a ||= {});
			},
			"./src/GLModel.ts"(e, t, n) {
				n.r(t), n.d(t, { GLModel: () => m });
				var r = n("./src/WebGL/index.ts"), i = n("./src/WebGL/shapes/index.ts"), a = n("./src/WebGL/math/index.ts"), o = n("./src/colors.ts"), s = n("./src/GLDraw.ts"), c = n("./src/glcartoon.ts"), l = n("./src/utilities.ts"), u = n("./src/Gradient.ts"), d = n("./src/parsers/index.ts"), f = n("./node_modules/netcdfjs/lib-esm/index.js"), p = n("./src/parsers/utils/assignBonds.ts");
				class m {
					static sameObj(e, t) {
						return e && t ? JSON.stringify(e) == JSON.stringify(t) : e == t;
					}
					constructor(e, t, n) {
						this.atoms = [], this.frames = [], this.box = null, this.atomdfs = null, this.id = 0, this.hidden = !1, this.molObj = null, this.renderedMolObj = null, this.lastColors = null, this.modelData = {}, this.modelDatas = null, this.idMatrix = new a.Matrix4(), this.dontDuplicateAtoms = !0, this.defaultColor = o.elementColors.defaultColor, this.defaultStickRadius = .25, this._drawnAromaticRings = /* @__PURE__ */ new Set(), this._ringCache = /* @__PURE__ */ new Map(), this.options = t || {}, this.viewer = n, this.ElementColors = this.options.defaultcolors ? this.options.defaultcolors : o.elementColors.defaultColors, this.defaultSphereRadius = this.options.defaultSphereRadius ? this.options.defaultSphereRadius : 1.5, this.defaultCartoonQuality = this.options.cartoonQuality ? this.options.cartoonQuality : 10, this.id = e;
					}
					getRadiusFromStyle(e, t) {
						var n = this.defaultSphereRadius;
						if (t.radius !== void 0) n = t.radius;
						else if (m.vdwRadii[e.elem]) n = m.vdwRadii[e.elem];
						else if (e.elem.length > 1) {
							let t = e.elem;
							t = t[0].toUpperCase() + t[1].toLowerCase(), m.vdwRadii[t] && (n = m.vdwRadii[t]);
						}
						return t.scale !== void 0 && (n *= t.scale), n;
					}
					drawAtomCross(e, t) {
						if (e.style.cross) {
							var n = e.style.cross;
							if (!n.hidden) {
								var i = n.linewidth || m.defaultlineWidth;
								t[i] || (t[i] = new r.Geometry());
								var o = t[i].updateGeoGroup(6), s = this.getRadiusFromStyle(e, n), c = [
									[
										s,
										0,
										0
									],
									[
										-s,
										0,
										0
									],
									[
										0,
										s,
										0
									],
									[
										0,
										-s,
										0
									],
									[
										0,
										0,
										s
									],
									[
										0,
										0,
										-s
									]
								], u = e.clickable || e.hoverable;
								u && e.intersectionShape === void 0 && (e.intersectionShape = {
									sphere: [],
									cylinder: [],
									line: []
								});
								for (var d = (0, l.getColorFromStyle)(e, n), f = o.vertexArray, p = o.colorArray, h = 0; h < 6; h++) {
									var g = o.vertices * 3;
									if (o.vertices++, f[g] = e.x + c[h][0], f[g + 1] = e.y + c[h][1], f[g + 2] = e.z + c[h][2], p[g] = d.r, p[g + 1] = d.g, p[g + 2] = d.b, u) {
										var _ = new a.Vector3(c[h][0], c[h][1], c[h][2]);
										_.multiplyScalar(.1), _.set(_.x + e.x, _.y + e.y, _.z + e.z), e.intersectionShape.line.push(_);
									}
								}
							}
						}
					}
					getGoodCross(e, t, n, r) {
						for (var i = null, o = -1, s = 0, c = e.bonds.length; s < c; s++) if (e.bonds[s] != t.index) {
							let t = e.bonds[s], c = this.atoms[t], u = new a.Vector3(c.x, c.y, c.z).clone();
							u.sub(n);
							let d = u.clone();
							d.cross(r);
							var l = d.lengthSq();
							if (l > o && (o = l, i = d, o > .1)) return i;
						}
						return i;
					}
					getSideBondV(e, t, n) {
						var r, i, o, s, c, l = new a.Vector3(e.x, e.y, e.z), u = new a.Vector3(t.x, t.y, t.z).clone(), d = null;
						if (u.sub(l), e.bonds.length === 1) {
							if (t.bonds.length === 1) d = u.clone(), Math.abs(d.x) > 1e-4 ? d.y += 1 : d.x += 1;
							else {
								for (o = null, r = 0; r < t.bonds.length; r++) if (i = t.bonds[r], i !== e.index) {
									o = this.atoms[i];
									break;
								}
								o ? (s = new a.Vector3(o.x, o.y, o.z), c = s.clone(), c.sub(l), d = c.clone(), d.cross(u)) : (d = u.clone(), d.x += 1);
							}
						} else if (d = this.getGoodCross(e, t, l, u), d.lengthSq() < .01) {
							var f = this.getGoodCross(t, e, l, u);
							f != null && (d = f);
						}
						d.lengthSq() < .01 && (d = u.clone(), Math.abs(d.x) > 1e-4 ? d.y += 1 : d.x += 1), d.cross(u), d.normalize();
						var p = .001;
						return Math.abs(d.x) > p ? d.x < 0 && d.negate() : Math.abs(d.y) > p ? d.y < 0 && d.negate() : d.z < 0 && d.negate(), d;
					}
					addLine(e, t, n, r, i, a) {
						e[n] = r.x, e[n + 1] = r.y, e[n + 2] = r.z, t[n] = a.r, t[n + 1] = a.g, t[n + 2] = a.b, e[n + 3] = i.x, e[n + 4] = i.y, e[n + 5] = i.z, t[n + 3] = a.r, t[n + 4] = a.g, t[n + 5] = a.b;
					}
					drawBondLines(e, t, n) {
						if (e.style.line) {
							var i = e.style.line;
							if (!i.hidden) {
								var s, c, u, d, f = i.linewidth || m.defaultlineWidth;
								n[f] || (n[f] = new r.Geometry());
								for (var p = n[f].updateGeoGroup(6 * e.bonds.length), h = p.vertexArray, g = p.colorArray, _ = 0; _ < e.bonds.length; _++) {
									var v = t[e.bonds[_]];
									if (v.style.line && !(e.index >= v.index)) {
										var y = new a.Vector3(e.x, e.y, e.z), b = new a.Vector3(v.x, v.y, v.z), x = y.clone().add(b).multiplyScalar(.5), S = !1, C = e.clickable || e.hoverable, w = v.clickable || v.hoverable;
										(C || w) && (C && (e.intersectionShape === void 0 && (e.intersectionShape = {
											sphere: [],
											cylinder: [],
											line: [],
											triangle: []
										}), e.intersectionShape.line.push(y), e.intersectionShape.line.push(x)), w && (v.intersectionShape === void 0 && (v.intersectionShape = {
											sphere: [],
											cylinder: [],
											line: [],
											triangle: []
										}), v.intersectionShape.line.push(x), v.intersectionShape.line.push(b)));
										var T = (0, l.getColorFromStyle)(e, e.style.line), E = (0, l.getColorFromStyle)(v, v.style.line);
										if (e.bondStyles && e.bondStyles[_]) {
											var D = e.bondStyles[_];
											if (!D.iswire) continue;
											D.singleBond && (S = !0), D.color1 !== void 0 && (T = o.CC.color(D.color1)), D.color2 !== void 0 && (E = o.CC.color(D.color2));
										}
										var O = p.vertices * 3, k, A;
										if (e.bondOrder[_] > 1 && e.bondOrder[_] < 4 && !S) {
											var j = this.getSideBondV(e, v, _), M = b.clone();
											M.sub(y), e.bondOrder[_] == 2 ? (j.multiplyScalar(.1), s = y.clone(), s.add(j), c = y.clone(), c.sub(j), u = s.clone(), u.add(M), d = c.clone(), d.add(M), T == E ? (p.vertices += 4, this.addLine(h, g, O, s, u, T), this.addLine(h, g, O + 6, c, d, T)) : (p.vertices += 8, M.multiplyScalar(.5), k = s.clone(), k.add(M), A = c.clone(), A.add(M), this.addLine(h, g, O, s, k, T), this.addLine(h, g, O + 6, k, u, E), this.addLine(h, g, O + 12, c, A, T), this.addLine(h, g, O + 18, A, d, E))) : e.bondOrder[_] == 3 && (j.multiplyScalar(.1), s = y.clone(), s.add(j), c = y.clone(), c.sub(j), u = s.clone(), u.add(M), d = c.clone(), d.add(M), T == E ? (p.vertices += 6, this.addLine(h, g, O, y, b, T), this.addLine(h, g, O + 6, s, u, T), this.addLine(h, g, O + 12, c, d, T)) : (p.vertices += 12, M.multiplyScalar(.5), k = s.clone(), k.add(M), A = c.clone(), A.add(M), this.addLine(h, g, O, y, x, T), this.addLine(h, g, O + 6, x, b, E), this.addLine(h, g, O + 12, s, k, T), this.addLine(h, g, O + 18, k, u, E), this.addLine(h, g, O + 24, c, A, T), this.addLine(h, g, O + 30, A, d, E)));
										} else T == E ? (p.vertices += 2, this.addLine(h, g, O, y, b, T)) : (p.vertices += 4, this.addLine(h, g, O, y, x, T), this.addLine(h, g, O + 6, x, b, E));
									}
								}
							}
						}
					}
					drawAtomSphere(e, t) {
						if (e.style.sphere) {
							var n = e.style.sphere;
							if (!n.hidden) {
								var r = (0, l.getColorFromStyle)(e, n), o = this.getRadiusFromStyle(e, n);
								if ((e.clickable === !0 || e.hoverable) && e.intersectionShape !== void 0) {
									var c = new a.Vector3(e.x, e.y, e.z);
									e.intersectionShape.sphere.push(new i.Sphere(c, o));
								}
								s.GLDraw.drawSphere(t, e, o, r);
							}
						}
					}
					drawAtomClickSphere(e) {
						if (e.style.clicksphere) {
							var t = e.style.clicksphere;
							if (!t.hidden) {
								var n = this.getRadiusFromStyle(e, t);
								if ((e.clickable === !0 || e.hoverable) && e.intersectionShape !== void 0) {
									var r = new a.Vector3(e.x, e.y, e.z);
									e.intersectionShape.sphere.push(new i.Sphere(r, n));
								}
							}
						}
					}
					drawAtomInstanced(e, t) {
						if (e.style.sphere) {
							var n = e.style.sphere;
							if (!n.hidden) {
								var r = this.getRadiusFromStyle(e, n), o = (0, l.getColorFromStyle)(e, n), s = t.updateGeoGroup(1), c = s.vertices, u = c * 3, d = s.vertexArray, f = s.colorArray, p = s.radiusArray;
								if (d[u] = e.x, d[u + 1] = e.y, d[u + 2] = e.z, f[u] = o.r, f[u + 1] = o.g, f[u + 2] = o.b, p[c] = r, (e.clickable === !0 || e.hoverable) && e.intersectionShape !== void 0) {
									var m = new a.Vector3(e.x, e.y, e.z);
									e.intersectionShape.sphere.push(new i.Sphere(m, r));
								}
								s.vertices += 1;
							}
						}
					}
					drawSphereImposter(e, t, n, r) {
						var i = e.updateGeoGroup(4), a, o = i.vertices, s = o * 3, c = i.vertexArray, l = i.colorArray;
						for (a = 0; a < 4; a++) c[s + 3 * a] = t.x, c[s + 3 * a + 1] = t.y, c[s + 3 * a + 2] = t.z;
						var u = i.normalArray;
						for (a = 0; a < 4; a++) l[s + 3 * a] = r.r, l[s + 3 * a + 1] = r.g, l[s + 3 * a + 2] = r.b;
						u[s + 0] = -n, u[s + 1] = n, u[s + 2] = 0, u[s + 3] = -n, u[s + 4] = -n, u[s + 5] = 0, u[s + 6] = n, u[s + 7] = -n, u[s + 8] = 0, u[s + 9] = n, u[s + 10] = n, u[s + 11] = 0, i.vertices += 4;
						var d = i.faceArray, f = i.faceidx;
						d[f + 0] = o, d[f + 1] = o + 1, d[f + 2] = o + 2, d[f + 3] = o + 2, d[f + 4] = o + 3, d[f + 5] = o, i.faceidx += 6;
					}
					drawAtomImposter(e, t) {
						if (e.style.sphere) {
							var n = e.style.sphere;
							if (!n.hidden) {
								var r = this.getRadiusFromStyle(e, n), o = (0, l.getColorFromStyle)(e, n);
								if ((e.clickable === !0 || e.hoverable) && e.intersectionShape !== void 0) {
									var s = new a.Vector3(e.x, e.y, e.z);
									e.intersectionShape.sphere.push(new i.Sphere(s, r));
								}
								this.drawSphereImposter(t, e, r, o);
							}
						}
					}
					drawRingImposter(e, t, n, r, i, a) {
						for (var o = e.updateGeoGroup(4), s = o.vertices, c = s * 3, l = o.vertexArray, u = o.colorArray, d = o.normalArray, f = o.radiusArray, p = r + i, m = 0; m < 4; m++) l[c + 3 * m] = t.x, l[c + 3 * m + 1] = t.y, l[c + 3 * m + 2] = t.z;
						for (var h = n.x * i, g = n.y * i, _ = n.z * i, m = 0; m < 4; m++) d[c + 3 * m] = h, d[c + 3 * m + 1] = g, d[c + 3 * m + 2] = _;
						var v = Math.abs(a.b);
						v < 1e-4 && (v = 1e-4), u[c + 0] = a.r, u[c + 1] = a.g, u[c + 2] = v, u[c + 3] = a.r, u[c + 4] = a.g, u[c + 5] = -v, u[c + 6] = a.r, u[c + 7] = a.g, u[c + 8] = -v, u[c + 9] = a.r, u[c + 10] = a.g, u[c + 11] = v, f[s + 0] = -p, f[s + 1] = -p, f[s + 2] = p, f[s + 3] = p, o.vertices += 4;
						var y = o.faceArray, b = o.faceidx;
						y[b + 0] = s, y[b + 1] = s + 1, y[b + 2] = s + 2, y[b + 3] = s + 2, y[b + 4] = s + 3, y[b + 5] = s, o.faceidx += 6;
					}
					calculateDashes(e, t, n, r, i, o) {
						var s, c, l;
						let u = t.x - e.x, d = t.y - e.y, f = t.z - e.z, p = Math.sqrt(u * u + d * d + f * f);
						if (p < .001) return [{
							from: new a.Vector3(e.x, e.y, e.z),
							to: new a.Vector3(t.x, t.y, t.z),
							color: o?.[0] ?? null
						}];
						n = Math.max(n, 0), r = Math.max(r, .001);
						let m = Math.max(i, 0) + 2 * n, h = m / 2, g = p - 2 * h;
						if (g < r) return [{
							from: new a.Vector3(e.x, e.y, e.z),
							to: new a.Vector3(t.x, t.y, t.z),
							color: o?.[0] ?? null
						}];
						let _ = Math.floor((g - r) / (r + m)) + 1, v = _ * r, y = _ > 1 ? _ - 1 : 0, b = g - v, x = y > 0 ? b / (y + 1) : b, S = x / 2, C = u / p, w = d / p, T = f / p, E = [], D = h + S;
						for (let t = 0; t < _; t++) {
							let n = D + t * (r + x), i = n + r, s = new a.Vector3(e.x + C * n, e.y + w * n, e.z + T * n), c = new a.Vector3(e.x + C * i, e.y + w * i, e.z + T * i), l = o && o.length > 1 && t >= _ / 2 ? o[1] : o?.[0] ?? null;
							E.push({
								from: s,
								to: c,
								color: l
							});
						}
						return E;
					}
					calculateTwoColorSegments(e, t, n) {
						let r = [];
						if (n.length <= 1) r.push({
							from: new a.Vector3(e.x, e.y, e.z),
							to: new a.Vector3(t.x, t.y, t.z),
							color: n[0]
						});
						else {
							let i = new a.Vector3((e.x + t.x) / 2, (e.y + t.y) / 2, (e.z + t.z) / 2);
							r.push({
								from: new a.Vector3(e.x, e.y, e.z),
								to: i,
								color: n[0]
							}), r.push({
								from: i,
								to: new a.Vector3(t.x, t.y, t.z),
								color: n[1]
							});
						}
						return r;
					}
					findSmallestRing(e, t, n = 8) {
						let r = e < t ? e : t, i = e < t ? t : e, a = r + "," + i;
						if (this._ringCache.has(a)) return this._ringCache.get(a);
						let o = [[e]], s = /* @__PURE__ */ new Set([e]);
						for (; o.length > 0;) {
							let r = o.shift(), i = r[r.length - 1];
							if (r.length >= n) continue;
							let c = this.atoms[i];
							if (!(!c || !c.bonds)) for (let n = 0; n < c.bonds.length; n++) {
								let l = c.bonds[n];
								if ((i !== e || l !== t) && (i !== t || l !== e)) {
									if (l === t && r.length >= 2) {
										let e = [...r, t];
										return this._ringCache.set(a, e), e;
									}
									s.has(l) || (s.add(l), o.push([...r, l]));
								}
							}
						}
						return this._ringCache.set(a, null), null;
					}
					chooseDashedSide(e, t, n, r, i) {
						let o = this.findSmallestRing(e.index, t.index);
						if (o && o.length >= 3) {
							let e = new a.Vector3(0, 0, 0);
							for (let t = 0; t < o.length; t++) {
								let n = this.atoms[o[t]];
								e.x += n.x, e.y += n.y, e.z += n.z;
							}
							e.multiplyScalar(1 / o.length);
							let t = new a.Vector3().addVectors(n, r).multiplyScalar(.5), s = new a.Vector3(e.x - t.x, e.y - t.y, e.z - t.z), c = i.x * s.x + i.y * s.y + i.z * s.z, l = Math.sqrt(i.x * i.x + i.y * i.y + i.z * i.z), u = Math.sqrt(s.x * s.x + s.y * s.y + s.z * s.z);
							if (u >= .001 && Math.abs(c) >= .05 * l * u) return c > 0;
						}
						return this.chooseDashedPlusV(e, t, n, r, i);
					}
					chooseDashedPlusV(e, t, n, r, i) {
						let o = new a.Vector3(0, 0, 0), s = 0;
						for (let n = 0; n < e.bonds.length; n++) {
							if (e.bonds[n] === t.index) continue;
							let r = this.atoms[e.bonds[n]];
							r && (o.x += r.x, o.y += r.y, o.z += r.z, s++);
						}
						for (let n = 0; n < t.bonds.length; n++) {
							if (t.bonds[n] === e.index) continue;
							let r = this.atoms[t.bonds[n]];
							r && (o.x += r.x, o.y += r.y, o.z += r.z, s++);
						}
						if (s === 0) return !1;
						o.multiplyScalar(1 / s);
						let c = new a.Vector3().addVectors(n, r).multiplyScalar(.5), l = new a.Vector3(o.x - c.x, o.y - c.y, o.z - c.z), u = i.x * l.x + i.y * l.y + i.z * l.z, d = Math.sqrt(i.x * i.x + i.y * i.y + i.z * i.z), f = Math.sqrt(l.x * l.x + l.y * l.y + l.z * l.z);
						return f < .001 || Math.abs(u) < .1 * d * f ? !1 : u > 0;
					}
					drawAromaticRingTorus(e, t, n, r, i) {
						var o;
						let c = this.findSmallestRing(e.index, t.index);
						if (!c || c.length < 3) return;
						let l = c.slice().sort((e, t) => e - t).join(",");
						if (this._drawnAromaticRings.has(l)) return;
						this._drawnAromaticRings.add(l);
						let u = new a.Vector3(0, 0, 0);
						for (let e = 0; e < c.length; e++) {
							let t = this.atoms[c[e]];
							u.x += t.x, u.y += t.y, u.z += t.z;
						}
						u.multiplyScalar(1 / c.length);
						let d = new a.Vector3(0, 0, 0);
						for (let e = 0; e < c.length; e++) {
							let t = this.atoms[c[e]], n = this.atoms[c[(e + 1) % c.length]];
							d.x += (t.y - n.y) * (t.z + n.z), d.y += (t.z - n.z) * (t.x + n.x), d.z += (t.x - n.x) * (t.y + n.y);
						}
						let f = Math.sqrt(d.x * d.x + d.y * d.y + d.z * d.z);
						if (f < 1e-4) return;
						d.multiplyScalar(1 / f);
						let p = 0, m = 0;
						for (let e = 0; e < c.length; e++) {
							let t = this.atoms[c[e]], n = t.x - u.x, r = t.y - u.y, i = t.z - u.z;
							if (p += Math.sqrt(n * n + r * r + i * i), t.style?.sphere && !t.style.sphere.hidden && t.style.sphere.radius) {
								let e = this.getRadiusFromStyle(t, t.style.sphere);
								e > m && (m = e);
							}
						}
						p /= c.length;
						let h = r * .5, g = p * Math.cos(Math.PI / c.length) - h - 2 * r, _ = p - h - m - r, v = Math.max(h, Math.min(g, _));
						n.imposter ? this.drawRingImposter(n, u, d, v, h, i) : s.GLDraw.drawTorus(n, u, d, v, h, i);
					}
					static drawStickImposter(e, t, n, r, i, a = 0, o = 0) {
						for (var s = e.updateGeoGroup(4), c = s.vertices, l = c * 3, u = s.vertexArray, d = s.colorArray, f = s.radiusArray, p = s.normalArray, m = i.r, h = i.g, g = i.b, _ = function(e) {
							var t = -e;
							return t == 0 && (t = -1e-4), t;
						}, v = l, y = 0; y < 4; y++) u[v] = t.x, p[v] = n.x, d[v] = m, v++, u[v] = t.y, p[v] = n.y, d[v] = h, v++, u[v] = t.z, p[v] = n.z, y < 2 ? d[v] = g : d[v] = _(g), v++;
						s.vertices += 4, f[c] = -r, f[c + 1] = r, f[c + 2] = -r, f[c + 3] = r;
						var b = s.faceArray, x = s.faceidx;
						b[x + 0] = c, b[x + 1] = c + 1, b[x + 2] = c + 2, b[x + 3] = c + 2, b[x + 4] = c + 3, b[x + 5] = c, s.faceidx += 6;
					}
					drawBondSticks(e, t, n, r) {
						var c, u, d, f, p, h, g, _, v, y;
						if (!e.style.stick) return;
						var b = e.style.stick;
						if (b.hidden) return;
						var x = b.radius || this.defaultStickRadius, S = b.doubleBondScaling || .4, C = b.tripleBondScaling || .25;
						let w = b.dashedBondConfig?.dashLength || .1, T = b.dashedBondConfig?.gapLength || .25, E = b.aromaticStyle || "dashed";
						var D = x, O = b.singleBonds || !1, k = b.dashedBonds || !1, A = 0, j = 0, M, N, P, F, I, L, R, z, B, V, H = (0, l.getColorFromStyle)(e, b), U, W, G;
						!e.capDrawn && e.bonds.length < 4 && (A = 2);
						let ee = b.dashedBondConfig?.solidColor ? o.CC.color(b.dashedBondConfig.solidColor) : null, te = b.dashedBondConfig?.dashedColor ? o.CC.color(b.dashedBondConfig.dashedColor) : null, ne = (e) => {
							let t = n.imposter ? m.drawStickImposter : s.GLDraw.drawCylinder;
							return !k && e % 1 == 0 ? (e, n, r, i, a, o, s = 0, c = 0) => {
								if (!o || a === o) t(e, n, r, i, a, s, c);
								else {
									let l = this.calculateTwoColorSegments(n, r, [a, o]);
									for (let n = 0; n < l.length; n++) {
										let r = l[n], a = n === 0 ? s : 0, o = n === l.length - 1 ? c : 0;
										t(e, r.from, r.to, i, r.color, a, o);
									}
								}
							} : (e, n, r, i, a, o, s = 0, c = 0) => {
								let l = o ? [a, o] : [a];
								this.calculateDashes(n, r, i, w, T, l).forEach((n) => {
									t(e, n.from, n.to, i, n.color, s, c);
								});
							};
						};
						for (P = 0; P < e.bonds.length; P++) {
							let c = e.bondOrder[P], u = c === 4, d;
							d = u ? E === "circle" ? 1 : 1.5 : c;
							let f = ne(d), p = t[e.bonds[P]];
							if (U = W = G = null, e.index < p.index) {
								j = 0;
								let t = p.style;
								if (!t.stick || t.stick.hidden) continue;
								let c = H, h = (0, l.getColorFromStyle)(p, t.stick);
								D = x, F = O;
								let g = e.bondStyles?.[P];
								if (g) {
									if (g.iswire) continue;
									g.radius && (D = g.radius), g.singleBond && (F = !0), g.color1 !== void 0 && (c = o.CC.color(g.color1)), g.color2 !== void 0 && (h = o.CC.color(g.color2));
								}
								let _ = new a.Vector3(e.x, e.y, e.z), v = new a.Vector3(p.x, p.y, p.z), y = g?.dashedBondConfig?.solidColor ? o.CC.color(g.dashedBondConfig.solidColor) : null, b = g?.dashedBondConfig?.dashedColor ? o.CC.color(g.dashedBondConfig.dashedColor) : null, k = g && (g.color1 !== void 0 || g.color2 !== void 0), ne = y || (k ? c : ee || c), J = y || (k ? h : ee || h), Y = b || (k ? c : te || c), se = b || (k ? h : te || h), ce = g?.dashedBondConfig?.dashLength || w, X = g?.dashedBondConfig?.gapLength || T;
								if (d <= 1 || F || d > 3) {
									d < 1 && (D *= d), !p.capDrawn && p.bonds.length < 4 && (j = 2);
									let t = d % 1 != 0;
									if (f(n, _, v, D, t ? Y : c, t ? se : h, A, j), M = e.clickable || e.hoverable, N = p.clickable || p.hoverable, M || N) {
										if (U ||= new a.Vector3().addVectors(_, v).multiplyScalar(.5), M) {
											var re = new i.Cylinder(_, U, D), ie = new i.Sphere(_, D);
											e.intersectionShape.cylinder.push(re), e.intersectionShape.sphere.push(ie);
										}
										if (N) {
											var K = new i.Cylinder(v, U, D), ae = new i.Sphere(v, D);
											p.intersectionShape.cylinder.push(K), p.intersectionShape.sphere.push(ae);
										}
									}
									if (u && E === "circle") {
										let t = b || te || c;
										this.drawAromaticRingTorus(e, p, r, D, t);
									}
								} else if (d > 1) {
									var oe = 0, q = 0;
									D != x && (oe = 2, q = 2);
									let t = v.clone();
									t.sub(_);
									let r, o, l, u, f, y, b = this.getSideBondV(e, p, P), w = !1;
									d % 1 != 0 && (w = g?.dashedBondFlip == null ? this.chooseDashedSide(e, p, _, v, b) : g.dashedBondFlip);
									let T = n.imposter ? m.drawStickImposter : s.GLDraw.drawCylinder, E = (e, t, r, i, o, s, c) => {
										if (i != o) {
											let l = new a.Vector3().addVectors(e, t).multiplyScalar(.5);
											T(n, e, l, r, i, s, 0), T(n, l, t, r, o, 0, c);
										} else T(n, e, t, r, i, s, c);
									}, O = (e, t, r, i, a, o, s) => {
										let c = i == a ? [i] : [i, a];
										this.calculateDashes(e, t, r, ce, X, c).forEach((e) => {
											T(n, e.from, e.to, r, e.color || i, o, s);
										});
									};
									if (d > 1 && d <= 2) {
										if (r = D * S, o = r * (d - 1), b.multiplyScalar(r * 1.5), l = _.clone(), l.add(b), u = _.clone(), u.sub(b), f = l.clone(), f.add(t), y = u.clone(), y.add(t), d === 2 ? (E(l, f, r, c, h, oe, q), E(u, y, r, c, h, oe, q)) : w ? (O(l, f, o, Y, se, oe, q), E(u, y, r, ne, J, oe, q)) : (E(l, f, r, ne, J, oe, q), O(u, y, o, Y, se, oe, q)), M = e.clickable || e.hoverable, N = p.clickable || p.hoverable, M || N) {
											U ||= new a.Vector3().addVectors(l, f).multiplyScalar(.5), W ||= new a.Vector3().addVectors(u, y).multiplyScalar(.5);
											let t = d === 2 ? r : w ? o : r, n = d === 2 || w ? r : o;
											M && (I = new i.Cylinder(l, U, t), L = new i.Cylinder(u, W, n), e.intersectionShape.cylinder.push(I), e.intersectionShape.cylinder.push(L)), N && (z = new i.Cylinder(f, U, t), B = new i.Cylinder(y, W, n), p.intersectionShape.cylinder.push(z), p.intersectionShape.cylinder.push(B));
										}
									} else if (d > 2 && d <= 3) {
										r = D * C;
										let n = r * (d - 2);
										if (b.cross(t), b.normalize(), b.multiplyScalar(r * 3), l = _.clone(), l.add(b), u = _.clone(), u.sub(b), f = l.clone(), f.add(t), y = u.clone(), y.add(t), d === 3 ? (E(l, f, r, c, h, oe, q), E(_, v, r, c, h, A, j), E(u, y, r, c, h, oe, q)) : w ? (O(l, f, n, Y, se, oe, q), E(_, v, r, ne, J, A, j), E(u, y, r, ne, J, oe, q)) : (E(l, f, r, ne, J, oe, q), E(_, v, r, ne, J, A, j), O(u, y, n, Y, se, oe, q)), M = e.clickable || e.hoverable, N = p.clickable || p.hoverable, M || N) {
											U ||= new a.Vector3().addVectors(l, f).multiplyScalar(.5), W ||= new a.Vector3().addVectors(u, y).multiplyScalar(.5), G ||= new a.Vector3().addVectors(_, v).multiplyScalar(.5);
											let t = d === 3 ? r : w ? n : r, o = d === 3 || w ? r : n;
											M && (I = new i.Cylinder(l.clone(), U.clone(), t), L = new i.Cylinder(u.clone(), W.clone(), o), R = new i.Cylinder(_.clone(), G.clone(), r), e.intersectionShape.cylinder.push(I), e.intersectionShape.cylinder.push(L), e.intersectionShape.cylinder.push(R)), N && (z = new i.Cylinder(f.clone(), U.clone(), t), B = new i.Cylinder(y.clone(), W.clone(), o), V = new i.Cylinder(v.clone(), G.clone(), r), p.intersectionShape.cylinder.push(z), p.intersectionShape.cylinder.push(B), p.intersectionShape.cylinder.push(V));
										}
									}
								}
							}
						}
						var J = !1, Y = 0, se = !1;
						for (P = 0; P < e.bonds.length; P++) {
							F = O;
							var ce = e.bondStyles?.[P];
							ce && (ce.singleBond && (F = !0), ce.radius && ce.radius != x && (se = !0)), (F || e.bondOrder[P] == 1) && Y++;
						}
						se ? Y > 0 && (J = !0) : Y == 0 && (e.bonds.length > 0 || b.showNonBonded) && (J = !0), J && (D = x, n.imposter ? this.drawSphereImposter(n.sphereGeometry, e, D, H) : s.GLDraw.drawSphere(n, e, D, H));
					}
					createMolObj(e, t) {
						t ||= {}, this._drawnAromaticRings = /* @__PURE__ */ new Set(), this._ringCache = /* @__PURE__ */ new Map();
						var n = new r.Object3D(), i = [], a = {}, l = {}, u = this.drawAtomSphere, d = null, f = null, p = null;
						t.supportsImposters ? (p = new r.Geometry(!0), p.imposter = !0, p.radii = !0, u = this.drawAtomImposter, d = new r.Geometry(!0), d.imposter = !0, f = new r.Geometry(!0, !0), f.imposter = !0, f.sphereGeometry = new r.Geometry(!0), f.sphereGeometry.imposter = !0, f.drawnCaps = {}) : t.supportsAIA ? (p = new r.Geometry(!0), u = this.drawAtomInstanced, d = new r.Geometry(!1, !0, !0), d.instanced = !0, f = new r.Geometry(!0)) : (p = new r.Geometry(!0), d = new r.Geometry(!0), f = new r.Geometry(!0));
						var m, h, g, _, v = {}, y = [Infinity, -Infinity];
						for (m = 0, g = e.length; m < g; m++) {
							var b = e[m];
							if (b && b.style) {
								for (h in (b.clickable || b.hoverable) && b.intersectionShape === void 0 && (b.intersectionShape = {
									sphere: [],
									cylinder: [],
									line: [],
									triangle: []
								}), _ = {
									line: void 0,
									cross: void 0,
									stick: void 0,
									sphere: void 0
								}, _) b.style[h] ? b.style[h].opacity ? _[h] = parseFloat(b.style[h].opacity) : _[h] = 1 : _[h] = void 0, v[h] ? _[h] != null && v[h] != _[h] && (console.log("Warning: " + h + " opacity is ambiguous"), v[h] = 1) : v[h] = _[h];
								u.call(this, b, d), this.drawAtomClickSphere(b), this.drawAtomCross(b, l), this.drawBondLines(b, e, a), this.drawBondSticks(b, e, f, p), b.style.cartoon !== void 0 && !b.style.cartoon.hidden && (b.style.cartoon.color === "spectrum" && typeof b.resi == "number" && !b.hetflag && (b.resi < y[0] && (y[0] = b.resi), b.resi > y[1] && (y[1] = b.resi)), i.push(b));
							}
						}
						if (i.length > 0 && (0, c.drawCartoon)(n, i, y, this.defaultCartoonQuality), d && d.vertices > 0) {
							d.initTypedArrays();
							var x = null, S = null;
							d.imposter ? x = new r.SphereImposterMaterial({
								ambient: 0,
								vertexColors: !0,
								reflectivity: 0
							}) : d.instanced ? (S = new r.Geometry(!0), s.GLDraw.drawSphere(S, {
								x: 0,
								y: 0,
								z: 0
							}, 1, new o.Color(.5, .5, .5)), S.initTypedArrays(), x = new r.InstancedMaterial({
								sphereMaterial: new r.MeshLambertMaterial({
									ambient: 0,
									vertexColors: !0,
									reflectivity: 0
								}),
								sphere: S
							})) : x = new r.MeshLambertMaterial({
								ambient: 0,
								vertexColors: !0,
								reflectivity: 0
							}), v.sphere < 1 && v.sphere >= 0 && (x.transparent = !0, x.opacity = v.sphere), S = new r.Mesh(d, x), n.add(S);
						}
						if (f.vertices > 0) {
							var C = null, w = null, T = f.sphereGeometry;
							(!T || T.vertices === void 0 || T.vertices == 0) && (T = null), f.initTypedArrays(), T && T.initTypedArrays();
							var E = {
								ambient: 0,
								vertexColors: !0,
								reflectivity: 0
							};
							f.imposter ? (C = new r.StickImposterMaterial(E), w = new r.SphereImposterMaterial(E)) : (C = new r.MeshLambertMaterial(E), w = new r.MeshLambertMaterial(E), C.wireframe && (f.setUpWireframe(), T && T.setUpWireframe())), v.stick < 1 && v.stick >= 0 && (C.transparent = !0, C.opacity = v.stick, w.transparent = !0, w.opacity = v.stick);
							var D = new r.Mesh(f, C);
							if (n.add(D), T) {
								var O = new r.Mesh(T, w);
								n.add(O);
							}
						}
						if (p.vertices > 0) {
							p.initTypedArrays();
							var k = p.imposter ? new r.RingImposterMaterial({
								ambient: 0,
								vertexColors: !0,
								reflectivity: 0
							}) : new r.MeshLambertMaterial({
								ambient: 0,
								vertexColors: !0,
								reflectivity: 0
							});
							v.stick < 1 && v.stick >= 0 && (k.transparent = !0, k.opacity = v.stick), n.add(new r.Mesh(p, k));
						}
						var A;
						for (m in a) if (a.hasOwnProperty(m)) {
							A = m;
							var j = new r.LineBasicMaterial({
								linewidth: A,
								vertexColors: !0
							});
							v.line < 1 && v.line >= 0 && (j.transparent = !0, j.opacity = v.line), a[m].initTypedArrays();
							var M = new r.Line(a[m], j, r.LineStyle.LinePieces);
							n.add(M);
						}
						for (m in l) if (l.hasOwnProperty(m)) {
							A = m;
							var N = new r.LineBasicMaterial({
								linewidth: A,
								vertexColors: !0
							});
							v.cross < 1 && v.cross >= 0 && (N.transparent = !0, N.opacity = v.cross), l[m].initTypedArrays();
							var P = new r.Line(l[m], N, r.LineStyle.LinePieces);
							n.add(P);
						}
						if (this.dontDuplicateAtoms && this.modelData.symmetries && this.modelData.symmetries.length > 0) {
							var F = new r.Object3D(), I;
							for (I = 0; I < this.modelData.symmetries.length; I++) {
								var L = new r.Object3D();
								L = n.clone(), L.matrix.copy(this.modelData.symmetries[I]), L.matrixAutoUpdate = !1, F.add(L);
							}
							return F;
						}
						return n;
					}
					getViewer() {
						return this.viewer;
					}
					getInternalState() {
						return {
							atoms: this.atoms,
							frames: this.frames
						};
					}
					setInternalState(e) {
						this.atoms = e.atoms, this.frames = e.frames, this.molObj = null;
					}
					getCrystData() {
						if (this.modelData.cryst) {
							if (!this.modelData.cryst.matrix) {
								let e = this.modelData.cryst;
								this.modelData.cryst.matrix = (0, a.conversionMatrix3)(e.a, e.b, e.c, e.alpha, e.beta, e.gamma);
							}
							return this.modelData.cryst;
						}
						return null;
					}
					setCrystData(e, t, n, r, i, o) {
						e ||= 1, t ||= 1, n ||= 1, r ||= 90, i ||= 90, o ||= 90;
						let s = (0, a.conversionMatrix3)(e, t, n, r, i, o);
						this.modelData.cryst = {
							a: e,
							b: t,
							c: n,
							alpha: r,
							beta: i,
							gamma: o,
							matrix: s
						};
					}
					setCrystMatrix(e) {
						e ||= new a.Matrix3(1, 0, 0, 0, 1, 0, 0, 0, 1), this.modelData.cryst = { matrix: e };
					}
					getSymmetries() {
						return this.modelData.symmetries === void 0 && (this.modelData.symmetries = [this.idMatrix]), this.modelData.symmetries;
					}
					setSymmetries(e) {
						e === void 0 ? this.modelData.symmetries = [this.idMatrix] : (this.modelData.symmetries = e, this.molObj = null);
					}
					getID() {
						return this.id;
					}
					getNumFrames() {
						return this.frames.numFrames == null ? this.frames.length : this.frames.numFrames;
					}
					adjustCoord(e, t, n, r) {
						var i = t - e;
						return i < -n ? t + r : i > n ? t - r : t;
					}
					adjustCoordinatesToBox() {
						if (this.box && this.atomdfs) for (var e = this.box[0], t = this.box[1], n = this.box[2], r = e * .9, i = t * .9, a = n * .9, o = 0; o < this.atomdfs.length; o++) for (var s = this.atomdfs[o], c = 1; c < s.length; c++) {
							var l = this.atoms[s[c][0]], u = this.atoms[s[c][1]];
							l.x = this.adjustCoord(u.x, l.x, r, e), l.y = this.adjustCoord(u.y, l.y, i, t), l.z = this.adjustCoord(u.z, l.z, a, n);
						}
					}
					setFrame(e) {
						var t = this.getNumFrames();
						let n = this, r = this.viewer;
						return new Promise(function(i, a) {
							if (t == 0 && i(), (e < 0 || e >= t) && (e = t - 1), n.frames.url != null) {
								var o = n.frames.url;
								(0, l.getbin)(o + "/traj/frame/" + e + "/" + n.frames.path, void 0, "POST", void 0).then(function(e) {
									for (var t = new Float32Array(e, 44), r = 0, a = 0; a < n.atoms.length; a++) n.atoms[a].x = t[r++], n.atoms[a].y = t[r++], n.atoms[a].z = t[r++];
									n.box && n.atomdfs && n.adjustCoordinatesToBox(), i();
								}).catch(a);
							} else n.atoms = n.frames[e], i();
							n.molObj = null, n.modelDatas && e < n.modelDatas.length && (n.modelData = n.modelDatas[e] || {}, n.unitCellObjects && r && (r.removeUnitCell(n), r.addUnitCell(n)));
						});
					}
					addFrame(e) {
						this.frames.push(e);
					}
					vibrate(e = 10, t = 1, n = !1, r) {
						var i = 0, o = e;
						let s = this.viewer;
						n && (i = -e, o = e), this.frames !== void 0 && this.frames.origIndex !== void 0 ? this.setFrame(this.frames.origIndex) : this.setFrame(0), i < o && (this.frames = []), n && (this.frames.origIndex = e);
						for (var c = i; c < o; c++) {
							var u = [], d = this.frames.length;
							if (c == 0 && !r) {
								this.frames.push(this.atoms);
								continue;
							}
							for (var f = 0; f < this.atoms.length; f++) {
								var p = (0, l.getAtomProperty)(this.atoms[f], "dx"), m = (0, l.getAtomProperty)(this.atoms[f], "dy"), h = (0, l.getAtomProperty)(this.atoms[f], "dz"), g = new a.Vector3(p, m, h), _ = new a.Vector3(this.atoms[f].x, this.atoms[f].y, this.atoms[f].z), v = c * t / e;
								g.multiplyScalar(v), _.add(g);
								var y = {};
								for (var b in this.atoms[f]) y[b] = this.atoms[f][b];
								if (y.x = _.x, y.y = _.y, y.z = _.z, u.push(y), s && r) {
									var x = (0, l.extend)({}, r), S = new a.Vector3(p, m, h);
									if (S.multiplyScalar(t), S.add(_), x.start = _, x.end = S, x.frame = d, !x.color) {
										var C = y.style.sphere;
										C ||= y.style.stick, C ||= y.style.line, x.color = (0, l.getColorFromStyle)(y, C);
									}
									s.addArrow(x);
								}
							}
							this.frames.push(u);
						}
					}
					setAtomDefaults(e) {
						for (let t = 0; t < e.length; t++) {
							let n = e[t];
							n && (n.style = n.style || (0, l.deepCopy)(m.defaultAtomStyle), n.color = n.color || this.ElementColors[n.elem] || this.defaultColor, n.model = this.id, (n.clickable || n.hoverable) && (n.intersectionShape = {
								sphere: [],
								cylinder: [],
								line: [],
								triangle: []
							}));
						}
					}
					addMolData(e, t, n = {}) {
						var r, i = m.parseMolData(e, t, n);
						this.dontDuplicateAtoms = !n.duplicateAssemblyAtoms;
						var a = i.modelData;
						if (a && (Array.isArray(a) ? (this.modelData = a[0] || {}, this.modelDatas = a) : this.modelData = a), this.box = i.box ? i.box : null, this.frames.length == 0) {
							let e = this.modelDatas ? [] : null;
							for (let t = 0; t < i.length; t++) i[t].length != 0 && (this.frames.push(i[t]), e && e.push(this.modelDatas[t] || null));
							e && (this.modelDatas = e, e[0] && (this.modelData = e[0])), this.frames[0] && (this.atoms = this.frames[0]);
						} else if (n.frames) for (let e = 0; e < i.length; e++) this.frames.push(i[e]);
						else for (var o = 0; o < i.length; o++) this.addAtoms(i[o]);
						for (let e = 0; e < this.frames.length; e++) this.setAtomDefaults(this.frames[e]);
						if (n.vibrate && n.vibrate.frames && n.vibrate.amplitude && this.vibrate(n.vibrate.frames, n.vibrate.amplitude), this.modelDatas) for (let e = 0; e < this.modelDatas.length; e++) this.modelDatas[e]?.style && this.setStyle({ frame: e }, this.modelDatas[e].style, !0);
						else a && a.style && this.setStyle({}, a.style, !0);
						n.style && this.setStyle({}, n.style);
					}
					setDontDuplicateAtoms(e) {
						this.dontDuplicateAtoms = e;
					}
					setModelData(e) {
						this.modelData = e;
					}
					propertyMatches(e, t) {
						if (e == t) return !0;
						if (typeof t == "string" && typeof e == "number") {
							var n = t.match(/(-?\d+)\s*-\s*(-?\d+)/);
							if (n) {
								var r = parseInt(n[1]), i = parseInt(n[2]);
								if (n && e >= r && e <= i) return !0;
							}
						}
						return !1;
					}
					static deepCopyAndCache(e, t) {
						if (typeof e != "object" || !e || e instanceof m || e.__cache_created) return e;
						let n = {};
						for (let r in e) {
							let i = e[r];
							if (Array.isArray(i)) {
								n[r] = [];
								for (let e = 0; e < i.length; e++) n[r].push(m.deepCopyAndCache(i[e], t));
							} else n[r] = typeof i == "object" && r != "properties" && r != "model" ? m.deepCopyAndCache(i, t) : i;
							if (r == "and" || r == "or") {
								let e = [];
								for (let i of n[r]) {
									let n = /* @__PURE__ */ new Set();
									for (let e of t.selectedAtoms(i)) n.add(e.index);
									e.push(n);
								}
								if (r == "and") {
									let t = function(e, t) {
										let n = /* @__PURE__ */ new Set();
										for (let r of t) e.has(r) && n.add(r);
										return n;
									}, i = new Set(e[0]);
									for (let n of e.splice(1)) i = t(i, n);
									n[r].__cached_results = i;
								} else if (r == "or") {
									let t = /* @__PURE__ */ new Set();
									for (let n of e) for (let e of n) t.add(e);
									n[r].__cached_results = t;
								}
							}
						}
						return n.__cache_created = !0, n;
					}
					atomIsSelected(e, t) {
						if (t === void 0) return !0;
						var n = !!t.invert, r = !0;
						for (var i in t) if (i == "and" || i == "or" || i == "not") {
							if (i == "not") {
								if (this.atomIsSelected(e, t[i])) {
									r = !1;
									break;
								}
							} else if (t[i].__cached_results === void 0 && (t = m.deepCopyAndCache(t, this)), r = t[i].__cached_results.has(e.index), !r) break;
						} else if (i === "predicate") {
							if (!t.predicate(e)) {
								r = !1;
								break;
							}
						} else if (i == "properties" && e[i]) {
							for (var a in t.properties) if (!a.startsWith("__cache")) {
								if (e.properties[a] === void 0) {
									r = !1;
									break;
								}
								if (e.properties[a] != t.properties[a]) {
									r = !1;
									break;
								}
							}
						} else if (i == "model") {
							let e = t.model;
							if (typeof e == "number" && e < 0 && (e = this.viewer.getNextModelId() + e), Array.isArray(e)) {
								let t = !1;
								for (let n = 0; n < e.length; n++) if (e[n] == this || e[n] == this.id) {
									t = !0;
									break;
								}
								if (!t) {
									r = !1;
									break;
								}
							} else if (e != this && e != this.id) {
								r = !1;
								break;
							}
						} else if (t.hasOwnProperty(i) && !m.ignoredKeys.has(i) && !i.startsWith("__cache")) {
							if (e[i] === void 0) {
								r = !1;
								break;
							}
							let n = !1;
							if (i === "bonds") {
								if (t[i] != e.bonds.length) {
									r = !1;
									break;
								}
							} else if (Array.isArray(t[i])) {
								var o = t[i], s = e[i];
								for (let e = 0; e < o.length; e++) if (this.propertyMatches(s, o[e])) {
									n = !0;
									break;
								}
								if (!n) {
									r = !1;
									break;
								}
							} else {
								let n = t[i];
								if (!this.propertyMatches(e[i], n)) {
									r = !1;
									break;
								}
							}
						}
						return n ? !r : r;
					}
					static squaredDistance(e, t) {
						var n = t.x - e.x, r = t.y - e.y, i = t.z - e.z;
						return n * n + r * r + i * i;
					}
					expandAtomList(e, t) {
						if (t <= 0) return e;
						for (var n = (0, l.getExtent)(e, void 0), r = [
							[],
							[],
							[]
						], i = 0; i < 3; i++) r[0][i] = n[0][i] - t, r[1][i] = n[1][i] + t, r[2][i] = n[2][i];
						var a = [];
						for (let e = 0; e < this.atoms.length; e++) {
							var o = this.atoms[e].x, s = this.atoms[e].y, c = this.atoms[e].z;
							o >= r[0][0] && o <= r[1][0] && s >= r[0][1] && s <= r[1][1] && c >= r[0][2] && c <= r[1][2] && (o >= n[0][0] && o <= n[1][0] && s >= n[0][1] && s <= n[1][1] && c >= n[0][2] && c <= n[1][2] || a.push(this.atoms[e]));
						}
						return a;
					}
					static getFloat(e) {
						return typeof e == "number" ? e : parseFloat(e);
					}
					selectedAtoms(e, t) {
						var n = [];
						e = m.deepCopyAndCache(e || {}, this), t ||= this.atoms;
						for (var r = t.length, i = 0; i < r; i++) {
							var a = t[i];
							a && this.atomIsSelected(a, e) && n.push(a);
						}
						if (e.hasOwnProperty("expand")) {
							let t = m.getFloat(e.expand), r = this.expandAtomList(n, t), i = n.length, a = t * t;
							for (let e = 0; e < r.length; e++) for (let t = 0; t < i; t++) {
								var o = m.squaredDistance(r[e], n[t]);
								o < a && o > 0 && n.push(r[e]);
							}
						}
						if (e.hasOwnProperty("within") && e.within.hasOwnProperty("sel") && e.within.hasOwnProperty("distance")) {
							var s = this.selectedAtoms(e.within.sel, this.atoms), c = {};
							let t = m.getFloat(e.within.distance), r = t * t;
							for (let e = 0; e < s.length; e++) for (let t = 0; t < n.length; t++) {
								let i = m.squaredDistance(s[e], n[t]);
								i < r && i > 0 && (c[t] = 1);
							}
							var l = [];
							if (e.within.invert) for (let e = 0; e < n.length; e++) c[e] || l.push(n[e]);
							else for (let e in c) l.push(n[e]);
							n = l;
						}
						if (e.hasOwnProperty("byres")) {
							var u = {}, d = [], f = [];
							for (let e = 0; e < n.length; e++) {
								let t = n[e];
								var p = t.chain, h = t.resi;
								if (u[p] === void 0 && (u[p] = {}), t.hasOwnProperty("resi") && u[p][h] === void 0) {
									for (u[p][h] = !0, f.push(t); f.length > 0;) if (t = f.pop(), p = t.chain, h = t.resi, d[t.index] === void 0) {
										d[t.index] = !0;
										for (var g = 0; g < t.bonds.length; g++) {
											var _ = this.atoms[t.bonds[g]];
											d[_.index] === void 0 && _.hasOwnProperty("resi") && _.chain == p && _.resi == h && (f.push(_), n.push(_));
										}
									}
								}
							}
						}
						return n;
					}
					addAtoms(e) {
						this.molObj = null;
						var t = this.atoms.length, n = [], r;
						for (r = 0; r < e.length; r++) e[r].index === void 0 && (e[r].index = r), e[r].serial === void 0 && (e[r].serial = r), n[e[r].index] = t + r;
						for (r = 0; r < e.length; r++) {
							var i = e[r], a = n[i.index], o = (0, l.extend)({}, i);
							o.index = a, o.bonds = [], o.bondOrder = [], o.model = this.id, o.style = o.style || (0, l.deepCopy)(m.defaultAtomStyle), o.color === void 0 && (o.color = this.ElementColors[o.elem] || this.defaultColor);
							for (var s = i.bonds ? i.bonds.length : 0, c = 0; c < s; c++) {
								var u = n[i.bonds[c]];
								u !== void 0 && (o.bonds.push(u), o.bondOrder.push(i.bondOrder ? i.bondOrder[c] : 1));
							}
							this.atoms.push(o);
						}
					}
					assignBonds() {
						(0, p.assignBonds)(this.atoms, { assignBonds: !0 });
					}
					removeAtoms(e) {
						this.molObj = null;
						var t = [], n;
						for (n = 0; n < e.length; n++) t[e[n].index] = !0;
						var r = [];
						for (n = 0; n < this.atoms.length; n++) {
							var i = this.atoms[n];
							t[i.index] || r.push(i);
						}
						this.atoms = [], this.addAtoms(r);
					}
					setStyle(e, t, n) {
						t === void 0 && n === void 0 && (t = e, e = {}), e = e, typeof t == "string" && (t = (0, l.specStringToObject)(t));
						var r = !1, i = this, a = function(a) {
							var o = i.selectedAtoms(e, a);
							for (let e = 0; e < a.length; e++) a[e] && (a[e].capDrawn = !1);
							for (let e = 0; e < o.length; e++) {
								r = !0, (o[e].clickable || o[e].hoverable) && (o[e].intersectionShape = {
									sphere: [],
									cylinder: [],
									line: [],
									triangle: []
								}), n || (o[e].style = {});
								for (let n in t) t.hasOwnProperty(n) && (o[e].style[n] = o[e].style[n] || {}, Object.assign(o[e].style[n], t[n]));
							}
						};
						if (e.frame !== void 0 && e.frame < this.frames.length) {
							let t = e.frame;
							t < 0 && (t = this.frames.length + t), a(this.frames[t]);
						} else {
							a(this.atoms);
							for (var o = 0; o < this.frames.length; o++) this.frames[o] !== this.atoms && a(this.frames[o]);
						}
						r && (this.molObj = null);
					}
					setClickable(e, t, n) {
						if (t = !!t, n = (0, l.makeFunction)(n), n === null) {
							console.log("Callback is not a function");
							return;
						}
						var r = this.selectedAtoms(e, this.atoms), i = r.length;
						for (let e = 0; e < i; e++) r[e].intersectionShape = {
							sphere: [],
							cylinder: [],
							line: [],
							triangle: []
						}, r[e].clickable = t, n && (r[e].callback = n);
						i > 0 && (this.molObj = null);
					}
					setHoverable(e, t, n, r) {
						if (t = !!t, n = (0, l.makeFunction)(n), r = (0, l.makeFunction)(r), n === null) {
							console.log("Hover_callback is not a function");
							return;
						}
						if (r === null) {
							console.log("Unhover_callback is not a function");
							return;
						}
						var i = this.selectedAtoms(e, this.atoms), a = i.length;
						for (let e = 0; e < a; e++) i[e].intersectionShape = {
							sphere: [],
							cylinder: [],
							line: [],
							triangle: []
						}, i[e].hoverable = t, n && (i[e].hover_callback = n), r && (i[e].unhover_callback = r);
						a > 0 && (this.molObj = null);
					}
					enableContextMenu(e, t) {
						t = !!t;
						var n, r = this.selectedAtoms(e, this.atoms), i = r.length;
						for (n = 0; n < i; n++) r[n].intersectionShape = {
							sphere: [],
							cylinder: [],
							line: [],
							triangle: []
						}, r[n].contextMenuEnabled = t;
						i > 0 && (this.molObj = null);
					}
					setColorByElement(e, t) {
						if (!(this.molObj !== null && m.sameObj(t, this.lastColors))) {
							this.lastColors = t;
							var n = this.selectedAtoms(e, n);
							n.length > 0 && (this.molObj = null);
							for (var r = 0; r < n.length; r++) {
								var i = n[r];
								t[i.elem] !== void 0 && (i.color = t[i.elem]);
							}
						}
					}
					setColorByProperty(e, t, n, r) {
						var i, a, o = this.selectedAtoms(e, o);
						for (this.lastColors = null, o.length > 0 && (this.molObj = null), typeof n == "string" && u.Gradient.builtinGradients[n] !== void 0 && (n = new u.Gradient.builtinGradients[n]()), n = n, r ||= n.range(), r ||= (0, l.getPropertyRange)(o, t), i = 0; i < o.length; i++) a = o[i], (0, l.getAtomProperty)(a, t) != null && (a.color = n.valueToHex(parseFloat(a.properties[t]), r));
					}
					setColorByFunction(e, t) {
						var n = this.selectedAtoms(e, n);
						if (typeof t == "function") {
							this.lastColors = null, n.length > 0 && (this.molObj = null);
							for (let e = 0; e < n.length; e++) {
								let r = n[e];
								r.color = t(r);
							}
						}
					}
					toCDObject(e = !1) {
						var t = {
							a: [],
							b: []
						};
						e && (t.s = []);
						for (let r = 0; r < this.atoms.length; r++) {
							let i = {}, a = this.atoms[r];
							if (i.x = a.x, i.y = a.y, i.z = a.z, a.elem != "C" && (i.l = a.elem), e) {
								for (var n = 0; n < t.s.length && JSON.stringify(a.style) !== JSON.stringify(t.s[n]);) n++;
								n === t.s.length && t.s.push(a.style), n !== 0 && (i.s = n);
							}
							t.a.push(i);
							for (let e = 0; e < a.bonds.length; e++) {
								let n = r, i = a.bonds[e];
								if (n >= i) continue;
								let o = {
									b: n,
									e: i
								}, s = a.bondOrder[e];
								s != 1 && (o.o = s), t.b.push(o);
							}
						}
						return t;
					}
					globj(e, t) {
						(this.molObj === null || t.regen) && (this.molObj = this.createMolObj(this.atoms, t), this.renderedMolObj &&= (e.remove(this.renderedMolObj), null), this.renderedMolObj = this.molObj.clone(), this.hidden && (this.renderedMolObj.setVisible(!1), this.molObj.setVisible(!1)), e.add(this.renderedMolObj));
					}
					exportVRML() {
						return this.createMolObj(this.atoms, {
							supportsImposters: !1,
							supportsAIA: !1
						}).vrml();
					}
					removegl(e) {
						this.renderedMolObj &&= (this.renderedMolObj.geometry !== void 0 && this.renderedMolObj.geometry.dispose(), this.renderedMolObj.material !== void 0 && this.renderedMolObj.material.dispose(), e.remove(this.renderedMolObj), null), this.molObj = null;
					}
					hide() {
						this.hidden = !0, this.renderedMolObj && this.renderedMolObj.setVisible(!1), this.molObj && this.molObj.setVisible(!1);
					}
					show() {
						this.hidden = !1, this.renderedMolObj && this.renderedMolObj.setVisible(!0), this.molObj && this.molObj.setVisible(!0);
					}
					addPropertyLabels(e, t, n) {
						let r = this.selectedAtoms(t), i = this.viewer, a = (0, l.deepCopy)(n);
						for (let t = 0; t < r.length; t++) {
							let n = r[t];
							var o = null;
							n[e] === void 0 ? n.properties[e] !== void 0 && (o = String(n.properties[e])) : o = String(n[e]), o != null && (a.position = n, i.addLabel(o, a));
						}
					}
					addResLabels(e, t, n = !1) {
						let r = this.viewer;
						var i = [], o = function(n, o) {
							for (var s = n.selectedAtoms(e, s), c = {}, u = 0; u < s.length; u++) {
								var d = s[u], f = d.chain, p = d.resn, m = d.resi, h = p + "" + m;
								c[f] || (c[f] = {}), c[f][h] || (c[f][h] = []), c[f][h].push(d);
							}
							var g = (0, l.deepCopy)(t);
							for (let e in c) if (c.hasOwnProperty(e)) {
								var _ = c[e];
								for (let e in _) if (_.hasOwnProperty(e)) {
									let t = _[e], n = new a.Vector3(0, 0, 0);
									for (let e = 0; e < t.length; e++) {
										let r = t[e];
										n.x += r.x, n.y += r.y, n.z += r.z;
									}
									n.divideScalar(t.length), g.position = n, g.frame = o;
									let s = r.addLabel(e, g, void 0, !0);
									i.push(s);
								}
							}
						};
						if (n) {
							var s = this.getNumFrames();
							let e = this.atoms;
							for (let e = 0; e < s; e++) this.frames[e] && (this.atoms = this.frames[e], o(this, e));
							this.atoms = e;
						} else o(this);
						return i;
					}
					setupDFS() {
						this.atomdfs = [];
						var e = this, t = new Int8Array(this.atoms.length);
						t.fill(0);
						for (var n = function(r, i, a) {
							a.push([r, i]);
							var o = e.atoms[r];
							t[r] = 1;
							for (var s = 0; s < o.bonds.length; s++) {
								var c = o.bonds[s];
								e.atoms[c] && !t[c] && n(c, r, a);
							}
						}, r = 0; r < this.atoms.length; r++) if (this.atoms[r] && !t[r]) {
							var i = [];
							n(r, -1, i), this.atomdfs.push(i);
						}
					}
					setCoordinatesFromURL(e, t) {
						this.frames = [];
						var n = this;
						return this.box && this.setupDFS(), e.startsWith("http") || (e = "http://" + e), (0, l.get)(e + "/traj/numframes/" + t, function(r) {
							if (!isNaN(parseInt(r))) return n.frames.push(n.atoms), n.frames.numFrames = r, n.frames.url = e, n.frames.path = t, n.setFrame(0);
						});
					}
					setCoordinates(e, t) {
						if (t ||= "", !e) return [];
						if (/\.gz$/.test(t)) {
							t = t.replace(/\.gz$/, "");
							try {
								e = (0, l.inflateString)(e);
							} catch (e) {
								console.log(e);
							}
						}
						if ({
							mdcrd: "",
							inpcrd: "",
							pdb: "",
							netcdf: "",
							array: ""
						}.hasOwnProperty(t)) {
							this.frames = [];
							for (var n = this.atoms.length, r = m.parseCrd(e, t), i = 0; i < r.length;) {
								for (var a = [], o = 0; o < n; o++) {
									var s = {};
									for (var c in this.atoms[o]) s[c] = this.atoms[o][c];
									a[o] = s, a[o].x = r[i++], a[o].y = r[i++], a[o].z = r[i++];
								}
								this.frames.push(a);
							}
							return this.atoms = this.frames[0], this.frames;
						}
						return [];
					}
					addAtomSpecs(e) {}
					static parseCrd(e, t) {
						var n = [], r = 0;
						if (t == "pdb") for (var i = e.indexOf("\nATOM"); i != -1;) {
							for (; e.slice(i, i + 5) == "\nATOM" || e.slice(i, i + 7) == "\nHETATM";) n[r++] = parseFloat(e.slice(i + 31, i + 39)), n[r++] = parseFloat(e.slice(i + 39, i + 47)), n[r++] = parseFloat(e.slice(i + 47, i + 55)), i = e.indexOf("\n", i + 54), e.slice(i, i + 4) == "\nTER" && (i = e.indexOf("\n", i + 5));
							i = e.indexOf("\nATOM", i);
						}
						else if (t == "netcdf") {
							var a = new f.NetCDFReader(e);
							n = [].concat.apply([], a.getDataVariable("coordinates"));
						} else if (t == "array" || Array.isArray(e)) return e.flat(2);
						else {
							let r = e.indexOf("\n");
							t == "inpcrd" && (r = e.indexOf("\n", r + 1)), e = e.slice(r + 1), n = e.match(/\S+/g).map(parseFloat);
						}
						return n;
					}
					static parseMolData(e, t = "", n) {
						if (!e) return [];
						if (/\.gz$/.test(t)) {
							t = t.replace(/\.gz$/, "");
							try {
								e = t.match(/bcif/i) ? (0, l.inflateString)(e, !1) : (0, l.inflateString)(e);
							} catch (e) {
								console.log(e);
							}
						}
						d.Parsers[t] === void 0 && (t = t.split(".").pop(), d.Parsers[t] === void 0 && (console.log("Unknown format: " + t), t = e instanceof Uint8Array ? "bcif" : e.match(/^@<TRIPOS>MOLECULE/gm) ? "mol2" : e.match(/^data_/gm) && e.match(/^loop_/gm) ? "cif" : e.match(/^HETATM/gm) || e.match(/^ATOM/gm) ? "pdb" : e.match(/ITEM: TIMESTEP/gm) ? "lammpstrj" : e.match(/^.*\n.*\n.\s*(\d+)\s+(\d+)/gm) ? "sdf" : e.match(/^%VERSION\s+VERSION_STAMP/gm) ? "prmtop" : "xyz", console.log("Best guess: " + t)));
						var r = d.Parsers[t];
						return r(e, n);
					}
				}
				m.defaultAtomStyle = { line: {} }, m.defaultlineWidth = 1, m.vdwRadii = {
					H: 1.2,
					He: 1.4,
					Li: 1.82,
					Be: 1.53,
					B: 1.92,
					C: 1.7,
					N: 1.55,
					O: 1.52,
					F: 1.47,
					Ne: 1.54,
					Na: 2.27,
					Mg: 1.73,
					Al: 1.84,
					Si: 2.1,
					P: 1.8,
					S: 1.8,
					Cl: 1.75,
					Ar: 1.88,
					K: 2.75,
					Ca: 2.31,
					Ni: 1.63,
					Cu: 1.4,
					Zn: 1.39,
					Ga: 1.87,
					Ge: 2.11,
					As: 1.85,
					Se: 1.9,
					Br: 1.85,
					Kr: 2.02,
					Rb: 3.03,
					Sr: 2.49,
					Pd: 1.63,
					Ag: 1.72,
					Cd: 1.58,
					In: 1.93,
					Sn: 2.17,
					Sb: 2.06,
					Te: 2.06,
					I: 1.98,
					Xe: 2.16,
					Cs: 3.43,
					Ba: 2.68,
					Pt: 1.75,
					Au: 1.66,
					Hg: 1.55,
					Tl: 1.96,
					Pb: 2.02,
					Bi: 2.07,
					Po: 1.97,
					At: 2.02,
					Rn: 2.2,
					Fr: 3.48,
					Ra: 2.83,
					U: 1.86
				}, m.ignoredKeys = /* @__PURE__ */ new Set([
					"props",
					"invert",
					"model",
					"frame",
					"byres",
					"expand",
					"within",
					"and",
					"or",
					"not"
				]);
			},
			"./src/GLShape.ts"(e, t, n) {
				n.r(t), n.d(t, {
					GLShape: () => f,
					splitMesh: () => p
				});
				var r = n("./src/WebGL/index.ts"), i = n("./src/WebGL/shapes/index.ts"), a = n("./src/WebGL/math/index.ts"), o = n("./src/colors.ts"), s = n("./src/ProteinSurface4.ts"), c = n("./src/VolumeData.ts"), l = n("./src/GLDraw.ts"), u = n("./src/glcartoon.ts"), d = n("./src/utilities.ts");
				class f {
					static finalizeGeo(e) {
						var t = e.updateGeoGroup(0);
						t.vertices > 0 && t.truncateArrayBuffers(!0, !0);
					}
					static updateColor(e, t) {
						t ||= o.CC.color(t), e.colorsNeedUpdate = !0;
						var n, r, i;
						t.constructor !== Array && (n = t.r, r = t.g, i = t.b);
						for (let a in e.geometryGroups) {
							let o = e.geometryGroups[a], s = o.colorArray;
							for (let e = 0, a = o.vertices; e < a; ++e) {
								if (t.constructor === Array) {
									let a = t[e];
									n = a.r, r = a.g, i = a.b;
								}
								s[e * 3] = n, s[e * 3 + 1] = r, s[e * 3 + 2] = i;
							}
						}
					}
					static drawArrow(e, t, n) {
						var r = n.start, o = n.end, s = n.radius, c = n.radiusRatio, l = n.mid, u = n.midpos;
						if (!(r && o)) return;
						var d = t.updateGeoGroup(51), f = new a.Vector3(o.x, o.y, o.z).sub(r);
						if (u) {
							let e = f.length();
							l = u > 0 ? u / e : (e + u) / e;
						}
						f.multiplyScalar(l);
						var p = new a.Vector3(r.x, r.y, r.z).add(f), m = f.clone().negate();
						let h = new a.Vector3(r.x, r.y, r.z);
						e.intersectionShape.cylinder.push(new i.Cylinder(h, p.clone(), s)), e.intersectionShape.sphere.push(new i.Sphere(h, s));
						var g = [];
						g[0] = f.clone(), Math.abs(g[0].x) > 1e-4 ? g[0].y += 1 : g[0].x += 1, g[0].cross(f), g[0].normalize(), g[4] = g[0].clone(), g[4].crossVectors(g[0], f), g[4].normalize(), g[8] = g[0].clone().negate(), g[12] = g[4].clone().negate(), g[2] = g[0].clone().add(g[4]).normalize(), g[6] = g[4].clone().add(g[8]).normalize(), g[10] = g[8].clone().add(g[12]).normalize(), g[14] = g[12].clone().add(g[0]).normalize(), g[1] = g[0].clone().add(g[2]).normalize(), g[3] = g[2].clone().add(g[4]).normalize(), g[5] = g[4].clone().add(g[6]).normalize(), g[7] = g[6].clone().add(g[8]).normalize(), g[9] = g[8].clone().add(g[10]).normalize(), g[11] = g[10].clone().add(g[12]).normalize(), g[13] = g[12].clone().add(g[14]).normalize(), g[15] = g[14].clone().add(g[0]).normalize();
						var _ = d.vertices, v = d.vertexArray, y = d.faceArray, b = d.normalArray, x = d.lineArray, S, C, w;
						for (C = 0, w = g.length; C < w; ++C) {
							S = 3 * (_ + 3 * C);
							var T = g[C].clone().multiplyScalar(s).add(r), E = g[C].clone().multiplyScalar(s).add(p), D = g[C].clone().multiplyScalar(s * c).add(p);
							if (v[S] = T.x, v[S + 1] = T.y, v[S + 2] = T.z, v[S + 3] = E.x, v[S + 4] = E.y, v[S + 5] = E.z, v[S + 6] = D.x, v[S + 7] = D.y, v[S + 8] = D.z, C > 0) {
								var O = v[S - 3], k = v[S - 2], A = v[S - 1], j = new a.Vector3(O, k, A), M = new a.Vector3(o.x, o.y, o.z), N = p.clone(), P = new a.Vector3(D.x, D.y, D.z);
								e.intersectionShape.triangle.push(new i.Triangle(P, M, j)), e.intersectionShape.triangle.push(new i.Triangle(j.clone(), N, P.clone()));
							}
						}
						d.vertices += 48, S = d.vertices * 3, v[S] = r.x, v[S + 1] = r.y, v[S + 2] = r.z, v[S + 3] = p.x, v[S + 4] = p.y, v[S + 5] = p.z, v[S + 6] = o.x, v[S + 7] = o.y, v[S + 8] = o.z, d.vertices += 3;
						var F, I, L, R, z, B, V, H, U, W, G, ee, te, ne, re, ie, K, ae, oe, q = d.vertices - 3, J = d.vertices - 2, Y = d.vertices - 1, se = q * 3, ce = J * 3, X = Y * 3;
						for (C = 0, w = g.length - 1; C < w; ++C) {
							var le = _ + 3 * C;
							S = le * 3, I = d.faceidx, L = d.lineidx, R = le, W = R * 3, z = le + 1, G = z * 3, B = le + 2, ee = B * 3, V = le + 4, te = V * 3, H = le + 5, ne = H * 3, U = le + 3, re = U * 3, ie = K = g[C], ae = oe = g[C + 1], b[W] = ie.x, b[G] = K.x, b[re] = oe.x, b[W + 1] = ie.y, b[G + 1] = K.y, b[re + 1] = oe.y, b[W + 2] = ie.z, b[G + 2] = K.z, b[re + 2] = oe.z, b[G] = K.x, b[te] = ae.x, b[re] = oe.x, b[G + 1] = K.y, b[te + 1] = ae.y, b[re + 1] = oe.y, b[G + 2] = K.z, b[te + 2] = ae.z, b[re + 2] = oe.z, b[ee] = K.x, b[ne] = ae.x, b[ee + 1] = K.y, b[ne + 1] = ae.y, b[ee + 2] = K.z, b[ne + 2] = ae.z, y[I] = R, y[I + 1] = z, y[I + 2] = U, y[I + 3] = z, y[I + 4] = V, y[I + 5] = U, y[I + 6] = R, y[I + 7] = U, y[I + 8] = q, y[I + 9] = B, y[I + 10] = J, y[I + 11] = H, y[I + 12] = B, y[I + 13] = Y, y[I + 14] = H, x[L] = R, x[L + 1] = z, x[L + 2] = R, x[L + 3] = U, x[L + 4] = V, x[L + 5] = U, x[L + 6] = R, x[L + 7] = U, x[L + 8] = B, x[L + 9] = z, x[L + 10] = B, x[L + 11] = H, x[L + 12] = V, x[L + 13] = H, x[L + 14] = B, x[L + 15] = Y, x[L + 16] = B, x[L + 17] = H, x[L + 18] = Y, x[L + 19] = H, d.faceidx += 15, d.lineidx += 20;
						}
						F = [
							_ + 45,
							_ + 46,
							_ + 1,
							_,
							_ + 47,
							_ + 2
						], I = d.faceidx, L = d.lineidx, R = F[0], W = R * 3, z = F[1], G = z * 3, B = F[4], ee = B * 3, V = F[2], te = V * 3, H = F[5], ne = H * 3, U = F[3], re = U * 3, ie = K = g[15], ae = oe = g[0], b[W] = ie.x, b[G] = K.x, b[re] = oe.x, b[W + 1] = ie.y, b[G + 1] = K.y, b[re + 1] = oe.y, b[W + 2] = ie.z, b[G + 2] = K.z, b[re + 2] = oe.z, b[G] = K.x, b[te] = ae.x, b[re] = oe.x, b[G + 1] = K.y, b[te + 1] = ae.y, b[re + 1] = oe.y, b[G + 2] = K.z, b[te + 2] = ae.z, b[re + 2] = oe.z, b[ee] = K.x, b[ne] = ae.x, b[ee + 1] = K.y, b[ne + 1] = ae.y, b[ee + 2] = K.z, b[ne + 2] = ae.z, f.normalize(), m.normalize(), b[se] = m.x, b[ce] = b[X] = f.x, b[se + 1] = m.y, b[ce + 1] = b[X + 1] = f.y, b[se + 2] = m.z, b[ce + 2] = b[X + 2] = f.z, y[I] = R, y[I + 1] = z, y[I + 2] = U, y[I + 3] = z, y[I + 4] = V, y[I + 5] = U, y[I + 6] = R, y[I + 7] = U, y[I + 8] = q, y[I + 9] = B, y[I + 10] = J, y[I + 11] = H, y[I + 12] = B, y[I + 13] = Y, y[I + 14] = H, x[L] = R, x[L + 1] = z, x[L + 2] = R, x[L + 3] = U, x[L + 4] = V, x[L + 5] = U, x[L + 6] = R, x[L + 7] = U, x[L + 8] = B, x[L + 9] = z, x[L + 10] = B, x[L + 11] = H, x[L + 12] = V, x[L + 13] = H, x[L + 14] = B, x[L + 15] = Y, x[L + 16] = B, x[L + 17] = H, x[L + 18] = Y, x[L + 19] = H, d.faceidx += 15, d.lineidx += 20;
					}
					static updateBoundingFromPoints(e, t, n, r) {
						e.center.set(0, 0, 0);
						let i = Infinity, a = Infinity, o = Infinity, s = -Infinity, c = -Infinity, l = -Infinity;
						e.box && (i = e.box.min.x, s = e.box.max.x, a = e.box.min.y, c = e.box.max.y, o = e.box.min.z, l = e.box.max.z);
						for (let e = 0, t = r; e < t; e++) {
							var u = n[e * 3], d = n[e * 3 + 1], f = n[e * 3 + 2];
							u < i && (i = u), d < a && (a = d), f < o && (o = f), u > s && (s = u), d > c && (c = d), f > l && (l = f);
						}
						e.center.set((s + i) / 2, (c + a) / 2, (l + o) / 2), e.radius = e.center.distanceTo({
							x: s,
							y: c,
							z: l
						}), e.box = {
							min: {
								x: i,
								y: a,
								z: o
							},
							max: {
								x: s,
								y: c,
								z: l
							}
						};
					}
					static addCustomGeo(e, t, n, r, o) {
						var s = t.addGeoGroup(), c = n.vertexArr, l = n.normalArr, u = n.faceArr;
						s.vertices = c.length, s.faceidx = u.length;
						var d, p, m, h, g, _, v, y, b, x = s.vertexArray, S = s.colorArray;
						for (r.constructor !== Array && (y = r.r, b = r.g, h = r.b), _ = 0, v = s.vertices; _ < v; ++_) d = _ * 3, p = c[_], x[d] = p.x, x[d + 1] = p.y, x[d + 2] = p.z, r.constructor === Array && (g = r[_], y = g.r, b = g.g, h = g.b), S[d] = y, S[d + 1] = b, S[d + 2] = h;
						if (o) for (_ = 0, v = s.faceidx / 3; _ < v; ++_) {
							d = _ * 3, m = u[d], h = u[d + 1], g = u[d + 2];
							var C = new a.Vector3(), w = new a.Vector3(), T = new a.Vector3();
							e.intersectionShape.triangle.push(new i.Triangle(C.copy(c[m]), w.copy(c[h]), T.copy(c[g])));
						}
						if (o) {
							var E = new a.Vector3(0, 0, 0), D = 0;
							for (let e = 0; e < t.geometryGroups.length; e++) E.add(t.geometryGroups[e].getCentroid()), D++;
							E.divideScalar(D), f.updateBoundingFromPoints(e.boundingSphere, { centroid: E }, x, s.vertices);
						}
						if (s.faceArray = new Uint16Array(u), s.truncateArrayBuffers(!0, !0), l.length < s.vertices) s.setNormals();
						else {
							var O = s.normalArray = new Float32Array(s.vertices * 3), k;
							for (_ = 0, v = s.vertices; _ < v; ++_) d = _ * 3, k = l[_], O[d] = k.x, O[d + 1] = k.y, O[d + 2] = k.z;
						}
						s.setLineIndices(), s.lineidx = s.lineArray.length;
					}
					static updateFromStyle(e, t) {
						t.color === void 0 ? e.color = o.CC.color(0) : (e.color = t.color || new o.Color(), t.color instanceof o.Color || (e.color = o.CC.color(t.color))), e.wireframe = !!t.wireframe, e.opacity = t.alpha ? (0, a.clamp)(t.alpha, 0, 1) : 1, t.opacity !== void 0 && (e.opacity = (0, a.clamp)(t.opacity, 0, 1)), e.side = t.side === void 0 ? r.DoubleSide : t.side, e.linewidth = t.linewidth === void 0 ? 1 : t.linewidth, e.clickable = !!t.clickable, e.callback = (0, d.makeFunction)(t.callback), e.hoverable = !!t.hoverable, e.hover_callback = (0, d.makeFunction)(t.hover_callback), e.unhover_callback = (0, d.makeFunction)(t.unhover_callback), e.contextMenuEnabled = !!t.contextMenuEnabled, e.hidden = t.hidden, e.frame = t.frame;
					}
					constructor(e) {
						this.color = 16777215, this.hidden = !1, this.wireframe = !1, this.opacity = 1, this.linewidth = 1, this.clickable = !1, this.hoverable = !1, this.contextMenuEnabled = !1, this.side = r.DoubleSide, this.stylespec = e || {}, this.boundingSphere = new i.Sphere(), this.intersectionShape = {
							sphere: [],
							cylinder: [],
							line: [],
							triangle: []
						}, f.updateFromStyle(this, this.stylespec), this.components = [], this.shapeObj = null, this.renderedShapeObj = null, this.geo = new r.Geometry(!0), this.linegeo = new r.Geometry(!0);
					}
					updateStyle(e) {
						for (var t in e) this.stylespec[t] = e[t];
						if (f.updateFromStyle(this, this.stylespec), e.voldata && e.volscheme) {
							(0, d.adjustVolumeStyle)(e);
							let t = e.volscheme, n = e.voldata, r = o.CC, i = t.range() || [-1, 1];
							this.geo.setColors(function(e, a, o) {
								let s = n.getVal(e, a, o);
								return r.color(t.valueToHex(s, i));
							}), delete this.color;
						}
					}
					addCustom(e) {
						e.vertexArr = e.vertexArr || [], e.faceArr = e.faceArr || [], e.normalArr = e.normalArr || [], f.drawCustom(this, this.geo, e);
					}
					addSphere(e) {
						e.center ||= new a.Vector3(0, 0, 0), e.radius = e.radius ? (0, a.clamp)(e.radius, 0, Infinity) : 1.5, e.color = o.CC.color(e.color), this.intersectionShape.sphere.push(new i.Sphere(e.center, e.radius)), l.GLDraw.drawSphere(this.geo, e.center, e.radius, e.color, e.quality), this.components.push({ centroid: new a.Vector3(e.center.x, e.center.y, e.center.z) });
						var t = this.geo.updateGeoGroup(0);
						f.updateBoundingFromPoints(this.boundingSphere, this.components, t.vertexArray, t.vertices);
					}
					addBox(e) {
						var t = e.dimensions || {
							w: 1,
							h: 1,
							d: 1
						}, n = typeof t.w == "number" ? {
							x: t.w,
							y: 0,
							z: 0
						} : t.w, r = typeof t.h == "number" ? {
							x: 0,
							y: t.h,
							z: 0
						} : t.h, i = typeof t.d == "number" ? {
							x: 0,
							y: 0,
							z: t.d
						} : t.d, o = e.corner;
						o ??= e.center === void 0 ? {
							x: 0,
							y: 0,
							z: 0
						} : {
							x: e.center.x - .5 * (n.x + r.x + i.x),
							y: e.center.y - .5 * (n.y + r.y + i.y),
							z: e.center.z - .5 * (n.z + r.z + i.z)
						};
						var s = [
							{
								x: o.x,
								y: o.y,
								z: o.z
							},
							{
								x: o.x + n.x,
								y: o.y + n.y,
								z: o.z + n.z
							},
							{
								x: o.x + r.x,
								y: o.y + r.y,
								z: o.z + r.z
							},
							{
								x: o.x + n.x + r.x,
								y: o.y + n.y + r.y,
								z: o.z + n.z + r.z
							},
							{
								x: o.x + i.x,
								y: o.y + i.y,
								z: o.z + i.z
							},
							{
								x: o.x + n.x + i.x,
								y: o.y + n.y + i.y,
								z: o.z + n.z + i.z
							},
							{
								x: o.x + r.x + i.x,
								y: o.y + r.y + i.y,
								z: o.z + r.z + i.z
							},
							{
								x: o.x + n.x + r.x + i.x,
								y: o.y + n.y + r.y + i.y,
								z: o.z + n.z + r.z + i.z
							}
						], c = [], l = [];
						c.splice(c.length, 0, s[0], s[1], s[2], s[3]), l.splice(l.length, 0, 0, 2, 1, 1, 2, 3);
						var u = 4;
						c.splice(c.length, 0, s[2], s[3], s[6], s[7]), l.splice(l.length, 0, u + 0, u + 2, u + 1, u + 1, u + 2, u + 3), u += 4, c.splice(c.length, 0, s[4], s[5], s[0], s[1]), l.splice(l.length, 0, u + 0, u + 2, u + 1, u + 1, u + 2, u + 3), u += 4, c.splice(c.length, 0, s[6], s[7], s[4], s[5]), l.splice(l.length, 0, u + 0, u + 2, u + 1, u + 1, u + 2, u + 3), u += 4, c.splice(c.length, 0, s[3], s[1], s[7], s[5]), l.splice(l.length, 0, u + 0, u + 2, u + 1, u + 1, u + 2, u + 3), u += 4, c.splice(c.length, 0, s[2], s[6], s[0], s[4]), l.splice(l.length, 0, u + 0, u + 2, u + 1, u + 1, u + 2, u + 3), u += 4;
						var p = (0, d.extend)({}, e);
						p.vertexArr = c, p.faceArr = l, p.normalArr = [], f.drawCustom(this, this.geo, p);
						var m = new a.Vector3();
						this.components.push({ centroid: m.addVectors(s[0], s[7]).multiplyScalar(.5) });
						var h = this.geo.updateGeoGroup(0);
						f.updateBoundingFromPoints(this.boundingSphere, this.components, h.vertexArray, h.vertices);
					}
					addCylinder(e) {
						var t = e.start ? new a.Vector3(e.start.x || 0, e.start.y || 0, e.start.z || 0) : new a.Vector3(0, 0, 0), n;
						e.end ? (n = new a.Vector3(e.end.x, e.end.y || 0, e.end.z || 0), n.x === void 0 && (n.x = 3)) : n = new a.Vector3(0, 0, 0);
						var r = e.radius || .1, s = o.CC.color(e.color);
						this.intersectionShape.cylinder.push(new i.Cylinder(t, n, r)), l.GLDraw.drawCylinder(this.geo, t, n, r, s, e.fromCap, e.toCap);
						var c = new a.Vector3();
						this.components.push({ centroid: c.addVectors(t, n).multiplyScalar(.5) });
						var u = this.geo.updateGeoGroup(0);
						f.updateBoundingFromPoints(this.boundingSphere, this.components, u.vertexArray, u.vertices);
					}
					addDashedCylinder(e) {
						e.dashLength = e.dashLength || .25, e.gapLength = e.gapLength || .25;
						var t = e.start ? new a.Vector3(e.start.x || 0, e.start.y || 0, e.start.z || 0) : new a.Vector3(0, 0, 0), n;
						e.end ? (n = new a.Vector3(e.end.x, e.end.y || 0, e.end.z || 0), n.x === void 0 && (n.x = 3)) : n = new a.Vector3(3, 0, 0);
						for (var r = e.radius || .1, s = o.CC.color(e.color), c = Math.sqrt((t.x - n.x) ** 2 + (t.y - n.y) ** 2 + (t.z - n.z) ** 2), u = c / (e.gapLength + e.dashLength), d = new a.Vector3(e.start.x || 0, e.start.y || 0, e.start.z || 0), p = new a.Vector3(e.end.x, e.end.y || 0, e.end.z || 0), m = new a.Vector3((n.x - t.x) / (c / e.gapLength), (n.y - t.y) / (c / e.gapLength), (n.z - t.z) / (c / e.gapLength)), h = new a.Vector3((n.x - t.x) / (c / e.dashLength), (n.y - t.y) / (c / e.dashLength), (n.z - t.z) / (c / e.dashLength)), g = 0; g < u; g++) p = new a.Vector3(d.x + h.x, d.y + h.y, d.z + h.z), this.intersectionShape.cylinder.push(new i.Cylinder(d, p, r)), l.GLDraw.drawCylinder(this.geo, d, p, r, s, e.fromCap, e.toCap), d = new a.Vector3(p.x + m.x, p.y + m.y, p.z + m.z);
						var _ = new a.Vector3();
						this.components.push({ centroid: _.addVectors(t, n).multiplyScalar(.5) });
						var v = this.geo.updateGeoGroup(0);
						f.updateBoundingFromPoints(this.boundingSphere, this.components, v.vertexArray, v.vertices);
					}
					addCurve(e) {
						e.points = e.points || [], e.smooth = e.smooth || 10, e.fromCap === void 0 && (e.fromCap = 2), e.toCap === void 0 && (e.toCap = 2);
						var t = (0, u.subdivide_spline)(e.points, e.smooth);
						if (t.length < 3) {
							console.log("Too few points in addCurve");
							return;
						}
						var n = e.radius || .1, r = o.CC.color(e.color), i = 0, a = t.length - 1, s = t[0].distanceTo(t[1]), c = Math.ceil(2 * n / s);
						if (e.toArrow) {
							a -= c;
							let e = {
								start: t[a],
								end: t[t.length - 1],
								radius: n,
								color: r,
								mid: 1e-4
							};
							this.addArrow(e);
						}
						if (e.fromArrow) {
							i += c;
							let e = {
								start: t[i],
								end: t[0],
								radius: n,
								color: r,
								mid: 1e-4
							};
							this.addArrow(e);
						}
						for (var l = Math.ceil(t.length / 2), d = {
							radius: n,
							color: r,
							fromCap: 2,
							toCap: 2
						}, f = i; f < a; f++) d.start = t[f], d.end = t[f + 1], d.fromCap = 2, d.toCap = 2, f < l ? (d.fromCap = 2, d.toCap = 0) : f > l ? (d.fromCap = 0, d.toCap = 2) : (d.fromCap = 2, d.toCap = 2), this.addCylinder(d);
					}
					addLine(e) {
						var t = e.start ? new a.Vector3(e.start.x || 0, e.start.y || 0, e.start.z || 0) : new a.Vector3(0, 0, 0), n;
						e.end ? (n = new a.Vector3(e.end.x, e.end.y || 0, e.end.z || 0), n.x === void 0 && (n.x = 3)) : n = new a.Vector3(3, 0, 0);
						var r = this.geo.updateGeoGroup(2), i = r.vertices, o = i * 3, s = r.vertexArray;
						s[o] = t.x, s[o + 1] = t.y, s[o + 2] = t.z, s[o + 3] = n.x, s[o + 4] = n.y, s[o + 5] = n.z, r.vertices += 2;
						var c = r.lineArray, l = r.lineidx;
						c[l] = i, c[l + 1] = i + 1, r.lineidx += 2;
						var u = new a.Vector3();
						this.components.push({ centroid: u.addVectors(t, n).multiplyScalar(.5) }), r = this.geo.updateGeoGroup(0), f.updateBoundingFromPoints(this.boundingSphere, this.components, r.vertexArray, r.vertices);
					}
					addArrow(e) {
						e.start = e.start ? new a.Vector3(e.start.x || 0, e.start.y || 0, e.start.z || 0) : new a.Vector3(0, 0, 0), e.dir instanceof a.Vector3 && typeof e.length == "number" ? e.end = e.dir.clone().multiplyScalar(e.length).add(e.start) : e.end ? (e.end = new a.Vector3(e.end.x, e.end.y || 0, e.end.z || 0), e.end.x === void 0 && (e.end.x = 3)) : e.end = new a.Vector3(3, 0, 0), e.radius = e.radius || .1, e.radiusRatio = e.radiusRatio || 1.618034, e.mid = 0 < e.mid && e.mid < 1 ? e.mid : .618034, f.drawArrow(this, this.geo, e);
						var t = new a.Vector3();
						this.components.push({ centroid: t.addVectors(e.start, e.end).multiplyScalar(.5) });
						var n = this.geo.updateGeoGroup(0);
						f.updateBoundingFromPoints(this.boundingSphere, this.components, n.vertexArray, n.vertices);
					}
					static distance_from(e, t) {
						return Math.sqrt((e.x - t.x) ** 2 + (e.y - t.y) ** 2 + (e.z - t.z) ** 2);
					}
					static inSelectedRegion(e, t, n) {
						for (var r = 0; r < t.length; r++) if (f.distance_from(t[r], e) <= n) return !0;
						return !1;
					}
					addIsosurface(e, t, n, r) {
						var i = t.isoval !== void 0 && typeof t.isoval == "number" ? t.isoval : 0, o = !!t.voxel, c = t.smoothness === void 0 ? 1 : t.smoothness, l = e.size.x, u = e.size.y, d = e.size.z, p = new Int16Array(l * u * d), m = e.data, h, g;
						for (h = 0, g = p.length; h < g; ++h) p[h] = -1;
						var _ = new Uint8Array(l * u * d);
						for (h = 0, g = m.length; h < g; ++h) (i >= 0 ? m[h] - i : i - m[h]) > 0 && (_[h] |= f.ISDONE);
						var v = [], y = [];
						s.MarchingCube.march(_, v, y, {
							fulltable: !0,
							voxel: o,
							unitCube: e.unit,
							origin: e.origin,
							matrix: e.matrix,
							nX: l,
							nY: u,
							nZ: d
						}), !o && c > 0 && s.MarchingCube.laplacianSmooth(c, v, y);
						var b = [], x = [], S = [];
						if (t.selectedRegion && t.coords === void 0 && (t.coords = t.selectedRegion), t.coords === void 0 && t.selection !== void 0 && (r ? t.coords = r.selectedAtoms(t.selection) : console.log("addIsosurface needs viewer is selection provided.")), t.coords !== void 0) {
							var C = t.coords[0].x, w = t.coords[0].y, T = t.coords[0].z, E = t.coords[0].x, D = t.coords[0].y, O = t.coords[0].z;
							for (let e = 0; e < t.coords.length; e++) t.coords[e].x > C ? C = t.coords[e].x : t.coords[e].x < E && (E = t.coords[e].x), t.coords[e].y > w ? w = t.coords[e].y : t.coords[e].y < D && (D = t.coords[e].y), t.coords[e].z > T ? T = t.coords[e].z : t.coords[e].z < O && (O = t.coords[e].z);
							var k = 2;
							t.radius !== void 0 && (k = t.radius), t.selectedOffset !== void 0 && (k = t.selectedOffset), t.seldist !== void 0 && (k = t.seldist), E -= k, C += k, D -= k, w += k, O -= k, T += k;
							for (let e = 0; e < v.length; e++) v[e].x > E && v[e].x < C && v[e].y > D && v[e].y < w && v[e].z > O && v[e].z < T && f.inSelectedRegion(v[e], t.coords, k) ? (b.push(x.length), x.push(v[e])) : b.push(-1);
							for (let e = 0; e + 2 < y.length; e += 3) b[y[e]] !== -1 && b[y[e + 1]] !== -1 && b[y[e + 2]] !== -1 && (S.push(y[e] - (y[e] - b[y[e]])), S.push(y[e + 1] - (y[e + 1] - b[y[e + 1]])), S.push(y[e + 2] - (y[e + 2] - b[y[e + 2]])));
							v = x, y = S;
						}
						f.drawCustom(this, this.geo, {
							vertexArr: v,
							faceArr: y,
							normalArr: [],
							clickable: t.clickable,
							hoverable: t.hoverable
						}), this.updateStyle(t);
						var A = new a.Vector3(e.origin.x, e.origin.y, e.origin.z), j = new a.Vector3(e.size.x * e.unit.x, e.size.y * e.unit.y, e.size.z * e.unit.z), M = new a.Vector3(0, 0, 0), N = A.clone(), P = A.clone().add(j);
						for (let e = 0; e < v.length; e++) M.add(v[e]), N.max(v[e]), P.min(v[e]);
						M.divideScalar(v.length);
						var F = M.distanceTo(P), I = M.distanceTo(N);
						this.boundingSphere.center = M, this.boundingSphere.radius = Math.max(F, I), typeof n == "function" && n();
					}
					addVolumetricData(e, t, n) {
						e = new c.VolumeData(e, t), this.addIsosurface(e, n);
					}
					finalize() {
						return f.finalizeGeo(this.geo), this.geo.initTypedArrays(), this.geo;
					}
					globj(e) {
						if (this.renderedShapeObj &&= (e.remove(this.renderedShapeObj), null), !this.hidden) {
							f.finalizeGeo(this.geo), this.geo.initTypedArrays(), this.wireframe && this.geo.setUpWireframe(), this.color !== void 0 && f.updateColor(this.geo, this.color), this.shapeObj = new r.Object3D();
							var t = null;
							t = this.side == r.DoubleSide ? new r.MeshDoubleLambertMaterial({
								wireframe: this.wireframe,
								side: this.side,
								transparent: this.opacity < 1,
								opacity: this.opacity,
								wireframeLinewidth: this.linewidth,
								vertexColors: r.Coloring.VertexColors
							}) : new r.MeshLambertMaterial({
								wireframe: this.wireframe,
								side: this.side,
								transparent: this.opacity < 1,
								opacity: this.opacity,
								wireframeLinewidth: this.linewidth,
								vertexColors: r.Coloring.VertexColors
							});
							var n = new r.Mesh(this.geo, t);
							if (this.shapeObj.add(n), this.linegeo && this.linegeo.vertices > 0) {
								var i = new r.LineBasicMaterial({
									linewidth: this.linewidth,
									color: this.color
								}), a = new r.Line(this.linegeo, i, r.LineStyle.LinePieces);
								this.shapeObj.add(a);
							}
							this.renderedShapeObj = this.shapeObj.clone(), e.add(this.renderedShapeObj);
						}
					}
					removegl(e) {
						this.renderedShapeObj &&= (this.renderedShapeObj.geometry !== void 0 && this.renderedShapeObj.geometry.dispose(), this.renderedShapeObj.material !== void 0 && this.renderedShapeObj.material.dispose(), e.remove(this.renderedShapeObj), null), this.shapeObj = null;
					}
					get position() {
						return this.boundingSphere.center;
					}
					get x() {
						return this.boundingSphere.center.x;
					}
					get y() {
						return this.boundingSphere.center.y;
					}
					get z() {
						return this.boundingSphere.center.z;
					}
				}
				f.ISDONE = 2, f.drawCustom = function(e, t, n) {
					var r = n, i = r.vertexArr, a = r.faceArr;
					(i.length === 0 || a.length === 0) && console.warn("Error adding custom shape component: No vertices and/or face indices supplied!");
					var s = n.color;
					s === void 0 && (s = e.color), s = o.CC.color(s);
					for (var c = p(r), l = 0, u = c.length; l < u; l++) f.addCustomGeo(e, t, c[l], c[l].colorArr ? c[l].colorArr : s, n.clickable);
				};
				function p(e) {
					var t = 64e3;
					if (e.vertexArr.length < t) return [e];
					var n = [{
						vertexArr: [],
						normalArr: [],
						faceArr: []
					}];
					e.colorArr && (n.colorArr = []);
					var r = [], i = [], a = 0, o = e.faceArr;
					for (let c = 0, l = o.length; c < l; c += 3) {
						let l = n[a];
						for (let t = 0; t < 3; t++) {
							var s = o[c + t];
							r[s] !== a && (r[s] = a, i[s] = l.vertexArr.length, l.vertexArr.push(e.vertexArr[s]), e.normalArr && e.normalArr[s] && l.normalArr.push(e.normalArr[s]), e.colorArr && e.colorArr[s] && l.colorArr.push(e.colorArr[s])), l.faceArr.push(i[s]);
						}
						l.vertexArr.length >= t && (n.push({
							vertexArr: [],
							normalArr: [],
							faceArr: []
						}), e.colorArr && (n.colorArr = []), a++);
					}
					return n;
				}
			},
			"./src/GLViewer.ts"(e, t, n) {
				n.r(t), n.d(t, {
					CONTEXTS_PER_VIEWPORT: () => g,
					GLViewer: () => v,
					createStereoViewer: () => x,
					createViewer: () => y,
					createViewerGrid: () => b
				});
				var r = n("./node_modules/upng-js/UPNG.js"), i = /*#__PURE__*/ n.n(r), a = n("./src/GLModel.ts"), o = n("./src/GLShape.ts"), s = n("./src/Gradient.ts"), c = n("./src/Label.ts"), l = n("./src/ProteinSurface4.ts"), u = n("./src/VolumeData.ts"), d = n("./src/VolumetricRender.ts"), f = n("./src/WebGL/index.ts"), p = n("./src/WebGL/math/index.ts"), m = n("./src/colors.ts"), h = n("./src/utilities.ts");
				let g = 16;
				class _ extends Array {
					constructor(e) {
						super(...e);
					}
					getSymmetries() {
						if (this.length == 0) return [];
						let e = this[0];
						return e.symmetries === void 0 && this.setSymmetries([new p.Matrix4()]), e.symmetries;
					}
					setSymmetries(e) {
						e === void 0 && (e = [new p.Matrix4()]);
						for (let t of this) t.symmetries = e, t.finished = !1;
					}
				}
				class v {
					getWidth() {
						let e = this.container, t = e.offsetWidth;
						if (t == 0 && e.style.display === "none") {
							let n = e.style.position, r = e.style.visibility;
							e.style.display = "block", e.style.visibility = "hidden", e.style.position = "absolute", t = e.offsetWidth, e.style.display = "none", e.style.visibility = r, e.style.position = n;
						}
						return t;
					}
					getHeight() {
						let e = this.container, t = e.offsetHeight;
						if (t == 0 && e.style.display === "none") {
							let n = e.style.position, r = e.style.visibility;
							e.style.display = "block", e.style.visibility = "hidden", e.style.position = "absolute", t = e.offsetHeight, e.style.display = "none", e.style.visibility = r, e.style.position = n;
						}
						return t;
					}
					setupRenderer() {
						let e = Object.assign(Object.assign({}, this.config), {
							preserveDrawingBuffer: !0,
							premultipliedAlpha: !1,
							containerWidth: this.WIDTH,
							containerHeight: this.HEIGHT
						});
						this.renderer = new f.Renderer(e), this.renderer.domElement.style.width = "100%", this.renderer.domElement.style.height = "100%", this.renderer.domElement.style.padding = "0", this.renderer.domElement.style.position = "absolute", this.renderer.domElement.style.top = "0px", this.renderer.domElement.style.left = "0px", this.renderer.domElement.style.zIndex = "0";
					}
					initializeScene() {
						this.scene = new f.Scene(), this.scene.fog = new f.Fog(this.bgColor, 100, 200), this.modelGroup = new f.Object3D(), this.rotationGroup = new f.Object3D(), this.rotationGroup.useQuaternion = !0, this.rotationGroup.quaternion = new p.Quaternion(0, 0, 0, 1), this.rotationGroup.add(this.modelGroup), this.scene.add(this.rotationGroup);
						var e = new f.Light(16777215);
						e.position = new p.Vector3(.2, .2, 1).normalize(), e.intensity = 1, this.scene.add(e);
					}
					_handleLostContext(e) {
						let t = function(e) {
							let t = e.getBoundingClientRect();
							return !(t.right < 0 || t.bottom < 0 || t.top > (window.innerHeight || document.documentElement.clientHeight) || t.left > (window.innerWidth || document.documentElement.clientWidth));
						};
						if (t(this.container)) {
							let e = 0;
							for (let n of document.getElementsByTagName("canvas")) if (t(n) && n._3dmol_viewer != null && (n._3dmol_viewer.resize(), e += 1, e >= 16)) break;
						}
					}
					initContainer(e) {
						this.container = e, this.WIDTH = this.getWidth(), this.HEIGHT = this.getHeight(), this.ASPECT = this.renderer.getAspect(this.WIDTH, this.HEIGHT), this.renderer.setSize(this.WIDTH, this.HEIGHT), this.container.append(this.renderer.domElement), this.glDOM = this.renderer.domElement, this.glDOM._3dmol_viewer = this, this.glDOM.addEventListener("webglcontextlost", this._handleLostContext.bind(this)), this.nomouse || (this.glDOM.addEventListener("mousedown", this._handleMouseDown.bind(this), { passive: !1 }), this.glDOM.addEventListener("touchstart", this._handleMouseDown.bind(this), { passive: !1 }), this.glDOM.addEventListener("wheel", this._handleMouseScroll.bind(this), { passive: !1 }), this.glDOM.addEventListener("mousemove", this._handleMouseMove.bind(this), { passive: !1 }), this.glDOM.addEventListener("touchmove", this._handleMouseMove.bind(this), { passive: !1 }), this.glDOM.addEventListener("contextmenu", this._handleContextMenu.bind(this), { passive: !1 }));
					}
					decAnim() {
						this.animated--, this.animated < 0 && (this.animated = 0);
					}
					incAnim() {
						this.animated++;
					}
					nextSurfID() {
						var e = 0;
						for (let n in this.surfaces) if (this.surfaces.hasOwnProperty(n)) {
							var t = parseInt(n);
							isNaN(t) || t > e && (e = t);
						}
						return e + 1;
					}
					setSlabAndFog() {
						let e = this.camera.position.z - this.rotationGroup.position.z;
						e < 1 && (e = 1), this.camera.near = e + this.slabNear, !this.camera.ortho && this.camera.near < 1 && (this.camera.near = 1), this.camera.far = e + this.slabFar, this.camera.near + 1 > this.camera.far && (this.camera.far = this.camera.near + 1), this.camera.fov = this.fov, this.camera.right = e * Math.tan(Math.PI / 180 * this.fov), this.camera.left = -this.camera.right, this.camera.top = this.camera.right / this.ASPECT, this.camera.bottom = -this.camera.top, this.camera.updateProjectionMatrix(), this.scene.fog.near = this.camera.near + this.fogStart * (this.camera.far - this.camera.near), this.scene.fog.far = this.camera.near + this.fogEnd * (this.camera.far - this.camera.near), this.config.disableFog && (this.scene.fog.near = this.scene.fog.far);
					}
					show(e) {
						if (this.renderer.setViewport(), this.scene && (this.setSlabAndFog(), this.renderer.render(this.scene, this.camera), this.viewChangeCallback && this.viewChangeCallback(this._viewer.getView()), !e && this.linkedViewers.length > 0)) for (var t = this._viewer.getView(), n = 0; n < this.linkedViewers.length; n++) this.linkedViewers[n].setView(t, !0);
					}
					updateClickables() {
						this.clickables.splice(0, this.clickables.length), this.hoverables.splice(0, this.hoverables.length), this.contextMenuEnabledObjects.splice(0, this.contextMenuEnabledObjects.length);
						for (let e = 0, t = this.models.length; e < t; e++) {
							let t = this.models[e];
							if (t) {
								let e = t.selectedAtoms({ clickable: !0 }), n = t.selectedAtoms({ hoverable: !0 }), r = t.selectedAtoms({ contextMenuEnabled: !0 });
								for (let e = 0; e < n.length; e++) this.hoverables.push(n[e]);
								for (let t = 0; t < e.length; t++) this.clickables.push(e[t]);
								for (let e = 0; e < r.length; e++) this.contextMenuEnabledObjects.push(r[e]);
							}
						}
						for (let e = 0, t = this.shapes.length; e < t; e++) {
							let t = this.shapes[e];
							t && t.clickable && this.clickables.push(t), t && t.hoverable && this.hoverables.push(t), t && t.contextMenuEnabled && this.contextMenuEnabledObjects.push(t);
						}
					}
					handleClickSelection(e, t, n) {
						let r = this.targetedObjects(e, t, this.clickables);
						if (r.length) {
							var i = r[0].clickable;
							i.callback !== void 0 && (typeof i.callback != "function" && (i.callback = (0, h.makeFunction)(i.callback)), typeof i.callback == "function" && (this.mouseButton === 3 && this.contextMenuEnabledObjects.includes(i) && this.userContextMenuHandler || i.callback(i, this._viewer, n, this.container, r)));
						}
					}
					canvasOffset() {
						let e = this.glDOM, t = e.getBoundingClientRect(), n = e.ownerDocument, r = n.documentElement, i = n.defaultView;
						return {
							top: t.top + i.pageYOffset - r.clientTop,
							left: t.left + i.pageXOffset - r.clientLeft
						};
					}
					setHover(e, t, n) {
						e && e.hidden && (e = null), this.current_hover != e && (this.current_hover && (typeof this.current_hover.unhover_callback != "function" && (this.current_hover.unhover_callback = (0, h.makeFunction)(this.current_hover.unhover_callback)), this.current_hover.unhover_callback(this.current_hover, this._viewer, t, this.container, n)), this.current_hover = e, e && e.hover_callback !== void 0 && (typeof e.hover_callback != "function" && (e.hover_callback = (0, h.makeFunction)(e.hover_callback)), typeof e.hover_callback == "function" && e.hover_callback(e, this._viewer, t, this.container, n)));
					}
					handleHoverSelection(e, t, n) {
						if (this.hoverables.length == 0) return;
						let r = this.targetedObjects(e, t, this.hoverables);
						if (r.length) {
							var i = r[0].clickable;
							this.setHover(i, n, r), this.current_hover = i;
						} else this.setHover(null);
					}
					handleHoverContinue(e, t) {
						let n = this.targetedObjects(e, t, this.hoverables);
						(n.length == 0 || n[0] === void 0) && this.setHover(null), n[0] !== void 0 && n[0].clickable !== this.current_hover && this.setHover(null);
					}
					closeEnoughForClick(e, { allowTolerance: t = e.targetTouches, tolerance: n = 5 } = {}) {
						let r = this.getX(e), i = this.getY(e);
						if (t) {
							let e = Math.abs(r - this.mouseStartX), t = Math.abs(i - this.mouseStartY);
							return e <= n && t <= n;
						}
						return r === this.mouseStartX && i === this.mouseStartY;
					}
					calcTouchDistance(e) {
						var t = e.targetTouches[0].pageX - e.targetTouches[1].pageX, n = e.targetTouches[0].pageY - e.targetTouches[1].pageY;
						return Math.hypot(t, n);
					}
					getX(e) {
						var t = e.pageX;
						return t ??= e.pageX, e.targetTouches && e.targetTouches[0] ? t = e.targetTouches[0].pageX : e.changedTouches && e.changedTouches[0] && (t = e.changedTouches[0].pageX), t;
					}
					getY(e) {
						var t = e.pageY;
						return t ??= e.pageY, e.targetTouches && e.targetTouches[0] ? t = e.targetTouches[0].pageY : e.changedTouches && e.changedTouches[0] && (t = e.changedTouches[0].pageY), t;
					}
					isInViewer(e, t) {
						if (this.viewers != null) {
							var n = this.WIDTH / this.cols, r = this.HEIGHT / this.rows, i = this.canvasOffset(), a = e - i.left, o = t - i.top, s = this.rows - Math.floor(o / r) - 1, c = Math.floor(a / n);
							if (s != this.row || c != this.col) return !1;
						}
						return !0;
					}
					adjustZoomToLimits(e) {
						if (this.config.lowerZoomLimit && this.config.lowerZoomLimit > 0) {
							let t = this.CAMERA_Z - this.config.lowerZoomLimit;
							e > t && (e = t);
						}
						if (this.config.upperZoomLimit && this.config.upperZoomLimit > 0) {
							let t = this.CAMERA_Z - this.config.upperZoomLimit;
							e < t && (e = t);
						}
						return e > this.CAMERA_Z - 1 && (e = this.CAMERA_Z - 1), e;
					}
					static slerp(e, t, n) {
						if (n == 1) return t.clone();
						if (n == 0) return e.clone();
						let r = e.x * t.x + e.y * t.y + e.z * t.z + e.w * t.w;
						if (r > .9995) {
							let r = new p.Quaternion(e.x + n * (t.x - e.x), e.y + n * (t.y - e.y), e.z + n * (t.z - e.z), e.w + n * (t.w - e.w));
							return r.normalize(), r;
						}
						r < 0 && (t = t.clone().multiplyScalar(-1), r = -r), r > 1 ? r = 1 : r < -1 && (r = -1);
						var i = Math.acos(r) * n, a = t.clone();
						a.sub(e.clone().multiplyScalar(r)), a.normalize();
						var o = Math.cos(i), s = Math.sin(i), c = new p.Quaternion(e.x * o + a.x * s, e.y * o + a.y * s, e.z * o + a.z * s, e.w * o + a.w * s);
						return c.normalize(), c;
					}
					constructor(e, t = {}) {
						if (this.nomouse = !1, this.glDOM = null, this.models = [], this.surfaces = {}, this.shapes = [], this.labels = [], this.clickables = [], this.hoverables = [], this.contextMenuEnabledObjects = [], this.current_hover = null, this.hoverDuration = 500, this.longTouchDuration = 1e3, this.viewer_frame = 0, this.viewChangeCallback = null, this.stateChangeCallback = null, this.NEAR = 1, this.FAR = 800, this.CAMERA_Z = 150, this.fov = 20, this.linkedViewers = [], this.renderer = null, this.control_all = !1, this.scene = null, this.rotationGroup = null, this.modelGroup = null, this.fogStart = .4, this.fogEnd = 1, this.slabNear = -50, this.slabFar = 50, this.cq = new p.Quaternion(0, 0, 0, 1), this.dq = new p.Quaternion(0, 0, 0, 1), this.animated = 0, this.animationTimers = /* @__PURE__ */ new Set(), this.isDragging = !1, this.mouseStartX = 0, this.mouseStartY = 0, this.touchDistanceStart = 0, this.touchHold = !1, this.currentModelPos = 0, this.cz = 0, this.cslabNear = 0, this.cslabFar = 0, this.userContextMenuHandler = null, this.config = t, this.callback = this.config.callback, this.defaultcolors = this.config.defaultcolors, this.defaultcolors ||= m.elementColors.defaultColors, this.nomouse = !!this.config.nomouse, this.bgColor = 0, this.config.backgroundColor = this.config.backgroundColor || "#ffffff", this.config.backgroundColor !== void 0 && (this.bgColor = m.CC.color(this.config.backgroundColor).getHex()), this.config.backgroundAlpha = this.config.backgroundAlpha == null ? 1 : this.config.backgroundAlpha, this.camerax = 0, this.config.camerax !== void 0 && (this.camerax = typeof this.config.camerax == "string" ? parseFloat(this.config.camerax) : this.config.camerax), this._viewer = this, this.container = e, this.config.hoverDuration != null && (this.hoverDuration = this.config.hoverDuration), this.config.antialias === void 0 && (this.config.antialias = !0), this.config.cartoonQuality === void 0 && (this.config.cartoonQuality = 10), this.WIDTH = this.getWidth(), this.HEIGHT = this.getHeight(), this.setupRenderer(), this.row = this.config.row == null ? 0 : this.config.row, this.col = this.config.col == null ? 0 : this.config.col, this.cols = this.config.cols, this.rows = this.config.rows, this.viewers = this.config.viewers, this.control_all = this.config.control_all, this.ASPECT = this.renderer.getAspect(this.WIDTH, this.HEIGHT), this.camera = new f.Camera(this.fov, this.ASPECT, this.NEAR, this.FAR, this.config.orthographic), this.camera.position = new p.Vector3(this.camerax, 0, this.CAMERA_Z), this.lookingAt = new p.Vector3(), this.camera.lookAt(this.lookingAt), this.raycaster = new f.Raycaster(new p.Vector3(0, 0, 0), new p.Vector3(0, 0, 0)), this.projector = new f.Projector(), this.initializeScene(), this.renderer.setClearColorHex(this.bgColor, this.config.backgroundAlpha), this.scene.fog.color = m.CC.color(this.bgColor), document.body.addEventListener("mouseup", this._handleMouseUp.bind(this)), document.body.addEventListener("touchend", this._handleMouseUp.bind(this)), this.initContainer(this.container), this.config.style && this.setViewStyle(this.config), window.addEventListener("resize", this.resize.bind(this)), window.ResizeObserver !== void 0 && (this.divwatcher = new window.ResizeObserver(this.resize.bind(this)), this.divwatcher.observe(this.container)), window.IntersectionObserver !== void 0) {
							let e = (e, t) => {
								e.forEach((e) => {
									e.isIntersecting && this.resize();
								});
							};
							this.intwatcher = new window.IntersectionObserver(e), this.intwatcher.observe(this.container);
						}
						try {
							typeof this.callback == "function" && this.callback(this);
						} catch (e) {
							console.log("error with glviewer callback: " + e);
						}
					}
					targetedObjects(e, t, n) {
						var r = {
							x: e,
							y: t,
							z: -1
						};
						return Array.isArray(n) || (n = this.selectedAtoms(n)), n.length == 0 ? [] : (this.raycaster.setFromCamera(r, this.camera), this.raycaster.intersectObjects(this.modelGroup, n));
					}
					modelToScreen(e) {
						let t = !1;
						Array.isArray(e) || (e = [e], t = !0);
						let n = this.renderer.getXRatio(), r = this.renderer.getYRatio(), i = this.col, a = this.row, o = i * (this.WIDTH / n), s = (r - a - 1) * (this.HEIGHT / r), c = [], l = this.canvasOffset();
						return e.forEach((e) => {
							let t = new p.Vector3(e.x, e.y, e.z);
							t.applyMatrix4(this.modelGroup.matrixWorld), this.projector.projectVector(t, this.camera);
							let i = this.WIDTH / n * (t.x + 1) / 2 + l.left + o, a = -(this.HEIGHT / r) * (t.y - 1) / 2 + l.top + s;
							c.push({
								x: i,
								y: a
							});
						}), t && (c = c[0]), c;
					}
					screenOffsetToModel(e, t, n) {
						var r = e / this.WIDTH, i = t / this.HEIGHT, a = n === void 0 ? this.rotationGroup.position.z : n, o = this.rotationGroup.quaternion, s = new p.Vector3(0, 0, a);
						return this.projector.projectVector(s, this.camera), s.x += r * 2, s.y -= i * 2, this.projector.unprojectVector(s, this.camera), s.z = 0, s.applyQuaternion(o), s;
					}
					screenToModelDistance(e, t) {
						let n = this.canvasOffset(), r = new p.Vector3(t.x, t.y, t.z);
						r.applyMatrix4(this.modelGroup.matrixWorld);
						let i = r.clone();
						this.projector.projectVector(r, this.camera);
						let a = new p.Vector3((e.x - n.left) * 2 / this.WIDTH - 1, (e.y - n.top) * 2 / -this.HEIGHT + 1, r.z);
						return this.projector.unprojectVector(a, this.camera), a.distanceTo(i);
					}
					setViewChangeCallback(e) {
						(typeof e == "function" || e == null) && (this.viewChangeCallback = e);
					}
					setStateChangeCallback(e) {
						(typeof e == "function" || e == null) && (this.stateChangeCallback = e);
					}
					getConfig() {
						return this.config;
					}
					setConfig(e) {
						this.config = e, e.ambientOcclusion && this.renderer.enableAmbientOcclusion(e.ambientOcclusion);
					}
					getInternalState() {
						var e = {
							models: [],
							surfaces: [],
							shapes: [],
							labels: []
						};
						for (let t = 0; t < this.models.length; t++) this.models[t] && (e.models[t] = this.models[t].getInternalState());
						return e;
					}
					setInternalState(e) {
						this.clear();
						var t = e.models;
						for (let e = 0; e < t.length; e++) t[e] && (this.models[e] = new a.GLModel(e, void 0, this), this.models[e].setInternalState(t[e]));
						this.render();
					}
					setZoomLimits(e, t) {
						e !== void 0 && (this.config.lowerZoomLimit = e), t && (this.config.upperZoomLimit = t), this.rotationGroup.position.z = this.adjustZoomToLimits(this.rotationGroup.position.z), this.show();
					}
					setCameraParameters(e) {
						e.fov !== void 0 && (this.fov = e.fov, this.camera.fov = this.fov), e.z !== void 0 && (this.CAMERA_Z = e.z, this.camera.z = this.CAMERA_Z), e.orthographic !== void 0 && (this.camera.ortho = e.orthographic), this.setSlabAndFog();
					}
					_handleMouseDown(e) {
						if (e.preventDefault(), !this.scene) return;
						var t = this.getX(e), n = this.getY(e);
						if (t === void 0) return;
						this.isDragging = !0, this.mouseButton = e.which, this.mouseStartX = t, this.mouseStartY = n, this.touchHold = !0, this.touchDistanceStart = 0, e.targetTouches && e.targetTouches.length == 2 && (this.touchDistanceStart = this.calcTouchDistance(e)), this.cq = this.rotationGroup.quaternion.clone(), this.cz = this.rotationGroup.position.z, this.currentModelPos = this.modelGroup.position.clone(), this.cslabNear = this.slabNear, this.cslabFar = this.slabFar;
						let r = this;
						e.targetTouches && e.targetTouches.length === 1 && (this.longTouchTimeout = setTimeout(function() {
							if (r.touchHold == 1) {
								r.glDOM = r.renderer.domElement;
								let t = e.targetTouches[0], n = new PointerEvent("contextmenu", Object.assign(Object.assign({}, e), {
									pageX: t.pageX,
									pageY: t.pageY,
									screenX: t.screenX,
									screenY: t.screenY,
									clientX: t.clientX,
									clientY: t.clientY
								}));
								r.glDOM.dispatchEvent(n);
							}
						}, this.longTouchDuration));
					}
					_handleMouseUp(e) {
						if (this.touchHold = !1, this.isDragging && this.scene) {
							var t = this.getX(e), n = this.getY(e);
							if (this.closeEnoughForClick(e) && this.isInViewer(t, n)) {
								let r = this.mouseXY(t, n);
								this.handleClickSelection(r.x, r.y, e);
							}
						}
						this.isDragging = !1;
					}
					_handleMouseScroll(e) {
						if (e.preventDefault(), this.scene) {
							var t = this.getX(e), n = this.getY(e);
							if (t !== void 0 && !(!this.control_all && !this.isInViewer(t, n))) {
								var r = (this.CAMERA_Z - this.rotationGroup.position.z) * .85, i = 1;
								if (e.ctrlKey && (i = -1), e.detail) this.rotationGroup.position.z += i * r * e.detail / 10;
								else if (e.wheelDelta) {
									let t = e.wheelDelta * 600 / (e.wheelDelta + 600);
									this.rotationGroup.position.z -= i * r * t / 400;
								}
								this.rotationGroup.position.z = this.adjustZoomToLimits(this.rotationGroup.position.z), this.show();
							}
						}
					}
					pngURI() {
						return this.getCanvas().toDataURL("image/png");
					}
					apngURI(e) {
						let t = this;
						return e ||= 1, new Promise(function(n) {
							let i = 0, a = t.viewChangeCallback, o = [], s = [], c = Date.now();
							t.viewChangeCallback = function() {
								s.push(Date.now() - c), c = Date.now(), o.push(new Promise((e) => {
									t.getCanvas().toBlob(function(t) {
										t.arrayBuffer().then(e);
									}, "image/png");
								})), i += 1, i == e && (t.viewChangeCallback = a, Promise.all(o).then((e) => {
									let i = [];
									for (let t = 0; t < e.length; t++) {
										let n = (0, r.decode)(e[t]);
										i.push((0, r.toRGBA8)(n)[0]);
									}
									let a = t.getCanvas().width, o = t.getCanvas().height, c = (0, r.encode)(i, a, o, 0, s), l = new Blob([c], { type: "image/png" }), u = new FileReader();
									u.onload = function(e) {
										n(e.target.result);
									}, u.readAsDataURL(l);
								}));
							};
						});
					}
					getCanvas() {
						return this.glDOM;
					}
					getRenderer() {
						return this.renderer;
					}
					setHoverDuration(e) {
						this.hoverDuration = e;
					}
					mouseXY(e, t) {
						let n = this.canvasOffset(), r = this.renderer.getXRatio(), i = this.renderer.getYRatio(), a = this.col, o = this.row, s = a * (this.WIDTH / r), c = (i - o - 1) * (this.HEIGHT / i);
						return {
							x: (e - n.left - s) / (this.WIDTH / r) * 2 - 1,
							y: -((t - n.top - c) / (this.HEIGHT / i)) * 2 + 1
						};
					}
					_handleMouseMove(e) {
						clearTimeout(this.hoverTimeout), e.preventDefault();
						let t = this.getX(e), n = this.getY(e);
						if (t === void 0) return;
						let r = this.renderer.getXRatio(), i = this.renderer.getYRatio(), a = this.mouseXY(t, n), o = this;
						this.current_hover !== null && this.handleHoverContinue(a.x, a.y);
						var s = 0;
						if (!(!this.control_all && !this.isInViewer(t, n)) && this.scene && (this.hoverables.length > 0 && (this.hoverTimeout = setTimeout(function() {
							o.handleHoverSelection(a.x, a.y, e);
						}, this.hoverDuration)), this.isDragging)) {
							e.targetTouches && (e.targetTouches.length > 1 || e.targetTouches.length === 1 && !this.closeEnoughForClick(e)) && clearTimeout(this.longTouchTimeout);
							var c = (t - this.mouseStartX) / this.WIDTH, l = (n - this.mouseStartY) / this.HEIGHT;
							if (this.touchDistanceStart != 0 && e.targetTouches && e.targetTouches.length == 2) {
								var u = this.calcTouchDistance(e);
								s = 2, l = (u - this.touchDistanceStart) * 2 / (this.WIDTH + this.HEIGHT);
							} else e.targetTouches && e.targetTouches.length == 3 && (s = 1);
							c *= r, l *= i;
							var d = Math.hypot(c, l), f;
							if (s == 3 || this.mouseButton == 3 && e.ctrlKey) this.slabNear = this.cslabNear + c * 100, this.slabFar = this.cslabFar - l * 100;
							else if (s == 2 || this.mouseButton == 3 || e.shiftKey) f = (this.CAMERA_Z - this.rotationGroup.position.z) * .85, f < 80 && (f = 80), this.rotationGroup.position.z = this.cz + l * f, this.rotationGroup.position.z = this.adjustZoomToLimits(this.rotationGroup.position.z);
							else if (s == 1 || this.mouseButton == 2 || e.ctrlKey) {
								var p = this.screenOffsetToModel(r * (t - this.mouseStartX), i * (n - this.mouseStartY));
								this.modelGroup.position.addVectors(this.currentModelPos, p);
							} else if ((s === 0 || this.mouseButton == 1) && d !== 0) {
								var m = Math.sin(d * Math.PI) / d;
								this.dq.x = Math.cos(d * Math.PI), this.dq.y = 0, this.dq.z = m * c, this.dq.w = -m * l, this.rotationGroup.quaternion.set(1, 0, 0, 0), this.rotationGroup.quaternion.multiply(this.dq), this.rotationGroup.quaternion.multiply(this.cq);
							}
							this.show();
						}
					}
					_handleContextMenu(e) {
						if (e.preventDefault(), this.closeEnoughForClick(e)) {
							var t = this.mouseStartX, n = this.mouseStartY, r = this.canvasOffset();
							let a = this.mouseXY(t, n), o = a.x, s = a.y, c = this.targetedObjects(o, s, this.contextMenuEnabledObjects);
							var i = null;
							c.length && (i = c[0].clickable);
							var r = this.canvasOffset(), t = this.mouseStartX - r.left, n = this.mouseStartY - r.top;
							this.userContextMenuHandler && (this.userContextMenuHandler(i, t, n, c, e), this.isDragging = !1);
						}
					}
					setContainer(e) {
						let t = (0, h.getElement)(e) || this.container;
						return this.initContainer(t), this;
					}
					setBackgroundColor(e, t) {
						(t === void 0 || t < 0 || t > 1) && (t = 1);
						var n = m.CC.color(e);
						return this.scene.fog.color = n, this.bgColor = n.getHex(), this.renderer.setClearColorHex(n.getHex(), t), this.show(), this;
					}
					setProjection(e) {
						this.camera.ortho = e === "orthographic", this.setSlabAndFog();
					}
					setViewStyle(e) {
						if (e ||= {}, e.style = e.style || "", e.style.includes("outline") ? this.renderer.enableOutline(e) : this.renderer.disableOutline(), e.style.includes("ambientOcclusion")) {
							var t = {};
							e.strength && (t.strength = e.strength), e.radius && (t.radius = e.radius), this.renderer.enableAmbientOcclusion(t);
						} else this.renderer.disableAmbientOcclusion();
						return this;
					}
					updateSize() {
						this.renderer.setSize(this.WIDTH, this.HEIGHT), this.ASPECT = this.renderer.getAspect(this.WIDTH, this.HEIGHT), this.renderer.setSize(this.WIDTH, this.HEIGHT), this.camera.aspect = this.ASPECT, this.camera.updateProjectionMatrix();
					}
					setWidth(e) {
						return this.WIDTH = e || this.WIDTH, this.updateSize(), this;
					}
					setHeight(e) {
						return this.HEIGHT = e || this.HEIGHT, this.updateSize(), this;
					}
					resize() {
						this.WIDTH = this.getWidth(), this.HEIGHT = this.getHeight();
						let e = !1;
						if (this.renderer.isLost() && this.WIDTH > 0 && this.HEIGHT > 0) {
							let t = !1, n = this.container.querySelector("canvas");
							n && n != this.renderer.getCanvas() ? this.config.canvas = n : (n.remove(), this.config && this.config.canvas != null && (delete this.config.canvas, t = !0)), this.setupRenderer(), this.initContainer(this.container), this.renderer.setClearColorHex(this.bgColor, this.config.backgroundAlpha), e = !0, t && (this.config.canvas = this.renderer.getCanvas());
						}
						if (this.WIDTH == 0 || this.HEIGHT == 0 ? this.animated && this._viewer.pauseAnimate() : this.animated && this._viewer.resumeAnimate(), this.updateSize(), e) {
							let e = this.renderer.supportedExtensions();
							if (e.regen = !0, this.viewers) for (let t = 0, n = this.viewers.length; t < n; t++) for (let n = 0, r = this.viewers[t].length; n < r; n++) this.viewers[t][n].render(null, e);
							this._viewer.render(null, e);
						} else this.WIDTH > 0 && this.HEIGHT > 0 && this.show();
						return this;
					}
					getModel(e) {
						return e === void 0 ? this.models.length == 0 ? null : this.models[this.models.length - 1] : e instanceof a.GLModel ? e : e in this.models ? this.models[e] : this.models.length == 0 ? null : this.models[this.models.length - 1];
					}
					spin(e, t = 1, n = !1) {
						if (clearInterval(this.spinInterval), e === void 0 && (e = "y"), typeof e == "boolean") {
							if (e) e = "y";
							else return;
						}
						Array.isArray(e) && (e = {
							x: e[0],
							y: e[1],
							z: e[2]
						});
						var r = this;
						this.spinInterval = setInterval(function() {
							!r.getCanvas().isConnected && r.renderer.isLost() && clearInterval(r.spinInterval), (!n || r.container.checkVisibility && r.container.checkVisibility()) && r.rotate(1 * t, e);
						}, 25);
					}
					animateMotion(e, t, n, r, i, a) {
						var o = 20, s = Math.ceil(e / o);
						s < 1 && (s = 1), this.incAnim();
						var c = {
							mpos: this.modelGroup.position.clone(),
							rz: this.rotationGroup.position.z,
							rot: this.rotationGroup.quaternion.clone(),
							cam: this.lookingAt.clone()
						};
						if (t) {
							let e = Array(s);
							for (let t = 0; t < s; t++) {
								let o = (t + 1) / s, l = {
									mpos: c.mpos,
									rz: c.rz,
									rot: c.rot
								};
								l.mpos = n.clone().sub(c.mpos).multiplyScalar(o).add(c.mpos), l.rz = c.rz + o * (r - c.rz), l.rot = v.slerp(c.rot, i, o), l.cam = a.clone().sub(c.cam).multiplyScalar(o).add(c.cam), e[t] = l;
							}
							let t = 0, l = this, u = function() {
								var n = e[t];
								t += 1, l.modelGroup.position = n.mpos, l.rotationGroup.position.z = n.rz, l.rotationGroup.quaternion = n.rot, l.camera.lookAt(n.cam), t < e.length ? setTimeout(u, o) : l.decAnim(), l.show();
							};
							setTimeout(u, o);
						} else {
							var l = {};
							let e = 1 / s;
							if (n && (l.mpos = n.clone().sub(c.mpos).multiplyScalar(e)), r !== void 0 && r != null && (l.rz = e * (r - c.rz)), i) {
								var u = v.slerp(c.rot, i, e);
								l.rot = c.rot.clone().inverse().multiply(u);
							}
							a && (l.cam = a.clone().sub(c.cam).multiplyScalar(e));
							let t = 0, d = this, f = function() {
								t += 1, l.mpos && d.modelGroup.position.add(l.mpos), l.rz && (d.rotationGroup.position.z += l.rz), l.rot && d.rotationGroup.quaternion.multiply(l.rot), l.cam && (d.lookingAt.add(l.cam), d.camera.lookAt(d.lookingAt)), t < s ? setTimeout(f, o) : d.decAnim(), d.show();
							};
							setTimeout(f, o);
						}
					}
					rotate(e, t = "y", n = 0, r = !1) {
						if (t == "x" ? t = {
							x: 1,
							y: 0,
							z: 0
						} : t == "y" ? t = {
							x: 0,
							y: 1,
							z: 0
						} : t == "z" && (t = {
							x: 0,
							y: 0,
							z: 1
						}), t == "vx" ? t = {
							vx: 1,
							vy: 0,
							vz: 0
						} : t == "vy" ? t = {
							vx: 0,
							vy: 1,
							vz: 0
						} : t == "vz" && (t = {
							vx: 0,
							vy: 0,
							vz: 1
						}), t.vx !== void 0) {
							var i = new p.Vector3(t.vx, t.vy, t.vz);
							i.applyQuaternion(this.rotationGroup.quaternion), t = {
								x: i.x,
								y: i.y,
								z: i.z
							};
						}
						var a = function(e) {
							var n = Math.sin(e / 2), r = Math.cos(e / 2), i = 0, a = 0, o = 0;
							return i = t.x * n, a = t.y * n, o = t.z * n, new p.Quaternion(i, a, o, r).normalize();
						}(Math.PI * e / 180);
						if (n) {
							var o = new p.Quaternion().copy(this.rotationGroup.quaternion).multiply(a);
							this.animateMotion(n, r, this.modelGroup.position, this.rotationGroup.position.z, o, this.lookingAt);
						} else this.rotationGroup.quaternion.multiply(a), this.show();
						return this;
					}
					surfacesFinished() {
						for (var e in this.surfaces) if (!this.surfaces[e][0].done) return !1;
						return !0;
					}
					getView() {
						if (!this.modelGroup) return [
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							1
						];
						var e = this.modelGroup.position, t = this.rotationGroup.quaternion;
						return [
							e.x,
							e.y,
							e.z,
							this.rotationGroup.position.z,
							t.x,
							t.y,
							t.z,
							t.w
						];
					}
					setView(e, t) {
						return e === void 0 || !(e instanceof Array || e.length !== 8) || !this.modelGroup || !this.rotationGroup ? this : (this.modelGroup.position.x = e[0], this.modelGroup.position.y = e[1], this.modelGroup.position.z = e[2], this.rotationGroup.position.z = e[3], this.rotationGroup.quaternion.x = e[4], this.rotationGroup.quaternion.y = e[5], this.rotationGroup.quaternion.z = e[6], this.rotationGroup.quaternion.w = e[7], e[8] !== void 0 && (this.rotationGroup.position.x = e[8], this.rotationGroup.position.y = e[9]), this.show(t), this);
					}
					render(e, t) {
						this.renderer.setViewport(), this.updateClickables();
						var n = this.getView();
						this.stateChangeCallback && this.stateChangeCallback(this.getInternalState());
						var r, i;
						for (t ||= this.renderer.supportedExtensions(), r = 0; r < this.models.length; r++) this.models[r] && this.models[r].globj(this.modelGroup, t);
						for (r = 0; r < this.shapes.length; r++) this.shapes[r] && (this.shapes[r].frame === void 0 || this.viewer_frame < 0 || this.shapes[r].frame < 0 || this.shapes[r].frame == this.viewer_frame ? this.shapes[r].globj(this.modelGroup, t) : this.shapes[r].removegl(this.modelGroup));
						for (r = 0; r < this.labels.length; r++) t.regen && (this.labels[r].dispose(), this.modelGroup.remove(this.labels[r].sprite), this.labels[r].setContext(), this.modelGroup.add(this.labels[r].sprite)), this.labels[r] && this.labels[r].frame !== void 0 && this.labels[r].frame >= 0 && (this.modelGroup.remove(this.labels[r].sprite), (this.viewer_frame < 0 || this.labels[r].frame == this.viewer_frame) && this.modelGroup.add(this.labels[r].sprite));
						for (r in this.surfaces) if (this.surfaces.hasOwnProperty(r)) {
							var a = this.surfaces[r];
							for (i = 0; i < a.length; i++) if (a.hasOwnProperty(i)) {
								var o = a[i].geo;
								if (!a[i].finished || t.regen) {
									o.verticesNeedUpdate = !0, o.elementsNeedUpdate = !0, o.normalsNeedUpdate = !0, o.colorsNeedUpdate = !0, o.buffersNeedUpdate = !0, a[i].mat.needsUpdate = !0, a[i].done && (a[i].finished = !0), a[i].lastGL && this.modelGroup.remove(a[i].lastGL);
									var s = null;
									if (a[i].mat instanceof f.LineBasicMaterial ? s = new f.Line(o, a[i].mat) : ("wireframe" in a.style && a.style.wireframe && o.setUpWireframe(), s = new f.Mesh(o, a[i].mat)), a[i].mat.transparent && a[i].mat.opacity == 0 ? s.visible = !1 : s.visible = !0, a[i].symmetries.length > 1 || a[i].symmetries.length == 1 && !a[i].symmetries[0].isIdentity()) {
										var c, l = new f.Object3D();
										for (c = 0; c < a[i].symmetries.length; c++) {
											var u = s.clone();
											u.matrix = a[i].symmetries[c], u.matrixAutoUpdate = !1, l.add(u);
										}
										a[i].lastGL = l, this.modelGroup.add(l);
									} else a[i].lastGL = s, this.modelGroup.add(s);
								}
							}
						}
						return this.setView(n), typeof e == "function" && e(this), this;
					}
					getModelList(e) {
						let t = [];
						if (e === void 0 || e.model === void 0) for (let e = 0; e < this.models.length; e++) this.models[e] && t.push(this.models[e]);
						else {
							let r = e.model;
							Array.isArray(r) || (r = [r]);
							for (let e = 0; e < r.length; e++) if (typeof r[e] == "number") {
								var n = r[e];
								n < 0 && (n += this.models.length), t.push(this.models[n]);
							} else t.push(r[e]);
						}
						return t;
					}
					getAtomsFromSel(e) {
						var t = [];
						e === void 0 && (e = {});
						var n = this.getModelList(e);
						for (let r = 0; r < n.length; r++) t = t.concat(n[r].selectedAtoms(e));
						return t;
					}
					atomIsSelected(e, t) {
						t === void 0 && (t = {});
						for (var n = this.getModelList(t), r = 0; r < n.length; r++) if (n[r].atomIsSelected(e, t)) return !0;
						return !1;
					}
					selectedAtoms(e) {
						return this.getAtomsFromSel(e);
					}
					getUniqueValues(e, t) {
						t === void 0 && (t = {});
						var n = this.getAtomsFromSel(t), r = {};
						for (var i in n) if (n[i].hasOwnProperty(e)) {
							var a = n[i][e];
							r[a] = !0;
						}
						return Object.keys(r);
					}
					pdbData(e) {
						for (var t = this.getAtomsFromSel(e), n = "", r = 0, i = t.length; r < i; ++r) n += t[r].pdbline + "\n";
						return n;
					}
					zoom(e = 2, t = 0, n = !1) {
						var r = (this.CAMERA_Z - this.rotationGroup.position.z) / e, i = this.CAMERA_Z - r;
						return t > 0 ? this.animateMotion(t, n, this.modelGroup.position, this.adjustZoomToLimits(i), this.rotationGroup.quaternion, this.lookingAt) : (this.rotationGroup.position.z = this.adjustZoomToLimits(i), this.show()), this;
					}
					translate(e, t, n = 0, r = !1) {
						var i = e / this.WIDTH, a = t / this.HEIGHT, o = new p.Vector3(0, 0, -this.CAMERA_Z);
						this.projector.projectVector(o, this.camera), o.x -= i, o.y -= a, this.projector.unprojectVector(o, this.camera), o.z = 0;
						var s = this.lookingAt.clone().add(o);
						return n > 0 ? this.animateMotion(n, r, this.modelGroup.position, this.rotationGroup.position.z, this.rotationGroup.quaternion, s) : (this.lookingAt = s, this.camera.lookAt(this.lookingAt), this.show()), this;
					}
					translateScene(e, t, n = 0, r = !1) {
						var i = this.screenOffsetToModel(e, t), a = this.modelGroup.position.clone().add(i);
						return n > 0 ? this.animateMotion(n, r, this.modelGroup.position, this.rotationGroup.position.z, this.rotationGroup.quaternion, this.lookingAt) : (this.modelGroup.position = a, this.show()), this;
					}
					fitSlab(e) {
						e ||= {};
						var t = this.getAtomsFromSel(e), n = (0, h.getExtent)(t), r = n[1][0] - n[0][0], i = n[1][1] - n[0][1], a = n[1][2] - n[0][2], o = Math.hypot(r, i, a);
						return o < 5 && (o = 5), this.slabNear = -o / 1.9, this.slabFar = o / 2, this;
					}
					center(e = {}, t = 0, n = !1) {
						var r, i, a = this.getAtomsFromSel(e), o = (0, h.getExtent)(a);
						(0, h.isEmptyObject)(e) ? (this.shapes.forEach((e) => {
							if (e && e.boundingSphere && e.boundingSphere.center) {
								var t = e.boundingSphere.center, n = e.boundingSphere.radius;
								n > 0 ? (a.push(new p.Vector3(t.x + n, t.y, t.z)), a.push(new p.Vector3(t.x - n, t.y, t.z)), a.push(new p.Vector3(t.x, t.y + n, t.z)), a.push(new p.Vector3(t.x, t.y - n, t.z)), a.push(new p.Vector3(t.x, t.y, t.z + n)), a.push(new p.Vector3(t.x, t.y, t.z - n))) : a.push(t);
							}
						}), o = (0, h.getExtent)(a), r = a, i = o) : (r = this.getAtomsFromSel({}), i = (0, h.getExtent)(r));
						var s = new p.Vector3(o[2][0], o[2][1], o[2][2]), c = i[1][0] - i[0][0], l = i[1][1] - i[0][1], u = i[1][2] - i[0][2], d = Math.hypot(c, l, u);
						d < 5 && (d = 5), this.slabNear = -d / 1.9, this.slabFar = d / 2, c = o[1][0] - o[0][0], l = o[1][1] - o[0][1], u = o[1][2] - o[0][2], d = Math.hypot(c, l, u), d < 5 && (d = 5);
						for (var f = 25, m = 0; m < a.length; m++) if (a[m]) {
							var g = s.distanceToSquared(a[m]);
							g > f && (f = g);
						}
						d = Math.sqrt(f) * 2;
						var _ = s.clone().multiplyScalar(-1);
						return t > 0 ? this.animateMotion(t, n, _, this.rotationGroup.position.z, this.rotationGroup.quaternion, this.lookingAt) : (this.modelGroup.position = _, this.show()), this;
					}
					zoomTo(e = {}, t = 0, n = !1) {
						let r = this.getAtomsFromSel(e), i = (0, h.getExtent)(r), a = i;
						if ((0, h.isEmptyObject)(e)) {
							let e = r && r.length;
							if (this.shapes.forEach((e) => {
								if (e && e.boundingSphere) {
									if (e.boundingSphere.box) {
										let t = e.boundingSphere.box;
										r.push(new p.Vector3(t.min.x, t.min.y, t.min.z)), r.push(new p.Vector3(t.max.x, t.max.y, t.max.z));
									} else if (e.boundingSphere.center) {
										var t = e.boundingSphere.center, n = e.boundingSphere.radius;
										n > 0 ? (r.push(new p.Vector3(t.x + n, t.y, t.z)), r.push(new p.Vector3(t.x - n, t.y, t.z)), r.push(new p.Vector3(t.x, t.y + n, t.z)), r.push(new p.Vector3(t.x, t.y - n, t.z)), r.push(new p.Vector3(t.x, t.y, t.z + n)), r.push(new p.Vector3(t.x, t.y, t.z - n))) : r.push(t);
									}
								}
							}), a = (0, h.getExtent)(r), !e) for (let e = 0; e < 3; e++) i[2][e] = (a[0][e] + a[1][e]) / 2;
						} else {
							let e = this.getAtomsFromSel({});
							a = (0, h.getExtent)(e);
						}
						var o = new p.Vector3(i[2][0], i[2][1], i[2][2]), s = a[1][0] - a[0][0], c = a[1][1] - a[0][1], l = a[1][2] - a[0][2], u = Math.hypot(s, c, l);
						u < 5 && (u = 5), this.slabNear = -u / 1.9, this.slabFar = u / 2, Object.keys(e).length === 0 && (this.slabNear = Math.min(-u * 2, -50), this.slabFar = Math.max(u * 2, 50));
						var d = this.config.minimumZoomToDistance || 5;
						s = i[1][0] - i[0][0], c = i[1][1] - i[0][1], l = i[1][2] - i[0][2], u = Math.hypot(s, c, l), u < d && (u = d);
						for (var f = d * d, m = 0; m < r.length; m++) if (r[m]) {
							var g = o.distanceToSquared(r[m]);
							g > f && (f = g);
						}
						u = Math.sqrt(f) * 2;
						var _ = o.clone().multiplyScalar(-1), v = -(u * .5 / Math.tan(Math.PI / 180 * this.camera.fov / 2) - this.CAMERA_Z);
						return v = this.adjustZoomToLimits(v), t > 0 ? this.animateMotion(t, n, _, v, this.rotationGroup.quaternion, this.lookingAt) : (this.modelGroup.position = _, this.rotationGroup.position.z = v, this.show()), this;
					}
					setSlab(e, t) {
						this.slabNear = e, this.slabFar = t;
					}
					getSlab() {
						return {
							near: this.slabNear,
							far: this.slabFar
						};
					}
					addLabel(e, t = {}, n, r = !1) {
						if (n) {
							var i = (0, h.getExtent)(this.getAtomsFromSel(n));
							t.position = {
								x: i[2][0],
								y: i[2][1],
								z: i[2][2]
							};
						}
						var a = new c.Label(e, t);
						return a.setContext(), this.modelGroup.add(a.sprite), this.labels.push(a), r || this.show(), a;
					}
					addResLabels(e, t, n = !1) {
						let r = this.labels.length;
						return this.applyToModels("addResLabels", e, t, n), this.show(), this.labels.slice(r);
					}
					addPropertyLabels(e, t, n) {
						return this.applyToModels("addPropertyLabels", e, t, n), this.show(), this;
					}
					removeLabel(e) {
						for (var t = 0; t < this.labels.length; t++) if (this.labels[t] == e) {
							this.labels.splice(t, 1), e.dispose(), this.modelGroup.remove(e.sprite);
							break;
						}
						return this.show(), this;
					}
					removeAllLabels() {
						for (var e = 0; e < this.labels.length; e++) this.labels[e] && this.labels[e].sprite && this.modelGroup.remove(this.labels[e].sprite);
						return this.labels.splice(0, this.labels.length), this.show(), this;
					}
					hideAllLabels() {
						for (var e = 0; e < this.labels.length; e++) this.labels[e] && this.labels[e].hide();
						return this.show(), this;
					}
					showAllLabels() {
						for (var e = 0; e < this.labels.length; e++) this.labels[e] && this.labels[e].show();
						return this.show(), this;
					}
					setLabelStyle(e, t) {
						return this.modelGroup.remove(e.sprite), e.dispose(), e.stylespec = t, e.setContext(), this.modelGroup.add(e.sprite), this.show(), e;
					}
					setLabelText(e, t) {
						return this.modelGroup.remove(e.sprite), e.dispose(), e.text = t, e.setContext(), this.modelGroup.add(e.sprite), this.show(), e;
					}
					addShape(e) {
						e ||= {};
						var t = new o.GLShape(e);
						return t.shapePosition = this.shapes.length, this.shapes.push(t), t;
					}
					removeShape(e) {
						if (!e) return this;
						for (e.removegl(this.modelGroup), delete this.shapes[e.shapePosition]; this.shapes.length > 0 && this.shapes[this.shapes.length - 1] === void 0;) this.shapes.pop();
						return this;
					}
					removeAllShapes() {
						for (var e = 0; e < this.shapes.length; e++) {
							var t = this.shapes[e];
							t && t.removegl(this.modelGroup);
						}
						return this.shapes.splice(0, this.shapes.length), this;
					}
					getSelectionCenter(e) {
						if (e.hasOwnProperty("x") && e.hasOwnProperty("y") && e.hasOwnProperty("z")) return e;
						var t = this.getAtomsFromSel(e);
						if (t.length == 0) return {
							x: 0,
							y: 0,
							z: 0
						};
						var n = (0, h.getExtent)(t);
						return {
							x: n[0][0] + (n[1][0] - n[0][0]) / 2,
							y: n[0][1] + (n[1][1] - n[0][1]) / 2,
							z: n[0][2] + (n[1][2] - n[0][2]) / 2
						};
					}
					addSphere(e) {
						e ||= {}, e.center = this.getSelectionCenter(e.center);
						var t = new o.GLShape(e);
						return t.shapePosition = this.shapes.length, t.addSphere(e), this.shapes.push(t), t.finalize(), t;
					}
					addBox(e = {}) {
						e.corner != null && (e.corner = this.getSelectionCenter(e.corner)), e.center != null && (e.center = this.getSelectionCenter(e.center));
						var t = new o.GLShape(e);
						return t.shapePosition = this.shapes.length, t.addBox(e), this.shapes.push(t), t.finalize(), t;
					}
					addArrow(e = {}) {
						e.start = this.getSelectionCenter(e.start), e.end = this.getSelectionCenter(e.end);
						var t = new o.GLShape(e);
						return t.shapePosition = this.shapes.length, t.addArrow(e), this.shapes.push(t), t.finalize(), t;
					}
					addCylinder(e = {}) {
						e.start = this.getSelectionCenter(e.start), e.end = this.getSelectionCenter(e.end);
						var t = new o.GLShape(e);
						return t.shapePosition = this.shapes.length, e.dashed ? t.addDashedCylinder(e) : t.addCylinder(e), this.shapes.push(t), t.finalize(), t;
					}
					addCurve(e = {}) {
						var t = new o.GLShape(e);
						return t.shapePosition = this.shapes.length, t.addCurve(e), this.shapes.push(t), t.finalize(), t;
					}
					addLine(e = {}) {
						e.start = this.getSelectionCenter(e.start), e.end = this.getSelectionCenter(e.end), e.wireframe = !0;
						var t = new o.GLShape(e);
						return t.shapePosition = this.shapes.length, e.dashed ? t = this.addLineDashed(e, t) : t.addLine(e), this.shapes.push(t), t.finalize(), t;
					}
					addUnitCell(e, t) {
						e = this.getModel(e), t ||= {
							alabel: "a",
							blabel: "b",
							clabel: "c"
						}, t.box = t.box || {}, t.astyle = t.astyle || {
							color: "red",
							radius: .1,
							midpos: -1
						}, t.bstyle = t.bstyle || {
							color: "green",
							radius: .1,
							midpos: -1
						}, t.cstyle = t.cstyle || {
							color: "blue",
							radius: .1,
							midpos: -1
						}, t.alabelstyle = t.alabelstyle || {
							fontColor: "red",
							showBackground: !1,
							alignment: "center",
							inFront: !1
						}, t.blabelstyle = t.blabelstyle || {
							fontColor: "green",
							showBackground: !1,
							alignment: "center",
							inFront: !1
						}, t.clabelstyle = t.clabelstyle || {
							fontColor: "blue",
							showBackground: !1,
							alignment: "center",
							inFront: !1
						}, e.unitCellObjects && this.removeUnitCell(e), e.unitCellObjects = {
							shapes: [],
							labels: []
						};
						var n = e.getCrystData(), r = null;
						if (n) {
							if (n.matrix) r = n.matrix;
							else {
								var i = n.a, a = n.b, s = n.c, c = n.alpha, l = n.beta, u = n.gamma;
								c = c * Math.PI / 180, l = l * Math.PI / 180, u = u * Math.PI / 180;
								var d = Math.cos(l), f = (Math.cos(c) - Math.cos(l) * Math.cos(u)) / Math.sin(u), m = Math.sqrt(Math.max(0, 1 - d * d - f * f));
								r = new p.Matrix3(i, a * Math.cos(u), s * d, 0, a * Math.sin(u), s * f, 0, 0, s * m);
							}
							var h = [
								new p.Vector3(0, 0, 0),
								new p.Vector3(1, 0, 0),
								new p.Vector3(0, 1, 0),
								new p.Vector3(0, 0, 1),
								new p.Vector3(1, 1, 0),
								new p.Vector3(0, 1, 1),
								new p.Vector3(1, 0, 1),
								new p.Vector3(1, 1, 1)
							];
							if (n.matrix4) for (let e = 0; e < h.length; e++) n.size && h[e].multiplyVectors(h[e], n.size), h[e] = h[e].applyMatrix4(n.matrix4);
							else for (let e = 0; e < h.length; e++) h[e] = h[e].applyMatrix3(r);
							if (t.box && !t.box.hidden) {
								t.box.wireframe = !0;
								var g = new o.GLShape(t.box);
								g.shapePosition = this.shapes.length, g.addLine({
									start: h[0],
									end: h[1]
								}), g.addLine({
									start: h[0],
									end: h[2]
								}), g.addLine({
									start: h[1],
									end: h[4]
								}), g.addLine({
									start: h[2],
									end: h[4]
								}), g.addLine({
									start: h[0],
									end: h[3]
								}), g.addLine({
									start: h[3],
									end: h[5]
								}), g.addLine({
									start: h[2],
									end: h[5]
								}), g.addLine({
									start: h[1],
									end: h[6]
								}), g.addLine({
									start: h[4],
									end: h[7]
								}), g.addLine({
									start: h[6],
									end: h[7]
								}), g.addLine({
									start: h[3],
									end: h[6]
								}), g.addLine({
									start: h[5],
									end: h[7]
								}), this.shapes.push(g), e.unitCellObjects.shapes.push(g), g.finalize();
							}
							if (!t.astyle.hidden) {
								t.astyle.start = h[0], t.astyle.end = h[1];
								let n = this.addArrow(t.astyle);
								e.unitCellObjects.shapes.push(n);
							}
							if (!t.bstyle.hidden) {
								t.bstyle.start = h[0], t.bstyle.end = h[2];
								let n = this.addArrow(t.bstyle);
								e.unitCellObjects.shapes.push(n);
							}
							if (!t.cstyle.hidden) {
								t.cstyle.start = h[0], t.cstyle.end = h[3];
								let n = this.addArrow(t.cstyle);
								e.unitCellObjects.shapes.push(n);
							}
							if (t.alabel) {
								t.alabelstyle.position = h[1];
								let n = this.addLabel(t.alabel, t.alabelstyle);
								e.unitCellObjects.labels.push(n);
							}
							if (t.blabel) {
								t.blabelstyle.position = h[2];
								let n = this.addLabel(t.blabel, t.blabelstyle);
								e.unitCellObjects.labels.push(n);
							}
							if (t.clabel) {
								t.clabelstyle.position = h[3];
								let n = this.addLabel(t.clabel, t.clabelstyle);
								e.unitCellObjects.labels.push(n);
							}
						}
					}
					removeUnitCell(e) {
						if (e = this.getModel(e), e.unitCellObjects) {
							let t = this;
							e.unitCellObjects.shapes.forEach(function(e) {
								t.removeShape(e);
							}), e.unitCellObjects.labels.forEach(function(e) {
								t.removeLabel(e);
							});
						}
						delete e.unitCellObjects;
					}
					replicateUnitCell(e = 3, t = e, n = t, r, i, a) {
						r = this.getModel(r);
						let o = r.getCrystData();
						if (o) {
							let s = r.selectedAtoms({}), c = o.matrix, l = function(e) {
								return e % 2 == 0 ? -e / 2 : Math.ceil(e / 2);
							};
							e <= 1 && t <= 1 && n <= 1 && (a = !0, e = t = n = 3);
							let u = function(e, t, n) {
								return !1;
							};
							if (a) {
								let e = new p.Matrix3().getInverse3(c);
								u = function(t, n, r) {
									let i = new p.Vector3(t, n, r).applyMatrix3(e);
									return !(i.x > -1e-4 && i.x < 1.0001 && i.y > -1e-4 && i.y < 1.0001 && i.z > -1e-4 && i.z < 1.0001);
								};
							}
							for (let i = 0; i < e; i++) for (let e = 0; e < t; e++) for (let t = 0; t < n; t++) {
								if (i == 0 && e == 0 && t == 0) continue;
								let n = new p.Vector3(l(i), l(e), l(t));
								n.applyMatrix3(c);
								let a = [];
								for (let e = 0; e < s.length; e++) {
									let t = s[e].x + n.x, r = s[e].y + n.y, i = s[e].z + n.z;
									if (u(t, r, i)) continue;
									let o = {};
									for (let t in s[e]) o[t] = s[e][t];
									o.x = t, o.y = r, o.z = i, a.push(o);
								}
								r.addAtoms(a);
							}
							i && r.assignBonds();
						}
					}
					addLineDashed(e, t) {
						e.dashLength = e.dashLength || .5, e.gapLength = e.gapLength || .5;
						var n = e.start ? new p.Vector3(e.start.x || 0, e.start.y || 0, e.start.z || 0) : new p.Vector3(0, 0, 0), r = e.end ? new p.Vector3(e.end.x, e.end.y || 0, e.end.z || 0) : new p.Vector3(0, 0, 0), i = new p.Vector3(), a = new p.Vector3(), o = new p.Vector3(), s, c, l, u = n.clone(), d = 0;
						for (i.subVectors(r, n), s = i.length(), i.normalize(), a = i.clone(), o = i.clone(), a.multiplyScalar(e.dashLength), o.multiplyScalar(e.gapLength), c = a.length(), l = o.length(); d < s;) {
							if (d + c > s) {
								e.start = n, e.end = r, t.addLine(e);
								break;
							}
							u.addVectors(n, a), e.start = n, e.end = u, t.addLine(e), n = u.clone(), d += c, u.addVectors(n, o), n = u.clone(), d += l;
						}
						return t.finalize(), t;
					}
					addCustom(e) {
						e ||= {};
						var t = new o.GLShape(e);
						return t.shapePosition = this.shapes.length, t.addCustom(e), this.shapes.push(t), t.finalize(), t;
					}
					addVolumetricData(e, t, n = {}) {
						var r = new u.VolumeData(e, t);
						return n.hasOwnProperty("transferfn") ? this.addVolumetricRender(r, n) : this.addIsosurface(r, n);
					}
					addIsosurface(e, t = {}, n) {
						var r = new o.GLShape(t);
						return r.shapePosition = this.shapes.length, r.addIsosurface(e, t, n, this), this.shapes.push(r), r;
					}
					addVolumetricRender(e, t) {
						t ||= {};
						var n = new d.GLVolumetricRender(e, t, this);
						return n.shapePosition = this.shapes.length, this.shapes.push(n), n;
					}
					hasVolumetricRender() {
						return this.renderer.supportsVolumetric();
					}
					enableFog(e) {
						if (e) {
							this.scene.fog = new f.Fog(this.bgColor, 100, 200), this.config.disableFog = !1;
							let t = e;
							this.fogStart = t.fogStart == null ? .4 : t.fogStart, this.fogEnd = t.fogEnd == null ? 1 : t.fogEnd;
						} else this.config.disableFog = !0, this.show();
					}
					setFrame(e) {
						this.viewer_frame = e;
						let t = this;
						return new Promise(function(n) {
							var r = t.models.map(function(t) {
								return t.setFrame(e);
							});
							Promise.all(r).then(function() {
								n();
							});
						});
					}
					getFrame() {
						return this.viewer_frame;
					}
					getNumFrames() {
						var e = 0;
						for (let t = 0; t < this.models.length; t++) this.models[t].getNumFrames() > e && (e = this.models[t].getNumFrames());
						for (let t = 0; t < this.shapes.length; t++) this.shapes[t].frame && this.shapes[t].frame >= e && (e = this.shapes[t].frame + 1);
						for (let t = 0; t < this.labels.length; t++) this.labels[t].frame && this.labels[t].frame >= e && (e = this.labels[t].frame + 1);
						return e;
					}
					getNextModelId() {
						return this.models.length;
					}
					animate(e) {
						this.incAnim();
						var t = 100, n = "forward", r = Infinity;
						e ||= {}, e.interval && (t = e.interval), e.loop && (n = e.loop), e.reps && (r = e.reps);
						var i = this.getNumFrames(), a = this, o = 0;
						e.startFrame && (o = e.startFrame % i);
						var s = 1;
						e.step && (s = e.step, r /= s);
						var c = 0, l = i * r, u = /* @__PURE__ */ new Date(), d, f, p = function(e) {
							u = /* @__PURE__ */ new Date(), e == "forward" ? a.setFrame(o).then(function() {
								o = (o + s) % i, d();
							}) : e == "backward" ? a.setFrame(i - 1 - o).then(function() {
								o = (o + s) % i, d();
							}) : a.setFrame(o).then(function() {
								o += s, s *= o % (i - 1) == 0 ? -1 : 1, d();
							});
						};
						return d = function() {
							if (a.render(), !a.getCanvas().isConnected) a.stopAnimate();
							else if (++c >= l || !a.isAnimated()) f.cancel(), a.animationTimers.delete(f), a.decAnim();
							else {
								var e = t - ((/* @__PURE__ */ new Date()).getTime() - u.getTime());
								e = e > 0 ? e : 0, f.cancel(), a.animationTimers.delete(f), f = new h.PausableTimer(p, e, n), a.animationTimers.add(f);
							}
						}, f = new h.PausableTimer(p, 0, n), this.animationTimers.add(f), this;
					}
					stopAnimate() {
						return this.animated = 0, this.animationTimers.forEach(function(e) {
							e.cancel();
						}), this.animationTimers = /* @__PURE__ */ new Set(), this;
					}
					pauseAnimate() {
						return this.animationTimers.forEach(function(e) {
							e.pause();
						}), this;
					}
					resumeAnimate() {
						return this.animationTimers.forEach(function(e) {
							e.resume();
						}), this;
					}
					isAnimated() {
						return this.animated > 0;
					}
					getModelOpt(e) {
						return e && !e.defaultcolors ? (e.defaultcolors = this.defaultcolors, e.cartoonQuality = e.cartoonQuality || this.config.cartoonQuality) : e === void 0 && (e = {
							defaultcolors: this.defaultcolors,
							cartoonQuality: this.config.cartoonQuality
						}), e;
					}
					addModel(e, t = "", n) {
						n = this.getModelOpt(n);
						var r = new a.GLModel(this.models.length, n, this);
						return r.addMolData(e, t, n), this.models.push(r), r;
					}
					addModels(e, t, n) {
						n = this.getModelOpt(n), n.multimodel = !0, n.frames = !0;
						for (var r = a.GLModel.parseMolData(e, t, n), i = 0; i < r.length; i++) {
							var o = new a.GLModel(this.models.length, n, this);
							o.setAtomDefaults(r[i]), o.addFrame(r[i]), o.setFrame(0), r.modelData && o.setModelData(r.modelData[i]), o.setDontDuplicateAtoms(!n.duplicateAssemblyAtoms), this.models.push(o);
						}
						return this.models;
					}
					addModelsAsFrames(e, t, n) {
						n = this.getModelOpt(n), n.multimodel = !0, n.frames = !0;
						var r = new a.GLModel(this.models.length, n, this);
						return r.addMolData(e, t, n), this.models.push(r), r;
					}
					addAsOneMolecule(e, t, n) {
						n = this.getModelOpt(n), n.multimodel = !0, n.onemol = !0;
						var r = new a.GLModel(this.models.length, n, this);
						return r.addMolData(e, t, n), this.models.push(r), r;
					}
					removeModel(e) {
						if (e = this.getModel(e), e) {
							for (e.removegl(this.modelGroup), delete this.models[e.getID()]; this.models.length > 0 && this.models[this.models.length - 1] === void 0;) this.models.pop();
							return this;
						}
					}
					removeAllModels() {
						for (var e = 0; e < this.models.length; e++) {
							var t = this.models[e];
							t && t.removegl(this.modelGroup);
						}
						return this.models.splice(0, this.models.length), this;
					}
					exportJSON(e, t) {
						var n = {};
						return n.m = t === void 0 ? this.models.map(function(t) {
							return t.toCDObject(e);
						}) : [this.models[t].toCDObject()], JSON.stringify(n);
					}
					exportVRML() {
						var e = this.modelGroup;
						this.applyToModels("removegl", this.modelGroup), this.modelGroup = new f.Object3D(), this.render(null, {
							supportsImposters: !1,
							supportsAIA: !1,
							regen: !0
						});
						var t = "#VRML V2.0 utf8\n" + this.modelGroup.vrml() + "\n";
						return this.applyToModels("removegl", this.modelGroup), this.modelGroup = e, t;
					}
					createModelFrom(e, t = !1) {
						for (var n = new a.GLModel(this.models.length, this.defaultcolors, this), r = 0; r < this.models.length; r++) if (this.models[r]) {
							var i = this.models[r].selectedAtoms(e);
							n.addAtoms(i), t && this.models[r].removeAtoms(i);
						}
						return this.models.push(n), n;
					}
					applyToModels(e, t, n, r, i, a, o) {
						for (var s = this.getModelList(t), c = 0; c < s.length; c++) s[c][e](t, n, r, i, a, o);
					}
					setStyle(e, t) {
						return t === void 0 && (t = e, e = {}), this.applyToModels("setStyle", e, t, !1), this;
					}
					addStyle(e, t) {
						return t === void 0 && (t = e, e = {}), this.applyToModels("setStyle", e, t, !0), this;
					}
					setClickable(e, t, n) {
						return this.applyToModels("setClickable", e, t, n), this;
					}
					setHoverable(e, t, n, r) {
						return this.applyToModels("setHoverable", e, t, n, r), this;
					}
					enableContextMenu(e, t) {
						return this.applyToModels("enableContextMenu", e, t), this;
					}
					vibrate(e, t, n, r) {
						return this.applyToModels("vibrate", e, t, n, r), this;
					}
					setColorByProperty(e, t, n, r) {
						return this.applyToModels("setColorByProperty", e, t, n, r), this;
					}
					setColorByElement(e, t) {
						return this.applyToModels("setColorByElement", e, t), this;
					}
					static getAtomsWithin(e, t) {
						var n = [];
						for (let i = 0; i < e.length; i++) {
							var r = e[i];
							r !== void 0 && (r.x < t[0][0] || r.x > t[1][0] || r.y < t[0][1] || r.y > t[1][1] || r.z < t[0][2] || r.z > t[1][2] || n.push(r));
						}
						return n;
					}
					static volume(e) {
						var t = e[1][0] - e[0][0], n = e[1][1] - e[0][1], r = e[1][2] - e[0][2];
						return t * n * r;
					}
					carveUpExtent(e, t, n) {
						let r = [], i = {};
						for (let e = 0, n = t.length; e < n; e++) i[t[e].index] = e;
						let a = function(e) {
							let t = [];
							for (let n = 0, r = e.length; n < r; n++) e[n].index in i && t.push(i[e[n].index]);
							return t;
						}, o = function(e) {
							let t = [];
							return t[0] = [
								e[0][0],
								e[0][1],
								e[0][2]
							], t[1] = [
								e[1][0],
								e[1][1],
								e[1][2]
							], t;
						}, s = function(e) {
							if (v.volume(e) < v.maxVolume) return [e];
							var t = e[1][0] - e[0][0], n = e[1][1] - e[0][1], r = e[1][2] - e[0][2], i = t > n && t > r ? 0 : n > t && n > r ? 1 : 2, a = o(e), c = o(e), l = (e[1][i] - e[0][i]) / 2 + e[0][i];
							a[1][i] = l, c[0][i] = l;
							var u = s(a), d = s(c);
							return u.concat(d);
						}, c = s(e), l = 6;
						for (let e = 0, i = c.length; e < i; e++) {
							let i = o(c[e]);
							i[0][0] -= 6, i[0][1] -= 6, i[0][2] -= 6, i[1][0] += 6, i[1][1] += 6, i[1][2] += 6;
							let s = v.getAtomsWithin(t, i), l = v.getAtomsWithin(n, c[e]);
							r.push({
								extent: c[e],
								atoms: a(s),
								toshow: a(l)
							});
						}
						return r;
					}
					static generateSurfaceMesh(e, t, n) {
						var r = new f.Geometry(!0), i = r.updateGeoGroup(0), a = [];
						for (let t = 0, n = e.length; t < n; t++) {
							var o = e[t];
							o && (o.surfaceColor === void 0 ? o.color && (a[t] = m.CC.color(o.color)) : a[t] = o.surfaceColor);
						}
						var s = i.vertexArray, c = t.vertices;
						for (let e = 0, t = c.length; e < t; e++) {
							let t = i.vertices * 3;
							s[t] = c[e].x, s[t + 1] = c[e].y, s[t + 2] = c[e].z, i.vertices++;
						}
						var l = i.colorArray;
						let u = i.atomArray;
						if (n.voldata && n.volscheme) {
							var d = n.volscheme, h = n.voldata, g = d.range() || [-1, 1];
							for (let t = 0, n = c.length; t < n; t++) {
								let n = c[t].atomid, r = h.getVal(c[t].x, c[t].y, c[t].z), i = m.CC.color(d.valueToHex(r, g)), a = t * 3;
								l[a] = i.r, l[a + 1] = i.g, l[a + 2] = i.b, u[t] = e[n];
							}
						} else if (a.length > 0) for (let t = 0, n = c.length; t < n; t++) {
							let n = c[t].atomid, r = t * 3;
							l[r] = a[n].r, l[r + 1] = a[n].g, l[r + 2] = a[n].b, u[t] = e[n];
						}
						var _ = t.faces;
						i.faceidx = _.length, r.initTypedArrays();
						var v = i.vertexArray, y = i.normalArray, b, x, S, C;
						for (let e = 0, t = _.length; e < t; e += 3) {
							var w = _[e], T = _[e + 1], E = _[e + 2], D = w * 3, O = T * 3, k = E * 3;
							b = new p.Vector3(v[D], v[D + 1], v[D + 2]), x = new p.Vector3(v[O], v[O + 1], v[O + 2]), S = new p.Vector3(v[k], v[k + 1], v[k + 2]), S.subVectors(S, x), b.subVectors(b, x), S.cross(b), C = S, C.normalize(), y[D] += C.x, y[O] += C.x, y[k] += C.x, y[D + 1] += C.y, y[O + 1] += C.y, y[k + 1] += C.y, y[D + 2] += C.z, y[O + 2] += C.z, y[k + 2] += C.z;
						}
						return i.faceArray = new Uint16Array(_), new f.Mesh(r, n);
					}
					static generateMeshSyncHelper(e, t, n, r, i, a) {
						var o = new l.ProteinSurface();
						return o.initparm(t, e !== 1, a), o.fillvoxels(i, n), o.buildboundary(), (e == l.SurfaceType.SES || e == l.SurfaceType.MS) && (o.fastdistancemap(), o.boundingatom(!1), o.fillvoxelswaals(i, n)), o.marchingcube(e), o.getFacesAndVertices(r);
					}
					static getMatWithStyle(e) {
						let t = null;
						for (var n in t = e.onesided ? new f.MeshLambertMaterial() : new f.MeshDoubleLambertMaterial(), t.vertexColors = f.Coloring.VertexColors, e) n === "color" || n === "map" || e.hasOwnProperty(n) && (t[n] = e[n]);
						return e.opacity !== void 0 && (e.opacity === 1 ? t.transparent = !1 : t.transparent = !0), e.wireframe !== void 0 && (t.wireframe = e.wireframe), t;
					}
					addMesh(e) {
						let t = {
							geo: e.geometry,
							mat: e.material,
							done: !0,
							finished: !1
						};
						var n = this.nextSurfID();
						return this.surfaces[n] = new _([t]), n;
					}
					static shallowCopy(e) {
						var t = [];
						let n = e.length;
						for (let r = 0; r < n; r++) t[r] = (0, h.extend)({}, e[r]);
						return t;
					}
					addSurface(e, t = {}, n = {}, r, i, a) {
						let c = this.nextSurfID(), u = null, d = this, m = l.SurfaceType.VDW;
						typeof e == "string" ? v.surfaceTypeMap[e.toUpperCase()] === void 0 ? console.log("Surface type : " + e + " is not recognized") : m = v.surfaceTypeMap[e] : typeof e == "number" && (m = e);
						var g = null, y = null, b = v.shallowCopy(this.getAtomsFromSel(n));
						g = r ? v.shallowCopy(this.getAtomsFromSel(r)) : b, (0, h.adjustVolumeStyle)(t);
						var x = !1, S;
						for (S = 0; S < this.models.length; S++) if (this.models[S]) {
							var C = this.models[S].getSymmetries();
							if (C.length > 1 || C.length == 1 && !C[0].isIdentity()) {
								x = !0;
								break;
							}
						}
						var w = function(e, n, r) {
							y = i ? v.shallowCopy(d.getAtomsFromSel(i)) : r;
							var a, f = (0, h.getExtent)(r, !0);
							if (t.map && t.map.prop) {
								var p = t.map.prop;
								let e = (0, s.getGradient)(t.map.scheme || t.map.gradient || new s.Gradient.RWB()), n = e.range();
								n ||= (0, h.getPropertyRange)(r, p), t.colorscheme = {
									prop: p,
									gradient: e
								};
							}
							for (let e = 0, r = n.length; e < r; e++) a = n[e], a.surfaceColor = (0, h.getColorFromStyle)(a, t);
							var g = v.volume(f), _ = d.carveUpExtent(f, n, r);
							if (y && y.length && y.length > 0) {
								var b = (0, h.getExtent)(y, !0);
								_.sort(function(e, t) {
									var n = function(e, t) {
										var n = e.extent, r = n[1][0] - n[0][0], i = n[1][1] - n[0][1], a = n[1][2] - n[0][2], o = r - t[2][0];
										o *= o;
										var s = i - t[2][1];
										s *= s;
										var c = a - t[2][2];
										return c *= c, o + s + c;
									};
									return n(e, b) - n(t, b);
								});
							}
							var x = [];
							for (let e = 0, t = n.length; e < t; e++) a = n[e], x[e] = {
								x: a.x,
								y: a.y,
								z: a.z,
								serial: e,
								elem: a.elem
							};
							var S = !!l.syncSurface;
							if ((typeof $3Dmol > "u" || $3Dmol.SurfaceWorker === void 0) && (console.log("$3Dmol.SurfaceWorker is not defined, using synchronous surface generation."), S = !0), S) {
								var C = function(t) {
									return new Promise(function(r) {
										for (var i = v.generateMeshSyncHelper(m, _[t].extent, _[t].atoms, _[t].toshow, x, g), a = (0, o.splitMesh)({
											vertexArr: i.vertices,
											faceArr: i.faces
										}), s = 0, c = a.length; s < c; s++) {
											i = {
												vertices: a[s].vertexArr,
												faces: a[s].faceArr
											};
											var l = v.generateSurfaceMesh(n, i, u);
											(0, h.mergeGeos)(e.geo, l);
										}
										d.render(), r();
									});
								}, w = [];
								for (let e = 0; e < _.length; e++) w.push(C(e));
								return Promise.all(w).then(function() {
									return e.done = !0, d.render(), Promise.resolve(c);
								});
							}
							var T = [];
							m < 0 && (m = 0);
							for (let e = 0, t = v.numWorkers; e < t; e++) {
								var E = new Worker($3Dmol.SurfaceWorker);
								T.push(E), E.postMessage({
									type: -1,
									atoms: x,
									volume: g
								});
							}
							return new Promise(function(t, r) {
								var i = 0, a = function() {
									!T || !T.length || T.forEach(function(e) {
										e && e.terminate && e.terminate();
									});
								}, s = function(r) {
									for (var s = (0, o.splitMesh)({
										vertexArr: r.data.vertices,
										faceArr: r.data.faces
									}), l = 0, f = s.length; l < f; l++) {
										var p = {
											vertices: s[l].vertexArr,
											faces: s[l].faceArr
										}, m = v.generateSurfaceMesh(n, p, u);
										(0, h.mergeGeos)(e.geo, m);
									}
									d.render(), i++, i == _.length && (e.done = !0, a(), t(c));
								}, l = function(e) {
									a(), console.log(e.message + " (" + e.filename + ":" + e.lineno + ")"), r(e);
								};
								for (let e = 0; e < _.length; e++) {
									var f = T[e % T.length];
									f.onmessage = s, f.onerror = l, f.postMessage({
										type: m,
										expandedExtent: _[e].extent,
										extendedAtoms: _[e].atoms,
										atomsToShow: _[e].toshow
									});
								}
							});
						};
						t ||= {}, u = v.getMatWithStyle(t);
						let T = new _([]);
						T.style = t, T.atomsel = n, T.allsel = r, T.focus = i;
						var E = null;
						if (x) {
							var D = {}, O = {};
							for (S = 0; S < this.models.length; S++) D[S] = [], O[S] = [];
							for (S = 0; S < g.length; S++) D[g[S].model].push(g[S]);
							for (S = 0; S < b.length; S++) O[b[S].model].push(b[S]);
							var k = [];
							for (S = 0; S < this.models.length; S++) O[S].length > 0 && (T.push({
								geo: new f.Geometry(!0),
								mat: u,
								done: !1,
								finished: !1,
								symmetries: this.models[S].getSymmetries()
							}), k.push(w(T[T.length - 1], D[S], O[S])));
							E = Promise.all(k);
						} else T.push({
							geo: new f.Geometry(!0),
							mat: u,
							done: !1,
							finished: !1,
							symmetries: [new p.Matrix4()]
						}), E = w(T[T.length - 1], g, b);
						return this.surfaces[c] = T, E.surfid = c, a && typeof a == "function" ? (E.then(function(e) {
							a(e);
						}), c) : E;
					}
					setSurfaceMaterialStyle(e, t) {
						if ((0, h.adjustVolumeStyle)(t), this.surfaces[e]) {
							var n = this.surfaces[e];
							for (let e = 0; e < n.length; e++) {
								var r = n[e].mat = v.getMatWithStyle(t);
								if (n[e].mat.side = f.FrontSide, t.wireframe && n[e].geo.setUpWireframe(), t.color) {
									n[e].mat.color = m.CC.color(t.color), n[e].geo.colorsNeedUpdate = !0;
									let r = m.CC.color(t.color);
									n[e].geo.setColor(r);
								} else if (r.voldata && r.volscheme) {
									let t = r.volscheme, i = r.voldata, a = m.CC, o = t.range() || [-1, 1];
									n[e].geo.setColors(function(e, n, r) {
										let s = i.getVal(e, n, r);
										return a.color(t.valueToHex(s, o));
									});
								} else {
									n[e].geo.colorsNeedUpdate = !0;
									for (let r of n[e].geo.geometryGroups) for (let e = 0; e < r.vertices; e++) {
										let n = (0, h.getColorFromStyle)(r.atomArray[e], t), i = 3 * e;
										r.colorArray[i] = n.r, r.colorArray[i + 1] = n.g, r.colorArray[i + 2] = n.b;
									}
								}
								n[e].finished = !1;
							}
						}
						return this;
					}
					getSurface(e) {
						return this.surfaces[e];
					}
					removeSurface(e) {
						for (var t = this.surfaces[e], n = 0; n < t.length; n++) t[n] && t[n].lastGL && (t[n].geo !== void 0 && t[n].geo.dispose(), t[n].mat !== void 0 && t[n].mat.dispose(), this.modelGroup.remove(t[n].lastGL));
						return delete this.surfaces[e], this.show(), this;
					}
					removeAllSurfaces() {
						for (var e in this.surfaces) if (this.surfaces.hasOwnProperty(e)) {
							for (var t = this.surfaces[e], n = 0; n < t.length; n++) t[n] && t[n].lastGL && (t[n].geo !== void 0 && t[n].geo.dispose(), t[n].mat !== void 0 && t[n].mat.dispose(), this.modelGroup.remove(t[n].lastGL));
							delete this.surfaces[e];
						}
						return this.show(), this;
					}
					jmolMoveTo() {
						var e = this.modelGroup.position, t = "center { " + -e.x + " " + -e.y + " " + -e.z + " }; ", n = this.rotationGroup.quaternion;
						return t += "moveto .5 quaternion { " + n.x + " " + n.y + " " + n.z + " " + n.w + " };", t;
					}
					clear() {
						return this.removeAllSurfaces(), this.removeAllModels(), this.removeAllLabels(), this.removeAllShapes(), this.show(), this;
					}
					mapAtomProperties(e, t) {
						t ||= {};
						var n = this.getAtomsFromSel(t);
						if (typeof e == "function") for (let t = 0, r = n.length; t < r; t++) {
							let r = n[t];
							e(r);
						}
						else for (let t = 0, a = n.length; t < a; t++) {
							var r = n[t];
							for (let t = 0, n = e.length; t < n; t++) {
								let n = e[t];
								if (n.props) for (var i in n.props) n.props.hasOwnProperty(i) && this.atomIsSelected(r, n) && (r.properties ||= {}, r.properties[i] = n.props[i]);
							}
						}
						return this;
					}
					linkViewer(e) {
						return this.linkedViewers.push(e), this;
					}
					getPerceivedDistance() {
						return this.CAMERA_Z - this.rotationGroup.position.z;
					}
					setPerceivedDistance(e) {
						this.rotationGroup.position.z = this.CAMERA_Z - e;
					}
					setAutoEyeSeparation(e, t) {
						var n = this.getPerceivedDistance();
						return t ||= 5, e || this.camera.position.x > 0 ? this.camera.position.x = n * Math.tan(Math.PI / 180 * t) : this.camera.position.x = -n * Math.tan(Math.PI / 180 * t), this.camera.lookAt(new p.Vector3(0, 0, this.rotationGroup.position.z)), this.camera.position.x;
					}
					setDefaultCartoonQuality(e) {
						this.config.cartoonQuality = e;
					}
				}
				v.numWorkers = 4, v.maxVolume = 64e3, v.surfaceTypeMap = {
					VDW: l.SurfaceType.VDW,
					MS: l.SurfaceType.MS,
					SAS: l.SurfaceType.SAS,
					SES: l.SurfaceType.SES
				};
				function y(e, t) {
					if (e = (0, h.getElement)(e), e) {
						t ||= {};
						try {
							return new v(e, t);
						} catch (e) {
							throw "error creating viewer: " + e;
						}
					}
				}
				function b(e, t = {}, n = {}) {
					if (e = (0, h.getElement)(e), e) {
						var r = [], i = document.createElement("canvas");
						n.rows = t.rows, n.cols = t.cols, n.control_all = t.control_all != null && t.control_all, e.appendChild(i);
						try {
							for (var a = 0; a < t.rows; a++) {
								for (var o = [], s = 0; s < t.cols; s++) {
									n.row = a, n.col = s, n.canvas = i, n.viewers = r, n.control_all = t.control_all;
									var c = y(e, (0, h.extend)({}, n));
									o.push(c);
								}
								r.unshift(o);
							}
						} catch (e) {
							throw "error creating viewer grid: " + e;
						}
						return r;
					}
				}
				function x(e) {
					var t = this;
					if (e = (0, h.getElement)(e), e) {
						var n = b(e, {
							rows: 1,
							cols: 2,
							control_all: !0
						});
						this.glviewer1 = n[0][0], this.glviewer2 = n[0][1], this.glviewer1.setAutoEyeSeparation(!1), this.glviewer2.setAutoEyeSeparation(!0), this.glviewer1.linkViewer(this.glviewer2), this.glviewer2.linkViewer(this.glviewer1);
						for (var r = Object.getOwnPropertyNames(this.glviewer1.__proto__).filter(function(e) {
							return typeof t.glviewer1[e] == "function";
						}), i = 0; i < r.length; i++) this[r[i]] = (function(e) {
							return function() {
								return [this.glviewer1[e].apply(this.glviewer1, arguments), this.glviewer2[e].apply(this.glviewer2, arguments)];
							};
						})(r[i]);
						this.setCoordinates = function(e, t, n) {
							for (var r = 0; r < e.length; r++) e[r].setCoordinates(t, n);
						}, this.surfacesFinished = function() {
							return this.glviewer1.surfacesFinished() && this.glviewer2.surfacesFinished();
						}, this.isAnimated = function() {
							return this.glviewer1.isAnimated() || this.glviewer2.isAnimated();
						}, this.render = function(e) {
							this.glviewer1.render(), this.glviewer2.render(), e && e(this);
						}, this.getCanvas = function() {
							return this.glviewer1.getCanvas();
						};
					}
				}
			},
			"./src/Gradient.ts"(e, t, n) {
				n.r(t), n.d(t, {
					CustomLinear: () => u,
					Gradient: () => f,
					GradientType: () => i,
					ROYGB: () => c,
					RWB: () => s,
					Sinebow: () => l,
					builtinGradients: () => d,
					getGradient: () => o,
					normalizeValue: () => a
				});
				var r = n("./src/colors.ts");
				class i {}
				function a(e, t, n) {
					return t >= e ? (n < e && (n = e), n > t && (n = t), {
						lo: e,
						hi: t,
						val: n
					}) : (n > e && (n = e), n < t && (n = t), n = e - n + t, {
						lo: t,
						hi: e,
						val: n
					});
				}
				function o(e) {
					if (e instanceof i) return e;
					if (e.gradient !== void 0 && d[e.gradient]) {
						let t = e.min === void 0 ? -1 : e.min, n = e.max === void 0 ? 1 : e.max;
						return e.mid === void 0 ? e.colors === void 0 ? new d[e.gradient](t, n) : new d[e.gradient](t, n, e.colors) : new d[e.gradient](t, n, e.mid);
					}
					if (typeof e.gradient == "string" && e.gradient.startsWith("linear_")) {
						let t = e.gradient.split("_");
						t.shift();
						let n = e.min === void 0 ? -1 : e.min, r = e.max === void 0 ? 1 : e.max;
						return new u(n, r, t);
					}
					return e;
				}
				class s extends i {
					constructor(e, t, n) {
						super(), this.gradient = "RWB", this.mult = 1, this.mid = n, this.min = e, this.max = t, t === void 0 && Array.isArray(e) && e.length >= 2 ? (this.max = e[1], this.min = e[0]) : e && t && !Array.isArray(e) && (this.min = e, this.max = t);
					}
					range() {
						return this.min !== void 0 && this.max !== void 0 ? [this.min, this.max] : null;
					}
					valueToHex(e, t) {
						var n, r;
						if (e = this.mult * e, t ? (n = t[0], r = t[1]) : (n = this.min, r = this.max), e === void 0) return 16777215;
						var i = a(n, r, e);
						n = i.lo, r = i.hi, e = i.val;
						var o = (r + n) / 2;
						o = t && t[2] !== void 0 ? t[2] : this.mid === void 0 ? (n + r) / 2 : this.mid;
						var s, c;
						return e < o ? (s = Math.floor(255 * Math.sqrt((e - n) / (o - n))), c = 16711680 + 256 * s + s, c) : e > o ? (s = Math.floor(255 * Math.sqrt(1 - (e - o) / (r - o))), c = 65536 * s + 256 * s + 255, c) : 16777215;
					}
				}
				class c extends i {
					constructor(e, t) {
						super(), this.gradient = "ROYGB", this.mult = 1, this.min = e, this.max = t, t === void 0 && Array.isArray(e) && e.length >= 2 ? (this.max = e[1], this.min = e[0]) : e && t && !Array.isArray(e) && (this.min = e, this.max = t);
					}
					valueToHex(e, t) {
						var n, r;
						if (e = this.mult * e, t ? (n = t[0], r = t[1]) : (n = this.min, r = this.max), e === void 0) return 16777215;
						var i = a(n, r, e);
						n = i.lo, r = i.hi, e = i.val;
						var o = (n + r) / 2, s = (n + o) / 2, c = (o + r) / 2, l, u;
						return e < s ? (l = Math.floor(255 * Math.sqrt((e - n) / (s - n))), u = 16711680 + 256 * l + 0, u) : e < o ? (l = Math.floor(255 * Math.sqrt(1 - (e - s) / (o - s))), u = 65536 * l + 65280 + 0, u) : e < c ? (l = Math.floor(255 * Math.sqrt((e - o) / (c - o))), u = 65280 + 1 * l, u) : (l = Math.floor(255 * Math.sqrt(1 - (e - c) / (r - c))), u = 0 + 256 * l + 255, u);
					}
					range() {
						return this.min !== void 0 && this.max !== void 0 ? [this.min, this.max] : null;
					}
				}
				class l extends i {
					constructor(e, t) {
						super(), this.gradient = "Sinebow", this.mult = 1, this.min = e, this.max = t, t === void 0 && Array.isArray(e) && e.length >= 2 && (this.max = e[1], this.min = e[0]), t < e && (this.mult = -1, this.min *= -1, this.max *= -1);
					}
					valueToHex(e, t) {
						var n, r;
						if (e = this.mult * e, t ? (n = t[0], r = t[1]) : (n = this.min, r = this.max), e === void 0) return 16777215;
						var i = f.normalizeValue(n, r, e);
						n = i.lo, r = i.hi, e = i.val;
						var a = 5 * ((e - n) / (r - n)) / 6 + .5, o = Math.sin(Math.PI * a);
						o *= o * 255;
						var s = Math.sin(Math.PI * (a + 1 / 3));
						s *= s * 255;
						var c = Math.sin(Math.PI * (a + 2 / 3));
						return c *= c * 255, 65536 * Math.floor(o) + 256 * Math.floor(c) + 1 * Math.floor(s);
					}
					range() {
						return this.min !== void 0 && this.max !== void 0 ? [this.min, this.max] : null;
					}
				}
				class u extends i {
					constructor(e, t, n) {
						super(), this.gradient = "linear", this.colors = [];
						var i;
						if (Array.isArray(e) && e.length >= 2 ? (this.max = e[1], this.min = e[0], i = t) : (this.min = e, this.max = t, i = n), i) for (let e of i) this.colors.push(r.CC.color(e));
						else this.colors.push(r.CC.color(0));
					}
					range() {
						return this.min !== void 0 && this.max !== void 0 ? [this.min, this.max] : null;
					}
					valueToHex(e, t) {
						var n, i;
						if (t ? (n = t[0], i = t[1]) : (n = this.min, i = this.max), e === void 0) return 16777215;
						var o = a(n, i, e);
						n = o.lo, i = o.hi, e = o.val;
						let s = this.colors.length, c = (i - n) / s, l = Math.min(Math.floor((e - n) / c), s - 1), u = Math.min(l + 1, s - 1), d = (e - n - l * c) / c, f = this.colors[l], p = this.colors[u];
						return new r.Color(f.r + d * (p.r - f.r), f.g + d * (p.g - f.g), f.b + d * (p.b - f.b)).getHex();
					}
				}
				let d = {
					rwb: s,
					RWB: s,
					roygb: c,
					ROYGB: c,
					sinebow: l,
					linear: u
				};
				class f extends i {
					valueToHex(e, t) {
						return 0;
					}
					range() {
						return null;
					}
				}
				f.RWB = s, f.ROYGB = c, f.Sinebow = l, f.CustomLinear = u, f.builtinGradients = d, f.normalizeValue = a, f.getGradient = o;
			},
			"./src/Label.ts"(e, t, n) {
				n.r(t), n.d(t, {
					Label: () => l,
					LabelCount: () => o
				});
				var r = n("./src/WebGL/index.ts"), i = n("./src/Gradient.ts"), a = n("./src/colors.ts");
				let o = 0;
				function s(e, t, n, r, i, a, o) {
					e.beginPath(), e.moveTo(t + a, n), e.lineTo(t + r - a, n), e.quadraticCurveTo(t + r, n, t + r, n + a), e.lineTo(t + r, n + i - a), e.quadraticCurveTo(t + r, n + i, t + r - a, n + i), e.lineTo(t + a, n + i), e.quadraticCurveTo(t, n + i, t, n + i - a), e.lineTo(t, n + a), e.quadraticCurveTo(t, n, t + a, n), e.closePath(), e.fill(), o && e.stroke();
				}
				function c(e, t, n) {
					var r = n;
					return e !== void 0 && (e instanceof a.Color ? r = e.scaled() : (r = a.CC.color(e), r.scaled !== void 0 && (r = r.scaled()))), t !== void 0 && (r.a = parseFloat(t)), r;
				}
				class l {
					constructor(e, t) {
						this.id = o++, this.stylespec = t || {}, this.canvas = document.createElement("canvas"), this.canvas.width = 134, this.canvas.height = 35, this.context = this.canvas.getContext("2d"), this.sprite = new r.Sprite(), this.text = e, this.frame = this.stylespec.frame;
					}
					getStyle() {
						return this.stylespec;
					}
					hide() {
						this.sprite && (this.sprite.visible = !1);
					}
					show() {
						this.sprite && (this.sprite.visible = !0);
					}
					setContext() {
						var e = this.stylespec, t = e.useScreen !== void 0 && e.useScreen, n = e.showBackground;
						(n === "0" || n === "false") && (n = !1), n === void 0 && (n = !0);
						var a = e.font ? e.font : "sans-serif", o = parseInt(e.fontSize) ? parseInt(e.fontSize) : 18, l = c(e.fontColor, e.fontOpacity, {
							r: 255,
							g: 255,
							b: 255,
							a: 1
						}), u = e.padding ? e.padding : 4, d = e.borderThickness ? e.borderThickness : 0, f = c(e.backgroundColor, e.backgroundOpacity, {
							r: 0,
							g: 0,
							b: 0,
							a: 1
						}), p = c(e.borderColor, e.borderOpacity, f), m = e.position ? e.position : {
							x: -10,
							y: 1,
							z: 1
						}, h = e.inFront === void 0 || e.inFront;
						(h === "false" || h === "0") && (h = !1);
						var g = e.alignment || r.SpriteAlignment.topLeft;
						typeof g == "string" && g in r.SpriteAlignment && (g = r.SpriteAlignment[g]);
						var _ = "";
						e.bold && (_ = "bold "), this.context.font = _ + o + "px  " + a;
						var v = this.context.measureText(this.text).width;
						n || (d = 0);
						var y = v + 2.5 * d + 2 * u, b = o * 1.25 + 2 * d + 2 * u;
						if (e.backgroundImage) {
							var x = e.backgroundImage, S = e.backgroundWidth ? e.backgroundWidth : x.width, C = e.backgroundHeight ? e.backgroundHeight : x.height;
							S > y && (y = S), C > b && (b = C);
						}
						if (this.canvas.width = y, this.canvas.height = b, this.context.clearRect(0, 0, this.canvas.width, this.canvas.height), _ = "", e.bold && (_ = "bold "), this.context.font = _ + o + "px  " + a, this.context.fillStyle = "rgba(" + f.r + "," + f.g + "," + f.b + "," + f.a + ")", this.context.strokeStyle = "rgba(" + p.r + "," + p.g + "," + p.b + "," + p.a + ")", e.backgroundGradient) {
							let t = this.context.createLinearGradient(0, b / 2, y, b / 2), n = i.Gradient.getGradient(e.backgroundGradient), r = n.range(), a = -1, o = 1;
							r && (a = r[0], o = r[1]);
							let s = o - a;
							for (let e = 0; e < 1.01; e += .1) {
								let r = c(n.valueToHex(a + s * e)), i = "rgba(" + r.r + "," + r.g + "," + r.b + "," + r.a + ")";
								t.addColorStop(e, i);
							}
							this.context.fillStyle = t;
						}
						this.context.lineWidth = d, n && s(this.context, d, d, y - 2 * d, b - 2 * d, 6, d > 0), e.backgroundImage && this.context.drawImage(x, 0, 0, y, b), this.context.fillStyle = "rgba(" + l.r + "," + l.g + "," + l.b + "," + l.a + ")", this.context.fillText(this.text, d + u, o + d + u, v);
						var w = new r.Texture(this.canvas);
						w.needsUpdate = !0, this.sprite.material = new r.SpriteMaterial({
							map: w,
							useScreenCoordinates: t,
							alignment: g,
							depthTest: !h,
							screenOffset: e.screenOffset || null
						}), this.sprite.scale.set(1, 1, 1), this.sprite.position.set(m.x, m.y, m.z);
					}
					dispose() {
						this.sprite.material.map !== void 0 && this.sprite.material.map.dispose(), this.sprite.material !== void 0 && this.sprite.material.dispose();
					}
				}
			},
			"./src/ProteinSurface4.ts"(e, t, n) {
				n.r(t), n.d(t, {
					MarchingCube: () => c,
					MarchingCubeInitializer: () => s,
					PointGrid: () => l,
					ProteinSurface: () => u,
					SurfaceType: () => i,
					setSyncSurface: () => o,
					syncSurface: () => a
				});
				var r = n("./src/WebGL/math/index.ts"), i;
				(function(e) {
					e[e.VDW = 1] = "VDW", e[e.MS = 2] = "MS", e[e.SAS = 3] = "SAS", e[e.SES = 4] = "SES";
				})(i ||= {});
				var a = !1;
				function o(e) {
					a = e;
				}
				(window.navigator.userAgent.indexOf("MSIE ") >= 0 || window.navigator.userAgent.indexOf("Trident/") >= 0) && (a = !0);
				class s {
					constructor() {
						this.ISDONE = 2, this.edgeTable = new Uint32Array([
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							2816,
							0,
							0,
							0,
							1792,
							0,
							3328,
							3584,
							3840,
							0,
							0,
							0,
							138,
							0,
							21,
							0,
							134,
							0,
							0,
							0,
							652,
							0,
							2067,
							3865,
							3600,
							0,
							0,
							0,
							42,
							0,
							0,
							0,
							294,
							0,
							0,
							21,
							28,
							0,
							3875,
							1049,
							3360,
							0,
							168,
							162,
							170,
							0,
							645,
							2475,
							2210,
							0,
							687,
							293,
							172,
							4010,
							3747,
							3497,
							3232,
							0,
							0,
							0,
							0,
							0,
							69,
							0,
							900,
							0,
							0,
							0,
							1792,
							138,
							131,
							1608,
							1920,
							0,
							81,
							0,
							2074,
							84,
							85,
							84,
							86,
							0,
							81,
							0,
							3676,
							330,
							1105,
							1881,
							1616,
							0,
							0,
							0,
							42,
							0,
							69,
							0,
							502,
							0,
							0,
							21,
							3580,
							138,
							2035,
							1273,
							1520,
							2816,
							104,
							2337,
							106,
							840,
							581,
							367,
							102,
							2816,
							3695,
							3429,
							3180,
							1898,
							1635,
							1385,
							1120,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							3910,
							0,
							0,
							69,
							588,
							42,
							2083,
							41,
							2880,
							0,
							0,
							0,
							1722,
							0,
							2293,
							4095,
							3830,
							0,
							255,
							757,
							764,
							2538,
							2291,
							3065,
							2800,
							0,
							0,
							81,
							338,
							0,
							3925,
							1119,
							3414,
							84,
							855,
							85,
							340,
							2130,
							2899,
							89,
							2384,
							1792,
							712,
							194,
							1162,
							4036,
							3781,
							3535,
							3270,
							708,
							719,
							197,
							204,
							3018,
							2755,
							2505,
							2240,
							0,
							0,
							0,
							0,
							168,
							420,
							168,
							1958,
							162,
							162,
							676,
							2988,
							170,
							163,
							680,
							928,
							3328,
							3096,
							3328,
							3642,
							52,
							53,
							1855,
							1590,
							2340,
							2111,
							2869,
							2620,
							298,
							51,
							825,
							560,
							3584,
							3584,
							3090,
							3482,
							1668,
							1941,
							1183,
							1430,
							146,
							2975,
							2069,
							2460,
							154,
							915,
							153,
							400,
							3840,
							3592,
							3329,
							3082,
							1796,
							1541,
							1295,
							1030,
							2818,
							2575,
							2309,
							2060,
							778,
							515,
							265,
							0
						]), this.triTable = [
							[],
							[],
							[],
							[],
							[],
							[],
							[],
							[
								11,
								9,
								8
							],
							[],
							[],
							[],
							[
								8,
								10,
								9
							],
							[],
							[
								10,
								8,
								11
							],
							[
								9,
								11,
								10
							],
							[
								8,
								10,
								9,
								8,
								11,
								10
							],
							[],
							[],
							[],
							[
								1,
								7,
								3
							],
							[],
							[
								4,
								2,
								0
							],
							[],
							[
								2,
								1,
								7
							],
							[],
							[],
							[],
							[
								2,
								7,
								3,
								2,
								9,
								7
							],
							[],
							[
								1,
								4,
								11,
								1,
								0,
								4
							],
							[
								3,
								8,
								0,
								11,
								9,
								4,
								11,
								10,
								9
							],
							[
								4,
								11,
								9,
								11,
								10,
								9
							],
							[],
							[],
							[],
							[
								5,
								3,
								1
							],
							[],
							[],
							[],
							[
								2,
								5,
								8,
								2,
								1,
								5
							],
							[],
							[],
							[
								2,
								4,
								0
							],
							[
								3,
								2,
								4
							],
							[],
							[
								0,
								9,
								1,
								8,
								10,
								5,
								8,
								11,
								10
							],
							[
								3,
								4,
								0,
								3,
								10,
								4
							],
							[
								5,
								8,
								10,
								8,
								11,
								10
							],
							[],
							[
								3,
								5,
								7
							],
							[
								7,
								1,
								5
							],
							[
								1,
								7,
								3,
								1,
								5,
								7
							],
							[],
							[
								9,
								2,
								0,
								9,
								7,
								2
							],
							[
								0,
								3,
								8,
								1,
								7,
								11,
								1,
								5,
								7
							],
							[
								11,
								1,
								7,
								1,
								5,
								7
							],
							[],
							[
								9,
								1,
								0,
								5,
								3,
								2,
								5,
								7,
								3
							],
							[
								8,
								2,
								5,
								8,
								0,
								2
							],
							[
								2,
								5,
								3,
								5,
								7,
								3
							],
							[
								3,
								9,
								1,
								3,
								8,
								9,
								7,
								11,
								10,
								7,
								10,
								5
							],
							[
								9,
								1,
								0,
								10,
								7,
								11,
								10,
								5,
								7
							],
							[
								3,
								8,
								0,
								7,
								10,
								5,
								7,
								11,
								10
							],
							[
								11,
								5,
								7,
								11,
								10,
								5
							],
							[],
							[],
							[],
							[],
							[],
							[
								0,
								6,
								2
							],
							[],
							[
								7,
								2,
								9,
								7,
								9,
								8
							],
							[],
							[],
							[],
							[
								8,
								10,
								9
							],
							[
								7,
								1,
								3
							],
							[
								7,
								1,
								0
							],
							[
								6,
								9,
								3,
								6,
								10,
								9
							],
							[
								7,
								10,
								8,
								10,
								9,
								8
							],
							[],
							[
								6,
								0,
								4
							],
							[],
							[
								11,
								1,
								4,
								11,
								3,
								1
							],
							[
								2,
								4,
								6
							],
							[
								2,
								0,
								4,
								2,
								4,
								6
							],
							[
								2,
								4,
								6
							],
							[
								1,
								4,
								2,
								4,
								6,
								2
							],
							[],
							[
								6,
								0,
								4
							],
							[],
							[
								2,
								11,
								3,
								6,
								9,
								4,
								6,
								10,
								9
							],
							[
								8,
								6,
								1,
								8,
								1,
								3
							],
							[
								10,
								0,
								6,
								0,
								4,
								6
							],
							[
								8,
								0,
								3,
								9,
								6,
								10,
								9,
								4,
								6
							],
							[
								10,
								4,
								6,
								10,
								9,
								4
							],
							[],
							[],
							[],
							[
								5,
								3,
								1
							],
							[],
							[
								0,
								6,
								2
							],
							[],
							[
								7,
								4,
								8,
								5,
								2,
								1,
								5,
								6,
								2
							],
							[],
							[],
							[
								2,
								4,
								0
							],
							[
								7,
								4,
								8,
								2,
								11,
								3,
								10,
								5,
								6
							],
							[
								7,
								1,
								3
							],
							[
								5,
								6,
								10,
								0,
								9,
								1,
								8,
								7,
								4
							],
							[
								5,
								6,
								10,
								7,
								0,
								3,
								7,
								4,
								0
							],
							[
								10,
								5,
								6,
								4,
								8,
								7
							],
							[
								9,
								11,
								8
							],
							[
								3,
								5,
								6
							],
							[
								0,
								5,
								11,
								0,
								11,
								8
							],
							[
								6,
								3,
								5,
								3,
								1,
								5
							],
							[
								3,
								9,
								6,
								3,
								8,
								9
							],
							[
								9,
								6,
								0,
								6,
								2,
								0
							],
							[
								0,
								3,
								8,
								2,
								5,
								6,
								2,
								1,
								5
							],
							[
								1,
								6,
								2,
								1,
								5,
								6
							],
							[
								9,
								11,
								8
							],
							[
								1,
								0,
								9,
								6,
								10,
								5,
								11,
								3,
								2
							],
							[
								6,
								10,
								5,
								2,
								8,
								0,
								2,
								11,
								8
							],
							[
								3,
								2,
								11,
								10,
								5,
								6
							],
							[
								10,
								5,
								6,
								9,
								3,
								8,
								9,
								1,
								3
							],
							[
								0,
								9,
								1,
								5,
								6,
								10
							],
							[
								8,
								0,
								3,
								10,
								5,
								6
							],
							[
								10,
								5,
								6
							],
							[],
							[],
							[],
							[],
							[],
							[],
							[],
							[
								1,
								10,
								2,
								9,
								11,
								6,
								9,
								8,
								11
							],
							[],
							[],
							[
								6,
								0,
								2
							],
							[
								3,
								6,
								9,
								3,
								2,
								6
							],
							[
								3,
								5,
								1
							],
							[
								0,
								5,
								1,
								0,
								11,
								5
							],
							[
								0,
								3,
								5
							],
							[
								6,
								9,
								11,
								9,
								8,
								11
							],
							[],
							[],
							[],
							[
								4,
								5,
								9,
								7,
								1,
								10,
								7,
								3,
								1
							],
							[],
							[
								11,
								6,
								7,
								2,
								4,
								5,
								2,
								0,
								4
							],
							[
								11,
								6,
								7,
								8,
								0,
								3,
								1,
								10,
								2,
								9,
								4,
								5
							],
							[
								6,
								7,
								11,
								1,
								10,
								2,
								9,
								4,
								5
							],
							[],
							[
								4,
								1,
								0,
								4,
								5,
								1,
								6,
								7,
								3,
								6,
								3,
								2
							],
							[
								9,
								4,
								5,
								0,
								6,
								7,
								0,
								2,
								6
							],
							[
								4,
								5,
								9,
								6,
								3,
								2,
								6,
								7,
								3
							],
							[
								6,
								7,
								11,
								5,
								3,
								8,
								5,
								1,
								3
							],
							[
								6,
								7,
								11,
								4,
								1,
								0,
								4,
								5,
								1
							],
							[
								4,
								5,
								9,
								3,
								8,
								0,
								11,
								6,
								7
							],
							[
								9,
								4,
								5,
								7,
								11,
								6
							],
							[],
							[],
							[
								0,
								6,
								4
							],
							[
								8,
								6,
								4,
								8,
								1,
								6
							],
							[],
							[
								0,
								10,
								2,
								0,
								9,
								10,
								4,
								8,
								11,
								4,
								11,
								6
							],
							[
								10,
								2,
								1,
								6,
								0,
								3,
								6,
								4,
								0
							],
							[
								10,
								2,
								1,
								11,
								4,
								8,
								11,
								6,
								4
							],
							[
								4,
								2,
								6
							],
							[
								1,
								0,
								9,
								2,
								4,
								8,
								2,
								6,
								4
							],
							[
								2,
								4,
								0,
								2,
								6,
								4
							],
							[
								8,
								2,
								4,
								2,
								6,
								4
							],
							[
								11,
								4,
								1,
								11,
								6,
								4
							],
							[
								0,
								9,
								1,
								4,
								11,
								6,
								4,
								8,
								11
							],
							[
								3,
								6,
								0,
								6,
								4,
								0
							],
							[
								8,
								6,
								4,
								8,
								11,
								6
							],
							[
								10,
								8,
								9
							],
							[
								6,
								3,
								9,
								6,
								7,
								3
							],
							[
								6,
								7,
								1
							],
							[
								10,
								7,
								1,
								7,
								3,
								1
							],
							[
								7,
								11,
								6,
								8,
								10,
								2,
								8,
								9,
								10
							],
							[
								11,
								6,
								7,
								10,
								0,
								9,
								10,
								2,
								0
							],
							[
								2,
								1,
								10,
								7,
								11,
								6,
								8,
								0,
								3
							],
							[
								1,
								10,
								2,
								6,
								7,
								11
							],
							[
								7,
								2,
								6,
								7,
								9,
								2
							],
							[
								1,
								0,
								9,
								3,
								6,
								7,
								3,
								2,
								6
							],
							[
								7,
								0,
								6,
								0,
								2,
								6
							],
							[
								2,
								7,
								3,
								2,
								6,
								7
							],
							[
								7,
								11,
								6,
								3,
								9,
								1,
								3,
								8,
								9
							],
							[
								9,
								1,
								0,
								11,
								6,
								7
							],
							[
								0,
								3,
								8,
								11,
								6,
								7
							],
							[
								11,
								6,
								7
							],
							[],
							[],
							[],
							[],
							[
								5,
								3,
								7
							],
							[
								8,
								5,
								2,
								8,
								7,
								5
							],
							[
								5,
								3,
								7
							],
							[
								1,
								10,
								2,
								5,
								8,
								7,
								5,
								9,
								8
							],
							[
								1,
								7,
								5
							],
							[
								1,
								7,
								5
							],
							[
								9,
								2,
								7,
								9,
								7,
								5
							],
							[
								11,
								3,
								2,
								8,
								5,
								9,
								8,
								7,
								5
							],
							[
								1,
								3,
								7,
								1,
								7,
								5
							],
							[
								0,
								7,
								1,
								7,
								5,
								1
							],
							[
								9,
								3,
								5,
								3,
								7,
								5
							],
							[
								9,
								7,
								5,
								9,
								8,
								7
							],
							[
								8,
								10,
								11
							],
							[
								3,
								4,
								10,
								3,
								10,
								11
							],
							[
								8,
								10,
								11
							],
							[
								5,
								9,
								4,
								1,
								11,
								3,
								1,
								10,
								11
							],
							[
								2,
								4,
								5
							],
							[
								5,
								2,
								4,
								2,
								0,
								4
							],
							[
								0,
								3,
								8,
								5,
								9,
								4,
								10,
								2,
								1
							],
							[
								2,
								1,
								10,
								9,
								4,
								5
							],
							[
								2,
								8,
								5,
								2,
								11,
								8
							],
							[
								3,
								2,
								11,
								1,
								4,
								5,
								1,
								0,
								4
							],
							[
								9,
								4,
								5,
								8,
								2,
								11,
								8,
								0,
								2
							],
							[
								11,
								3,
								2,
								9,
								4,
								5
							],
							[
								8,
								5,
								3,
								5,
								1,
								3
							],
							[
								5,
								0,
								4,
								5,
								1,
								0
							],
							[
								3,
								8,
								0,
								4,
								5,
								9
							],
							[
								9,
								4,
								5
							],
							[
								11,
								9,
								10
							],
							[
								11,
								9,
								10
							],
							[
								1,
								11,
								4,
								1,
								10,
								11
							],
							[
								8,
								7,
								4,
								11,
								1,
								10,
								11,
								3,
								1
							],
							[
								2,
								7,
								9,
								2,
								9,
								10
							],
							[
								4,
								8,
								7,
								0,
								10,
								2,
								0,
								9,
								10
							],
							[
								2,
								1,
								10,
								0,
								7,
								4,
								0,
								3,
								7
							],
							[
								10,
								2,
								1,
								8,
								7,
								4
							],
							[
								1,
								7,
								4
							],
							[
								3,
								2,
								11,
								4,
								8,
								7,
								9,
								1,
								0
							],
							[
								11,
								4,
								2,
								4,
								0,
								2
							],
							[
								2,
								11,
								3,
								7,
								4,
								8
							],
							[
								4,
								1,
								7,
								1,
								3,
								7
							],
							[
								1,
								0,
								9,
								8,
								7,
								4
							],
							[
								3,
								4,
								0,
								3,
								7,
								4
							],
							[
								8,
								7,
								4
							],
							[
								8,
								9,
								10,
								8,
								10,
								11
							],
							[
								3,
								9,
								11,
								9,
								10,
								11
							],
							[
								0,
								10,
								8,
								10,
								11,
								8
							],
							[
								10,
								3,
								1,
								10,
								11,
								3
							],
							[
								2,
								8,
								10,
								8,
								9,
								10
							],
							[
								9,
								2,
								0,
								9,
								10,
								2
							],
							[
								8,
								0,
								3,
								1,
								10,
								2
							],
							[
								10,
								2,
								1
							],
							[
								1,
								11,
								9,
								11,
								8,
								9
							],
							[
								11,
								3,
								2,
								0,
								9,
								1
							],
							[
								11,
								0,
								2,
								11,
								8,
								0
							],
							[
								11,
								3,
								2
							],
							[
								8,
								1,
								3,
								8,
								9,
								1
							],
							[
								9,
								1,
								0
							],
							[
								8,
								0,
								3
							],
							[]
						], this.edgeTable2 = [
							0,
							265,
							515,
							778,
							2060,
							2309,
							2575,
							2822,
							1030,
							1295,
							1541,
							1804,
							3082,
							3331,
							3593,
							3840,
							400,
							153,
							915,
							666,
							2460,
							2197,
							2975,
							2710,
							1430,
							1183,
							1941,
							1692,
							3482,
							3219,
							3993,
							3728,
							560,
							825,
							51,
							314,
							2620,
							2869,
							2111,
							2358,
							1590,
							1855,
							1077,
							1340,
							3642,
							3891,
							3129,
							3376,
							928,
							681,
							419,
							170,
							2988,
							2725,
							2479,
							2214,
							1958,
							1711,
							1445,
							1196,
							4010,
							3747,
							3497,
							3232,
							2240,
							2505,
							2755,
							3018,
							204,
							453,
							719,
							966,
							3270,
							3535,
							3781,
							4044,
							1226,
							1475,
							1737,
							1984,
							2384,
							2137,
							2899,
							2650,
							348,
							85,
							863,
							598,
							3414,
							3167,
							3925,
							3676,
							1370,
							1107,
							1881,
							1616,
							2800,
							3065,
							2291,
							2554,
							764,
							1013,
							255,
							502,
							3830,
							4095,
							3317,
							3580,
							1786,
							2035,
							1273,
							1520,
							2912,
							2665,
							2403,
							2154,
							876,
							613,
							367,
							102,
							3942,
							3695,
							3429,
							3180,
							1898,
							1635,
							1385,
							1120,
							1120,
							1385,
							1635,
							1898,
							3180,
							3429,
							3695,
							3942,
							102,
							367,
							613,
							876,
							2154,
							2403,
							2665,
							2912,
							1520,
							1273,
							2035,
							1786,
							3580,
							3317,
							4095,
							3830,
							502,
							255,
							1013,
							764,
							2554,
							2291,
							3065,
							2800,
							1616,
							1881,
							1107,
							1370,
							3676,
							3925,
							3167,
							3414,
							598,
							863,
							85,
							348,
							2650,
							2899,
							2137,
							2384,
							1984,
							1737,
							1475,
							1226,
							4044,
							3781,
							3535,
							3270,
							966,
							719,
							453,
							204,
							3018,
							2755,
							2505,
							2240,
							3232,
							3497,
							3747,
							4010,
							1196,
							1445,
							1711,
							1958,
							2214,
							2479,
							2725,
							2988,
							170,
							419,
							681,
							928,
							3376,
							3129,
							3891,
							3642,
							1340,
							1077,
							1855,
							1590,
							2358,
							2111,
							2869,
							2620,
							314,
							51,
							825,
							560,
							3728,
							3993,
							3219,
							3482,
							1692,
							1941,
							1183,
							1430,
							2710,
							2975,
							2197,
							2460,
							666,
							915,
							153,
							400,
							3840,
							3593,
							3331,
							3082,
							1804,
							1541,
							1295,
							1030,
							2822,
							2575,
							2309,
							2060,
							778,
							515,
							265,
							0
						], this.triTable2 = [
							[],
							[
								8,
								3,
								0
							],
							[
								9,
								0,
								1
							],
							[
								8,
								3,
								1,
								8,
								1,
								9
							],
							[
								11,
								2,
								3
							],
							[
								11,
								2,
								0,
								11,
								0,
								8
							],
							[
								11,
								2,
								3,
								0,
								1,
								9
							],
							[
								2,
								1,
								11,
								1,
								9,
								11,
								11,
								9,
								8
							],
							[
								10,
								1,
								2
							],
							[
								8,
								3,
								0,
								1,
								2,
								10
							],
							[
								9,
								0,
								2,
								9,
								2,
								10
							],
							[
								3,
								2,
								8,
								2,
								10,
								8,
								8,
								10,
								9
							],
							[
								10,
								1,
								3,
								10,
								3,
								11
							],
							[
								1,
								0,
								10,
								0,
								8,
								10,
								10,
								8,
								11
							],
							[
								0,
								3,
								9,
								3,
								11,
								9,
								9,
								11,
								10
							],
							[
								8,
								10,
								9,
								8,
								11,
								10
							],
							[
								8,
								4,
								7
							],
							[
								3,
								0,
								4,
								3,
								4,
								7
							],
							[
								1,
								9,
								0,
								8,
								4,
								7
							],
							[
								9,
								4,
								1,
								4,
								7,
								1,
								1,
								7,
								3
							],
							[
								2,
								3,
								11,
								7,
								8,
								4
							],
							[
								7,
								11,
								4,
								11,
								2,
								4,
								4,
								2,
								0
							],
							[
								3,
								11,
								2,
								4,
								7,
								8,
								9,
								0,
								1
							],
							[
								2,
								7,
								11,
								2,
								1,
								7,
								1,
								4,
								7,
								1,
								9,
								4
							],
							[
								10,
								1,
								2,
								8,
								4,
								7
							],
							[
								2,
								10,
								1,
								0,
								4,
								7,
								0,
								7,
								3
							],
							[
								4,
								7,
								8,
								0,
								2,
								10,
								0,
								10,
								9
							],
							[
								2,
								7,
								3,
								2,
								9,
								7,
								7,
								9,
								4,
								2,
								10,
								9
							],
							[
								8,
								4,
								7,
								11,
								10,
								1,
								11,
								1,
								3
							],
							[
								11,
								4,
								7,
								1,
								4,
								11,
								1,
								11,
								10,
								1,
								0,
								4
							],
							[
								3,
								8,
								0,
								7,
								11,
								4,
								11,
								9,
								4,
								11,
								10,
								9
							],
							[
								7,
								11,
								4,
								4,
								11,
								9,
								11,
								10,
								9
							],
							[
								9,
								5,
								4
							],
							[
								3,
								0,
								8,
								4,
								9,
								5
							],
							[
								5,
								4,
								0,
								5,
								0,
								1
							],
							[
								4,
								8,
								5,
								8,
								3,
								5,
								5,
								3,
								1
							],
							[
								11,
								2,
								3,
								9,
								5,
								4
							],
							[
								9,
								5,
								4,
								8,
								11,
								2,
								8,
								2,
								0
							],
							[
								3,
								11,
								2,
								1,
								5,
								4,
								1,
								4,
								0
							],
							[
								8,
								5,
								4,
								2,
								5,
								8,
								2,
								8,
								11,
								2,
								1,
								5
							],
							[
								2,
								10,
								1,
								9,
								5,
								4
							],
							[
								0,
								8,
								3,
								5,
								4,
								9,
								10,
								1,
								2
							],
							[
								10,
								5,
								2,
								5,
								4,
								2,
								2,
								4,
								0
							],
							[
								3,
								4,
								8,
								3,
								2,
								4,
								2,
								5,
								4,
								2,
								10,
								5
							],
							[
								5,
								4,
								9,
								1,
								3,
								11,
								1,
								11,
								10
							],
							[
								0,
								9,
								1,
								4,
								8,
								5,
								8,
								10,
								5,
								8,
								11,
								10
							],
							[
								3,
								4,
								0,
								3,
								10,
								4,
								4,
								10,
								5,
								3,
								11,
								10
							],
							[
								4,
								8,
								5,
								5,
								8,
								10,
								8,
								11,
								10
							],
							[
								9,
								5,
								7,
								9,
								7,
								8
							],
							[
								0,
								9,
								3,
								9,
								5,
								3,
								3,
								5,
								7
							],
							[
								8,
								0,
								7,
								0,
								1,
								7,
								7,
								1,
								5
							],
							[
								1,
								7,
								3,
								1,
								5,
								7
							],
							[
								11,
								2,
								3,
								8,
								9,
								5,
								8,
								5,
								7
							],
							[
								9,
								2,
								0,
								9,
								7,
								2,
								2,
								7,
								11,
								9,
								5,
								7
							],
							[
								0,
								3,
								8,
								2,
								1,
								11,
								1,
								7,
								11,
								1,
								5,
								7
							],
							[
								2,
								1,
								11,
								11,
								1,
								7,
								1,
								5,
								7
							],
							[
								1,
								2,
								10,
								5,
								7,
								8,
								5,
								8,
								9
							],
							[
								9,
								1,
								0,
								10,
								5,
								2,
								5,
								3,
								2,
								5,
								7,
								3
							],
							[
								5,
								2,
								10,
								8,
								2,
								5,
								8,
								5,
								7,
								8,
								0,
								2
							],
							[
								10,
								5,
								2,
								2,
								5,
								3,
								5,
								7,
								3
							],
							[
								3,
								9,
								1,
								3,
								8,
								9,
								7,
								11,
								10,
								7,
								10,
								5
							],
							[
								9,
								1,
								0,
								10,
								7,
								11,
								10,
								5,
								7
							],
							[
								3,
								8,
								0,
								7,
								10,
								5,
								7,
								11,
								10
							],
							[
								11,
								5,
								7,
								11,
								10,
								5
							],
							[
								11,
								7,
								6
							],
							[
								0,
								8,
								3,
								11,
								7,
								6
							],
							[
								9,
								0,
								1,
								11,
								7,
								6
							],
							[
								7,
								6,
								11,
								3,
								1,
								9,
								3,
								9,
								8
							],
							[
								2,
								3,
								7,
								2,
								7,
								6
							],
							[
								8,
								7,
								0,
								7,
								6,
								0,
								0,
								6,
								2
							],
							[
								1,
								9,
								0,
								3,
								7,
								6,
								3,
								6,
								2
							],
							[
								7,
								6,
								2,
								7,
								2,
								9,
								2,
								1,
								9,
								7,
								9,
								8
							],
							[
								1,
								2,
								10,
								6,
								11,
								7
							],
							[
								2,
								10,
								1,
								7,
								6,
								11,
								8,
								3,
								0
							],
							[
								11,
								7,
								6,
								10,
								9,
								0,
								10,
								0,
								2
							],
							[
								7,
								6,
								11,
								3,
								2,
								8,
								8,
								2,
								10,
								8,
								10,
								9
							],
							[
								6,
								10,
								7,
								10,
								1,
								7,
								7,
								1,
								3
							],
							[
								6,
								10,
								1,
								6,
								1,
								7,
								7,
								1,
								0,
								7,
								0,
								8
							],
							[
								9,
								0,
								3,
								6,
								9,
								3,
								6,
								10,
								9,
								6,
								3,
								7
							],
							[
								6,
								10,
								7,
								7,
								10,
								8,
								10,
								9,
								8
							],
							[
								8,
								4,
								6,
								8,
								6,
								11
							],
							[
								11,
								3,
								6,
								3,
								0,
								6,
								6,
								0,
								4
							],
							[
								0,
								1,
								9,
								4,
								6,
								11,
								4,
								11,
								8
							],
							[
								1,
								9,
								4,
								11,
								1,
								4,
								11,
								3,
								1,
								11,
								4,
								6
							],
							[
								3,
								8,
								2,
								8,
								4,
								2,
								2,
								4,
								6
							],
							[
								2,
								0,
								4,
								2,
								4,
								6
							],
							[
								1,
								9,
								0,
								3,
								8,
								2,
								2,
								8,
								4,
								2,
								4,
								6
							],
							[
								9,
								4,
								1,
								1,
								4,
								2,
								4,
								6,
								2
							],
							[
								10,
								1,
								2,
								11,
								8,
								4,
								11,
								4,
								6
							],
							[
								10,
								1,
								2,
								11,
								3,
								6,
								6,
								3,
								0,
								6,
								0,
								4
							],
							[
								0,
								2,
								10,
								0,
								10,
								9,
								4,
								11,
								8,
								4,
								6,
								11
							],
							[
								2,
								11,
								3,
								6,
								9,
								4,
								6,
								10,
								9
							],
							[
								8,
								4,
								6,
								8,
								6,
								1,
								6,
								10,
								1,
								8,
								1,
								3
							],
							[
								1,
								0,
								10,
								10,
								0,
								6,
								0,
								4,
								6
							],
							[
								8,
								0,
								3,
								9,
								6,
								10,
								9,
								4,
								6
							],
							[
								10,
								4,
								6,
								10,
								9,
								4
							],
							[
								9,
								5,
								4,
								7,
								6,
								11
							],
							[
								4,
								9,
								5,
								3,
								0,
								8,
								11,
								7,
								6
							],
							[
								6,
								11,
								7,
								4,
								0,
								1,
								4,
								1,
								5
							],
							[
								6,
								11,
								7,
								4,
								8,
								5,
								5,
								8,
								3,
								5,
								3,
								1
							],
							[
								4,
								9,
								5,
								6,
								2,
								3,
								6,
								3,
								7
							],
							[
								9,
								5,
								4,
								8,
								7,
								0,
								0,
								7,
								6,
								0,
								6,
								2
							],
							[
								4,
								0,
								1,
								4,
								1,
								5,
								6,
								3,
								7,
								6,
								2,
								3
							],
							[
								7,
								4,
								8,
								5,
								2,
								1,
								5,
								6,
								2
							],
							[
								6,
								11,
								7,
								1,
								2,
								10,
								9,
								5,
								4
							],
							[
								11,
								7,
								6,
								8,
								3,
								0,
								1,
								2,
								10,
								9,
								5,
								4
							],
							[
								11,
								7,
								6,
								10,
								5,
								2,
								2,
								5,
								4,
								2,
								4,
								0
							],
							[
								7,
								4,
								8,
								2,
								11,
								3,
								10,
								5,
								6
							],
							[
								4,
								9,
								5,
								6,
								10,
								7,
								7,
								10,
								1,
								7,
								1,
								3
							],
							[
								5,
								6,
								10,
								0,
								9,
								1,
								8,
								7,
								4
							],
							[
								5,
								6,
								10,
								7,
								0,
								3,
								7,
								4,
								0
							],
							[
								10,
								5,
								6,
								4,
								8,
								7
							],
							[
								5,
								6,
								9,
								6,
								11,
								9,
								9,
								11,
								8
							],
							[
								0,
								9,
								5,
								0,
								5,
								3,
								3,
								5,
								6,
								3,
								6,
								11
							],
							[
								0,
								1,
								5,
								0,
								5,
								11,
								5,
								6,
								11,
								0,
								11,
								8
							],
							[
								11,
								3,
								6,
								6,
								3,
								5,
								3,
								1,
								5
							],
							[
								9,
								5,
								6,
								3,
								9,
								6,
								3,
								8,
								9,
								3,
								6,
								2
							],
							[
								5,
								6,
								9,
								9,
								6,
								0,
								6,
								2,
								0
							],
							[
								0,
								3,
								8,
								2,
								5,
								6,
								2,
								1,
								5
							],
							[
								1,
								6,
								2,
								1,
								5,
								6
							],
							[
								1,
								2,
								10,
								5,
								6,
								9,
								9,
								6,
								11,
								9,
								11,
								8
							],
							[
								1,
								0,
								9,
								6,
								10,
								5,
								11,
								3,
								2
							],
							[
								6,
								10,
								5,
								2,
								8,
								0,
								2,
								11,
								8
							],
							[
								3,
								2,
								11,
								10,
								5,
								6
							],
							[
								10,
								5,
								6,
								9,
								3,
								8,
								9,
								1,
								3
							],
							[
								0,
								9,
								1,
								5,
								6,
								10
							],
							[
								8,
								0,
								3,
								10,
								5,
								6
							],
							[
								10,
								5,
								6
							],
							[
								10,
								6,
								5
							],
							[
								8,
								3,
								0,
								10,
								6,
								5
							],
							[
								0,
								1,
								9,
								5,
								10,
								6
							],
							[
								10,
								6,
								5,
								9,
								8,
								3,
								9,
								3,
								1
							],
							[
								3,
								11,
								2,
								10,
								6,
								5
							],
							[
								6,
								5,
								10,
								2,
								0,
								8,
								2,
								8,
								11
							],
							[
								1,
								9,
								0,
								6,
								5,
								10,
								11,
								2,
								3
							],
							[
								1,
								10,
								2,
								5,
								9,
								6,
								9,
								11,
								6,
								9,
								8,
								11
							],
							[
								1,
								2,
								6,
								1,
								6,
								5
							],
							[
								0,
								8,
								3,
								2,
								6,
								5,
								2,
								5,
								1
							],
							[
								5,
								9,
								6,
								9,
								0,
								6,
								6,
								0,
								2
							],
							[
								9,
								6,
								5,
								3,
								6,
								9,
								3,
								9,
								8,
								3,
								2,
								6
							],
							[
								11,
								6,
								3,
								6,
								5,
								3,
								3,
								5,
								1
							],
							[
								0,
								5,
								1,
								0,
								11,
								5,
								5,
								11,
								6,
								0,
								8,
								11
							],
							[
								0,
								5,
								9,
								0,
								3,
								5,
								3,
								6,
								5,
								3,
								11,
								6
							],
							[
								5,
								9,
								6,
								6,
								9,
								11,
								9,
								8,
								11
							],
							[
								10,
								6,
								5,
								4,
								7,
								8
							],
							[
								5,
								10,
								6,
								7,
								3,
								0,
								7,
								0,
								4
							],
							[
								5,
								10,
								6,
								0,
								1,
								9,
								8,
								4,
								7
							],
							[
								4,
								5,
								9,
								6,
								7,
								10,
								7,
								1,
								10,
								7,
								3,
								1
							],
							[
								7,
								8,
								4,
								2,
								3,
								11,
								10,
								6,
								5
							],
							[
								11,
								6,
								7,
								10,
								2,
								5,
								2,
								4,
								5,
								2,
								0,
								4
							],
							[
								11,
								6,
								7,
								8,
								0,
								3,
								1,
								10,
								2,
								9,
								4,
								5
							],
							[
								6,
								7,
								11,
								1,
								10,
								2,
								9,
								4,
								5
							],
							[
								7,
								8,
								4,
								5,
								1,
								2,
								5,
								2,
								6
							],
							[
								4,
								1,
								0,
								4,
								5,
								1,
								6,
								7,
								3,
								6,
								3,
								2
							],
							[
								9,
								4,
								5,
								8,
								0,
								7,
								0,
								6,
								7,
								0,
								2,
								6
							],
							[
								4,
								5,
								9,
								6,
								3,
								2,
								6,
								7,
								3
							],
							[
								6,
								7,
								11,
								4,
								5,
								8,
								5,
								3,
								8,
								5,
								1,
								3
							],
							[
								6,
								7,
								11,
								4,
								1,
								0,
								4,
								5,
								1
							],
							[
								4,
								5,
								9,
								3,
								8,
								0,
								11,
								6,
								7
							],
							[
								9,
								4,
								5,
								7,
								11,
								6
							],
							[
								10,
								6,
								4,
								10,
								4,
								9
							],
							[
								8,
								3,
								0,
								9,
								10,
								6,
								9,
								6,
								4
							],
							[
								1,
								10,
								0,
								10,
								6,
								0,
								0,
								6,
								4
							],
							[
								8,
								6,
								4,
								8,
								1,
								6,
								6,
								1,
								10,
								8,
								3,
								1
							],
							[
								2,
								3,
								11,
								6,
								4,
								9,
								6,
								9,
								10
							],
							[
								0,
								10,
								2,
								0,
								9,
								10,
								4,
								8,
								11,
								4,
								11,
								6
							],
							[
								10,
								2,
								1,
								11,
								6,
								3,
								6,
								0,
								3,
								6,
								4,
								0
							],
							[
								10,
								2,
								1,
								11,
								4,
								8,
								11,
								6,
								4
							],
							[
								9,
								1,
								4,
								1,
								2,
								4,
								4,
								2,
								6
							],
							[
								1,
								0,
								9,
								3,
								2,
								8,
								2,
								4,
								8,
								2,
								6,
								4
							],
							[
								2,
								4,
								0,
								2,
								6,
								4
							],
							[
								3,
								2,
								8,
								8,
								2,
								4,
								2,
								6,
								4
							],
							[
								1,
								4,
								9,
								11,
								4,
								1,
								11,
								1,
								3,
								11,
								6,
								4
							],
							[
								0,
								9,
								1,
								4,
								11,
								6,
								4,
								8,
								11
							],
							[
								11,
								6,
								3,
								3,
								6,
								0,
								6,
								4,
								0
							],
							[
								8,
								6,
								4,
								8,
								11,
								6
							],
							[
								6,
								7,
								10,
								7,
								8,
								10,
								10,
								8,
								9
							],
							[
								9,
								3,
								0,
								6,
								3,
								9,
								6,
								9,
								10,
								6,
								7,
								3
							],
							[
								6,
								1,
								10,
								6,
								7,
								1,
								7,
								0,
								1,
								7,
								8,
								0
							],
							[
								6,
								7,
								10,
								10,
								7,
								1,
								7,
								3,
								1
							],
							[
								7,
								11,
								6,
								3,
								8,
								2,
								8,
								10,
								2,
								8,
								9,
								10
							],
							[
								11,
								6,
								7,
								10,
								0,
								9,
								10,
								2,
								0
							],
							[
								2,
								1,
								10,
								7,
								11,
								6,
								8,
								0,
								3
							],
							[
								1,
								10,
								2,
								6,
								7,
								11
							],
							[
								7,
								2,
								6,
								7,
								9,
								2,
								2,
								9,
								1,
								7,
								8,
								9
							],
							[
								1,
								0,
								9,
								3,
								6,
								7,
								3,
								2,
								6
							],
							[
								8,
								0,
								7,
								7,
								0,
								6,
								0,
								2,
								6
							],
							[
								2,
								7,
								3,
								2,
								6,
								7
							],
							[
								7,
								11,
								6,
								3,
								9,
								1,
								3,
								8,
								9
							],
							[
								9,
								1,
								0,
								11,
								6,
								7
							],
							[
								0,
								3,
								8,
								11,
								6,
								7
							],
							[
								11,
								6,
								7
							],
							[
								11,
								7,
								5,
								11,
								5,
								10
							],
							[
								3,
								0,
								8,
								7,
								5,
								10,
								7,
								10,
								11
							],
							[
								9,
								0,
								1,
								10,
								11,
								7,
								10,
								7,
								5
							],
							[
								3,
								1,
								9,
								3,
								9,
								8,
								7,
								10,
								11,
								7,
								5,
								10
							],
							[
								10,
								2,
								5,
								2,
								3,
								5,
								5,
								3,
								7
							],
							[
								5,
								10,
								2,
								8,
								5,
								2,
								8,
								7,
								5,
								8,
								2,
								0
							],
							[
								9,
								0,
								1,
								10,
								2,
								5,
								5,
								2,
								3,
								5,
								3,
								7
							],
							[
								1,
								10,
								2,
								5,
								8,
								7,
								5,
								9,
								8
							],
							[
								2,
								11,
								1,
								11,
								7,
								1,
								1,
								7,
								5
							],
							[
								0,
								8,
								3,
								2,
								11,
								1,
								1,
								11,
								7,
								1,
								7,
								5
							],
							[
								9,
								0,
								2,
								9,
								2,
								7,
								2,
								11,
								7,
								9,
								7,
								5
							],
							[
								11,
								3,
								2,
								8,
								5,
								9,
								8,
								7,
								5
							],
							[
								1,
								3,
								7,
								1,
								7,
								5
							],
							[
								8,
								7,
								0,
								0,
								7,
								1,
								7,
								5,
								1
							],
							[
								0,
								3,
								9,
								9,
								3,
								5,
								3,
								7,
								5
							],
							[
								9,
								7,
								5,
								9,
								8,
								7
							],
							[
								4,
								5,
								8,
								5,
								10,
								8,
								8,
								10,
								11
							],
							[
								3,
								0,
								4,
								3,
								4,
								10,
								4,
								5,
								10,
								3,
								10,
								11
							],
							[
								0,
								1,
								9,
								4,
								5,
								8,
								8,
								5,
								10,
								8,
								10,
								11
							],
							[
								5,
								9,
								4,
								1,
								11,
								3,
								1,
								10,
								11
							],
							[
								3,
								8,
								4,
								3,
								4,
								2,
								2,
								4,
								5,
								2,
								5,
								10
							],
							[
								10,
								2,
								5,
								5,
								2,
								4,
								2,
								0,
								4
							],
							[
								0,
								3,
								8,
								5,
								9,
								4,
								10,
								2,
								1
							],
							[
								2,
								1,
								10,
								9,
								4,
								5
							],
							[
								8,
								4,
								5,
								2,
								8,
								5,
								2,
								11,
								8,
								2,
								5,
								1
							],
							[
								3,
								2,
								11,
								1,
								4,
								5,
								1,
								0,
								4
							],
							[
								9,
								4,
								5,
								8,
								2,
								11,
								8,
								0,
								2
							],
							[
								11,
								3,
								2,
								9,
								4,
								5
							],
							[
								4,
								5,
								8,
								8,
								5,
								3,
								5,
								1,
								3
							],
							[
								5,
								0,
								4,
								5,
								1,
								0
							],
							[
								3,
								8,
								0,
								4,
								5,
								9
							],
							[
								9,
								4,
								5
							],
							[
								7,
								4,
								11,
								4,
								9,
								11,
								11,
								9,
								10
							],
							[
								3,
								0,
								8,
								7,
								4,
								11,
								11,
								4,
								9,
								11,
								9,
								10
							],
							[
								11,
								7,
								4,
								1,
								11,
								4,
								1,
								10,
								11,
								1,
								4,
								0
							],
							[
								8,
								7,
								4,
								11,
								1,
								10,
								11,
								3,
								1
							],
							[
								2,
								3,
								7,
								2,
								7,
								9,
								7,
								4,
								9,
								2,
								9,
								10
							],
							[
								4,
								8,
								7,
								0,
								10,
								2,
								0,
								9,
								10
							],
							[
								2,
								1,
								10,
								0,
								7,
								4,
								0,
								3,
								7
							],
							[
								10,
								2,
								1,
								8,
								7,
								4
							],
							[
								2,
								11,
								7,
								2,
								7,
								1,
								1,
								7,
								4,
								1,
								4,
								9
							],
							[
								3,
								2,
								11,
								4,
								8,
								7,
								9,
								1,
								0
							],
							[
								7,
								4,
								11,
								11,
								4,
								2,
								4,
								0,
								2
							],
							[
								2,
								11,
								3,
								7,
								4,
								8
							],
							[
								9,
								1,
								4,
								4,
								1,
								7,
								1,
								3,
								7
							],
							[
								1,
								0,
								9,
								8,
								7,
								4
							],
							[
								3,
								4,
								0,
								3,
								7,
								4
							],
							[
								8,
								7,
								4
							],
							[
								8,
								9,
								10,
								8,
								10,
								11
							],
							[
								0,
								9,
								3,
								3,
								9,
								11,
								9,
								10,
								11
							],
							[
								1,
								10,
								0,
								0,
								10,
								8,
								10,
								11,
								8
							],
							[
								10,
								3,
								1,
								10,
								11,
								3
							],
							[
								3,
								8,
								2,
								2,
								8,
								10,
								8,
								9,
								10
							],
							[
								9,
								2,
								0,
								9,
								10,
								2
							],
							[
								8,
								0,
								3,
								1,
								10,
								2
							],
							[
								10,
								2,
								1
							],
							[
								2,
								11,
								1,
								1,
								11,
								9,
								11,
								8,
								9
							],
							[
								11,
								3,
								2,
								0,
								9,
								1
							],
							[
								11,
								0,
								2,
								11,
								8,
								0
							],
							[
								11,
								3,
								2
							],
							[
								8,
								1,
								3,
								8,
								9,
								1
							],
							[
								9,
								1,
								0
							],
							[
								8,
								0,
								3
							],
							[]
						];
					}
					march(e, t, n, i) {
						let a = !!i.fulltable, o = i.hasOwnProperty("origin") && i.origin.hasOwnProperty("x") ? i.origin : {
							x: 0,
							y: 0,
							z: 0
						}, s = !!i.voxel, c = i.matrix, l = i.nX || 0, u = i.nY || 0, d = i.nZ || 0, f = i.scale || 1, p = null;
						p = i.unitCube ? i.unitCube : {
							x: f,
							y: f,
							z: f
						};
						let m = new Int32Array(l * u * d), h, g;
						for (h = 0, g = m.length; h < g; ++h) m[h] = -1;
						let _ = function(e, n, i, a, l, f) {
							let h = {
								x: 0,
								y: 0,
								z: 0
							}, g = !!(a & 1 << l), _ = !!(a & 1 << f), v = l;
							if (!g && _ && (v = f), v & 1 && i++, v & 2 && n++, v & 4 && e++, c) {
								let t = new r.Vector3(e, n, i);
								t = t.applyMatrix4(c), h = {
									x: t.x,
									y: t.y,
									z: t.z
								};
							} else h.x = o.x + p.x * e, h.y = o.y + p.y * n, h.z = o.z + p.z * i;
							let y = (u * e + n) * d + i;
							return s ? (t.push(h), t.length - 1) : (m[y] < 0 && (m[y] = t.length, t.push(h)), m[y]);
						}, v = /* @__PURE__ */ new Int32Array(12), y = a ? this.edgeTable2 : this.edgeTable, b = a ? this.triTable2 : this.triTable;
						for (h = 0; h < l - 1; ++h) for (let r = 0; r < u - 1; ++r) for (let i = 0; i < d - 1; ++i) {
							let a = 0;
							for (let t = 0; t < 8; ++t) {
								let n = !!(e[(u * (h + ((t & 4) >> 2)) + r + ((t & 2) >> 1)) * d + i + (t & 1)] & this.ISDONE);
								a |= n << t;
							}
							if (a === 0 || a === 255) continue;
							let o = y[a];
							if (o === 0) continue;
							let c = b[a];
							o & 1 && (v[0] = _(h, r, i, a, 0, 1)), o & 2 && (v[1] = _(h, r, i, a, 1, 3)), o & 4 && (v[2] = _(h, r, i, a, 3, 2)), o & 8 && (v[3] = _(h, r, i, a, 2, 0)), o & 16 && (v[4] = _(h, r, i, a, 4, 5)), o & 32 && (v[5] = _(h, r, i, a, 5, 7)), o & 64 && (v[6] = _(h, r, i, a, 7, 6)), o & 128 && (v[7] = _(h, r, i, a, 6, 4)), o & 256 && (v[8] = _(h, r, i, a, 0, 4)), o & 512 && (v[9] = _(h, r, i, a, 1, 5)), o & 1024 && (v[10] = _(h, r, i, a, 3, 7)), o & 2048 && (v[11] = _(h, r, i, a, 2, 6));
							for (let e = 0; e < c.length; e += 3) {
								let r = v[c[e]], i = v[c[e + 1]], a = v[c[e + 2]];
								s && e >= 3 && (t.push(t[r]), r = t.length - 1, t.push(t[i]), i = t.length - 1, t.push(t[a]), a = t.length - 1), n.push(r), n.push(i), n.push(a);
							}
						}
					}
					laplacianSmooth(e, t, n) {
						let r = Array(t.length), i, a, o, s, c;
						for (i = 0, a = t.length; i < a; i++) r[i] = {
							x: 0,
							y: 0,
							z: 0
						};
						let l = Array(20), u;
						for (i = 0; i < 20; i++) l[i] = Array(t.length);
						for (i = 0, a = t.length; i < a; i++) l[0][i] = 0;
						for (i = 0, a = n.length / 3; i < a; i++) {
							let e = i * 3, t = i * 3 + 1, r = i * 3 + 2;
							for (u = !0, o = 0, s = l[0][n[e]]; o < s; o++) if (n[t] == l[o + 1][n[e]]) {
								u = !1;
								break;
							}
							for (u && (l[0][n[e]]++, l[l[0][n[e]]][n[e]] = n[t]), u = !0, o = 0, s = l[0][n[e]]; o < s; o++) if (n[r] == l[o + 1][n[e]]) {
								u = !1;
								break;
							}
							for (u && (l[0][n[e]]++, l[l[0][n[e]]][n[e]] = n[r]), u = !0, o = 0, s = l[0][n[t]]; o < s; o++) if (n[e] == l[o + 1][n[t]]) {
								u = !1;
								break;
							}
							for (u && (l[0][n[t]]++, l[l[0][n[t]]][n[t]] = n[e]), u = !0, o = 0, s = l[0][n[t]]; o < s; o++) if (n[r] == l[o + 1][n[t]]) {
								u = !1;
								break;
							}
							for (u && (l[0][n[t]]++, l[l[0][n[t]]][n[t]] = n[r]), u = !0, o = 0; o < l[0][n[r]]; o++) if (n[e] == l[o + 1][n[r]]) {
								u = !1;
								break;
							}
							for (u && (l[0][n[r]]++, l[l[0][n[r]]][n[r]] = n[e]), u = !0, o = 0, s = l[0][n[r]]; o < s; o++) if (n[t] == l[o + 1][n[r]]) {
								u = !1;
								break;
							}
							u && (l[0][n[r]]++, l[l[0][n[r]]][n[r]] = n[t]);
						}
						let d = 1, f = .5;
						for (c = 0; c < e; c++) {
							for (i = 0, a = t.length; i < a; i++) if (l[0][i] < 3) r[i].x = t[i].x, r[i].y = t[i].y, r[i].z = t[i].z;
							else if (l[0][i] == 3 || l[0][i] == 4) {
								for (r[i].x = 0, r[i].y = 0, r[i].z = 0, o = 0, s = l[0][i]; o < s; o++) r[i].x += t[l[o + 1][i]].x, r[i].y += t[l[o + 1][i]].y, r[i].z += t[l[o + 1][i]].z;
								r[i].x += f * t[i].x, r[i].y += f * t[i].y, r[i].z += f * t[i].z, r[i].x /= f + l[0][i], r[i].y /= f + l[0][i], r[i].z /= f + l[0][i];
							} else {
								for (r[i].x = 0, r[i].y = 0, r[i].z = 0, o = 0, s = l[0][i]; o < s; o++) r[i].x += t[l[o + 1][i]].x, r[i].y += t[l[o + 1][i]].y, r[i].z += t[l[o + 1][i]].z;
								r[i].x += 1 * t[i].x, r[i].y += 1 * t[i].y, r[i].z += 1 * t[i].z, r[i].x /= 1 + l[0][i], r[i].y /= 1 + l[0][i], r[i].z /= 1 + l[0][i];
							}
							for (i = 0, a = t.length; i < a; i++) t[i].x = r[i].x, t[i].y = r[i].y, t[i].z = r[i].z;
						}
					}
				}
				let c = new s();
				class l {
					constructor(e, t, n) {
						this.data = new Int32Array(e * t * n * 3), this.width = t, this.height = n;
					}
					set(e, t, n, r) {
						let i = ((e * this.width + t) * this.height + n) * 3;
						this.data[i] = r.ix, this.data[i + 1] = r.iy, this.data[i + 2] = r.iz;
					}
					get(e, t, n) {
						let r = ((e * this.width + t) * this.height + n) * 3;
						return {
							ix: this.data[r],
							iy: this.data[r + 1],
							iz: this.data[r + 2]
						};
					}
				}
				class u {
					constructor() {
						this.INOUT = 1, this.ISDONE = 2, this.ISBOUND = 4, this.ptranx = 0, this.ptrany = 0, this.ptranz = 0, this.probeRadius = 1.4, this.defaultScaleFactor = 2, this.scaleFactor = this.defaultScaleFactor, this.pHeight = 0, this.pWidth = 0, this.pLength = 0, this.cutRadius = 0, this.vpBits = null, this.vpDistance = null, this.vpAtomID = null, this.pminx = 0, this.pminy = 0, this.pminz = 0, this.pmaxx = 0, this.pmaxy = 0, this.pmaxz = 0, this.depty = {}, this.widxz = {}, this.faces = [], this.verts = [], this.vdwRadii = {
							H: 1.2,
							Li: 1.82,
							Na: 2.27,
							K: 2.75,
							C: 1.7,
							N: 1.55,
							O: 1.52,
							F: 1.47,
							P: 1.8,
							S: 1.8,
							CL: 1.75,
							BR: 1.85,
							SE: 1.9,
							ZN: 1.39,
							CU: 1.4,
							NI: 1.63,
							X: 2
						}, this.nb = [
							new Int32Array([
								1,
								0,
								0
							]),
							new Int32Array([
								-1,
								0,
								0
							]),
							new Int32Array([
								0,
								1,
								0
							]),
							new Int32Array([
								0,
								-1,
								0
							]),
							new Int32Array([
								0,
								0,
								1
							]),
							new Int32Array([
								0,
								0,
								-1
							]),
							new Int32Array([
								1,
								1,
								0
							]),
							new Int32Array([
								1,
								-1,
								0
							]),
							new Int32Array([
								-1,
								1,
								0
							]),
							new Int32Array([
								-1,
								-1,
								0
							]),
							new Int32Array([
								1,
								0,
								1
							]),
							new Int32Array([
								1,
								0,
								-1
							]),
							new Int32Array([
								-1,
								0,
								1
							]),
							new Int32Array([
								-1,
								0,
								-1
							]),
							new Int32Array([
								0,
								1,
								1
							]),
							new Int32Array([
								0,
								1,
								-1
							]),
							new Int32Array([
								0,
								-1,
								1
							]),
							new Int32Array([
								0,
								-1,
								-1
							]),
							new Int32Array([
								1,
								1,
								1
							]),
							new Int32Array([
								1,
								1,
								-1
							]),
							new Int32Array([
								1,
								-1,
								1
							]),
							new Int32Array([
								-1,
								1,
								1
							]),
							new Int32Array([
								1,
								-1,
								-1
							]),
							new Int32Array([
								-1,
								-1,
								1
							]),
							new Int32Array([
								-1,
								1,
								-1
							]),
							new Int32Array([
								-1,
								-1,
								-1
							])
						], u.MarchingCube ||= new s();
					}
					getVDWIndex(e) {
						return !e.elem || this.vdwRadii[e.elem] === void 0 ? "X" : e.elem;
					}
					getFacesAndVertices(e) {
						let t = {};
						for (let n = 0, r = e.length; n < r; n++) t[e[n]] = !0;
						let n = this.verts;
						for (let e = 0, t = n.length; e < t; e++) n[e].x = n[e].x / this.scaleFactor - this.ptranx, n[e].y = n[e].y / this.scaleFactor - this.ptrany, n[e].z = n[e].z / this.scaleFactor - this.ptranz;
						let r = [];
						for (let e = 0, i = this.faces.length; e < i; e += 3) {
							let i = this.faces[e], a = this.faces[e + 1], o = this.faces[e + 2], s = n[i].atomid, c = n[a].atomid, l = n[o].atomid, u = s;
							c < u && (u = c), l < u && (u = l), t[u] && i !== a && a !== o && i !== o && (r.push(i), r.push(a), r.push(o));
						}
						return this.vpBits = null, this.vpDistance = null, this.vpAtomID = null, {
							vertices: n,
							faces: r
						};
					}
					initparm(e, t, n) {
						n > 1e6 && (this.scaleFactor = this.defaultScaleFactor / 2);
						let r = 1 / this.scaleFactor * 5.5;
						this.pminx = e[0][0], this.pmaxx = e[1][0], this.pminy = e[0][1], this.pmaxy = e[1][1], this.pminz = e[0][2], this.pmaxz = e[1][2], t ? (this.pminx -= this.probeRadius + r, this.pminy -= this.probeRadius + r, this.pminz -= this.probeRadius + r, this.pmaxx += this.probeRadius + r, this.pmaxy += this.probeRadius + r, this.pmaxz += this.probeRadius + r) : (this.pminx -= r, this.pminy -= r, this.pminz -= r, this.pmaxx += r, this.pmaxy += r, this.pmaxz += r), this.pminx = Math.floor(this.pminx * this.scaleFactor) / this.scaleFactor, this.pminy = Math.floor(this.pminy * this.scaleFactor) / this.scaleFactor, this.pminz = Math.floor(this.pminz * this.scaleFactor) / this.scaleFactor, this.pmaxx = Math.ceil(this.pmaxx * this.scaleFactor) / this.scaleFactor, this.pmaxy = Math.ceil(this.pmaxy * this.scaleFactor) / this.scaleFactor, this.pmaxz = Math.ceil(this.pmaxz * this.scaleFactor) / this.scaleFactor, this.ptranx = -this.pminx, this.ptrany = -this.pminy, this.ptranz = -this.pminz, this.pLength = Math.ceil(this.scaleFactor * (this.pmaxx - this.pminx)) + 1, this.pWidth = Math.ceil(this.scaleFactor * (this.pmaxy - this.pminy)) + 1, this.pHeight = Math.ceil(this.scaleFactor * (this.pmaxz - this.pminz)) + 1, this.boundingatom(t), this.cutRadius = this.probeRadius * this.scaleFactor, this.vpBits = new Uint8Array(this.pLength * this.pWidth * this.pHeight), this.vpDistance = new Float64Array(this.pLength * this.pWidth * this.pHeight), this.vpAtomID = new Int32Array(this.pLength * this.pWidth * this.pHeight);
					}
					boundingatom(e) {
						let t = {};
						for (let n in this.vdwRadii) {
							let r = this.vdwRadii[n];
							t[n] = e ? (r + this.probeRadius) * this.scaleFactor + .5 : r * this.scaleFactor + .5;
							let i = t[n] * t[n];
							this.widxz[n] = Math.floor(t[n]) + 1, this.depty[n] = new Int32Array(this.widxz[n] * this.widxz[n]);
							let a = 0;
							for (let e = 0; e < this.widxz[n]; e++) for (let t = 0; t < this.widxz[n]; t++) {
								let r = e * e + t * t;
								if (r > i) this.depty[n][a] = -1;
								else {
									let e = Math.sqrt(i - r);
									this.depty[n][a] = Math.floor(e);
								}
								a++;
							}
						}
					}
					fillvoxels(e, t) {
						for (let e = 0, t = this.vpBits.length; e < t; e++) this.vpBits[e] = 0, this.vpDistance[e] = -1, this.vpAtomID[e] = -1;
						for (let n in t) {
							let r = e[t[n]];
							r !== void 0 && this.fillAtom(r, e);
						}
						for (let e = 0, t = this.vpBits.length; e < t; e++) this.vpBits[e] & this.INOUT && (this.vpBits[e] |= this.ISDONE);
					}
					fillAtom(e, t) {
						let n = Math.floor(.5 + this.scaleFactor * (e.x + this.ptranx)), r = Math.floor(.5 + this.scaleFactor * (e.y + this.ptrany)), i = Math.floor(.5 + this.scaleFactor * (e.z + this.ptranz)), a = this.getVDWIndex(e), o = 0, s = this.pWidth * this.pHeight;
						for (let c = 0, l = this.widxz[a]; c < l; c++) for (let u = 0; u < l; u++) {
							if (this.depty[a][o] != -1) {
								for (let l = -1; l < 2; l++) for (let d = -1; d < 2; d++) for (let f = -1; f < 2; f++) if (l !== 0 && d !== 0 && f !== 0) {
									let p = l * c, m = f * u;
									for (let c = 0; c <= this.depty[a][o]; c++) {
										let a = c * d, o = n + p, l = r + a, u = i + m;
										if (o < 0 || l < 0 || u < 0 || o >= this.pLength || l >= this.pWidth || u >= this.pHeight) continue;
										let f = o * s + l * this.pHeight + u;
										if (!(this.vpBits[f] & this.INOUT)) this.vpBits[f] |= this.INOUT, this.vpAtomID[f] = e.serial;
										else {
											let o = t[this.vpAtomID[f]];
											if (o.serial != e.serial) {
												let t = n + p - Math.floor(.5 + this.scaleFactor * (o.x + this.ptranx)), s = r + a - Math.floor(.5 + this.scaleFactor * (o.y + this.ptrany)), c = i + m - Math.floor(.5 + this.scaleFactor * (o.z + this.ptranz));
												p * p + a * a + m * m < t * t + s * s + c * c && (this.vpAtomID[f] = e.serial);
											}
										}
									}
								}
							}
							o++;
						}
					}
					fillvoxelswaals(e, t) {
						for (let e = 0, t = this.vpBits.length; e < t; e++) this.vpBits[e] &= ~this.ISDONE;
						for (let n in t) {
							let r = e[t[n]];
							r !== void 0 && this.fillAtomWaals(r, e);
						}
					}
					fillAtomWaals(e, t) {
						let n = 0, r = Math.floor(.5 + this.scaleFactor * (e.x + this.ptranx)), i = Math.floor(.5 + this.scaleFactor * (e.y + this.ptrany)), a = Math.floor(.5 + this.scaleFactor * (e.z + this.ptranz)), o = this.getVDWIndex(e), s = this.pWidth * this.pHeight;
						for (let c = 0, l = this.widxz[o]; c < l; c++) for (let u = 0; u < l; u++) {
							if (this.depty[o][n] != -1) {
								for (let l = -1; l < 2; l++) for (let d = -1; d < 2; d++) for (let f = -1; f < 2; f++) if (l !== 0 && d !== 0 && f !== 0) {
									let p = l * c, m = f * u;
									for (let c = 0; c <= this.depty[o][n]; c++) {
										let n = c * d, o = r + p, l = i + n, u = a + m;
										if (o < 0 || l < 0 || u < 0 || o >= this.pLength || l >= this.pWidth || u >= this.pHeight) continue;
										let f = o * s + l * this.pHeight + u;
										if (!(this.vpBits[f] & this.ISDONE)) this.vpBits[f] |= this.ISDONE, this.vpAtomID[f] = e.serial;
										else {
											let o = t[this.vpAtomID[f]];
											if (o.serial != e.serial) {
												let t = r + p - Math.floor(.5 + this.scaleFactor * (o.x + this.ptranx)), s = i + n - Math.floor(.5 + this.scaleFactor * (o.y + this.ptrany)), c = a + m - Math.floor(.5 + this.scaleFactor * (o.z + this.ptranz));
												p * p + n * n + m * m < t * t + s * s + c * c && (this.vpAtomID[f] = e.serial);
											}
										}
									}
								}
							}
							n++;
						}
					}
					buildboundary() {
						let e = this.pWidth * this.pHeight;
						for (let t = 0; t < this.pLength; t++) for (let n = 0; n < this.pHeight; n++) for (let r = 0; r < this.pWidth; r++) {
							let i = t * e + r * this.pHeight + n;
							if (this.vpBits[i] & this.INOUT) {
								let a = 0;
								for (; a < 26;) {
									let o = t + this.nb[a][0], s = n + this.nb[a][2], c = r + this.nb[a][1];
									if (o > -1 && o < this.pLength && c > -1 && c < this.pWidth && s > -1 && s < this.pHeight && !(this.vpBits[o * e + c * this.pHeight + s] & this.INOUT)) {
										this.vpBits[i] |= this.ISBOUND;
										break;
									}
									a++;
								}
							}
						}
					}
					fastdistancemap() {
						let e = new l(this.pLength, this.pWidth, this.pHeight), t = this.pWidth * this.pHeight, n = this.cutRadius * this.cutRadius, r = [], i = [], a;
						for (let n = 0; n < this.pLength; n++) for (let i = 0; i < this.pWidth; i++) for (let o = 0; o < this.pHeight; o++) if (a = n * t + i * this.pHeight + o, this.vpBits[a] &= ~this.ISDONE, this.vpBits[a] & this.INOUT && this.vpBits[a] & this.ISBOUND) {
							let t = {
								ix: n,
								iy: i,
								iz: o
							};
							e.set(n, i, o, t), r.push(t), this.vpDistance[a] = 0, this.vpBits[a] |= this.ISDONE, this.vpBits[a] &= ~this.ISBOUND;
						}
						do {
							i = this.fastoneshell(r, e), r = [];
							for (let e = 0, o = i.length; e < o; e++) a = t * i[e].ix + this.pHeight * i[e].iy + i[e].iz, this.vpBits[a] &= ~this.ISBOUND, this.vpDistance[a] <= 1.0404 * n && r.push({
								ix: i[e].ix,
								iy: i[e].iy,
								iz: i[e].iz
							});
						} while (r.length !== 0);
						r = [], i = [], e = null;
						let o = this.scaleFactor - .5;
						o < 0 && (o = 0);
						let s = n - .5 / (.1 + o);
						for (let e = 0; e < this.pLength; e++) for (let n = 0; n < this.pWidth; n++) for (let r = 0; r < this.pHeight; r++) a = e * t + n * this.pHeight + r, this.vpBits[a] &= ~this.ISBOUND, this.vpBits[a] & this.INOUT && (!(this.vpBits[a] & this.ISDONE) || this.vpBits[a] & this.ISDONE && this.vpDistance[a] >= s) && (this.vpBits[a] |= this.ISBOUND);
					}
					fastoneshell(e, t) {
						let n, r, i, a, o, s, c, l, u, d = [];
						if (e.length === 0) return d;
						let f = {
							ix: -1,
							iy: -1,
							iz: -1
						}, p = this.pWidth * this.pHeight;
						for (let m = 0, h = e.length; m < h; m++) {
							n = e[m].ix, r = e[m].iy, i = e[m].iz, l = t.get(n, r, i);
							for (let e = 0; e < 6; e++) f.ix = n + this.nb[e][0], f.iy = r + this.nb[e][1], f.iz = i + this.nb[e][2], f.ix < this.pLength && f.ix > -1 && f.iy < this.pWidth && f.iy > -1 && f.iz < this.pHeight && f.iz > -1 && (u = f.ix * p + this.pHeight * f.iy + f.iz, this.vpBits[u] & this.INOUT && !(this.vpBits[u] & this.ISDONE) ? (t.set(f.ix, f.iy, i + this.nb[e][2], l), a = f.ix - l.ix, o = f.iy - l.iy, s = f.iz - l.iz, c = a * a + o * o + s * s, this.vpDistance[u] = c, this.vpBits[u] |= this.ISDONE, this.vpBits[u] |= this.ISBOUND, d.push({
								ix: f.ix,
								iy: f.iy,
								iz: f.iz
							})) : this.vpBits[u] & this.INOUT && this.vpBits[u] & this.ISDONE && (a = f.ix - l.ix, o = f.iy - l.iy, s = f.iz - l.iz, c = a * a + o * o + s * s, c < this.vpDistance[u] && (t.set(f.ix, f.iy, f.iz, l), this.vpDistance[u] = c, this.vpBits[u] & this.ISBOUND || (this.vpBits[u] |= this.ISBOUND, d.push({
								ix: f.ix,
								iy: f.iy,
								iz: f.iz
							})))));
						}
						for (let m = 0, h = e.length; m < h; m++) {
							n = e[m].ix, r = e[m].iy, i = e[m].iz, l = t.get(n, r, i);
							for (let e = 6; e < 18; e++) f.ix = n + this.nb[e][0], f.iy = r + this.nb[e][1], f.iz = i + this.nb[e][2], f.ix < this.pLength && f.ix > -1 && f.iy < this.pWidth && f.iy > -1 && f.iz < this.pHeight && f.iz > -1 && (u = f.ix * p + this.pHeight * f.iy + f.iz, this.vpBits[u] & this.INOUT && !(this.vpBits[u] & this.ISDONE) ? (t.set(f.ix, f.iy, i + this.nb[e][2], l), a = f.ix - l.ix, o = f.iy - l.iy, s = f.iz - l.iz, c = a * a + o * o + s * s, this.vpDistance[u] = c, this.vpBits[u] |= this.ISDONE, this.vpBits[u] |= this.ISBOUND, d.push({
								ix: f.ix,
								iy: f.iy,
								iz: f.iz
							})) : this.vpBits[u] & this.INOUT && this.vpBits[u] & this.ISDONE && (a = f.ix - l.ix, o = f.iy - l.iy, s = f.iz - l.iz, c = a * a + o * o + s * s, c < this.vpDistance[u] && (t.set(f.ix, f.iy, f.iz, l), this.vpDistance[u] = c, this.vpBits[u] & this.ISBOUND || (this.vpBits[u] |= this.ISBOUND, d.push({
								ix: f.ix,
								iy: f.iy,
								iz: f.iz
							})))));
						}
						for (let m = 0, h = e.length; m < h; m++) {
							n = e[m].ix, r = e[m].iy, i = e[m].iz, l = t.get(n, r, i);
							for (let e = 18; e < 26; e++) f.ix = n + this.nb[e][0], f.iy = r + this.nb[e][1], f.iz = i + this.nb[e][2], f.ix < this.pLength && f.ix > -1 && f.iy < this.pWidth && f.iy > -1 && f.iz < this.pHeight && f.iz > -1 && (u = f.ix * p + this.pHeight * f.iy + f.iz, this.vpBits[u] & this.INOUT && !(this.vpBits[u] & this.ISDONE) ? (t.set(f.ix, f.iy, i + this.nb[e][2], l), a = f.ix - l.ix, o = f.iy - l.iy, s = f.iz - l.iz, c = a * a + o * o + s * s, this.vpDistance[u] = c, this.vpBits[u] |= this.ISDONE, this.vpBits[u] |= this.ISBOUND, d.push({
								ix: f.ix,
								iy: f.iy,
								iz: f.iz
							})) : this.vpBits[u] & this.INOUT && this.vpBits[u] & this.ISDONE && (a = f.ix - l.ix, o = f.iy - l.iy, s = f.iz - l.iz, c = a * a + o * o + s * s, c < this.vpDistance[u] && (t.set(f.ix, f.iy, f.iz, l), this.vpDistance[u] = c, this.vpBits[u] & this.ISBOUND || (this.vpBits[u] |= this.ISBOUND, d.push({
								ix: f.ix,
								iy: f.iy,
								iz: f.iz
							})))));
						}
						return d;
					}
					marchingcubeinit(e) {
						for (let t = 0, n = this.vpBits.length; t < n; t++) e == 1 ? this.vpBits[t] &= ~this.ISBOUND : e == 4 ? (this.vpBits[t] &= ~this.ISDONE, this.vpBits[t] & this.ISBOUND && (this.vpBits[t] |= this.ISDONE), this.vpBits[t] &= ~this.ISBOUND) : e == 2 ? this.vpBits[t] & this.ISBOUND && this.vpBits[t] & this.ISDONE ? this.vpBits[t] &= ~this.ISBOUND : this.vpBits[t] & this.ISBOUND && !(this.vpBits[t] & this.ISDONE) && (this.vpBits[t] |= this.ISDONE) : e == 3 && (this.vpBits[t] &= ~this.ISBOUND);
					}
					marchingcube(e) {
						this.marchingcubeinit(e), this.verts = [], this.faces = [], u.MarchingCube.march(this.vpBits, this.verts, this.faces, {
							smooth: 1,
							nX: this.pLength,
							nY: this.pWidth,
							nZ: this.pHeight
						});
						let t = this.pWidth * this.pHeight;
						for (let e = 0, n = this.verts.length; e < n; e++) this.verts[e].atomid = this.vpAtomID[this.verts[e].x * t + this.pHeight * this.verts[e].y + this.verts[e].z];
						u.MarchingCube.laplacianSmooth(1, this.verts, this.faces);
					}
				}
				u.MarchingCube = new s();
			},
			"./src/SurfaceWorker.js"() {
				$3Dmol.workerString = function() {
					self.onmessage = function(e) {
						var t = e.data, n = t.type;
						if (n < 0) self.atomData = t.atoms, self.volume = t.volume, self.ps = new ProteinSurface();
						else {
							var r = self.ps;
							r.initparm(t.expandedExtent, n != 1, self.volume), r.fillvoxels(self.atomData, t.extendedAtoms), r.buildboundary(), (n === 4 || n === 2) && (r.fastdistancemap(), r.boundingatom(!1), r.fillvoxelswaals(self.atomData, t.extendedAtoms)), r.marchingcube(n);
							var i = r.getFacesAndVertices(t.atomsToShow);
							self.postMessage(i);
						}
					};
				}.toString().replace(/(^.*?\{|\}$)/g, ""), $3Dmol.workerString += ";\nfunction _classCallCheck() {};", $3Dmol.workerString += ";\n" + $3Dmol.Vector3.toString(), $3Dmol.workerString += ";\n" + $3Dmol.MarchingCubeInitializer.toString() + ";\n\n", $3Dmol.workerString += ";\n" + $3Dmol.PointGrid.toString() + ";\n", $3Dmol.workerString += ";\nvar ProteinSurface = " + $3Dmol.ProteinSurface.toString() + ";\n", $3Dmol.SurfaceWorker = window.URL ? window.URL.createObjectURL(new Blob([$3Dmol.workerString], { type: "text/javascript" })) : void 0;
			},
			"./src/VolumeData.ts"(e, t, n) {
				n.r(t), n.d(t, { VolumeData: () => c });
				var r = n("./src/utilities.ts"), i = n("./src/WebGL/math/index.ts"), a = n("./src/parsers/VASP.ts"), o = n("./src/parsers/CUBE.ts"), s = n("./node_modules/pako/dist/pako.esm.mjs");
				class c {
					constructor(e, t, n) {
						if (this.unit = {
							x: 1,
							y: 1,
							z: 1
						}, this.origin = {
							x: 0,
							y: 0,
							z: 0
						}, this.size = {
							x: 0,
							y: 0,
							z: 0
						}, this.data = new Float32Array([]), this.matrix = null, this.inversematrix = null, this.isbinary = /* @__PURE__ */ new Set(["ccp4", "CCP4"]), this.getCoordinates = function(e) {
							var t = e / (this.size.y * this.size.z), n = e % (this.size.y * this.size.z), r = e % this.size.z;
							return t *= this.unit.x, n *= this.unit.y, r *= this.unit.z, t += this.origin.x, n += this.origin.y, r += this.origin.z, {
								x: t,
								y: n,
								z: r
							};
						}, this.vasp = function(e) {
							var t = e.replace(/^\s+/, "").split(/[\n\r]/), n = (0, a.VASP)(e)[0].length;
							if (n == 0) {
								console.warn("No good formating of CHG or CHGCAR file, not atomic information provided in the file."), this.data = [];
								return;
							}
							var r = 1.889725992, o = .036749309, s = parseFloat(t[1]), c = t[2].replace(/^\s+/, "").split(/\s+/), l = new i.Vector3(parseFloat(c[0]), parseFloat(c[1]), parseFloat(c[2])).multiplyScalar(s * r);
							c = t[3].replace(/^\s+/, "").split(/\s+/);
							var u = new i.Vector3(parseFloat(c[0]), parseFloat(c[1]), parseFloat(c[2])).multiplyScalar(s * r);
							c = t[4].replace(/^\s+/, "").split(/\s+/);
							var d = new i.Vector3(parseFloat(c[0]), parseFloat(c[1]), parseFloat(c[2])).multiplyScalar(s * r), f = l.x * (u.y * d.z - d.y * u.z) - u.x * (l.y * d.z - d.y * l.z) + d.x * (l.y * u.z - u.y * l.z);
							f = Math.abs(f) / r ** 3;
							var p = 1 / f;
							t.splice(0, 8 + n + 1);
							var m = t[0].replace(/^\s+/, "").replace(/\s+/g, " ").split(" "), h = Math.abs(parseFloat(m[0])), g = Math.abs(parseFloat(m[1])), _ = Math.abs(parseFloat(m[2])), v = this.origin = new i.Vector3(0, 0, 0);
							this.size = {
								x: h,
								y: g,
								z: _
							}, this.unit = new i.Vector3(l.x, u.y, d.z), l = l.multiplyScalar(1 / (r * h)), u = u.multiplyScalar(1 / (r * g)), d = d.multiplyScalar(1 / (r * _)), (l.y != 0 || l.z != 0 || u.x != 0 || u.z != 0 || d.x != 0 || d.y != 0) && (this.matrix = new i.Matrix4(l.x, u.x, d.x, 0, l.y, u.y, d.y, 0, l.z, u.z, d.z, 0, 0, 0, 0, 1), this.matrix = this.matrix.multiplyMatrices(this.matrix, new i.Matrix4().makeTranslation(v.x, v.y, v.z)), this.origin = new i.Vector3(0, 0, 0), this.unit = new i.Vector3(1, 1, 1)), t.splice(0, 1);
							var y = t.join(" ");
							y = y.replace(/^\s+/, "");
							var b = y.split(/[\s\r]+/);
							b.splice(h * g * _ + 1);
							for (var x = Float32Array.from(b, parseFloat), S = 0; S < x.length; S++) x[S] = x[S] * p * o;
							this.data = x;
						}, this.dx = function(e) {
							var t = e.split(/[\n\r]+/), n, r = /gridpositions\s+counts\s+(\d+)\s+(\d+)\s+(\d+)/, a = /^origin\s+(\S+)\s+(\S+)\s+(\S+)/, o = /^delta\s+(\S+)\s+(\S+)\s+(\S+)/, s = /data follows/, c = 0;
							for (c = 0; c < t.length; c++) {
								var l = t[c];
								if (n = r.exec(l)) {
									var u = parseInt(n[1]), d = parseInt(n[2]), f = parseInt(n[3]);
									this.size = {
										x: u,
										y: d,
										z: f
									};
								} else if (n = o.exec(l)) {
									var p = parseFloat(n[1]);
									if ((parseFloat(n[2]) != 0 || parseFloat(n[3]) != 0) && console.warn("Non-orthogonal delta matrix not currently supported in dx format"), c += 1, l = t[c], n = o.exec(l), n == null) {
										console.error("Parse error in dx delta matrix");
										return;
									}
									var m = parseFloat(n[2]);
									if ((parseFloat(n[1]) != 0 || parseFloat(n[3]) != 0) && console.warn("Non-orthogonal delta matrix not currently supported in dx format"), c += 1, l = t[c], n = o.exec(l), n == null) {
										console.error("Parse error in dx delta matrix");
										return;
									}
									var h = parseFloat(n[3]);
									(parseFloat(n[1]) != 0 || parseFloat(n[2]) != 0) && console.warn("Non-orthogonal delta matrix not currently supported in dx format"), this.unit = new i.Vector3(p, m, h);
								} else if (n = a.exec(l)) {
									var g = parseFloat(n[1]), _ = parseFloat(n[2]), v = parseFloat(n[3]);
									this.origin = new i.Vector3(g, _, v);
								} else if (n = s.exec(l)) break;
							}
							if (c += 1, !this.size || !this.origin || !this.unit || !this.size) {
								console.error("Error parsing dx format");
								return;
							}
							var y = t.splice(c).join(" ").split(/[\s\r]+/);
							this.data = Float32Array.from(y, parseFloat);
						}, t = t.toLowerCase(), /\.gz$/.test(t)) {
							t = t.replace(/\.gz$/, "");
							try {
								this[t] && this.isbinary.has(t) ? (typeof e == "string" && (e = (0, r.base64ToArray)(e)), e = (0, s.inflate)(e)) : e = new TextDecoder("utf-8").decode((0, s.inflate)(e));
							} catch (e) {
								console.error(e);
							}
						}
						if (this[t] && (this.isbinary.has(t) && typeof e == "string" && (e = (0, r.base64ToArray)(e)), this[t](e)), n) {
							if (n.negate) for (let e = 0, t = this.data.length; e < t; e++) this.data[e] = -this.data[e];
							if (n.normalize) {
								var o = 0;
								for (let e = 0, t = this.data.length; e < t; e++) o += this.data[e];
								var c = o / this.data.length;
								o = 0;
								for (let e = 0, t = this.data.length; e < t; e++) {
									var l = this.data[e] - c;
									o += l * l;
								}
								var u = o / this.data.length;
								for (let e = 0, t = this.data.length; e < t; e++) this.data[e] = (this.data[e] - c) / u;
							}
						}
					}
					getIndex(e, t, n) {
						if (this.matrix) {
							this.inversematrix ??= new i.Matrix4().getInverse(this.matrix);
							var r = new i.Vector3(e, t, n);
							r = r.applyMatrix4(this.inversematrix), e = r.x, t = r.y, n = r.z;
						} else e -= this.origin.x, t -= this.origin.y, n -= this.origin.z, e /= this.unit.x, t /= this.unit.y, n /= this.unit.z;
						return e = Math.round(e), t = Math.round(t), n = Math.round(n), e < 0 || e >= this.size.x || t < 0 || t >= this.size.y || n < 0 || n >= this.size.z ? -1 : e * this.size.y * this.size.z + t * this.size.z + n;
					}
					getVal(e, t, n) {
						let r = this.getIndex(e, t, n);
						return r < 0 ? 0 : this.data[r];
					}
					cube(e) {
						var t = e.split(/\r?\n/);
						if (!(t.length < 6)) {
							var n = (0, o.CUBE)(e, {}).modelData[0].cryst, r = t[2].replace(/^\s+/, "").replace(/\s+/g, " ").split(" "), i = parseFloat(r[0]), a = Math.abs(i);
							this.origin = n.origin, this.size = n.size, this.unit = n.unit, this.matrix = n.matrix4;
							var s = 6;
							i < 0 && s++;
							var c = t.splice(a + s).join(" ");
							c = c.replace(/^\s+/, "");
							var l = c.split(/[\s\r]+/);
							this.data = Float32Array.from(l, parseFloat);
						}
					}
					ccp4(e) {
						var t = {};
						e = new Int8Array(e);
						var n = new Int32Array(e.buffer, 0, 56), r = new Float32Array(e.buffer, 0, 56), a = new DataView(e.buffer);
						if (t.MAP = String.fromCharCode(a.getUint8(208), a.getUint8(209), a.getUint8(210), a.getUint8(211)), t.MACHST = [a.getUint8(212), a.getUint8(213)], t.MACHST[0] === 17 && t.MACHST[1] === 17) for (var o = e.byteLength, s = 0; s < o; s += 4) a.setFloat32(s, a.getFloat32(s), !0);
						t.NX = n[0], t.NY = n[1], t.NZ = n[2], t.MODE = n[3], t.NXSTART = n[4], t.NYSTART = n[5], t.NZSTART = n[6], t.MX = n[7], t.MY = n[8], t.MZ = n[9], t.xlen = r[10], t.ylen = r[11], t.zlen = r[12], t.alpha = r[13], t.beta = r[14], t.gamma = r[15], t.MAPC = n[16], t.MAPR = n[17], t.MAPS = n[18], t.DMIN = r[19], t.DMAX = r[20], t.DMEAN = r[21], t.ISPG = n[22], t.NSYMBT = n[23], t.LSKFLG = n[24], t.originX = r[49], t.originY = r[50], t.originZ = r[51], t.ARMS = r[54];
						var c = t, l = [
							c.xlen,
							0,
							0
						], u = [
							c.ylen * Math.cos(Math.PI / 180 * c.gamma),
							c.ylen * Math.sin(Math.PI / 180 * c.gamma),
							0
						], d = [
							c.zlen * Math.cos(Math.PI / 180 * c.beta),
							c.zlen * (Math.cos(Math.PI / 180 * c.alpha) - Math.cos(Math.PI / 180 * c.gamma) * Math.cos(Math.PI / 180 * c.beta)) / Math.sin(Math.PI / 180 * c.gamma),
							0
						];
						d[2] = Math.sqrt(c.zlen * c.zlen * Math.sin(Math.PI / 180 * c.beta) * Math.sin(Math.PI / 180 * c.beta) - d[1] * d[1]);
						var f = [
							0,
							l,
							u,
							d
						], p = [
							0,
							c.MX,
							c.MY,
							c.MZ
						], m = [
							0,
							c.MAPC,
							c.MAPR,
							c.MAPS
						];
						this.matrix = new i.Matrix4(), this.matrix.set(f[m[1]][0] / p[m[1]], f[m[2]][0] / p[m[2]], f[m[3]][0] / p[m[3]], 0, f[m[1]][1] / p[m[1]], f[m[2]][1] / p[m[2]], f[m[3]][1] / p[m[3]], 0, f[m[1]][2] / p[m[1]], f[m[2]][2] / p[m[2]], f[m[3]][2] / p[m[3]], 0, 0, 0, 0, 1), this.matrix = this.matrix.multiplyMatrices(this.matrix, new i.Matrix4().makeTranslation(c.NXSTART + c.originX, c.NYSTART + c.originY, c.NZSTART + c.originZ)), this.origin = new i.Vector3(0, 0, 0), this.unit = new i.Vector3(1, 1, 1), this.size = {
							x: t.NX,
							y: t.NY,
							z: t.NZ
						}, this.dimensionorder = [
							t.MAPC,
							t.MAPR,
							t.MAPS
						];
						var h = new Float32Array(e.buffer, 1024 + t.NSYMBT), g = t.NX, _ = t.NY, v = t.NZ;
						this.data = new Float32Array(g * _ * v);
						for (let e = 0; e < g; e++) for (let t = 0; t < _; t++) for (let n = 0; n < v; n++) this.data[(e * _ + t) * v + n] = h[(n * _ + t) * g + e];
					}
				}
			},
			"./src/VolumetricRender.ts"(e, t, n) {
				n.r(t), n.d(t, { GLVolumetricRender: () => c });
				var r = n("./src/WebGL/shapes/index.ts"), i = n("./src/WebGL/math/index.ts"), a = n("./src/WebGL/index.ts"), o = n("./src/colors.ts"), s = n("./src/GLShape.ts");
				class c {
					static interpolateArray(e, t) {
						function n(e, t, n) {
							return e + (t - e) * n;
						}
						var r = [], i = (e.length - 1) / (t - 1);
						r[0] = e[0];
						for (var a = 1; a < t - 1; a++) {
							var o = a * i, s = Math.floor(o), c = Math.ceil(o), l = o - s;
							r[a] = n(e[s], e[c], l);
						}
						return r[t - 1] = e[e.length - 1], r;
					}
					constructor(e, t, n) {
						this.hidden = !1, this.boundingSphere = new r.Sphere(), this.renderedShapeObj = null, this.shapeObj = null, this.subsamples = 5, this.data = null, this.transferfunctionbuffer = [], this.min = 0, this.max = 0, t ||= {};
						var a = Object.assign([], t.transferfn);
						this.subsamples = t.subsamples || 5;
						let l = 256;
						a.forEach(function(e) {
							e.value = parseFloat(e.value);
						}), a.sort(function(e, t) {
							return e.value - t.value;
						}), this.min = a[0].value, a.length == 0 && a.push(a[0]), this.max = a[a.length - 1].value;
						var u, d, f, p, m, h, g, _, v, y;
						for (let e = 0; e < a.length - 1; e++) if (f = o.CC.color(a[e].color), p = o.CC.color(a[e + 1].color), v = a[e].opacity, y = a[e + 1].opacity, u = Math.floor((a[e].value - this.min) * 256 / (this.max - this.min)), d = Math.floor((a[e + 1].value - this.min) * 256 / (this.max - this.min)), u != d) {
							m = c.interpolateArray([f.r * 255, p.r * 255], d - u), h = c.interpolateArray([f.g * 255, p.g * 255], d - u), g = c.interpolateArray([f.b * 255, p.b * 255], d - u), _ = c.interpolateArray([v * 255, y * 255], d - u);
							for (let e = 0; e < m.length; e++) this.transferfunctionbuffer.push(m[e]), this.transferfunctionbuffer.push(h[e]), this.transferfunctionbuffer.push(g[e]), this.transferfunctionbuffer.push(_[e]);
						}
						if (this.transferfunctionbuffer = new Uint8ClampedArray(this.transferfunctionbuffer), e.matrix) {
							let t = new i.Vector3(0, 0, 0), n = new i.Vector3(e.size.x, e.size.y, e.size.z), r = new i.Vector3(1, 1, 1);
							t.applyMatrix4(e.matrix), n.applyMatrix4(e.matrix), r.applyMatrix4(e.matrix).sub(t), this.extent = [[
								t.x,
								t.y,
								t.z
							], [
								n.x,
								n.y,
								n.z
							]];
							for (let t = 1; t < 7; t++) n.x = t & 1 ? e.size.x : 0, n.y = t & 2 ? e.size.y : 0, n.z = t & 4 ? e.size.z : 0, n.applyMatrix4(e.matrix), this.extent[0][0] = Math.min(this.extent[0][0], n.x), this.extent[0][1] = Math.min(this.extent[0][1], n.y), this.extent[0][2] = Math.min(this.extent[0][2], n.z), this.extent[1][0] = Math.max(this.extent[1][0], n.x), this.extent[1][1] = Math.max(this.extent[1][1], n.y), this.extent[1][2] = Math.max(this.extent[1][2], n.z);
							let a = n.x - t.x, o = n.y - t.y, s = n.z - t.z;
							this.maxdepth = Math.sqrt(a * a + o * o + s * s), this.minunit = Math.min(Math.min(r.x, r.y), r.z), this.texmatrix = new i.Matrix4().identity().scale({
								x: e.size.x,
								y: e.size.y,
								z: e.size.z
							}), this.texmatrix = this.texmatrix.multiplyMatrices(e.matrix, this.texmatrix), this.texmatrix = this.texmatrix.getInverse(this.texmatrix);
						} else {
							this.texmatrix = new i.Matrix4().identity();
							let t = e.unit.x * e.size.x, n = e.unit.y * e.size.y, r = e.unit.z * e.size.z;
							this.texmatrix.makeTranslation(-e.origin.x / t, -e.origin.y / n, -e.origin.z / r), this.texmatrix.scale({
								x: 1 / t,
								y: 1 / n,
								z: 1 / r
							}), this.minunit = Math.min(Math.min(e.unit.x, e.unit.y), e.unit.z), this.extent = [[
								e.origin.x,
								e.origin.y,
								e.origin.z
							], [
								e.origin.x + t,
								e.origin.y + n,
								e.origin.z + r
							]], this.maxdepth = Math.sqrt(t * t + n * n + r * r);
						}
						var b = new s.GLShape({});
						if (b.addBox({
							corner: {
								x: this.extent[0][0],
								y: this.extent[0][1],
								z: this.extent[0][2]
							},
							dimensions: {
								w: this.extent[1][0] - this.extent[0][0],
								h: this.extent[1][1] - this.extent[0][1],
								d: this.extent[1][2] - this.extent[0][2]
							}
						}), this.geo = b.finalize(), this.boundingSphere.center = new i.Vector3((this.extent[0][0] + this.extent[1][0]) / 2, (this.extent[0][1] + this.extent[1][1]) / 2, (this.extent[0][2] + this.extent[1][2]) / 2), this.boundingSphere.radius = this.maxdepth / 2, t.coords === void 0 && t.selection !== void 0 && (n ? t.coords = n.selectedAtoms(t.selection) : console.log("Need to provide viewer to volumetric renderer if selection specified.")), t.coords !== void 0 && t.seldist !== void 0) {
							let n = new Uint8Array(e.data.length), r = t.seldist, i = r * r;
							for (let a = 0, o = t.coords.length; a < o; a++) {
								let o = t.coords[a], s = o.x - r, c = o.y - r, l = o.z - r, u = o.x + r, d = o.y + r, f = o.z + r;
								if (e.getIndex(s, c, l) >= 0 || e.getIndex(u, d, f) >= 0) for (let t = s; t < u; t += this.minunit) for (let r = c; r < d; r += this.minunit) for (let a = l; a < f; a += this.minunit) {
									let s = e.getIndex(t, r, a);
									s >= 0 && !n[s] && (t - o.x) * (t - o.x) + (r - o.y) * (r - o.y) + (a - o.z) * (a - o.z) < i && (n[s] = 1);
								}
							}
							for (let t = 0, r = e.data.length; t < r; t++) n[t] == 0 && (e.data[t] = Infinity);
						}
						this.data = e;
					}
					globj(e) {
						if (this.renderedShapeObj &&= (e.remove(this.renderedShapeObj), null), !this.hidden) {
							this.shapeObj = new a.Object3D();
							var t = null, n = new a.Texture(this.data, !0), r = new a.Texture(this.transferfunctionbuffer, !1);
							n.needsUpdate = !0, r.needsUpdate = !0, r.flipY = !1, t = new a.VolumetricMaterial({
								transferfn: r,
								transfermin: this.min,
								transfermax: this.max,
								map: n,
								extent: this.extent,
								maxdepth: this.maxdepth,
								texmatrix: this.texmatrix,
								unit: this.minunit,
								subsamples: this.subsamples
							});
							var i = new a.Mesh(this.geo, t);
							this.shapeObj.add(i), this.renderedShapeObj = this.shapeObj.clone(), e.add(this.renderedShapeObj);
						}
					}
					removegl(e) {
						this.renderedShapeObj &&= (this.renderedShapeObj.geometry !== void 0 && this.renderedShapeObj.geometry.dispose(), this.renderedShapeObj.material !== void 0 && this.renderedShapeObj.material.dispose(), e.remove(this.renderedShapeObj), null), this.shapeObj = null;
					}
					get position() {
						return this.boundingSphere.center;
					}
					get x() {
						return this.boundingSphere.center.x;
					}
					get y() {
						return this.boundingSphere.center.y;
					}
					get z() {
						return this.boundingSphere.center.z;
					}
				}
			},
			"./src/WebGL/Camera.ts"(e, t, n) {
				n.r(t), n.d(t, { Camera: () => a });
				var r = n("./src/WebGL/core/index.ts"), i = n("./src/WebGL/math/index.ts");
				class a extends r.Object3D {
					constructor(e = 50, t = 1, n = .1, r = 2e3, a = !1) {
						super(), this.projectionMatrix = new i.Matrix4(), this.projectionMatrixInverse = new i.Matrix4(), this.matrixWorldInverse = new i.Matrix4(), this.fov = e, this.aspect = t, this.near = n, this.far = r;
						var o = this.position.z;
						this.right = o * Math.tan(Math.PI / 180 * e), this.left = -this.right, this.top = this.right / this.aspect, this.bottom = -this.top, this.ortho = !!a, this.updateProjectionMatrix();
					}
					lookAt(e) {
						this.matrix.lookAt(this.position, e, this.up), this.rotationAutoUpdate && (this.useQuaternion === !1 && this.rotation instanceof i.Vector3 ? this.rotation.setEulerFromRotationMatrix(this.matrix, this.eulerOrder) : console.error("Unimplemented math operation."));
					}
					updateProjectionMatrix() {
						this.ortho ? this.projectionMatrix.makeOrthographic(this.left, this.right, this.top, this.bottom, this.near, this.far) : this.projectionMatrix.makePerspective(this.fov, this.aspect, this.near, this.far), this.projectionMatrixInverse.getInverse(this.projectionMatrix);
					}
				}
			},
			"./src/WebGL/Fog.ts"(e, t, n) {
				n.r(t), n.d(t, { Fog: () => i });
				var r = n("./src/colors.ts");
				class i {
					constructor(e, t = 1, n = 1e3) {
						this.name = "", this.color = new r.Color(e), this.near = t, this.far = n;
					}
					clone() {
						return new i(this.color.getHex(), this.near, this.far);
					}
				}
			},
			"./src/WebGL/Renderer.ts"(e, t, n) {
				n.r(t), n.d(t, { Renderer: () => h });
				var r = n("./src/WebGL/Camera.ts"), i = n("./src/WebGL/constants/Sides.ts"), a = n("./src/WebGL/constants/TextureConstants.ts"), o = n("./src/WebGL/core/index.ts"), s = n("./src/colors.ts"), c = n("./src/WebGL/materials/index.ts"), l = n("./src/WebGL/math/index.ts"), u = n("./src/WebGL/objects/index.ts"), d = n("./src/WebGL/shaders/index.ts"), f = n("./src/WebGL/SpritePlugin.ts"), p = null, m = null;
				class h {
					constructor(e) {
						this.context = null, this.devicePixelRatio = 1, this.sortObjects = !0, this.autoUpdateObjects = !0, this.autoUpdateScene = !0, this.info = {
							memory: {
								programs: 0,
								geometries: 0,
								textures: 0
							},
							render: {
								calls: 0,
								vertices: 0,
								faces: 0,
								points: 0
							}
						}, this._offscreen = null, this._bitmap = null, this._programs = [], this._programs_counter = 0, this._webglversion = 1, this._currentProgram = null, this._currentMaterialId = -1, this._currentGeometryGroupHash = null, this._currentCamera = null, this._geometryGroupCounter = 0, this._oldDoubleSided = -1, this._oldFlipSided = -1, this._oldDepthTest = -1, this._oldDepthWrite = -1, this._oldPolygonOffset = null, this._oldLineWidth = null, this._viewportWidth = 0, this._viewportHeight = 0, this._currentWidth = 0, this._currentHeight = 0, this._enabledAttributes = {}, this._vector3 = new l.Vector3(), this._worldInverse = new l.Matrix4(), this._projInverse = new l.Matrix4(), this._textureMatrix = new l.Matrix4(), this._fullProjModelMatrix = new l.Matrix4(), this._fullProjModelMatrixInv = new l.Matrix4(), this._direction = new l.Vector3(), this._lightsNeedUpdate = !0, this._lights = {
							ambient: [
								0,
								0,
								0
							],
							directional: {
								length: 0,
								colors: [],
								positions: []
							},
							point: {
								length: 0,
								colors: [],
								positions: [],
								distances: []
							},
							spot: {
								length: 0,
								colors: [],
								positions: [],
								distances: [],
								directions: [],
								anglesCos: [],
								exponents: []
							},
							hemi: {
								length: 0,
								skyColors: [],
								groundColors: [],
								positions: []
							}
						}, this.sprites = new f.SpritePlugin(), this._screenshader = null, this._AOshader = null, this._blurshader = null, this._vertexattribpos = null, this._aovertexattribpos = null, this._blurvertexattribpos = null, this._screenQuadVBO = null, this._fb = null, this._targetTexture = null, this._depthTexture = null, this._shadingTexture = null, this._scratchTexture = null, this._upscale = null, this._AOstrength = 1, this._AOradius = 5, this.SHADE_TEXTURE = 3, e ||= {}, this.row = e.row, this.col = e.col, this.rows = e.rows, this.cols = e.cols, this._canvas = e.canvas === void 0 ? document.createElement("canvas") : e.canvas, this._precision = e.precision === void 0 ? "highp" : e.precision, this._alpha = e.alpha === void 0 || e.alpha, this._premultipliedAlpha = e.premultipliedAlpha === void 0 || e.premultipliedAlpha, this._antialias = e.antialias !== void 0 && e.antialias, this._upscale = e.upscale === void 0 ? this._antialias : e.upscale, this._preserveDrawingBuffer = e.preserveDrawingBuffer !== void 0 && e.preserveDrawingBuffer, this._clearColor = e.clearColor === void 0 ? new s.Color(0) : new s.Color(e.clearColor), this._clearAlpha = e.clearAlpha === void 0 ? 0 : e.clearAlpha, this._outlineMaterial = new c.MeshOutlineMaterial(e.outline), this._outlineSphereImposterMaterial = new c.SphereImposterOutlineMaterial(e.outline), this._outlineStickImposterMaterial = new c.StickImposterOutlineMaterial(e.outline), this._outlineEnabled = !!e.outline, this._AOEnabled = !!e.ambientOcclusion, e.ambientOcclusion && e.ambientOcclusion.strength !== void 0 && (this._AOstrength = parseFloat(e.ambientOcclusion.strength)), this._AOstrength == 0 && (this._AOEnabled = !1), e.ambientOcclusion && e.ambientOcclusion.radius !== void 0 && (this._AOradius = parseFloat(e.ambientOcclusion.radius)), this.domElement = this._canvas, this._canvas.id = e.id, e.containerWidth != 0 && e.containerHeight != 0 && (this.initGL(), this.setDefaultGLState(), this.context = this._gl, this._extInstanced = this.isWebGL1() ? this._gl.getExtension("ANGLE_instanced_arrays") : {
							vertexAttribDivisorANGLE: this._gl.vertexAttribDivisor.bind(this._gl),
							drawElementsInstancedANGLE: this._gl.drawElementsInstanced.bind(this._gl)
						}, this._extFragDepth = this._gl.getExtension("EXT_frag_depth"), this._extFloatLinear = this._gl.getExtension("OES_texture_float_linear"), this._extColorBufferFloat = this._gl.getExtension("EXT_color_buffer_float"), this.sprites.init(this));
					}
					supportedExtensions() {
						return {
							supportsAIA: !!this._extInstanced,
							supportsImposters: !!this._extFragDepth || !this.isWebGL1(),
							regen: !1
						};
					}
					getContext() {
						return this._gl;
					}
					getCanvas() {
						return this._canvas;
					}
					isLost() {
						return this._gl == null || this._gl.isContextLost();
					}
					getPrecision() {
						return this._precision;
					}
					setClearColorHex(e, t) {
						this._clearColor.setHex(e), this._clearAlpha = t, this.isLost() || this._gl.clearColor(this._clearColor.r, this._clearColor.g, this._clearColor.b, this._clearAlpha);
					}
					enableOutline(e) {
						this._outlineMaterial = new c.MeshOutlineMaterial(e), this._outlineSphereImposterMaterial = new c.SphereImposterOutlineMaterial(e), this._outlineStickImposterMaterial = new c.StickImposterOutlineMaterial(e), this._outlineEnabled = !0;
					}
					disableOutline() {
						this._outlineEnabled = !1;
					}
					enableAmbientOcclusion(e) {
						e && (e.strength && (this._AOstrength = e.strength), e.scale && (this._AOradius = e.scale)), this._AOEnabled = this._AOstrength > 0;
					}
					disableAmbientOcclusion() {
						this._AOEnabled = !1;
					}
					setViewport() {
						if (this._offscreen && (this._offscreen.width = this._canvas.width, this._offscreen.height = this._canvas.height), this.rows != null && this.cols != null && this.row != null && this.col != null && !this.isLost()) {
							var e = this._gl.drawingBufferWidth / this.cols, t = this._gl.drawingBufferHeight / this.rows;
							this._viewportWidth = e, this._viewportHeight = t, this._gl.enable(this._gl.SCISSOR_TEST), this._gl.scissor(e * this.col, t * this.row, e, t), this._gl.viewport(e * this.col, t * this.row, e, t);
						}
					}
					setSize(e, t) {
						this.devicePixelRatio = window.devicePixelRatio === void 0 ? 1 : window.devicePixelRatio, this._upscale && this.devicePixelRatio < 2 && (this.devicePixelRatio = 2), this._canvas.width = e * this.devicePixelRatio, this._canvas.height = t * this.devicePixelRatio, this._canvas.style.width = e + "px", this._canvas.style.height = t + "px", this.rows != null && this.cols != null && this.row != null && this.col != null ? (this.isLost() || (this._viewportWidth = this._gl.drawingBufferWidth / this.cols, this._viewportHeight = this._gl.drawingBufferHeight / this.rows), this.setViewport()) : (this._viewportWidth = this._canvas.width, this._viewportHeight = this._canvas.height, this.isLost() || this._gl.viewport(0, 0, this._gl.drawingBufferWidth, this._gl.drawingBufferHeight)), this.initFrameBuffer();
					}
					clear(e, t, n) {
						var r = 0;
						(e === void 0 || e) && (r |= this._gl.COLOR_BUFFER_BIT), (t === void 0 || t) && (r |= this._gl.DEPTH_BUFFER_BIT), (n === void 0 || n) && (r |= this._gl.STENCIL_BUFFER_BIT), this._gl.clear(r);
					}
					setMaterialFaces(e, t) {
						var n = e.side === i.DoubleSide, r = e.side === i.BackSide;
						e.imposter || (r = t ? !r : r), this._oldDoubleSided !== n && (n ? this._gl.disable(this._gl.CULL_FACE) : this._gl.enable(this._gl.CULL_FACE), this._oldDoubleSided = n), this._oldFlipSided !== r && (r ? this._gl.frontFace(this._gl.CW) : this._gl.frontFace(this._gl.CCW), this._oldFlipSided = r), this._gl.cullFace(this._gl.BACK);
					}
					setDepthTest(e) {
						this._oldDepthTest !== e && (e ? this._gl.enable(this._gl.DEPTH_TEST) : this._gl.disable(this._gl.DEPTH_TEST), this._oldDepthTest = e);
					}
					setDepthWrite(e) {
						this._oldDepthWrite !== e && (this._gl.depthMask(e), this._oldDepthWrite = e);
					}
					setBlending(e) {
						e ? (this._gl.enable(this._gl.BLEND), this._gl.blendEquationSeparate(this._gl.FUNC_ADD, this._gl.FUNC_ADD), this._gl.blendFuncSeparate(this._gl.SRC_ALPHA, this._gl.ONE_MINUS_SRC_ALPHA, this._gl.ONE, this._gl.ONE_MINUS_SRC_ALPHA)) : this._gl.disable(this._gl.BLEND);
					}
					initMaterial(e, t, n, r) {
						e.addEventListener("dispose", this.onMaterialDispose.bind(this));
						var i, a = e.shaderID;
						if (a) {
							var o = d.ShaderLib[a];
							e.vertexShader = o.vertexShader, e.fragmentShader = o.fragmentShader, e.uniforms = d.ShaderUtils.clone(o.uniforms), e.shaded && e.makeShaded(this.SHADE_TEXTURE);
						}
						i = {
							wireframe: e.wireframe,
							fragdepth: e.imposter,
							volumetric: e.volumetric,
							shaded: e.shaded
						}, e.program = this.buildProgram(e.fragmentShader, e.vertexShader, e.uniforms, i);
					}
					renderBuffer(e, t, n, r, i, a) {
						if (r.visible) {
							var o = this.setProgram(e, t, n, r, a, this), s;
							if (o) {
								s = o.attributes;
								var c = !1, l = +!!r.wireframe, d = i.id * 16777215 + o.id * 2 + l;
								d !== this._currentGeometryGroupHash && (this._currentGeometryGroupHash = d, c = !0), c && (this.disableAttributes(), s.position >= 0 && (this._gl.bindBuffer(this._gl.ARRAY_BUFFER, i.__webglVertexBuffer), this.enableAttribute(s.position), this._gl.vertexAttribPointer(s.position, 3, this._gl.FLOAT, !1, 0, 0)), s.color >= 0 && (this._gl.bindBuffer(this._gl.ARRAY_BUFFER, i.__webglColorBuffer), this.enableAttribute(s.color), this._gl.vertexAttribPointer(s.color, 3, this._gl.FLOAT, !1, 0, 0)), s.normal >= 0 && (this._gl.bindBuffer(this._gl.ARRAY_BUFFER, i.__webglNormalBuffer), this.enableAttribute(s.normal), this._gl.vertexAttribPointer(s.normal, 3, this._gl.FLOAT, !1, 0, 0)), s.offset >= 0 && (this._gl.bindBuffer(this._gl.ARRAY_BUFFER, i.__webglOffsetBuffer), this.enableAttribute(s.offset), this._gl.vertexAttribPointer(s.offset, 3, this._gl.FLOAT, !1, 0, 0)), s.radius >= 0 && (this._gl.bindBuffer(this._gl.ARRAY_BUFFER, i.__webglRadiusBuffer), this.enableAttribute(s.radius), this._gl.vertexAttribPointer(s.radius, 1, this._gl.FLOAT, !1, 0, 0)));
								var f, p;
								if (a instanceof u.Mesh) {
									if (r.shaderID === "instanced") {
										var m = r.sphere.geometryGroups[0];
										c && (this._gl.bindBuffer(this._gl.ARRAY_BUFFER, i.__webglVertexBuffer), this._gl.bufferData(this._gl.ARRAY_BUFFER, m.vertexArray, this._gl.STATIC_DRAW), this._gl.bindBuffer(this._gl.ARRAY_BUFFER, i.__webglNormalBuffer), this._gl.bufferData(this._gl.ARRAY_BUFFER, m.normalArray, this._gl.STATIC_DRAW), this._gl.bindBuffer(this._gl.ELEMENT_ARRAY_BUFFER, i.__webglFaceBuffer), this._gl.bufferData(this._gl.ELEMENT_ARRAY_BUFFER, m.faceArray, this._gl.STATIC_DRAW)), f = m.faceidx, this._extInstanced.vertexAttribDivisorANGLE(s.offset, 1), this._extInstanced.vertexAttribDivisorANGLE(s.radius, 1), this._extInstanced.vertexAttribDivisorANGLE(s.color, 1), this._extInstanced.drawElementsInstancedANGLE(this._gl.TRIANGLES, f, this._gl.UNSIGNED_SHORT, 0, i.radiusArray.length), this._extInstanced.vertexAttribDivisorANGLE(s.offset, 0), this._extInstanced.vertexAttribDivisorANGLE(s.radius, 0), this._extInstanced.vertexAttribDivisorANGLE(s.color, 0);
									} else r.wireframe ? (p = i.lineidx, this.setLineWidth(r.wireframeLinewidth), c && this._gl.bindBuffer(this._gl.ELEMENT_ARRAY_BUFFER, i.__webglLineBuffer), this._gl.drawElements(this._gl.LINES, p, this._gl.UNSIGNED_SHORT, 0)) : (f = i.faceidx, c && this._gl.bindBuffer(this._gl.ELEMENT_ARRAY_BUFFER, i.__webglFaceBuffer), this._gl.drawElements(this._gl.TRIANGLES, f, this._gl.UNSIGNED_SHORT, 0));
									this.info.render.calls++, this.info.render.vertices += f, this.info.render.faces += f / 3;
								} else a instanceof u.Line && (p = i.vertices, this.setLineWidth(r.linewidth), this._gl.drawArrays(this._gl.LINES, 0, p), this.info.render.calls++);
							}
						}
					}
					clearShading() {
						this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.DEPTH_ATTACHMENT, this._gl.TEXTURE_2D, this._shadingTexture, 0), this.clear(!1, !0, !1), this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.DEPTH_ATTACHMENT, this._gl.TEXTURE_2D, this._depthTexture, 0);
					}
					setShading(e, t, n) {
						let r = e.__lights, i = e.fog, a = [];
						for (let t = 0, r = e.__webglObjects.length; t < r; t++) {
							let r = e.__webglObjects[t];
							r.render && r[n] && a.push(r);
						}
						if (a.length == 0) return;
						this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.DEPTH_ATTACHMENT, this._gl.TEXTURE_2D, this._shadingTexture, 0), this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.COLOR_ATTACHMENT0, this._gl.TEXTURE_2D, null, 0), this.renderObjects(e.__webglObjects, !0, n + "Depth", t, r, i, !1), this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.DEPTH_ATTACHMENT, this._gl.TEXTURE_2D, this._scratchTexture, 0), this.clear(!1, !0, !1), this._gl.useProgram(this._AOshader), this._currentProgram = this._AOshader, this.setDepthTest(-1), this.setDepthWrite(-1);
						let o = this._AOshader.uniforms;
						this._gl.uniform1f(o.total_strength, this._AOstrength), this._gl.uniform1f(o.radius, this._AOradius), this._fullProjModelMatrix = new l.Matrix4(), this._fullProjModelMatrixInv = new l.Matrix4();
						let s = a[0].object;
						this._fullProjModelMatrix.multiplyMatrices(t.projectionMatrix, s._modelViewMatrix), this._fullProjModelMatrixInv.getInverse(this._fullProjModelMatrix), this._gl.uniformMatrix4fv(o.projectionMatrix, !1, this._fullProjModelMatrix.elements), this._gl.uniformMatrix4fv(o.projinv, !1, this._fullProjModelMatrixInv.elements), this._gl.bindBuffer(this._gl.ARRAY_BUFFER, this._screenQuadVBO), this._gl.enableVertexAttribArray(this._aovertexattribpos), this._gl.vertexAttribPointer(this._aovertexattribpos, 2, this._gl.FLOAT, !1, 0, 0), this._gl.activeTexture(this._gl.TEXTURE0), this._gl.bindTexture(this._gl.TEXTURE_2D, this._shadingTexture), this._gl.drawArrays(this._gl.TRIANGLES, 0, 6), this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.DEPTH_ATTACHMENT, this._gl.TEXTURE_2D, this._shadingTexture, 0), this.clear(!1, !0, !1), this._gl.useProgram(this._blurshader), this._currentProgram = this._blurshader, this.setDepthTest(-1), this.setDepthWrite(-1), this._gl.bindBuffer(this._gl.ARRAY_BUFFER, this._screenQuadVBO), this._gl.enableVertexAttribArray(this._blurvertexattribpos), this._gl.vertexAttribPointer(this._blurvertexattribpos, 2, this._gl.FLOAT, !1, 0, 0), this._gl.activeTexture(this._gl.TEXTURE0), this._gl.bindTexture(this._gl.TEXTURE_2D, this._scratchTexture), this._gl.drawArrays(this._gl.TRIANGLES, 0, 6), this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.COLOR_ATTACHMENT0, this._gl.TEXTURE_2D, this._targetTexture, 0), this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.DEPTH_ATTACHMENT, this._gl.TEXTURE_2D, this._depthTexture, 0);
					}
					render(e, t) {
						if (!(t instanceof r.Camera)) {
							console.error("Renderer.render: camera is not an instance of Camera.");
							return;
						}
						var n, i, a, o, s, c = e.__lights, l = e.fog;
						if (this._currentMaterialId = -1, this._lightsNeedUpdate = !0, this.autoUpdateScene && e.updateMatrixWorld(), t.parent === void 0 && t.updateMatrixWorld(), t.matrixWorldInverse.getInverse(t.matrixWorld), this.isLost()) return;
						this.autoUpdateObjects && this.initWebGLObjects(e), this.info.render.calls = 0, this.info.render.vertices = 0, this.info.render.faces = 0, this.info.render.points = 0, this._currentWidth = this._viewportWidth, this._currentHeight = this._viewportHeight, this.setViewport(), this.setFrameBuffer(), this._gl.clearColor(this._clearColor.r, this._clearColor.g, this._clearColor.b, this._clearAlpha), this.clear(!0, !0, !0), s = e.__webglObjects;
						let u = !1, d = this._AOEnabled;
						for (n = 0, i = s.length; n < i; n++) a = s[n], o = a.object, a.render = !1, o.visible && (this.setupMatrices(o, t), this.unrollBufferMaterial(a), a.render = !0, a.volumetric && (u = !0), a.hasAO && (d = !0));
						if (this.setBlending(!1), d && this.setShading(e, t, "opaque"), this.renderObjects(e.__webglObjects, !0, "opaque", t, c, l, !1), d && this.clearShading(), this.renderSprites(e, t, !1), this.renderObjects(e.__webglObjects, !0, "transparentDepth", t, c, l, !0), this.renderObjects(e.__webglObjects, !1, "transparent", t, c, l, !0), u && this._fb && (this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.DEPTH_ATTACHMENT, this._gl.TEXTURE_2D, null, 0), this.renderObjects(e.__webglObjects, !1, "volumetric", t, c, l, !0)), this.renderFrameBuffertoScreen(), this.setDepthTest(!0), this.setDepthWrite(!0), this.renderSprites(e, t, !0), this._bitmap) {
							let e = this._offscreen.transferToImageBitmap();
							this._bitmap.transferFromImageBitmap(e), e.close();
						}
					}
					setFrameBuffer() {
						if (this.isWebGL1() || !this._fb) return;
						let e = this._viewportWidth, t = this._viewportHeight;
						this._gl.enable(this._gl.SCISSOR_TEST), this._gl.scissor(0, 0, e, t), this._gl.viewport(0, 0, e, t), this._gl.bindTexture(this._gl.TEXTURE_2D, this._targetTexture), this._gl.texImage2D(this._gl.TEXTURE_2D, 0, this._gl.RGBA, e, t, 0, this._gl.RGBA, this._gl.UNSIGNED_BYTE, null), this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_MIN_FILTER, this._gl.LINEAR), this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_MAG_FILTER, this._gl.LINEAR), this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_WRAP_S, this._gl.CLAMP_TO_EDGE), this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_WRAP_T, this._gl.CLAMP_TO_EDGE), this._gl.bindTexture(this._gl.TEXTURE_2D, this._depthTexture), this._gl.texImage2D(this._gl.TEXTURE_2D, 0, this._gl.DEPTH_COMPONENT32F, e, t, 0, this._gl.DEPTH_COMPONENT, this._gl.FLOAT, null), this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_MIN_FILTER, this._gl.NEAREST), this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_MAG_FILTER, this._gl.NEAREST), this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_WRAP_S, this._gl.CLAMP_TO_EDGE), this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_WRAP_T, this._gl.CLAMP_TO_EDGE), this._shadingTexture && (this._gl.deleteTexture(this._shadingTexture), this._shadingTexture = this._gl.createTexture(), this._gl.bindTexture(this._gl.TEXTURE_2D, this._shadingTexture), this._gl.texImage2D(this._gl.TEXTURE_2D, 0, this._gl.DEPTH_COMPONENT32F, e, t, 0, this._gl.DEPTH_COMPONENT, this._gl.FLOAT, null), this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_MIN_FILTER, this._gl.NEAREST), this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_MAG_FILTER, this._gl.NEAREST), this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_WRAP_S, this._gl.CLAMP_TO_EDGE), this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_WRAP_T, this._gl.CLAMP_TO_EDGE), this._gl.deleteTexture(this._scratchTexture), this._scratchTexture = this._gl.createTexture(), this._gl.bindTexture(this._gl.TEXTURE_2D, this._scratchTexture), this._gl.texImage2D(this._gl.TEXTURE_2D, 0, this._gl.DEPTH_COMPONENT32F, e, t, 0, this._gl.DEPTH_COMPONENT, this._gl.FLOAT, null), this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_MIN_FILTER, this._gl.NEAREST), this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_MAG_FILTER, this._gl.NEAREST), this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_WRAP_S, this._gl.CLAMP_TO_EDGE), this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_WRAP_T, this._gl.CLAMP_TO_EDGE)), this._gl.bindFramebuffer(this._gl.FRAMEBUFFER, this._fb), this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.COLOR_ATTACHMENT0, this._gl.TEXTURE_2D, this._targetTexture, 0), this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.DEPTH_ATTACHMENT, this._gl.TEXTURE_2D, this._shadingTexture, 0), this._gl.clearDepth(1), this._gl.clear(this._gl.DEPTH_BUFFER_BIT), this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.DEPTH_ATTACHMENT, this._gl.TEXTURE_2D, this._depthTexture, 0);
					}
					initFrameBuffer() {
						if (this.isWebGL1()) return;
						let e = this._viewportWidth, t = this._viewportHeight;
						this._gl.enable(this._gl.SCISSOR_TEST), this._gl.scissor(0, 0, e, t), this._gl.viewport(0, 0, e, t), this._targetTexture = this._gl.createTexture(), this._depthTexture = this._gl.createTexture(), this._shadingTexture = this._gl.createTexture(), this._scratchTexture = this._gl.createTexture(), this._fb = this._gl.createFramebuffer();
						var n = this._antialias ? d.ShaderLib.screenaa : d.ShaderLib.screen;
						this._screenshader = this.buildProgram(n.fragmentShader, n.vertexShader, n.uniforms, {}), this._vertexattribpos = this._gl.getAttribLocation(this._screenshader, "vertexPosition");
						var r = [
							1,
							1,
							-1,
							1,
							-1,
							-1,
							-1,
							-1,
							1,
							-1,
							1,
							1
						];
						this._screenQuadVBO = this._gl.createBuffer(), this._gl.bindBuffer(this._gl.ARRAY_BUFFER, this._screenQuadVBO), this._gl.bufferData(this._gl.ARRAY_BUFFER, new Float32Array(r), this._gl.STATIC_DRAW);
						let i = d.ShaderLib.ssao;
						this._AOshader = this.buildProgram(i.fragmentShader, i.vertexShader, i.uniforms, {}), this._aovertexattribpos = this._gl.getAttribLocation(this._AOshader, "vertexPosition");
						let a = d.ShaderLib.blur;
						this._blurshader = this.buildProgram(a.fragmentShader, a.vertexShader, a.uniforms, {}), this._blurvertexattribpos = this._gl.getAttribLocation(this._blurshader, "vertexPosition");
					}
					renderFrameBuffertoScreen() {
						this.isWebGL1() || this._fb === null || (this.setViewport(), this._gl.bindFramebuffer(this._gl.FRAMEBUFFER, null), this._gl.clear(this._gl.COLOR_BUFFER_BIT | this._gl.DEPTH_BUFFER_BIT), this._gl.frontFace(this._gl.CCW), this._gl.cullFace(this._gl.BACK), this._gl.useProgram(this._screenshader), this._currentProgram = this._screenshader, this.setDepthTest(-1), this.setDepthWrite(-1), this._gl.bindBuffer(this._gl.ARRAY_BUFFER, this._screenQuadVBO), this._gl.enableVertexAttribArray(this._vertexattribpos), this._gl.vertexAttribPointer(this._vertexattribpos, 2, this._gl.FLOAT, !1, 0, 0), this._gl.activeTexture(this._gl.TEXTURE0), this._gl.bindTexture(this._gl.TEXTURE_2D, this._targetTexture), this._gl.drawArrays(this._gl.TRIANGLES, 0, 6));
					}
					initWebGLObjects(e) {
						if (e.__webglObjects || (e.__webglObjects = [], e.__webglObjectsImmediate = [], e.__webglSprites = [], e.__webglFlares = []), e.__objectsAdded.length) {
							for (; e.__objectsAdded.length;) this.addObject(e.__objectsAdded[0], e), e.__objectsAdded.splice(0, 1);
							this._currentGeometryGroupHash = -1;
						}
						for (; e.__objectsRemoved.length;) this.removeObject(e.__objectsRemoved[0], e), e.__objectsRemoved.splice(0, 1);
						for (var t = 0, n = e.__webglObjects.length; t < n; t++) this.updateObject(e.__webglObjects[t].object);
					}
					getYRatio() {
						return this.rows !== void 0 && this.row !== void 0 ? this.rows : 1;
					}
					getXRatio() {
						return this.cols !== void 0 && this.col !== void 0 ? this.cols : 1;
					}
					getAspect(e, t) {
						(e == null || t == null) && (e = this._canvas.width, t = this._canvas.height);
						var n = e / t;
						return this.rows != null && this.cols != null && this.row != null && this.col != null && (n = e / this.cols / (t / this.rows)), n;
					}
					setTexture(e, t, n) {
						if (e.needsUpdate) {
							e.__webglInit || (e.__webglInit = !0, e.addEventListener("dispose", this.onTextureDispose.bind(this)), e.__webglTexture = this._gl.createTexture(), this.info.memory.textures++), this._gl.activeTexture(this._gl.TEXTURE0 + t);
							var r = n ? this._gl.TEXTURE_3D : this._gl.TEXTURE_2D;
							this._gl.bindTexture(r, e.__webglTexture), this._gl.pixelStorei(this._gl.UNPACK_FLIP_Y_WEBGL, e.flipY), this._gl.pixelStorei(this._gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, e.premultiplyAlpha), this._gl.pixelStorei(this._gl.UNPACK_ALIGNMENT, e.unpackAlignment), this._gl.pixelStorei(this._gl.PACK_ALIGNMENT, e.unpackAlignment);
							var i = this.paramToGL(e.format), a = this.paramToGL(e.type);
							if (n) this.setTextureParameters(this._gl.TEXTURE_3D, e), this._gl.texImage3D(this._gl.TEXTURE_3D, 0, this._gl.R32F, e.image.size.z, e.image.size.y, e.image.size.x, 0, this._gl.RED, this._gl.FLOAT, e.image.data);
							else {
								var o = e.image, s = o.width, c = o.height;
								s === void 0 && (s = o.length, i == this._gl.RGBA && (s /= 4), c = 1), this.setTextureParameters(this._gl.TEXTURE_2D, e), this.isWebGL1() ? this._gl.texImage2D(this._gl.TEXTURE_2D, 0, i, i, a, e.image) : this._gl.texImage2D(this._gl.TEXTURE_2D, 0, i, s, c, 0, i, a, e.image);
							}
							e.needsUpdate = !1, e.onUpdate && e.onUpdate();
						} else this._gl.activeTexture(this._gl.TEXTURE0 + t), n ? this._gl.bindTexture(this._gl.TEXTURE_3D, e.__webglTexture) : this._gl.bindTexture(this._gl.TEXTURE_2D, e.__webglTexture);
					}
					supportsVolumetric() {
						return !this.isWebGL1();
					}
					enableAttribute(e) {
						this._enabledAttributes[e] || (this._gl.enableVertexAttribArray(e), this._enabledAttributes[e] = !0);
					}
					disableAttributes() {
						for (let e in this._enabledAttributes) this._enabledAttributes[e] && (this._gl.disableVertexAttribArray(e), this._enabledAttributes[e] = !1);
					}
					setPolygonOffset(e, t, n) {
						this._oldPolygonOffset !== e && (e ? this._gl.enable(this._gl.POLYGON_OFFSET_FILL) : this._gl.disable(this._gl.POLYGON_OFFSET_FILL));
					}
					setLineWidth(e) {
						e !== this._oldLineWidth && (this._gl.lineWidth(e), this._oldLineWidth = e);
					}
					deallocateGeometry(e) {
						if (e.__webglInit = void 0, e.__webglVertexBuffer !== void 0 && this._gl.deleteBuffer(e.__webglVertexBuffer), e.__webglColorBuffer !== void 0 && this._gl.deleteBuffer(e.__webglColorBuffer), e.geometryGroups !== void 0) for (var t = 0, n = e.groups; t < n; t++) {
							var r = e.geometryGroups[t];
							r.__webglVertexBuffer !== void 0 && this._gl.deleteBuffer(r.__webglVertexBuffer), r.__webglColorBuffer !== void 0 && this._gl.deleteBuffer(r.__webglColorBuffer), r.__webglNormalBuffer !== void 0 && this._gl.deleteBuffer(r.__webglNormalBuffer), r.__webglFaceBuffer !== void 0 && this._gl.deleteBuffer(r.__webglFaceBuffer), r.__webglLineBuffer !== void 0 && this._gl.deleteBuffer(r.__webglLineBuffer);
						}
					}
					deallocateMaterial(e) {
						var t = e.program;
						if (t !== void 0) {
							e.program = void 0;
							var n, r, i, a = !1;
							for (n = 0, r = this._programs.length; n < r; n++) if (i = this._programs[n], i.program === t) {
								i.usedTimes--, i.usedTimes === 0 && (a = !0);
								break;
							}
							if (a === !0) {
								var o = [];
								for (n = 0, r = this._programs.length; n < r; n++) i = this._programs[n], i.program !== t && o.push(i);
								this._programs = o, this._gl.deleteProgram(t), this.info.memory.programs--;
							}
						}
					}
					deallocateTexture(e) {
						if (e.image && e.image.__webglTextureCube) this._gl.deleteTexture(e.image.__webglTextureCube);
						else {
							if (!e.__webglInit) return;
							e.__webglInit = !1, this._gl.deleteTexture(e.__webglTexture);
						}
					}
					onGeometryDispose(e) {
						var t = e.target;
						t.removeEventListener("dispose", this.onGeometryDispose), this.deallocateGeometry(t), this.info.memory.geometries--;
					}
					onTextureDispose(e) {
						var t = e.target;
						t.removeEventListener("dispose", this.onTextureDispose), this.deallocateTexture(t), this.info.memory.textures--;
					}
					onMaterialDispose(e) {
						var t = e.target;
						t.removeEventListener("dispose", this.onMaterialDispose), this.deallocateMaterial(t);
					}
					getShader(e, t) {
						var n;
						return !this.isWebGL1() && !t.startsWith("#version") && (t = t.replace(/gl_FragDepthEXT/g, "gl_FragDepth"), t = e == "fragment" ? t.replace(/varying/g, "in") : t.replace(/varying/g, "out"), t = t.replace(/attribute/g, "in"), t = t.replace(/texture2D/g, "texture"), t = t.replace(/\/\/DEFINEFRAGCOLOR/g, "out vec4 glFragColor;"), t = t.replace(/gl_FragColor/g, "glFragColor"), t = "#version 300 es\n" + t), e === "fragment" ? n = this._gl.createShader(this._gl.FRAGMENT_SHADER) : e === "vertex" && (n = this._gl.createShader(this._gl.VERTEX_SHADER)), n == null ? null : (this._gl.shaderSource(n, t), this._gl.compileShader(n), this._gl.getShaderParameter(n, this._gl.COMPILE_STATUS) ? n : (console.error(this._gl.getShaderInfoLog(n)), console.error("could not initialize shader"), null));
					}
					buildProgram(e, t, n, r) {
						var i, a, o, s, c = [];
						for (i in c.push(e), c.push(t), r) c.push(i), c.push(r[i]);
						for (s = c.join(), i = 0, a = this._programs.length; i < a; i++) {
							var l = this._programs[i];
							if (l.code === s) return l.usedTimes++, l.program;
						}
						if (this.isWebGL1() && r.volumetric) throw Error("Volumetric rendering requires webgl2 which is not supported by your hardware.");
						if (o = this._gl.createProgram(), o == null) return null;
						var u = "precision " + this._precision + " float;", d = [r.volumetric ? "#version 300 es" : "", u].join("\n"), f = [
							r.volumetric ? "#version 300 es" : "",
							r.fragdepth && this.isWebGL1() ? "#extension GL_EXT_frag_depth: enable" : "",
							r.shaded ? "#define SHADED 1" : "",
							r.wireframe ? "#define WIREFRAME 1" : "",
							u
						].join("\n"), p = this.getShader("fragment", f + e), m = this.getShader("vertex", d + t);
						m != null && this._gl.attachShader(o, m), p != null && this._gl.attachShader(o, p), this._gl.linkProgram(o), this._gl.getProgramParameter(o, this._gl.LINK_STATUS) || console.error("Could not initialize shader"), o.uniforms = {}, o.attributes = {};
						var h = [
							"viewMatrix",
							"modelViewMatrix",
							"projectionMatrix",
							"normalMatrix",
							"vWidth",
							"vHeight"
						], g, _;
						for (g in n) h.push(g);
						for (_ = 0; _ < h.length; _++) {
							var v = h[_];
							o.uniforms[v] = this._gl.getUniformLocation(o, v);
						}
						for (h = [
							"position",
							"normal",
							"color",
							"lineDistance",
							"offset",
							"radius"
						], _ = 0; _ < h.length; _++) {
							var y = h[_];
							o.attributes[y] = this._gl.getAttribLocation(o, y);
						}
						return o.id = this._programs_counter++, this._programs.push({
							program: o,
							code: s,
							usedTimes: 1
						}), this.info.memory.programs = this._programs.length, o;
					}
					setProgram(e, t, n, r, i, a) {
						if (r.needsUpdate &&= (r.program && this.deallocateMaterial(r), this.initMaterial(r, t, n, i), !1), r.program == null) return null;
						var o = !1, s = r.program, c = s.uniforms, l = r.uniforms;
						if (s != this._currentProgram && (this._gl.useProgram(s), this._currentProgram = s, o = !0), r.id != this._currentMaterialId && (this._currentMaterialId = r.id, o = !0), e != this._currentCamera && (this._currentCamera = e, o = !0), c.projectionMatrix && this._gl.uniformMatrix4fv(c.projectionMatrix, !1, e.projectionMatrix.elements), c.modelViewMatrix && this._gl.uniformMatrix4fv(c.modelViewMatrix, !1, i._modelViewMatrix.elements), c.normalMatrix && this._gl.uniformMatrix3fv(c.normalMatrix, !1, i._normalMatrix.elements), c.projinv && (this._projInverse.getInverse(e.projectionMatrix), this._gl.uniformMatrix4fv(c.projinv, !1, this._projInverse.elements)), c.viewMatrix && this._gl.uniformMatrix4fv(c.viewMatrix, !1, e.matrixWorldInverse.elements), c.vWidth && this._gl.uniform1f(c.vWidth, this._viewportWidth), c.vHeight && this._gl.uniform1f(c.vHeight, this._viewportHeight), o) {
							if (l.fogColor.value = n.color, l.fogNear.value = n.near, l.fogFar.value = n.far, r.shaderID.startsWith("lambert") || r.shaderID === "instanced" || r.shaderID.endsWith("imposter")) this._lightsNeedUpdate &&= (this.setupLights(s, t), !1), l.directionalLightColor.value = this._lights.directional.colors, l.directionalLightDirection.value = this._lights.directional.positions;
							else if (r.shaderID.endsWith("outline")) l.outlineColor.value = r.outlineColor, l.outlineWidth.value = r.outlineWidth, l.outlinePushback.value = r.outlinePushback, l.outlineMaxPixels.value = r.outlineMaxPixels * this.devicePixelRatio;
							else if (r.shaderID === "volumetric") {
								i._modelViewMatrix.getScale(this._direction), this._worldInverse.getInverse(i._modelViewMatrix), this._projInverse.getInverse(e.projectionMatrix), this._textureMatrix.multiplyMatrices(i.material.texmatrix, this._worldInverse), this._gl.uniformMatrix4fv(c.textmat, !1, this._textureMatrix.elements), this._gl.uniformMatrix4fv(c.projinv, !1, this._projInverse.elements);
								let t = Math.min(Math.min(this._direction.x, this._direction.y), this._direction.z);
								l.step.value = i.material.unit * t, l.maxdepth.value = i.material.maxdepth * t, l.transfermax.value = i.material.transfermax, l.transfermin.value = i.material.transfermin, l.subsamples.value = i.material.subsamples, a.setTexture(i.material.transferfn, 4, !1), a.setTexture(i.material.map, 3, !0), this._gl.activeTexture(this._gl.TEXTURE5), this._gl.bindTexture(this._gl.TEXTURE_2D, this._depthTexture);
							}
							l.opacity.value = r.opacity, this.loadMaterialUniforms(c, l);
						}
						return l.shading && (l.shading.value == 3 ? (this._gl.activeTexture(this._gl.TEXTURE0 + this.SHADE_TEXTURE), this._gl.bindTexture(this._gl.TEXTURE_2D, this._shadingTexture)) : console.error("Invalid shading textures.")), s;
					}
					loadMaterialUniforms(e, t) {
						var n, r, i, a;
						for (n in t) e[n] && (r = t[n].type, i = t[n].value, a = e[n], r === "f" ? this._gl.uniform1f(a, i) : r === "i" ? this._gl.uniform1i(a, i) : r === "fv" ? this._gl.uniform3fv(a, i) : r === "c" ? this._gl.uniform3f(a, i.r, i.g, i.b) : r === "f4" && this._gl.uniform4f(a, i[0], i[1], i[2], i[3]));
					}
					addObject(e, t) {
						var n, r, i, a;
						if (!e.__webglInit && (e.__webglInit = !0, e._modelViewMatrix = new l.Matrix4(), e._normalMatrix = new l.Matrix3(), e.geometry !== void 0 && e.geometry.__webglInit === void 0 && (e.geometry.__webglInit = !0, e.geometry.addEventListener("dispose", this.onGeometryDispose.bind(this))), e instanceof u.Mesh || e instanceof u.Line)) for (i = e.geometry, n = 0, r = i.geometryGroups.length; n < r; n++) a = i.geometryGroups[n], a.id = this._geometryGroupCounter++, a.__webglVertexBuffer || (e instanceof u.Mesh ? (this.createMeshBuffers(a), i.elementsNeedUpdate = !0, i.normalsNeedUpdate = !0) : e instanceof u.Line && this.createLineBuffers(a), i.verticesNeedUpdate = !0, i.colorsNeedUpdate = !0);
						if (!e.__webglActive) {
							if (e instanceof u.Mesh || e instanceof u.Line) for (i = e.geometry, n = 0, r = i.geometryGroups.length; n < r; n++) a = i.geometryGroups[n], this.addBuffer(t.__webglObjects, a, e);
							else e instanceof u.Sprite && t.__webglSprites.push(e);
							e.__webglActive = !0;
						}
					}
					updateObject(e) {
						var t = e.geometry, n;
						if (e instanceof u.Mesh || e instanceof u.Line) {
							for (var r = 0, i = t.geometryGroups.length; r < i; r++) n = t.geometryGroups[r], (t.verticesNeedUpdate || t.elementsNeedUpdate || t.colorsNeedUpdate || t.normalsNeedUpdate) && this.setBuffers(n, this._gl.STATIC_DRAW);
							t.verticesNeedUpdate = !1, t.elementsNeedUpdate = !1, t.normalsNeedUpdate = !1, t.colorsNeedUpdate = !1, t.buffersNeedUpdate = !1;
						}
					}
					removeObject(e, t) {
						e instanceof u.Mesh || e instanceof u.Line ? this.removeInstances(t.__webglObjects, e) : e instanceof u.Sprite && this.removeInstancesDirect(t.__webglSprites, e), e.__webglActive = !1;
					}
					removeInstances(e, t) {
						for (var n = e.length - 1; n >= 0; --n) e[n].object === t && e.splice(n, 1);
					}
					removeInstancesDirect(e, t) {
						for (var n = e.length - 1; n >= 0; --n) e[n] === t && e.splice(n, 1);
					}
					unrollBufferMaterial(e) {
						var t = e.object.material;
						if (t.volumetric) e.opaque = null, e.transparent = null, e.volumetric = t;
						else if (t.transparent) {
							if (e.opaque = null, e.volumetric = null, e.transparent = t, !t.wireframe) {
								let n = t.clone();
								n.opacity = 0, e.transparentDepth = n;
							}
						} else {
							if (e.opaque = t, e.transparent = null, e.volumetric = null, !t.wireframe) {
								let n = t.clone();
								n.opacity = 0, e.opaqueDepth = n;
							}
							t.hasAO && (e.hasAO = !0), (this._AOEnabled || e.hasAO) && (e.opaqueShaded = t.clone(), e.opaqueShaded.shaded = !0);
						}
					}
					setBuffers(e, t) {
						var n = e.vertexArray, r = e.colorArray;
						if (e.__webglOffsetBuffer === void 0 ? (this._gl.bindBuffer(this._gl.ARRAY_BUFFER, e.__webglVertexBuffer), this._gl.bufferData(this._gl.ARRAY_BUFFER, n, t)) : (this._gl.bindBuffer(this._gl.ARRAY_BUFFER, e.__webglOffsetBuffer), this._gl.bufferData(this._gl.ARRAY_BUFFER, n, t)), this._gl.bindBuffer(this._gl.ARRAY_BUFFER, e.__webglColorBuffer), this._gl.bufferData(this._gl.ARRAY_BUFFER, r, t), e.normalArray && e.__webglNormalBuffer !== void 0) {
							var i = e.normalArray;
							this._gl.bindBuffer(this._gl.ARRAY_BUFFER, e.__webglNormalBuffer), this._gl.bufferData(this._gl.ARRAY_BUFFER, i, t);
						}
						if (e.radiusArray && e.__webglRadiusBuffer !== void 0 && (this._gl.bindBuffer(this._gl.ARRAY_BUFFER, e.__webglRadiusBuffer), this._gl.bufferData(this._gl.ARRAY_BUFFER, e.radiusArray, t)), e.faceArray && e.__webglFaceBuffer !== void 0) {
							var a = e.faceArray;
							this._gl.bindBuffer(this._gl.ELEMENT_ARRAY_BUFFER, e.__webglFaceBuffer), this._gl.bufferData(this._gl.ELEMENT_ARRAY_BUFFER, a, t);
						}
						if (e.lineArray && e.__webglLineBuffer !== void 0) {
							var o = e.lineArray;
							this._gl.bindBuffer(this._gl.ELEMENT_ARRAY_BUFFER, e.__webglLineBuffer), this._gl.bufferData(this._gl.ELEMENT_ARRAY_BUFFER, o, t);
						}
					}
					createMeshBuffers(e) {
						e.radiusArray && (e.__webglRadiusBuffer = this._gl.createBuffer()), e.useOffset && (e.__webglOffsetBuffer = this._gl.createBuffer()), e.__webglVertexBuffer = this._gl.createBuffer(), e.__webglNormalBuffer = this._gl.createBuffer(), e.__webglColorBuffer = this._gl.createBuffer(), e.__webglFaceBuffer = this._gl.createBuffer(), e.__webglLineBuffer = this._gl.createBuffer(), this.info.memory.geometries++;
					}
					createLineBuffers(e) {
						e.__webglVertexBuffer = this._gl.createBuffer(), e.__webglColorBuffer = this._gl.createBuffer(), this.info.memory.geometries++;
					}
					addBuffer(e, t, n) {
						e.push({
							buffer: t,
							object: n,
							opaque: null,
							transparent: null
						});
					}
					setupMatrices(e, t) {
						e._modelViewMatrix.multiplyMatrices(t.matrixWorldInverse, e.matrixWorld), e._normalMatrix.getInverse(e._modelViewMatrix), e._normalMatrix.transpose();
					}
					filterFallback(e) {
						return this._gl.LINEAR;
					}
					setTextureParameters(e, t) {
						e == this._gl.TEXTURE_2D ? (this._gl.texParameteri(e, this._gl.TEXTURE_WRAP_S, this._gl.CLAMP_TO_EDGE), this._gl.texParameteri(e, this._gl.TEXTURE_WRAP_T, this._gl.CLAMP_TO_EDGE), this._gl.texParameteri(e, this._gl.TEXTURE_MAG_FILTER, this.filterFallback(t.magFilter)), this._gl.texParameteri(e, this._gl.TEXTURE_MIN_FILTER, this.filterFallback(t.minFilter))) : (this._gl.texParameteri(e, this._gl.TEXTURE_WRAP_S, this._gl.CLAMP_TO_EDGE), this._gl.texParameteri(e, this._gl.TEXTURE_WRAP_T, this._gl.CLAMP_TO_EDGE), this._gl.texParameteri(e, this._gl.TEXTURE_WRAP_R, this._gl.CLAMP_TO_EDGE), this._extColorBufferFloat && this._extFloatLinear ? (this._gl.texParameteri(e, this._gl.TEXTURE_MAG_FILTER, this._gl.LINEAR), this._gl.texParameteri(e, this._gl.TEXTURE_MIN_FILTER, this._gl.LINEAR)) : (this._gl.texParameteri(e, this._gl.TEXTURE_MAG_FILTER, this._gl.NEAREST), this._gl.texParameteri(e, this._gl.TEXTURE_MIN_FILTER, this._gl.NEAREST)));
					}
					paramToGL(e) {
						return e === a.UnsignedByteType ? this._gl.UNSIGNED_BYTE : e === a.RGBAFormat ? this._gl.RGBA : e === a.NearestFilter ? this._gl.NEAREST : 0;
					}
					setupLights(e, t) {
						var n, r, i, a = 0, s = 0, c = 0, l, u, d = this._lights, f = d.directional.colors, p = d.directional.positions, m = 0, h = 0;
						for (n = 0, r = t.length; n < r; n++) if (i = t[n], l = i.color, u = i.intensity, i instanceof o.Light) {
							if (this._direction.getPositionFromMatrix(i.matrixWorld), this._vector3.getPositionFromMatrix(i.target.matrixWorld), this._direction.sub(this._vector3), this._direction.normalize(), this._direction.x === 0 && this._direction.y === 0 && this._direction.z === 0) continue;
							p[h] = this._direction.x, p[h + 1] = this._direction.y, p[h + 2] = this._direction.z, f[h] = l.r * u, f[h + 1] = l.g * u, f[h + 2] = l.b * u, h += 3, m++;
						}
						d.ambient[0] = a, d.ambient[1] = s, d.ambient[2] = c, d.directional.length = m;
					}
					initGL() {
						try {
							if (OffscreenCanvas && (this.rows == null || this.cols == null || this.row == null || this.col == null)) (m == null || m.isContextLost()) && (p = new OffscreenCanvas(this._canvas.width, this._canvas.height), m = p.getContext("webgl2", {
								alpha: !0,
								premultipliedAlpha: this._premultipliedAlpha,
								antialias: this._antialias,
								preserveDrawingBuffer: this._preserveDrawingBuffer
							})), this._offscreen = p, this._gl = m, this._bitmap = this._canvas.getContext("bitmaprenderer", { alpha: !0 });
							else if (!(this._gl = this._canvas.getContext("webgl2", {
								alpha: this._alpha,
								premultipliedAlpha: this._premultipliedAlpha,
								antialias: this._antialias,
								preserveDrawingBuffer: this._preserveDrawingBuffer
							})) && !(this._gl = this._canvas.getContext("experimental-webgl", {
								alpha: this._alpha,
								premultipliedAlpha: this._premultipliedAlpha,
								antialias: this._antialias,
								preserveDrawingBuffer: this._preserveDrawingBuffer
							})) && !(this._gl = this._canvas.getContext("webgl", {
								alpha: this._alpha,
								premultipliedAlpha: this._premultipliedAlpha,
								antialias: this._antialias,
								preserveDrawingBuffer: this._preserveDrawingBuffer
							}))) throw "Error creating WebGL context.";
							var e = this._gl.getParameter(this._gl.VERSION);
							this._webglversion = parseInt(e[6]);
						} catch (e) {
							console.error(e);
						}
					}
					isWebGL1() {
						return this._webglversion == 1;
					}
					setDefaultGLState() {
						this._gl.clearDepth(1), this._gl.clearStencil(0), this._gl.enable(this._gl.DEPTH_TEST), this._gl.depthFunc(this._gl.LEQUAL), this._gl.frontFace(this._gl.CCW), this._gl.cullFace(this._gl.BACK), this._gl.enable(this._gl.CULL_FACE), this._gl.enable(this._gl.BLEND), this._gl.blendEquation(this._gl.FUNC_ADD), this._gl.blendFunc(this._gl.SRC_ALPHA, this._gl.ONE_MINUS_SRC_ALPHA), this._gl.clearColor(this._clearColor.r, this._clearColor.g, this._clearColor.b, this._clearAlpha);
					}
					renderObjects(e, t, n, r, i, a, o) {
						var s, c, l, u, d, f, p;
						t ? (d = e.length - 1, f = -1, p = -1) : (d = 0, f = e.length, p = 1);
						for (var m = d; m !== f; m += p) if (s = e[m], s.render) {
							if (c = s.object, l = s.buffer, u = s[n], (s.hasAO || this._AOEnabled) && s[n + "Shaded"] && (u = s[n + "Shaded"]), !u) continue;
							this.setBlending(o), this.setDepthTest(u.depthTest), this.setDepthWrite(u.depthWrite), this.setPolygonOffset(u.polygonOffset, u.polygonOffsetFactor, u.polygonOffsetUnits);
							var h = c._modelViewMatrix.isReflected();
							if (this.setMaterialFaces(u, h), this.renderBuffer(r, i, a, u, l, c), (this._outlineEnabled || u.outline) && !u.wireframe && u.shaderID !== "basic" && u.opacity !== 0) {
								let e = this._outlineMaterial;
								u.shaderID == "sphereimposter" ? e = this._outlineSphereImposterMaterial : u.shaderID == "stickimposter" && (e = this._outlineStickImposterMaterial), this.renderBuffer(r, i, a, e, l, c);
							}
						}
					}
					renderSprites(e, t, n) {
						this._currentGeometryGroupHash = -1, this._currentProgram = null, this._currentCamera = null, this._oldDepthWrite = -1, this._oldDepthTest = -1, this._oldDoubleSided = -1, this._currentMaterialId = -1, this._oldFlipSided = -1, this._lightsNeedUpdate = !0, this.sprites.render(e, t, this._currentWidth, this._currentHeight, n), this._currentGeometryGroupHash = -1, this._currentProgram = null, this._currentCamera = null, this._oldDepthWrite = -1, this._oldDepthTest = -1, this._oldDoubleSided = -1, this._currentMaterialId = -1, this._oldFlipSided = -1;
					}
				}
			},
			"./src/WebGL/SpritePlugin.ts"(e, t, n) {
				n.r(t), n.d(t, { SpritePlugin: () => i });
				var r = n("./src/WebGL/shaders/index.ts");
				class i {
					constructor() {
						this.sprite = {
							vertices: null,
							faces: null,
							vertexBuffer: null,
							elementBuffer: null,
							program: null,
							attributes: {},
							uniforms: null
						};
					}
					init(e) {
						this.gl = e.context, this.renderer = e, this.precision = e.getPrecision(), this.sprite.vertices = /* @__PURE__ */ new Float32Array(16), this.sprite.faces = /* @__PURE__ */ new Uint16Array(6);
						var t = 0;
						this.sprite.vertices[t++] = -1, this.sprite.vertices[t++] = -1, this.sprite.vertices[t++] = 0, this.sprite.vertices[t++] = 0, this.sprite.vertices[t++] = 1, this.sprite.vertices[t++] = -1, this.sprite.vertices[t++] = 1, this.sprite.vertices[t++] = 0, this.sprite.vertices[t++] = 1, this.sprite.vertices[t++] = 1, this.sprite.vertices[t++] = 1, this.sprite.vertices[t++] = 1, this.sprite.vertices[t++] = -1, this.sprite.vertices[t++] = 1, this.sprite.vertices[t++] = 0, this.sprite.vertices[t++] = 1, t = 0, this.sprite.faces[t++] = 0, this.sprite.faces[t++] = 1, this.sprite.faces[t++] = 2, this.sprite.faces[t++] = 0, this.sprite.faces[t++] = 2, this.sprite.faces[t++] = 3, this.sprite.vertexBuffer = this.gl.createBuffer(), this.sprite.elementBuffer = this.gl.createBuffer(), this.gl.bindBuffer(this.gl.ARRAY_BUFFER, this.sprite.vertexBuffer), this.gl.bufferData(this.gl.ARRAY_BUFFER, this.sprite.vertices, this.gl.STATIC_DRAW), this.gl.bindBuffer(this.gl.ELEMENT_ARRAY_BUFFER, this.sprite.elementBuffer), this.gl.bufferData(this.gl.ELEMENT_ARRAY_BUFFER, this.sprite.faces, this.gl.STATIC_DRAW), this.sprite.program = this.createProgram(r.ShaderLib.sprite, this.precision || 1), this.sprite.attributes = {};
						let n = {};
						this.sprite.attributes.position = this.gl.getAttribLocation(this.sprite.program, "position"), this.sprite.attributes.uv = this.gl.getAttribLocation(this.sprite.program, "uv"), n.uvOffset = this.gl.getUniformLocation(this.sprite.program, "uvOffset"), n.uvScale = this.gl.getUniformLocation(this.sprite.program, "uvScale"), n.rotation = this.gl.getUniformLocation(this.sprite.program, "rotation"), n.scale = this.gl.getUniformLocation(this.sprite.program, "scale"), n.alignment = this.gl.getUniformLocation(this.sprite.program, "alignment"), n.color = this.gl.getUniformLocation(this.sprite.program, "color"), n.map = this.gl.getUniformLocation(this.sprite.program, "map"), n.opacity = this.gl.getUniformLocation(this.sprite.program, "opacity"), n.useScreenCoordinates = this.gl.getUniformLocation(this.sprite.program, "useScreenCoordinates"), n.screenPosition = this.gl.getUniformLocation(this.sprite.program, "screenPosition"), n.modelViewMatrix = this.gl.getUniformLocation(this.sprite.program, "modelViewMatrix"), n.projectionMatrix = this.gl.getUniformLocation(this.sprite.program, "projectionMatrix"), n.fogNear = this.gl.getUniformLocation(this.sprite.program, "fogNear"), n.fogFar = this.gl.getUniformLocation(this.sprite.program, "fogFar"), n.fogColor = this.gl.getUniformLocation(this.sprite.program, "fogColor"), n.alphaTest = this.gl.getUniformLocation(this.sprite.program, "alphaTest"), this.sprite.uniforms = n;
					}
					render(e, t, n, r, i) {
						var o, s, c, l, u, d, f, p, m, h;
						if (!this.gl) throw Error("WebGLRenderer not initialized");
						let g = [];
						(o = e?.__webglSprites) == null || o.forEach((e) => {
							(i && e.material.depthTest == 0 || !i && e.material.depthTest) && g.push(e);
						});
						let _ = g.length;
						if (!_) return;
						let v = this.sprite.attributes, y = this.sprite.uniforms;
						if (!y) throw Error("Uniforms not defined");
						var b = n * .5, x = r * .5;
						this.gl.useProgram(this.sprite.program), this.gl.enableVertexAttribArray(v.position), this.gl.enableVertexAttribArray(v.uv), this.gl.disable(this.gl.CULL_FACE), this.gl.enable(this.gl.BLEND), this.gl.bindBuffer(this.gl.ARRAY_BUFFER, this.sprite.vertexBuffer), this.gl.vertexAttribPointer(v.position, 2, this.gl.FLOAT, !1, 16, 0), this.gl.vertexAttribPointer(v.uv, 2, this.gl.FLOAT, !1, 16, 8), this.gl.bindBuffer(this.gl.ELEMENT_ARRAY_BUFFER, this.sprite.elementBuffer), this.gl.uniformMatrix4fv(y.projectionMatrix, !1, t.projectionMatrix.elements), this.gl.activeTexture(this.gl.TEXTURE0), this.gl.uniform1i(y.map, 0);
						var S = e.fog;
						S ? (this.gl.uniform3f(y.fogColor, S.color.r, S.color.g, S.color.b), this.gl.uniform1f(y.fogNear, S.near), this.gl.uniform1f(y.fogFar, S.far)) : (this.gl.uniform1f(y.fogNear, 0), this.gl.uniform1f(y.fogFar, 0));
						var C;
						let w, T, E, D = [];
						for (C = 0; C < _; C++) w = g[C], T = w.material, T && (T.depthTest == 0 && !i || !w.visible || T.opacity === 0 || (T.useScreenCoordinates ? w.z = -w.position.z : (w._modelViewMatrix.multiplyMatrices(t.matrixWorldInverse, w.matrixWorld), w.z = -w._modelViewMatrix.elements[14])));
						for (g.sort(a), C = 0; C < _; C++) if (w = g[C], T = w.material, T && !(!w.visible || T.opacity === 0) && T.map && T.map.image && T.map.image.width) {
							this.gl.uniform1f(y?.alphaTest || null, T.alphaTest);
							var O = T.map.image.width, k = T.map.image.height;
							D[0] = O * this.renderer.devicePixelRatio / n, D[1] = k * this.renderer.devicePixelRatio / r, T.useScreenCoordinates === !0 ? (this.gl.uniform1i(y.useScreenCoordinates, 1), this.gl.uniform3f(y.screenPosition, (w.position.x * this.renderer.devicePixelRatio - b) / b, (x - w.position.y * this.renderer.devicePixelRatio) / x, Math.max(0, Math.min(1, w.position.z)))) : (this.gl.uniform1i(y.useScreenCoordinates, 0), this.gl.uniformMatrix4fv(y.modelViewMatrix, !1, w._modelViewMatrix.elements)), E = 1 / (T.scaleByViewport ? r : 1), D[0] *= E * w.scale.x, D[1] *= E * w.scale.y;
							let e = T?.alignment?.x, t = T?.alignment?.y;
							T.screenOffset && (e = (e || 0) + 2 * T.screenOffset.x / O, t = (t || 0) + 2 * T.screenOffset.y / k), this.gl.uniform2f(y.uvScale, T?.uvScale?.x || 1, T?.uvScale?.y || 1), this.gl.uniform2f(y.uvOffset, T?.uvOffset?.x || 0, T?.uvOffset?.y || 0), this.gl.uniform2f(y.alignment, e || 0, t || 0), this.gl.uniform1f(y.opacity, T.opacity), this.gl.uniform3f(y.color, T?.color?.r || 0, T?.color?.g || 0, T?.color?.b || 0), this.gl.uniform1f(y.rotation, w.rotation), this.gl.uniform2fv(y.scale, D), this.renderer.setDepthTest(T.depthTest), this.renderer.setDepthWrite(T.depthWrite), this.renderer.setTexture(T.map, 0), this.gl.drawElements(this.gl.TRIANGLES, 6, this.gl.UNSIGNED_SHORT, 0);
						}
						this.gl.enable(this.gl.CULL_FACE);
					}
					createProgram(e, t) {
						if (!this.gl) throw Error("WebGL Rendering context not found");
						var n = this.gl.createProgram();
						if (!n) throw Error("Error creating webgl program");
						var r = this.gl.createShader(this.gl.FRAGMENT_SHADER), i = this.gl.createShader(this.gl.VERTEX_SHADER);
						if (!r) throw Error("Unable to create fragment shader SpritePlugin.createProgram");
						if (!i) throw Error("Unable to create vertex shader SpritePlugin.createProgram");
						var a = "precision " + t + " float;\n";
						if (this.gl.shaderSource(r, a + e.fragmentShader), this.gl.shaderSource(i, a + e.vertexShader), this.gl.compileShader(r), this.gl.compileShader(i), !this.gl.getShaderParameter(r, this.gl.COMPILE_STATUS) || !this.gl.getShaderParameter(i, this.gl.COMPILE_STATUS)) throw Error(`Error compiling shader: 
      ${this.gl.getShaderInfoLog(r)} 
      ${this.gl.getShaderInfoLog(i)}`);
						return this.gl.attachShader(n, r), this.gl.attachShader(n, i), this.gl.linkProgram(n), this.gl.getProgramParameter(n, this.gl.LINK_STATUS) || console.error("Could not initialize shader"), n;
					}
				}
				function a(e, t) {
					return e.z === t.z ? t.id - e.id : t.z - e.z;
				}
			},
			"./src/WebGL/constants/Coloring.ts"(e, t, n) {
				n.r(t), n.d(t, { Coloring: () => r });
				var r;
				(function(e) {
					e[e.NoColors = 0] = "NoColors", e[e.FaceColors = 1] = "FaceColors", e[e.VertexColors = 2] = "VertexColors";
				})(r ||= {});
			},
			"./src/WebGL/constants/Shading.ts"(e, t, n) {
				n.r(t), n.d(t, { Shading: () => r });
				var r;
				(function(e) {
					e[e.NoShading = 0] = "NoShading", e[e.FlatShading = 1] = "FlatShading", e[e.SmoothShading = 2] = "SmoothShading";
				})(r ||= {});
			},
			"./src/WebGL/constants/Sides.ts"(e, t, n) {
				n.r(t), n.d(t, {
					BackSide: () => i,
					DoubleSide: () => a,
					FrontSide: () => r
				});
				let r = 0, i = 1, a = 2;
			},
			"./src/WebGL/constants/SpriteAlignment.ts"(e, t, n) {
				n.r(t), n.d(t, { SpriteAlignment: () => i });
				var r = n("./src/WebGL/math/index.ts");
				let i = {
					topLeft: new r.Vector2(1, -1),
					topCenter: new r.Vector2(0, -1),
					topRight: new r.Vector2(-1, -1),
					centerLeft: new r.Vector2(1, 0),
					center: new r.Vector2(0, 0),
					centerRight: new r.Vector2(-1, 0),
					bottomLeft: new r.Vector2(1, 1),
					bottomCenter: new r.Vector2(0, 1),
					bottomRight: new r.Vector2(-1, 1)
				};
			},
			"./src/WebGL/constants/TextureConstants.ts"(e, t, n) {
				n.r(t), n.d(t, {
					ClampToEdgeWrapping: () => r,
					FloatType: () => c,
					LinearFilter: () => i,
					LinearMipMapLinearFilter: () => o,
					NearestFilter: () => a,
					R32Format: () => d,
					RFormat: () => u,
					RGBAFormat: () => l,
					UnsignedByteType: () => s
				});
				let r = 1001, i = 1006, a = 1007, o = 1008, s = 1009, c = 1010, l = 1021, u = 1022, d = 1023;
			},
			"./src/WebGL/constants/TextureOperations.ts"(e, t, n) {
				n.r(t), n.d(t, { TextureOperations: () => r });
				var r;
				(function(e) {
					e[e.MultiplyOperation = 0] = "MultiplyOperation", e[e.MixOperation = 1] = "MixOperation", e[e.AddOperation = 2] = "AddOperation";
				})(r ||= {});
			},
			"./src/WebGL/constants/index.ts"(e, t, n) {
				n.r(t), n.d(t, {
					BackSide: () => i.BackSide,
					ClampToEdgeWrapping: () => s.ClampToEdgeWrapping,
					Coloring: () => r.Coloring,
					DoubleSide: () => i.DoubleSide,
					FloatType: () => s.FloatType,
					FrontSide: () => i.FrontSide,
					LinearFilter: () => s.LinearFilter,
					LinearMipMapLinearFilter: () => s.LinearMipMapLinearFilter,
					NearestFilter: () => s.NearestFilter,
					R32Format: () => s.R32Format,
					RFormat: () => s.RFormat,
					RGBAFormat: () => s.RGBAFormat,
					Shading: () => a.Shading,
					SpriteAlignment: () => o.SpriteAlignment,
					TextureOperations: () => c.TextureOperations,
					UnsignedByteType: () => s.UnsignedByteType
				});
				var r = n("./src/WebGL/constants/Coloring.ts"), i = n("./src/WebGL/constants/Sides.ts"), a = n("./src/WebGL/constants/Shading.ts"), o = n("./src/WebGL/constants/SpriteAlignment.ts"), s = n("./src/WebGL/constants/TextureConstants.ts"), c = n("./src/WebGL/constants/TextureOperations.ts");
			},
			"./src/WebGL/core/EventDispatcher.ts"(e, t, n) {
				n.r(t), n.d(t, { EventDispatcher: () => r });
				class r {
					constructor() {
						this.listeners = {};
					}
					dispatchEvent(e) {
						var t = this.listeners[e.type];
						if (t !== void 0) {
							e.target = this;
							for (var n = 0, r = t.length; n < r; n++) t[n].call(this, e);
						}
					}
					removeEventListener(e, t) {
						if (!t) this.listeners[e] = [];
						else {
							var n = this.listeners[e].indexOf(t);
							n !== -1 && this.listeners[e].splice(n, 1);
						}
					}
					addEventListener(e, t) {
						this.listeners[e] === void 0 && (this.listeners[e] = []), this.listeners[e].indexOf(t) === -1 && this.listeners[e].push(t);
					}
				}
			},
			"./src/WebGL/core/Geometry.ts"(e, t, n) {
				n.r(t), n.d(t, {
					Geometry: () => l,
					GeometryGroup: () => c,
					GeometryIDCount: () => u
				});
				var r = n("./src/WebGL/materials/LineBasicMaterial.ts"), i = n("./src/WebGL/core/EventDispatcher.ts"), a = n("./src/WebGL/math/index.ts"), o = n("./src/colors.ts");
				let s = 65535;
				class c {
					constructor(e = 0) {
						this.vertexArray = null, this.colorArray = null, this.normalArray = null, this.radiusArray = null, this.faceArray = null, this.lineArray = null, this.atomArray = [], this.vertices = 0, this.faceidx = 0, this.lineidx = 0, this.__inittedArrays = !1, this.id = e;
					}
					setColor(e) {
						var t = this.vertexArray, n = this.colorArray;
						if (!t) throw Error("vertex array not initialized");
						if (!n) throw Error("color array not initialized");
						let r = o.CC.color(e);
						for (var i = 0; i < t.length; i += 3) n[i] = r.r, n[i + 1] = r.g, n[i + 2] = r.b;
					}
					setColors(e) {
						var t = this.vertexArray, n = this.colorArray;
						if (!t) throw Error("vertex array not initialized");
						if (!n) throw Error("color array not initialized");
						if (t.length != n.length) {
							console.log("Cannot re-color geometry group due to mismatched lengths.");
							return;
						}
						for (var r = 0; r < t.length; r += 3) {
							var i = e(t[r], t[r + 1], t[r + 2]);
							i instanceof o.Color || (i = o.CC.color(i)), n[r] = i.r, n[r + 1] = i.g, n[r + 2] = i.b;
						}
					}
					getNumVertices() {
						return this.vertices;
					}
					getVertices() {
						return this.vertexArray;
					}
					getCentroid() {
						if (!this.vertexArray) throw Error("vertex array not initialized");
						for (var e = new a.Vector3(), t, n, r, i, o = 0; o < this.vertices; ++o) t = o * 3, n = this.vertexArray[t], r = this.vertexArray[t + 1], i = this.vertexArray[t + 2], e.x += n, e.y += r, e.z += i;
						return e.divideScalar(this.vertices), e;
					}
					setNormals() {
						var e = this.faceArray, t = this.vertexArray, n = this.normalArray;
						if (!(!this.vertices || !this.faceidx)) {
							if (!e) throw Error("face array not initialized");
							if (!t) throw Error("vertex array not initialized");
							if (!n) throw Error("normal array not initialized");
							for (var r, i, o, s, c, l, u, d = 0; d < e.length / 3; ++d) r = e[d * 3] * 3, i = e[d * 3 + 1] * 3, o = e[d * 3 + 2] * 3, s = new a.Vector3(t[r], t[r + 1], t[r + 2]), c = new a.Vector3(t[i], t[i + 1], t[i + 2]), l = new a.Vector3(t[o], t[o + 1], t[o + 2]), s.subVectors(s, c), l.subVectors(l, c), l.cross(s), u = l, u.normalize(), n[r] += u.x, n[i] += u.x, n[o] += u.x, n[r + 1] += u.y, n[i + 1] += u.y, n[o + 1] += u.y, n[r + 2] += u.z, n[i + 2] += u.z, n[o + 2] += u.z;
						}
					}
					setLineIndices() {
						if (this.faceidx && !(this.lineArray && this.lineArray.length == this.faceidx * 2 && this.lineidx == this.faceidx * 2)) {
							var e = this.faceArray, t = this.lineArray = new Uint16Array(this.faceidx * 2);
							if (this.lineidx = this.faceidx * 2, !e) throw Error("face array not initialized");
							for (var n = 0; n < this.faceidx / 3; ++n) {
								var r = n * 3, i = r * 2, a = e[r], o = e[r + 1], s = e[r + 2];
								t[i] = a, t[i + 1] = o, t[i + 2] = a, t[i + 3] = s, t[i + 4] = o, t[i + 5] = s;
							}
						}
					}
					vrml(e, t) {
						var n, i, a, o, s, c, l, u, d, f, p, m, h, g, _, v, y, b, x = "";
						if (x += e + "Shape {\n" + e + " appearance Appearance {\n" + e + "  material Material {\n" + e + "   diffuseColor " + t?.color?.r + " " + t?.color?.g + " " + t?.color?.b + "\n", t.wireframe && this.colorArray) {
							let t = this.colorArray;
							x += e + "    emissiveColor " + t[0] + " " + t[1] + " " + t[2] + "\n";
						}
						t?.transparent && (x += e + "   transparency " + (1 - t.opacity) + "\n"), x += e + "  }\n", x += e + " }\n";
						var S = e;
						if (e += " ", t instanceof r.LineBasicMaterial || t.wireframe) {
							x += e + "geometry IndexedLineSet {\n" + e + " colorPerVertex TRUE\n" + e + " coord Coordinate {\n" + e + "  point [\n";
							let n, r, i;
							for (let t = 0; t < this.vertices; ++t) {
								let a = t * 3;
								n = this.vertexArray?.[a], r = this.vertexArray?.[a + 1], i = this.vertexArray?.[a + 2], x += e + "   " + n + " " + r + " " + i + ",\n";
							}
							if (x += e + "  ]\n", x += e + " }\n", this.colorArray && !t.wireframe) {
								x += e + " color Color {\n" + e + "  color [\n";
								for (let t = 0; t < this.vertices; ++t) {
									let a = t * 3;
									n = this.colorArray[a], r = this.colorArray[a + 1], i = this.colorArray[a + 2], x += e + "   " + n + " " + r + " " + i + ",\n";
								}
								x += e + "  ]\n", x += e + " }\n";
							}
							if (x += e + " coordIndex [\n", t.wireframe && this.faceArray) for (let t = 0; t < this.faceidx; t += 3) n = this.faceArray?.[t], r = this.faceArray?.[t + 1], i = this.faceArray?.[t + 2], x += e + "  " + n + ", " + r + ", " + i + ", -1,\n";
							else for (let t = 0; t < this.vertices - 1; t += 2) x += e + "  " + t + ", " + (t + 1) + ", -1,\n";
							x += e + " ]\n", x += e + "}\n";
						} else {
							x += e + "geometry IndexedFaceSet {\n" + e + " colorPerVertex TRUE\n" + e + " normalPerVertex TRUE\n" + e + " solid FALSE\n", x += e + " coord Coordinate {\n" + e + "  point [\n";
							let t, n, r;
							for (let i = 0; i < this.vertices; ++i) {
								let a = i * 3;
								t = this.vertexArray?.[a], n = this.vertexArray?.[a + 1], r = this.vertexArray?.[a + 2], x += e + "   " + t + " " + n + " " + r + ",\n";
							}
							x += e + "  ]\n", x += e + " }\n", x += e + " normal Normal {\n" + e + "  vector [\n";
							for (let i = 0; i < this.vertices; ++i) {
								let a = i * 3;
								t = this.normalArray?.[a], n = this.normalArray?.[a + 1], r = this.normalArray?.[a + 2], x += e + "   " + t + " " + n + " " + r + ",\n";
							}
							if (x += e + "  ]\n", x += e + " }\n", this.colorArray) {
								x += e + " color Color {\n" + e + "  color [\n";
								for (let i = 0; i < this.vertices; ++i) {
									let a = i * 3;
									t = this.colorArray[a], n = this.colorArray[a + 1], r = this.colorArray[a + 2], x += e + "   " + t + " " + n + " " + r + ",\n";
								}
								x += e + "  ]\n", x += e + " }\n";
							}
							x += e + " coordIndex [\n";
							for (let i = 0; i < this.faceidx; i += 3) t = this.faceArray?.[i], n = this.faceArray?.[i + 1], r = this.faceArray?.[i + 2], x += e + "  " + t + ", " + n + ", " + r + ", -1,\n";
							x += e + " ]\n", x += e + "}\n";
						}
						return x += S + "}", x;
					}
					truncateArrayBuffers(e = !0, t = !1) {
						var n = this.vertexArray, r = this.colorArray, i = this.normalArray, a = this.faceArray, o = this.lineArray, s = this.radiusArray;
						this.vertexArray = n?.subarray(0, this.vertices * 3) || null, this.colorArray = r?.subarray(0, this.vertices * 3) || null, e ? (this.normalArray = i?.subarray(0, this.vertices * 3) || null, this.faceArray = a?.subarray(0, this.faceidx) || null, this.lineArray = this.lineidx > 0 ? o?.subarray(0, this.lineidx) || null : /* @__PURE__ */ new Uint16Array()) : (this.normalArray = /* @__PURE__ */ new Float32Array(), this.faceArray = /* @__PURE__ */ new Uint16Array(), this.lineArray = /* @__PURE__ */ new Uint16Array()), s && (this.radiusArray = s.subarray(0, this.vertices)), t && (this.normalArray &&= new Float32Array(this.normalArray), this.faceArray &&= new Uint16Array(this.faceArray), this.lineArray &&= new Uint16Array(this.lineArray), this.vertexArray &&= new Float32Array(this.vertexArray), this.colorArray &&= new Float32Array(this.colorArray), this.radiusArray &&= new Float32Array(this.radiusArray)), this.__inittedArrays = !0;
					}
				}
				class l extends i.EventDispatcher {
					constructor(e = !1, t = !1, n = !1) {
						super(), this.name = "", this.hasTangents = !1, this.dynamic = !0, this.verticesNeedUpdate = !1, this.elementsNeedUpdate = !1, this.normalsNeedUpdate = !1, this.colorsNeedUpdate = !1, this.buffersNeedUpdate = !1, this.imposter = !1, this.instanced = !1, this.geometryGroups = [], this.groups = 0, this.id = u++, this.mesh = e, this.radii = t, this.offset = n;
					}
					updateGeoGroup(e = 0) {
						var t, n = this.groups > 0 ? this.geometryGroups[this.groups - 1] : null;
						return (!n || n.vertices + e > (n?.vertexArray?.length || 0) / 3) && (n = this.addGeoGroup()), n;
					}
					vrml(e, t) {
						for (var n = "", r = this.geometryGroups.length, i = 0; i < r; i++) {
							var a = this.geometryGroups[i];
							n += a.vrml(e, t) + ",\n";
						}
						return n;
					}
					addGeoGroup() {
						var e = new c(this.geometryGroups.length);
						return this.geometryGroups.push(e), this.groups = this.geometryGroups.length, e.vertexArray = new Float32Array(s * 3), e.colorArray = new Float32Array(s * 3), this.mesh && (e.normalArray = new Float32Array(s * 3), e.faceArray = new Uint16Array(s * 6), e.lineArray = new Uint16Array(s * 6)), this.radii && (e.radiusArray = new Float32Array(s)), e.useOffset = this.offset, e;
					}
					setUpNormals(...e) {
						for (var t = 0; t < this.groups; t++) this.geometryGroups[t].setNormals(...e);
					}
					setColors(...e) {
						for (var t = this.geometryGroups.length, n = 0; n < t; n++) this.geometryGroups[n].setColors(...e);
					}
					setColor(...e) {
						let t = this.geometryGroups.length;
						for (var n = 0; n < t; n++) this.geometryGroups[n].setColor(...e);
					}
					setUpWireframe(...e) {
						let t = this.geometryGroups.length;
						for (var n = 0; n < t; n++) this.geometryGroups[n].setLineIndices(...e);
					}
					initTypedArrays() {
						for (var e = 0; e < this.groups; e++) {
							var t = this.geometryGroups[e];
							t.__inittedArrays !== !0 && t.truncateArrayBuffers(this.mesh, !1);
						}
					}
					dispose() {
						this.dispatchEvent({ type: "dispose" });
					}
					get vertices() {
						for (var e = 0, t = 0; t < this.groups; t++) e += this.geometryGroups[t].vertices;
						return e;
					}
				}
				let u = 0;
			},
			"./src/WebGL/core/Object3D.ts"(e, t, n) {
				n.r(t), n.d(t, {
					Light: () => c,
					Object3D: () => o,
					Object3DIDCount: () => a,
					Scene: () => s
				});
				var r = n("./src/WebGL/math/index.ts"), i = n("./src/colors.ts");
				let a = 0;
				class o {
					constructor() {
						this.id = a++, this.name = "", this.children = [], this.position = new r.Vector3(), this.rotation = new r.Vector3(), this.matrix = new r.Matrix4(), this.matrixWorld = new r.Matrix4(), this.quaternion = new r.Quaternion(), this.eulerOrder = "XYZ", this.up = new r.Vector3(0, 1, 0), this.scale = new r.Vector3(1, 1, 1), this.matrixAutoUpdate = !0, this.matrixWorldNeedsUpdate = !0, this.rotationAutoUpdate = !0, this.useQuaternion = !1, this.visible = !0;
					}
					lookAt(e) {
						this.matrix.lookAt(e, this.position, this.up), this.rotationAutoUpdate && (this.useQuaternion === !0 ? console.error("Unimplemented math operation.") : this.rotation instanceof r.Vector3 && this.rotation.setEulerFromRotationMatrix(this.matrix, this.eulerOrder));
					}
					add(e) {
						if (e === this) {
							console.error("Can't add $3Dmol.Object3D to itself");
							return;
						}
						e.parent = this, this.children.push(e);
						for (var t = this; t.parent !== void 0;) t = t.parent;
						t !== void 0 && t instanceof s && t.__addObject(e);
					}
					remove(e) {
						var t = this.children.indexOf(e);
						if (t !== -1) {
							e.parent = void 0, this.children.splice(t, 1);
							for (var n = this; n.parent !== void 0;) n = n.parent;
							n !== void 0 && n instanceof s && n.__removeObject(e);
						}
					}
					vrml(e) {
						e ||= " ";
						var t = 2 * Math.atan2(this.quaternion.lengthxyz(), this.quaternion.w), n = 0, r = 0, i = 0;
						if (t != 0) {
							let e = Math.sin(t / 2);
							n = this.quaternion.x / e, r = this.quaternion.y / e, i = this.quaternion.z / e;
						}
						var a = e + "Transform {\n" + e + " center " + this.position.x + " " + this.position.y + " " + this.position.z + "\n" + e + " rotation " + n + " " + r + " " + i + " " + t + "\n" + e + " children [\n";
						this.geometry && (a += this.geometry.vrml(e, this.material));
						for (var o = 0; o < this.children.length; o++) a += this.children[o].vrml(e + " ") + ",\n";
						return a += " ]\n", a += "}", a;
					}
					updateMatrix() {
						this.matrix.setPosition(this.position), this.useQuaternion === !1 && this.rotation instanceof r.Vector3 ? this.matrix.setRotationFromEuler(this.rotation, this.eulerOrder) : this.matrix.setRotationFromQuaternion(this.quaternion), (this.scale.x !== 1 || this.scale.y !== 1 || this.scale.z !== 1) && this.matrix.scale(this.scale), this.matrixWorldNeedsUpdate = !0;
					}
					updateMatrixWorld(e) {
						this.matrixAutoUpdate === !0 && this.updateMatrix(), (this.matrixWorldNeedsUpdate === !0 || e === !0) && (this.parent === void 0 ? this.matrixWorld.copy(this.matrix) : this.matrixWorld.multiplyMatrices(this.parent.matrixWorld, this.matrix)), this.matrixWorldNeedsUpdate = !1;
						for (var t = 0; t < this.children.length; t++) this.children[t].updateMatrixWorld(!0);
					}
					clone(e) {
						e === void 0 && (e = new o()), e.name = this.name, e.up.copy(this.up), e.position.copy(this.position), e.rotation instanceof r.Vector3 && this.rotation instanceof r.Vector3 ? e.rotation.copy(this.rotation) : e.rotation = this.rotation, e.eulerOrder = this.eulerOrder, e.scale.copy(this.scale), e.rotationAutoUpdate = this.rotationAutoUpdate, e.matrix.copy(this.matrix), e.matrixWorld.copy(this.matrixWorld), e.quaternion.copy(this.quaternion), e.matrixAutoUpdate = this.matrixAutoUpdate, e.matrixWorldNeedsUpdate = this.matrixWorldNeedsUpdate, e.useQuaternion = this.useQuaternion, e.visible = this.visible;
						for (var t = 0; t < this.children.length; t++) {
							var n = this.children[t];
							e.add(n.clone());
						}
						return e;
					}
					setVisible(e) {
						this.visible = e;
						for (var t = 0; t < this.children.length; t++) this.children[t].setVisible(e);
					}
				}
				class s extends o {
					constructor() {
						super(...arguments), this.fog = null, this.overrideMaterial = null, this.matrixAutoUpdate = !1, this.__objects = [], this.__lights = [], this.__objectsAdded = [], this.__objectsRemoved = [];
					}
					__addObject(e) {
						if (e instanceof c) this.__lights.indexOf(e) === -1 && this.__lights.push(e), e.target && e.target.parent === void 0 && this.add(e.target);
						else if (this.__objects.indexOf(e) === -1) {
							this.__objects.push(e), this.__objectsAdded.push(e);
							var t = this.__objectsRemoved.indexOf(e);
							t !== -1 && this.__objectsRemoved.splice(t, 1);
						}
						for (var n = 0; n < e.children.length; n++) this.__addObject(e.children[n]);
					}
					__removeObject(e) {
						var t;
						e instanceof c ? (t = this.__lights.indexOf(e), t !== -1 && this.__lights.splice(t, 1)) : (t = this.__objects.indexOf(e), t !== -1 && (this.__objects.splice(t, 1), this.__objectsRemoved.push(e), this.__objectsAdded.indexOf(e) !== -1 && this.__objectsAdded.splice(t, 1)));
						for (var n = 0; n < e.children.length; n++) this.__removeObject(e.children[n]);
					}
				}
				class c extends o {
					constructor(e, t = 1) {
						super(), this.position = new r.Vector3(0, 1, 0), this.target = new o(), this.castShadow = !1, this.onlyShadow = !1, this.color = new i.Color(e), this.intensity = t;
					}
				}
			},
			"./src/WebGL/core/Projector.ts"(e, t, n) {
				n.r(t), n.d(t, { Projector: () => i });
				let r = new (n("./src/WebGL/math/index.ts")).Matrix4();
				class i {
					static unprojectVector(e, t) {
						return t.projectionMatrixInverse.getInverse(t.projectionMatrix), r.multiplyMatrices(t.matrixWorld, t.projectionMatrixInverse), e.applyProjection(r);
					}
					static projectVector(e, t) {
						return t.matrixWorldInverse.getInverse(t.matrixWorld), r.multiplyMatrices(t.projectionMatrix, t.matrixWorldInverse), e.applyProjection(r);
					}
					projectVector(e, t) {
						return i.projectVector(e, t);
					}
					unprojectVector(e, t) {
						return i.unprojectVector(e, t);
					}
				}
			},
			"./src/WebGL/core/Raycaster.ts"(e, t, n) {
				n.r(t), n.d(t, {
					Raycaster: () => s,
					intersectObject: () => _
				});
				var r = n("./src/WebGL/math/index.ts"), i = n("./src/WebGL/shapes/index.ts");
				let a = (e, t) => e.distance - t.distance, o = new r.Matrix4();
				class s {
					constructor(e, t, n, i) {
						this.precision = 1e-4, this.linePrecision = .2, this.ray = new r.Ray(e, t), this.ray.direction.lengthSq() > 0 && this.ray.direction.normalize(), this.near = i || 0, this.far = n || Infinity;
					}
					set(e, t) {
						this.ray.set(e, t);
					}
					setFromCamera(e, t) {
						t.ortho ? (this.ray.origin.set(e.x, e.y, (t.near + t.far) / (t.near - t.far)).unproject(t), this.ray.direction.set(0, 0, -1).transformDirection(t.matrixWorld)) : (this.ray.origin.setFromMatrixPosition(t.matrixWorld), this.ray.direction.set(e.x, e.y, e.z), t.projectionMatrixInverse.getInverse(t.projectionMatrix), o.multiplyMatrices(t.matrixWorld, t.projectionMatrixInverse), this.ray.direction.applyProjection(o), this.ray.direction.sub(this.ray.origin).normalize());
					}
					intersectObjects(e, t) {
						for (var n = [], r = 0, i = t.length; r < i; r++) _(e, t[r], this, n);
						return n.sort(a), n;
					}
				}
				let c = (e) => Math.min(Math.max(e, -1), 1);
				var l = new i.Sphere(), u = new i.Cylinder(), d = new i.Triangle(), f = new r.Vector3(), p = new r.Vector3(), m = new r.Vector3(), h = new r.Vector3(), g = new r.Vector3();
				function _(e, t, n, r) {
					if (g.getPositionFromMatrix(e.matrixWorld), t.intersectionShape === void 0 || t.hidden) return r;
					var a = t.intersectionShape, o = n.linePrecision;
					o *= e.matrixWorld.getMaxScaleOnAxis();
					var s = o * o;
					if (t.boundingSphere !== void 0 && t.boundingSphere instanceof i.Sphere && (l.copy(t.boundingSphere), l.applyMatrix4(e.matrixWorld), !n.ray.isIntersectionSphere(l))) return r;
					var _, v, y, b, x, S, C, w, T, E, D, O, k, A;
					for (_ = 0, v = a.triangle.length; _ < v; _++) if (a.triangle[_] instanceof i.Triangle) {
						if (d.copy(a.triangle[_]), d.applyMatrix4(e.matrixWorld), y = d.getNormal(), b = n.ray.direction.dot(y), b >= 0 || (f.subVectors(d.a, n.ray.origin), C = y.dot(f) / b, C < 0)) continue;
						p.copy(n.ray.direction).multiplyScalar(C).add(n.ray.origin), p.sub(d.a), m.copy(d.b).sub(d.a), h.copy(d.c).sub(d.a);
						var j = m.dot(h), M = m.lengthSq(), N = h.lengthSq();
						if (O = (M * p.dot(h) - j * p.dot(m)) / (M * N - j * j), O < 0 || O > 1 || (D = (p.dot(m) - O * j) / M, D < 0 || D > 1 || D + O > 1)) continue;
						r.push({
							clickable: t,
							distance: C
						});
					}
					for (_ = 0, v = a.cylinder.length; _ < v; _++) if (a.cylinder[_] instanceof i.Cylinder) {
						if (u.copy(a.cylinder[_]), u.applyMatrix4(e.matrixWorld), f.subVectors(u.c1, n.ray.origin), x = f.dot(u.direction), S = f.dot(n.ray.direction), b = c(n.ray.direction.dot(u.direction)), T = 1 - b * b, T === 0) continue;
						k = (b * S - x) / T, A = (S - b * x) / T, p.copy(u.direction).multiplyScalar(k).add(u.c1), m.copy(n.ray.direction).multiplyScalar(A).add(n.ray.origin), w = h.subVectors(p, m).lengthSq();
						var P = u.radius * u.radius;
						if (w <= P) {
							if (E = (b * x - S) * (b * x - S) - T * (f.lengthSq() - x * x - P), O = C = E <= 0 ? Math.sqrt(w) : (S - b * x - Math.sqrt(E)) / T, D = b * O - x, D < 0 || D * D > u.lengthSq() || O < 0) continue;
							r.push({
								clickable: t,
								distance: C
							});
						}
					}
					for (_ = 0, v = a.line.length; _ < v; _ += 2) {
						p.copy(a.line[_]), p.applyMatrix4(e.matrixWorld), m.copy(a.line[_ + 1]), m.applyMatrix4(e.matrixWorld), h.subVectors(m, p);
						var F = h.lengthSq();
						h.normalize(), f.subVectors(p, n.ray.origin);
						var I = f.dot(h);
						S = f.dot(n.ray.direction), b = c(n.ray.direction.dot(h)), T = 1 - b * b, T !== 0 && (k = (b * S - I) / T, A = (S - b * I) / T, p.add(h.multiplyScalar(k)), m.copy(n.ray.direction).multiplyScalar(A).add(n.ray.origin), w = h.subVectors(m, p).lengthSq(), w < s && k * k < F && r.push({
							clickable: t,
							distance: A
						}));
					}
					for (_ = 0, v = a.sphere.length; _ < v; _++) if (a.sphere[_] instanceof i.Sphere && (l.copy(a.sphere[_]), l.applyMatrix4(e.matrixWorld), n.ray.isIntersectionSphere(l))) {
						p.subVectors(l.center, n.ray.origin);
						var L = p.dot(n.ray.direction);
						if (E = L * L - (p.lengthSq() - l.radius * l.radius), L < 0) return r;
						C = E <= 0 ? L : L - Math.sqrt(E), r.push({
							clickable: t,
							distance: C
						});
					}
					return r;
				}
			},
			"./src/WebGL/core/Texture.ts"(e, t, n) {
				n.r(t), n.d(t, {
					Texture: () => s,
					TextureIdCount: () => c
				});
				var r = n("./src/WebGL/constants/TextureConstants.ts"), i = n("./src/WebGL/math/index.ts"), a = n("./src/WebGL/core/EventDispatcher.ts"), o = n("./src/WebGL/core/UVMapping.ts");
				class s extends a.EventDispatcher {
					constructor(e, t) {
						super(), this.id = c++, this.name = "", this.image = e, this.mapping = new o.UVMapping(), this.wrapS = r.ClampToEdgeWrapping, this.wrapT = r.ClampToEdgeWrapping, this.anisotropy = 1, t ? (this.format = r.RFormat, this.type = r.FloatType, this.premultiplyAlpha = !1, this.flipY = !1, this.unpackAlignment = 1, this.magFilter = r.NearestFilter, this.minFilter = r.NearestFilter) : (this.format = r.RGBAFormat, this.type = r.UnsignedByteType, this.offset = new i.Vector2(0, 0), this.repeat = new i.Vector2(1, 1), this.premultiplyAlpha = !1, this.flipY = !0, this.unpackAlignment = 4, this.magFilter = r.LinearFilter, this.minFilter = r.LinearMipMapLinearFilter), this.needsUpdate = !1, this.onUpdate = null;
					}
					clone(e = new s()) {
						return e.image = this.image, e.mapping = this.mapping, e.wrapS = this.wrapS, e.wrapT = this.wrapT, e.magFilter = this.magFilter, e.minFilter = this.minFilter, e.anisotropy = this.anisotropy, e.format = this.format, e.type = this.type, e.offset.copy(this.offset), e.repeat.copy(this.repeat), e.premultiplyAlpha = this.premultiplyAlpha, e.flipY = this.flipY, e.unpackAlignment = this.unpackAlignment, e;
					}
					dispose() {
						this.dispatchEvent({ type: "dispose" });
					}
				}
				let c = 0;
			},
			"./src/WebGL/core/UVMapping.ts"(e, t, n) {
				n.r(t), n.d(t, { UVMapping: () => r });
				class r {}
			},
			"./src/WebGL/core/index.ts"(e, t, n) {
				n.r(t), n.d(t, {
					EventDispatcher: () => r.EventDispatcher,
					Geometry: () => i.Geometry,
					GeometryGroup: () => i.GeometryGroup,
					GeometryIDCount: () => i.GeometryIDCount,
					Light: () => a.Light,
					Object3D: () => a.Object3D,
					Object3DIDCount: () => a.Object3DIDCount,
					Projector: () => o.Projector,
					Raycaster: () => s.Raycaster,
					Scene: () => a.Scene,
					Texture: () => c.Texture,
					TextureIdCount: () => c.TextureIdCount,
					UVMapping: () => l.UVMapping,
					intersectObject: () => s.intersectObject
				});
				var r = n("./src/WebGL/core/EventDispatcher.ts"), i = n("./src/WebGL/core/Geometry.ts"), a = n("./src/WebGL/core/Object3D.ts"), o = n("./src/WebGL/core/Projector.ts"), s = n("./src/WebGL/core/Raycaster.ts"), c = n("./src/WebGL/core/Texture.ts"), l = n("./src/WebGL/core/UVMapping.ts");
			},
			"./src/WebGL/index.ts"(e, t, n) {
				n.r(t), n.d(t, {
					BackSide: () => r.BackSide,
					Camera: () => u.Camera,
					ClampToEdgeWrapping: () => r.ClampToEdgeWrapping,
					Coloring: () => r.Coloring,
					Cylinder: () => l.Cylinder,
					DoubleSide: () => r.DoubleSide,
					EventDispatcher: () => i.EventDispatcher,
					FloatType: () => r.FloatType,
					Fog: () => d.Fog,
					FrontSide: () => r.FrontSide,
					Geometry: () => i.Geometry,
					GeometryGroup: () => i.GeometryGroup,
					GeometryIDCount: () => i.GeometryIDCount,
					ImposterMaterial: () => a.ImposterMaterial,
					InstancedMaterial: () => a.InstancedMaterial,
					Light: () => i.Light,
					Line: () => s.Line,
					LineBasicMaterial: () => a.LineBasicMaterial,
					LineStyle: () => s.LineStyle,
					LinearFilter: () => r.LinearFilter,
					LinearMipMapLinearFilter: () => r.LinearMipMapLinearFilter,
					Material: () => a.Material,
					MaterialIdCount: () => a.MaterialIdCount,
					Matrix3: () => o.Matrix3,
					Matrix4: () => o.Matrix4,
					Mesh: () => s.Mesh,
					MeshDoubleLambertMaterial: () => a.MeshDoubleLambertMaterial,
					MeshLambertMaterial: () => a.MeshLambertMaterial,
					MeshOutlineMaterial: () => a.MeshOutlineMaterial,
					NearestFilter: () => r.NearestFilter,
					Object3D: () => i.Object3D,
					Object3DIDCount: () => i.Object3DIDCount,
					Projector: () => i.Projector,
					Quaternion: () => o.Quaternion,
					R32Format: () => r.R32Format,
					RFormat: () => r.RFormat,
					RGBAFormat: () => r.RGBAFormat,
					Ray: () => o.Ray,
					Raycaster: () => i.Raycaster,
					Renderer: () => f.Renderer,
					RingImposterMaterial: () => a.RingImposterMaterial,
					Scene: () => i.Scene,
					ShaderLib: () => c.ShaderLib,
					ShaderUtils: () => c.ShaderUtils,
					Shading: () => r.Shading,
					Sphere: () => l.Sphere,
					SphereImposterMaterial: () => a.SphereImposterMaterial,
					SphereImposterOutlineMaterial: () => a.SphereImposterOutlineMaterial,
					Sprite: () => s.Sprite,
					SpriteAlignment: () => r.SpriteAlignment,
					SpriteMaterial: () => a.SpriteMaterial,
					SpritePlugin: () => p.SpritePlugin,
					StickImposterMaterial: () => a.StickImposterMaterial,
					StickImposterOutlineMaterial: () => a.StickImposterOutlineMaterial,
					Texture: () => i.Texture,
					TextureIdCount: () => i.TextureIdCount,
					TextureOperations: () => r.TextureOperations,
					Triangle: () => l.Triangle,
					UVMapping: () => i.UVMapping,
					UnsignedByteType: () => r.UnsignedByteType,
					Vector2: () => o.Vector2,
					Vector3: () => o.Vector3,
					VolumetricMaterial: () => a.VolumetricMaterial,
					basic: () => c.basic,
					clamp: () => o.clamp,
					clone: () => c.clone,
					conversionMatrix3: () => o.conversionMatrix3,
					degToRad: () => o.degToRad,
					instanced: () => c.instanced,
					intersectObject: () => i.intersectObject,
					lambert: () => c.lambert,
					lambertdouble: () => c.lambertdouble,
					outline: () => c.outline,
					ringimposter: () => c.ringimposter,
					screen: () => c.screen,
					screenaa: () => c.screenaa,
					sphereimposter: () => c.sphereimposter,
					sphereimposteroutline: () => c.sphereimposteroutline,
					sprite: () => c.sprite,
					stickimposter: () => c.stickimposter,
					stickimposteroutline: () => c.stickimposteroutline,
					volumetric: () => c.volumetric
				});
				var r = n("./src/WebGL/constants/index.ts"), i = n("./src/WebGL/core/index.ts"), a = n("./src/WebGL/materials/index.ts"), o = n("./src/WebGL/math/index.ts"), s = n("./src/WebGL/objects/index.ts"), c = n("./src/WebGL/shaders/index.ts"), l = n("./src/WebGL/shapes/index.ts"), u = n("./src/WebGL/Camera.ts"), d = n("./src/WebGL/Fog.ts"), f = n("./src/WebGL/Renderer.ts"), p = n("./src/WebGL/SpritePlugin.ts");
			},
			"./src/WebGL/materials/ImposterMaterial.ts"(e, t, n) {
				n.r(t), n.d(t, { ImposterMaterial: () => c });
				var r = n("./src/WebGL/constants/Coloring.ts"), i = n("./src/WebGL/constants/Shading.ts"), a = n("./src/colors.ts"), o = n("./src/WebGL/math/index.ts"), s = n("./src/WebGL/materials/Material.ts");
				class c extends s.Material {
					constructor(e) {
						super(), this.color = new a.Color(16777215), this.ambient = new a.Color(1048575), this.emissive = new a.Color(0), this.imposter = !0, this.wrapAround = !1, this.wrapRGB = new o.Vector3(1, 1, 1), this.map = void 0, this.lightMap = null, this.specularMap = null, this.envMap = null, this.reflectivity = 1, this.refractionRatio = .98, this.fog = !0, this.wireframe = !1, this.wireframeLinewidth = 1, this.wireframeLinecap = "round", this.wireframeLinejoin = "round", this.shading = i.Shading.SmoothShading, this.shaderID = null, this.vertexColors = r.Coloring.NoColors, this.skinning = !1, this.setValues(e);
					}
					clone(e = new c()) {
						return super.clone.call(this, e), e.color.copy(this.color), e.ambient.copy(this.ambient), e.emissive.copy(this.emissive), e.wrapAround = this.wrapAround, e.wrapRGB.copy(this.wrapRGB), e.map = this.map, e.lightMap = this.lightMap, e.specularMap = this.specularMap, e.envMap = this.envMap, e.combine = this.combine, e.reflectivity = this.reflectivity, e.refractionRatio = this.refractionRatio, e.fog = this.fog, e.shading = this.shading, e.shaderID = this.shaderID, e.vertexColors = this.vertexColors, e.skinning = this.skinning, e.morphTargets = this.morphTargets, e.morphNormals = this.morphNormals, e;
					}
				}
			},
			"./src/WebGL/materials/InstancedMaterial.ts"(e, t, n) {
				n.r(t), n.d(t, { InstancedMaterial: () => c });
				var r = n("./src/WebGL/constants/Coloring.ts"), i = n("./src/WebGL/constants/Shading.ts"), a = n("./src/colors.ts"), o = n("./src/WebGL/math/index.ts"), s = n("./src/WebGL/materials/Material.ts");
				class c extends s.Material {
					constructor(e) {
						super(), this.color = new a.Color(16777215), this.ambient = new a.Color(1048575), this.emissive = new a.Color(0), this.wrapAround = !1, this.wrapRGB = new o.Vector3(1, 1, 1), this.map = void 0, this.lightMap = null, this.specularMap = null, this.envMap = null, this.reflectivity = 1, this.refractionRatio = .98, this.fog = !0, this.wireframe = !1, this.wireframeLinewidth = 1, this.wireframeLinecap = "round", this.wireframeLinejoin = "round", this.shading = i.Shading.SmoothShading, this.shaderID = "instanced", this.vertexColors = r.Coloring.NoColors, this.skinning = !1, this.sphere = null, this.setValues(e);
					}
					clone(e = new c()) {
						return super.clone.call(this, e), e.color.copy(this.color), e.ambient.copy(this.ambient), e.emissive.copy(this.emissive), e.wrapAround = this.wrapAround, e.wrapRGB.copy(this.wrapRGB), e.map = this.map, e.lightMap = this.lightMap, e.specularMap = this.specularMap, e.envMap = this.envMap, e.combine = this.combine, e.reflectivity = this.reflectivity, e.refractionRatio = this.refractionRatio, e.fog = this.fog, e.shading = this.shading, e.shaderID = this.shaderID, e.vertexColors = this.vertexColors, e.skinning = this.skinning, e.morphTargets = this.morphTargets, e.morphNormals = this.morphNormals, e.sphere = this.sphere, e;
					}
				}
			},
			"./src/WebGL/materials/LineBasicMaterial.ts"(e, t, n) {
				n.r(t), n.d(t, { LineBasicMaterial: () => a });
				var r = n("./src/colors.ts"), i = n("./src/WebGL/materials/Material.ts");
				class a extends i.Material {
					constructor(e) {
						super(), this.color = new r.Color(16777215), this.linewidth = 1, this.linecap = "round", this.linejoin = "round", this.vertexColors = !1, this.fog = !0, this.shaderID = "basic", this.setValues(e);
					}
					clone(e = new a()) {
						return super.clone.call(this, e), e.color.copy(this.color), e;
					}
				}
			},
			"./src/WebGL/materials/Material.ts"(e, t, n) {
				n.r(t), n.d(t, {
					Material: () => s,
					MaterialIdCount: () => c
				});
				var r = n("./src/WebGL/constants/Sides.ts"), i = n("./src/WebGL/core/index.ts"), a = n("./src/WebGL/math/index.ts"), o = n("./src/colors.ts");
				class s extends i.EventDispatcher {
					constructor() {
						super(...arguments), this.id = c++, this.name = "", this.side = r.FrontSide, this.opacity = 1, this.transparent = !1, this.depthTest = !0, this.depthWrite = !0, this.polygonOffset = !1, this.polygonOffsetFactor = 0, this.polygonOffsetUnits = 0, this.alphaTest = 0, this.visible = !0, this.needsUpdate = !0, this.outline = !1, this.wireframe = !1, this.shaded = !1;
					}
					setValues(e = {}) {
						if (e !== void 0) for (var t in e) {
							var n = e[t];
							if (n === void 0) {
								console.warn("$3Dmol.Material: '" + t + "' parameter is undefined.");
								continue;
							}
							if (t in this) {
								var r = this[t];
								r instanceof o.Color && n instanceof o.Color ? r.copy(n) : r instanceof o.Color ? r.set(n) : r instanceof a.Vector3 && n instanceof a.Vector3 ? r.copy(n) : this[t] = n;
							}
						}
					}
					clone(e = new s()) {
						return e.name = this.name, e.side = this.side, e.opacity = this.opacity, e.transparent = this.transparent, e.depthTest = this.depthTest, e.depthWrite = this.depthWrite, e.polygonOffset = this.polygonOffset, e.polygonOffsetFactor = this.polygonOffsetFactor, e.polygonOffsetUnits = this.polygonOffsetUnits, e.alphaTest = this.alphaTest, e.overdraw = this.overdraw, e.visible = this.visible, e;
					}
					makeShaded(e) {
						this.shaded = !0, this.uniforms && (this.uniforms.shading = {
							type: "i",
							value: e
						}, this.uniforms.vWidth = {
							type: "f",
							value: 1
						}, this.uniforms.vHeight = {
							type: "f",
							value: 1
						});
					}
					dispose() {
						this.dispatchEvent({ type: "dispose" });
					}
				}
				let c = 0;
			},
			"./src/WebGL/materials/MeshDoubleLambertMaterial.ts"(e, t, n) {
				n.r(t), n.d(t, { MeshDoubleLambertMaterial: () => a });
				var r = n("./src/WebGL/constants/Sides.ts"), i = n("./src/WebGL/materials/MeshLambertMaterial.ts");
				class a extends i.MeshLambertMaterial {
					constructor(e) {
						super(e), this.shaderID = "lambertdouble", this.side = r.DoubleSide, this.outline = !1;
					}
					clone(e = new a()) {
						return super.clone.call(this, e), e;
					}
				}
			},
			"./src/WebGL/materials/MeshLambertMaterial.ts"(e, t, n) {
				n.r(t), n.d(t, { MeshLambertMaterial: () => c });
				var r = n("./src/WebGL/constants/Coloring.ts"), i = n("./src/WebGL/constants/Shading.ts"), a = n("./src/WebGL/materials/Material.ts"), o = n("./src/colors.ts"), s = n("./src/WebGL/math/index.ts");
				class c extends a.Material {
					constructor(e) {
						super(), this.color = new o.Color(16777215), this.ambient = new o.Color(1048575), this.emissive = new o.Color(0), this.wrapAround = !1, this.wrapRGB = new s.Vector3(1, 1, 1), this.map = void 0, this.lightMap = null, this.specularMap = null, this.envMap = null, this.reflectivity = 1, this.refractionRatio = .98, this.fog = !0, this.wireframe = !1, this.wireframeLinewidth = 1, this.wireframeLinecap = "round", this.wireframeLinejoin = "round", this.shading = i.Shading.SmoothShading, this.shaderID = "lambert", this.vertexColors = r.Coloring.NoColors, this.skinning = !1, this.setValues(e);
					}
					clone(e = new c()) {
						return super.clone.call(this, e), e.color.copy(this.color), e.ambient.copy(this.ambient), e.emissive.copy(this.emissive), e.wrapAround = this.wrapAround, e.wrapRGB.copy(this.wrapRGB), e.map = this.map, e.lightMap = this.lightMap, e.specularMap = this.specularMap, e.envMap = this.envMap, e.combine = this.combine, e.reflectivity = this.reflectivity, e.refractionRatio = this.refractionRatio, e.fog = this.fog, e.shading = this.shading, e.shaderID = this.shaderID, e.vertexColors = this.vertexColors, e.skinning = this.skinning, e.morphTargets = this.morphTargets, e.morphNormals = this.morphNormals, e;
					}
				}
			},
			"./src/WebGL/materials/MeshOutlineMaterial.ts"(e, t, n) {
				n.r(t), n.d(t, { MeshOutlineMaterial: () => a });
				var r = n("./src/colors.ts"), i = n("./src/WebGL/materials/Material.ts");
				class a extends i.Material {
					constructor(e) {
						super(), e ||= {}, this.fog = !0, this.shaderID = "outline", this.wireframe = !1, this.outlineColor = r.CC.color(e.color || new r.Color(0, 0, 0)), this.outlineWidth = e.width || .1, this.outlinePushback = e.pushback || 1, this.outlineMaxPixels = e.maxpixels || 0;
					}
					clone(e = new a()) {
						return super.clone.call(this, e), e.fog = this.fog, e.shaderID = this.shaderID, e.wireframe = this.wireframe, e.outlineColor = this.outlineColor, e.outlineWidth = this.outlineWidth, e.outlinePushback = this.outlinePushback, e.outlineMaxPixels = this.outlineMaxPixels, e;
					}
				}
			},
			"./src/WebGL/materials/RingImposterMaterial.ts"(e, t, n) {
				n.r(t), n.d(t, { RingImposterMaterial: () => i });
				var r = n("./src/WebGL/materials/ImposterMaterial.ts");
				class i extends r.ImposterMaterial {
					constructor(e) {
						super(e), this.shaderID = "ringimposter", this.setValues(e);
					}
					clone(e = new i()) {
						return super.clone.call(this, e), e;
					}
				}
			},
			"./src/WebGL/materials/SphereImposterMaterial.ts"(e, t, n) {
				n.r(t), n.d(t, { SphereImposterMaterial: () => i });
				var r = n("./src/WebGL/materials/ImposterMaterial.ts");
				class i extends r.ImposterMaterial {
					constructor(e) {
						super(e), this.shaderID = "sphereimposter", this.setValues(e);
					}
					clone(e = new i()) {
						return super.clone.call(this, e), e;
					}
				}
			},
			"./src/WebGL/materials/SphereImposterOutlineMaterial.ts"(e, t, n) {
				n.r(t), n.d(t, { SphereImposterOutlineMaterial: () => a });
				var r = n("./src/colors.ts"), i = n("./src/WebGL/materials/ImposterMaterial.ts");
				class a extends i.ImposterMaterial {
					constructor(e) {
						super(e), e ||= {}, this.shaderID = "sphereimposteroutline", this.outlineColor = r.CC.color(e.color || new r.Color(0, 0, 0)), this.outlineWidth = e.width || .1, this.outlinePushback = e.pushback || 1, this.outlineMaxPixels = e.maxpixels || 0, this.setValues(e);
					}
					clone(e = new a()) {
						return super.clone.call(this, e), e.outlineColor = this.outlineColor, e.outlineWidth = this.outlineWidth, e.outlinePushback = this.outlinePushback, e.outlineMaxPixels = this.outlineMaxPixels, e;
					}
				}
			},
			"./src/WebGL/materials/SpriteMaterial.ts"(e, t, n) {
				n.r(t), n.d(t, { SpriteMaterial: () => c });
				var r = n("./src/WebGL/constants/SpriteAlignment.ts"), i = n("./src/WebGL/core/Texture.ts"), a = n("./src/colors.ts"), o = n("./src/WebGL/math/index.ts"), s = n("./src/WebGL/materials/Material.ts");
				class c extends s.Material {
					constructor(e) {
						super(), this.color = new a.Color(16777215), this.map = new i.Texture(), this.useScreenCoordinates = !0, this.fog = !1, this.uvOffset = new o.Vector2(0, 0), this.uvScale = new o.Vector2(1, 1), this.depthTest = !this.useScreenCoordinates, this.sizeAttenuation = !this.useScreenCoordinates, this.screenOffset = this.screenOffset, this.scaleByViewPort = !this.sizeAttenuation, this.alignment = r.SpriteAlignment.center.clone(), this.setValues(e), e ||= {}, e.depthTest === void 0 && (this.depthTest = !this.useScreenCoordinates), e.sizeAttenuation === void 0 && (this.sizeAttenuation = !this.useScreenCoordinates), e.scaleByViewPort === void 0 && (this.scaleByViewPort = !this.sizeAttenuation);
					}
					clone(e = new c()) {
						return super.clone.call(this, e), e.color.copy(this.color), e.map = this.map, e.useScreenCoordinates = this.useScreenCoordinates, e.screenOffset = this.screenOffset, e.sizeAttenuation = this.sizeAttenuation, e.scaleByViewport = this.scaleByViewPort, e.alignment.copy(this.alignment), e.uvOffset.copy(this.uvOffset), e;
					}
				}
			},
			"./src/WebGL/materials/StickImposterMaterial.ts"(e, t, n) {
				n.r(t), n.d(t, { StickImposterMaterial: () => i });
				var r = n("./src/WebGL/materials/ImposterMaterial.ts");
				class i extends r.ImposterMaterial {
					constructor(e) {
						super(e), this.shaderID = "stickimposter", this.setValues(e);
					}
					clone(e = new i()) {
						return super.clone.call(this, e), e;
					}
				}
			},
			"./src/WebGL/materials/StickImposterOutlineMaterial.ts"(e, t, n) {
				n.r(t), n.d(t, { StickImposterOutlineMaterial: () => a });
				var r = n("./src/colors.ts"), i = n("./src/WebGL/materials/ImposterMaterial.ts");
				class a extends i.ImposterMaterial {
					constructor(e = {}) {
						super(e), this.shaderID = "stickimposteroutline", this.outlineColor = new r.Color(0, 0, 0), this.outlineWidth = .1, this.outlinePushback = 1, this.outlineMaxPixels = 0, e.color && (this.outlineColor = r.CC.color(e.color)), e.width && (this.outlineWidth = e.width), e.pushback && (this.outlinePushback = e.pushback), e.maxpixels && (this.outlineMaxPixels = e.maxpixels), this.setValues(e);
					}
					clone(e = new a()) {
						return super.clone.call(this, e), e.outlineColor = this.outlineColor, e.outlineWidth = this.outlineWidth, e.outlinePushback = this.outlinePushback, e.outlineMaxPixels = this.outlineMaxPixels, e;
					}
				}
			},
			"./src/WebGL/materials/VolumetricMaterial.ts"(e, t, n) {
				n.r(t), n.d(t, { VolumetricMaterial: () => o });
				var r = n("./src/WebGL/constants/Sides.ts"), i = n("./src/colors.ts"), a = n("./src/WebGL/materials/Material.ts");
				class o extends a.Material {
					constructor(e) {
						super(), this.transparent = !1, this.volumetric = !0, this.color = new i.Color(16777215), this.transferfn = null, this.map = void 0, this.extent = [], this.maxdepth = 100, this.unit = 0, this.texmatrix = null, this.transfermin = -1, this.transfermax = 1, this.subsamples = 5, this.shaderID = "volumetric", this.side = r.FrontSide, this.setValues(e);
					}
					clone(e = new o()) {
						return super.clone.call(this, e), e.transparent = this.transparent, e.volumetric = this.volumetric, e.color = this.color, e.transferfn = this.transferfn, e.map = this.map, e.extent = this.extent, e.maxdepth = this.maxdepth, e.unit = this.unit, e.texmatrix = this.texmatrix, e.transfermin = this.transfermin, e.transfermax = this.transfermax, e.subsamples = this.subsamples, e.shaderID = this.shaderID, e.side = this.side, e;
					}
				}
			},
			"./src/WebGL/materials/index.ts"(e, t, n) {
				n.r(t), n.d(t, {
					ImposterMaterial: () => r.ImposterMaterial,
					InstancedMaterial: () => i.InstancedMaterial,
					LineBasicMaterial: () => a.LineBasicMaterial,
					Material: () => o.Material,
					MaterialIdCount: () => o.MaterialIdCount,
					MeshDoubleLambertMaterial: () => s.MeshDoubleLambertMaterial,
					MeshLambertMaterial: () => c.MeshLambertMaterial,
					MeshOutlineMaterial: () => l.MeshOutlineMaterial,
					RingImposterMaterial: () => u.RingImposterMaterial,
					SphereImposterMaterial: () => d.SphereImposterMaterial,
					SphereImposterOutlineMaterial: () => f.SphereImposterOutlineMaterial,
					SpriteMaterial: () => p.SpriteMaterial,
					StickImposterMaterial: () => m.StickImposterMaterial,
					StickImposterOutlineMaterial: () => h.StickImposterOutlineMaterial,
					VolumetricMaterial: () => g.VolumetricMaterial
				});
				var r = n("./src/WebGL/materials/ImposterMaterial.ts"), i = n("./src/WebGL/materials/InstancedMaterial.ts"), a = n("./src/WebGL/materials/LineBasicMaterial.ts"), o = n("./src/WebGL/materials/Material.ts"), s = n("./src/WebGL/materials/MeshDoubleLambertMaterial.ts"), c = n("./src/WebGL/materials/MeshLambertMaterial.ts"), l = n("./src/WebGL/materials/MeshOutlineMaterial.ts"), u = n("./src/WebGL/materials/RingImposterMaterial.ts"), d = n("./src/WebGL/materials/SphereImposterMaterial.ts"), f = n("./src/WebGL/materials/SphereImposterOutlineMaterial.ts"), p = n("./src/WebGL/materials/SpriteMaterial.ts"), m = n("./src/WebGL/materials/StickImposterMaterial.ts"), h = n("./src/WebGL/materials/StickImposterOutlineMaterial.ts"), g = n("./src/WebGL/materials/VolumetricMaterial.ts");
			},
			"./src/WebGL/math/Quaternion.ts"(e, t, n) {
				n.r(t), n.d(t, { Quaternion: () => r });
				class r {
					constructor(e, t, n, r) {
						this.x = e || 0, this.y = t || 0, this.z = n || 0, this.w = r === void 0 ? 1 : r;
					}
					set(e, t, n, r) {
						return this.x = e, this.y = t, this.z = n, this.w = r, this;
					}
					copy(e) {
						return this.x = e.x, this.y = e.y, this.z = e.z, this.w = e.w, this;
					}
					conjugate() {
						return this.x *= -1, this.y *= -1, this.z *= -1, this;
					}
					inverse() {
						return this.conjugate().normalize();
					}
					length() {
						return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w);
					}
					lengthxyz() {
						return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
					}
					normalize() {
						let e = this.length();
						return e === 0 ? (this.x = 0, this.y = 0, this.z = 0, this.w = 1) : (e = 1 / e, this.x *= e, this.y *= e, this.z *= e, this.w *= e), this;
					}
					multiply(e) {
						return this.multiplyQuaternions(this, e);
					}
					multiplyScalar(e) {
						return this.x *= e, this.y *= e, this.z *= e, this.w *= e, this;
					}
					multiplyQuaternions(e, t) {
						let n = e.x, r = e.y, i = e.z, a = e.w, o = t.x, s = t.y, c = t.z, l = t.w;
						return this.x = n * l + a * o + r * c - i * s, this.y = r * l + a * s + i * o - n * c, this.z = i * l + a * c + n * s - r * o, this.w = a * l - n * o - r * s - i * c, this;
					}
					sub(e) {
						return this.x -= e.x, this.y -= e.y, this.z -= e.z, this.w -= e.w, this;
					}
					clone() {
						return new r(this.x, this.y, this.z, this.w);
					}
					setFromEuler(e) {
						let t = Math.cos(e.x / 2), n = Math.cos(e.y / 2), r = Math.cos(e.z / 2), i = Math.sin(e.x / 2), a = Math.sin(e.y / 2), o = Math.sin(e.z / 2);
						return this.x = i * n * r + t * a * o, this.y = t * a * r - i * n * o, this.z = t * n * o + i * a * r, this.w = t * n * r - i * a * o, this;
					}
				}
			},
			"./src/WebGL/math/Vector2.ts"(e, t, n) {
				n.r(t), n.d(t, { Vector2: () => r });
				class r {
					constructor(e, t) {
						this.x = e || 0, this.y = t || 0;
					}
					set(e, t) {
						return this.x = e, this.y = t, this;
					}
					subVectors(e, t) {
						return this.x = e.x - t.x, this.y = e.y - t.y, this;
					}
					copy(e) {
						return this.x = e.x, this.y = e.y, this;
					}
					clone() {
						return new r(this.x, this.y);
					}
				}
			},
			"./src/WebGL/math/index.ts"(e, t, n) {
				n.r(t), n.d(t, {
					Matrix3: () => c.Matrix3,
					Matrix4: () => c.Matrix4,
					Quaternion: () => r.Quaternion,
					Ray: () => c.Ray,
					Vector2: () => i.Vector2,
					Vector3: () => c.Vector3,
					clamp: () => a.clamp,
					conversionMatrix3: () => o.conversionMatrix3,
					degToRad: () => s.degToRad
				});
				var r = n("./src/WebGL/math/Quaternion.ts"), i = n("./src/WebGL/math/Vector2.ts"), a = n("./src/WebGL/math/utils/clamp.ts"), o = n("./src/WebGL/math/utils/conversionMatrix3.ts"), s = n("./src/WebGL/math/utils/degToRad.ts"), c = n("./src/WebGL/math/math.ts");
			},
			"./src/WebGL/math/math.ts"(e, t, n) {
				n.r(t), n.d(t, {
					Matrix3: () => f,
					Matrix4: () => u,
					Ray: () => p,
					Vector3: () => d
				});
				var r = n("./src/WebGL/math/utils/degToRad.ts"), i = n("./src/WebGL/math/utils/clamp.ts"), a, o, s, c, l;
				class u {
					constructor(e = 1, t = 0, n = 0, r = 0, i = 0, a = 1, o = 0, s = 0, c = 0, l = 0, u = 1, d = 0, f = 0, p = 0, m = 0, h = 1) {
						e !== void 0 && typeof e != "number" ? this.elements = new Float32Array(e) : (this.elements = /* @__PURE__ */ new Float32Array(16), this.elements[0] = e, this.elements[4] = t, this.elements[8] = n, this.elements[12] = r, this.elements[1] = i, this.elements[5] = a, this.elements[9] = o, this.elements[13] = s, this.elements[2] = c, this.elements[6] = l, this.elements[10] = u, this.elements[14] = d, this.elements[3] = f, this.elements[7] = p, this.elements[11] = m, this.elements[15] = h);
					}
					makeScale(e, t, n) {
						throw Error("Method not implemented.");
					}
					set(e, t, n, r, i, a, o, s, c, l, u, d, f, p, m, h) {
						let g = this.elements;
						return g[0] = e, g[4] = t, g[8] = n, g[12] = r, g[1] = i, g[5] = a, g[9] = o, g[13] = s, g[2] = c, g[6] = l, g[10] = u, g[14] = d, g[3] = f, g[7] = p, g[11] = m, g[15] = h, this;
					}
					identity() {
						return this.set(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1), this;
					}
					copy(e) {
						let t = e.elements;
						return this.set(t[0], t[4], t[8], t[12], t[1], t[5], t[9], t[13], t[2], t[6], t[10], t[14], t[3], t[7], t[11], t[15]), this;
					}
					matrix3FromTopLeft() {
						let e = this.elements;
						return new f(e[0], e[4], e[8], e[1], e[5], e[9], e[2], e[6], e[10]);
					}
					setRotationFromEuler(e, t) {
						let n = this.elements, { x: r, y: i, z: a } = e, o = Math.cos(r), s = Math.sin(r), c = Math.cos(i), l = Math.sin(i), u = Math.cos(a), d = Math.sin(a);
						if (t === void 0 || t === "XYZ") {
							let e = o * u, t = o * d, r = s * u, i = s * d;
							n[0] = c * u, n[4] = -c * d, n[8] = l, n[1] = t + r * l, n[5] = e - i * l, n[9] = -s * c, n[2] = i - e * l, n[6] = r + t * l, n[10] = o * c;
						} else console.error(`Error with matrix4 setRotationFromEuler. Order: ${t}`);
						return this;
					}
					setRotationFromQuaternion(e) {
						let t = this.elements, { x: n, y: r, z: i, w: a } = e, o = n + n, s = r + r, c = i + i, l = n * o, u = n * s, d = n * c, f = r * s, p = r * c, m = i * c, h = a * o, g = a * s, _ = a * c;
						return t[0] = 1 - (f + m), t[4] = u - _, t[8] = d + g, t[1] = u + _, t[5] = 1 - (l + m), t[9] = p - h, t[2] = d - g, t[6] = p + h, t[10] = 1 - (l + f), this;
					}
					multiplyMatrices(e, t) {
						let n = e.elements, r = t.elements, i = this.elements, a = n[0], o = n[4], s = n[8], c = n[12], l = n[1], u = n[5], d = n[9], f = n[13], p = n[2], m = n[6], h = n[10], g = n[14], _ = n[3], v = n[7], y = n[11], b = n[15], x = r[0], S = r[4], C = r[8], w = r[12], T = r[1], E = r[5], D = r[9], O = r[13], k = r[2], A = r[6], j = r[10], M = r[14], N = r[3], P = r[7], F = r[11], I = r[15];
						return i[0] = a * x + o * T + s * k + c * N, i[4] = a * S + o * E + s * A + c * P, i[8] = a * C + o * D + s * j + c * F, i[12] = a * w + o * O + s * M + c * I, i[1] = l * x + u * T + d * k + f * N, i[5] = l * S + u * E + d * A + f * P, i[9] = l * C + u * D + d * j + f * F, i[13] = l * w + u * O + d * M + f * I, i[2] = p * x + m * T + h * k + g * N, i[6] = p * S + m * E + h * A + g * P, i[10] = p * C + m * D + h * j + g * F, i[14] = p * w + m * O + h * M + g * I, i[3] = _ * x + v * T + y * k + b * N, i[7] = _ * S + v * E + y * A + b * P, i[11] = _ * C + v * D + y * j + b * F, i[15] = _ * w + v * O + y * M + b * I, this;
					}
					multiplyScalar(e) {
						let t = this.elements;
						return t[0] *= e, t[4] *= e, t[8] *= e, t[12] *= e, t[1] *= e, t[5] *= e, t[9] *= e, t[13] *= e, t[2] *= e, t[6] *= e, t[10] *= e, t[14] *= e, t[3] *= e, t[7] *= e, t[11] *= e, t[15] *= e, this;
					}
					makeTranslation(e, t, n) {
						return this.set(1, 0, 0, e, 0, 1, 0, t, 0, 0, 1, n, 0, 0, 0, 1), this;
					}
					snap(e) {
						e ||= 4;
						let t = 1e4, n = this.elements;
						for (let e = 0; e < 16; e++) {
							let r = Math.round(n[e]);
							r === Math.round(n[e] * t) / t && (n[e] = r);
						}
						return this;
					}
					transpose() {
						let e = this.elements, t;
						return t = e[1], e[1] = e[4], e[4] = t, t = e[2], e[2] = e[8], e[8] = t, t = e[6], e[6] = e[9], e[9] = t, t = e[3], e[3] = e[12], e[12] = t, t = e[7], e[7] = e[13], e[13] = t, t = e[11], e[11] = e[14], e[14] = t, this;
					}
					setPosition(e) {
						let t = this.elements;
						return t[12] = e.x, t[13] = e.y, t[14] = e.z, this;
					}
					translate(e) {
						let t = this.elements;
						return t[12] += e.x, t[13] += e.y, t[14] += e.z, this;
					}
					getInverse(e, t) {
						let n = this.elements, r = e.elements, i = r[0], a = r[4], o = r[8], s = r[12], c = r[1], l = r[5], u = r[9], d = r[13], f = r[2], p = r[6], m = r[10], h = r[14], g = r[3], _ = r[7], v = r[11], y = r[15];
						n[0] = u * h * _ - d * m * _ + d * p * v - l * h * v - u * p * y + l * m * y, n[4] = s * m * _ - o * h * _ - s * p * v + a * h * v + o * p * y - a * m * y, n[8] = o * d * _ - s * u * _ + s * l * v - a * d * v - o * l * y + a * u * y, n[12] = s * u * p - o * d * p - s * l * m + a * d * m + o * l * h - a * u * h, n[1] = d * m * g - u * h * g - d * f * v + c * h * v + u * f * y - c * m * y, n[5] = o * h * g - s * m * g + s * f * v - i * h * v - o * f * y + i * m * y, n[9] = s * u * g - o * d * g - s * c * v + i * d * v + o * c * y - i * u * y, n[13] = o * d * f - s * u * f + s * c * m - i * d * m - o * c * h + i * u * h, n[2] = l * h * g - d * p * g + d * f * _ - c * h * _ - l * f * y + c * p * y, n[6] = s * p * g - a * h * g - s * f * _ + i * h * _ + a * f * y - i * p * y, n[10] = a * d * g - s * l * g + s * c * _ - i * d * _ - a * c * y + i * l * y, n[14] = s * l * f - a * d * f - s * c * p + i * d * p + a * c * h - i * l * h, n[3] = u * p * g - l * m * g - u * f * _ + c * m * _ + l * f * v - c * p * v, n[7] = a * m * g - o * p * g + o * f * _ - i * m * _ - a * f * v + i * p * v, n[11] = o * l * g - a * u * g - o * c * _ + i * u * _ + a * c * v - i * l * v, n[15] = a * u * f - o * l * f + o * c * p - i * u * p - a * c * m + i * l * m;
						let b = i * n[0] + c * n[4] + f * n[8] + g * n[12];
						if (b === 0) {
							let e = "Matrix4.getInverse(): can't invert matrix, determinant is 0";
							if (t) throw Error(e);
							return console.warn(e), this.identity(), this;
						}
						return this.multiplyScalar(1 / b), this;
					}
					isReflected() {
						let e = this.elements, t = e[0], n = e[4], r = e[8], i = e[1], a = e[5], o = e[9], s = e[2], c = e[6], l = e[10];
						return t * a * l + i * c * r + s * n * o - s * a * r - i * n * l - t * c * o < 0;
					}
					scale(e) {
						let t = this.elements, { x: n } = e, { y: r } = e, { z: i } = e;
						return t[0] *= n, t[4] *= r, t[8] *= i, t[1] *= n, t[5] *= r, t[9] *= i, t[2] *= n, t[6] *= r, t[10] *= i, t[3] *= n, t[7] *= r, t[11] *= i, this;
					}
					getMaxScaleOnAxis() {
						let e = this.elements, t = e[0] * e[0] + e[1] * e[1] + e[2] * e[2], n = e[4] * e[4] + e[5] * e[5] + e[6] * e[6], r = e[8] * e[8] + e[9] * e[9] + e[10] * e[10];
						return Math.sqrt(Math.max(t, Math.max(n, r)));
					}
					makeFrustum(e, t, n, r, i, a) {
						let o = this.elements, s = 2 * i / (t - e), c = 2 * i / (r - n), l = (t + e) / (t - e), u = (r + n) / (r - n), d = -(a + i) / (a - i), f = -2 * a * i / (a - i);
						return o[0] = s, o[4] = 0, o[8] = l, o[12] = 0, o[1] = 0, o[5] = c, o[9] = u, o[13] = 0, o[2] = 0, o[6] = 0, o[10] = d, o[14] = f, o[3] = 0, o[7] = 0, o[11] = -1, o[15] = 0, this;
					}
					makePerspective(e, t, n, i) {
						let a = n * Math.tan((0, r.degToRad)(e * .5)), o = -a, s = o * t, c = a * t;
						return this.makeFrustum(s, c, o, a, n, i);
					}
					makeOrthographic(e, t, n, r, i, a) {
						let o = this.elements, s = 1 / (t - e), c = 1 / (n - r), l = 1 / (a - i), u = (t + e) * s, d = (n + r) * c, f = (a + i) * l;
						return o[0] = 2 * s, o[4] = 0, o[8] = 0, o[12] = -u, o[1] = 0, o[5] = 2 * c, o[9] = 0, o[13] = -d, o[2] = 0, o[6] = 0, o[10] = -2 * l, o[14] = -f, o[3] = 0, o[7] = 0, o[11] = 0, o[15] = 1, this;
					}
					isEqual(e) {
						let t = e.elements, n = this.elements;
						return n[0] === t[0] && n[4] === t[4] && n[8] === t[8] && n[12] === t[12] && n[1] === t[1] && n[5] === t[5] && n[9] === t[9] && n[13] === t[13] && n[2] === t[2] && n[6] === t[6] && n[10] === t[10] && n[14] === t[14] && n[3] === t[3] && n[7] === t[7] && n[11] === t[11] && n[15] === t[15];
					}
					clone() {
						let e = this.elements;
						return new u(e[0], e[4], e[8], e[12], e[1], e[5], e[9], e[13], e[2], e[6], e[10], e[14], e[3], e[7], e[11], e[15]);
					}
					isIdentity() {
						let e = this.elements;
						return e[0] === 1 && e[4] === 0 && e[8] === 0 && e[12] === 0 && e[1] === 0 && e[5] === 1 && e[9] === 0 && e[13] === 0 && e[2] === 0 && e[6] === 0 && e[10] === 1 && e[14] === 0 && e[3] === 0 && e[7] === 0 && e[11] === 0 && e[15] === 1;
					}
					isNearlyIdentity(e) {
						return this.clone().snap(e).isIdentity();
					}
					getScale(e) {
						let t = this.elements;
						return e ||= new d(), s.set(t[0], t[1], t[2]), c.set(t[4], t[5], t[6]), l.set(t[8], t[9], t[10]), e.x = s.length(), e.y = c.length(), e.z = l.length(), e;
					}
					lookAt(e, t, n) {
						let r = this.elements;
						return l.subVectors(e, t).normalize(), l.length() === 0 && (l.z = 1), s.crossVectors(n, l).normalize(), s.length() === 0 && (l.x += 1e-4, s.crossVectors(n, l).normalize()), c.crossVectors(l, s), r[0] = s.x, r[4] = c.x, r[8] = l.x, r[1] = s.y, r[5] = c.y, r[9] = l.y, r[2] = s.z, r[6] = c.z, r[10] = l.z, this;
					}
					compose(e, t, n) {
						let r = this.elements;
						return a.identity(), a.setRotationFromQuaternion(t), o.makeScale(n.x, n.y, n.z), this.multiplyMatrices(a, o), r[12] = e.x, r[13] = e.y, r[14] = e.z, this;
					}
				}
				a = new u(), o = new u();
				class d {
					constructor(e, t, n) {
						this.x = e || 0, this.y = t || 0, this.z = n || 0, this.atomid = void 0;
					}
					set(e, t, n) {
						return this.x = e, this.y = t, this.z = n, this;
					}
					copy(e) {
						return this.x = e.x, this.y = e.y, this.z = e.z, this;
					}
					add(e) {
						return this.x += e.x, this.y += e.y, this.z += e.z, this;
					}
					addVectors(e, t) {
						return this.x = e.x + t.x, this.y = e.y + t.y, this.z = e.z + t.z, this;
					}
					multiplyVectors(e, t) {
						return this.x = e.x * t.x, this.y = e.y * t.y, this.z = e.z * t.z, this;
					}
					sub(e) {
						return this.x -= e.x, this.y -= e.y, this.z -= e.z, this;
					}
					subVectors(e, t) {
						return this.x = e.x - t.x, this.y = e.y - t.y, this.z = e.z - t.z, this;
					}
					multiplyScalar(e) {
						return this.x *= e, this.y *= e, this.z *= e, this;
					}
					divideScalar(e) {
						return e === 0 ? (this.x = 0, this.y = 0, this.z = 0) : (this.x /= e, this.y /= e, this.z /= e), this;
					}
					max(e) {
						return this.x = Math.max(this.x, e.x), this.y = Math.max(this.y, e.y), this.z = Math.max(this.z, e.z), this;
					}
					min(e) {
						return this.x = Math.min(this.x, e.x), this.y = Math.min(this.y, e.y), this.z = Math.min(this.z, e.z), this;
					}
					distanceTo(e) {
						return Math.sqrt(this.distanceToSquared(e));
					}
					distanceToSquared(e) {
						let t = this.x - e.x, n = this.y - e.y, r = this.z - e.z;
						return t * t + n * n + r * r;
					}
					applyMatrix3(e) {
						let { x: t } = this, { y: n } = this, { z: r } = this, i = e.elements;
						return this.x = i[0] * t + i[3] * n + i[6] * r, this.y = i[1] * t + i[4] * n + i[7] * r, this.z = i[2] * t + i[5] * n + i[8] * r, this;
					}
					applyMatrix4(e) {
						let { x: t } = this, { y: n } = this, { z: r } = this, i = e.elements;
						return this.x = i[0] * t + i[4] * n + i[8] * r + i[12], this.y = i[1] * t + i[5] * n + i[9] * r + i[13], this.z = i[2] * t + i[6] * n + i[10] * r + i[14], this;
					}
					applyProjection(e) {
						let { x: t } = this, { y: n } = this, { z: r } = this, i = e.elements, a = i[3] * t + i[7] * n + i[11] * r + i[15];
						return this.x = (i[0] * t + i[4] * n + i[8] * r + i[12]) / a, this.y = (i[1] * t + i[5] * n + i[9] * r + i[13]) / a, this.z = (i[2] * t + i[6] * n + i[10] * r + i[14]) / a, this;
					}
					applyQuaternion(e) {
						let { x: t } = this, { y: n } = this, { z: r } = this, i = e.x, a = e.y, o = e.z, s = e.w, c = {};
						c.x = 2 * (n * o - r * a), c.y = 2 * (r * i - t * o), c.z = 2 * (t * a - n * i);
						let l = {};
						return l.x = c.y * o - c.z * a, l.y = c.z * i - c.x * o, l.z = c.x * a - c.y * i, this.x = t + s * c.x + l.x, this.y = n + s * c.y + l.y, this.z = r + s * c.z + l.z, this;
					}
					negate() {
						return this.multiplyScalar(-1);
					}
					dot(e) {
						return this.x * e.x + this.y * e.y + this.z * e.z;
					}
					length() {
						return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
					}
					lengthSq() {
						return this.x * this.x + this.y * this.y + this.z * this.z;
					}
					normalize() {
						return this.divideScalar(this.length());
					}
					cross(e) {
						let { x: t } = this, { y: n } = this, { z: r } = this;
						return this.x = n * e.z - r * e.y, this.y = r * e.x - t * e.z, this.z = t * e.y - n * e.x, this;
					}
					crossVectors(e, t) {
						return this.x = e.y * t.z - e.z * t.y, this.y = e.z * t.x - e.x * t.z, this.z = e.x * t.y - e.y * t.x, this;
					}
					equals(e) {
						return this.x == e.x && this.y == e.y && this.z == e.z;
					}
					getPositionFromMatrix(e) {
						return this.x = e.elements[12], this.y = e.elements[13], this.z = e.elements[14], this;
					}
					setEulerFromRotationMatrix(e, t) {
						let n = e.elements, r = n[0], a = n[4], o = n[8], s = n[5], c = n[9], l = n[6], u = n[10];
						return t === void 0 || t === "XYZ" ? (this.y = Math.asin((0, i.clamp)(o, -1, 1)), Math.abs(o) < .99999 ? (this.x = Math.atan2(-c, u), this.z = Math.atan2(-a, r)) : (this.x = Math.atan2(l, s), this.z = 0)) : console.error(`Error with vector's setEulerFromRotationMatrix: Unknown order: ${t}`), this;
					}
					rotateAboutVector(e, t) {
						e.normalize();
						let n = Math.cos(t), r = Math.sin(t), i = this.clone().multiplyScalar(n), a = e.clone().cross(this).multiplyScalar(r), o = e.clone().multiplyScalar(e.clone().dot(this)).multiplyScalar(1 - n), s = i.add(a).add(o);
						return this.x = s.x, this.y = s.y, this.z = s.z, this;
					}
					setFromMatrixPosition(e) {
						let t = e.elements;
						return this.x = t[12], this.y = t[13], this.z = t[14], this;
					}
					transformDirection(e) {
						let { x: t } = this, { y: n } = this, { z: r } = this, i = e.elements;
						return this.x = i[0] * t + i[4] * n + i[8] * r, this.y = i[1] * t + i[5] * n + i[9] * r, this.z = i[2] * t + i[6] * n + i[10] * r, this.normalize();
					}
					clone() {
						return new d(this.x, this.y, this.z);
					}
					unproject(e) {
						let t = a;
						return t.multiplyMatrices(e.matrixWorld, t.getInverse(e.projectionMatrix)), this.applyMatrix4(t);
					}
				}
				s = new d(), c = new d(), l = new d();
				class f {
					constructor(e = 1, t = 0, n = 0, r = 0, i = 1, a = 0, o = 0, s = 0, c = 1) {
						this.elements = /* @__PURE__ */ new Float32Array(9), this.set(e, t, n, r, i, a, o, s, c);
					}
					set(e, t, n, r, i, a, o, s, c) {
						let l = this.elements;
						return l[0] = e, l[3] = t, l[6] = n, l[1] = r, l[4] = i, l[7] = a, l[2] = o, l[5] = s, l[8] = c, this;
					}
					identity() {
						return this.set(1, 0, 0, 0, 1, 0, 0, 0, 1), this;
					}
					copy(e) {
						let t = e.elements;
						this.set(t[0], t[3], t[6], t[1], t[4], t[7], t[2], t[5], t[8]);
					}
					multiplyScalar(e) {
						let t = this.elements;
						return t[0] *= e, t[3] *= e, t[6] *= e, t[1] *= e, t[4] *= e, t[7] *= e, t[2] *= e, t[5] *= e, t[8] *= e, this;
					}
					getInverse3(e) {
						let t = e.elements, n = this.elements;
						n[0] = t[4] * t[8] - t[5] * t[7], n[3] = t[6] * t[5] - t[3] * t[8], n[6] = t[3] * t[7] - t[6] * t[4], n[1] = t[7] * t[2] - t[1] * t[8], n[4] = t[0] * t[8] - t[6] * t[2], n[7] = t[1] * t[6] - t[0] * t[7], n[2] = t[1] * t[5] - t[2] * t[4], n[5] = t[2] * t[3] - t[0] * t[5], n[8] = t[0] * t[4] - t[1] * t[3];
						let r = t[0] * n[0] + t[3] * n[1] + t[6] * n[2];
						return this.multiplyScalar(1 / r), this;
					}
					getInverse(e, t) {
						let n = e.elements, r = this.elements;
						r[0] = n[10] * n[5] - n[6] * n[9], r[1] = -n[10] * n[1] + n[2] * n[9], r[2] = n[6] * n[1] - n[2] * n[5], r[3] = -n[10] * n[4] + n[6] * n[8], r[4] = n[10] * n[0] - n[2] * n[8], r[5] = -n[6] * n[0] + n[2] * n[4], r[6] = n[9] * n[4] - n[5] * n[8], r[7] = -n[9] * n[0] + n[1] * n[8], r[8] = n[5] * n[0] - n[1] * n[4];
						let i = n[0] * r[0] + n[1] * r[3] + n[2] * r[6];
						if (i === 0) {
							let e = "Matrix3.getInverse(): can't invert matrix, determinant is 0";
							if (t) throw Error(e);
							return console.warn(e), this.identity(), this;
						}
						return this.multiplyScalar(1 / i), this;
					}
					getDeterminant() {
						let e = this.elements;
						return e[0] * e[4] * e[8] + e[1] * e[5] * e[6] + e[2] * e[3] * e[7] - e[2] * e[4] * e[6] - e[1] * e[3] * e[8] - e[0] * e[5] * e[7];
					}
					transpose() {
						let e, t = this.elements;
						return e = t[1], t[1] = t[3], t[3] = e, e = t[2], t[2] = t[6], t[6] = e, e = t[5], t[5] = t[7], t[7] = e, this;
					}
					clone() {
						let e = this.elements;
						return new f(e[0], e[3], e[6], e[1], e[4], e[7], e[2], e[5], e[8]);
					}
					getMatrix4() {
						let e = this.elements;
						return new u(e[0], e[3], e[6], 0, e[1], e[4], e[7], 0, e[2], e[5], e[8], 0);
					}
				}
				class p {
					constructor(e, t) {
						this.origin = e === void 0 ? new d() : e, this.direction = t === void 0 ? new d() : t;
					}
					set(e, t) {
						return this.origin.copy(e), this.direction.copy(t), this;
					}
					copy(e) {
						return this.origin.copy(e.origin), this.direction.copy(e.direction), this;
					}
					at(e, t) {
						return (t || new d()).copy(this.direction).multiplyScalar(e).add(this.origin);
					}
					recast(e) {
						let t = s;
						return this.origin.copy(this.at(e, t)), this;
					}
					closestPointToPoint(e, t) {
						let n = t || new d();
						n.subVectors(e, this.origin);
						let r = n.dot(this.direction);
						return n.copy(this.direction).multiplyScalar(r).add(this.origin);
					}
					distanceToPoint(e) {
						let t = s, n = t.subVectors(e, this.origin).dot(this.direction);
						return t.copy(this.direction).multiplyScalar(n).add(this.origin), t.distanceTo(e);
					}
					isIntersectionCylinder() {}
					isIntersectionSphere(e) {
						return this.distanceToPoint(e.center) <= e.radius;
					}
					isIntersectionPlane(e) {
						return e.normal.dot(this.direction) !== 0 || e.distanceToPoint(this.origin) === 0;
					}
					distanceToPlane(e) {
						let t = e.normal.dot(this.direction);
						return t === 0 ? e.distanceToPoint(this.origin) === 0 ? 0 : void 0 : -(this.origin.dot(e.normal) + e.constant) / t;
					}
					intersectPlane(e, t) {
						let n = this.distanceToPlane(e);
						if (n !== void 0) return this.at(n, t);
					}
					applyMatrix4(e) {
						return this.direction.add(this.origin).applyMatrix4(e), this.origin.applyMatrix4(e), this.direction.sub(this.origin), this;
					}
					clone() {
						return new p().copy(this);
					}
				}
			},
			"./src/WebGL/math/utils/clamp.ts"(e, t, n) {
				n.r(t), n.d(t, { clamp: () => r });
				function r(e, t, n) {
					return Math.min(Math.max(e, t), n);
				}
			},
			"./src/WebGL/math/utils/conversionMatrix3.ts"(e, t, n) {
				n.r(t), n.d(t, { conversionMatrix3: () => i });
				var r = n("./src/WebGL/math/math.ts");
				function i(e, t, n, i, a, o) {
					i = i * Math.PI / 180, a = a * Math.PI / 180, o = o * Math.PI / 180;
					let s = (e) => e * e, c = Math.cos(i), l = Math.cos(a), u = Math.cos(o), d = Math.sin(o);
					return new r.Matrix3(e, t * u, n * l, 0, t * d, n * (c - l * u) / d, 0, 0, n * Math.sqrt(1 - s(c) - s(l) - s(u) + 2 * c * l * u) / d);
				}
			},
			"./src/WebGL/math/utils/degToRad.ts"(e, t, n) {
				n.r(t), n.d(t, { degToRad: () => i });
				let r = Math.PI / 180;
				function i(e) {
					return e * r;
				}
			},
			"./src/WebGL/objects/Line.ts"(e, t, n) {
				n.r(t), n.d(t, {
					Line: () => o,
					LineStyle: () => a
				});
				var r = n("./src/WebGL/materials/index.ts"), i = n("./src/WebGL/core/index.ts"), a;
				(function(e) {
					e[e.LineStrip = 0] = "LineStrip", e[e.LinePieces = 1] = "LinePieces";
				})(a ||= {});
				class o extends i.Object3D {
					constructor(e, t = new r.LineBasicMaterial({ color: Math.random() * 16777215 }), n = a.LineStrip) {
						super(), this.geometry = e, this.material = t, this.type = n;
					}
					clone(e = new o(this.geometry, this.material, this.type)) {
						return super.clone.call(this, e), e;
					}
				}
			},
			"./src/WebGL/objects/Mesh.ts"(e, t, n) {
				n.r(t), n.d(t, { Mesh: () => i });
				var r = n("./src/WebGL/core/index.ts");
				class i extends r.Object3D {
					constructor(e, t) {
						super(), this.geometry = e, this.material = t;
					}
					clone(e) {
						return e === void 0 && (e = new i(this.geometry, this.material)), super.clone.call(this, e), e;
					}
				}
			},
			"./src/WebGL/objects/Sprite.ts"(e, t, n) {
				n.r(t), n.d(t, { Sprite: () => a });
				var r = n("./src/WebGL/materials/index.ts"), i = n("./src/WebGL/core/index.ts");
				class a extends i.Object3D {
					constructor(e = new r.SpriteMaterial()) {
						super(), this.material = e, this.rotation3d = this.rotation, this.rotation = 0;
					}
					updateMatrix() {
						this.matrix.setPosition(this.position), this.rotation3d.set(0, 0, this.rotation), this.matrix.setRotationFromEuler(this.rotation3d), (this.scale.x !== 1 || this.scale.y !== 1) && this.matrix.scale(this.scale), this.matrixWorldNeedsUpdate = !0;
					}
					clone(e = new a(this.material)) {
						return i.Object3D.prototype.clone.call(this, e), e;
					}
				}
			},
			"./src/WebGL/objects/index.ts"(e, t, n) {
				n.r(t), n.d(t, {
					Line: () => r.Line,
					LineStyle: () => r.LineStyle,
					Mesh: () => i.Mesh,
					Sprite: () => a.Sprite
				});
				var r = n("./src/WebGL/objects/Line.ts"), i = n("./src/WebGL/objects/Mesh.ts"), a = n("./src/WebGL/objects/Sprite.ts");
			},
			"./src/WebGL/shaders/ShaderType.ts"(e, t, n) {
				n.r(t);
			},
			"./src/WebGL/shaders/index.ts"(e, t, n) {
				n.r(t), n.d(t, {
					ShaderLib: () => r.ShaderLib,
					ShaderUtils: () => i.ShaderUtils,
					basic: () => r.basic,
					clone: () => i.clone,
					instanced: () => r.instanced,
					lambert: () => r.lambert,
					lambertdouble: () => r.lambertdouble,
					outline: () => r.outline,
					ringimposter: () => r.ringimposter,
					screen: () => r.screen,
					screenaa: () => r.screenaa,
					sphereimposter: () => r.sphereimposter,
					sphereimposteroutline: () => r.sphereimposteroutline,
					sprite: () => r.sprite,
					stickimposter: () => r.stickimposter,
					stickimposteroutline: () => r.stickimposteroutline,
					volumetric: () => r.volumetric
				});
				var r = n("./src/WebGL/shaders/lib/index.ts"), i = n("./src/WebGL/shaders/utils/index.ts"), a = n("./src/WebGL/shaders/ShaderType.ts");
			},
			"./src/WebGL/shaders/lib/basic/basic.frag"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "uniform mat4 viewMatrix;\nuniform float opacity;\nuniform vec3 fogColor;\nuniform float fogNear;\nuniform float fogFar;\nvarying vec3 vColor;\nvarying vec4 mvPosition;\n\n//DEFINEFRAGCOLOR\nvoid main() {\n    gl_FragColor = vec4( vColor, opacity );\n    if(fogNear != fogFar) {\n        float depth = -mvPosition.z;\n        float fogFactor = smoothstep( fogNear, fogFar, depth );\n        gl_FragColor = mix( gl_FragColor, vec4( fogColor, gl_FragColor.w ), fogFactor );\n    }\n}";
			},
			"./src/WebGL/shaders/lib/basic/basic.vert"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "uniform mat4 modelViewMatrix;\nuniform mat4 projectionMatrix;\nuniform mat4 viewMatrix;\nuniform mat3 normalMatrix;\n\nattribute vec3 position;\nattribute vec3 color;\n\nvarying vec3 vColor;\nvarying vec4 mvPosition;\n\nvoid main() {\n\n    vColor = color;\n    mvPosition = modelViewMatrix * vec4( position, 1.0 );\n    gl_Position = projectionMatrix * mvPosition;\n\n}";
			},
			"./src/WebGL/shaders/lib/basic/index.ts"(e, t, n) {
				n.r(t), n.d(t, { basic: () => a });
				var r = n("./src/WebGL/shaders/lib/basic/uniforms.ts"), i = n("./src/WebGL/shaders/lib/basic/basic.frag");
				let a = {
					vertexShader: n("./src/WebGL/shaders/lib/basic/basic.vert").default.replace("#define GLSLIFY 1", ""),
					fragmentShader: i.default.replace("#define GLSLIFY 1", ""),
					uniforms: r.uniforms
				};
			},
			"./src/WebGL/shaders/lib/basic/uniforms.ts"(e, t, n) {
				n.r(t), n.d(t, { uniforms: () => r });
				let r = {
					opacity: {
						type: "f",
						value: 1
					},
					fogColor: {
						type: "c",
						value: new (n("./src/colors.ts")).Color(1, 1, 1)
					},
					fogNear: {
						type: "f",
						value: 1
					},
					fogFar: {
						type: "f",
						value: 2e3
					}
				};
			},
			"./src/WebGL/shaders/lib/blur/blur.frag"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "const float INV_TOTAL_SAMPLES_FACTOR = 1.0 / 9.0;\nuniform highp sampler2D inTex;\nvarying highp vec2 vTexCoords;\n    \nvoid main() {\n \n vec2 texelSize = 1.0 / vec2(textureSize(inTex,0));\n float blurred_visibility_factor = 0.0f;\n for (int t = -1; t <= 1; ++t) {\n  for (int s = -1; s <= 1; ++s) {\n   vec2 offset = vec2(float(s), float(t)) * texelSize;\n   blurred_visibility_factor += texture2D(inTex, vTexCoords + offset).r;\n  }\n }\n    \n gl_FragDepthEXT = blurred_visibility_factor * INV_TOTAL_SAMPLES_FACTOR;\n \n}";
			},
			"./src/WebGL/shaders/lib/blur/blur.vert"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "attribute vec2 vertexPosition;\nvarying highp vec2 vTexCoords;\nconst vec2 scale = vec2(0.5, 0.5);\n\nvoid main() {\n   vTexCoords  = vertexPosition * scale + scale; // scale vertex attribute to [0,1] range\n   gl_Position = vec4(vertexPosition, 0.0, 1.0);\n}\n        ";
			},
			"./src/WebGL/shaders/lib/blur/index.ts"(e, t, n) {
				n.r(t), n.d(t, { blur: () => o });
				var r = n("./src/WebGL/shaders/lib/blur/uniforms.ts"), i = n("./src/WebGL/shaders/lib/blur/blur.frag"), a = n("./src/WebGL/shaders/lib/blur/blur.vert");
				let o = {
					fragmentShader: i.default,
					vertexShader: a.default,
					uniforms: r.uniforms
				};
			},
			"./src/WebGL/shaders/lib/blur/uniforms.ts"(e, t, n) {
				n.r(t), n.d(t, { uniforms: () => r });
				let r = {};
			},
			"./src/WebGL/shaders/lib/index.ts"(e, t, n) {
				n.r(t), n.d(t, {
					ShaderLib: () => y,
					basic: () => r.basic,
					instanced: () => i.instanced,
					lambert: () => a.lambert,
					lambertdouble: () => o.lambertdouble,
					outline: () => s.outline,
					ringimposter: () => u.ringimposter,
					screen: () => c.screen,
					screenaa: () => l.screenaa,
					sphereimposter: () => d.sphereimposter,
					sphereimposteroutline: () => f.sphereimposteroutline,
					sprite: () => p.sprite,
					stickimposter: () => m.stickimposter,
					stickimposteroutline: () => h.stickimposteroutline,
					volumetric: () => g.volumetric
				});
				var r = n("./src/WebGL/shaders/lib/basic/index.ts"), i = n("./src/WebGL/shaders/lib/instanced/index.ts"), a = n("./src/WebGL/shaders/lib/lambert/index.ts"), o = n("./src/WebGL/shaders/lib/lambertdouble/index.ts"), s = n("./src/WebGL/shaders/lib/outline/index.ts"), c = n("./src/WebGL/shaders/lib/screen/index.ts"), l = n("./src/WebGL/shaders/lib/screenaa/index.ts"), u = n("./src/WebGL/shaders/lib/ringimposter/index.ts"), d = n("./src/WebGL/shaders/lib/sphereimposter/index.ts"), f = n("./src/WebGL/shaders/lib/sphereimposteroutline/index.ts"), p = n("./src/WebGL/shaders/lib/sprite/index.ts"), m = n("./src/WebGL/shaders/lib/stickimposter/index.ts"), h = n("./src/WebGL/shaders/lib/stickimposteroutline/index.ts"), g = n("./src/WebGL/shaders/lib/volumetric/index.ts"), _ = n("./src/WebGL/shaders/lib/ssao/index.ts"), v = n("./src/WebGL/shaders/lib/blur/index.ts");
				let y = {
					basic: r.basic,
					blur: v.blur,
					instanced: i.instanced,
					lambert: a.lambert,
					lambertdouble: o.lambertdouble,
					outline: s.outline,
					screen: c.screen,
					screenaa: l.screenaa,
					ssao: _.ssao,
					ringimposter: u.ringimposter,
					sphereimposter: d.sphereimposter,
					sphereimposteroutline: f.sphereimposteroutline,
					sprite: p.sprite,
					stickimposter: m.stickimposter,
					stickimposteroutline: h.stickimposteroutline,
					volumetric: g.volumetric
				};
			},
			"./src/WebGL/shaders/lib/instanced/index.ts"(e, t, n) {
				n.r(t), n.d(t, { instanced: () => o });
				var r = n("./src/WebGL/shaders/lib/instanced/uniforms.ts"), i = n("./src/WebGL/shaders/lib/instanced/instanced.frag"), a = n("./src/WebGL/shaders/lib/instanced/instanced.vert");
				let o = {
					fragmentShader: i.default.replace("#define GLSLIFY 1", ""),
					vertexShader: a.default.replace("#define GLSLIFY 1", ""),
					uniforms: r.uniforms
				};
			},
			"./src/WebGL/shaders/lib/instanced/instanced.frag"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "uniform mat4 viewMatrix;\nuniform float opacity;\n\nuniform vec3 fogColor;\nuniform float fogNear;\nuniform float fogFar;\n#ifdef SHADED\nuniform highp sampler2D shading;\n#endif\nvarying vec3 vLightFront;\nvarying vec3 vColor;\n//DEFINEFRAGCOLOR\n\nvoid main() {\n\n    gl_FragColor = vec4( vec3 ( 1.0 ), opacity );\n\n    #ifndef WIREFRAME\n    gl_FragColor.xyz *= vLightFront;\n    #endif\n\n#ifdef SHADED\n    ivec2 dim = textureSize(shading,0);\n    float shadowFactor = texture2D(shading,vec2(gl_FragCoord.x/float(dim.x),gl_FragCoord.y/float(dim.y))).r;\n    vColor *= shadowFactor;\n#endif\n    gl_FragColor = gl_FragColor * vec4( vColor, opacity );\n    float depth = gl_FragCoord.z / gl_FragCoord.w;\n\n    float fogFactor = smoothstep( fogNear, fogFar, depth );\n\n    gl_FragColor = mix( gl_FragColor, vec4( fogColor, gl_FragColor.w ), fogFactor );\n\n}\n\n\n";
			},
			"./src/WebGL/shaders/lib/instanced/instanced.vert"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "\n\nuniform mat4 modelViewMatrix;\nuniform mat4 projectionMatrix;\nuniform mat4 viewMatrix;\nuniform mat3 normalMatrix;\nuniform vec3 directionalLightColor[ 1 ];\nuniform vec3 directionalLightDirection[ 1 ];\n\nattribute vec3 offset;\nattribute vec3 position;\nattribute vec3 normal;\nattribute vec3 color;\nattribute float radius;\n\nvarying vec3 vColor;\nvarying vec3 vLightFront;\n\nvoid main() {\n\n    vColor = color;\n\n    vec3 objectNormal = normal;\n    vec3 transformedNormal = normalMatrix * objectNormal;\n    vec4 mvPosition = modelViewMatrix * vec4( position * radius + offset, 1.0 );\n\n    vLightFront = vec3( 0.0 );\n\n    transformedNormal = normalize( transformedNormal );\n\n    vec4 lDirection = viewMatrix * vec4( directionalLightDirection[ 0 ], 0.0 );\n    vec3 dirVector = normalize( lDirection.xyz );\n    float dotProduct = dot( transformedNormal, dirVector );\n    vec3 directionalLightWeighting = vec3( max( dotProduct, 0.0 ) );\n\n    vLightFront += directionalLightColor[ 0 ] * directionalLightWeighting;\n\n    gl_Position = projectionMatrix * mvPosition;\n}\n\n";
			},
			"./src/WebGL/shaders/lib/instanced/uniforms.ts"(e, t, n) {
				n.r(t), n.d(t, { uniforms: () => r });
				let r = {
					opacity: {
						type: "f",
						value: 1
					},
					fogColor: {
						type: "c",
						value: new (n("./src/colors.ts")).Color(1, 1, 1)
					},
					fogNear: {
						type: "f",
						value: 1
					},
					fogFar: {
						type: "f",
						value: 2e3
					},
					directionalLightColor: {
						type: "fv",
						value: []
					},
					directionalLightDirection: {
						type: "fv",
						value: []
					}
				};
			},
			"./src/WebGL/shaders/lib/lambert/index.ts"(e, t, n) {
				n.r(t), n.d(t, { lambert: () => o });
				var r = n("./src/WebGL/shaders/lib/lambert/uniforms.ts"), i = n("./src/WebGL/shaders/lib/lambert/lambert.frag"), a = n("./src/WebGL/shaders/lib/lambert/lambert.vert");
				let o = {
					fragmentShader: i.default.replace("#define GLSLIFY 1", ""),
					vertexShader: a.default.replace("#define GLSLIFY 1", ""),
					uniforms: r.uniforms
				};
			},
			"./src/WebGL/shaders/lib/lambert/lambert.frag"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "uniform mat4 viewMatrix;\nuniform float opacity;\n\nuniform vec3 fogColor;\nuniform float fogNear;\nuniform float fogFar;\n#ifdef SHADED\nuniform highp sampler2D shading;\n#endif\nvarying vec3 vLightFront;\nvarying vec3 vColor;\nvarying vec4 mvPosition;\n\n\n//DEFINEFRAGCOLOR\n\nvoid main() {\n\n    gl_FragColor = vec4( vec3 ( 1.0 ), opacity );\n\n    #ifndef WIREFRAME\n    gl_FragColor.xyz *= vLightFront;\n    #endif\n#ifdef SHADED\n    ivec2 dim = textureSize(shading,0);\n    float shadowFactor = texture2D(shading,vec2(gl_FragCoord.x/float(dim.x),gl_FragCoord.y/float(dim.y))).r;\n    vColor *= shadowFactor;\n#endif\n    gl_FragColor = gl_FragColor * vec4( vColor, opacity );\n\n    if(fogNear != fogFar) {\n        float depth = -mvPosition.z;\n        float fogFactor = smoothstep( fogNear, fogFar, depth );\n        gl_FragColor = mix( gl_FragColor, vec4( fogColor, gl_FragColor.w ), fogFactor );\n    }\n\n}";
			},
			"./src/WebGL/shaders/lib/lambert/lambert.vert"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "\nuniform mat4 modelViewMatrix;\nuniform mat4 projectionMatrix;\nuniform mat4 viewMatrix;\nuniform mat3 normalMatrix;\nuniform vec3 directionalLightColor[ 1 ];\nuniform vec3 directionalLightDirection[ 1 ];\n\nattribute vec3 position;\nattribute vec3 normal;\nattribute vec3 color;\n\nvarying vec3 vColor;\nvarying vec3 vLightFront;\nvarying vec4 mvPosition;\n\nvoid main() {\n\n    vColor = color;\n\n    vec3 objectNormal = normal;\n    vec3 transformedNormal = normalMatrix * objectNormal;\n    mvPosition = modelViewMatrix * vec4( position, 1.0 );\n\n    vLightFront = vec3( 0.0 );\n\n    transformedNormal = normalize( transformedNormal );\n\n    vec4 lDirection = viewMatrix * vec4( directionalLightDirection[ 0 ], 0.0 );\n    vec3 dirVector = normalize( lDirection.xyz );\n    float dotProduct = dot( transformedNormal, dirVector );\n    vec3 directionalLightWeighting = vec3( max( dotProduct, 0.0 ) );\n\n    vLightFront += directionalLightColor[ 0 ] * directionalLightWeighting;\n\n    gl_Position = projectionMatrix * mvPosition;\n}";
			},
			"./src/WebGL/shaders/lib/lambert/uniforms.ts"(e, t, n) {
				n.r(t), n.d(t, { uniforms: () => r });
				let r = {
					opacity: {
						type: "f",
						value: 1
					},
					fogColor: {
						type: "c",
						value: new (n("./src/colors.ts")).Color(1, 1, 1)
					},
					fogNear: {
						type: "f",
						value: 1
					},
					fogFar: {
						type: "f",
						value: 2e3
					},
					directionalLightColor: {
						type: "fv",
						value: []
					},
					directionalLightDirection: {
						type: "fv",
						value: []
					}
				};
			},
			"./src/WebGL/shaders/lib/lambertdouble/index.ts"(e, t, n) {
				n.r(t), n.d(t, { lambertdouble: () => o });
				var r = n("./src/WebGL/shaders/lib/lambertdouble/uniforms.ts"), i = n("./src/WebGL/shaders/lib/lambertdouble/lambertdouble.frag"), a = n("./src/WebGL/shaders/lib/lambertdouble/lambertdouble.vert");
				let o = {
					fragmentShader: i.default.replace("#define GLSLIFY 1", ""),
					vertexShader: a.default.replace("#define GLSLIFY 1", ""),
					uniforms: r.uniforms
				};
			},
			"./src/WebGL/shaders/lib/lambertdouble/lambertdouble.frag"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "\n#ifdef SHADED\nuniform highp sampler2D shading;\n#endif\n\nuniform mat4 viewMatrix;\nuniform float opacity;\n\nuniform vec3 fogColor;\nuniform float fogNear;\nuniform float fogFar;\n\nvarying vec3 vLightFront;\nvarying vec3 vLightBack;\n\nvarying vec3 vColor;\nvarying vec4 mvPosition;\n\n//DEFINEFRAGCOLOR\n\nvoid main() {\n\n    gl_FragColor = vec4( vec3 ( 1.0 ), opacity );\n\n    #ifndef WIREFRAME\n    if ( gl_FrontFacing )\n       gl_FragColor.xyz *= vLightFront;\n    else\n       gl_FragColor.xyz *= vLightBack;\n    #endif\n\n    vec3 color = vColor;\n#ifdef SHADED\n    ivec2 dim = textureSize(shading,0);\n    float shadowFactor = texture2D(shading,vec2(gl_FragCoord.x/float(dim.x),gl_FragCoord.y/float(dim.y))).r;\n    color *= shadowFactor;\n#endif\n    gl_FragColor = gl_FragColor * vec4( color, opacity );\n\n    if(fogNear != fogFar) {\n        float depth = -mvPosition.z;\n        float fogFactor = smoothstep( fogNear, fogFar, depth );\n        gl_FragColor = mix( gl_FragColor, vec4( fogColor, gl_FragColor.w ), fogFactor );\n    }\n\n}\n\n\n";
			},
			"./src/WebGL/shaders/lib/lambertdouble/lambertdouble.vert"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "\n\nuniform mat4 modelViewMatrix;\nuniform mat4 projectionMatrix;\nuniform mat4 viewMatrix;\nuniform mat3 normalMatrix;\nuniform vec3 directionalLightColor[ 1 ];\nuniform vec3 directionalLightDirection[ 1 ];\n\nattribute vec3 position;\nattribute vec3 normal;\nattribute vec3 color;\n\nvarying vec3 vColor;\nvarying vec3 vLightFront;\nvarying vec3 vLightBack;\nvarying vec4 mvPosition;\n\nvoid main() {\n\n    vColor = color;\n\n    vec3 objectNormal = normal;\n    vec3 transformedNormal = normalMatrix * objectNormal;\n    mvPosition = modelViewMatrix * vec4( position, 1.0 );\n\n    vLightFront = vec3( 0.0 );\n    vLightBack = vec3( 0.0 );\n\n    transformedNormal = normalize( transformedNormal );\n\n    vec4 lDirection = viewMatrix * vec4( directionalLightDirection[ 0 ], 0.0 );\n    vec3 dirVector = normalize( lDirection.xyz );\n    float dotProduct = dot( transformedNormal, dirVector );\n    vec3 directionalLightWeighting = vec3( max( dotProduct, 0.0 ) );\n    vec3 directionalLightWeightingBack = vec3( max( -dotProduct, 0.0 ) );\n\n    vLightFront += directionalLightColor[ 0 ] * directionalLightWeighting;\n    vLightBack += directionalLightColor[ 0 ] * directionalLightWeightingBack;\n\n    gl_Position = projectionMatrix * mvPosition;\n}\n\n";
			},
			"./src/WebGL/shaders/lib/lambertdouble/uniforms.ts"(e, t, n) {
				n.r(t), n.d(t, { uniforms: () => r });
				let r = {
					opacity: {
						type: "f",
						value: 1
					},
					fogColor: {
						type: "c",
						value: new (n("./src/colors.ts")).Color(1, 1, 1)
					},
					fogNear: {
						type: "f",
						value: 1
					},
					fogFar: {
						type: "f",
						value: 2e3
					},
					directionalLightColor: {
						type: "fv",
						value: []
					},
					directionalLightDirection: {
						type: "fv",
						value: []
					}
				};
			},
			"./src/WebGL/shaders/lib/outline/index.ts"(e, t, n) {
				n.r(t), n.d(t, { outline: () => o });
				var r = n("./src/WebGL/shaders/lib/outline/uniforms.ts"), i = n("./src/WebGL/shaders/lib/outline/outline.frag"), a = n("./src/WebGL/shaders/lib/outline/outline.vert");
				let o = {
					fragmentShader: i.default.replace("#define GLSLIFY 1", ""),
					vertexShader: a.default.replace("#define GLSLIFY 1", ""),
					uniforms: r.uniforms
				};
			},
			"./src/WebGL/shaders/lib/outline/outline.frag"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "\n\nuniform float opacity;\nuniform vec3 outlineColor;\nuniform vec3 fogColor;\nuniform float fogNear;\nuniform float fogFar;\n\nvarying vec4 mvPosition;\n//DEFINEFRAGCOLOR\n\nvoid main() {\n    gl_FragColor = vec4( outlineColor, 1 );\n\n    if(fogNear != fogFar) {\n        float depth = -mvPosition.z;\n        float fogFactor = smoothstep( fogNear, fogFar, depth );\n        gl_FragColor = mix( gl_FragColor, vec4( fogColor, gl_FragColor.w ), fogFactor );\n    }\n}\n\n\n";
			},
			"./src/WebGL/shaders/lib/outline/outline.vert"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "\n\nuniform mat4 modelViewMatrix;\nuniform mat4 projectionMatrix;\nuniform float outlineWidth;\nuniform float outlinePushback;\nuniform float vWidth;\nuniform float vHeight;\nuniform float outlineMaxPixels;\n\nattribute vec3 position;\nattribute vec3 normal;\nattribute vec3 color;\n\nvarying vec4 mvPosition;\n\nvoid main() {\n\n    vec4 norm = modelViewMatrix*vec4(normalize(normal),0.0);\n    mvPosition = modelViewMatrix * vec4( position, 1.0 );\n    mvPosition.xy += norm.xy*outlineWidth;\n    vec4 outpos = projectionMatrix * mvPosition;\n\n    if(outlineMaxPixels > 0.0) {\n        vec4 unadjusted = projectionMatrix*modelViewMatrix * vec4( position, 1.0 );\n        float w = outpos.w;\n        //normalize homogeneous coords\n        unadjusted /= unadjusted.w;\n        outpos /= outpos.w;\n        vec2 diff = outpos.xy-unadjusted.xy;\n        //put into pixels\n        diff.x *= vWidth;\n        diff.y *= vHeight;\n        if ( length(diff) > outlineMaxPixels) {\n            vec2 ndiff = normalize(diff)*outlineMaxPixels;\n            ndiff.x /= vWidth;\n            ndiff.y /= vHeight;\n            outpos.xy = unadjusted.xy;\n            outpos.xy += ndiff;\n        }\n        outpos *= w; //if I don't do this things blow up\n    }\n    gl_Position = outpos;\n    mvPosition.z -= outlinePushback; //go backwards in model space\n    vec4 pushpos = projectionMatrix*mvPosition; //project to get z in projection space, I'm probably missing some simple math to do the same thing..\n    gl_Position.z = gl_Position.w*pushpos.z/pushpos.w;\n}\n\n";
			},
			"./src/WebGL/shaders/lib/outline/uniforms.ts"(e, t, n) {
				n.r(t), n.d(t, { uniforms: () => i });
				var r = n("./src/colors.ts");
				let i = {
					opacity: {
						type: "f",
						value: 1
					},
					outlineColor: {
						type: "c",
						value: new r.Color(0, 0, 0)
					},
					fogColor: {
						type: "c",
						value: new r.Color(1, 1, 1)
					},
					fogNear: {
						type: "f",
						value: 1
					},
					fogFar: {
						type: "f",
						value: 2e3
					},
					outlineWidth: {
						type: "f",
						value: .1
					},
					outlinePushback: {
						type: "f",
						value: 1
					},
					outlineMaxPixels: {
						type: "f",
						value: 0
					}
				};
			},
			"./src/WebGL/shaders/lib/ringimposter/index.ts"(e, t, n) {
				n.r(t), n.d(t, { ringimposter: () => a });
				var r = n("./src/WebGL/shaders/lib/ringimposter/uniforms.ts"), i = n("./src/WebGL/shaders/lib/ringimposter/ringimposter.frag");
				let a = {
					vertexShader: n("./src/WebGL/shaders/lib/ringimposter/ringimposter.vert").default.replace("#define GLSLIFY 1", ""),
					fragmentShader: i.default.replace("#define GLSLIFY 1", ""),
					uniforms: r.uniforms
				};
			},
			"./src/WebGL/shaders/lib/ringimposter/ringimposter.frag"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "\nuniform float opacity;\nuniform mat4 projectionMatrix;\n\nuniform vec3 fogColor;\nuniform float fogNear;\nuniform float fogFar;\n\nvarying vec3 vColor;\nvarying vec2 mapping;\nvarying float vOuterR;\nvarying float vMinorR;\nvarying vec3 vLight;\nvarying vec3 center;\nvarying vec3 vRingNormal;\n\n//DEFINEFRAGCOLOR\n\nvoid main() {\n    float majorR = vOuterR - vMinorR;\n\n    // The fragment represents a view ray at screen position (center.xy + mapping).\n    // Intersect this ray with the ring plane to find the in-plane distance.\n    // Ring plane: dot(P - center, vRingNormal) = 0\n    // Ray: P = (center.x + mapping.x, center.y + mapping.y, center.z + t)\n    // Solution: mapping.x*nx + mapping.y*ny + t*nz = 0  =>  t = -a/nz\n    float a = mapping.x * vRingNormal.x + mapping.y * vRingNormal.y;\n    float nz = vRingNormal.z;\n\n    // Clamp |nz| to avoid singularity for edge-on rings\n    float nzSafe = nz;\n    if (abs(nzSafe) < 0.01) nzSafe = (nzSafe >= 0.0) ? 0.01 : -0.01;\n    float zHit = -a / nzSafe;\n\n    // In-ring-plane distance from center\n    // hitPoint = (mapping.x, mapping.y, zHit) is in the ring plane by construction\n    float dFromCenterSq = mapping.x * mapping.x + mapping.y * mapping.y + zHit * zHit;\n    float dFromCenter = sqrt(dFromCenterSq);\n\n    // Distance from ring centerline (in ring plane)\n    float dRadial = dFromCenter - majorR;\n\n    // Tube test\n    if (dRadial * dRadial > vMinorR * vMinorR)\n        discard;\n\n    // Tube cross-section height\n    float tubeZ = sqrt(max(0.0, vMinorR * vMinorR - dRadial * dRadial));\n\n    // Always render the front surface (closest to camera).\n    // The tube extends ±tubeZ along vRingNormal from the ring plane.\n    // When vRingNormal.z > 0, +tubeZ is toward camera; when < 0, -tubeZ is.\n    float tubeSign = (vRingNormal.z >= 0.0) ? 1.0 : -1.0;\n\n    // Direction from center to the ring-plane hit point (normalized)\n    vec3 hitPoint = vec3(mapping.x, mapping.y, zHit);\n    vec3 radDir = (dFromCenter > 0.0001) ? hitPoint / dFromCenter : vec3(1.0, 0.0, 0.0);\n\n    // Surface normal: radial component + tube bulge toward viewer\n    vec3 norm = normalize(dRadial * radDir + tubeSign * tubeZ * vRingNormal);\n\n    // Surface position: ring-plane intersection + tube bulge toward viewer\n    vec3 surfacePos = center + hitPoint + tubeSign * tubeZ * vRingNormal;\n\n    vec4 clipPos = projectionMatrix * vec4(surfacePos, 1.0);\n    float ndcDepth = clipPos.z / clipPos.w;\n    gl_FragDepthEXT = ((gl_DepthRange.diff * ndcDepth) + gl_DepthRange.near + gl_DepthRange.far) / 2.0;\n\n    float dotProduct = dot( norm, vLight );\n    vec3 directionalLightWeighting = vec3( max( dotProduct, 0.0 ) );\n    vec3 vLightResult = directionalLightWeighting;\n    vec3 color = vLightResult * vColor;\n    gl_FragColor = vec4(color, opacity * opacity);\n\n    if(fogNear != fogFar) {\n        float depth = -surfacePos.z;\n        float fogFactor = smoothstep( fogNear, fogFar, depth );\n        gl_FragColor = mix( gl_FragColor, vec4( fogColor, gl_FragColor.w ), fogFactor );\n    }\n\n}\n";
			},
			"./src/WebGL/shaders/lib/ringimposter/ringimposter.vert"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "uniform mat4 modelViewMatrix;\nuniform mat4 projectionMatrix;\nuniform mat4 viewMatrix;\nuniform mat3 normalMatrix;\nuniform vec3 directionalLightColor[ 1 ];\nuniform vec3 directionalLightDirection[ 1 ];\n\nattribute vec3 position;\nattribute vec3 normal;\nattribute vec3 color;\nattribute float radius;\n\nvarying vec2 mapping;\nvarying vec3 vColor;\nvarying float vOuterR;\nvarying float vMinorR;\nvarying vec3 vLight;\nvarying vec3 center;\nvarying vec3 vRingNormal;\n\nvoid main() {\n\n    // Decode: normal direction = ring plane normal, length = minorR\n    vMinorR = length(normal);\n    vec3 ringNormalObj = normal / max(vMinorR, 0.0001);\n\n    // Decode: |radius| = outerR, sign(radius) = X billboard corner\n    vOuterR = abs(radius);\n    float xSign = sign(radius);\n\n    // Decode: sign(color.b) = Y billboard corner, actual color = (r, g, |b|)\n    float ySign = sign(color.b);\n    vColor = vec3(color.r, color.g, abs(color.b));\n\n    // Transform ring center to view space\n    vec4 mvPosition = modelViewMatrix * vec4( position, 1.0 );\n    center = mvPosition.xyz;\n\n    // Transform ring normal to view space\n    vRingNormal = normalize( normalMatrix * ringNormalObj );\n\n    // Billboard expansion\n    mapping = vec2(xSign * vOuterR, ySign * vOuterR);\n    vec4 projPosition = projectionMatrix * mvPosition;\n    vec4 adjust = projectionMatrix * vec4(mapping, 0.0, 0.0);\n    adjust.z = 0.0; adjust.w = 0.0;\n\n    vec4 lDirection = viewMatrix * vec4( directionalLightDirection[ 0 ], 0.0 );\n    vLight = normalize( lDirection.xyz );\n    gl_Position = projPosition + adjust;\n\n}\n";
			},
			"./src/WebGL/shaders/lib/ringimposter/uniforms.ts"(e, t, n) {
				n.r(t), n.d(t, { uniforms: () => r });
				let r = {
					opacity: {
						type: "f",
						value: 1
					},
					fogColor: {
						type: "c",
						value: new (n("./src/colors.ts")).Color(1, 1, 1)
					},
					fogNear: {
						type: "f",
						value: 1
					},
					fogFar: {
						type: "f",
						value: 2e3
					},
					directionalLightColor: {
						type: "fv",
						value: []
					},
					directionalLightDirection: {
						type: "fv",
						value: []
					}
				};
			},
			"./src/WebGL/shaders/lib/screen/index.ts"(e, t, n) {
				n.r(t), n.d(t, { screen: () => o });
				var r = n("./src/WebGL/shaders/lib/screen/uniforms.ts"), i = n("./src/WebGL/shaders/lib/screen/screen.frag"), a = n("./src/WebGL/shaders/lib/screen/screen.vert");
				let o = {
					fragmentShader: i.default.replace("#define GLSLIFY 1", ""),
					vertexShader: a.default.replace("#define GLSLIFY 1", ""),
					uniforms: r.uniforms
				};
			},
			"./src/WebGL/shaders/lib/screen/screen.frag"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "uniform sampler2D colormap;\nvarying highp vec2 vTexCoords;\nuniform vec2 dimensions;\n//DEFINEFRAGCOLOR\nvoid main (void) {\n   gl_FragColor = texture2D(colormap, vTexCoords);\n\n   //gl_FragColor.g = gl_FragColor.b =  gl_FragColor.r; //debug shading \n}\n        ";
			},
			"./src/WebGL/shaders/lib/screen/screen.vert"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "attribute vec2 vertexPosition;\nvarying highp vec2 vTexCoords;\nconst vec2 scale = vec2(0.5, 0.5);\n\nvoid main() {\n   vTexCoords  = vertexPosition * scale + scale; // scale vertex attribute to [0,1] range\n   gl_Position = vec4(vertexPosition, 0.0, 1.0);\n}\n        ";
			},
			"./src/WebGL/shaders/lib/screen/uniforms.ts"(e, t, n) {
				n.r(t), n.d(t, { uniforms: () => r });
				let r = {};
			},
			"./src/WebGL/shaders/lib/screenaa/index.ts"(e, t, n) {
				n.r(t), n.d(t, { screenaa: () => o });
				var r = n("./src/WebGL/shaders/lib/screenaa/uniforms.ts"), i = n("./src/WebGL/shaders/lib/screenaa/screenaa.frag"), a = n("./src/WebGL/shaders/lib/screenaa/screenaa.vert");
				let o = {
					fragmentShader: i.default.replace("#define GLSLIFY 1", ""),
					vertexShader: a.default.replace("#define GLSLIFY 1", ""),
					uniforms: r.uniforms
				};
			},
			"./src/WebGL/shaders/lib/screenaa/screenaa.frag"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "\n        \nprecision highp float;\nprecision highp int;\nprecision highp sampler2D;\n\nuniform sampler2D tColor;\nvarying highp vec2 vTexCoords;\n\n// adapted from https://github.com/kosua20/Rendu\n// MIT License Copyright (c) 2017 Simon Rodriguez\n// by way of molstar (https://github.com/molstar/molstar/blob/master/src/mol-gl/shader/fxaa.frag.ts)\n\n#define QUALITY(q) ((q) < 5 ? 1.0 : ((q) > 5 ? ((q) < 10 ? 2.0 : ((q) < 11 ? 4.0 : 8.0)) : 1.5))\n\nfloat rgb2luma(vec3 rgb){\n    return sqrt(dot(rgb, vec3(0.299, 0.587, 0.114)));\n}\n\nfloat sampleLuma(vec2 uv) {\n    return rgb2luma(texture2D(tColor, uv).rgb);\n}\n\nfloat sampleLuma(vec2 uv, float uOffset, float vOffset) {\n    uv += vec2(uOffset, vOffset);\n    return sampleLuma(uv);\n}\n\n//DEFINEFRAGCOLOR\nvoid main(void) {\n    ivec2 dim = textureSize(tColor,0);\n    vec2 dimensions = vec2(float(dim.x),float(dim.y));\n    vec2 inverseScreenSize = vec2(1.0 / dimensions.x, 1.0 / dimensions.y);\n    vec2 coords = vTexCoords;\n\n    vec4 colorCenter = texture2D(tColor, coords);\n    float dEdgeThresholdMin = 0.0312;\n    float dEdgeThresholdMax = 0.125;\n    int dIterations = 12;\n    float dSubpixelQuality = 0.3;\n\n    // Luma at the current fragment\n    float lumaCenter = rgb2luma(colorCenter.rgb);\n\n    // Luma at the four direct neighbours of the current fragment.\n    float lumaDown = sampleLuma(coords, 0.0, -inverseScreenSize.y);\n    float lumaUp = sampleLuma(coords, 0.0, inverseScreenSize.y);\n    float lumaLeft = sampleLuma(coords, -inverseScreenSize.x, 0.0);\n    float lumaRight = sampleLuma(coords, inverseScreenSize.x, 0.0);\n\n    // Find the maximum and minimum luma around the current fragment.\n    float lumaMin = min(lumaCenter, min(min(lumaDown, lumaUp), min(lumaLeft, lumaRight)));\n    float lumaMax = max(lumaCenter, max(max(lumaDown, lumaUp), max(lumaLeft, lumaRight)));\n\n    // Compute the delta.\n    float lumaRange = lumaMax - lumaMin;\n\n    // If the luma variation is lower that a threshold (or if we are in a really dark area),\n    // we are not on an edge, don't perform any AA.\n    if (lumaRange < max(dEdgeThresholdMin, lumaMax * dEdgeThresholdMax)) {\n        gl_FragColor = colorCenter;\n        return;\n    }\n\n    // Query the 4 remaining corners lumas.\n    float lumaDownLeft = sampleLuma(coords, -inverseScreenSize.x, -inverseScreenSize.y);\n    float lumaUpRight = sampleLuma(coords, inverseScreenSize.x, inverseScreenSize.y);\n    float lumaUpLeft = sampleLuma(coords, -inverseScreenSize.x, inverseScreenSize.y);\n    float lumaDownRight = sampleLuma(coords, inverseScreenSize.x, -inverseScreenSize.y);\n\n    // Combine the four edges lumas (using intermediary variables for future computations\n    // with the same values).\n    float lumaDownUp = lumaDown + lumaUp;\n    float lumaLeftRight = lumaLeft + lumaRight;\n\n    // Same for corners\n    float lumaLeftCorners = lumaDownLeft + lumaUpLeft;\n    float lumaDownCorners = lumaDownLeft + lumaDownRight;\n    float lumaRightCorners = lumaDownRight + lumaUpRight;\n    float lumaUpCorners = lumaUpRight + lumaUpLeft;\n\n    // Compute an estimation of the gradient along the horizontal and vertical axis.\n    float edgeHorizontal = abs(-2.0 * lumaLeft + lumaLeftCorners) + abs(-2.0 * lumaCenter + lumaDownUp) * 2.0 + abs(-2.0 * lumaRight + lumaRightCorners);\n    float edgeVertical = abs(-2.0 * lumaUp + lumaUpCorners) + abs(-2.0 * lumaCenter + lumaLeftRight) * 2.0 + abs(-2.0 * lumaDown + lumaDownCorners);\n\n    // Is the local edge horizontal or vertical ?\n    bool isHorizontal = (edgeHorizontal >= edgeVertical);\n\n    // Choose the step size (one pixel) accordingly.\n    float stepLength = isHorizontal ? inverseScreenSize.y : inverseScreenSize.x;\n\n    // Select the two neighboring texels lumas in the opposite direction to the local edge.\n    float luma1 = isHorizontal ? lumaDown : lumaLeft;\n    float luma2 = isHorizontal ? lumaUp : lumaRight;\n    // Compute gradients in this direction.\n    float gradient1 = luma1 - lumaCenter;\n    float gradient2 = luma2 - lumaCenter;\n\n    // Which direction is the steepest ?\n    bool is1Steepest = abs(gradient1) >= abs(gradient2);\n\n    // Gradient in the corresponding direction, normalized.\n    float gradientScaled = 0.25 * max(abs(gradient1), abs(gradient2));\n\n    // Average luma in the correct direction.\n    float lumaLocalAverage = 0.0;\n    if(is1Steepest){\n        // Switch the direction\n        stepLength = -stepLength;\n        lumaLocalAverage = 0.5 * (luma1 + lumaCenter);\n    } else {\n        lumaLocalAverage = 0.5 * (luma2 + lumaCenter);\n    }\n\n    // Shift UV in the correct direction by half a pixel.\n    vec2 currentUv = coords;\n    if(isHorizontal){\n        currentUv.y += stepLength * 0.5;\n    } else {\n        currentUv.x += stepLength * 0.5;\n    }\n\n    // Compute offset (for each iteration step) in the right direction.\n    vec2 offset = isHorizontal ? vec2(inverseScreenSize.x, 0.0) : vec2(0.0, inverseScreenSize.y);\n    // Compute UVs to explore on each side of the edge, orthogonally.\n    // The QUALITY allows us to step faster.\n    vec2 uv1 = currentUv - offset * QUALITY(0);\n    vec2 uv2 = currentUv + offset * QUALITY(0);\n\n    // Read the lumas at both current extremities of the exploration segment,\n    // and compute the delta wrt to the local average luma.\n    float lumaEnd1 = sampleLuma(uv1);\n    float lumaEnd2 = sampleLuma(uv2);\n    lumaEnd1 -= lumaLocalAverage;\n    lumaEnd2 -= lumaLocalAverage;\n\n    // If the luma deltas at the current extremities is larger than the local gradient,\n    // we have reached the side of the edge.\n    bool reached1 = abs(lumaEnd1) >= gradientScaled;\n    bool reached2 = abs(lumaEnd2) >= gradientScaled;\n    bool reachedBoth = reached1 && reached2;\n\n    // If the side is not reached, we continue to explore in this direction.\n    if(!reached1){\n        uv1 -= offset * QUALITY(1);\n    }\n    if(!reached2){\n        uv2 += offset * QUALITY(1);\n    }\n\n    // If both sides have not been reached, continue to explore.\n    if(!reachedBoth){\n        for(int i = 2; i < dIterations; i++){\n            // If needed, read luma in 1st direction, compute delta.\n            if(!reached1){\n                lumaEnd1 = sampleLuma(uv1);\n                lumaEnd1 = lumaEnd1 - lumaLocalAverage;\n            }\n            // If needed, read luma in opposite direction, compute delta.\n            if(!reached2){\n                lumaEnd2 = sampleLuma(uv2);\n                lumaEnd2 = lumaEnd2 - lumaLocalAverage;\n            }\n            // If the luma deltas at the current extremities is larger than the local gradient,\n            // we have reached the side of the edge.\n            reached1 = abs(lumaEnd1) >= gradientScaled;\n            reached2 = abs(lumaEnd2) >= gradientScaled;\n            reachedBoth = reached1 && reached2;\n\n            // If the side is not reached, we continue to explore in this direction,\n            // with a variable quality.\n            if(!reached1){\n                uv1 -= offset * QUALITY(i);\n            }\n            if(!reached2){\n                uv2 += offset * QUALITY(i);\n            }\n\n            // If both sides have been reached, stop the exploration.\n            if(reachedBoth){\n                break;\n            }\n        }\n    }\n\n    // Compute the distances to each side edge of the edge (!).\n    float distance1 = isHorizontal ? (coords.x - uv1.x) : (coords.y - uv1.y);\n    float distance2 = isHorizontal ? (uv2.x - coords.x) : (uv2.y - coords.y);\n\n    // In which direction is the side of the edge closer ?\n    bool isDirection1 = distance1 < distance2;\n    float distanceFinal = min(distance1, distance2);\n\n    // Thickness of the edge.\n    float edgeThickness = (distance1 + distance2);\n\n    // Is the luma at center smaller than the local average ?\n    bool isLumaCenterSmaller = lumaCenter < lumaLocalAverage;\n\n    // If the luma at center is smaller than at its neighbour,\n    // the delta luma at each end should be positive (same variation).\n    bool correctVariation1 = (lumaEnd1 < 0.0) != isLumaCenterSmaller;\n    bool correctVariation2 = (lumaEnd2 < 0.0) != isLumaCenterSmaller;\n\n    // Only keep the result in the direction of the closer side of the edge.\n    bool correctVariation = isDirection1 ? correctVariation1 : correctVariation2;\n\n    // UV offset: read in the direction of the closest side of the edge.\n    float pixelOffset = - distanceFinal / edgeThickness + 0.5;\n\n    // If the luma variation is incorrect, do not offset.\n    float finalOffset = correctVariation ? pixelOffset : 0.0;\n\n    // Sub-pixel shifting\n    // Full weighted average of the luma over the 3x3 neighborhood.\n    float lumaAverage = (1.0 / 12.0) * (2.0 * (lumaDownUp + lumaLeftRight) + lumaLeftCorners + lumaRightCorners);\n    // Ratio of the delta between the global average and the center luma,\n    // over the luma range in the 3x3 neighborhood.\n    float subPixelOffset1 = clamp(abs(lumaAverage - lumaCenter) / lumaRange, 0.0, 1.0);\n    float subPixelOffset2 = (-2.0 * subPixelOffset1 + 3.0) * subPixelOffset1 * subPixelOffset1;\n    // Compute a sub-pixel offset based on this delta.\n    float subPixelOffsetFinal = subPixelOffset2 * subPixelOffset2 * float(dSubpixelQuality);\n\n    // Pick the biggest of the two offsets.\n    finalOffset = max(finalOffset, subPixelOffsetFinal);\n\n    // Compute the final UV coordinates.\n    vec2 finalUv = coords;\n    if(isHorizontal){\n        finalUv.y += finalOffset * stepLength;\n    } else {\n        finalUv.x += finalOffset * stepLength;\n    }\n\n    // Read the color at the new UV coordinates, and use it.\n    gl_FragColor = texture2D(tColor, finalUv);\n}        \n\n/* old fxaa implementation\nuniform highp sampler2D colormap;\nvarying highp vec2 vTexCoords;\n\n\n// Basic FXAA implementation based on the code on geeks3d.com \n#define FXAA_REDUCE_MIN (1.0/ 128.0)\n#define FXAA_REDUCE_MUL (1.0 / 8.0)\n#define FXAA_SPAN_MAX 8.0\n\n\nvec4 applyFXAA(vec2 fragCoord, highp sampler2D tex)\n{\n    vec4 color;\n    ivec2 dim = textureSize(tex,0);\n    vec2 dimensions = vec2(float(dim.x),float(dim.y));\n    vec2 inverseVP = vec2(1.0 / dimensions.x, 1.0 / dimensions.y);\n    vec4 rgbNW = texture2D(tex, fragCoord + vec2(-1.0, -1.0) * inverseVP);\n    vec4 rgbNE = texture2D(tex, fragCoord + vec2(1.0, -1.0) * inverseVP);\n    vec4 rgbSW = texture2D(tex, fragCoord + vec2(-1.0, 1.0) * inverseVP);\n    vec4 rgbSE = texture2D(tex, fragCoord + vec2(1.0, 1.0) * inverseVP);\n    vec4 rgbM  = texture2D(tex, fragCoord );\n    vec3 luma = vec3(0.299, 0.587, 0.114);\n    float lumaNW = dot(rgbNW.xyz, luma);\n    float lumaNE = dot(rgbNE.xyz, luma);\n    float lumaSW = dot(rgbSW.xyz, luma);\n    float lumaSE = dot(rgbSE.xyz, luma);\n    float lumaM  = dot(rgbM.xyz,  luma);\n    float lumaMin = min(lumaM, min(min(lumaNW, lumaNE), min(lumaSW, lumaSE)));\n    float lumaMax = max(lumaM, max(max(lumaNW, lumaNE), max(lumaSW, lumaSE)));\n\n    vec2 dir;\n    dir.x = -((lumaNW + lumaNE) - (lumaSW + lumaSE));\n    dir.y =  ((lumaNW + lumaSW) - (lumaNE + lumaSE));\n\n    float dirReduce = max((lumaNW + lumaNE + lumaSW + lumaSE) *\n                        (0.25 * FXAA_REDUCE_MUL), FXAA_REDUCE_MIN);\n\n    float rcpDirMin = 1.0 / (min(abs(dir.x), abs(dir.y)) + dirReduce);\n    dir = min(vec2(FXAA_SPAN_MAX, FXAA_SPAN_MAX),\n            max(vec2(-FXAA_SPAN_MAX, -FXAA_SPAN_MAX),\n            dir * rcpDirMin)) * inverseVP;\n\n    vec4 rgbA = 0.5 * (\n        texture2D(tex, fragCoord + dir * (1.0 / 3.0 - 0.5)) +\n        texture2D(tex, fragCoord  + dir * (2.0 / 3.0 - 0.5)));\n    vec4 rgbB = rgbA * 0.5 + 0.25 * (\n        texture2D(tex, fragCoord  + dir * -0.5) +\n        texture2D(tex, fragCoord  + dir * 0.5));\n\n    float lumaB = dot(rgbB.xyz, luma);\n    if ((lumaB < lumaMin) || (lumaB > lumaMax))\n        color = rgbA;\n    else\n        color = rgbB;\n\n    return color;\n}\n\n\n//DEFINEFRAGCOLOR\nvoid main (void) {\n    ivec2 dim = textureSize(colormap,0);\n\n  gl_FragColor = applyFXAA(vTexCoords, colormap);\n}\n        \n*/";
			},
			"./src/WebGL/shaders/lib/screenaa/screenaa.vert"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "attribute vec2 vertexPosition;\nvarying highp vec2 vTexCoords;\nconst vec2 scale = vec2(0.5, 0.5);\n\nvoid main() {\n   vTexCoords  = vertexPosition * scale + scale; // scale vertex attribute to [0,1] range\n   gl_Position = vec4(vertexPosition, 0.0, 1.0);\n}\n        ";
			},
			"./src/WebGL/shaders/lib/screenaa/uniforms.ts"(e, t, n) {
				n.r(t), n.d(t, { uniforms: () => r });
				let r = {};
			},
			"./src/WebGL/shaders/lib/sphereimposter/index.ts"(e, t, n) {
				n.r(t), n.d(t, { sphereimposter: () => a });
				var r = n("./src/WebGL/shaders/lib/sphereimposter/uniforms.ts"), i = n("./src/WebGL/shaders/lib/sphereimposter/sphereimposter.frag");
				let a = {
					vertexShader: n("./src/WebGL/shaders/lib/sphereimposter/sphereimposter.vert").default.replace("#define GLSLIFY 1", ""),
					fragmentShader: i.default.replace("#define GLSLIFY 1", ""),
					uniforms: r.uniforms
				};
			},
			"./src/WebGL/shaders/lib/sphereimposter/sphereimposter.frag"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "\nuniform mat4 viewMatrix;\nuniform float opacity;\nuniform mat4 projectionMatrix;\n\nuniform vec3 fogColor;\nuniform float fogNear;\nuniform float fogFar;\nuniform float uDepth;\nuniform vec3 directionalLightColor[ 1 ];\n\nvarying vec3 vColor;\nvarying vec2 mapping;\nvarying float rval;\nvarying vec3 vLight;\nvarying vec3 center;\n\n#ifdef SHADED\nuniform highp sampler2D shading;\n#endif\n\n//DEFINEFRAGCOLOR\n\nvoid main() {\n    float lensqr = dot(mapping,mapping);\n    float rsqr = rval*rval;\n    if(lensqr > rsqr)\n       discard;\n    float z = sqrt(rsqr-lensqr);\n    vec3 cameraPos = center+ vec3(mapping.x,mapping.y,z);\n    vec4 clipPos = projectionMatrix * vec4(cameraPos, 1.0);\n    float ndcDepth = clipPos.z / clipPos.w;\n    gl_FragDepthEXT = ((gl_DepthRange.diff * ndcDepth) + gl_DepthRange.near + gl_DepthRange.far) / 2.0;\n    vec3 norm = normalize(vec3(mapping.x,mapping.y,z));\n    float dotProduct = dot( norm, vLight );\n    vec3 directionalLightWeighting = vec3( max( dotProduct, 0.0 ) );\n    vec3 vLight = directionalLightColor[ 0 ] * directionalLightWeighting;\n    vec3 color = vLight*vColor;\n#ifdef SHADED\n    ivec2 dim = textureSize(shading,0);\n    float shadowFactor = texture2D(shading,vec2(gl_FragCoord.x/float(dim.x),gl_FragCoord.y/float(dim.y))).r;\n    color *= shadowFactor;\n#endif    \n    gl_FragColor = vec4(color, opacity*opacity );\n\n    if(fogNear != fogFar) {\n        float depth = -cameraPos.z;\n        float fogFactor = smoothstep( fogNear, fogFar, depth );\n        gl_FragColor = mix( gl_FragColor, vec4( fogColor, gl_FragColor.w ), fogFactor );\n    }\n     \n}\n\n";
			},
			"./src/WebGL/shaders/lib/sphereimposter/sphereimposter.vert"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "uniform mat4 modelViewMatrix;\nuniform mat4 projectionMatrix;\nuniform mat4 viewMatrix;\nuniform mat3 normalMatrix;\nuniform vec3 directionalLightColor[ 1 ];\nuniform vec3 directionalLightDirection[ 1 ];\n\nattribute vec3 position;\nattribute vec3 normal;\nattribute vec3 color;\n\nvarying vec2 mapping;\nvarying vec3 vColor;\nvarying float rval;\nvarying vec3 vLight;\nvarying vec3 center;\n\nvoid main() {\n\n    vColor = color;\n    vec4 mvPosition = modelViewMatrix * vec4( position, 1.0 );\n    center = mvPosition.xyz;\n    vec4 projPosition = projectionMatrix * mvPosition;\n    vec4 adjust = projectionMatrix* vec4(normal,0.0); adjust.z = 0.0; adjust.w = 0.0;\n    vec4 lDirection = viewMatrix * vec4( directionalLightDirection[ 0 ], 0.0 );\n    vLight = normalize( lDirection.xyz );\n    mapping = normal.xy;\n    rval = abs(normal.x);\n    gl_Position = projPosition+adjust;\n\n}\n";
			},
			"./src/WebGL/shaders/lib/sphereimposter/uniforms.ts"(e, t, n) {
				n.r(t), n.d(t, { uniforms: () => r });
				let r = {
					opacity: {
						type: "f",
						value: 1
					},
					fogColor: {
						type: "c",
						value: new (n("./src/colors.ts")).Color(1, 1, 1)
					},
					fogNear: {
						type: "f",
						value: 1
					},
					fogFar: {
						type: "f",
						value: 2e3
					},
					directionalLightColor: {
						type: "fv",
						value: []
					},
					directionalLightDirection: {
						type: "fv",
						value: []
					}
				};
			},
			"./src/WebGL/shaders/lib/sphereimposteroutline/index.ts"(e, t, n) {
				n.r(t), n.d(t, { sphereimposteroutline: () => o });
				var r = n("./src/WebGL/shaders/lib/sphereimposteroutline/uniforms.ts"), i = n("./src/WebGL/shaders/lib/sphereimposteroutline/sphereimposteroutline.frag"), a = n("./src/WebGL/shaders/lib/sphereimposteroutline/sphereimposteroutline.vert");
				let o = {
					fragmentShader: i.default.replace("#define GLSLIFY 1", ""),
					vertexShader: a.default.replace("#define GLSLIFY 1", ""),
					uniforms: r.uniforms
				};
			},
			"./src/WebGL/shaders/lib/sphereimposteroutline/sphereimposteroutline.frag"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "\n\nuniform float opacity;\nuniform vec3 outlineColor;\nuniform vec3 fogColor;\nuniform float fogNear;\nuniform float fogFar;\nuniform mat4 projectionMatrix;\nvarying vec2 mapping;\nvarying float rval;\nvarying vec3 center;\n\nuniform float outlinePushback;\n\n//DEFINEFRAGCOLOR\n\nvoid main() {\n    float lensqr = dot(mapping,mapping);\n    float rsqr = rval*rval;\n    if(lensqr > rsqr)\n       discard;\n    float z = sqrt(rsqr-lensqr);\n    vec3 cameraPos = center+ vec3(mapping.x,mapping.y,z-outlinePushback);\n    vec4 clipPos = projectionMatrix * vec4(cameraPos, 1.0);\n    float ndcDepth = clipPos.z / clipPos.w;\n    gl_FragDepthEXT = ((gl_DepthRange.diff * ndcDepth) + gl_DepthRange.near + gl_DepthRange.far) / 2.0;\n    gl_FragColor = vec4(outlineColor, 1 );\n\n    if(fogNear != fogFar) {\n        float depth = -cameraPos.z;\n        float fogFactor = smoothstep( fogNear, fogFar, depth );\n        gl_FragColor = mix( gl_FragColor, vec4( fogColor, gl_FragColor.w ), fogFactor );\n    }\n}\n\n\n";
			},
			"./src/WebGL/shaders/lib/sphereimposteroutline/sphereimposteroutline.vert"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "\n\nuniform mat4 modelViewMatrix;\nuniform mat4 projectionMatrix;\nuniform float outlineWidth;\nuniform float outlinePushback;\nuniform float outlineMaxPixels;\nuniform float vWidth;\nuniform float vHeight;\n\nattribute vec3 position;\nattribute vec3 normal;\nattribute vec3 color;\n\nvarying vec2 mapping;\nvarying float rval;\nvarying vec3 center;\n\nvoid main() {\n\n    vec4 mvPosition = modelViewMatrix * vec4( position, 1.0 );\n    center = mvPosition.xyz;\n    vec4 projPosition = projectionMatrix * mvPosition;\n    vec2 norm = normal.xy + vec2(sign(normal.x)*outlineWidth,sign(normal.y)*outlineWidth);\n\n    vec4 adjust = projectionMatrix* vec4(norm,normal.z,1.0); \n    mapping = norm.xy;\n    rval = abs(norm.x);\n    gl_Position = projPosition+vec4(adjust.xy,0.0,0.0);\n\n    if(outlineMaxPixels > 0.0) {\n        vec4 unadjusted = projectionMatrix*vec4(center.x+normal.x, center.y,center.z,1.0); \n        vec4 ccoord = projectionMatrix*vec4(center.xyz,1.0);\n        adjust = projectionMatrix* vec4(center.x+norm.x,center.y,center.z,1.0); \n        //subtract center \n        unadjusted.xyz -= ccoord.xyz;\n        adjust.xyz -= ccoord.xyz;\n        unadjusted /= unadjusted.w;\n        adjust /= adjust.w;\n        float diff = abs(adjust.x-unadjusted.x);\n        diff *= vWidth;\n        if(diff > outlineMaxPixels) {\n            \n            float fixlen = abs(unadjusted.x) + outlineMaxPixels/vWidth;\n            //adjsut reval by ratio of lengths\n            rval *= fixlen/abs(adjust.x);\n        }\n\n    }\n}\n\n";
			},
			"./src/WebGL/shaders/lib/sphereimposteroutline/uniforms.ts"(e, t, n) {
				n.r(t), n.d(t, { uniforms: () => i });
				var r = n("./src/colors.ts");
				let i = {
					opacity: {
						type: "f",
						value: 1
					},
					outlineColor: {
						type: "c",
						value: new r.Color(0, 0, 0)
					},
					fogColor: {
						type: "c",
						value: new r.Color(1, 1, 1)
					},
					fogNear: {
						type: "f",
						value: 1
					},
					fogFar: {
						type: "f",
						value: 2e3
					},
					outlineWidth: {
						type: "f",
						value: .1
					},
					outlinePushback: {
						type: "f",
						value: 1
					},
					outlineMaxPixels: {
						type: "f",
						value: 0
					}
				};
			},
			"./src/WebGL/shaders/lib/sprite/index.ts"(e, t, n) {
				n.r(t), n.d(t, { sprite: () => o });
				var r = n("./src/WebGL/shaders/lib/sprite/uniforms.ts"), i = n("./src/WebGL/shaders/lib/sprite/sprite.frag"), a = n("./src/WebGL/shaders/lib/sprite/sprite.vert");
				let o = {
					fragmentShader: i.default.replace("#define GLSLIFY 1", ""),
					vertexShader: a.default.replace("#define GLSLIFY 1", ""),
					uniforms: r.uniforms
				};
			},
			"./src/WebGL/shaders/lib/sprite/sprite.frag"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "\n\nuniform vec3 color;\nuniform sampler2D map;\nuniform float opacity;\n\nuniform vec3 fogColor;\nuniform float fogNear;\nuniform float fogFar;\nuniform float alphaTest;\n\nvarying vec2 vUV;\n//DEFINEFRAGCOLOR\n\nvoid main() {\n\n    vec4 texture = texture2D(map, vUV);\n\n    if (texture.a <= alphaTest) discard;\n\n    gl_FragColor = vec4(color * texture.xyz, texture.a * opacity);\n\n    if (fogNear != fogFar) {\n\n        float depth = gl_FragCoord.z / gl_FragCoord.w; //probably wrong\n        float fogFactor = smoothstep(fogNear, fogFar, depth);        \n        gl_FragColor = mix(gl_FragColor, vec4(fogColor, gl_FragColor.w), fogFactor);\n    }\n}\n\n";
			},
			"./src/WebGL/shaders/lib/sprite/sprite.vert"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "\n\nuniform int useScreenCoordinates;\nuniform vec3 screenPosition;\nuniform mat4 modelViewMatrix;\nuniform mat4 projectionMatrix;\nuniform float rotation;\nuniform vec2 scale;\nuniform vec2 alignment;\nuniform vec2 uvOffset;\nuniform vec2 uvScale;\n\nattribute vec2 position;\nattribute vec2 uv;\n\nvarying vec2 vUV;\n\nvoid main() {\n\n    vUV = uvOffset + uv * uvScale;\n\n    vec2 alignedPosition = position + alignment;\n\n    vec2 rotatedPosition;\n    rotatedPosition.x = ( cos(rotation) * alignedPosition.x - sin(rotation) * alignedPosition.y ) * scale.x;\n    rotatedPosition.y = ( sin(rotation) * alignedPosition.x + cos(rotation) * alignedPosition.y ) * scale.y;\n\n    vec4 finalPosition;\n\n    if(useScreenCoordinates != 0) {\n        finalPosition = vec4(screenPosition.xy + rotatedPosition, screenPosition.z, 1.0);\n    }\n\n    else {\n        finalPosition = projectionMatrix * modelViewMatrix * vec4(0.0, 0.0, 0.0, 1.0); finalPosition /= finalPosition.w;\n        finalPosition.xy += rotatedPosition; \n    }\n\n    gl_Position = finalPosition;\n\n}\n\n";
			},
			"./src/WebGL/shaders/lib/sprite/uniforms.ts"(e, t, n) {
				n.r(t), n.d(t, { uniforms: () => r });
				let r = {};
			},
			"./src/WebGL/shaders/lib/ssao/index.ts"(e, t, n) {
				n.r(t), n.d(t, { ssao: () => o });
				var r = n("./src/WebGL/shaders/lib/ssao/uniforms.ts"), i = n("./src/WebGL/shaders/lib/ssao/ssao.frag"), a = n("./src/WebGL/shaders/lib/ssao/ssao.vert");
				let o = {
					fragmentShader: i.default,
					vertexShader: a.default,
					uniforms: r.uniforms
				};
			},
			"./src/WebGL/shaders/lib/ssao/ssao.frag"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "uniform sampler2D depthmap;\nvarying highp vec2 vTexCoords;\nuniform float vWidth;\nuniform float vHeight;\nuniform float total_strength;\nuniform float radius;\nuniform mat4 projinv;\nuniform mat4 projectionMatrix;\n\n//code for pseudorandom vector from chatgpt\nfloat hash(vec3 p) {\n    p = fract(p * vec3(0.1031, 0.1030, 0.0973));\n    p += dot(p, p.yzx + 33.33);\n    return fract((p.x + p.y) * p.z);\n}\n\n// Generate a pseudorandom vec3 from a seed vec3\nvec3 pseudorandomVec3(vec3 seed) {\n    vec3 randomVec;\n    randomVec.x = hash(seed);\n    randomVec.y = hash(seed + vec3(1.0, 0.0, 17.1));\n    randomVec.z = hash(seed + vec3(0.0, 13.23, 0.0));\n    return randomVec;\n}\n\nvoid main(void)\n{   \n   const float base = 0.2;\n   const float area = 0.75;\n   const int cycles = 1;\n\n   const int samples = 64;\n   vec3 sample_sphere[64] = vec3[](\n      vec3(0.091258,-0.510164,0.000000),\n      vec3(-0.204347,-0.872967,0.187199),\n      vec3(0.009690,-0.263696,-0.110414),\n      vec3(0.175208,-0.563987,0.228527),\n      vec3(-0.001824,-0.003113,-0.000323),\n      vec3(0.411134,-0.719869,-0.261530),\n      vec3(-0.074272,-0.377368,0.276290),\n      vec3(-0.147773,-0.381587,-0.284529),\n      vec3(0.173317,-0.199635,0.063295),\n      vec3(-0.186452,-0.199460,0.076965),\n      vec3(0.143985,-0.308160,-0.307687),\n      vec3(0.053194,-0.148286,0.169589),\n      vec3(-0.547656,-0.486476,-0.317378),\n      vec3(0.020804,-0.015092,-0.004574),\n      vec3(-0.038006,-0.043165,0.054059),\n      vec3(-0.094795,-0.443908,-0.731525),\n      vec3(0.547552,-0.396466,0.461477),\n      vec3(-0.176886,-0.089989,0.007315),\n      vec3(0.074401,-0.048840,-0.074039),\n      vec3(-0.008240,-0.075697,0.178197),\n      vec3(-0.307880,-0.185053,-0.368943),\n      vec3(0.309520,-0.108483,0.041646),\n      vec3(-0.773478,-0.292946,0.538166),\n      vec3(0.184487,-0.231594,-0.820065),\n      vec3(0.207318,-0.100531,0.361797),\n      vec3(-0.173306,-0.037737,-0.055289),\n      vec3(0.548102,-0.105342,-0.253237),\n      vec3(-0.119342,-0.043907,0.285162),\n      vec3(-0.270247,-0.087861,-0.751357),\n      vec3(0.449312,-0.039777,0.236146),\n      vec3(-0.743773,-0.036095,0.196056),\n      vec3(0.148819,-0.004300,-0.231448),\n      vec3(0.008773,0.000809,0.051047),\n      vec3(-0.461467,0.027390,-0.357386),\n      vec3(0.169626,0.013338,-0.014053),\n      vec3(-0.043786,0.007095,0.047331),\n      vec3(0.004821,0.140371,-0.988260),\n      vec3(0.092402,0.023994,0.101860),\n      vec3(-0.295335,0.061530,-0.027372),\n      vec3(0.024903,0.007537,-0.018901),\n      vec3(-0.081463,0.125402,0.447794),\n      vec3(-0.397119,0.231805,-0.631062),\n      vec3(0.163853,0.059014,0.044905),\n      vec3(-0.495220,0.214357,0.254139),\n      vec3(0.306123,0.373687,-0.825715),\n      vec3(0.021665,0.026737,0.053220),\n      vec3(-0.208231,0.117129,-0.098685),\n      vec3(0.139749,0.080968,-0.043086),\n      vec3(-0.153599,0.182814,0.262090),\n      vec3(-0.159673,0.496777,-0.743568),\n      vec3(0.134797,0.117152,0.095753),\n      vec3(-0.155626,0.120533,0.019395),\n      vec3(0.042311,0.054462,-0.049709),\n      vec3(0.001257,0.031288,0.034468),\n      vec3(-0.002271,0.003199,-0.002304),\n      vec3(0.662104,0.717307,0.033854),\n      vec3(-0.373100,0.576021,0.308274),\n      vec3(0.024233,0.231316,-0.173688),\n      vec3(0.161311,0.420217,0.234273),\n      vec3(-0.045248,0.078031,-0.010411),\n      vec3(0.167453,0.376942,-0.094872),\n      vec3(-0.056194,0.433247,0.173218),\n      vec3(-0.016224,0.123149,-0.035569),\n      vec3(0.067127,0.407641,0.028479)\n   );\n\n   float depth = texture2D(depthmap, vTexCoords).r;\n   if(depth == 1.0) {\n      discard;\n   }\n\n   vec4 screen_position = vec4(vTexCoords, depth,1.0);\n   vec4 pos = projinv*screen_position;\n   pos /= pos.w;\n   vec3 position = pos.xyz;\n\n   //approximate the normal from the depth map; I find this simpler\n   //than trying to recompute the exact normal within every possible object shader\n\n   //pixel offset positions in screen space\n   ivec2 dim = textureSize(depthmap,0);\n   vec2 offset1 = vec2(0.0,1.0/float(dim.y));\n   vec2 offset2 = vec2(1.0/float(dim.x),0.0);\n   float depth1 = texture2D(depthmap, vTexCoords + offset1).r;\n   float depth2 = texture2D(depthmap, vTexCoords + offset2).r;\n   \n   vec3 p1 = vec3(screen_position.xy+offset1, depth1 - depth);\n   vec3 p2 = vec3(screen_position.xy+offset2, depth2 - depth);\n\n   //convert to model space\n   vec4 pos1 = projinv*vec4(p1,1);\n   pos1 /= pos1.w;\n   vec4 pos2 = projinv*vec4(p2,1);\n   pos2 /= pos2.w;\n\n   vec3 normal = normalize(cross(pos1.xyz-position, pos2.xyz-position)); //model normal, important we normalize in model space\n\n   //pseudo random number\n\n   float occlusion = 0.0;\n   for(int c = 0; c < cycles; c++) {\n   vec3 random = normalize(pseudorandomVec3(position+float(c)));\n   for(int i=0; i < samples; i++) {\n\n      vec3 ray = radius * reflect(sample_sphere[i],random);\n      vec3 hemi_ray = position + sign(dot(ray,normal)) * ray; //model space\n      vec4 hemi_screen = projectionMatrix*vec4(hemi_ray,1.0);\n      hemi_screen /= hemi_screen.w;\n      \n      float occ_depth = texture2D(depthmap, clamp(hemi_screen.xy,0.0,1.0)).r;\n      float difference = hemi_screen.z - occ_depth;\n      \n      occlusion += step(0.0, difference) * (1.0-smoothstep(0.0, area, difference));\n   }\n   }\n   float ao = 1.0 - total_strength * occlusion * (1.0 / float(cycles*samples));\n   gl_FragDepthEXT = clamp(ao+base,0.0,1.0);\n\n}";
			},
			"./src/WebGL/shaders/lib/ssao/ssao.vert"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "attribute vec2 vertexPosition;\nvarying highp vec2 vTexCoords;\nconst vec2 scale = vec2(0.5, 0.5);\n\nvoid main() {\n   vTexCoords  = vertexPosition * scale + scale; // scale vertex attribute to [0,1] range\n   gl_Position = vec4(vertexPosition, 0.0, 1.0);\n}\n        ";
			},
			"./src/WebGL/shaders/lib/ssao/uniforms.ts"(e, t, n) {
				n.r(t), n.d(t, { uniforms: () => r });
				let r = {
					total_strength: {
						type: "f",
						value: 1
					},
					radius: {
						type: "f",
						value: 5
					},
					projinv: {
						type: "mat4",
						value: []
					}
				};
			},
			"./src/WebGL/shaders/lib/stickimposter/index.ts"(e, t, n) {
				n.r(t), n.d(t, { stickimposter: () => s });
				var r = n("./src/WebGL/shaders/lib/stickimposter/uniforms.ts"), i = n("./src/WebGL/shaders/lib/stickimposter/stickimposterFragmentShader.partial.frag"), a = n("./src/WebGL/shaders/lib/stickimposter/stickimposter.partial.frag"), o = n("./src/WebGL/shaders/lib/stickimposter/stickimposter.vert");
				let s = {
					fragmentShader: [i.default, a.default].join("\n"),
					vertexShader: o.default,
					uniforms: r.uniforms
				};
			},
			"./src/WebGL/shaders/lib/stickimposter/stickimposter.partial.frag"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "    float dotProduct = dot( norm, vLight );\n    vec3 light = vec3( max( dotProduct, 0.0 ) );\n    color *= light;\n#ifdef SHADED\n    ivec2 dim = textureSize(shading,0);\n    float shadowFactor = texture2D(shading,vec2(gl_FragCoord.x/float(dim.x),gl_FragCoord.y/float(dim.y))).r;\n    color *= shadowFactor;\n#endif    \n    gl_FragColor = vec4(color, opacity*opacity );\n    if(fogNear != fogFar) {\n        float depth = -qi.z;\n        float fogFactor = smoothstep( fogNear, fogFar, depth );\n        gl_FragColor = mix( gl_FragColor, vec4( fogColor, gl_FragColor.w ), fogFactor );\n    }\n}";
			},
			"./src/WebGL/shaders/lib/stickimposter/stickimposter.vert"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "\n\nuniform mat4 modelViewMatrix;\nuniform mat4 projectionMatrix;\nuniform mat4 viewMatrix;\nuniform mat3 normalMatrix;\nuniform vec3 directionalLightColor[ 1 ];\nuniform vec3 directionalLightDirection[ 1 ];\n\nattribute vec3 position;\nattribute vec3 normal;\nattribute vec3 color;\nattribute float radius;\n\nvarying vec3 vColor;\nvarying vec3 vLight;\nvarying vec3 cposition;\nvarying vec3 p1;\nvarying vec3 p2;\nvarying float r;\n\nvoid main() {\n\n    vColor = color; vColor.z = abs(vColor.z); //z indicates which vertex and so would vary\n    r = abs(radius);\n    vec4 to = modelViewMatrix*vec4(normal, 1.0); //normal is other point of cylinder\n    vec4 pt = modelViewMatrix*vec4(position, 1.0);\n    vec4 mvPosition = pt;\n    p1 = pt.xyz; p2 = to.xyz;\n    vec3 norm = to.xyz-pt.xyz;\n    float mult = 1.1; //slop to account for perspective of sphere\n    if(length(p1) > length(p2)) { //billboard at level of closest point\n       mvPosition = to;\n    }\n    vec3 n = normalize(mvPosition.xyz);\n    bool isperspective = (projectionMatrix[3][3] == 0.0);\n//intersect with the plane defined by the camera looking at the billboard point\n    if(color.z >= 0.0) { //p1\n       if(isperspective) { //perspective\n         vec3 pnorm = normalize(p1);\n         float t = dot(mvPosition.xyz-p1,n)/dot(pnorm,n);\n         mvPosition.xyz = p1+t*pnorm; \n       } else { //orthographic\n         mvPosition.xyz = p1;\n       }\n    } else {\n      if(isperspective) { //perspective\n         vec3 pnorm = normalize(p2);\n         float t = dot(mvPosition.xyz-p2,n)/dot(pnorm,n);\n         mvPosition.xyz = p2+t*pnorm;\n       } else { //orthographic\n         mvPosition.xyz = p2;\n       } \n       mult *= -1.0;\n    }\n\n    if(isperspective) { //perspective\n      vec3 cr = normalize(cross(mvPosition.xyz,norm))*radius;\n      vec3 doublecr = normalize(cross(mvPosition.xyz,cr))*radius;\n      mvPosition.xyz +=  mult*(cr + doublecr).xyz;\n    } else {\n      vec3 cr = normalize(cross(vec3(0.0,0.0,-1.0),norm))*radius;\n      vec3 doublecr = normalize(cross(vec3(0.0,0.0,-1.0),cr))*radius;\n      mvPosition.xyz +=  mult*(cr + doublecr).xyz;     \n    }\n\n    cposition = mvPosition.xyz;\n    gl_Position = projectionMatrix * mvPosition;\n    vec4 lDirection = viewMatrix * vec4( directionalLightDirection[ 0 ], 0.0 );\n    vLight = normalize( lDirection.xyz )*directionalLightColor[0]; //not really sure this is right, but color is always white so..\n}\n\n";
			},
			"./src/WebGL/shaders/lib/stickimposter/stickimposterFragmentShader.partial.frag"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "uniform float opacity;\nuniform mat4 projectionMatrix;\n\nuniform vec3 fogColor;\nuniform float fogNear;\nuniform float fogFar;\n\nvarying vec3 vLight;\nvarying vec3 vColor;\nvarying vec3 cposition;\nvarying vec3 p1;\nvarying vec3 p2;\nvarying float r;\n\n#ifdef SHADED\nuniform highp sampler2D shading;\n#endif\n\n//DEFINEFRAGCOLOR\n\n//cylinder-ray intersection testing taken from http://mrl.nyu.edu/~dzorin/cg05/lecture12.pdf\n//also useful: http://stackoverflow.com/questions/9595300/cylinder-impostor-in-glsl\n//with a bit more care (caps) this could be a general cylinder imposter (see also outline)\nvoid main() {\n    vec3 color = abs(vColor);\n    vec3 pos = cposition;\n    vec3 p = pos; //ray point\n    vec3 v = vec3(0.0,0.0,-1.0); //ray normal - orthographic\n    if(projectionMatrix[3][3] == 0.0) v = normalize(pos); //ray normal - perspective\n    vec3 pa = p1; //cyl start\n    vec3 va = normalize(p2-p1); //cyl norm\n    vec3 tmp1 = v-(dot(v,va)*va);\n    vec3 deltap = p-pa;\n    float A = dot(tmp1,tmp1);\n    if(A == 0.0) discard;\n    vec3 tmp2 = deltap-(dot(deltap,va)*va);\n    float B = 2.0*dot(tmp1, tmp2);\n    float C = dot(tmp2,tmp2)-r*r;\n//quadratic equation!\n    float det = (B*B) - (4.0*A*C);\n    if(det < 0.0) discard;\n    float sqrtDet = sqrt(det);\n    float posT = (-B+sqrtDet)/(2.0*A);\n    float negT = (-B-sqrtDet)/(2.0*A);\n    float intersectionT = min(posT,negT);\n    vec3 qi = p+v*intersectionT;\n    float dotp1 = dot(va,qi-p1);\n    float dotp2 = dot(va,qi-p2);\n    vec3 norm;\n    if( dotp1 < 0.0 || dotp2 > 0.0) { //(p-c)^2 + 2(p-c)vt +v^2+t^2 - r^2 = 0\n       vec3 cp;\n       if( dotp1 < 0.0) {  \n//        if(vColor.x < 0.0 ) discard; //color sign bit indicates if we should cap or not\n        cp = p1;\n       } else {\n//          if(vColor.y < 0.0 ) discard;\n          cp = p2;\n       }\n       vec3 diff = p-cp;\n       A = dot(v,v);\n       B = dot(diff,v)*2.0;\n       C = dot(diff,diff)-r*r;\n       det = (B*B) - (4.0*C);\n       if(det < 0.0) discard;\n       sqrtDet = sqrt(det);\n       posT = (-B+sqrtDet)/(2.0);\n       negT = (-B-sqrtDet)/(2.0);\n       float t = min(posT,negT);\n       qi = p+v*t; \n       norm = normalize(qi-cp); \n    } else {\n       norm = normalize(qi-(dotp1*va + p1));\n    }\n    vec4 clipPos = projectionMatrix * vec4(qi, 1.0);\n    float ndcDepth = clipPos.z / clipPos.w;\n    float depth = ((gl_DepthRange.diff * ndcDepth) + gl_DepthRange.near + gl_DepthRange.far) / 2.0;\n    gl_FragDepthEXT = depth;";
			},
			"./src/WebGL/shaders/lib/stickimposter/uniforms.ts"(e, t, n) {
				n.r(t), n.d(t, { uniforms: () => r });
				let r = {
					opacity: {
						type: "f",
						value: 1
					},
					fogColor: {
						type: "c",
						value: new (n("./src/colors.ts")).Color(1, 1, 1)
					},
					fogNear: {
						type: "f",
						value: 1
					},
					fogFar: {
						type: "f",
						value: 2e3
					},
					directionalLightColor: {
						type: "fv",
						value: []
					},
					directionalLightDirection: {
						type: "fv",
						value: []
					}
				};
			},
			"./src/WebGL/shaders/lib/stickimposteroutline/index.ts"(e, t, n) {
				n.r(t), n.d(t, { stickimposteroutline: () => s });
				var r = n("./src/WebGL/shaders/lib/stickimposteroutline/uniforms.ts"), i = n("./src/WebGL/shaders/lib/stickimposter/stickimposterFragmentShader.partial.frag"), a = n("./src/WebGL/shaders/lib/stickimposteroutline/stickimposteroutline.partial.frag"), o = n("./src/WebGL/shaders/lib/stickimposteroutline/stickimposteroutline.vert");
				let s = {
					fragmentShader: i.default + a.default,
					vertexShader: o.default,
					uniforms: r.uniforms
				};
			},
			"./src/WebGL/shaders/lib/stickimposteroutline/stickimposteroutline.partial.frag"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "\n    gl_FragColor = vec4(color, opacity*opacity );\n    if(fogNear != fogFar) {\n        float depth = -qi.z;\n        float fogFactor = smoothstep( fogNear, fogFar, depth );\n        gl_FragColor = mix( gl_FragColor, vec4( fogColor, gl_FragColor.w ), fogFactor );\n    }\n}";
			},
			"./src/WebGL/shaders/lib/stickimposteroutline/stickimposteroutline.vert"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "\n\nuniform mat4 modelViewMatrix;\nuniform mat4 projectionMatrix;\nuniform mat4 viewMatrix;\nuniform mat3 normalMatrix;\nuniform vec3 directionalLightColor[ 1 ];\nuniform vec3 directionalLightDirection[ 1 ];\nuniform vec3 outlineColor;\nuniform float outlineWidth;\nuniform float outlinePushback;\nuniform float outlineMaxPixels;\nuniform float vWidth;\nuniform mat4 projinv;\n\n\nattribute vec3 position;\nattribute vec3 normal;\nattribute vec3 color;\nattribute float radius;\n\nvarying vec3 vColor;\nvarying vec3 vLight;\nvarying vec3 cposition;\nvarying vec3 p1;\nvarying vec3 p2;\nvarying float r;\n\nvoid main() {\n\n    vColor = outlineColor;\n    float rad = radius+sign(radius)*outlineWidth;\n    r = abs(rad);\n\n    vec4 to = modelViewMatrix*vec4(normal, 1.0); //normal is other point of cylinder\n    vec4 pt = modelViewMatrix*vec4(position, 1.0);\n//pushback\n    float scale = 1.0;\n    if(projectionMatrix[3][3] != 0.0) { //orthographic\n        to.z -= outlinePushback;\n        pt.z -= outlinePushback;\n    } else { //perspective\n        vec4 midbefore = pt;\n        if(length(to.xyz) < length(pt)) {\n            midbefore = to;\n        }\n        vec4 midafter = midbefore;\n        midafter.xyz += normalize(midbefore.xyz)*outlinePushback;\n\n        to.xyz += normalize(to.xyz)*outlinePushback;\n        pt.xyz += normalize(pt.xyz)*outlinePushback;\n\n        //figure out a scaling factor for radius to account for perspective setback\n        vec4 midbeforer = vec4(midbefore.x+rad,midbefore.y, midbefore.z, midbefore.w);\n        vec4 midafterr = vec4(midafter.x+rad,midafter.y, midafter.z, midafter.w);\n\n        vec4 mb = projectionMatrix*midbefore;\n        vec4 mbr = projectionMatrix*midbeforer;\n        vec4 ma = projectionMatrix*midafter;\n        vec4 mar = projectionMatrix*midafterr;\n        mb /= mb.w;\n        mbr /= mbr.w;\n        ma /= ma.w;\n        mar /= mar.w;\n        scale = abs((mbr.x-mb.x)/(mar.x-ma.x));\n        rad *= scale;\n        r = abs(rad);\n    }\n    vec4 mvPosition = pt;\n    p1 = pt.xyz; p2 = to.xyz;\n    vec3 norm = to.xyz-pt.xyz;\n    float mult = 1.1; //slop to account for perspective of sphere\n    if(length(p1) > length(p2)) { //billboard at level of closest point\n       mvPosition = to;\n    }\n\n    vec3 n = normalize(mvPosition.xyz);\n//intersect with the plane defined by the camera looking at the billboard point\n    if(color.z >= 0.0) { //p1\n       vec3 pnorm = normalize(p1);\n       float t = dot(mvPosition.xyz-p1,n)/dot(pnorm,n);\n       mvPosition.xyz = p1+t*pnorm;\n    } else {\n       vec3 pnorm = normalize(p2);\n       float t = dot(mvPosition.xyz-p2,n)/dot(pnorm,n);\n       mvPosition.xyz = p2+t*pnorm;\n       mult *= -1.0;\n    }\n\n    if(outlineMaxPixels > 0.0) {\n        vec4 cpos = mvPosition;\n        vec4 unadjusted = projectionMatrix*vec4(cpos.x+abs(scale*radius), cpos.y,cpos.z,cpos.w); \n        vec4 ccoord = projectionMatrix*cpos;\n        vec4 adjust = projectionMatrix*vec4(cpos.x+r,cpos.y,cpos.z,cpos.w); \n        unadjusted /= unadjusted.w;\n        adjust /= adjust.w;\n        unadjusted.xyz -= ccoord.xyz/ccoord.w;\n        adjust.xyz -= ccoord.xyz/ccoord.w;\n        float diff = abs(adjust.x-unadjusted.x);\n        diff *= vWidth; //this should now be in pixels\n        if(diff > outlineMaxPixels) {\n            float fixlen = abs(unadjusted.x) + outlineMaxPixels/vWidth; \n            vec4 pcoord = ccoord;\n            pcoord.x += fixlen*pcoord.w;\n            vec4 altc = projinv*pcoord;\n            r= abs(altc.x-cpos.x);\n        }\n    }\n\n    vec3 cr = normalize(cross(mvPosition.xyz,norm))*rad;\n    vec3 doublecr = normalize(cross(mvPosition.xyz,cr))*rad;\n    mvPosition.xy +=  mult*(cr + doublecr).xy;\n    cposition = mvPosition.xyz;\n    gl_Position = projectionMatrix * mvPosition;\n    vLight = vec3(1.0,1.0,1.0);\n}\n\n";
			},
			"./src/WebGL/shaders/lib/stickimposteroutline/uniforms.ts"(e, t, n) {
				n.r(t), n.d(t, { uniforms: () => i });
				var r = n("./src/colors.ts");
				let i = {
					opacity: {
						type: "f",
						value: 1
					},
					fogColor: {
						type: "c",
						value: new r.Color(1, 1, 1)
					},
					fogNear: {
						type: "f",
						value: 1
					},
					fogFar: {
						type: "f",
						value: 2e3
					},
					outlineColor: {
						type: "c",
						value: new r.Color(0, 0, 0)
					},
					outlineWidth: {
						type: "f",
						value: .1
					},
					outlinePushback: {
						type: "f",
						value: 1
					},
					outlineMaxPixels: {
						type: "f",
						value: 0
					},
					projinv: {
						type: "mat4",
						value: []
					}
				};
			},
			"./src/WebGL/shaders/lib/volumetric/index.ts"(e, t, n) {
				n.r(t), n.d(t, { volumetric: () => o });
				var r = n("./src/WebGL/shaders/lib/volumetric/uniforms.ts"), i = n("./src/WebGL/shaders/lib/volumetric/volumetric.frag"), a = n("./src/WebGL/shaders/lib/volumetric/volumetric.vert");
				let o = {
					fragmentShader: i.default.replace("#define GLSLIFY 1", ""),
					vertexShader: a.default.replace("#define GLSLIFY 1", ""),
					uniforms: r.uniforms
				};
			},
			"./src/WebGL/shaders/lib/volumetric/uniforms.ts"(e, t, n) {
				n.r(t), n.d(t, { uniforms: () => r });
				let r = {
					opacity: {
						type: "f",
						value: 1
					},
					fogColor: {
						type: "c",
						value: new (n("./src/colors.ts")).Color(1, 1, 1)
					},
					fogNear: {
						type: "f",
						value: 1
					},
					fogFar: {
						type: "f",
						value: 2e3
					},
					data: {
						type: "i",
						value: 3
					},
					colormap: {
						type: "i",
						value: 4
					},
					depthmap: {
						type: "i",
						value: 5
					},
					step: {
						type: "f",
						value: 1
					},
					maxdepth: {
						type: "f",
						value: 100
					},
					subsamples: {
						type: "f",
						value: 5
					},
					textmat: {
						type: "mat4",
						value: []
					},
					projinv: {
						type: "mat4",
						value: []
					},
					transfermin: {
						type: "f",
						value: -.2
					},
					transfermax: {
						type: "f",
						value: .2
					}
				};
			},
			"./src/WebGL/shaders/lib/volumetric/volumetric.frag"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "\nuniform highp sampler3D data;\nuniform highp sampler2D colormap;\nuniform highp sampler2D depthmap;\n\n\nuniform mat4 textmat;\nuniform mat4 projinv;\nuniform mat4 projectionMatrix;\n\nuniform float step;\nuniform float subsamples;\nuniform float maxdepth;\nuniform float transfermin;\nuniform float transfermax;\nin  vec4 mvPosition;\nout vec4 color;\nvoid main(void) {\n\n   vec4 pos = mvPosition;\n   bool seengood = false;\n   float i = 0.0;\n   color = vec4(1,1,1,0);\n   float increment = 1.0/subsamples;\n   float maxsteps = (maxdepth*subsamples/step);\n//there's probably a better way to do this..\n//calculate farthest possible point in model coordinates\n   vec4 maxpos = vec4(pos.x,pos.y,pos.z-maxdepth,1.0);\n// convert to projection\n   maxpos = projectionMatrix*maxpos;\n   vec4 startp = projectionMatrix*pos;\n// homogonize\n   maxpos /= maxpos.w;\n   startp /= startp.w;\n//take x,y from start and z from max\n   maxpos = vec4(startp.x,startp.y,maxpos.z,1.0);\n//convert back to model space\n   maxpos = projinv*maxpos;\n   maxpos /= maxpos.w;\n   float incr = step/subsamples;\n//get depth from depthmap\n//startp is apparently [-1,1]\n   vec2 tpos = startp.xy/2.0+0.5;\n   float depth = texture(depthmap, tpos).r;\n//compute vector between start and end\n   vec4 direction = maxpos-pos;\n   for( i = 0.0; i <= maxsteps; i++) {\n      vec4 pt = (pos+(i/maxsteps)*direction);\n      vec4 ppt = projectionMatrix*pt;\n      float ptdepth = ppt.z/ppt.w;\n      ptdepth = ((gl_DepthRange.diff * ptdepth) + gl_DepthRange.near + gl_DepthRange.far) / 2.0;\n      if(ptdepth > depth) break;\n      pt = textmat*pt;\n//       pt /= pt.w;\n      if(pt.x >= -0.01 && pt.y >= -0.01 && pt.z >= -0.01 && pt.x <= 1.01 && pt.y <= 1.01 && pt.z <= 1.01) {\n         seengood = true;\n      } else if(seengood) {\n         break;\n      }\n      if( pt.x < -0.01 || pt.x > 1.01 || pt.y < -0.01 || pt.y > 1.01 || pt.z < -0.01 || pt.z > 1.01  ){\n          color.a = 0.0;\n          continue;\n      }\n      else {\n         float val = texture(data, pt.zyx).r;\n         if(isinf(val)) continue; //masked out\n         float cval = (val-transfermin)/(transfermax-transfermin); //scale to texture 0-1 range\n         vec4 val_color = texture(colormap, vec2(cval,0.5));\n         color.rgb = color.rgb*color.a + (1.0-color.a)*val_color.a*val_color.rgb;\n         color.a += (1.0 - color.a) * val_color.a; \n         if(color.a > 0.0) color.rgb /= color.a;\n//          color = vec4(pt.x, pt.y, pt.z, 1.0);\n      }\n//       color = vec4(pt.x, pt.y, pt.z, 0.0)\n    }\n}\n\n        ";
			},
			"./src/WebGL/shaders/lib/volumetric/volumetric.vert"(e, t, n) {
				n.r(t), n.d(t, { default: () => r });
				let r = "uniform mat4 modelViewMatrix;\nuniform mat4 projectionMatrix;\nuniform mat4 viewMatrix;\n\nin vec3 position;\nout vec4 mvPosition;\nvoid main() {\n\n    mvPosition = modelViewMatrix * vec4( position, 1.0 );\n    gl_Position = projectionMatrix*mvPosition;\n}\n";
			},
			"./src/WebGL/shaders/utils/clone.ts"(e, t, n) {
				n.r(t), n.d(t, { clone: () => i });
				var r = n("./src/colors.ts");
				function i(e) {
					let t = {};
					for (let i in e) {
						t[i] = {}, t[i].type = e[i].type;
						var n = e[i].value;
						n instanceof r.Color ? t[i].value = n.clone() : typeof n == "number" ? t[i].value = n : n instanceof Array ? t[i].value = [] : console.error("Error copying shader uniforms from ShaderLib: unknown type for uniform");
					}
					return t;
				}
			},
			"./src/WebGL/shaders/utils/index.ts"(e, t, n) {
				n.r(t), n.d(t, {
					ShaderUtils: () => i,
					clone: () => r.clone
				});
				var r = n("./src/WebGL/shaders/utils/clone.ts");
				let i = { clone: r.clone };
			},
			"./src/WebGL/shapes/Cylinder.ts"(e, t, n) {
				n.r(t), n.d(t, { Cylinder: () => a });
				var r = n("./src/WebGL/math/index.ts");
				let i = new r.Vector3();
				class a {
					constructor(e = new r.Vector3(), t = new r.Vector3(), n = 0) {
						this.c1 = e, this.c2 = t, this.radius = n, this.direction = new r.Vector3().subVectors(this.c2, this.c1).normalize();
					}
					copy(e) {
						return this.c1.copy(e.c1), this.c2.copy(e.c2), this.direction.copy(e.direction), this.radius = e.radius, this;
					}
					lengthSq() {
						return i.subVectors(this.c2, this.c1).lengthSq();
					}
					applyMatrix4(e) {
						return this.direction.add(this.c1).applyMatrix4(e), this.c1.applyMatrix4(e), this.c2.applyMatrix4(e), this.direction.sub(this.c1).normalize(), this.radius *= e.getMaxScaleOnAxis(), this;
					}
				}
			},
			"./src/WebGL/shapes/Sphere.ts"(e, t, n) {
				n.r(t), n.d(t, { Sphere: () => i });
				var r = n("./src/WebGL/math/index.ts");
				class i {
					constructor(e = {
						x: 0,
						y: 0,
						z: 0
					}, t = 0) {
						this.center = new r.Vector3(e.x, e.y, e.z), this.radius = t;
					}
					set(e, t) {
						return this.center.copy(e), this.radius = t, this;
					}
					copy(e) {
						return this.center.copy(e.center), this.radius = e.radius, this;
					}
					applyMatrix4(e) {
						return this.center.applyMatrix4(e), this.radius *= e.getMaxScaleOnAxis(), this;
					}
					translate(e) {
						return this.center.add(e), this;
					}
					equals(e) {
						return e.center.equals(this.center) && e.radius === this.radius;
					}
					clone() {
						return new i().copy(this);
					}
				}
			},
			"./src/WebGL/shapes/Triangle.ts"(e, t, n) {
				n.r(t), n.d(t, { Triangle: () => a });
				var r = n("./src/WebGL/math/index.ts");
				let i = new r.Vector3();
				class a {
					constructor(e = new r.Vector3(), t = new r.Vector3(), n = new r.Vector3()) {
						this.a = e, this.b = t, this.c = n;
					}
					copy(e) {
						return this.a.copy(e.a), this.b.copy(e.b), this.c.copy(e.c), this;
					}
					applyMatrix4(e) {
						return this.a.applyMatrix4(e), this.b.applyMatrix4(e), this.c.applyMatrix4(e), this;
					}
					getNormal() {
						var e = this.a.clone();
						return e.sub(this.b), i.subVectors(this.c, this.b), e.cross(i), e.normalize(), e;
					}
				}
			},
			"./src/WebGL/shapes/index.ts"(e, t, n) {
				n.r(t), n.d(t, {
					Cylinder: () => i.Cylinder,
					Sphere: () => r.Sphere,
					Triangle: () => a.Triangle
				});
				var r = n("./src/WebGL/shapes/Sphere.ts"), i = n("./src/WebGL/shapes/Cylinder.ts"), a = n("./src/WebGL/shapes/Triangle.ts");
			},
			"./src/autoload.ts"(e, t, n) {
				n.r(t), n.d(t, {
					autoinit: () => s,
					autoload: () => u,
					processing_autoinit: () => c,
					viewers: () => l
				});
				var r = n("./src/GLViewer.ts"), i = n("./src/ProteinSurface4.ts"), a = n("./src/utilities.ts"), o = n("./src/colors.ts"), s = !1, c = !1, l = {};
				function u(e, t) {
					var n, u, d;
					if (document.querySelector(".viewer_3Dmoljs") != null && (s = !0), s) {
						c = !0, e ??= null;
						var f = 0;
						document.querySelectorAll(".viewer_3Dmoljs").forEach((s) => {
							var p = [], m = [], h = "";
							s.style.position == "static" && (s.style.position = "relative");
							var g = null;
							if (d = null, s.dataset.pdb) p.push("https://files.rcsb.org/view/" + s.dataset.pdb + ".pdb"), m.push("pdb");
							else if (s.dataset.cid) m.push("sdf"), p.push("https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/" + s.dataset.cid + "/SDF?record_type=3d");
							else if (s.dataset.href || s.dataset.url) {
								if (h = s.dataset.href ? s.dataset.href : s.dataset.url, p.push(h), d = h.substring(h.lastIndexOf(".") + 1), d == "gz") {
									let e = h.substring(0, h.lastIndexOf(".")).lastIndexOf(".");
									d = h.substring(e + 1);
								}
								m.push(d);
								var _ = h.substring(h.lastIndexOf("/") + 1, h.lastIndexOf("."));
								_ == "/" && (_ = h.substring(h.lastIndexOf("/") + 1)), s.dataset[m[m.length - 1]] = _;
							}
							let v = s.dataset;
							for (n in v) n.substring(0, 3) === "pdb" && n !== "pdb" ? (p.push("https://files.rcsb.org/view/" + v[n] + ".pdb"), m.push("pdb")) : n.substring(0, 4) === "href" && n !== "href" ? (h = v[n], p.push(h), m.push(h.substring(h.lastIndexOf(".") + 1))) : n.substring(0, 3) === "cid" && n !== "cid" && (p.push("https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/" + v[n] + "/SDF?record_type=3d"), m.push("sdf"));
							var y = {};
							s.dataset.options && (y = (0, a.specStringToObject)(s.dataset.options));
							var b = o.CC.color(s.dataset.backgroundcolor), x = s.dataset.backgroundalpha;
							x = x == null ? 1 : parseFloat(x);
							var S = !!s.dataset.style, C = { line: {} };
							S && (C = (0, a.specStringToObject)(s.dataset.style));
							var w = {};
							s.dataset.select && (w = (0, a.specStringToObject)(s.dataset.select));
							var T = [], E = [], D = [], O = {}, k = null, A = s.dataset, j = /style(.+)/, M = /surface(.*)/, N = /labelres(.*)/, P = [];
							for (u in A) Object.prototype.hasOwnProperty.call(A, u) && P.push(u);
							for (P.sort(), n = 0; n < P.length; n++) {
								u = P[n];
								var F = j.exec(u), I, L, R;
								F && (I = "select" + F[1], L = (0, a.specStringToObject)(A[I]), R = (0, a.specStringToObject)(A[u]), T.push([L, R])), F = M.exec(u), F && (I = "select" + F[1], L = (0, a.specStringToObject)(A[I]), R = (0, a.specStringToObject)(A[u]), E.push([L, R])), F = N.exec(u), F && (I = "select" + F[1], L = (0, a.specStringToObject)(A[I]), R = (0, a.specStringToObject)(A[u]), D.push([L, R])), u == "zoomto" && (O = (0, a.specStringToObject)(A[u])), u == "spin" && (k = (0, a.specStringToObject)(A[u]));
							}
							var z = function(e) {
								for (S ? e.setStyle(w, C) : e.addStyle(w, C), g && g.createSelectionAndStyle(w, C), n = 0; n < T.length; n++) {
									let t = T[n][0] || {}, r = T[n][1] || { line: {} };
									e.setStyle(t, r), g && g.createSelectionAndStyle(w, C);
								}
								for (n = 0; n < E.length; n++) {
									let t = E[n][0] || {}, r = E[n][1] || {};
									g ? e.addSurface(i.SurfaceType.VDW, r, t, t).then((e) => {
										g.loadSurface("VDW", t, r, e);
									}) : e.addSurface(i.SurfaceType.VDW, r, t, t);
								}
								for (n = 0; n < D.length; n++) {
									let t = D[n][0] || {}, r = D[n][1] || {};
									e.addResLabels(t, r);
								}
								e.render(), e.zoomTo(O), k && e.spin(k.axis, k.speed);
							};
							let B = e;
							try {
								var V = (0, a.specStringToObject)(s.dataset.config) || {};
								V.backgroundColor === void 0 && (V.backgroundColor = b), V.backgroundAlpha === void 0 && (V.backgroundAlpha = x), B == null ? B = l[s.id || f++] = (0, r.createViewer)(s, V) : (B.setBackgroundColor(b, x), B.setConfig(V), g && g.initiateUI()), s.dataset.ui && $3Dmol.StateManager && (g = new $3Dmol.StateManager(B));
							} catch (e) {
								console.log(e), s.textContent = "WebGL appears to be disabled.";
							}
							if (p.length != 0) {
								let e = 0, n = ((r, i) => function(o) {
									h = p[e];
									var s = r.dataset.type || r.dataset.datatype || m[e];
									if (i.addModel(o, s, y), g) {
										var l = r.dataset[m[e]];
										g.setModelTitle(l);
									}
									e += 1, e < p.length ? (0, a.get)(p[e]).then(n) : (z(i), r.dataset.callback && (0, a.makeFunction)(r.dataset.callback)(i), c = !1, t && t(i));
								})(s, B);
								d && d.endsWith("gz") ? (0, a.getbin)(p[0]).then(n) : (0, a.get)(p[0]).then(n);
							} else {
								if (s.dataset.element) {
									var H = "#" + s.dataset.element, U = document.querySelector(H), W = U ? U.textContent : "";
									d = s.dataset.type || s.dataset.datatype, B.addModel(W, d, y);
								}
								z(B), s.dataset.callback && (0, a.makeFunction)(s.dataset.callback)(B), c = !1, t && t(B);
							}
						});
					}
				}
				document.onreadystatechange = () => {
					document.readyState === "complete" && u();
				};
			},
			"./src/colors.ts"(e, t, n) {
				n.r(t), n.d(t, {
					CC: () => i,
					Color: () => r,
					builtinColorSchemes: () => d,
					chains: () => u,
					elementColors: () => c,
					htmlColors: () => a,
					residues: () => l,
					ssColors: () => o
				});
				class r {
					constructor(e, t, n) {
						return this.r = 0, this.g = 0, this.b = 0, arguments.length > 1 && typeof e == "number" ? (this.r = e || 0, this.g = t || 0, this.b = n || 0, this) : this.set(e || 0);
					}
					set(e) {
						return e instanceof r ? e.clone() : (typeof e == "number" ? this.setHex(e) : typeof e == "object" && (this.r = e?.r || 0, this.g = e?.g || 0, this.b = e?.b || 0), this);
					}
					setHex(e) {
						return e = Math.floor(e), this.r = (e >> 16 & 255) / 255, this.g = (e >> 8 & 255) / 255, this.b = (e & 255) / 255, this;
					}
					getHex() {
						var e = Math.round(this.r * 255), t = Math.round(this.g * 255), n = Math.round(this.b * 255);
						return e << 16 | t << 8 | n;
					}
					clone() {
						return new r(this.r, this.g, this.b);
					}
					copy(e) {
						return this.r = e.r, this.g = e.g, this.b = e.b, this;
					}
					scaled() {
						var e = {};
						return e.r = Math.round(this.r * 255), e.g = Math.round(this.g * 255), e.b = Math.round(this.b * 255), e.a = 1, e;
					}
				}
				class i {
					static color(e) {
						if (!e) return i.cache[0];
						if (e instanceof r) return e;
						if (typeof e == "number" && i.cache[e] !== void 0) return i.cache[e];
						if (e && Array.isArray(e)) return e.map(i.color);
						let t = i.getHex(e), n = new r(t);
						return i.cache[t] = n, n;
					}
					static getHex(e) {
						if (Array.isArray(e)) return e.map(i.getHex);
						if (typeof e == "string") {
							let t = e;
							if (!isNaN(parseInt(t))) return parseInt(t);
							if (t = t.trim(), t.length == 4 && t[0] == "#" && (t = "#" + t[1] + t[1] + t[2] + t[2] + t[3] + t[3]), t.length == 7 && t[0] == "#") return parseInt(t.substring(1), 16);
							let n = i.rgbRegEx.exec(t);
							if (n) {
								n[1] != "" && console.log("WARNING: Opacity value in rgba ignored.  Specify separately as opacity attribute.");
								let e = 0;
								for (let t = 2; t < 5; t++) {
									e *= 256;
									let r = n[t].endsWith("%") ? 255 * parseFloat(n[t]) / 100 : parseFloat(n[t]);
									e += Math.round(r);
								}
								return e;
							}
							let r = a[t.toLowerCase()];
							return r === void 0 ? (console.error("color not found", e.toLowerCase(), a), 0) : r;
						}
						return e;
					}
				}
				i.rgbRegEx = /rgb(a?)\(\s*([^ ,\)\t]+)\s*,\s*([^ ,\)\t]+)\s*,\s*([^ ,\)\t]+)/i, i.cache = { 0: new r(0) };
				let a = {
					aliceblue: 15792383,
					antiquewhite: 16444375,
					aqua: 65535,
					aquamarine: 8388564,
					azure: 15794175,
					beige: 16119260,
					bisque: 16770244,
					black: 0,
					blanchedalmond: 16772045,
					blue: 255,
					blueviolet: 9055202,
					brown: 10824234,
					burlywood: 14596231,
					cadetblue: 6266528,
					chartreuse: 8388352,
					chocolate: 13789470,
					coral: 16744272,
					cornflowerblue: 6591981,
					cornsilk: 16775388,
					crimson: 14423100,
					cyan: 65535,
					darkblue: 139,
					darkcyan: 35723,
					darkgoldenrod: 12092939,
					darkgray: 11119017,
					darkgrey: 11119017,
					darkgreen: 25600,
					darkkhaki: 12433259,
					darkmagenta: 9109643,
					darkolivegreen: 5597999,
					darkorange: 16747520,
					darkorchid: 10040012,
					darkred: 9109504,
					darksalmon: 15308410,
					darkseagreen: 9419919,
					darkslateblue: 4734347,
					darkslategray: 3100495,
					darkslategrey: 3100495,
					darkturquoise: 52945,
					darkviolet: 9699539,
					deeppink: 16716947,
					deepskyblue: 49151,
					dimgray: 6908265,
					dimgrey: 6908265,
					dodgerblue: 2003199,
					firebrick: 11674146,
					floralwhite: 16775920,
					forestgreen: 2263842,
					fuchsia: 16711935,
					gainsboro: 14474460,
					ghostwhite: 16316671,
					gold: 16766720,
					goldenrod: 14329120,
					gray: 8421504,
					grey: 8421504,
					green: 32768,
					greenyellow: 11403055,
					honeydew: 15794160,
					hotpink: 16738740,
					indianred: 13458524,
					indigo: 4915330,
					ivory: 16777200,
					khaki: 15787660,
					lavender: 15132410,
					lavenderblush: 16773365,
					lawngreen: 8190976,
					lemonchiffon: 16775885,
					lightblue: 11393254,
					lightcoral: 15761536,
					lightcyan: 14745599,
					lightgoldenrodyellow: 16448210,
					lightgray: 13882323,
					lightgrey: 13882323,
					lightgreen: 9498256,
					lightpink: 16758465,
					lightsalmon: 16752762,
					lightseagreen: 2142890,
					lightskyblue: 8900346,
					lightslategray: 7833753,
					lightslategrey: 7833753,
					lightsteelblue: 11584734,
					lightyellow: 16777184,
					lime: 65280,
					limegreen: 3329330,
					linen: 16445670,
					magenta: 16711935,
					maroon: 8388608,
					mediumaquamarine: 6737322,
					mediumblue: 205,
					mediumorchid: 12211667,
					mediumpurple: 9662683,
					mediumseagreen: 3978097,
					mediumslateblue: 8087790,
					mediumspringgreen: 64154,
					mediumturquoise: 4772300,
					mediumvioletred: 13047173,
					midnightblue: 1644912,
					mintcream: 16121850,
					mistyrose: 16770273,
					moccasin: 16770229,
					navajowhite: 16768685,
					navy: 128,
					oldlace: 16643558,
					olive: 8421376,
					olivedrab: 7048739,
					orange: 16753920,
					orangered: 16729344,
					orchid: 14315734,
					palegoldenrod: 15657130,
					palegreen: 10025880,
					paleturquoise: 11529966,
					palevioletred: 14381203,
					papayawhip: 16773077,
					peachpuff: 16767673,
					peru: 13468991,
					pink: 16761035,
					plum: 14524637,
					powderblue: 11591910,
					purple: 8388736,
					rebeccapurple: 6697881,
					red: 16711680,
					rosybrown: 12357519,
					royalblue: 4286945,
					saddlebrown: 9127187,
					salmon: 16416882,
					sandybrown: 16032864,
					seagreen: 3050327,
					seashell: 16774638,
					sienna: 10506797,
					silver: 12632256,
					skyblue: 8900331,
					slateblue: 6970061,
					slategray: 7372944,
					slategrey: 7372944,
					snow: 16775930,
					springgreen: 65407,
					steelblue: 4620980,
					tan: 13808780,
					teal: 32896,
					thistle: 14204888,
					tomato: 16737095,
					turquoise: 4251856,
					violet: 15631086,
					wheat: 16113331,
					white: 16777215,
					whitesmoke: 16119285,
					yellow: 16776960,
					yellowgreen: 10145074,
					b: 255,
					g: 32768,
					r: 16711680,
					c: 49087,
					m: 12517567,
					y: 12566272,
					k: 0,
					w: 16777215
				}, o = {
					pyMol: {
						h: 16711680,
						s: 16776960,
						c: 65280
					},
					Jmol: {
						h: 16711808,
						s: 16762880,
						c: 16777215
					}
				}, s = {
					H: 16777215,
					He: 16761035,
					HE: 16761035,
					Li: 11674146,
					LI: 11674146,
					B: 65280,
					C: 13158600,
					N: 9408511,
					O: 15728640,
					F: 14329120,
					Na: 255,
					NA: 255,
					Mg: 2263842,
					MG: 2263842,
					Al: 8421520,
					AL: 8421520,
					Si: 14329120,
					SI: 14329120,
					P: 16753920,
					S: 16762930,
					Cl: 65280,
					CL: 65280,
					Ca: 8421520,
					CA: 8421520,
					Ti: 8421520,
					TI: 8421520,
					Cr: 8421520,
					CR: 8421520,
					Mn: 8421520,
					MN: 8421520,
					Fe: 16753920,
					FE: 16753920,
					Ni: 10824234,
					NI: 10824234,
					Cu: 10824234,
					CU: 10824234,
					Zn: 10824234,
					ZN: 10824234,
					Br: 10824234,
					BR: 10824234,
					Ag: 8421520,
					AG: 8421520,
					I: 10494192,
					Ba: 16753920,
					BA: 16753920,
					Au: 14329120,
					AU: 14329120
				}, c = {
					defaultColor: 16716947,
					Jmol: {
						H: 16777215,
						He: 14286847,
						HE: 14286847,
						Li: 13402367,
						LI: 13402367,
						Be: 12779264,
						BE: 12779264,
						B: 16758197,
						C: 9474192,
						N: 3166456,
						O: 16715021,
						F: 9494608,
						Ne: 11789301,
						NE: 11789301,
						Na: 11230450,
						NA: 11230450,
						Mg: 9109248,
						MG: 9109248,
						Al: 12560038,
						AL: 12560038,
						Si: 1578e4,
						SI: 1578e4,
						P: 16744448,
						S: 16777008,
						Cl: 2093087,
						CL: 2093087,
						Ar: 8442339,
						AR: 8442339,
						K: 9388244,
						Ca: 4062976,
						CA: 4062976,
						Sc: 15132390,
						SC: 15132390,
						Ti: 12567239,
						TI: 12567239,
						V: 10921643,
						Cr: 9083335,
						CR: 9083335,
						Mn: 10255047,
						MN: 10255047,
						Fe: 14706227,
						FE: 14706227,
						Co: 15765664,
						CO: 15765664,
						Ni: 5296208,
						NI: 5296208,
						Cu: 13140019,
						CU: 13140019,
						Zn: 8224944,
						ZN: 8224944,
						Ga: 12750735,
						GA: 12750735,
						Ge: 6721423,
						GE: 6721423,
						As: 12419299,
						AS: 12419299,
						Se: 16752896,
						SE: 16752896,
						Br: 10889513,
						BR: 10889513,
						Kr: 6076625,
						KR: 6076625,
						Rb: 7351984,
						RB: 7351984,
						Sr: 65280,
						SR: 65280,
						Y: 9764863,
						Zr: 9756896,
						ZR: 9756896,
						Nb: 7586505,
						NB: 7586505,
						Mo: 5551541,
						MO: 5551541,
						Tc: 3907230,
						TC: 3907230,
						Ru: 2396047,
						RU: 2396047,
						Rh: 687500,
						RH: 687500,
						Pd: 27013,
						PD: 27013,
						Ag: 12632256,
						AG: 12632256,
						Cd: 16767375,
						CD: 16767375,
						In: 10909043,
						IN: 10909043,
						Sn: 6717568,
						SN: 6717568,
						Sb: 10380213,
						SB: 10380213,
						Te: 13924864,
						TE: 13924864,
						I: 9699476,
						Xe: 4366e3,
						XE: 4366e3,
						Cs: 5707663,
						CS: 5707663,
						Ba: 51456,
						BA: 51456,
						La: 7394559,
						LA: 7394559,
						Ce: 16777159,
						CE: 16777159,
						Pr: 14286791,
						PR: 14286791,
						Nd: 13107143,
						ND: 13107143,
						Pm: 10747847,
						PM: 10747847,
						Sm: 9437127,
						SM: 9437127,
						Eu: 6422471,
						EU: 6422471,
						Gd: 4587463,
						GD: 4587463,
						Tb: 3211207,
						TB: 3211207,
						Dy: 2097095,
						DY: 2097095,
						Ho: 65436,
						HO: 65436,
						Er: 58997,
						ER: 58997,
						Tm: 54354,
						TM: 54354,
						Yb: 48952,
						YB: 48952,
						Lu: 43812,
						LU: 43812,
						Hf: 5096191,
						HF: 5096191,
						Ta: 5089023,
						TA: 5089023,
						W: 2200790,
						Re: 2522539,
						RE: 2522539,
						Os: 2516630,
						OS: 2516630,
						Ir: 1528967,
						IR: 1528967,
						Pt: 13684960,
						PT: 13684960,
						Au: 16765219,
						AU: 16765219,
						Hg: 12105936,
						HG: 12105936,
						Tl: 10900557,
						TL: 10900557,
						Pb: 5724513,
						PB: 5724513,
						Bi: 10375093,
						BI: 10375093,
						Po: 11230208,
						PO: 11230208,
						At: 7688005,
						AT: 7688005,
						Rn: 4358806,
						RN: 4358806,
						Fr: 4325478,
						FR: 4325478,
						Ra: 32e3,
						RA: 32e3,
						Ac: 7384058,
						AC: 7384058,
						Th: 47871,
						TH: 47871,
						Pa: 41471,
						PA: 41471,
						U: 36863,
						Np: 33023,
						NP: 33023,
						Pu: 27647,
						PU: 27647,
						Am: 5528818,
						AM: 5528818,
						Cm: 7888099,
						CM: 7888099,
						Bk: 9064419,
						BK: 9064419,
						Cf: 10565332,
						CF: 10565332,
						Es: 11739092,
						ES: 11739092,
						Fm: 11739066,
						FM: 11739066,
						Md: 11734438,
						MD: 11734438,
						No: 12389767,
						NO: 12389767,
						Lr: 13041766,
						LR: 13041766,
						Rf: 13369433,
						RF: 13369433,
						Db: 13697103,
						DB: 13697103,
						Sg: 14221381,
						SG: 14221381,
						Bh: 14680120,
						BH: 14680120,
						Hs: 15073326,
						HS: 15073326,
						Mt: 15400998,
						MT: 15400998
					},
					rasmol: s,
					defaultColors: Object.assign({}, s),
					greenCarbon: Object.assign(Object.assign({}, s), { C: 65280 }),
					cyanCarbon: Object.assign(Object.assign({}, s), { C: 65535 }),
					magentaCarbon: Object.assign(Object.assign({}, s), { C: 16711935 }),
					yellowCarbon: Object.assign(Object.assign({}, s), { C: 16776960 }),
					whiteCarbon: Object.assign(Object.assign({}, s), { C: 16777215 }),
					orangeCarbon: Object.assign(Object.assign({}, s), { C: 16753920 }),
					purpleCarbon: Object.assign(Object.assign({}, s), { C: 8388736 }),
					blueCarbon: Object.assign(Object.assign({}, s), { C: 255 })
				}, l = {
					amino: {
						ALA: 13158600,
						ARG: 1334015,
						ASN: 56540,
						ASP: 15075850,
						CYS: 15132160,
						GLN: 56540,
						GLU: 15075850,
						GLY: 15461355,
						HIS: 8553170,
						ILE: 1016335,
						LEU: 1016335,
						LYS: 1334015,
						MET: 15132160,
						PHE: 3289770,
						PRO: 14456450,
						SER: 16422400,
						THR: 16422400,
						TRP: 11819700,
						TYR: 3289770,
						VAL: 1016335,
						ASX: 16738740,
						GLX: 16738740
					},
					shapely: {
						ALA: 9240460,
						ARG: 124,
						ASN: 16743536,
						ASP: 10485826,
						CYS: 16777072,
						GLN: 16731212,
						GLU: 6684672,
						GLY: 16777215,
						HIS: 7368959,
						ILE: 19456,
						LEU: 4546117,
						LYS: 4671416,
						MET: 12099650,
						PHE: 5459026,
						PRO: 5395026,
						SER: 16740418,
						THR: 12078080,
						TRP: 5195264,
						TYR: 9203788,
						VAL: 16747775,
						ASX: 16711935,
						GLX: 16711935
					},
					nucleic: {
						A: 10526975,
						G: 16740464,
						I: 8454143,
						C: 16747595,
						T: 10551200,
						U: 16744576
					}
				}, u = {
					atom: {
						A: 12636415,
						B: 11599792,
						C: 16761032,
						D: 16777088,
						E: 16761087,
						F: 11596016,
						G: 16765040,
						H: 15761536,
						I: 16113331,
						J: 49151,
						K: 13458524,
						L: 6737322,
						M: 10145074,
						N: 15631086,
						O: 52945,
						P: 65407,
						Q: 3978097,
						R: 139,
						S: 12433259,
						T: 25600,
						U: 8388608,
						V: 8421376,
						W: 8388736,
						X: 32896,
						Y: 12092939,
						Z: 11674146
					},
					hetatm: {
						A: 9478351,
						B: 8441752,
						C: 13602992,
						D: 13619056,
						E: 13603023,
						F: 8437952,
						G: 13607008,
						H: 12603504,
						I: 12955267,
						J: 42959,
						K: 11881548,
						L: 5682578,
						M: 9090346,
						N: 12481214,
						O: 46753,
						P: 53103,
						Q: 3447649,
						R: 187,
						S: 10854235,
						T: 37888,
						U: 11534336,
						V: 11579392,
						W: 11534512,
						X: 45232,
						Y: 15250963,
						Z: 12726834
					}
				}, d = {
					ssPyMol: {
						prop: "ss",
						map: o.pyMol
					},
					ssJmol: {
						prop: "ss",
						map: o.Jmol
					},
					Jmol: {
						prop: "elem",
						map: c.Jmol
					},
					amino: {
						prop: "resn",
						map: l.amino
					},
					shapely: {
						prop: "resn",
						map: l.shapely
					},
					nucleic: {
						prop: "resn",
						map: l.nucleic
					},
					chain: {
						prop: "chain",
						map: u.atom
					},
					rasmol: {
						prop: "elem",
						map: c.rasmol
					},
					default: {
						prop: "elem",
						map: c.defaultColors
					},
					greenCarbon: {
						prop: "elem",
						map: c.greenCarbon
					},
					chainHetatm: {
						prop: "chain",
						map: u.hetatm
					},
					cyanCarbon: {
						prop: "elem",
						map: c.cyanCarbon
					},
					magentaCarbon: {
						prop: "elem",
						map: c.magentaCarbon
					},
					purpleCarbon: {
						prop: "elem",
						map: c.purpleCarbon
					},
					whiteCarbon: {
						prop: "elem",
						map: c.whiteCarbon
					},
					orangeCarbon: {
						prop: "elem",
						map: c.orangeCarbon
					},
					yellowCarbon: {
						prop: "elem",
						map: c.yellowCarbon
					},
					blueCarbon: {
						prop: "elem",
						map: c.blueCarbon
					}
				};
			},
			"./src/exporter.js"(e) {
				typeof e.exports == "object" && (e.exports = window.$3Dmol);
			},
			"./src/glcartoon.ts"(e, t, n) {
				n.r(t), n.d(t, {
					drawCartoon: () => O,
					subdivide_spline: () => u
				});
				var r = n("./src/WebGL/math/index.ts"), i = n("./src/WebGL/shapes/index.ts"), a = n("./src/WebGL/index.ts"), o = n("./src/Gradient.ts"), s = n("./src/colors.ts"), c = n("./src/GLDraw.ts"), l = n("./src/utilities.ts");
				function u(e, t) {
					var n = [], i = e;
					i = [], i.push(e[0]);
					var a, o, s, c, l, u, d, f, p;
					for (a = 1, o = e.length - 1; a < o; a++) if (l = e[a], u = e[a + 1], l.smoothen) {
						var m = new r.Vector3((l.x + u.x) / 2, (l.y + u.y) / 2, (l.z + u.z) / 2);
						m.atom = l.atom, i.push(m);
					} else i.push(l);
					for (i.push(e[e.length - 1]), a = -1, s = i.length; a <= s - 3; a++) if (c = i[a === -1 ? 0 : a], l = i[a + 1], u = i[a + 2], d = i[a === s - 3 ? s - 1 : a + 3], f = new r.Vector3().subVectors(u, c).multiplyScalar(.5), p = new r.Vector3().subVectors(d, l).multiplyScalar(.5), !u.skip) for (var h = 0; h < t; h++) {
						var g = 1 / t * h, _ = l.x + g * f.x + g * g * (-3 * l.x + 3 * u.x - 2 * f.x - p.x) + g * g * g * (2 * l.x - 2 * u.x + f.x + p.x), v = l.y + g * f.y + g * g * (-3 * l.y + 3 * u.y - 2 * f.y - p.y) + g * g * g * (2 * l.y - 2 * u.y + f.y + p.y), y = l.z + g * f.z + g * g * (-3 * l.z + 3 * u.z - 2 * f.z - p.z) + g * g * g * (2 * l.z - 2 * u.z + f.z + p.z), b = new r.Vector3(_, v, y);
						b.atom = h < t / 2 ? l.atom : u.atom, n.push(b);
					}
					return n.push(i[i.length - 1]), n;
				}
				let d = .5, f = 1.3, p = .8, m = .4, h = .4;
				function g(e, t, n, r) {
					for (var i, a, o, c, l = 0, u = t.length; l < u; l++) {
						c = Math.round(l * (r.length - 1) / u), o = s.CC.color(r[c]);
						var d = e.updateGeoGroup(2), f = d.vertexArray, p = d.colorArray, m = d.faceArray;
						i = d.vertices, a = i * 3, f[a] = t[l].x, f[a + 1] = t[l].y, f[a + 2] = t[l].z, f[a + 3] = n[l].x, f[a + 4] = n[l].y, f[a + 5] = n[l].z;
						for (var h = 0; h < 6; ++h) p[a + 3 * h] = o.r, p[a + 1 + 3 * h] = o.g, p[a + 2 + 3 * h] = o.b;
						if (l > 0) {
							var g = [
								i,
								i + 1,
								i - 1,
								i - 2
							], _ = d.faceidx;
							m[_] = g[0], m[_ + 1] = g[1], m[_ + 2] = g[3], m[_ + 3] = g[1], m[_ + 4] = g[2], m[_ + 5] = g[3], d.faceidx += 6;
						}
						d.vertices += 2;
					}
				}
				function _(e, t, n, r, a, o, c) {
					var l, d, f = t.length, p;
					if (f < 2 || t[0].length < 2) return;
					for (l = 0; l < f; l++) t[l] = u(t[l], r);
					if (p = t[0].length, !a) return g(e, t[0], t[f - 1], n);
					var m, h, _, v, y, b, x = [], S = [], C = [];
					for (d = 0; d < f; d++) x.push(.25 + 1.5 * Math.sqrt((f - 1) * d - d ** 2) / (f - 1)), S.push(.5), C.push(2 * ((d / f) ** 2 - d / f) + .6);
					var w = [];
					for (d = 0; d < f * 2 - 1; d++) w[d] = [
						d,
						d + 1,
						d + 1 - 2 * f,
						d - 2 * f
					];
					w[f * 2 - 1] = [
						d,
						d + 1 - 2 * f,
						d + 1 - 4 * f,
						d - 2 * f
					];
					var T, E, D, O, k, A, j, M, N, P;
					let F = e.updateGeoGroup();
					for (l = 0; l < p; l++) {
						let r = e.groups, o = !1;
						F = e.updateGeoGroup(2 * f), r != e.groups && l > 0 && (--l, o = !0), A = Math.round(l * (n.length - 1) / p), k = s.CC.color(n[A]), y = _, b = v, _ = [], v = [], m = [], t[0][l].atom !== void 0 && (O = t[0][l].atom, c === "oval" ? h = x : c === "rectangle" ? h = S : c === "parabola" && (h = C)), h ||= S;
						var I, L;
						for (d = 0; d < f; d++) I = l < p - 1 ? t[d][l + 1].clone().sub(t[d][l]) : t[d][l - 1].clone().sub(t[d][l]).negate(), L = d < f - 1 ? t[d + 1][l].clone().sub(t[d][l]) : t[d - 1][l].clone().sub(t[d][l]).negate(), m[d] = L.cross(I).normalize().multiplyScalar(a * h[d]);
						for (d = 0; d < f; d++) _[d] = t[d][l].clone().add(m[d].clone().negate());
						for (d = 0; d < f; d++) v[d] = t[d][l].clone().add(m[d]);
						for (j = F.vertexArray, M = F.colorArray, N = F.faceArray, T = F.vertices, E = T * 3, d = 0; d < f; d++) j[E + 3 * d + 0] = _[d].x, j[E + 3 * d + 1] = _[d].y, j[E + 3 * d + 2] = _[d].z;
						for (d = 0; d < f; d++) j[E + 3 * d + 0 + 3 * f] = v[f - 1 - d].x, j[E + 3 * d + 1 + 3 * f] = v[f - 1 - d].y, j[E + 3 * d + 2 + 3 * f] = v[f - 1 - d].z;
						for (d = 0; d < 2 * f; ++d) M[E + 3 * d + 0] = k.r, M[E + 3 * d + 1] = k.g, M[E + 3 * d + 2] = k.b;
						if (l > 0 && !o) {
							for (d = 0; d < f * 2; d++) P = [
								T + w[d][0],
								T + w[d][1],
								T + w[d][2],
								T + w[d][3]
							], D = F.faceidx, N[D] = P[0], N[D + 1] = P[1], N[D + 2] = P[3], N[D + 3] = P[1], N[D + 4] = P[2], N[D + 5] = P[3], F.faceidx += 6;
							if (O.clickable || O.hoverable) {
								var R = [];
								for (d in R.push(new i.Triangle(y[0], _[0], _[f - 1])), R.push(new i.Triangle(y[0], _[f - 1], y[f - 1])), R.push(new i.Triangle(y[f - 1], _[f - 1], v[f - 1])), R.push(new i.Triangle(y[f - 1], v[f - 1], b[f - 1])), R.push(new i.Triangle(v[0], b[0], b[f - 1])), R.push(new i.Triangle(v[f - 1], v[0], b[f - 1])), R.push(new i.Triangle(_[0], y[0], b[0])), R.push(new i.Triangle(v[0], _[0], b[0])), R) O.intersectionShape.triangle.push(R[d]);
							}
						}
						F.vertices += 2 * f;
					}
					for (j = F.vertexArray, M = F.colorArray, N = F.faceArray, T = F.vertices, E = T * 3, D = F.faceidx, l = 0; l < f - 1; l++) P = [
						l,
						l + 1,
						2 * f - 2 - l,
						2 * f - 1 - l
					], D = F.faceidx, N[D] = P[0], N[D + 1] = P[1], N[D + 2] = P[3], N[D + 3] = P[1], N[D + 4] = P[2], N[D + 5] = P[3], F.faceidx += 6;
					for (l = 0; l < f - 1; l++) P = [
						T - 1 - l,
						T - 2 - l,
						T - 2 * f + l + 1,
						T - 2 * f + l
					], D = F.faceidx, N[D] = P[0], N[D + 1] = P[1], N[D + 2] = P[3], N[D + 3] = P[1], N[D + 4] = P[2], N[D + 5] = P[3], F.faceidx += 6;
				}
				function v(e, t, n, r, a, o) {
					if (!(t.length < 2)) {
						var c = t[0], l = t[t.length - 1];
						if (c = u(c, r), l = u(l, r), !a) return g(e, c, l, n);
						var d = [], f, p, m, h, _, v = [
							[
								0,
								2,
								-6,
								-8
							],
							[
								-4,
								-2,
								6,
								4
							],
							[
								7,
								-1,
								-5,
								3
							],
							[
								-3,
								5,
								1,
								-7
							]
						], y, b, x, S, C, w, T, E, D, O, k, A, j, M, N, P, F;
						for (E = 0, D = c.length; E < D; E++) {
							if (C = Math.round(E * (n.length - 1) / D), S = s.CC.color(n[C]), d.push(p = c[E]), d.push(p), d.push(m = l[E]), d.push(m), E < D - 1) {
								var I = c[E + 1].clone().sub(c[E]);
								f = l[E].clone().sub(c[E]).cross(I).normalize().multiplyScalar(a);
							}
							for (d.push(h = c[E].clone().add(f)), d.push(h), d.push(_ = l[E].clone().add(f)), d.push(_), p.atom !== void 0 && (w = p.atom), M = e.updateGeoGroup(8), N = M.vertexArray, P = M.colorArray, F = M.faceArray, y = M.vertices, b = y * 3, N[b] = p.x, N[b + 1] = p.y, N[b + 2] = p.z, N[b + 3] = p.x, N[b + 4] = p.y, N[b + 5] = p.z, N[b + 6] = m.x, N[b + 7] = m.y, N[b + 8] = m.z, N[b + 9] = m.x, N[b + 10] = m.y, N[b + 11] = m.z, N[b + 12] = h.x, N[b + 13] = h.y, N[b + 14] = h.z, N[b + 15] = h.x, N[b + 16] = h.y, N[b + 17] = h.z, N[b + 18] = _.x, N[b + 19] = _.y, N[b + 20] = _.z, N[b + 21] = _.x, N[b + 22] = _.y, N[b + 23] = _.z, O = 0; O < 8; ++O) P[b + 3 * O] = S.r, P[b + 1 + 3 * O] = S.g, P[b + 2 + 3 * O] = S.b;
							if (E > 0) {
								var L = T !== void 0 && w !== void 0 && T.serial !== w.serial;
								for (O = 0; O < 4; O++) {
									var R = [
										y + v[O][0],
										y + v[O][1],
										y + v[O][2],
										y + v[O][3]
									];
									if (x = M.faceidx, F[x] = R[0], F[x + 1] = R[1], F[x + 2] = R[3], F[x + 3] = R[1], F[x + 4] = R[2], F[x + 5] = R[3], M.faceidx += 6, w.clickable || T.clickable || w.hoverable || T.hoverable) {
										var z = d[R[3]].clone(), B = d[R[0]].clone(), V = d[R[2]].clone(), H = d[R[1]].clone();
										if (z.atom = d[R[3]].atom || null, V.atom = d[R[2]].atom || null, B.atom = d[R[0]].atom || null, H.atom = d[R[1]].atom || null, L) {
											var U = z.clone().add(B).multiplyScalar(.5), W = V.clone().add(H).multiplyScalar(.5), G = z.clone().add(H).multiplyScalar(.5);
											O % 2 == 0 ? ((T.clickable || T.hoverable) && (k = new i.Triangle(U, G, z), A = new i.Triangle(W, V, G), j = new i.Triangle(G, V, z), T.intersectionShape.triangle.push(k), T.intersectionShape.triangle.push(A), T.intersectionShape.triangle.push(j)), (w.clickable || w.hoverable) && (k = new i.Triangle(B, H, G), A = new i.Triangle(H, W, G), j = new i.Triangle(B, G, U), w.intersectionShape.triangle.push(k), w.intersectionShape.triangle.push(A), w.intersectionShape.triangle.push(j))) : ((w.clickable || w.hoverable) && (k = new i.Triangle(U, G, z), A = new i.Triangle(W, V, G), j = new i.Triangle(G, V, z), w.intersectionShape.triangle.push(k), w.intersectionShape.triangle.push(A), w.intersectionShape.triangle.push(j)), (T.clickable || T.hoverable) && (k = new i.Triangle(B, H, G), A = new i.Triangle(H, W, G), j = new i.Triangle(B, G, U), T.intersectionShape.triangle.push(k), T.intersectionShape.triangle.push(A), T.intersectionShape.triangle.push(j)));
										} else (w.clickable || w.hoverable) && (k = new i.Triangle(B, H, z), A = new i.Triangle(H, V, z), w.intersectionShape.triangle.push(k), w.intersectionShape.triangle.push(A));
									}
								}
							}
							M.vertices += 8, T = w;
						}
						var ee = d.length - 8;
						for (M = e.updateGeoGroup(8), N = M.vertexArray, P = M.colorArray, F = M.faceArray, y = M.vertices, b = y * 3, x = M.faceidx, E = 0; E < 4; E++) {
							d.push(d[E * 2]), d.push(d[ee + E * 2]);
							var te = d[E * 2], ne = d[ee + E * 2];
							N[b + 6 * E] = te.x, N[b + 1 + 6 * E] = te.y, N[b + 2 + 6 * E] = te.z, N[b + 3 + 6 * E] = ne.x, N[b + 4 + 6 * E] = ne.y, N[b + 5 + 6 * E] = ne.z, P[b + 6 * E] = S.r, P[b + 1 + 6 * E] = S.g, P[b + 2 + 6 * E] = S.b, P[b + 3 + 6 * E] = S.r, P[b + 4 + 6 * E] = S.g, P[b + 5 + 6 * E] = S.b;
						}
						ee += 8, k = [
							y,
							y + 2,
							y + 6,
							y + 4
						], A = [
							y + 1,
							y + 5,
							y + 7,
							y + 3
						], F[x] = k[0], F[x + 1] = k[1], F[x + 2] = k[3], F[x + 3] = k[1], F[x + 4] = k[2], F[x + 5] = k[3], F[x + 6] = A[0], F[x + 7] = A[1], F[x + 8] = A[3], F[x + 9] = A[1], F[x + 10] = A[2], F[x + 11] = A[3], M.faceidx += 12, M.vertices += 8;
					}
				}
				function y(e, t, n, r, i, a, o) {
					(!o || o === "default") && (o = "rectangle"), o === "edged" ? v(e, t, n, r, i, a) : (o === "rectangle" || o === "oval" || o === "parabola") && _(e, t, n, r, i, a, o);
				}
				function b(e) {
					return e && e.elem === "C" && e.atom === "CA";
				}
				function x(e, t) {
					if (e && t && e.chain === t.chain) {
						if (!e.hetflag && !t.hetflag && e.reschain === t.reschain && (e.resi === t.resi || e.resi === t.resi - 1)) return !0;
						if (e.resi < t.resi) {
							var n = e.x - t.x, r = e.y - t.y, i = e.z - t.z, a = n * n + r * r + i * i;
							if (e.atom == "CA" && t.atom == "CA" && a < 16 || (e.atom == "P" || t.atom == "P") && a < 64) return !0;
						}
					}
					return !1;
				}
				function S(e, t, n, r, i) {
					if (t != null && t.vertices != 0) {
						i && (t.initTypedArrays(), t.setUpNormals());
						var o = new a.MeshDoubleLambertMaterial();
						o.vertexColors = a.Coloring.FaceColors, typeof n == "number" && n >= 0 && n < 1 && (o.transparent = !0, o.opacity = n), o.outline = r;
						var s = new a.Mesh(t, o);
						e.add(s);
					}
				}
				function C(e, t, n, i, a, o, s, c, l) {
					var u, p, h, g, _, v;
					if (!(!i || !a || !s)) {
						var y = a.sub(i);
						y.normalize();
						var b = c[l];
						for (p = l + 1; p < c.length && (b = c[p], b.atom != s.atom); p++);
						if (b = b ? new r.Vector3(b.x, b.y, b.z) : new r.Vector3(0, 0, 0), b.sub(i), s.ss === "arrow start") {
							var x = b.clone().multiplyScalar(.3).cross(a);
							i.add(x);
							var S = b.clone().cross(y).normalize();
							y.rotateAboutVector(S, .43);
						}
						for (s.style.cartoon.ribbon ? u = s.style.cartoon.thickness || m : s.style.cartoon.width ? u = s.style.cartoon.width : s.ss === "c" ? u = s.atom === "P" ? .8 : d : s.ss === "arrow start" ? (u = f, _ = !0) : u = s.ss === "arrow end" || s.ss === "h" && s.style.cartoon.tubes || s.ss === "tube start" ? d : f, o != null && y.dot(o) < 0 && y.negate(), y.multiplyScalar(u), p = 0; p < t; p++) h = -1 + p * 2 / (t - 1), g = new r.Vector3(i.x + h * y.x, i.y + h * y.y, i.z + h * y.z), g.atom = s, n && s.ss === "s" && (g.smoothen = !0), e[p].push(g);
						if (_) for (y.multiplyScalar(2), p = 0; p < t; p++) h = -1 + p * 2 / (t - 1), g = new r.Vector3(i.x + h * y.x, i.y + h * y.y, i.z + h * y.z), g.atom = s, g.smoothen = !1, g.skip = !0, e[p].push(g);
						return v = s.style.cartoon.style || "default", e.style ? e.style != v && (console.log("Warning: a cartoon chain's strand-style is ambiguous"), e.style = "default") : e.style = v, (s.ss === "arrow start" || s.ss === "arrow end") && (s.ss = "s"), _;
					}
				}
				let w = {
					C: !0,
					CA: !0,
					O: !0,
					P: !0,
					OP2: !0,
					O2P: !0,
					"O5'": !0,
					"O3'": !0,
					"C5'": !0,
					"C2'": !0,
					"O5*": !0,
					"O3*": !0,
					"C5*": !0,
					"C2*": !0,
					N1: !0,
					N3: !0
				}, T = {
					DA: !0,
					DG: !0,
					A: !0,
					G: !0
				}, E = {
					DT: !0,
					DC: !0,
					U: !0,
					C: !0,
					T: !0
				}, D = {
					DA: !0,
					DG: !0,
					A: !0,
					G: !0,
					DT: !0,
					DC: !0,
					U: !0,
					C: !0,
					T: !0
				};
				function O(e, t, n, u = 10) {
					let d = u, f = u;
					var p, g, _, v, O, k, A, j, M, N, P, F, I, L, R, z, B, V, H = new a.Geometry(!0), U = new a.Geometry(!0), W = [], G = [], ee = 1, te = !1, ne = {};
					for (var re in o.Gradient.builtinGradients) o.Gradient.builtinGradients.hasOwnProperty(re) && (ne[re] = new o.Gradient.builtinGradients[re](n[1], n[0]));
					var ie = function(e, t) {
						return n && t.color === "spectrum" ? t.colorscheme in ne ? ne[t.colorscheme].valueToHex(e.resi) : ne.sinebow.valueToHex(e.resi) : (0, l.getColorFromStyle)(e, t).getHex();
					};
					for (j = 0; j < d; j++) G[j] = [];
					var K = !1, ae = !1, oe = [];
					for (j in t) {
						if (v = t[j], v.elem === "C" && v.atom === "CA") {
							var q = x(_, v);
							q && v.ss === "s" ? K = !0 : K &&= (_ && g && _.style.cartoon.arrows && g.style.cartoon.arrows && (_.ss = "arrow end", g.ss = "arrow start"), !1), q && (_.ss === "h" || _.ss == "tube start") && _.style.cartoon.tubes ? !ae && _.ss != "tube start" && v.style.cartoon.tubes && (v.ss = "tube start", ae = !0) : ae &&= (_.ss === "tube start" ? _.ss = "tube end" : g && g.style.cartoon.tubes && (g.ss = "tube end"), !1), g = _, _ = v;
						}
						v && v.atom in w && oe.push(v);
					}
					ae && _.style.cartoon.tubes && (_.ss = "tube end", ae = !1);
					var J = function(t) {
						G[0].length > 0 && y(U, G, W, f, A, ee, G.style);
						var n = [], r = null;
						if (t) {
							for (j = 0; j < d; j++) n[j] = G[j][G[j].length - 1];
							r = W[W.length - 1];
						}
						for (G = [], j = 0; j < d; j++) G[j] = [];
						if (W = [], t) {
							for (j = 0; j < d; j++) G[j].push(n[j]);
							W.push(r);
						}
						S(e, U, ee, te, !0), S(e, H, ee, te, !1), U = new a.Geometry(!0), H = new a.Geometry(!0);
					};
					_ = void 0;
					let Y = [];
					for (var se = 0; se < oe.length; se++) {
						v = oe[se];
						var ce = v.resn.trim(), X = ce in D;
						if (ee = 1, p = v.style.cartoon, _ && _.style.cartoon && (ee = _.style.cartoon.opacity), _ && _.style.cartoon && _.style.cartoon.outline && (te = _.style.cartoon.outline), _ && _.style.cartoon && (!v.style.cartoon || _.style.cartoon.opacity != v.style.cartoon.opacity) && J(_.chain == v.chain), _ && v && !x(_, v) && _.chain && _.chain == v.chain && !_.hetflag && !v.hetflag && _.reschain + 1 == v.reschain && Y.push([_, v]), p.style === "trace") {
							if (!v.hetflag && (v.elem === "C" && v.atom === "CA" || X && v.atom === "P" || v.atom === "BB")) {
								if (k = ie(v, p), A = (0, l.isNumeric)(p.thickness) ? p.thickness : m, x(_, v)) {
									if (k == O) {
										var le = s.CC.color(k);
										c.GLDraw.drawCylinder(H, _, v, A, le, 2, 2);
									} else {
										var Z = new r.Vector3().addVectors(_, v).multiplyScalar(.5), Q = s.CC.color(O), ue = s.CC.color(k);
										c.GLDraw.drawCylinder(H, _, Z, A, Q, 2, 0), c.GLDraw.drawCylinder(H, Z, v, A, ue, 0, 2);
									}
								}
								if ((v.clickable === !0 || v.hoverable) && v.intersectionShape !== void 0) {
									var de = new r.Vector3(v.x, v.y, v.z);
									v.intersectionShape.sphere.push(new i.Sphere(de, A));
								}
								_ = v, O = k;
							}
						} else {
							if (b(v) || X && (v.atom === "P" || v.atom.indexOf("O5") == 0)) {
								if (V) {
									if (v.ss === "tube end") V = !1, B = new r.Vector3(v.x, v.y, v.z), c.GLDraw.drawCylinder(H, z, B, 2, s.CC.color(O), 1, 1), v.ss = "h";
									else if (_.chain != v.chain || _.ss === "tube end") V = !1, _.ss = "h", B = new r.Vector3(_.x, _.y, _.z), c.GLDraw.drawCylinder(H, z, B, 2, s.CC.color(O), 1, 1);
									else continue;
								}
								if (_ && (!x(_, v) || _.ss === "tube start")) {
									for (_.ss === "tube start" && (V = !0, z = new r.Vector3(_.x, _.y, _.z), _.ss = "h"), R &&= (L = F ? new r.Vector3().addVectors(_, F).multiplyScalar(.5) : new r.Vector3(_.x, _.y, _.z), c.GLDraw.drawCylinder(H, L, R, h, s.CC.color(R.color), 0, 2), C(G, d, !0, F, I, P, _, oe, se), W.push(k), L = null, null), G[0].length > 0 && y(U, G, W, f, A, ee, G.style), G = [], j = 0; j < d; j++) G[j] = [];
									W = [];
								}
								if (_ === void 0 || _.rescode != v.rescode || _.resi != v.resi) {
									if (R && _ != null) {
										L = new r.Vector3().addVectors(_, v).multiplyScalar(.5);
										var $ = L.clone().sub(R).multiplyScalar(.02);
										L.add($), c.GLDraw.drawCylinder(H, L, R, h, s.CC.color(R.color), 0, 2), L = null, R = null;
									}
									k = ie(v, p), W.push(k), A = (0, l.isNumeric)(p.thickness) ? p.thickness : m, _ = v, M = new r.Vector3(_.x, _.y, _.z), M.resi = _.resi, O = k;
								}
								(v.clickable === !0 || v.hoverable === !0) && (v.intersectionShape === void 0 || v.intersectionShape.triangle === void 0) && (v.intersectionShape = {
									sphere: null,
									cylinder: [],
									line: [],
									triangle: []
								});
							} else _ != null && (b(_) && v.atom === "O" || X && _.atom === "P" && (v.atom === "OP2" || v.atom === "O2P") || X && _.atom.indexOf("O5") == 0 && v.atom.indexOf("C5") == 0) ? (N = new r.Vector3(v.x, v.y, v.z), N.resi = v.resi, (v.atom === "OP2" || v.atom === "O2P") && (I = new r.Vector3(v.x, v.y, v.z))) : X && v.atom.indexOf("O3") == 0 ? F = new r.Vector3(v.x, v.y, v.z) : (v.atom === "N1" && ce in T || v.atom === "N3" && ce in E) && (R = new r.Vector3(v.x, v.y, v.z), R.color = (0, l.getColorFromStyle)(v, p).getHex());
							N && M && N.resi === M.resi && (C(G, d, !0, M, N, P, _, oe, se), P = N, M = null, N = null, W.push(k));
						}
					}
					R && (L = F ? new r.Vector3().addVectors(_, F).multiplyScalar(.5) : new r.Vector3(_.x, _.y, _.z), c.GLDraw.drawCylinder(H, L, R, h, s.CC.color(R.color), 0, 2), C(G, d, !0, F, I, P, _, oe, se), W.push(k)), J(!1);
					var fe = function(e, t) {
						if (e.style.cartoon.gapcutoff && e.style.cartoon.gapcutoff == t.style.cartoon.gapcutoff) {
							let i = e.style.cartoon.gapcutoff, a = t.resi - e.resi;
							if (a > 0 && a < i) {
								let i = .25, o = t.x - e.x, u = t.y - e.y, d = t.z - e.z, f = Math.sqrt(o * o + u * u + d * d), p = f / (2 * a), m = new r.Vector3(e.x, e.y, e.z), h = f / p, g = new r.Vector3((t.x - e.x) / h, (t.y - e.y) / h, (t.z - e.z) / h);
								m.add({
									x: g.x / 2,
									y: g.y / 2,
									z: g.z / 2
								});
								let _ = m.clone().add(g);
								g.multiplyScalar(2);
								let v = (0, l.extend)({}, e);
								for (var n = 0; n < a; n++) {
									v.resi += 1;
									let e = ie(v, v.style.cartoon);
									c.GLDraw.drawCylinder(H, m, _, .25, s.CC.color(e), c.CAP.FLAT, c.CAP.FLAT), m.add(g), _.add(g);
								}
								J(!1);
							}
						}
					};
					for (let e of Y) fe(e[0], e[1]);
				}
			},
			"./src/index.ts"(e, t, n) {
				n.r(t), n.d(t, {
					CAP: () => r.CAP,
					CC: () => r.CC,
					CONTEXTS_PER_VIEWPORT: () => r.CONTEXTS_PER_VIEWPORT,
					Color: () => r.Color,
					CustomLinear: () => r.CustomLinear,
					Cylinder: () => r.Cylinder,
					GLDraw: () => r.GLDraw,
					GLModel: () => r.GLModel,
					GLShape: () => r.GLShape,
					GLViewer: () => r.GLViewer,
					GLVolumetricRender: () => r.GLVolumetricRender,
					Gradient: () => r.Gradient,
					GradientType: () => r.GradientType,
					Label: () => r.Label,
					LabelCount: () => r.LabelCount,
					MarchingCube: () => r.MarchingCube,
					MarchingCubeInitializer: () => r.MarchingCubeInitializer,
					Matrix3: () => r.Matrix3,
					Matrix4: () => r.Matrix4,
					Parsers: () => r.Parsers,
					PausableTimer: () => r.PausableTimer,
					PointGrid: () => r.PointGrid,
					ProteinSurface: () => r.ProteinSurface,
					Quaternion: () => r.Quaternion,
					ROYGB: () => r.ROYGB,
					RWB: () => r.RWB,
					Ray: () => r.Ray,
					Sinebow: () => r.Sinebow,
					Sphere: () => r.Sphere,
					SurfaceType: () => r.SurfaceType,
					Triangle: () => r.Triangle,
					Vector2: () => r.Vector2,
					Vector3: () => r.Vector3,
					VolumeData: () => r.VolumeData,
					adjustVolumeStyle: () => r.adjustVolumeStyle,
					applyPartialCharges: () => r.applyPartialCharges,
					autoinit: () => r.autoinit,
					autoload: () => r.autoload,
					base64ToArray: () => r.base64ToArray,
					bondLength: () => r.bondLength,
					builtinColorSchemes: () => r.builtinColorSchemes,
					builtinGradients: () => r.builtinGradients,
					chains: () => r.chains,
					clamp: () => r.clamp,
					conversionMatrix3: () => r.conversionMatrix3,
					createStereoViewer: () => r.createStereoViewer,
					createViewer: () => r.createViewer,
					createViewerGrid: () => r.createViewerGrid,
					deepCopy: () => r.deepCopy,
					degToRad: () => r.degToRad,
					download: () => r.download,
					drawCartoon: () => r.drawCartoon,
					elementColors: () => r.elementColors,
					extend: () => r.extend,
					get: () => r.get,
					getAtomProperty: () => r.getAtomProperty,
					getColorFromStyle: () => r.getColorFromStyle,
					getElement: () => r.getElement,
					getExtent: () => r.getExtent,
					getGradient: () => r.getGradient,
					getPropertyRange: () => r.getPropertyRange,
					getbin: () => r.getbin,
					htmlColors: () => r.htmlColors,
					inflateString: () => r.inflateString,
					isEmptyObject: () => r.isEmptyObject,
					isNumeric: () => r.isNumeric,
					makeFunction: () => r.makeFunction,
					mergeGeos: () => r.mergeGeos,
					normalizeValue: () => r.normalizeValue,
					partialCharges: () => r.partialCharges,
					processing_autoinit: () => r.processing_autoinit,
					residues: () => r.residues,
					setBondLength: () => r.setBondLength,
					setSyncSurface: () => r.setSyncSurface,
					specStringToObject: () => r.specStringToObject,
					splitMesh: () => r.splitMesh,
					ssColors: () => r.ssColors,
					subdivide_spline: () => r.subdivide_spline,
					syncSurface: () => r.syncSurface,
					viewers: () => r.viewers
				});
				var r = n("./src/3Dmol.ts");
				window && (window.$3Dmol = t);
			},
			"./src/parsers/BCIF.ts"(e, t, n) {
				n.r(t), n.d(t, { BCIF: () => m });
				var r = n("./src/utilities.ts"), i = n("./src/parsers/utils/computeSecondaryStructure.ts"), a = n("./src/parsers/utils/processSymmetries.ts"), o = n("./src/parsers/cifutils/category.ts"), s = n("./src/parsers/utils/assignPDBBonds.ts"), c = n("./src/WebGL/index.ts"), l = n("./src/parsers/utils/isEmpty.ts"), u = n("./src/vendor/mmtf.js");
				class d {
					constructor(e) {
						if (this.C = {}, e) {
							let t = e.getField("comp_id"), n = e.getField("atom_id_1"), r = e.getField("atom_id_2"), i = e.getField("value_order");
							for (let e = 0; e < t.length; e++) {
								let a = t[e], o = n[e], s = r[e], c = i[e], l = 1;
								c == "doub" ? l = 2 : c == "trip" && (l = 3), this.C[a] ?? (this.C[a] = {}), this.C[a][o] ?? (this.C[a][o] = {}), this.C[a][s] ?? (this.C[a][s] = {}), this.C[a][o][s] = l, this.C[a][s][o] = l;
							}
						}
					}
					order(e, t, n) {
						return this.C[e] !== void 0 && this.C[e][t] !== void 0 && this.C[e][t][n] !== void 0 ? this.C[e][t][n] : 0;
					}
				}
				class f {
					constructor(e) {
						if (this.C = [], e) {
							let t = e.getField("conn_type_id"), n = e.getField("ptnr1_label_asym_id"), r = e.getField("ptnr1_label_seq_id"), i = e.getField("ptnr1_label_comp_id"), a = e.getField("ptnr1_label_atom_id"), o = e.getField("ptnr2_label_asym_id"), s = e.getField("ptnr2_label_seq_id"), c = e.getField("ptnr2_label_comp_id"), l = e.getField("ptnr2_label_atom_id"), u = e.getField("pdbx_value_order");
							for (let e = 0; e < t.length; e++) if (t[e] == "disulf" || t[e] == "covale") {
								let t = u ? u[e] == "" ? 1 : parseInt(u[e]) : 1;
								this.C.push([
									[
										n[e],
										r[e],
										i[e],
										a[e]
									],
									[
										o[e],
										s[e],
										c[e],
										l[e]
									],
									t
								]);
							}
						}
					}
				}
				class p {
					constructor() {
						this.R = {};
					}
					add(e) {
						this.R[e.lchain] ?? (this.R[e.lchain] = {}), this.R[e.lchain][e.lresi] ?? (this.R[e.lchain][e.lresi] = {}), this.R[e.lchain][e.lresi][e.lresn] ?? (this.R[e.lchain][e.lresi][e.lresn] = []), this.R[e.lchain][e.lresi][e.lresn].push(e), this.R[e.lchain][e.lresi][e.lresn][e.atom] = e;
					}
					geta([e, t, n, r]) {
						if (this.R[e] !== void 0 && this.R[e][t] !== void 0 && this.R[e][t][n] !== void 0) return this.R[e][t][n][r];
					}
					setBonds(e, t) {
						for (let t in this.R) for (let n in this.R[t]) for (let r in this.R[t][n]) {
							let i = this.R[t][n][r];
							for (let t = 0; t < i.length; t++) for (let n = t + 1; n < i.length; n++) {
								let a = i[t], o = i[n], s = e.order(r, a.atom, o.atom);
								a.altLoc != o.altLoc && a.altLoc != "" && o.altLoc != "" && (s = 0), s > 0 && (a.bonds.push(o.index), o.bonds.push(a.index), a.bondOrder.push(s), o.bondOrder.push(s));
							}
						}
						for (let e of t.C) {
							let t = e[0], n = e[1], r = e[2], i = this.geta(t), a = this.geta(n);
							i != null && a != null && (i.bonds.push(a.index), a.bonds.push(i.index), i.bondOrder.push(r), a.bondOrder.push(r));
						}
					}
				}
				function m(e, t) {
					var n = !t.keepH, m = t.altLoc ? t.altLoc : "A", h = !t.noComputeSecondaryStructure;
					let g = !t.doAssembly, _ = t.assignBonds === void 0 || t.assignBonds;
					if (typeof e == "string") try {
						e = (0, r.base64ToArray)(e);
					} catch {
						e = new TextEncoder().encode(e);
					}
					else e = new Uint8Array(e);
					var v = u.decodeMsgpack(e);
					v == 31 && (e = (0, r.inflateString)(e, !1), v = u.decodeMsgpack(e));
					var y = [], b = y.modelData = [], x = v.dataBlocks.length;
					if (x == 0) return y;
					t.multimodel || (x = 1);
					for (let e = 0; e < x; e++) {
						let r = y.length, i = [];
						b.push({ symmetries: [] }), y.push([]);
						let a = v.dataBlocks[e], s = Object.create(null);
						for (let e of a.categories) s[e.name.substr(1)] = (0, o.Category)(e);
						let u = {}, h = s.struct_conf;
						if (h) {
							let e = h.getField("conf_type_id"), t = h.getField("beg_label_asym_id"), n = h.getField("beg_label_seq_id"), r = h.getField("end_label_seq_id");
							for (let i = 0; i < e.length; i++) if (e[i].startsWith("H")) {
								let e = t[i], a = n[i], o = r[i];
								e in u || (u[e] = {}), u[e][a] = "h1";
								for (let t = a + 1; t < o; t++) u[e][t] = "h";
								u[e][o] = "h2";
							}
						}
						let _ = s.struct_sheet_range;
						if (_) {
							let e = _.getField("id"), t = _.getField("beg_label_asym_id"), n = _.getField("beg_label_seq_id"), r = _.getField("end_label_seq_id");
							for (let i = 0; i < e.length; i++) {
								let e = t[i], a = n[i], o = r[i];
								e in u || (u[e] = {}), u[e][a] = "s1";
								for (let t = a + 1; t < o; t++) u[e][t] = "s";
								u[e][o] = "s2";
							}
						}
						let S = s.pdbx_struct_oper_list, C = S.getField("id");
						if (C && !g) {
							let e = S.getField("matrix[1][1]"), t = S.getField("matrix[1][2]"), n = S.getField("matrix[1][3]"), r = S.getField("matrix[2][1]"), i = S.getField("matrix[2][2]"), a = S.getField("matrix[2][3]"), o = S.getField("matrix[3][1]"), s = S.getField("matrix[3][2]"), l = S.getField("matrix[3][3]"), u = S.getField("vector[1]"), d = S.getField("vector[2]"), f = S.getField("vector[3]");
							for (let p = 0; p < C.length; p++) {
								let m = new c.Matrix4(e[p], t[p], n[p], u[p], r[p], i[p], a[p], d[p], o[p], s[p], l[p], f[p]);
								b[b.length - 1].symmetries.push(m);
							}
						}
						let w = new d(s.chem_comp_bond), T = new p(), E = new f(s.struct_conn), D = s.atom_site, O = D.rowCount, k = D.getField("group_PDB"), A = D.getField("Cartn_x"), j = D.getField("Cartn_y"), M = D.getField("Cartn_z"), N = D.getField("auth_asym_id"), P = D.getField("label_asym_id"), F = D.getField("auth_seq_id"), I = D.getField("label_seq_id"), L = D.getField("auth_comp_id"), R = D.getField("label_comp_id"), z = D.getField("auth_atom_id"), B = D.getField("label_atom_id"), V = D.getField("type_symbol"), H = D.getField("B_iso_or_equiv"), U = D.getField("id"), W = D.getField("label_alt_id"), G = D.getField("pdbx_PDB_model_num"), ee = G ? G[0] : 0;
						for (let e = 0; e < O; e++) {
							if (k !== void 0 && k[e] === "TER") continue;
							if (G && G[e] != ee) {
								if (ee = G[e], t.multimodel) t.onemol || (y.push([]), b.push(b[b.length - 1]), ee = G[e], T.setBonds(w, E), T = new p());
								else break;
							}
							let r = {};
							r.x = A[e], r.y = j[e], r.z = M[e], r.chain = N ? N[e] : P ? P[e] : void 0, r.lchain = P ? P[e] : void 0, r.resi = F ? F[e] : I ? I[e] : void 0, r.lresi = I ? I[e] : void 0, r.resn = L ? L[e].trim() : R ? R[e].trim() : void 0, r.lresn = R ? R[e].trim() : void 0, r.atom = z ? z[e].replace(/"/gm, "") : B ? B[e].replace(/"/gm, "") : void 0, r.icode = W ? W[e] : void 0, r.altLoc = r.icode, r.hetflag = !k || k[e] === "HETA" || k[e] === "HETATM";
							let a = "X";
							V && (a = V[e].replace(/\(?\+?\d+.*/, "")), r.elem = a[0].toUpperCase() + a.substring(1, 2).toLowerCase(), H && (r.b = H[e]), !(n && r.elem == "H") && (r.altLoc == "" || r.altLoc == m || m == "*") && (r.bonds = [], r.ss = "c", r.serial = U[e], r.model = ee, r.bondOrder = [], r.properties = {}, r.index = y[y.length - 1].length, i[r.serial] = [y.length, r.index], y[y.length - 1].push(r), T.add(r));
						}
						if (T.setBonds(w, E), !(0, l.isEmpty)(u)) for (let e = r; e < y.length; e++) {
							let t = y[e];
							for (let e = 0; e < t.length; e++) {
								let n = t[e];
								if (n !== void 0 && n.lchain in u && n.lresi in u[n.lchain]) {
									let e = u[n.lchain][n.lresi];
									n.ss = e[0], e.length > 1 && (e[1] == "1" ? n.ssbegin = !0 : e[1] == "2" && (n.ssend = !0));
								}
							}
						}
						t.multimodel && e < x - 1 && (t.onemol || (y.push([]), b.push({ symmetries: [] })));
					}
					for (let e = 0; e < y.length; e++) _ && !(t.duplicateAssemblyAtoms && !t.dontConnectDuplicatedAtoms) && (0, s.assignPDBBonds)(y[e], t), h && (0, i.computeSecondaryStructure)(y[e], t.hbondCutoff), (0, a.processSymmetries)(b[e].symmetries, y[e], t, b[e].cryst), t.duplicateAssemblyAtoms && !t.dontConnectDuplicatedAtoms && _ && (0, s.assignPDBBonds)(y[e], t);
					return y;
				}
			},
			"./src/parsers/CDJSON.ts"(e, t, n) {
				n.r(t), n.d(t, { CDJSON: () => r });
				function r(e, t) {
					var n = [[]];
					typeof e == "string" && (e = JSON.parse(e));
					for (var r = e.m, i = r[0].a, a = r[0].b, o = r[0].s, s = t !== void 0 && t.parseStyle !== void 0 ? t.parseStyle : o !== void 0, c = n[n.length - 1].length, l = 0; l < i.length; l++) {
						var u = i[l], d = {};
						d.id = u.i, d.x = u.x, d.y = u.y, d.z = u.z || 0, d.bonds = [], d.bondOrder = [];
						var f = u.l || "C";
						d.elem = f[0].toUpperCase() + f.substring(1).toLowerCase(), d.serial = n[n.length - 1].length, s && (d.style = o[u.s || 0]), n[n.length - 1].push(d);
					}
					for (let e = 0; e < a.length; e++) {
						let t = a[e], r = t.b + c, i = t.e + c, o = t.o || 1, s = n[n.length - 1][r], l = n[n.length - 1][i];
						s.bonds.push(i), s.bondOrder.push(o), l.bonds.push(r), l.bondOrder.push(o);
					}
					return n;
				}
			},
			"./src/parsers/CIF.ts"(e, t, n) {
				n.r(t), n.d(t, { CIF: () => c });
				var r = n("./src/parsers/utils/computeSecondaryStructure.ts"), i = n("./src/parsers/utils/processSymmetries.ts"), a = n("./src/WebGL/index.ts"), o = n("./src/parsers/utils/assignPDBBonds.ts");
				let s = function(e, t, n, r) {
					return new a.Vector3(t, n, r).applyMatrix3(e);
				};
				function c(e, t = {}) {
					let n = [], c = !t.doAssembly, l = n.modelData = [], u = t.assignBonds === void 0 || t.assignBonds;
					function d(e, t) {
						let n = [], r = 0, i = 0;
						for (; i < e.length;) {
							for (; e.substring(i, i + t.length) !== t && i < e.length;) if (e[i] === "'") {
								for (i++; i < e.length && e[i] !== "'";) i++;
								for (; e.substring(i, i + t.length) !== t && i < e.length;) i++;
							} else if (e[i] === "\"") {
								for (i++; i < e.length && e[i] !== "\"";) i++;
								i++;
							} else i++;
							n.push(e.substring(r, i)), r = i += t.length;
						}
						return n;
					}
					let f = e.split(/\r?\n|\r/), p = [], m = !1;
					for (let e = 0; e < f.length; e++) {
						var h = f[e].split("#")[0];
						if (m ? h[0] === ";" && (m = !1) : h[0] === ";" && (m = !0), m || h !== "") {
							if (!m && (h = h.trim(), h[0] === "_")) {
								let e = h.split(/\s/)[0].indexOf(".");
								if (e > -1) {
									let t = h.split("");
									t[e] = "_", h = t.join(""), h = h.substring(0, e) + "_" + h.substring(e + 1);
								}
							}
							p.push(h);
						}
					}
					let g = 0;
					for (; g < p.length;) {
						for (; !p[g].startsWith("data_") || p[g] === "data_global";) g++;
						g++;
						let e = {};
						for (; g < p.length && !p[g].startsWith("data_");) if (p[g][0] === void 0) g++;
						else if (p[g][0] === "_") {
							let t = p[g].split(/\s/)[0].toLowerCase(), n = e[t] = e[t] || [], r = p[g].substring(p[g].indexOf(t) + t.length);
							if (r === "") {
								if (g++, p[g][0] === ";") {
									let e = p[g].substring(1);
									for (g++; p[g] !== ";";) e = e + "\n" + p[g], g++;
									n.push(e);
								} else n.push(p[g]);
							} else n.push(r.trim());
							g++;
						} else if (p[g].substring(0, 5) === "loop_") {
							g++;
							let t = [];
							for (; p[g] === "" || p[g][0] === "_";) {
								if (p[g] !== "") {
									let n = p[g].split(/\s/)[0].toLowerCase(), r = e[n] = e[n] || [];
									t.push(r);
								}
								g++;
							}
							let n = 0;
							for (; g < p.length && p[g][0] !== "_" && !p[g].startsWith("loop_") && !p[g].startsWith("data_");) {
								let e = d(p[g], " ");
								for (let r = 0; r < e.length; r++) e[r] !== "" && (t[n].push(e[r]), n = (n + 1) % t.length);
								g++;
							}
						} else g++;
						l.push({ symmetries: [] }), n.push([]);
						let t = e._atom_site_id === void 0 ? e._atom_site_label.length : e._atom_site_id.length, r;
						if (e._cell_length_a !== void 0) {
							let t = parseFloat(e._cell_length_a), n = parseFloat(e._cell_length_b), i = parseFloat(e._cell_length_c), o = parseFloat(e._cell_angle_alpha) || 90, s = parseFloat(e._cell_angle_beta) || 90, c = parseFloat(e._cell_angle_gamma) || 90;
							r = (0, a.conversionMatrix3)(t, n, i, o, s, c), l[l.length - 1].cryst = {
								a: t,
								b: n,
								c: i,
								alpha: o,
								beta: s,
								gamma: c
							};
						}
						for (let i = 0; i < t; i++) {
							if (e._atom_site_group_pdb !== void 0 && e._atom_site_group_pdb[i] === "TER") continue;
							let t = {};
							if (e._atom_site_cartn_x !== void 0) t.x = parseFloat(e._atom_site_cartn_x[i]), t.y = parseFloat(e._atom_site_cartn_y[i]), t.z = parseFloat(e._atom_site_cartn_z[i]);
							else {
								let n = s(r, parseFloat(e._atom_site_fract_x[i]), parseFloat(e._atom_site_fract_y[i]), parseFloat(e._atom_site_fract_z[i]));
								t.x = n.x, t.y = n.y, t.z = n.z;
							}
							t.chain = e._atom_site_auth_asym_id ? e._atom_site_auth_asym_id[i] : e._atom_site_label_asym_id ? e._atom_site_label_asym_id[i] : void 0, t.lchain = e._atom_site_label_asym_id ? e._atom_site_label_asym_id[i] : void 0, t.resi = e._atom_site_auth_seq_id ? parseInt(e._atom_site_auth_seq_id[i]) : e._atom_site_label_seq_id ? e._atom_site_label_seq_id[i] : void 0, t.resn = e._atom_site_auth_comp_id ? e._atom_site_auth_comp_id[i].trim() : e._atom_site_label_comp_id ? e._atom_site_label_comp_id[i].trim() : void 0, t.atom = e._atom_site_auth_atom_id ? e._atom_site_auth_atom_id[i].replace(/"/gm, "") : e._atom_site_label_atom_id ? e._atom_site_label_atom_id[i].replace(/"/gm, "") : void 0, t.hetflag = !e._atom_site_group_pdb || e._atom_site_group_pdb[i] === "HETA" || e._atom_site_group_pdb[i] === "HETATM", e._atom_site_b_iso_or_equiv && (t.b = parseFloat(e._atom_site_b_iso_or_equiv[i]));
							let a = "X";
							e._atom_site_type_symbol ? a = e._atom_site_type_symbol[i].replace(/\(?\+?\d+.*/, "") : e._atom_site_label && (a = e._atom_site_label[i].split("_")[0].replace(/\(?\d+.*/, "")), t.elem = a[0].toUpperCase() + a.substring(1, 2).toLowerCase(), t.bonds = [], t.ss = "c", t.serial = i, t.bondOrder = [], t.properties = {}, n[n.length - 1].push(t);
						}
						if (e._pdbx_struct_oper_list_id !== void 0 && !c) for (let t = 0; t < e._pdbx_struct_oper_list_id.length; t++) {
							let n = parseFloat(e["_pdbx_struct_oper_list_matrix[1][1]"][t]), r = parseFloat(e["_pdbx_struct_oper_list_matrix[1][2]"][t]), i = parseFloat(e["_pdbx_struct_oper_list_matrix[1][3]"][t]), o = parseFloat(e["_pdbx_struct_oper_list_vector[1]"][t]), s = parseFloat(e["_pdbx_struct_oper_list_matrix[2][1]"][t]), c = parseFloat(e["_pdbx_struct_oper_list_matrix[2][2]"][t]), u = parseFloat(e["_pdbx_struct_oper_list_matrix[2][3]"][t]), d = parseFloat(e["_pdbx_struct_oper_list_vector[2]"][t]), f = parseFloat(e["_pdbx_struct_oper_list_matrix[3][1]"][t]), p = parseFloat(e["_pdbx_struct_oper_list_matrix[3][2]"][t]), m = parseFloat(e["_pdbx_struct_oper_list_matrix[3][3]"][t]), h = parseFloat(e["_pdbx_struct_oper_list_vector[3]"][t]), g = new a.Matrix4(n, r, i, o, s, c, u, d, f, p, m, h);
							l[l.length - 1].symmetries.push(g);
						}
						let i = function(e) {
							let t = e.match("-");
							e = e.replace(/[-xyz]/g, "");
							let n = e.split("/"), r, i;
							return i = n[1] === void 0 ? 1 : parseInt(n[1]), r = n[0] === "" ? 1 : parseInt(n[0]), r / i * (t ? -1 : 1);
						};
						if (e._symmetry_equiv_pos_as_xyz !== void 0 && !c) for (let t = 0; t < e._symmetry_equiv_pos_as_xyz.length; t++) {
							let n = e._symmetry_equiv_pos_as_xyz[t].replace(/["' ]/g, "").split(",").map(function(e) {
								return e.replace(/-/g, "+-");
							}), o = new a.Matrix4(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1);
							for (let e = 0; e < 3; e++) {
								let t = n[e].split("+");
								for (let n = 0; n < t.length; n++) {
									let r = t[n];
									if (r === "") continue;
									let a = i(r);
									r.match("x") ? o.elements[e + 0] = a : r.match("y") ? o.elements[e + 4] = a : r.match("z") ? o.elements[e + 8] = a : o.elements[e + 12] = a;
								}
							}
							let s = r.getMatrix4(), c = new a.Matrix4().getInverse(s, !0);
							o = new a.Matrix4().multiplyMatrices(o, c), o = new a.Matrix4().multiplyMatrices(s, o), l[l.length - 1].symmetries.push(o);
						}
					}
					for (let e = 0; e < n.length; e++) u && !(t.duplicateAssemblyAtoms && !t.dontConnectDuplicatedAtoms) && (0, o.assignPDBBonds)(n[e], t), (0, r.computeSecondaryStructure)(n[e], t.hbondCutoff), (0, i.processSymmetries)(l[e].symmetries, n[e], t, l[e].cryst), t.duplicateAssemblyAtoms && !t.dontConnectDuplicatedAtoms && u && (0, o.assignPDBBonds)(n[e], t);
					return n;
				}
			},
			"./src/parsers/CUBE.ts"(e, t, n) {
				n.r(t), n.d(t, { CUBE: () => o });
				var r = n("./src/WebGL/index.ts"), i = n("./src/parsers/utils/assignBonds.ts"), a = n("./src/parsers/utils/anumToSymbol.ts");
				function o(e, t) {
					t ||= {};
					let n = [[]], o = e.split(/\r?\n/), s = t.assignBonds === void 0 || t.assignBonds;
					if (o.length < 6) return n;
					let c = o[2].replace(/^\s+/, "").replace(/\s+/g, " ").split(" "), l = Math.abs(parseFloat(c[0])), u = {
						origin: void 0,
						size: void 0,
						unit: void 0,
						matrix4: void 0,
						matrix: void 0
					}, d = u.origin = new r.Vector3(parseFloat(c[1]), parseFloat(c[2]), parseFloat(c[3]));
					c = o[3].replace(/^\s+/, "").replace(/\s+/g, " ").split(" "), c = o[3].replace(/^\s+/, "").replace(/\s+/g, " ").split(" ");
					let f = c[0] > 0 ? .529177 : 1;
					d.multiplyScalar(f);
					let p = Math.abs(c[0]), m = new r.Vector3(parseFloat(c[1]), parseFloat(c[2]), parseFloat(c[3])).multiplyScalar(f);
					c = o[4].replace(/^\s+/, "").replace(/\s+/g, " ").split(" ");
					let h = Math.abs(c[0]), g = new r.Vector3(parseFloat(c[1]), parseFloat(c[2]), parseFloat(c[3])).multiplyScalar(f);
					c = o[5].replace(/^\s+/, "").replace(/\s+/g, " ").split(" ");
					let _ = Math.abs(c[0]), v = new r.Vector3(parseFloat(c[1]), parseFloat(c[2]), parseFloat(c[3])).multiplyScalar(f);
					if (u.size = {
						x: p,
						y: h,
						z: _
					}, u.unit = new r.Vector3(m.x, g.y, v.z), m.y != 0 || m.z != 0 || g.x != 0 || g.z != 0 || v.x != 0 || v.y != 0) {
						u.matrix4 = new r.Matrix4(m.x, g.x, v.x, 0, m.y, g.y, v.y, 0, m.z, g.z, v.z, 0, 0, 0, 0, 1);
						let e = new r.Matrix4().makeTranslation(d.x, d.y, d.z);
						u.matrix4 = u.matrix4.multiplyMatrices(e, u.matrix4), u.matrix = u.matrix4.matrix3FromTopLeft(), u.origin = new r.Vector3(0, 0, 0), u.unit = new r.Vector3(1, 1, 1);
					}
					n.modelData = [{ cryst: u }], o = o.splice(6, l);
					for (var y = n[n.length - 1].length, b = y + o.length, x = y; x < b; ++x) {
						var S = {};
						S.serial = x;
						var C = o[x - y].replace(/^\s+/, "").replace(/\s+/g, " ").split(" ");
						S.elem = a.anumToSymbol[C[0]], S.x = parseFloat(C[2]) * f, S.y = parseFloat(C[3]) * f, S.z = parseFloat(C[4]) * f, S.hetflag = !0, S.bonds = [], S.bondOrder = [], S.properties = {}, n[n.length - 1].push(S);
					}
					if (s) for (let e = 0; e < n.length; e++) (0, i.assignBonds)(n[e], t);
					return n;
				}
			},
			"./src/parsers/GRO.ts"(e, t, n) {
				n.r(t), n.d(t, { GRO: () => a });
				var r = n("./src/parsers/utils/assignPDBBonds.ts"), i = n("./src/parsers/utils/atomNameToElem.ts");
				function a(e, t) {
					let n = [], a = e.split(/\r?\n|\r/);
					for (; a.length > 0;) {
						let e = parseInt(a[1]);
						if (a.length < 3 || isNaN(e) || e <= 0 || a.length < e + 3) break;
						let t = [];
						n.push(t);
						let r = 2, o = t.length, s = o + e;
						for (let e = o; e < s; e++) {
							let n = a[r++], o = {};
							o.serial = e, o.atom = n.slice(10, 15).trim(), o.elem = (0, i.atomNameToElem)(o.atom, !0), o.x = 10 * parseFloat(n.slice(20, 28)), o.y = 10 * parseFloat(n.slice(28, 36)), o.z = 10 * parseFloat(n.slice(36, 44)), o.resi = parseInt(n.slice(0, 5)), o.resn = n.slice(5, 10).trim(), o.bonds = [], o.bondOrder = [], o.properties = {}, n.length > 44 && (o.dx = 10 * parseFloat(n.slice(44, 52)), o.dy = 10 * parseFloat(n.slice(52, 60)), o.dz = 10 * parseFloat(n.slice(60, 68))), t[e] = o;
						}
						if (a.length <= r + 3) {
							let e = a[r++].trim().split(/\s+/);
							if (e.length === 3) {
								for (let t = 0; t < 3; t++) e[t] = (parseFloat(e[t]) * 10).toString();
								n.box = e;
							}
						}
						a.splice(0, ++r);
					}
					for (let e = 0; e < n.length; e++) (0, r.assignPDBBonds)(n[e], t);
					return n;
				}
			},
			"./src/parsers/LAMMPSTRJ.ts"(e, t, n) {
				n.r(t), n.d(t, { LAMMPSTRJ: () => a });
				var r = n("./src/parsers/utils/assignBonds.ts");
				let i = {
					id: "serial",
					type: "atom",
					element: "elem",
					q: "charge",
					radius: "radius",
					x: "x",
					xu: "x",
					xs: "x",
					xsu: "x",
					y: "y",
					yu: "y",
					ys: "y",
					ysu: "y",
					z: "z",
					zu: "z",
					zs: "z",
					zsu: "z"
				};
				function a(e, t) {
					let n = [], a = e.split(/\r?\n|\r/), o = 0, s = 0, c = 0;
					for (; c < a.length - 9;) {
						for (var l = c; l < a.length; l++) if (a[l].match(/ITEM: NUMBER OF ATOMS/) && (s = parseInt(a[l + 1])), a[l].match(/ITEM: ATOMS/)) {
							o = l + 1;
							break;
						}
						let e = a[o - 1].replace("ITEM: ATOMS ", "").split(" ");
						n.push([]);
						for (let t = o; t < o + s; t++) {
							let r = {}, s = {}, c = a[t].split(" ");
							for (let t = 0; t < c.length; t++) {
								let n = i[e[t]];
								n !== void 0 && (n === "serial" ? r[n] = parseInt(c[t]) : n === "x" || n === "y" || n === "z" ? r[n] = parseFloat(c[t]) : n === "charge" || n === "radius" ? s[n] = parseFloat(c[t]) : r[n] = c[t]), r.properties = s, r.bonds = [], r.bondOrder = [];
							}
							n[n.length - 1][t - o] = r;
						}
						c = o + s - 1;
					}
					if (t.assignBonds) for (let e = 0; e < n.length; e++) (0, r.assignBonds)(n[e], t);
					return n;
				}
			},
			"./src/parsers/MMTF.ts"(e, t, n) {
				n.r(t), n.d(t, { MMTFparser: () => d });
				var r = n("./src/utilities.ts"), i = n("./src/WebGL/index.ts"), a = n("./src/parsers/utils/computeSecondaryStructure.ts"), o = n("./src/parsers/utils/processSymmetries.ts"), s = n("./src/vendor/mmtf.js"), c = function(e) {
					return String.fromCharCode.apply(null, e).replace(/\0/g, "");
				}, l = function(e) {
					return e == 0 || e == 2 || e == 4 ? "h" : e == 3 ? "s" : "c";
				};
				let u = /* @__PURE__ */ new Set([
					"D-SACCHARIDE",
					"D-SACCHARIDE 1,4 AND 1,4 LINKING",
					"D-SACCHARIDE 1,4 AND 1,6 LINKING",
					"L-SACCHARIDE",
					"L-SACCHARIDE 1,4 AND 1,4 LINKING",
					"L-SACCHARIDE 1,4 AND 1,6 LINKING",
					"NON-POLYMER",
					"OTHER",
					"PEPTIDE-LIKE",
					"SACCHARIDE"
				]);
				function d(e, t) {
					var n = !t.keepH, d = t.altLoc ? t.altLoc : "A", f = !!t.noSecondaryStructure, p = !t.noComputeSecondaryStructure, m = !t.doAssembly, h = t.assemblyIndex ? t.assemblyIndex : 0;
					e = typeof e == "string" ? (0, r.base64ToArray)(e) : new Uint8Array(e);
					var g = s.decode(e), _ = [[]], v = _.modelData = [], y = 0, b = 0, x = 0, S = g.secStructList, C = g.bFactorList, w = g.altLocList, T = g.occupancyList, E = g.bondAtomList, D = g.bondOrderList, O = g.numModels;
					if (O == 0) return _;
					t.multimodel || (O = 1);
					var k, A, j, M, N, P, F = [];
					if (!m && g.bioAssemblyList && g.bioAssemblyList.length > 0) {
						var I = g.bioAssemblyList[h].transformList;
						for (k = 0, P = I.length; k < P; k++) {
							var L = new i.Matrix4(I[k].matrix);
							L.transpose(), F.push(L);
						}
					}
					var R = null;
					if (g.unitCell) {
						var z = g.unitCell;
						R = {
							a: z[0],
							b: z[1],
							c: z[2],
							alpha: z[3],
							beta: z[4],
							gamma: z[5]
						};
					}
					let B = [];
					g.entityList.forEach((e) => {
						e.chainIndexList.forEach((t) => {
							B[t] = e.type == "polymer";
						});
					});
					var V = 0;
					for (N = 0; N < O; N++) {
						var H = g.chainsPerModel[N], U = _[_.length - 1], W = [];
						for (v.push({
							symmetries: F,
							cryst: R
						}), k = 0; k < H; ++k) {
							var G = g.groupsPerChain[y], ee = c(g.chainIdList.subarray(y * 4, y * 4 + 4));
							g.chainNameList && (ee = c(g.chainNameList.subarray(y * 4, y * 4 + 4)));
							var te = b, ne = "";
							for (A = 0; A < G; ++A) {
								var re = g.groupList[g.groupTypeList[b]], ie = re.atomNameList.length, K = 0, ae = !1, oe = !1;
								if (S) {
									K = S[b];
									var q = l(K);
									(b == 0 || q != ne) && (ae = !0), ne = q;
									var J = b + 1;
									(J >= S.length || l(S[J] != q)) && (oe = !0);
								}
								var Y = g.groupIdList[b], se = re.groupName;
								let e = re.chemCompType;
								var ce = x;
								let t = u.has(e) || !B[y];
								for (j = 0; j < ie; ++j) {
									var X = re.elementList[j];
									if (n && X == "H") {
										x += 1;
										continue;
									}
									var le = "";
									C && (le = C[x]);
									var Z = "";
									w && w[x] && (Z = String.fromCharCode(w[x]));
									var Q = "";
									if (T && (Q = T[x]), Z != "" && Z != d && d != "*") {
										x += 1;
										continue;
									}
									var ue = g.atomIdList[x], de = re.atomNameList[j], $ = 0;
									re.atomChargeList && ($ = re.atomChargeList[j]);
									var fe = g.xCoordList[x], pe = g.yCoordList[x], me = g.zCoordList[x];
									W[x] = U.length, U.push({
										resn: se,
										x: fe,
										y: pe,
										z: me,
										elem: X,
										hetflag: t,
										chain: ee,
										resi: Y,
										icode: Z,
										rescode: Y + (Z == " " ? "" : "^" + Z),
										serial: ue,
										altLoc: Z,
										index: x,
										atom: de,
										bonds: [],
										ss: l(K),
										ssbegin: ae,
										ssend: oe,
										bondOrder: [],
										properties: {
											charge: $,
											occupancy: Q
										},
										b: le
									}), x += 1;
								}
								var he = re.bondAtomList;
								for (j = 0, M = re.bondOrderList.length; j < M; ++j) {
									var ge = ce + he[j * 2], _e = ce + he[j * 2 + 1], ve = re.bondOrderList[j], ye = W[ge], be = W[_e], xe = U[ye], Se = U[be];
									xe && Se && (xe.bonds.push(be), xe.bondOrder.push(ve), Se.bonds.push(ye), Se.bondOrder.push(ve));
								}
								b += 1;
							}
							for (b = te, A = 0; A < G; ++A) b += 1;
							y += 1;
						}
						if (E) for (let e = V, t = E.length; e < t; e += 2) {
							let t = E[e], n = E[e + 1], r = D ? D[e / 2] : 1;
							if (t >= x) {
								V = e;
								break;
							}
							let i = W[t], a = W[n], o = U[i], s = U[a];
							o && s && (o.bonds.push(a), o.bondOrder.push(r), s.bonds.push(i), s.bondOrder.push(r));
						}
						t.multimodel && (t.onemol || _.push([]));
					}
					if (!m) for (let e = 0; e < _.length; e++) (0, o.processSymmetries)(v[e].symmetries, _[e], t, v[e].cryst);
					return p && !f && (0, a.computeSecondaryStructure)(_, t.hbondCutoff), _;
				}
			},
			"./src/parsers/MOL2.ts"(e, t, n) {
				n.r(t), n.d(t, { MOL2: () => i });
				let r = {
					"C.1": "C",
					C1: "C",
					"C.2": "C",
					C2: "C",
					"C.3": "C",
					C3: "C",
					"C.ar": "C",
					Car: "C",
					"C.cat": "C",
					Ccat: "C",
					"H.spc": "H",
					Hspc: "H",
					"H.t3p": "H",
					Ht3p: "H",
					"N.1": "N",
					N1: "N",
					"N.2": "N",
					N2: "N",
					"N.3": "N",
					N3: "N",
					"N.4": "N",
					N4: "N",
					"N.am": "N",
					Nam: "N",
					"N.ar": "N",
					Nar: "N",
					"N.p13": "N",
					Np13: "N",
					"O.2": "O",
					O2: "O",
					"O.3": "O",
					O3: "O",
					"O.co2": "O",
					Oco2: "O",
					"O.spc": "O",
					Ospc: "O",
					"O.t3p": "O",
					Ot3p: "O",
					"P.3": "P",
					P3: "P",
					"S.2": "S",
					S2: "S",
					"S.3": "S",
					S3: "S",
					"S.o": "S",
					So: "S",
					"S.o2": "S",
					So2: "S"
				};
				function i(e, t) {
					var n = [[]], i = !1;
					t.keepH !== void 0 && (i = !t.keepH);
					var a = e.search(/@<TRIPOS>MOLECULE/), o = e.search(/@<TRIPOS>ATOM/);
					if (a == -1 || o == -1) return n;
					for (var s = e.substring(a).split(/\r?\n|\r/); s.length > 0;) {
						var c = [], l = s[2].replace(/^\s+/, "").replace(/\s+/g, " ").split(" "), u = parseInt(l[0]), d = 0;
						l.length > 1 && (d = parseInt(l[1]));
						var f = 4, p;
						for (p = 3; p < s.length; p++) if (s[p] == "@<TRIPOS>ATOM") {
							f = p + 1;
							break;
						}
						var m = n[n.length - 1].length, h = m + u, g;
						for (p = m; p < h; p++) {
							g = s[f++], l = g.replace(/^\s+/, "").replace(/\s+/g, " ").split(" ");
							var _ = {}, v = l[5];
							if (r[v] === void 0 ? (v = v.split(".")[0], v = v[0].toUpperCase() + v.substring(1).toLowerCase()) : v = r[v], _.atom = l[1], _.elem = v, !(_.elem == "H" && i)) {
								var y = n[n.length - 1].length, b = parseInt(l[0]);
								_.serial = b, _.x = parseFloat(l[2]), _.y = parseFloat(l[3]), _.z = parseFloat(l[4]), _.atom = l[5];
								var x = parseFloat(l[8]);
								_.index = y, _.bonds = [], _.bondOrder = [], _.properties = {
									charge: x,
									partialCharge: x
								}, c[b] = y, n[n.length - 1].push(_);
							}
						}
						for (var S = !1; f < s.length;) if (s[f++] == "@<TRIPOS>BOND") {
							S = !0;
							break;
						}
						if (S && d) for (p = 0; p < d; p++) {
							g = s[f++], l = g.replace(/^\s+/, "").replace(/\s+/g, " ").split(" ");
							var C = parseInt(l[1]), w = n[n.length - 1][c[C]], T = parseInt(l[2]), E = n[n.length - 1][c[T]], D = parseInt(l[3]);
							isNaN(D) && (D = 1), w !== void 0 && E !== void 0 && (w.bonds.push(c[T]), w.bondOrder.push(D), E.bonds.push(c[C]), E.bondOrder.push(D));
						}
						if (t.multimodel) {
							t.onemol || n.push([]), s.splice(0, f), e = s.join("\n");
							continue;
						}
						break;
					}
					return n;
				}
			},
			"./src/parsers/PDB.ts"(e, t, n) {
				n.r(t), n.d(t, { PDB: () => i });
				var r = n("./src/parsers/utils/getSinglePDB.ts");
				function i(e, t) {
					t ||= {};
					var n = [], i = {};
					n.modelData = [];
					for (var a = e.split(/\r?\n|\r/); a.length > 0;) {
						var o = (0, r.getSinglePDB)(a, t, i), s = o[0], c = o[1];
						if (a = o[2], s.length != 0) {
							if (t.multimodel && t.onemol && n.length > 0) for (var l = n[0].length, u = 0; u < s.length; u++) {
								var d = s[u];
								d.index = u;
								for (var f = 0; f < d.bonds.length; f++) d.bonds[f] += l;
								n[0].push(d);
							}
							else n.modelData.push(c), n.push(s);
							if (!t.multimodel) break;
						}
					}
					return n;
				}
			},
			"./src/parsers/PQR.ts"(e, t, n) {
				n.r(t), n.d(t, { PQR: () => a });
				var r = n("./src/parsers/utils/assignPDBBonds.ts"), i = n("./src/parsers/utils/computeSecondaryStructure.ts");
				function a(e, t) {
					var n = [[]], a = !t.noSecondaryStructure;
					n.modelData = [{ symmetries: [] }];
					var o = [], s = e.split(/\r?\n|\r/), c;
					for (let e = 0; e < s.length; e++) {
						c = s[e].replace(/^\s*/, "");
						var l = c.substring(0, 6);
						if (l.indexOf("END") == 0) {
							if (t.multimodel) {
								t.onemol || n.push([]);
								continue;
							}
							break;
						}
						if (l == "ATOM  " || l == "HETATM") {
							var u;
							let e = parseInt(c.substring(6, 11)), t = c.substring(12, 16).replace(/ /g, ""), r = c.substring(17, 20).trim(), i = c.substring(21, 22), a = parseInt(c.substring(22, 26));
							var d = c.substring(30).trim().split(/\s+/), f = parseFloat(d[0]), p = parseFloat(d[1]), m = parseFloat(d[2]), h = parseFloat(d[3]), g = parseFloat(d[4]), _ = t[0];
							t.length > 1 && t[1].toUpperCase() != t[1] && (_ = t.substring(0, 2)), u = c[0] == "H", o[e] = n[n.length - 1].length, n[n.length - 1].push({
								resn: r,
								x: f,
								y: p,
								z: m,
								elem: _,
								hetflag: u,
								chain: i,
								resi: a,
								serial: e,
								atom: t,
								bonds: [],
								ss: "c",
								bondOrder: [],
								properties: {
									charge: h,
									partialCharge: h,
									radius: g
								},
								pdbline: c
							});
						} else if (l == "CONECT") {
							var v = parseInt(c.substring(6, 11)), y = n[n.length - 1][o[v]];
							for (let e = 0; e < 4; e++) {
								var b = parseInt(c.substring([
									11,
									16,
									21,
									26
								][e], [
									11,
									16,
									21,
									26
								][e] + 5)), x = n[n.length - 1][o[b]];
								y !== void 0 && x !== void 0 && (y.bonds.push(o[b]), y.bondOrder.push(1));
							}
						}
					}
					for (let e = 0; e < n.length; e++) (0, r.assignPDBBonds)(n[e], t), a && (0, i.computeSecondaryStructure)(n[e], t.hbondCutoff);
					return n;
				}
			},
			"./src/parsers/PRMTOP.ts"(e, t, n) {
				n.r(t), n.d(t, { PRMTOP: () => r });
				function r(e) {
					var t = [], n, r = 0, i = e.split(/\r?\n|\r/);
					if (i.length > 0 && i[0].includes("VERSION")) {
						var a = i.filter(function(e) {
							return e.includes("POINTERS") || e.includes("ATOM_NAME") || e.includes("CHARGE") || e.includes("RADII") || e.includes("BONDS_INC_HYDROGEN") || e.includes("BONDS_WITHOUT_HYDROGEN") || e.includes("RESIDUE_LABEL") || e.includes("RESIDUE_POINTER");
						}), o = d("POINTERS");
						if (o == -1) return [];
						var s = f(o), c = parseInt(i[o + 1].slice(0, s[1]));
						let e = parseInt(i[o + 2].slice(s[1], s[0] + s[1]));
						if (isNaN(c) || c <= 0 || (o = d("ATOM_NAME"), o == -1)) return [];
						s = f(o);
						var l = s[0];
						for (let e = 0; e < c / s[0]; e++) {
							e == parseInt(c / s[0]) && (l = c % s[0]);
							for (let e = 0; e < l; e++) {
								let n = {};
								n.serial = r, n.x = 0, n.y = 0, n.z = 0, n.atom = i[o + 1].slice(s[1] * e, s[1] * (e + 1)).trim(), n.elem = i[o + 1].slice(s[1] * e, s[1] * e + 1).trim(), n.properties = {
									charge: "",
									radii: ""
								}, n.bonds = [], n.bondOrder = [], n.index = t.length, t.push(n), r++;
							}
							o++;
						}
						if (o = d("CHARGE"), o != -1) {
							s = f(o), r = 0, l = s[0];
							for (let e = 0; e < c / s[0]; e++) {
								e == parseInt(c / s[0]) && (l = c % s[0]);
								for (let e = 0; e < l; e++) t[r].properties.charge = parseFloat(i[o + 1].slice(s[1] * e, s[1] * (e + 1))), r++;
								o++;
							}
						}
						o = d("RESIDUE_POINTER");
						var u = [];
						if (o != -1) {
							s = f(o), l = s[0], o += 1;
							for (let t = 0; t < e / s[0]; t++) {
								t == parseInt(e / s[0]) && (l = e % s[0]);
								for (let e = 0; e < l; e++) u.push(parseInt(i[o].slice(s[1] * e, s[1] * (e + 1))));
								o++;
							}
							if (o = d("RESIDUE_LABEL"), o != -1) {
								let n = [];
								s = f(o), l = s[0], o += 1;
								for (let t = 0; t < e / s[0]; t++) {
									t == parseInt(e / s[0]) && (l = e % s[0]);
									for (let e = 0; e < l; e++) n.push(i[o].slice(s[1] * e, s[1] * (e + 1)).trim());
									o++;
								}
								let r = 0, a = 0, c = "";
								u.push(t.length + 1);
								for (let e = 0; e < t.length; e++) e + 1 >= u[r] && (c = n[r], r += 1, a += 1), t[e].resi = a, t[e].resn = c;
							}
						}
						if (o = d("RADII"), o != -1) {
							s = f(o), r = 0, l = s[0];
							for (let e = 0; e < c / s[0]; e++) {
								e == parseInt(c / s[0]) && (l = c % s[0]);
								for (let e = 0; e < l; e++) t[r].properties.radii = parseFloat(i[o + 1].slice(s[1] * e, s[1] * (e + 1))), r++;
								o++;
							}
						}
						if (o = d("BONDS_WITHOUT_HYDROGEN"), o != -1) for (s = f(o), r = 0, l = s[0], o += 1; !i[o].match(/^%FLAG/);) {
							i[o + 1].match(/^%FLAG/) && (l = c % s[0]);
							for (let e = 0; e < l; e++) r % 3 == 0 ? n = parseInt(i[o].slice(s[1] * e, s[1] * (e + 1)) / 3) : r % 3 == 1 && (t[n].bonds.push(parseInt(i[o].slice(s[1] * e, s[1] * (e + 1)) / 3)), t[n].bondOrder.push(1)), r++;
							o++;
						}
						if (o = d("BONDS_INC_HYDROGEN"), o != -1) for (s = f(o), r = 0, l = s[0], o += 1; !i[o].match(/^%FLAG/);) {
							i[o + 1].match(/^%FLAG/) && (l = c % s[0]);
							for (let e = 0; e < l; e++) r % 3 == 0 ? n = parseInt(i[o].slice(s[1] * e, s[1] * (e + 1)) / 3) : r % 3 == 1 && (t[n].bonds.push(parseInt(i[o].slice(s[1] * e, s[1] * (e + 1)) / 3)), t[n].bonds.push(1)), r++;
							o++;
						}
					} else return [];
					function d(e) {
						var t = i.indexOf(a.filter(function(t) {
							return t.includes(e);
						})[0]);
						if (Number.isInteger(t) && t > 0) {
							for (; !i[t].includes("FORMAT");) t++;
							return t;
						}
						return -1;
					}
					function f(e) {
						var t = i[e].match(/\((\d*)\S*/), n = i[e].match(/[a-zA-Z](\d*)\)\s*/);
						return n ??= i[e].match(/[a-zA-Z](\d*)\.\d*\)\s*/), [parseInt(t[1]), parseInt(n[1])];
					}
					return [t];
				}
			},
			"./src/parsers/SDF.ts"(e, t, n) {
				n.r(t), n.d(t, { SDF: () => c });
				let r = function(e, t, n, r) {
					let i;
					try {
						i = JSON.parse(e);
					} catch {
						console.warn("3DMOL_STYLE: invalid JSON: " + e);
						return;
					}
					let a = t.length - 1, o = t[a];
					if (i.bonds && typeof i.bonds == "object") {
						let e = i.bonds;
						for (let t in e) {
							if (!e.hasOwnProperty(t)) continue;
							let i = t.split("-");
							if (i.length !== 2) continue;
							let a = parseInt(i[0]) - 1 + r, s = parseInt(i[1]) - 1 + r, c = n[a], l = n[s];
							if (c == null || l == null) continue;
							let u = e[t], d = c < l ? c : l, f = c < l ? l : c, p = o[d], m = p.bonds.indexOf(f);
							m < 0 || (p.bondStyles ||= [], p.bondStyles[m] || (p.bondStyles[m] = {}), c > l && (u.color1 || u.color2) && ([u.color1, u.color2] = [u.color2, u.color1]), Object.assign(p.bondStyles[m], u));
						}
						delete i.bonds;
					}
					Object.keys(i).length > 0 && (t.modelData[a].style = i);
				}, i = function(e, t, n, i, a) {
					for (; t < e.length && !e[t].startsWith("M  END");) t++;
					for (t < e.length && t++; t < e.length;) {
						let o = e[t], s = o.trim();
						if (t++, s === "$$$$") return t;
						let c = o.match(/^>\s*<([^>]+)>/);
						if (!c) continue;
						let l = c[1].trim(), u = [];
						for (; t < e.length && (s = e[t].trim(), s !== "" && s !== "$$$$" && e[t].charAt(0) !== ">");) u.push(e[t]), t++;
						l === "3DMOL_STYLE" && u.length > 0 && r(u.join(" ").trim(), n, i, a);
					}
					return t;
				}, a = function(e, t, n, r) {
					e[t].bonds.push(n), e[t].bondOrder.push(r), e[n].bonds.push(t), e[n].bondOrder.push(r);
				}, o = function(e, t) {
					let n = [[]], r = n.modelData = [];
					r.push({});
					let o = t.keepH !== void 0 && !t.keepH, s = 0;
					for (; s < e.length && !(e.length - s < 4);) {
						let c = parseInt(e[s + 3].substring(0, 3));
						if (isNaN(c) || c <= 0) break;
						let l = parseInt(e[s + 3].substring(3, 6)), u = 4;
						if (e.length - s < 4 + c + l) break;
						let d = [], f = n[n.length - 1], p = f.length, m = p + c;
						for (let t = p; t < m; t++, u++) {
							let n = e[s + u], r = {}, i = n.substring(31, 34).replace(/ /g, "");
							r.atom = r.elem = i[0].toUpperCase() + i.substring(1).toLowerCase(), (r.elem !== "H" || !o) && (r.serial = t, d[t] = f.length, r.x = parseFloat(n.substring(0, 10)), r.y = parseFloat(n.substring(10, 20)), r.z = parseFloat(n.substring(20, 30)), r.hetflag = !0, r.bonds = [], r.bondOrder = [], r.properties = {}, r.index = f.length, f.push(r));
						}
						for (let t = 0; t < l; t++, u++) {
							let t = e[s + u], n = d[parseInt(t.substring(0, 3)) - 1 + p], r = d[parseInt(t.substring(3, 6)) - 1 + p], i = parseFloat(t.substring(6));
							n !== void 0 && r !== void 0 && a(f, n, r, i);
						}
						if (s = i(e, s + u, n, d, p), !t.multimodel) break;
						t.onemol || (n.push([]), r.push({}));
					}
					return n;
				}, s = function(e, t) {
					let n = [[]], r = n.modelData = [];
					r.push({});
					let o = t.keepH !== void 0 && !t.keepH, s = 0;
					for (; s < e.length && !(e.length - s < 8 || !e[s + 4].startsWith("M  V30 BEGIN CTAB") || !e[s + 5].startsWith("M  V30 COUNTS") || e[s + 5].length < 14);) {
						let c = e[s + 5].substring(13).match(/\S+/g);
						if (c.length < 2) break;
						let l = parseInt(c[0]);
						if (isNaN(l) || l <= 0) break;
						let u = parseInt(c[1]), d = 7;
						if (e.length - s < 8 + l + u) break;
						let f = [], p = n[n.length - 1], m = p.length, h = m + l;
						for (let t = m; t < h; t++, d++) {
							let n = e[s + d].substring(6).match(/\S+/g);
							if (n.length > 4) {
								let e = {}, r = n[1].replace(/ /g, "");
								e.atom = e.elem = r[0].toUpperCase() + r.substring(1).toLowerCase(), (e.elem !== "H" || !o) && (e.serial = t, f[t] = p.length, e.x = parseFloat(n[2]), e.y = parseFloat(n[3]), e.z = parseFloat(n[4]), e.hetflag = !0, e.bonds = [], e.bondOrder = [], e.properties = {}, e.index = p.length, p.push(e));
							}
						}
						if (e[s + d] === "M  V30 END ATOM") d++;
						else break;
						if (u !== 0 && e[s + d] === "M  V30 BEGIN BOND") d++;
						else break;
						for (let t = 0; t < u; t++, d++) {
							let t = e[s + d].substring(6).match(/\S+/g);
							if (t.length > 3) {
								let e = f[parseInt(t[2]) - 1 + m], n = f[parseInt(t[3]) - 1 + m], r = parseFloat(t[1]);
								e !== void 0 && n !== void 0 && a(p, e, n, r);
							}
						}
						if (s = i(e, s + d, n, f, m), !t.multimodel) break;
						t.onemol || (n.push([]), r.push({}));
					}
					return n;
				};
				function c(e, t) {
					let n = "V2000", r = e.split(/\r?\n|\r/);
					return r.length > 3 && r[3].length > 38 && (n = r[3].substring(34, 39)), n === "V2000" ? o(r, t) : n === "V3000" ? s(r, t) : [[""]];
				}
			},
			"./src/parsers/VASP.ts"(e, t, n) {
				n.r(t), n.d(t, { VASP: () => a });
				var r = n("./src/WebGL/index.ts"), i = n("./src/parsers/utils/assignBonds.ts");
				function a(e, t = {}) {
					var n = [[]], a = {};
					let o = t.assignBonds === void 0 || t.assignBonds;
					var s = e.replace(/^\s+/, "").split(/\r?\n/);
					if (s.length < 3) return n;
					if (s[1].match(/\d+/)) a.length = parseFloat(s[1]);
					else return console.log("Warning: second line of the vasp structure file must be a number"), n;
					if (a.length < 0) return console.log("Warning: Vasp implementation for negative lattice lengths is not yet available"), n;
					a.xVec = new Float32Array(s[2].replace(/^\s+/, "").split(/\s+/)), a.yVec = new Float32Array(s[3].replace(/^\s+/, "").split(/\s+/)), a.zVec = new Float32Array(s[4].replace(/^\s+/, "").split(/\s+/));
					var c = new r.Matrix3(a.xVec[0], a.xVec[1], a.xVec[2], a.yVec[0], a.yVec[1], a.yVec[2], a.zVec[0], a.zVec[1], a.zVec[2]);
					c.multiplyScalar(a.length), n.modelData = [{
						symmetries: [],
						cryst: { matrix: c }
					}];
					var l = s[5].trim().split(/\s+/), u = new Int16Array(s[6].trim().split(/\s+/)), d = s[7].trim(), f = !1;
					if (d.match(/S/) && (f = !0, d = s[8].trim()), d.toLowerCase()[0] == "c") d = "cartesian";
					else if (d.toLowerCase()[0] == "d") d = "direct";
					else return console.log("Warning: Unknown vasp mode in POSCAR file: mode must be either C(artesian) or D(irect)"), n;
					if (l.length != u.length) return console.log("Warning: declaration of atomary species wrong:"), console.log(l), console.log(u), n;
					f ? s.splice(0, 9) : s.splice(0, 8);
					for (var p = 0, m = 0, h = l.length; m < h; m++) {
						for (var g = l[m], _ = 0, v = u[m]; _ < v; _++) {
							var y = new Float32Array(s[p + _].trim().split(/\s+/)), b = {};
							b.elem = g, d == "cartesian" ? (b.x = a.length * y[0], b.y = a.length * y[1], b.z = a.length * y[2]) : (b.x = a.length * (y[0] * a.xVec[0] + y[1] * a.yVec[0] + y[2] * a.zVec[0]), b.y = a.length * (y[0] * a.xVec[1] + y[1] * a.yVec[1] + y[2] * a.zVec[1]), b.z = a.length * (y[0] * a.xVec[2] + y[1] * a.yVec[2] + y[2] * a.zVec[2])), b.bonds = [], b.bondOrder = [], n[0].push(b);
						}
						p += u[m];
					}
					if (o) for (let e = 0; e < n.length; e++) (0, i.assignBonds)(n[e], t);
					return n;
				}
			},
			"./src/parsers/XYZ.ts"(e, t, n) {
				n.r(t), n.d(t, { XYZ: () => a });
				var r = n("./src/WebGL/index.ts"), i = n("./src/parsers/utils/assignBonds.ts");
				function a(e, t) {
					t ||= {};
					for (var n = [[]], a = t.assignBonds === void 0 || t.assignBonds, o = e.trimStart().split(/\r?\n|\r/); o.length > 0 && !(o.length < 3);) {
						var s = parseInt(o[0]);
						if (isNaN(s) || s <= 0 || o.length < s + 2) break;
						var c = /Lattice\s*=\s*["\{\}]([^"\{\}]+)["\{\}]\s*/gi.exec(o[1]);
						if (c != null && c.length > 1) {
							var l = new Float32Array(c[1].split(/\s+/)), u = new r.Matrix3(l[0], l[3], l[6], l[1], l[4], l[7], l[2], l[5], l[8]);
							n.modelData = [{ cryst: { matrix: u } }];
						}
						for (var d = 2, f = n[n.length - 1].length, p = f + s, m = f; m < p; m++) {
							var h = o[d++].trim().split(/\s+/), g = {};
							g.serial = m;
							var _ = h[0];
							g.atom = g.elem = _[0].toUpperCase() + _.substring(1, 2).toLowerCase(), g.x = parseFloat(h[1]), g.y = parseFloat(h[2]), g.z = parseFloat(h[3]), g.hetflag = !0, g.bonds = [], g.bondOrder = [], g.properties = {}, n[n.length - 1][m] = g, h.length >= 7 && (g.dx = parseFloat(h[4]), g.dy = parseFloat(h[5]), g.dz = parseFloat(h[6]));
						}
						if (t.multimodel) n.push([]), o.splice(0, d);
						else break;
					}
					if (a) for (let e = 0; e < n.length; e++) (0, i.assignBonds)(n[e], t);
					if (t.onemol) {
						var v = n;
						n = [], n.push(v[0]);
						for (let e = 1; e < v.length; e++) {
							let t = n[0].length;
							for (let r = 0; r < v[e].length; r++) {
								let i = v[e][r];
								for (let e = 0; e < i.bonds.length; e++) i.bonds[e] = i.bonds[e] + t;
								i.index = n[0].length, i.serial = n[0].length, n[0].push(i);
							}
						}
					}
					return n;
				}
			},
			"./src/parsers/cifutils/category.ts"(e, t, n) {
				n.r(t), n.d(t, { Category: () => i });
				var r = n("./src/parsers/cifutils/decoder.ts");
				function i(e) {
					let t = Object.create(null), n = Object.create(null);
					for (let n of e.columns) t[n.name] = n;
					return {
						rowCount: e.rowCount,
						name: e.name.substring(1),
						fieldNames: e.columns.map((e) => e.name),
						getField(e) {
							let i = t[e];
							if (i) return n[e] || (n[e] = (0, r.decode)(i.data)), n[e];
						}
					};
				}
			},
			"./src/parsers/cifutils/decoder.ts"(e, t, n) {
				n.r(t), n.d(t, { decode: () => o });
				var r = n("./src/parsers/cifutils/encoding.ts");
				let i = new Uint16Array(new Uint8Array([18, 52]).buffer)[0] === 13330;
				function a(e, t) {
					let n = new ArrayBuffer(e.length), r = new Uint8Array(n);
					for (let n = 0, i = e.length; n < i; n += t) for (let i = 0; i < t; i++) r[n + t - i - 1] = e[n + i];
					return n;
				}
				function o(e) {
					let t = e.data;
					for (let n = e.encoding.length - 1; n >= 0; n--) t = s(t, e.encoding[n]);
					return t;
				}
				function s(e, t) {
					switch (t.kind) {
						case "ByteArray": switch (t.type) {
							case r.Encoding.IntDataType.Uint8: return e;
							case r.Encoding.IntDataType.Int8: return u(e);
							case r.Encoding.IntDataType.Int16: return f(e);
							case r.Encoding.IntDataType.Uint16: return p(e);
							case r.Encoding.IntDataType.Int32: return m(e);
							case r.Encoding.IntDataType.Uint32: return h(e);
							case r.Encoding.FloatDataType.Float32: return g(e);
							case r.Encoding.FloatDataType.Float64: return _(e);
							default: throw Error("unreachable");
						}
						case "FixedPoint": return v(e, t);
						case "IntervalQuantization": return y(e, t);
						case "RunLength": return b(e, t);
						case "Delta": return x(e, t);
						case "IntegerPacking": return w(e, t);
						case "StringArray": return T(e, t);
					}
				}
				function c(e, t) {
					switch (e) {
						case r.Encoding.IntDataType.Int8: return new Int8Array(t);
						case r.Encoding.IntDataType.Int16: return new Int16Array(t);
						case r.Encoding.IntDataType.Int32: return new Int32Array(t);
						case r.Encoding.IntDataType.Uint8: return new Uint8Array(t);
						case r.Encoding.IntDataType.Uint16: return new Uint16Array(t);
						case r.Encoding.IntDataType.Uint32: return new Uint32Array(t);
						default: return new Int32Array(t);
					}
				}
				function l(e, t) {
					switch (e) {
						case r.Encoding.FloatDataType.Float32: return new Float32Array(t);
						case r.Encoding.FloatDataType.Float64: return new Float64Array(t);
						default: return new Float64Array(t);
					}
				}
				function u(e) {
					return new Int8Array(e.buffer, e.byteOffset);
				}
				function d(e, t, n) {
					return (e.byteOffset != 0 || e.byteLength != e.buffer.byteLength) && (e = new Uint8Array(e)), i ? new n(e.buffer) : new n(a(e, t));
				}
				function f(e) {
					return d(e, 2, Int16Array);
				}
				function p(e) {
					return d(e, 2, Uint16Array);
				}
				function m(e) {
					return d(e, 4, Int32Array);
				}
				function h(e) {
					return d(e, 4, Uint32Array);
				}
				function g(e) {
					return d(e, 4, Float32Array);
				}
				function _(e) {
					return d(e, 8, Float64Array);
				}
				function v(e, t) {
					let n = e.length, r = l(t.srcType, n), i = 1 / t.factor;
					for (let t = 0; t < n; t++) r[t] = i * e[t];
					return r;
				}
				function y(e, t) {
					let n = e.length, r = l(t.srcType, n), i = (t.max - t.min) / (t.numSteps - 1), a = t.min;
					for (let t = 0; t < n; t++) r[t] = a + i * e[t];
					return r;
				}
				function b(e, t) {
					let n = c(t.srcType, t.srcSize), r = 0;
					for (let t = 0, i = e.length; t < i; t += 2) {
						let i = e[t], a = e[t + 1];
						for (let e = 0; e < a; ++e) n[r++] = i;
					}
					return n;
				}
				function x(e, t) {
					let n = e.length, r = c(t.srcType, n);
					if (!n) return e;
					r[0] = e[0] + (t.origin | 0);
					for (let t = 1; t < n; ++t) r[t] = e[t] + r[t - 1];
					return r;
				}
				function S(e, t) {
					let n = t.byteCount === 1 ? 127 : 32767, r = -n - 1, i = e.length, a = new Int32Array(t.srcSize), o = 0, s = 0;
					for (; o < i;) {
						let t = 0, i = e[o];
						for (; i === n || i === r;) t += i, o++, i = e[o];
						t += i, a[s] = t, o++, s++;
					}
					return a;
				}
				function C(e, t) {
					let n = t.byteCount === 1 ? 255 : 65535, r = e.length, i = new Int32Array(t.srcSize), a = 0, o = 0;
					for (; a < r;) {
						let t = 0, r = e[a];
						for (; r === n;) t += r, a++, r = e[a];
						t += r, i[o] = t, a++, o++;
					}
					return i;
				}
				function w(e, t) {
					return e.length === t.srcSize ? e : t.isUnsigned ? C(e, t) : S(e, t);
				}
				function T(e, t) {
					let n = o({
						encoding: t.offsetEncoding,
						data: t.offsets
					}), r = o({
						encoding: t.dataEncoding,
						data: e
					}), i = t.stringData, a = Array(n.length);
					a[0] = "";
					for (let e = 1, t = n.length; e < t; e++) a[e] = i.substring(n[e - 1], n[e]);
					let s = 0, c = Array(r.length);
					for (let e = 0, t = r.length; e < t; e++) c[s++] = a[r[e] + 1];
					return c;
				}
			},
			"./src/parsers/cifutils/encoding.ts"(e, t, n) {
				n.r(t), n.d(t, {
					Encoding: () => i,
					VERSION: () => r
				});
				let r = "0.3.0";
				var i;
				(function(e) {
					let t;
					(function(e) {
						e[e.Int8 = 1] = "Int8", e[e.Int16 = 2] = "Int16", e[e.Int32 = 3] = "Int32", e[e.Uint8 = 4] = "Uint8", e[e.Uint16 = 5] = "Uint16", e[e.Uint32 = 6] = "Uint32";
					})(e.IntDataType ||= {});
					let n;
					(function(e) {
						e[e.Float32 = 32] = "Float32", e[e.Float64 = 33] = "Float64";
					})(e.FloatDataType ||= {});
					function r(t) {
						let n;
						return n = t instanceof Int8Array ? e.IntDataType.Int8 : t instanceof Int16Array ? e.IntDataType.Int16 : t instanceof Int32Array ? e.IntDataType.Int32 : t instanceof Uint8Array ? e.IntDataType.Uint8 : t instanceof Uint16Array ? e.IntDataType.Uint16 : t instanceof Uint32Array ? e.IntDataType.Uint32 : t instanceof Float32Array ? e.FloatDataType.Float32 : t instanceof Float64Array ? e.FloatDataType.Float64 : e.IntDataType.Int32, n;
					}
					e.getDataType = r;
					function i(e) {
						if (e instanceof Int8Array || e instanceof Int16Array || e instanceof Int32Array) return !0;
						for (let t = 0, n = e.length; t < n; t++) if (t < 0) return !1;
						return !0;
					}
					e.isSignedIntegerDataType = i;
				})(i ||= {});
			},
			"./src/parsers/index.ts"(e, t, n) {
				n.r(t), n.d(t, {
					Parsers: () => v,
					bondLength: () => _.bondLength,
					setBondLength: () => _.setBondLength
				});
				var r = n("./src/parsers/VASP.ts"), i = n("./src/parsers/CUBE.ts"), a = n("./src/parsers/XYZ.ts"), o = n("./src/parsers/SDF.ts"), s = n("./src/parsers/CDJSON.ts"), c = n("./src/parsers/CIF.ts"), l = n("./src/parsers/MOL2.ts"), u = n("./src/parsers/PDB.ts"), d = n("./src/parsers/PQR.ts"), f = n("./src/parsers/MMTF.ts"), p = n("./src/parsers/PRMTOP.ts"), m = n("./src/parsers/GRO.ts"), h = n("./src/parsers/LAMMPSTRJ.ts"), g = n("./src/parsers/BCIF.ts"), _ = n("./src/parsers/utils/bondLength.ts");
				let v = {
					vasp: r.VASP,
					VASP: r.VASP,
					cube: i.CUBE,
					CUBE: i.CUBE,
					xyz: a.XYZ,
					XYZ: a.XYZ,
					sdf: o.SDF,
					SDF: o.SDF,
					json: s.CDJSON,
					cdjson: s.CDJSON,
					CDJSON: s.CDJSON,
					mcif: c.CIF,
					cif: c.CIF,
					CIF: c.CIF,
					mol2: l.MOL2,
					MOL2: l.MOL2,
					pdb: u.PDB,
					PDB: u.PDB,
					pdbqt: u.PDB,
					PDBQT: u.PDB,
					pqr: d.PQR,
					PQR: d.PQR,
					mmtf: f.MMTFparser,
					MMTF: f.MMTFparser,
					prmtop: p.PRMTOP,
					PRMTOP: p.PRMTOP,
					gro: m.GRO,
					GRO: m.GRO,
					lammpstrj: h.LAMMPSTRJ,
					LAMMPSTRJ: h.LAMMPSTRJ,
					bcif: g.BCIF,
					BCIF: g.BCIF
				};
			},
			"./src/parsers/utils/anumToSymbol.ts"(e, t, n) {
				n.r(t), n.d(t, { anumToSymbol: () => r });
				let r = {
					1: "H",
					2: "He",
					3: "Li",
					4: "Be",
					5: "B",
					6: "C",
					7: "N",
					8: "O",
					9: "F",
					10: "Ne",
					11: "Na",
					12: "Mg",
					13: "Al",
					14: "Si",
					15: "P",
					16: "S",
					17: "Cl",
					18: "Ar",
					19: "K",
					20: "Ca",
					21: "Sc",
					22: "Ti",
					23: "V",
					24: "Cr",
					25: "Mn",
					26: "Fe",
					27: "Co",
					28: "Ni",
					29: "Cu",
					30: "Zn",
					31: "Ga",
					32: "Ge",
					33: "As",
					34: "Se",
					35: "Br",
					36: "Kr",
					37: "Rb",
					38: "Sr",
					39: "Y",
					40: "Zr",
					41: "Nb",
					42: "Mo",
					43: "Tc",
					44: "Ru",
					45: "Rh",
					46: "Pd",
					47: "Ag",
					48: "Cd",
					49: "In",
					50: "Sn",
					51: "Sb",
					52: "Te",
					53: "I",
					54: "Xe",
					55: "Cs",
					56: "Ba",
					71: "Lu",
					72: "Hf",
					73: "Ta",
					74: "W",
					75: "Re",
					76: "Os",
					77: "Ir",
					78: "Pt",
					79: "Au",
					80: "Hg",
					81: "Tl",
					82: "Pb",
					83: "Bi",
					84: "Po",
					85: "At",
					86: "Rn",
					87: "Fr",
					88: "Ra",
					104: "Rf",
					105: "Db",
					106: "Sg",
					107: "Bh",
					108: "Hs",
					109: "Mt",
					110: "Ds",
					111: "Rg",
					112: "Cn",
					113: "Nh",
					114: "Fl",
					115: "Mc",
					116: "Lv",
					117: "Ts",
					118: "Og",
					57: "La",
					58: "Ce",
					59: "Pr",
					60: "Nd",
					61: "Pm",
					62: "Sm",
					63: "Eu",
					64: "Gd",
					65: "Tb",
					66: "Dy",
					67: "Ho",
					68: "Er",
					69: "Tm",
					70: "Yb",
					89: "Ac",
					90: "Th",
					91: "Pa",
					92: "U",
					93: "Np",
					94: "Pu",
					95: "Am",
					96: "Cm",
					97: "Bk",
					98: "Cf",
					99: "Es",
					100: "Fm",
					101: "Md",
					102: "No"
				};
			},
			"./src/parsers/utils/areConnected.ts"(e, t, n) {
				n.r(t), n.d(t, { areConnected: () => a });
				var r = n("./src/parsers/utils/bondLength.ts");
				let i = /* @__PURE__ */ new Set([
					"Na",
					"K",
					"Ca",
					"Mg",
					"Mn",
					"Sr"
				]);
				function a(e, t, n) {
					if (n && n.unboundCations && (i.has(e.elem) || i.has(t.elem))) return !1;
					let a = (0, r.bondLength)(e.elem) + (0, r.bondLength)(t.elem);
					a += .25, a *= a;
					let o = e.x - t.x;
					if (o *= o, o > a) return !1;
					let s = e.y - t.y;
					if (s *= s, s > a) return !1;
					let c = e.z - t.z;
					if (c *= c, c > a) return !1;
					let l = o + s + c;
					return !(isNaN(l) || l < .5 || l > a || e.altLoc !== t.altLoc && e.altLoc.trim() !== "" && t.altLoc.trim() !== "");
				}
			},
			"./src/parsers/utils/assignBackboneHBonds.ts"(e, t, n) {
				n.r(t), n.d(t, { assignBackboneHBonds: () => r });
				function r(e, t) {
					let n = t || 3.2, r = n * n, i = [];
					for (let t = 0, n = e.length; t < n; t++) {
						e[t].index = t;
						let n = e[t];
						!n.hetflag && (n.atom === "N" || n.atom === "O") && (i.push(n), n.hbondOther = null, n.hbondDistanceSq = Infinity);
					}
					i.sort(function(e, t) {
						return e.z - t.z;
					});
					for (let e = 0, t = i.length; e < t; e++) {
						let a = i[e];
						for (let o = e + 1; o < t; o++) {
							let e = i[o], t = e.z - a.z;
							if (t > n) break;
							if (e.atom == a.atom) continue;
							let s = Math.abs(e.y - a.y);
							if (s > n) continue;
							let c = Math.abs(e.x - a.x);
							if (c > n) continue;
							let l = c * c + s * s + t * t;
							l > r || e.chain == a.chain && Math.abs(e.resi - a.resi) < 4 || (l < a.hbondDistanceSq && (a.hbondOther = e, a.hbondDistanceSq = l), l < e.hbondDistanceSq && (e.hbondOther = a, e.hbondDistanceSq = l));
						}
					}
				}
			},
			"./src/parsers/utils/assignBonds.ts"(e, t, n) {
				n.r(t), n.d(t, { assignBonds: () => o });
				var r = n("./src/parsers/utils/areConnected.ts");
				let i = [
					{
						x: 0,
						y: 0,
						z: 1
					},
					{
						x: 0,
						y: 1,
						z: -1
					},
					{
						x: 0,
						y: 1,
						z: 0
					},
					{
						x: 0,
						y: 1,
						z: 1
					},
					{
						x: 1,
						y: -1,
						z: -1
					},
					{
						x: 1,
						y: -1,
						z: 0
					},
					{
						x: 1,
						y: -1,
						z: 1
					},
					{
						x: 1,
						y: 0,
						z: -1
					},
					{
						x: 1,
						y: 0,
						z: 0
					},
					{
						x: 1,
						y: 0,
						z: 1
					},
					{
						x: 1,
						y: 1,
						z: -1
					},
					{
						x: 1,
						y: 1,
						z: 0
					},
					{
						x: 1,
						y: 1,
						z: 1
					}
				], a = 4.95;
				function o(e, t) {
					for (let t = 0, n = e.length; t < n; t++) e[t].index || (e[t].index = t);
					let n = { x: { y: { z: [] } } };
					for (let t = 0; t < e.length; t++) {
						let r = e[t], i = Math.floor(r.x / a), o = Math.floor(r.y / a), s = Math.floor(r.z / a);
						n[i] || (n[i] = {}), n[i][o] || (n[i][o] = {}), n[i][o][s] || (n[i][o][s] = []), n[i][o][s].push(r);
					}
					function o(e, n) {
						for (let i = 0; i < e.length; i++) {
							let a = e[i];
							for (let e = 0; e < n.length; e++) {
								let i = n[e];
								if ((0, r.areConnected)(a, i, t)) {
									let e = a.bonds.indexOf(i.index), t = i.bonds.indexOf(a.index);
									e === -1 && t === -1 ? (a.bonds.push(i.index), a.bondOrder.push(1), i.bonds.push(a.index), i.bondOrder.push(1)) : e === -1 ? (a.bonds.push(i.index), a.bondOrder.push(i.bondOrder[t])) : t === -1 && (i.bonds.push(a.index), i.bondOrder.push(a.bondOrder[e]));
								}
							}
						}
					}
					for (let e in n) {
						let a = parseInt(e);
						for (let e in n[a]) {
							let s = parseInt(e);
							for (let e in n[a][s]) {
								let c = parseInt(e), l = n[a][s][c];
								for (let e = 0; e < l.length; e++) {
									let n = l[e];
									for (let i = e + 1; i < l.length; i++) {
										let e = l[i];
										(0, r.areConnected)(n, e, t) && n.bonds.indexOf(e.index) == -1 && (n.bonds.push(e.index), n.bondOrder.push(1), e.bonds.push(n.index), e.bondOrder.push(1));
									}
								}
								for (let e = 0; e < i.length; e++) {
									let t = i[e];
									if (!n[a + t.x] || !n[a + t.x][s + t.y] || !n[a + t.x][s + t.y][c + t.z]) continue;
									let r = n[a + t.x][s + t.y][c + t.z];
									o(l, r);
								}
							}
						}
					}
				}
			},
			"./src/parsers/utils/assignPDBBonds.ts"(e, t, n) {
				n.r(t), n.d(t, { assignPDBBonds: () => o });
				var r = n("./src/parsers/utils/areConnected.ts"), i = n("./src/parsers/utils/assignBonds.ts"), a = n("./src/parsers/utils/standardResidues.ts");
				function o(e, t) {
					let n = [], o = [];
					for (let t = 0, r = e.length; t < r; t++) {
						let r = e[t];
						r.index = t, r.hetflag || !a.standardResidues.has(r.resn) ? o.push(r) : n.push(r);
					}
					(0, i.assignBonds)(o, t), n.sort(function(e, t) {
						return e.chain === t.chain ? e.resi - t.resi : e.chain < t.chain ? -1 : 1;
					});
					let s = -1, c = -1, l;
					for (let e = 0, i = n.length; e < i; e++) {
						let i = n[e];
						i.resi !== s && (s = i.resi, l || c++, l = !1), i.reschain = c;
						for (let a = e + 1; a < n.length; a++) {
							let e = n[a];
							if (e.chain !== i.chain || e.resi - i.resi > 1) break;
							(0, r.areConnected)(i, e, t) && (i.bonds.indexOf(e.index) === -1 && (i.bonds.push(e.index), i.bondOrder.push(1), e.bonds.push(i.index), e.bondOrder.push(1)), i.resi !== e.resi && (l = !0));
						}
					}
				}
			},
			"./src/parsers/utils/atomNameToElem.ts"(e, t, n) {
				n.r(t), n.d(t, { atomNameToElem: () => i });
				var r = n("./src/parsers/utils/bondLength.ts");
				function i(e, t) {
					let n = e.replace(/ /g, "");
					return n.length > 0 && n[0] === "H" && n !== "Hg" && n !== "He" && n !== "Hf" && n !== "Hs" && n !== "Ho" && (n = "H"), n.length > 1 && (n = n[0].toUpperCase() + n.substring(1).toLowerCase(), r.bondTable[n] === void 0 ? n = n[0] : t && (n === "Ca" || n === "Cd") && (n = "C")), n;
				}
			},
			"./src/parsers/utils/bondLength.ts"(e, t, n) {
				n.r(t), n.d(t, {
					bondLength: () => i,
					bondTable: () => r,
					setBondLength: () => a
				});
				let r = {
					H: .37,
					He: .32,
					Li: 1.34,
					Be: .9,
					B: .82,
					C: .77,
					N: .75,
					O: .73,
					F: .71,
					Ne: .69,
					Na: 1.54,
					Mg: 1.3,
					Al: 1.18,
					Si: 1.11,
					P: 1.06,
					S: 1.02,
					Cl: .99,
					Ar: .97,
					K: 1.96,
					Ca: 1.74,
					Sc: 1.44,
					Ti: 1.56,
					V: 1.25,
					Mn: 1.39,
					Fe: 1.25,
					Co: 1.26,
					Ni: 1.21,
					Cu: 1.38,
					Zn: 1.31,
					Ga: 1.26,
					Ge: 1.22,
					Se: 1.16,
					Br: 1.14,
					Kr: 1.1,
					Rb: 2.11,
					Sr: 1.92,
					Y: 1.62,
					Zr: 1.48,
					Nb: 1.37,
					Mo: 1.45,
					Tc: 1.56,
					Ru: 1.26,
					Rh: 1.35,
					Pd: 1.31,
					Ag: 1.53,
					Cd: 1.48,
					In: 1.44,
					Sn: 1.41,
					Sb: 1.38,
					Te: 1.35,
					I: 1.33,
					Xe: 1.3,
					Cs: 2.25,
					Ba: 1.98,
					Lu: 1.6,
					Hf: 1.5,
					Ta: 1.38,
					W: 1.46,
					Re: 1.59,
					Os: 1.44,
					Ir: 1.37,
					Pt: 1.28,
					Au: 1.44,
					Hg: 1.49,
					Tl: 1.48,
					Pb: 1.47,
					Bi: 1.46,
					Rn: 1.45
				};
				function i(e) {
					return r[e] || 1.6;
				}
				function a(e, t) {
					t < 0 && (t = 0), r[e] = t;
				}
			},
			"./src/parsers/utils/computeSecondaryStructure.ts"(e, t, n) {
				n.r(t), n.d(t, { computeSecondaryStructure: () => i });
				var r = n("./src/parsers/utils/assignBackboneHBonds.ts");
				function i(e, t) {
					(0, r.assignBackboneHBonds)(e, t);
					let n = {}, i, a, o, s, c, l;
					for (i = 0, a = e.length; i < a; i++) if (c = e[i], n[c.chain] === void 0 && (n[c.chain] = []), isFinite(c.hbondDistanceSq)) {
						let e = c.hbondOther;
						n[e.chain] === void 0 && (n[e.chain] = []), Math.abs(e.resi - c.resi) === 4 && (n[c.chain][c.resi] = "h");
					}
					for (o in n) for (s = 1; s < n[o].length - 1; s++) {
						let e = n[o][s - 1], t = n[o][s + 1];
						l = n[o][s], e == "h" && e == t && l != e && (n[o][s] = e);
					}
					for (i = 0, a = e.length; i < a; i++) c = e[i], isFinite(c.hbondDistanceSq) && n[c.chain][c.resi] != "h" && c.ss !== "h" && (n[c.chain][c.resi] = "maybesheet");
					for (let t = 0, r = e.length; t < r; t++) if (c = e[t], isFinite(c.hbondDistanceSq) && n[c.chain][c.resi] == "maybesheet") {
						let e = c.hbondOther, t = n[e.chain][e.resi];
						(t == "maybesheet" || t == "s") && (n[c.chain][c.resi] = "s", n[e.chain][e.resi] = "s");
					}
					for (let e in n) {
						for (let t = 1; t < n[e].length - 1; t++) {
							let r = n[e][t - 1], i = n[e][t + 1];
							l = n[e][t], r == "s" && r == i && l != r && (n[e][t] = r);
						}
						for (let t = 0; t < n[e].length; t++) {
							let r = n[e][t];
							(r == "h" || r == "s") && n[e][t - 1] != r && n[e][t + 1] != r && delete n[e][t];
						}
					}
					for (i = 0, a = e.length; i < a; i++) c = e[i], l = n[c.chain][c.resi], delete c.hbondOther, delete c.hbondDistanceSq, l !== void 0 && l !== "maybesheet" && (c.ss = l, n[c.chain][c.resi - 1] != l && (c.ssbegin = !0), n[c.chain][c.resi + 1] != l && (c.ssend = !0));
				}
			},
			"./src/parsers/utils/getSinglePDB.ts"(e, t, n) {
				n.r(t), n.d(t, { getSinglePDB: () => d });
				var r = n("./src/WebGL/index.ts"), i = n("./src/parsers/utils/atomNameToElem.ts"), a = n("./src/parsers/utils/bondLength.ts"), o = n("./src/parsers/utils/computeSecondaryStructure.ts"), s = n("./src/parsers/utils/isEmpty.ts"), c = n("./src/parsers/utils/processSymmetries.ts"), l = n("./src/parsers/utils/assignPDBBonds.ts"), u = n("./src/parsers/utils/validateBonds.ts");
				function d(e, t, n) {
					let d = [], f = t.assignBonds === void 0 || t.assignBonds, p = !t.keepH, m = !!t.noSecondaryStructure, h = !t.noComputeSecondaryStructure, g = !t.doAssembly, _ = t.altLoc ? t.altLoc : "A", v = {
						symmetries: [],
						cryst: void 0
					}, y, b = [], x = [], S, C = {};
					for (let t = 0; t < e.length; t++) {
						S = e[t].replace(/^\s*/, "");
						let o = S.substring(0, 6), s, c, l;
						if (o.indexOf("END") === 0) {
							if (b = e.slice(t + 1), o === "END") for (let e in n) n.hasOwnProperty(e) && delete n[e];
							break;
						}
						if (o === "ATOM  " || o === "HETATM") {
							let e, t, n, r, s, c, l, u, f, m, h, g;
							if (h = S.substring(16, 17), h !== " " && h !== _ && _ !== "*" || (m = parseInt(S.substring(6, 11)), y = S.substring(12, 16).replace(/ /g, ""), e = S.substring(17, 20).replace(/ /g, ""), t = S.substring(21, 22), n = parseInt(S.substring(22, 26)), r = S.substring(26, 27), s = parseFloat(S.substring(30, 38)), c = parseFloat(S.substring(38, 46)), l = parseFloat(S.substring(46, 54)), g = parseFloat(S.substring(60, 68)), f = S.substring(76, 78).replace(/ /g, ""), f = f === "" || a.bondTable[f] === void 0 ? (0, i.atomNameToElem)(S.substring(12, 14), S[0] == "A") : f[0].toUpperCase() + f.substring(1).toLowerCase(), f === "H" && p)) continue;
							u = o[0] == "H", x[m] = d.length, d.push({
								resn: e,
								x: s,
								y: c,
								z: l,
								elem: f,
								hetflag: u,
								altLoc: h,
								chain: t,
								resi: n,
								icode: r,
								rescode: n + (r === " " ? "" : "^" + r),
								serial: m,
								atom: y,
								bonds: [],
								ss: "c",
								bondOrder: [],
								properties: {},
								b: g,
								pdbline: S
							});
						} else if (o === "SHEET ") {
							s = S.substring(21, 22), c = parseInt(S.substring(22, 26)), l = parseInt(S.substring(33, 37)), s in n || (n[s] = {}), n[s][c] = "s1";
							for (let e = c + 1; e < l; e++) n[s][e] = "s";
							n[s][l] = "s2";
						} else if (o === "CONECT") {
							let e = x[parseInt(S.substring(6, 11))], t = d[e], n = [
								11,
								16,
								21,
								26
							];
							for (let r = 0; r < 4; r++) {
								let i = x[parseInt(S.substring(n[r], n[r] + 5))], a = e + ":" + i, o = d[i];
								if (t !== void 0 && o !== void 0) {
									if (!C[a]) C[a] = 1, (t.bonds.length == 0 || t.bonds[t.bonds.length - 1] !== i) && (t.bonds.push(i), t.bondOrder.push(1));
									else {
										C[a] += 1;
										for (let e = 0; e < t.bonds.length; e++) if (t.bonds[e] == i) {
											let n = C[a];
											n >= 4 ? t.bondOrder[e] = 1 : t.bondOrder[e] = n;
										}
									}
								}
							}
						} else if (o === "HELIX ") {
							s = S.substring(19, 20), c = parseInt(S.substring(21, 25)), l = parseInt(S.substring(33, 37)), s in n || (n[s] = {}), n[s][c] = "h1";
							for (let e = c + 1; e < l; e++) n[s][e] = "h";
							n[s][l] = "h2";
						} else if (!g && o === "REMARK" && S.substring(13, 18) === "BIOMT") {
							let n, i = new r.Matrix4();
							for (n = 1; n <= 3; n++) if (S = e[t].replace(/^\s*/, ""), parseInt(S.substring(18, 19)) == n) i.elements[n - 1] = parseFloat(S.substring(23, 33)), i.elements[n - 1 + 4] = parseFloat(S.substring(33, 43)), i.elements[n - 1 + 8] = parseFloat(S.substring(43, 53)), i.elements[n - 1 + 12] = parseFloat(S.substring(53)), t++;
							else for (; S.substring(13, 18) === "BIOMT";) t++, S = e[t].replace(/^\s*/, "");
							i.elements[3] = 0, i.elements[7] = 0, i.elements[11] = 0, i.elements[15] = 1, v.symmetries.push(i), t--;
						} else if (o === "CRYST1") {
							let e, t, n, r, i, a;
							e = parseFloat(S.substring(7, 15)), t = parseFloat(S.substring(16, 24)), n = parseFloat(S.substring(25, 33)), r = parseFloat(S.substring(34, 40)), i = parseFloat(S.substring(41, 47)), a = parseFloat(S.substring(48, 54)), v.cryst = {
								a: e,
								b: t,
								c: n,
								alpha: r,
								beta: i,
								gamma: a
							};
						} else if (o === "ANISOU") {
							let e = d[x[parseInt(S.substring(6, 11))]];
							if (e) {
								let t = S.substring(30).trim().split(/\s+/);
								e.uMat = {
									u11: parseInt(t[0]),
									u22: parseInt(t[1]),
									u33: parseInt(t[2]),
									u12: parseInt(t[3]),
									u13: parseInt(t[4]),
									u23: parseInt(t[5])
								};
							}
						}
					}
					if ((0, u.validateBonds)(d, x), f && (0, l.assignPDBBonds)(d, t), g || (0, c.processSymmetries)(v.symmetries, d, t, v.cryst), h && !m && (0, o.computeSecondaryStructure)(d, t.hbondCutoff), !(0, s.isEmpty)(n)) for (let e = 0; e < d.length; e++) {
						let t = d[e];
						if (t !== void 0 && t.chain in n && t.resi in n[t.chain]) {
							let e = n[t.chain][t.resi];
							t.ss = e[0], e.length > 1 && (e[1] == "1" ? t.ssbegin = !0 : e[1] == "2" && (t.ssend = !0));
						}
					}
					return [
						d,
						v,
						b
					];
				}
			},
			"./src/parsers/utils/isEmpty.ts"(e, t, n) {
				n.r(t), n.d(t, { isEmpty: () => r });
				function r(e) {
					for (let t in e) return !1;
					return !0;
				}
			},
			"./src/parsers/utils/processSymmetries.ts"(e, t, n) {
				n.r(t), n.d(t, { processSymmetries: () => i });
				var r = n("./src/WebGL/index.ts");
				function i(e, t, n, i) {
					let a = !n.duplicateAssemblyAtoms, o = t.length, s = o, c = -1, l = null, u = null;
					(n.normalizeAssembly || n.wrapAtoms) && i && (l = (0, r.conversionMatrix3)(i.a, i.b, i.c, i.alpha, i.beta, i.gamma), u = new r.Matrix3(), u.getInverse3(l));
					let d = function(e) {
						let t = e.clone().applyMatrix3(u), n = [
							t.x,
							t.y,
							t.z
						], i = [
							0,
							0,
							0
						];
						for (let e = 0; e < 3; e++) {
							for (; n[e] < -.001;) n[e] += 1, i[e] += 1;
							for (; n[e] > 1.001;) --n[e], --i[e];
						}
						let a = new r.Vector3(i[0], i[1], i[2]);
						return a.applyMatrix3(l), a;
					};
					if (n.normalizeAssembly && i) for (let n = 0; n < e.length; n++) {
						let i = new r.Vector3(0, 0, 0);
						for (let a = 0; a < o; a++) {
							let o = new r.Vector3(t[a].x, t[a].y, t[a].z);
							o.applyMatrix4(e[n]), i.add(o);
						}
						i.divideScalar(o);
						let a = d(i);
						e[n].isNearlyIdentity() && a.lengthSq() > .001 && (c = n), e[n].translate(a);
					}
					if (!a) {
						for (let e = 0; e < o; e++) t[e].sym = -1;
						for (let a = 0; a < e.length; a++) if (!e[a].isNearlyIdentity() && c != a) {
							let c = new r.Vector3();
							for (let r = 0; r < o; r++) {
								let o = [];
								for (let e = 0; e < t[r].bonds.length; e++) o.push(t[r].bonds[e] + s);
								if (c.set(t[r].x, t[r].y, t[r].z), c.applyMatrix4(e[a]), n.wrapAtoms && i) {
									let e = d(c);
									c.add(e);
								}
								let l = {};
								for (let e in t[r]) l[e] = t[r][e];
								l.x = c.x, l.y = c.y, l.z = c.z, l.bonds = o, l.sym = a, l.index = t.length, t.push(l);
							}
							s = t.length;
						} else for (let e = 0; e < o; e++) t[e].sym = a;
						if (n.wrapAtoms && i) {
							let e = new r.Vector3();
							for (let n = 0; n < o; n++) {
								e.set(t[n].x, t[n].y, t[n].z);
								let r = d(e);
								e.add(r), t[n].x = e.x, t[n].y = e.y, t[n].z = e.z;
							}
						}
						if (c >= 0) {
							let n = new r.Vector3();
							for (let r = 0; r < o; r++) n.set(t[r].x, t[r].y, t[r].z), n.applyMatrix4(e[c]), t[r].x = n.x, t[r].y = n.y, t[r].z = n.z;
						}
						e.length = 0;
					} else if (e.length > 1) for (let n = 0; n < t.length; n++) {
						var f = [];
						for (let i = 0; i < e.length; i++) if (!e[i].isNearlyIdentity()) {
							var p = new r.Vector3();
							p.set(t[n].x, t[n].y, t[n].z), p.applyMatrix4(e[i]), f.push(p);
						}
						t[n].symmetries = f;
					}
				}
			},
			"./src/parsers/utils/standardResidues.ts"(e, t, n) {
				n.r(t), n.d(t, { standardResidues: () => r });
				let r = /* @__PURE__ */ new Set(/* @__PURE__ */ "ABU.ACD.ALA.ALB.ALI.ARG.AR0.ASN.ASP.ASX.BAS.CYS.CYH.CYX.CSS.CSH.GLN.GLU.GLX.GLY.HIS.HIE.HID.HIP.HYP.ILE.ILU.LEU.LYS.MET.PCA.PGA.PHE.PR0.PRO.PRZ.SER.THR.TRP.TYR.VAL.A.1MA.C.5MC.OMC.G.1MG.2MG.M2G.7MG.OMG.YG.I.T.U.+U.H2U.5MU.PSU.ACE.F0R.H2O.HOH.WAT".split("."));
			},
			"./src/parsers/utils/validateBonds.ts"(e, t, n) {
				n.r(t), n.d(t, { validateBonds: () => r });
				function r(e, t) {
					for (let n = 0, r = e.length; n < r; n++) {
						let r = e[n];
						for (let n = 0; n < r.bonds.length; n++) {
							let i = e[r.bonds[n]], a = t[r.serial];
							i && a && i.bonds.indexOf(a) < 0 && (i.bonds.push(a), i.bondOrder.push(r.bondOrder[n]));
						}
					}
				}
			},
			"./src/partialCharges.ts"(e, t, n) {
				n.r(t), n.d(t, {
					applyPartialCharges: () => i,
					partialCharges: () => r
				});
				let r = {
					"ALA:N": -.15,
					"ALA:CA": .1,
					"ALA:CB": 0,
					"ALA:C": .6,
					"ALA:O": -.55,
					"ARG:N": -.15,
					"ARG:CA": .1,
					"ARG:CB": 0,
					"ARG:CG": 0,
					"ARG:CD": .1,
					"ARG:NE": -.1,
					"ARG:CZ": .5,
					"ARG:NH1": .25,
					"ARG:NH2": .25,
					"ARG:C": .6,
					"ARG:O": -.55,
					"ASN:N": -.15,
					"ASN:CA": .1,
					"ASN:CB": 0,
					"ASN:CG": .55,
					"ASN:OD1": -.55,
					"ASN:ND2": 0,
					"ASN:C": .6,
					"ASN:O": -.55,
					"ASP:N": -.15,
					"ASP:CA": .1,
					"ASP:CB": 0,
					"ASP:CG": .14,
					"ASP:OD1": -.57,
					"ASP:OD2": -.57,
					"ASP:C": .6,
					"ASP:O": -.55,
					"CYS:N": -.15,
					"CYS:CA": .1,
					"CYS:CB": .19,
					"CYS:SG": -.19,
					"CYS:C": .6,
					"CYS:O": -.55,
					"GLN:N": -.15,
					"GLN:CA": .1,
					"GLN:CB": 0,
					"GLN:CG": 0,
					"GLN:CD": .55,
					"GLN:OE1": -.55,
					"GLN:NE2": 0,
					"GLN:C": .6,
					"GLN:O": -.55,
					"GLU:N": -.15,
					"GLU:CA": .1,
					"GLU:CB": 0,
					"GLU:CG": 0,
					"GLU:CD": .14,
					"GLU:OE1": -.57,
					"GLU:OE2": -.57,
					"GLU:C": .6,
					"GLU:O": -.55,
					"GLY:N": -.15,
					"GLY:CA": .1,
					"GLY:C": .6,
					"GLY:O": -.55,
					"HIS:N": -.15,
					"HIS:CA": .1,
					"HIS:CB": 0,
					"HIS:CG": .1,
					"HIS:ND1": -.1,
					"HIS:CD2": .1,
					"HIS:NE2": -.4,
					"HIS:CE1": .3,
					"HIS:C": .6,
					"HIS:O": -.55,
					"ILE:N": -.15,
					"ILE:CA": .1,
					"ILE:CB": 0,
					"ILE:CG2": 0,
					"ILE:CG1": 0,
					"ILE:CD": 0,
					"ILE:C": .6,
					"ILE:O": -.55,
					"LEU:N": -.15,
					"LEU:CA": .1,
					"LEU:CB": 0,
					"LEU:CG": 0,
					"LEU:CD1": 0,
					"LEU:CD2": 0,
					"LEU:C": .6,
					"LEU:O": -.55,
					"LYS:N": -.15,
					"LYS:CA": .1,
					"LYS:CB": 0,
					"LYS:CG": 0,
					"LYS:CD": 0,
					"LYS:CE": .25,
					"LYS:NZ": .75,
					"LYS:C": .6,
					"LYS:O": -.55,
					"MET:N": -.15,
					"MET:CA": .1,
					"MET:CB": 0,
					"MET:CG": .06,
					"MET:SD": -.12,
					"MET:CE": .06,
					"MET:C": .6,
					"MET:O": -.55,
					"PHE:N": -.15,
					"PHE:CA": .1,
					"PHE:CB": 0,
					"PHE:CG": 0,
					"PHE:CD1": 0,
					"PHE:CD2": 0,
					"PHE:CE1": 0,
					"PHE:CE2": 0,
					"PHE:CZ": 0,
					"PHE:C": .6,
					"PHE:O": -.55,
					"PRO:N": -.25,
					"PRO:CD": .1,
					"PRO:CA": .1,
					"PRO:CB": 0,
					"PRO:CG": 0,
					"PRO:C": .6,
					"PRO:O": -.55,
					"SER:N": -.15,
					"SER:CA": .1,
					"SER:CB": .25,
					"SER:OG": -.25,
					"SER:C": .6,
					"SER:O": -.55,
					"THR:N": -.15,
					"THR:CA": .1,
					"THR:CB": .25,
					"THR:OG1": -.25,
					"THR:CG2": 0,
					"THR:C": .6,
					"THR:O": -.55,
					"TRP:N": -.15,
					"TRP:CA": .1,
					"TRP:CB": 0,
					"TRP:CG": -.03,
					"TRP:CD2": .1,
					"TRP:CE2": -.04,
					"TRP:CE3": -.03,
					"TRP:CD1": .06,
					"TRP:NE1": -.06,
					"TRP:CZ2": 0,
					"TRP:CZ3": 0,
					"TRP:CH2": 0,
					"TRP:C": .6,
					"TRP:O": -.55,
					"TYR:N": -.15,
					"TYR:CA": .1,
					"TYR:CB": 0,
					"TYR:CG": 0,
					"TYR:CD1": 0,
					"TYR:CE1": 0,
					"TYR:CD2": 0,
					"TYR:CE2": 0,
					"TYR:CZ": .25,
					"TYR:OH": -.25,
					"TYR:C": .6,
					"TYR:O": -.55,
					"VAL:N": -.15,
					"VAL:CA": .1,
					"VAL:CB": 0,
					"VAL:CG1": 0,
					"VAL:CG2": 0,
					"VAL:C": .6,
					"VAL:O": -.55
				};
				function i(e, t) {
					if ((!t || e.partialCharge === void 0) && e.resn && e.atom) {
						var n = e.resn + ":" + e.atom;
						e.properties.partialCharge = r[n];
					}
				}
			},
			"./src/specs.ts"(e, t, n) {
				n.r(t);
			},
			"./src/utilities.ts"(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
				__webpack_require__.r(__webpack_exports__), __webpack_require__.d(__webpack_exports__, {
					PausableTimer: () => PausableTimer,
					adjustVolumeStyle: () => adjustVolumeStyle,
					base64ToArray: () => base64ToArray,
					deepCopy: () => deepCopy,
					download: () => download,
					extend: () => extend,
					get: () => get,
					getAtomProperty: () => getAtomProperty,
					getColorFromStyle: () => getColorFromStyle,
					getElement: () => getElement,
					getExtent: () => getExtent,
					getPropertyRange: () => getPropertyRange,
					getbin: () => getbin,
					inflateString: () => inflateString,
					isEmptyObject: () => isEmptyObject,
					isNumeric: () => isNumeric,
					makeFunction: () => makeFunction,
					mergeGeos: () => mergeGeos,
					specStringToObject: () => specStringToObject
				});
				var _Gradient__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/Gradient.ts"), _VolumeData__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/VolumeData.ts"), _colors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/colors.ts"), pako__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./node_modules/pako/dist/pako.esm.mjs");
				function extend(e, t) {
					for (var n in t) t.hasOwnProperty(n) && t[n] !== void 0 && (e[n] = t[n]);
					return e;
				}
				function deepCopy(e) {
					let t, n, r;
					if (e == null) return {};
					if (typeof e != "object" || !e) return e;
					for (r in t = Array.isArray(e) ? [] : {}, e) n = e[r], t[r] = deepCopy(n);
					return t;
				}
				function isNumeric(e) {
					var t = typeof e;
					return (t === "number" || t === "string") && !isNaN(e - parseFloat(e));
				}
				function isEmptyObject(e) {
					return Object.keys(e).length === 0;
				}
				function makeFunction(callback) {
					return callback && typeof callback == "string" && (callback = eval("(" + callback + ")")), callback && typeof callback != "function" ? (console.warn("Invalid callback provided."), () => {}) : callback;
				}
				function adjustVolumeStyle(e) {
					e && (e.volformat && !(e.voldata instanceof _VolumeData__WEBPACK_IMPORTED_MODULE_1__.VolumeData) && (e.voldata = new _VolumeData__WEBPACK_IMPORTED_MODULE_1__.VolumeData(e.voldata, e.volformat)), e.volscheme &&= _Gradient__WEBPACK_IMPORTED_MODULE_0__.Gradient.getGradient(e.volscheme));
				}
				function getExtent(e, t) {
					var n, r, i, a, o, s, c, l, u, d, f = !t;
					if (n = r = i = 9999, a = o = s = -9999, c = l = u = d = 0, e.length === 0) return [
						[
							0,
							0,
							0
						],
						[
							0,
							0,
							0
						],
						[
							0,
							0,
							0
						]
					];
					for (var p = 0; p < e.length; p++) {
						var m = e[p];
						if (!(m === void 0 || !isFinite(m.x) || !isFinite(m.y) || !isFinite(m.z)) && (d++, c += m.x, l += m.y, u += m.z, n = n < m.x ? n : m.x, r = r < m.y ? r : m.y, i = i < m.z ? i : m.z, a = a > m.x ? a : m.x, o = o > m.y ? o : m.y, s = s > m.z ? s : m.z, m.symmetries && f)) for (var h = 0; h < m.symmetries.length; h++) d++, c += m.symmetries[h].x, l += m.symmetries[h].y, u += m.symmetries[h].z, n = n < m.symmetries[h].x ? n : m.symmetries[h].x, r = r < m.symmetries[h].y ? r : m.symmetries[h].y, i = i < m.symmetries[h].z ? i : m.symmetries[h].z, a = a > m.symmetries[h].x ? a : m.symmetries[h].x, o = o > m.symmetries[h].y ? o : m.symmetries[h].y, s = s > m.symmetries[h].z ? s : m.symmetries[h].z;
					}
					return [
						[
							n,
							r,
							i
						],
						[
							a,
							o,
							s
						],
						[
							c / d,
							l / d,
							u / d
						]
					];
				}
				function getPropertyRange(e, t) {
					for (var n = Infinity, r = -Infinity, i = 0, a = e.length; i < a; i++) {
						var o = e[i], s = getAtomProperty(o, t);
						s != null && (s < n && (n = s), s > r && (r = s));
					}
					return !isFinite(n) && !isFinite(r) ? n = r = 0 : isFinite(n) ? isFinite(r) || (r = n) : n = r, [n, r];
				}
				class PausableTimer {
					constructor(e, t, n) {
						this.total_time_run = 0, this.fn = e, this.arg = n, this.countdown = t, this.start_time = (/* @__PURE__ */ new Date()).getTime(), this.ident = setTimeout(e, t, n);
					}
					cancel() {
						clearTimeout(this.ident);
					}
					pause() {
						clearTimeout(this.ident), this.total_time_run = (/* @__PURE__ */ new Date()).getTime() - this.start_time;
					}
					resume() {
						this.ident = setTimeout(this.fn, Math.max(0, this.countdown - this.total_time_run), this.arg);
					}
				}
				function base64ToArray(e) {
					for (var t = window.atob(e), n = t.length, r = new Uint8Array(n), i = 0; i < n; i++) r[i] = t.charCodeAt(i);
					return r;
				}
				function getAtomProperty(e, t) {
					var n = null;
					return e.properties && e.properties[t] !== void 0 ? n = e.properties[t] : e[t] !== void 0 && (n = e[t]), n;
				}
				function mergeGeos(e, t) {
					var n = t.geometry;
					n !== void 0 && e.geometryGroups.push(n.geometryGroups[0]);
				}
				function specStringToObject(e) {
					if (typeof e == "object" || e === void 0 || e == null) return e;
					try {
						return JSON.parse(e);
					} catch {}
					e = e.replace(/%7E/g, "~");
					var t = function(e) {
						return isNumeric(e) ? Math.floor(parseFloat(e)) == parseInt(e) || e.indexOf(".") >= 0 ? parseFloat(e) : parseInt(e) : e === "true" || e !== "false" && e;
					}, n = {};
					if (e === "all") return n;
					for (var r = e.split(";"), i = 0; i < r.length; i++) {
						var a = r[i].split(":"), o = a[0], s = {}, c = a[1];
						if (c) {
							if (c = c.replace(/~/g, "="), c.indexOf("=") !== -1) for (var l = c.split(","), u = 0; u < l.length; u++) {
								var d = l[u].split("=", 2);
								s[d[0]] = t(d[1]);
							}
							else s = c.indexOf(",") === -1 ? t(c) : c.split(",");
						}
						n[o] = s;
					}
					return n;
				}
				function checkStatus(e) {
					if (!e.ok) throw Error(`HTTP ${e.status} - ${e.statusText}`);
					return e;
				}
				function get(e, t) {
					var n = fetch(e).then(checkStatus).then((e) => e.text());
					return t ? n.then(t) : n;
				}
				function getbin(e, t, n, r) {
					var i = n == "POST" ? fetch(e, {
						method: "POST",
						body: r
					}).then((e) => checkStatus(e)).then((e) => e.arrayBuffer()) : fetch(e).then((e) => checkStatus(e)).then((e) => e.arrayBuffer());
					return t ? i.then(t) : i;
				}
				function download(e, t, n, r) {
					var i = "", a = "", o = "", s = null, c = t.addModel();
					e.indexOf(":") < 0 && (e = e.length == 4 ? "pdb:" + e : isNaN(e) ? "url:" + e : "cid:" + e), e.substring(0, 5) == "mmtf:" && (console.warn("WARNING: MMTF now deprecated.  Reverting to bcif."), e = "bcif:" + e.slice(5));
					var l = function(e) {
						c.addMolData(e, i, n), t.zoomTo(), t.render();
					};
					if (e.substring(0, 5) === "bcif:") e = e.substring(5).toUpperCase(), o = "https://models.rcsb.org/" + e + ".bcif.gz", n && n.noComputeSecondaryStructure === void 0 && (n.noComputeSecondaryStructure = !0), s = new Promise(function(t) {
						getbin(o).then(function(e) {
							l(e), t(c);
						}).catch(function() {
							a = n && n.pdbUri ? n.pdbUri : "https://files.rcsb.org/view/", o = a + e + ".pdb", i = "pdb", console.warn("falling back to pdb format"), get(o).then(function(e) {
								l(e), t(c);
							}).catch(function(e) {
								l(""), t(c), console.error("fetch of " + o + " failed: " + e.statusText);
							});
						});
					});
					else {
						if (e.substring(0, 4) === "pdb:") {
							if (i = "bcif", n && n.format && (i = n.format), n && n.noComputeSecondaryStructure === void 0 && (n.noComputeSecondaryStructure = !0), e = e.substring(4).toUpperCase(), !e.match(/^[1-9][A-Za-z0-9]{3}$/)) {
								alert("Wrong PDB ID");
								return;
							}
							i == "bcif" ? o = "https://models.rcsb.org/" + e.toUpperCase() + ".bcif.gz" : (a = n && n.pdbUri ? n.pdbUri : "https://files.rcsb.org/view/", o = a + e + "." + i);
						} else if (e.substring(0, 4) == "cid:") {
							if (i = "sdf", e = e.substring(4), !e.match(/^[0-9]+$/)) {
								alert("Wrong Compound ID");
								return;
							}
							o = "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/" + e + "/SDF?record_type=3d";
						} else e.substring(0, 4) == "url:" && (o = e.substring(4), i = o);
						s = new Promise(function(t) {
							i == "bcif" ? getbin(o).then(function(e) {
								l(e), t(c);
							}).catch(function() {
								a = n && n.pdbUri ? n.pdbUri : "https://files.rcsb.org/view/", o = a + e + ".pdb", i = "pdb", console.warn("falling back to pdb format"), get(o).then(function(e) {
									l(e), t(c);
								}).catch(function(e) {
									l(""), t(c), console.error("fetch of " + o + " failed: " + e.statusText);
								});
							}) : get(o).then(function(e) {
								l(e), t(c);
							}).catch(function(e) {
								l(""), t(c), console.error("fetch of " + o + " failed: " + e.statusText);
							});
						});
					}
					return r ? (s.then(function(e) {
						r(e);
					}), c) : s;
				}
				function getColorFromStyle(e, t) {
					let n = t.colorscheme;
					if (_colors__WEBPACK_IMPORTED_MODULE_2__.builtinColorSchemes[n] !== void 0) n = _colors__WEBPACK_IMPORTED_MODULE_2__.builtinColorSchemes[n];
					else if (typeof n == "string" && n.endsWith("Carbon")) {
						let e = n.substring(0, n.lastIndexOf("Carbon")).toLowerCase();
						if (_colors__WEBPACK_IMPORTED_MODULE_2__.htmlColors[e] !== void 0) {
							let t = Object.assign({}, _colors__WEBPACK_IMPORTED_MODULE_2__.elementColors.defaultColors);
							t.C = _colors__WEBPACK_IMPORTED_MODULE_2__.htmlColors[e], _colors__WEBPACK_IMPORTED_MODULE_2__.builtinColorSchemes[n] = {
								prop: "elem",
								map: t
							}, n = _colors__WEBPACK_IMPORTED_MODULE_2__.builtinColorSchemes[n];
						}
					}
					let r = e.color;
					if (t.color !== void 0 && t.color != "spectrum" && (r = t.color), n !== void 0) {
						let a, o;
						if (_colors__WEBPACK_IMPORTED_MODULE_2__.elementColors[n] !== void 0) n = _colors__WEBPACK_IMPORTED_MODULE_2__.elementColors[n], n[e[n.prop]] !== void 0 && (r = n.map[e[n.prop]]);
						else if (n[e[n.prop]] !== void 0) r = n.map[e[n.prop]];
						else if (n.prop !== void 0 && n.gradient !== void 0) {
							a = n.prop;
							var i = n.gradient;
							i instanceof _Gradient__WEBPACK_IMPORTED_MODULE_0__.GradientType || (i = (0, _Gradient__WEBPACK_IMPORTED_MODULE_0__.getGradient)(n));
							let t = i.range() || [-1, 1];
							o = getAtomProperty(e, a), o != null && (r = i.valueToHex(o, t));
						} else n.prop !== void 0 && n.map !== void 0 ? (a = n.prop, o = getAtomProperty(e, a), n.map[o] !== void 0 && (r = n.map[o])) : t.colorscheme[e.elem] === void 0 ? console.warn("Could not interpret colorscheme " + n) : r = t.colorscheme[e.elem];
					} else t.colorfunc !== void 0 && (r = t.colorfunc(e));
					return _colors__WEBPACK_IMPORTED_MODULE_2__.CC.color(r);
				}
				function getElement(e) {
					let t = e;
					return typeof e == "string" ? t = document.querySelector("#" + e) : typeof e == "object" && e.get && (t = e.get(0)), t;
				}
				function inflateString(e, t = !0) {
					let n;
					return n = typeof e == "string" ? new TextEncoder().encode(e) : new Uint8Array(e), (0, pako__WEBPACK_IMPORTED_MODULE_3__.inflate)(n, { to: t ? "string" : null });
				}
			},
			"./src/vendor/mmtf.js"(e, t) {
				(function(e, n) {
					n(t);
				})(this, function(e) {
					function t(e, t, n) {
						for (var r = (e.byteLength, 0), i = n.length; i > r; r++) {
							var a = n.charCodeAt(r);
							if (128 > a) e.setUint8(t++, a >>> 0 & 127 | 0);
							else if (2048 > a) e.setUint8(t++, a >>> 6 & 31 | 192), e.setUint8(t++, a >>> 0 & 63 | 128);
							else if (65536 > a) e.setUint8(t++, a >>> 12 & 15 | 224), e.setUint8(t++, a >>> 6 & 63 | 128), e.setUint8(t++, a >>> 0 & 63 | 128);
							else {
								if (!(1114112 > a)) throw Error("bad codepoint " + a);
								e.setUint8(t++, a >>> 18 & 7 | 240), e.setUint8(t++, a >>> 12 & 63 | 128), e.setUint8(t++, a >>> 6 & 63 | 128), e.setUint8(t++, a >>> 0 & 63 | 128);
							}
						}
					}
					function n(e) {
						for (var t = 0, n = 0, r = e.length; r > n; n++) {
							var i = e.charCodeAt(n);
							if (128 > i) t += 1;
							else if (2048 > i) t += 2;
							else if (65536 > i) t += 3;
							else {
								if (!(1114112 > i)) throw Error("bad codepoint " + i);
								t += 4;
							}
						}
						return t;
					}
					function r(e, i, a) {
						var o = typeof e;
						if (o === "string") {
							var s = n(e);
							if (32 > s) return i.setUint8(a, 160 | s), t(i, a + 1, e), 1 + s;
							if (256 > s) return i.setUint8(a, 217), i.setUint8(a + 1, s), t(i, a + 2, e), 2 + s;
							if (65536 > s) return i.setUint8(a, 218), i.setUint16(a + 1, s), t(i, a + 3, e), 3 + s;
							if (4294967296 > s) return i.setUint8(a, 219), i.setUint32(a + 1, s), t(i, a + 5, e), 5 + s;
						}
						if (e instanceof Uint8Array) {
							var s = e.byteLength, c = new Uint8Array(i.buffer);
							if (256 > s) return i.setUint8(a, 196), i.setUint8(a + 1, s), c.set(e, a + 2), 2 + s;
							if (65536 > s) return i.setUint8(a, 197), i.setUint16(a + 1, s), c.set(e, a + 3), 3 + s;
							if (4294967296 > s) return i.setUint8(a, 198), i.setUint32(a + 1, s), c.set(e, a + 5), 5 + s;
						}
						if (o === "number") {
							if (!isFinite(e)) throw Error("Number not finite: " + e);
							if (Math.floor(e) !== e) return i.setUint8(a, 203), i.setFloat64(a + 1, e), 9;
							if (e >= 0) {
								if (128 > e) return i.setUint8(a, e), 1;
								if (256 > e) return i.setUint8(a, 204), i.setUint8(a + 1, e), 2;
								if (65536 > e) return i.setUint8(a, 205), i.setUint16(a + 1, e), 3;
								if (4294967296 > e) return i.setUint8(a, 206), i.setUint32(a + 1, e), 5;
								throw Error("Number too big 0x" + e.toString(16));
							}
							if (e >= -32) return i.setInt8(a, e), 1;
							if (e >= -128) return i.setUint8(a, 208), i.setInt8(a + 1, e), 2;
							if (e >= -32768) return i.setUint8(a, 209), i.setInt16(a + 1, e), 3;
							if (e >= -2147483648) return i.setUint8(a, 210), i.setInt32(a + 1, e), 5;
							throw Error("Number too small -0x" + (-e).toString(16).substr(1));
						}
						if (e === null) return i.setUint8(a, 192), 1;
						if (o === "boolean") return i.setUint8(a, e ? 195 : 194), 1;
						if (o === "object") {
							var s, l = 0, u = Array.isArray(e);
							if (u) s = e.length;
							else {
								var d = Object.keys(e);
								s = d.length;
							}
							var l;
							if (16 > s ? (i.setUint8(a, s | (u ? 144 : 128)), l = 1) : 65536 > s ? (i.setUint8(a, u ? 220 : 222), i.setUint16(a + 1, s), l = 3) : 4294967296 > s && (i.setUint8(a, u ? 221 : 223), i.setUint32(a + 1, s), l = 5), u) for (var f = 0; s > f; f++) l += r(e[f], i, a + l);
							else for (var f = 0; s > f; f++) {
								var p = d[f];
								l += r(p, i, a + l), l += r(e[p], i, a + l);
							}
							return l;
						}
						throw Error("Unknown type " + o);
					}
					function i(e) {
						var t = typeof e;
						if (t === "string") {
							var r = n(e);
							if (32 > r) return 1 + r;
							if (256 > r) return 2 + r;
							if (65536 > r) return 3 + r;
							if (4294967296 > r) return 5 + r;
						}
						if (e instanceof Uint8Array) {
							var r = e.byteLength;
							if (256 > r) return 2 + r;
							if (65536 > r) return 3 + r;
							if (4294967296 > r) return 5 + r;
						}
						if (t === "number") {
							if (Math.floor(e) !== e) return 9;
							if (e >= 0) {
								if (128 > e) return 1;
								if (256 > e) return 2;
								if (65536 > e) return 3;
								if (4294967296 > e) return 5;
								throw Error("Number too big 0x" + e.toString(16));
							}
							if (e >= -32) return 1;
							if (e >= -128) return 2;
							if (e >= -32768) return 3;
							if (e >= -2147483648) return 5;
							throw Error("Number too small -0x" + e.toString(16).substr(1));
						}
						if (t === "boolean" || e === null) return 1;
						if (t === "object") {
							var r, a = 0;
							if (Array.isArray(e)) {
								r = e.length;
								for (var o = 0; r > o; o++) a += i(e[o]);
							} else {
								var s = Object.keys(e);
								r = s.length;
								for (var o = 0; r > o; o++) {
									var c = s[o];
									a += i(c) + i(e[c]);
								}
							}
							if (16 > r) return 1 + a;
							if (65536 > r) return 3 + a;
							if (4294967296 > r) return 5 + a;
							throw Error("Array or object too long 0x" + r.toString(16));
						}
						throw Error("Unknown type " + t);
					}
					function a(e) {
						var t = new ArrayBuffer(i(e));
						return r(e, new DataView(t), 0), new Uint8Array(t);
					}
					function o(e, t, n) {
						return t ? new e(t.buffer, t.byteOffset, t.byteLength / (n || 1)) : void 0;
					}
					function s(e) {
						return o(DataView, e);
					}
					function c(e) {
						return o(Uint8Array, e);
					}
					function l(e) {
						return o(Int8Array, e);
					}
					function u(e) {
						return o(Int32Array, e, 4);
					}
					function d(e) {
						return o(Float32Array, e, 4);
					}
					function f(e, t) {
						var n = e.length / 2;
						t ||= new Int16Array(n);
						for (var r = 0, i = 0; n > r; ++r, i += 2) t[r] = e[i] << 8 ^ e[i + 1] << 0;
						return t;
					}
					function p(e, t) {
						var n = e.length;
						t ||= new Uint8Array(2 * n);
						for (var r = s(t), i = 0; n > i; ++i) r.setInt16(2 * i, e[i]);
						return c(t);
					}
					function m(e, t) {
						var n = e.length / 4;
						t ||= new Int32Array(n);
						for (var r = 0, i = 0; n > r; ++r, i += 4) t[r] = e[i] << 24 ^ e[i + 1] << 16 ^ e[i + 2] << 8 ^ e[i + 3] << 0;
						return t;
					}
					function h(e, t) {
						var n = e.length;
						t ||= new Uint8Array(4 * n);
						for (var r = s(t), i = 0; n > i; ++i) r.setInt32(4 * i, e[i]);
						return c(t);
					}
					function g(e, t) {
						var n = e.length;
						t ||= new Float32Array(n / 4);
						for (var r = s(t), i = s(e), a = 0, o = 0, c = n / 4; c > a; ++a, o += 4) r.setFloat32(o, i.getFloat32(o), !0);
						return t;
					}
					function _(e, t, n) {
						var r = e.length, i = 1 / t;
						n ||= new Float32Array(r);
						for (var a = 0; r > a; ++a) n[a] = e[a] * i;
						return n;
					}
					function v(e, t, n) {
						var r = e.length;
						n ||= new Int32Array(r);
						for (var i = 0; r > i; ++i) n[i] = Math.round(e[i] * t);
						return n;
					}
					function y(e, t) {
						var n, r;
						if (!t) {
							var i = 0;
							for (n = 0, r = e.length; r > n; n += 2) i += e[n + 1];
							t = new e.constructor(i);
						}
						var a = 0;
						for (n = 0, r = e.length; r > n; n += 2) for (var o = e[n], s = e[n + 1], c = 0; s > c; ++c) t[a] = o, ++a;
						return t;
					}
					function b(e) {
						if (e.length === 0) return /* @__PURE__ */ new Int32Array();
						var t, n, r = 2;
						for (t = 1, n = e.length; n > t; ++t) e[t - 1] !== e[t] && (r += 2);
						var i = new Int32Array(r), a = 0, o = 1;
						for (t = 1, n = e.length; n > t; ++t) e[t - 1] === e[t] ? ++o : (i[a] = e[t - 1], i[a + 1] = o, o = 1, a += 2);
						return i[a] = e[e.length - 1], i[a + 1] = o, i;
					}
					function x(e, t) {
						var n = e.length;
						t ||= new e.constructor(n), n && (t[0] = e[0]);
						for (var r = 1; n > r; ++r) t[r] = e[r] + t[r - 1];
						return t;
					}
					function S(e, t) {
						var n = e.length;
						t ||= new e.constructor(n), t[0] = e[0];
						for (var r = 1; n > r; ++r) t[r] = e[r] - e[r - 1];
						return t;
					}
					function C(e, t) {
						var n, r, i = e instanceof Int8Array ? 127 : 32767, a = -i - 1, o = e.length;
						if (!t) {
							var s = 0;
							for (n = 0; o > n; ++n) e[n] < i && e[n] > a && ++s;
							t = new Int32Array(s);
						}
						for (n = 0, r = 0; o > n;) {
							for (var c = 0; e[n] === i || e[n] === a;) c += e[n], ++n;
							c += e[n], ++n, t[r] = c, ++r;
						}
						return t;
					}
					function w(e, t) {
						var n, r = t ? 127 : 32767, i = -r - 1, a = e.length, o = 0;
						for (n = 0; a > n; ++n) {
							var s = e[n];
							s === 0 ? ++o : s > 0 ? (o += Math.ceil(s / r), s % r === 0 && (o += 1)) : (o += Math.ceil(s / i), s % i === 0 && (o += 1));
						}
						var c = t ? new Int8Array(o) : new Int16Array(o), l = 0;
						for (n = 0; a > n; ++n) {
							var s = e[n];
							if (s >= 0) for (; s >= r;) c[l] = r, ++l, s -= r;
							else for (; i >= s;) c[l] = i, ++l, s -= i;
							c[l] = s, ++l;
						}
						return c;
					}
					function T(e, t) {
						return x(y(e), t);
					}
					function E(e) {
						return b(S(e));
					}
					function D(e, t, n) {
						return _(y(e, u(n)), t, n);
					}
					function O(e, t) {
						return b(v(e, t));
					}
					function k(e, t, n) {
						return _(x(e, u(n)), t, n);
					}
					function A(e, t, n) {
						return S(v(e, t), n);
					}
					function j(e, t, n) {
						return _(C(e, u(n)), t, n);
					}
					function M(e, t, n) {
						var r = C(e, u(n));
						return k(r, t, d(r));
					}
					function N(e, t, n) {
						return w(A(e, t), n);
					}
					function P(e) {
						var t = s(e), n = t.getInt32(0), r = t.getInt32(4), i = e.subarray(8, 12), e = e.subarray(12);
						return [
							n,
							e,
							r,
							i
						];
					}
					function F(e, t, n, r) {
						var i = new ArrayBuffer(12 + r.byteLength), a = new Uint8Array(i), o = new DataView(i);
						return o.setInt32(0, e), o.setInt32(4, t), n && a.set(n, 8), a.set(r, 12), a;
					}
					function I(e) {
						var t = e.length;
						return F(2, t, void 0, c(e));
					}
					function L(e) {
						var t = e.length;
						return F(4, t, void 0, h(e));
					}
					function R(e, t) {
						return F(5, e.length / t, h([t]), c(e));
					}
					function z(e) {
						var t = e.length;
						return F(6, t, void 0, h(b(e)));
					}
					function B(e) {
						var t = e.length;
						return F(8, t, void 0, h(E(e)));
					}
					function V(e, t) {
						var n = e.length;
						return F(9, n, h([t]), h(O(e, t)));
					}
					function H(e, t) {
						var n = e.length;
						return F(10, n, h([t]), p(N(e, t)));
					}
					function U(e) {
						var t = {};
						return q.forEach(function(n) {
							e[n] !== void 0 && (t[n] = e[n]);
						}), e.bondAtomList && (t.bondAtomList = L(e.bondAtomList)), e.bondOrderList && (t.bondOrderList = I(e.bondOrderList)), t.xCoordList = H(e.xCoordList, 1e3), t.yCoordList = H(e.yCoordList, 1e3), t.zCoordList = H(e.zCoordList, 1e3), e.bFactorList && (t.bFactorList = H(e.bFactorList, 100)), e.atomIdList && (t.atomIdList = B(e.atomIdList)), e.altLocList && (t.altLocList = z(e.altLocList)), e.occupancyList && (t.occupancyList = V(e.occupancyList, 100)), t.groupIdList = B(e.groupIdList), t.groupTypeList = L(e.groupTypeList), e.secStructList && (t.secStructList = I(e.secStructList)), e.insCodeList && (t.insCodeList = z(e.insCodeList)), e.sequenceIndexList && (t.sequenceIndexList = B(e.sequenceIndexList)), t.chainIdList = R(e.chainIdList, 4), e.chainNameList && (t.chainNameList = R(e.chainNameList, 4)), t;
					}
					function W(e) {
						function t(e) {
							for (var t = {}, n = 0; e > n; n++) {
								var r = a();
								t[r] = a();
							}
							return t;
						}
						function n(t) {
							var n = e.subarray(o, o + t);
							return o += t, n;
						}
						function r(t) {
							var n = e.subarray(o, o + t);
							o += t;
							var r = 65535;
							if (t > r) {
								for (var i = [], a = 0; a < n.length; a += r) i.push(String.fromCharCode.apply(null, n.subarray(a, a + r)));
								return i.join("");
							}
							return String.fromCharCode.apply(null, n);
						}
						function i(e) {
							for (var t = Array(e), n = 0; e > n; n++) t[n] = a();
							return t;
						}
						function a() {
							var a, c, l = e[o];
							if (!(128 & l)) return o++, l;
							if ((240 & l) == 128) return c = 15 & l, o++, t(c);
							if ((240 & l) == 144) return c = 15 & l, o++, i(c);
							if ((224 & l) == 160) return c = 31 & l, o++, r(c);
							if ((224 & l) == 224) return a = s.getInt8(o), o++, a;
							switch (l) {
								case 192: return o++, null;
								case 194: return o++, !1;
								case 195: return o++, !0;
								case 196: return c = s.getUint8(o + 1), o += 2, n(c);
								case 197: return c = s.getUint16(o + 1), o += 3, n(c);
								case 198: return c = s.getUint32(o + 1), o += 5, n(c);
								case 202: return a = s.getFloat32(o + 1), o += 5, a;
								case 203: return a = s.getFloat64(o + 1), o += 9, a;
								case 204: return a = e[o + 1], o += 2, a;
								case 205: return a = s.getUint16(o + 1), o += 3, a;
								case 206: return a = s.getUint32(o + 1), o += 5, a;
								case 208: return a = s.getInt8(o + 1), o += 2, a;
								case 209: return a = s.getInt16(o + 1), o += 3, a;
								case 210: return a = s.getInt32(o + 1), o += 5, a;
								case 217: return c = s.getUint8(o + 1), o += 2, r(c);
								case 218: return c = s.getUint16(o + 1), o += 3, r(c);
								case 219: return c = s.getUint32(o + 1), o += 5, r(c);
								case 220: return c = s.getUint16(o + 1), o += 3, i(c);
								case 221: return c = s.getUint32(o + 1), o += 5, i(c);
								case 222: return c = s.getUint16(o + 1), o += 3, t(c);
								case 223: return c = s.getUint32(o + 1), o += 5, t(c);
							}
							throw Error("Unknown type 0x" + l.toString(16));
						}
						var o = 0, s = new DataView(e.buffer);
						return a();
					}
					function G(e, t, n, r) {
						switch (e) {
							case 1: return g(t);
							case 2: return l(t);
							case 3: return f(t);
							case 4: return m(t);
							case 5: return c(t);
							case 6: return y(m(t), new Uint8Array(n));
							case 7: return y(m(t));
							case 8: return T(m(t));
							case 9: return D(m(t), m(r)[0]);
							case 10: return M(f(t), m(r)[0]);
							case 11: return _(f(t), m(r)[0]);
							case 12: return j(f(t), m(r)[0]);
							case 13: return j(l(t), m(r)[0]);
							case 14: return C(f(t));
							case 15: return C(l(t));
						}
					}
					function ee(e, t) {
						t ||= {};
						var n = t.ignoreFields, r = {};
						return J.forEach(function(t) {
							var i = n ? n.indexOf(t) !== -1 : !1, a = e[t];
							i || a === void 0 || (r[t] = a instanceof Uint8Array ? G.apply(null, P(a)) : a);
						}), r;
					}
					function te(e) {
						return String.fromCharCode.apply(null, e).replace(/\0/g, "");
					}
					function ne(e, t, n) {
						n ||= {};
						var r, i, a, o, s, c, l = n.firstModelOnly, u = t.onModel, d = t.onChain, f = t.onGroup, p = t.onAtom, m = t.onBond, h = 0, g = 0, _ = 0, v = 0, y = 0, b = -1, x = e.chainNameList, S = e.secStructList, C = e.insCodeList, w = e.sequenceIndexList, T = e.atomIdList, E = e.bFactorList, D = e.altLocList, O = e.occupancyList, k = e.bondAtomList, A = e.bondOrderList;
						for (r = 0, i = e.chainsPerModel.length; i > r && !(l && h > 0); ++r) {
							var j = e.chainsPerModel[h];
							for (u && u({
								chainCount: j,
								modelIndex: h
							}), a = 0; j > a; ++a) {
								var M = e.groupsPerChain[g];
								if (d) {
									var N = te(e.chainIdList.subarray(4 * g, 4 * g + 4)), P = null;
									x && (P = te(x.subarray(4 * g, 4 * g + 4))), d({
										groupCount: M,
										chainIndex: g,
										modelIndex: h,
										chainId: N,
										chainName: P
									});
								}
								for (o = 0; M > o; ++o) {
									var F = e.groupList[e.groupTypeList[_]], I = F.atomNameList.length;
									if (f) {
										var L = null;
										S && (L = S[_]);
										var R = null;
										e.insCodeList && (R = String.fromCharCode(C[_]));
										var z = null;
										w && (z = w[_]), f({
											atomCount: I,
											groupIndex: _,
											chainIndex: g,
											modelIndex: h,
											groupId: e.groupIdList[_],
											groupType: e.groupTypeList[_],
											groupName: F.groupName,
											singleLetterCode: F.singleLetterCode,
											chemCompType: F.chemCompType,
											secStruct: L,
											insCode: R,
											sequenceIndex: z
										});
									}
									for (s = 0; I > s; ++s) {
										if (p) {
											var B = null;
											T && (B = T[v]);
											var V = null;
											E && (V = E[v]);
											var H = null;
											D && (H = String.fromCharCode(D[v]));
											var U = null;
											O && (U = O[v]), p({
												atomIndex: v,
												groupIndex: _,
												chainIndex: g,
												modelIndex: h,
												atomId: B,
												element: F.elementList[s],
												atomName: F.atomNameList[s],
												formalCharge: F.formalChargeList[s],
												xCoord: e.xCoordList[v],
												yCoord: e.yCoordList[v],
												zCoord: e.zCoordList[v],
												bFactor: V,
												altLoc: H,
												occupancy: U
											});
										}
										v += 1;
									}
									if (m) {
										var W = F.bondAtomList;
										for (s = 0, c = F.bondOrderList.length; c > s; ++s) m({
											atomIndex1: v - I + W[2 * s],
											atomIndex2: v - I + W[2 * s + 1],
											bondOrder: F.bondOrderList[s]
										});
									}
									_ += 1;
								}
								g += 1;
							}
							if (y = b + 1, b = v - 1, m && k) for (s = 0, c = k.length; c > s; s += 2) {
								var G = k[s], ee = k[s + 1];
								(G >= y && b >= G || ee >= y && b >= ee) && m({
									atomIndex1: G,
									atomIndex2: ee,
									bondOrder: A ? A[s / 2] : null
								});
							}
							h += 1;
						}
					}
					function re(e) {
						return a(U(e));
					}
					function ie(e, t) {
						e instanceof ArrayBuffer && (e = new Uint8Array(e));
						var n;
						return n = e instanceof Uint8Array ? W(e) : e, ee(n, t);
					}
					function K(e, t, n, r) {
						function i() {
							try {
								n(ie(a.response));
							} catch (e) {
								r(e);
							}
						}
						var a = new XMLHttpRequest();
						a.addEventListener("load", i, !0), a.addEventListener("error", r, !0), a.responseType = "arraybuffer", a.open("GET", t + e.toUpperCase()), a.send();
					}
					function ae(e, t, n) {
						K(e, ce, t, n);
					}
					function oe(e, t, n) {
						K(e, X, t, n);
					}
					var q = [
						"mmtfVersion",
						"mmtfProducer",
						"unitCell",
						"spaceGroup",
						"structureId",
						"title",
						"depositionDate",
						"releaseDate",
						"experimentalMethods",
						"resolution",
						"rFree",
						"rWork",
						"bioAssemblyList",
						"ncsOperatorList",
						"entityList",
						"groupList",
						"numBonds",
						"numAtoms",
						"numGroups",
						"numChains",
						"numModels",
						"groupsPerChain",
						"chainsPerModel"
					], J = q.concat([
						"xCoordList",
						"yCoordList",
						"zCoordList",
						"groupIdList",
						"groupTypeList",
						"chainIdList",
						"bFactorList",
						"atomIdList",
						"altLocList",
						"occupancyList",
						"secStructList",
						"insCodeList",
						"sequenceIndexList",
						"chainNameList",
						"bondAtomList",
						"bondOrderList"
					]), Y = "v1.0.1", se = "//mmtf.rcsb.org/v1.0/", ce = se + "full/", X = se + "reduced/";
					e.encode = re, e.decode = ie, e.traverse = ne, e.fetch = ae, e.fetchReduced = oe, e.version = Y, e.fetchUrl = ce, e.fetchReducedUrl = X, e.encodeMsgpack = a, e.encodeMmtf = U, e.decodeMsgpack = W, e.decodeMmtf = ee;
				});
			}
		}, __webpack_module_cache__ = {};
		function __webpack_require__(e) {
			var t = __webpack_module_cache__[e];
			if (t !== void 0) return t.exports;
			if (__webpack_modules__[e] === void 0) {
				var n = /* @__PURE__ */ Error("Cannot find module '" + e + "'");
				throw n.code = "MODULE_NOT_FOUND", n;
			}
			var r = __webpack_module_cache__[e] = { exports: {} };
			return __webpack_modules__[e].call(r.exports, r, r.exports, __webpack_require__), r.exports;
		}
		__webpack_require__.n = (e) => {
			var t = e && e.__esModule ? () => e.default : () => e;
			return __webpack_require__.d(t, { a: t }), t;
		}, __webpack_require__.d = (e, t) => {
			for (var n in t) __webpack_require__.o(t, n) && !__webpack_require__.o(e, n) && Object.defineProperty(e, n, {
				enumerable: !0,
				get: t[n]
			});
		}, __webpack_require__.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), __webpack_require__.r = (e) => {
			typeof Symbol < "u" && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e, "__esModule", { value: !0 });
		}, __webpack_require__("./src/index.ts"), __webpack_require__("./src/SurfaceWorker.js");
		var __webpack_exports__ = __webpack_require__("./src/exporter.js");
		return __webpack_exports__;
	})());
}));
//#endregion
export default require__3Dmol();
