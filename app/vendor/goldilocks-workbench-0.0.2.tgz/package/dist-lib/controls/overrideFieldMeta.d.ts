import { ReactNode } from 'react';
import { Source } from '../api/coreClient';
export interface OverrideFieldMeta {
    readonly key: string;
    readonly type: string;
    readonly enum?: readonly string[] | undefined;
    readonly unit?: string | null;
    readonly default?: unknown;
    readonly description: string;
}
export declare function fieldLabel(meta: OverrideFieldMeta): string;
/** `unknown`-safe stringification -- most override values are
 * primitives, but array/object-shaped ones (`k_grid`, `u_by_element`)
 * would otherwise stringify to the useless `"[object Object]"`. */
export declare function stringifyValue(value: unknown): string;
export declare function automaticPlaceholder(meta: OverrideFieldMeta): string;
/** A boolean/enum `OverrideControl`'s own description names whichever
 * tier actually produced the value the select shows -- "Your override"
 * once pinned, else whatever tier resolved it (heuristic/ml/llm),
 * else the field's own description alone when nothing has resolved yet. */
export declare function describeSource(description: string, pinned: boolean, source: Source | null | undefined): ReactNode;
