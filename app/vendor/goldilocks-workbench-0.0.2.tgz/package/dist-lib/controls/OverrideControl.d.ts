import { Source } from '../api/coreClient';
import { OverrideFieldMeta } from './overrideFieldMeta';
/** One human/heuristic override control, generic over the field's
 * declared `type` -- shared by the advisors accordion (settings) and
 * the analysis section (facts), since both are the same
 * human > ml > llm > heuristic override shape underneath.
 *
 * `resolvedValue`/`source` (boolean/enum fields only): the select shows
 * *this exact* value pre-selected -- and its own description names the
 * tier that produced it -- rather than a separate "Automatic" list entry
 * that revealed nothing about what automatic actually resolved to. A
 * human override still wins once set (`pinned`); `CloseButton` is the
 * only way back to automatic now that the select's own option list holds
 * nothing but genuine values. */
export declare function OverrideControl({ meta, value, resolvedValue, source, disabled, onChange, }: {
    readonly meta: OverrideFieldMeta;
    readonly value: unknown;
    readonly resolvedValue?: unknown;
    readonly source?: Source | null | undefined;
    readonly disabled: boolean;
    readonly onChange: (value: unknown) => void;
}): import('react').JSX.Element;
