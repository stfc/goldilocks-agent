import { StructureInput, StructureInspection } from '../api/coreClient';
export declare function StructureSourceControls({ source, inspection, inspecting, onOpen, }: {
    readonly source: StructureInput | null;
    readonly inspection: StructureInspection | null;
    readonly inspecting: boolean;
    readonly onOpen: (input: StructureInput) => Promise<void>;
}): import('react').JSX.Element;
