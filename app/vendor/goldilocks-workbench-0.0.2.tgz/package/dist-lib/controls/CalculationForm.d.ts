/** Code/Task/HPC profile: which target this calculation is even for, as
 * opposed to `CalculationForm` below's per-step *settings* for that
 * target. Lives in `StructureCard` (v2 epic 12 follow-up) -- right
 * between loading a structure and viewing it, since it's the other
 * half of "what am I calculating" alongside the structure itself,
 * rather than a settings-tuning concern like the accordion is. */
export declare function CalculationContextControls(): import('react').JSX.Element | null;
export declare function CalculationForm(): import('react').JSX.Element | null;
