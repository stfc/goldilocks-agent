import { ArchiveDownload, CalcTask, Capabilities, CoreClient, ExplainResult, MagneticOrderingsResult, StructureInput, StructureInspection, CoreFailure } from '../api/coreClient';
export type WorkspaceOperation = "capabilities" | "inspect" | "explain" | "download";
/** Independent of `WorkspaceOperation`: listing/ranking/downloading
 * magnetic-ordering candidates is an opt-in side-quest a user runs from
 * the Advisors card, not the main structure -> compute -> download
 * pipeline -- it must not disable the rest of that pipeline's controls
 * (or vice versa) while in flight. One nullable field, same idiom as
 * `WorkspaceOperation` itself, covering its own three concerns. */
export type MagneticOrderingsOperation = "list" | "rank" | "download";
/** The v2 request shape has no `intent`/`hints` vocabulary: every tunable
 * knob is a flat `overrides` entry reflected from `capabilities().settings`/
 * `.facts` (see `capabilities.py`'s own "add an advisor, its settings
 * automatically appear" design goal). A key's absence from `overrides`
 * means "let the heuristic/ml/llm chain decide" -- there is no separate
 * "automatic" sentinel value, matching `--set`'s own semantics. */
export interface CalculationDraft {
    readonly code: string;
    readonly task: CalcTask;
    readonly hpc: string | null;
    readonly overrides: Readonly<Record<string, unknown>>;
    readonly fetchMissing: boolean;
}
export interface WorkspaceSnapshot {
    readonly capabilities: Capabilities | null;
    readonly structureInput: StructureInput | null;
    readonly attemptedStructureInput: StructureInput | null;
    readonly inspection: StructureInspection | null;
    readonly draft: CalculationDraft | null;
    /** The last `/explain` preview -- records + warnings, no files. Never
     * carries an archive: `/explain` never calls `generate()`, so it can
     * succeed even when a `/run` would still refuse with
     * `advice_incomplete` (the tri-state "diagnosis is always available"
     * promise). Downloading real files is a separate `review.download`
     * step against `/run`. */
    readonly reviewed: ExplainResult | null;
    readonly outOfDate: boolean;
    readonly lastDownload: ArchiveDownload | null;
    readonly operation: WorkspaceOperation | null;
    readonly failure: CoreFailure | null;
    readonly failureOperation: WorkspaceOperation | null;
    readonly magneticOrderings: MagneticOrderingsResult | null;
    readonly magneticOrderingsOperation: MagneticOrderingsOperation | null;
    /** Shown inline in the Advisors card, not the global `FailureBanner` --
     * this is a side-quest failure, not a reason to block the main
     * pipeline the banner exists for. */
    readonly magneticOrderingsError: string | null;
}
export type WorkspaceAction = {
    readonly type: "workspace.start";
} | {
    readonly type: "source.open";
    readonly input: StructureInput;
} | {
    readonly type: "draft.patch";
    readonly code?: string;
    readonly task?: CalcTask;
    readonly hpc?: string | null;
    /** Shallow-merged into the current overrides. A value of
     * `undefined` clears that key back to "automatic" rather than
     * setting it to `undefined` on the wire. */
    readonly overrides?: Readonly<Record<string, unknown>>;
} | {
    readonly type: "review.compute";
}
/** Fetches a fresh archive for live preview without saving it anywhere
 * -- the auto-preview effect calls this, not a user action. */
 | {
    readonly type: "review.refreshArchive";
} | {
    readonly type: "review.download";
} | {
    readonly type: "magneticOrderings.list";
} | {
    readonly type: "magneticOrderings.rank";
} | {
    readonly type: "magneticOrderings.downloadSelected";
    readonly labels: readonly string[];
} | {
    readonly type: "failure.retry";
} | {
    readonly type: "failure.dismiss";
} | {
    readonly type: "workspace.reset";
};
export interface Workspace {
    getSnapshot(): WorkspaceSnapshot;
    subscribe(listener: () => void): () => void;
    dispatch(action: WorkspaceAction): Promise<void>;
}
type ArchiveSink = (archive: ArchiveDownload) => void;
export declare function createWorkspace(core: CoreClient, saveArchive?: ArchiveSink): Workspace;
export declare function saveArchiveToBrowser(archive: ArchiveDownload): void;
export {};
