import { Workspace, WorkspaceSnapshot } from './workspace';
/** There is no manual "generate"/"update recommendation" control in the
 * UI -- whatever structure is loaded should always drive what the
 * review/scientific-facts cards show, so a recommendation is computed
 * automatically (debounced) on load and after every later settings
 * change, reusing `outOfDate`'s existing staleness tracking to also
 * catch an edit that landed while a request was already in flight. A
 * live, undismissed `explain` failure blocks further auto-attempts --
 * otherwise a persistently failing structure would retry forever. */
export declare function useAutoCompute(workspace: Workspace, snapshot: WorkspaceSnapshot): void;
