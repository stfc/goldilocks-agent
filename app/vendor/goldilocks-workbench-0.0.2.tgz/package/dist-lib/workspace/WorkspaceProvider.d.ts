import { ReactNode } from 'react';
import { Workspace } from './workspace';
export declare function WorkspaceProvider({ workspace, children, }: {
    readonly workspace: Workspace;
    readonly children: ReactNode;
}): import('react').JSX.Element;
