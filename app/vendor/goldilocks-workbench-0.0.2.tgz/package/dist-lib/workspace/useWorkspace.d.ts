import { Workspace, WorkspaceSnapshot } from './workspace';
export declare function useWorkspace(): Workspace;
export declare function useWorkspaceSnapshot(): WorkspaceSnapshot;
