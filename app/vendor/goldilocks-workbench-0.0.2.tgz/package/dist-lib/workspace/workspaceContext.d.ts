import { Workspace } from './workspace';
export declare const WorkspaceContext: import('react').Context<Workspace | null>;
