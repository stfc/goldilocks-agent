export declare function AdvisorsCard({ kicker }: {
    readonly kicker: string;
}): import('react').JSX.Element;
