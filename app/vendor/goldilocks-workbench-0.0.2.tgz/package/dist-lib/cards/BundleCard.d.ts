export declare function BundleCard({ kicker }: {
    readonly kicker: string;
}): import('react').JSX.Element;
