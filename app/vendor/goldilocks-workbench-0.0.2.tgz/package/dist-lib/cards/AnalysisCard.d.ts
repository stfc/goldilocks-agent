export declare function AnalysisCard({ kicker }: {
    readonly kicker: string;
}): import('react').JSX.Element;
