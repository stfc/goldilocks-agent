export declare function StructureCard({ kicker }: {
    readonly kicker: string;
}): import('react').JSX.Element;
