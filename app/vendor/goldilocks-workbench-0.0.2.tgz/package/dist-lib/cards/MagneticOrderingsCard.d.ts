/** Auto-shown by `Workbench` only once a structure is classified
 * magnetic -- see `App.tsx`'s `showMagneticOrderings` -- rather than
 * always present like the other four columns, since exploring
 * alternative magnetic orderings is meaningless for a non-magnetic
 * structure. */
export declare function MagneticOrderingsCard({ kicker }: {
    readonly kicker: string;
}): import('react').JSX.Element;
