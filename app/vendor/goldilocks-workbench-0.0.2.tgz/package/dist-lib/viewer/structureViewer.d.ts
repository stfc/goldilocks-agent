export interface StructureViewer {
    show(canonicalCif: string): void;
    refreshTheme(): void;
    dispose(): void;
}
export type StructureViewerFactory = (element: HTMLElement, signal: AbortSignal) => StructureViewer | Promise<StructureViewer>;
export declare const attachStructureViewer: StructureViewerFactory;
