import { n as e } from "./rolldown-runtime-CYdcPHCu.js";
import * as t from "react";
import n, { Activity as r, Children as i, Fragment as a, cloneElement as o, createContext as s, createElement as c, forwardRef as l, use as u, useCallback as d, useContext as f, useEffect as p, useEffectEvent as m, useId as h, useLayoutEffect as g, useMemo as _, useRef as v, useState as y, useSyncExternalStore as b } from "react";
import x, { createPortal as S, flushSync as C } from "react-dom";
import { Fragment as w, jsx as T, jsxs as E } from "react/jsx-runtime";
// node_modules/@mantine/core/esm/core/utils/keys/keys.mjs
function D(e) {
	return Object.keys(e);
}
// node_modules/@mantine/core/esm/core/utils/deep-merge/deep-merge.mjs
function O(e) {
	return e && typeof e == "object" && !Array.isArray(e);
}
function k(e, t) {
	let n = { ...e }, r = t;
	return O(e) && O(t) && Object.keys(t).forEach((t) => {
		O(r[t]) && t in e ? n[t] = k(n[t], r[t]) : n[t] = r[t];
	}), n;
}
// node_modules/@mantine/core/esm/core/utils/camel-to-kebab-case/camel-to-kebab-case.mjs
function ee(e) {
	return e.replace(/[A-Z]/g, (e) => `-${e.toLowerCase()}`);
}
// node_modules/@mantine/core/esm/core/utils/units-converters/px.mjs
function A(e) {
	return typeof e != "string" || !e.includes("var(--mantine-scale)") ? e : e.match(/^calc\((.*?)\)$/)?.[1].split("*")[0].trim();
}
function j(e) {
	let t = A(e);
	return typeof t == "number" ? t : typeof t == "string" ? t.includes("calc") || t.includes("var") ? t : t.includes("px") ? Number(t.replace("px", "")) : t.includes("rem") ? Number(t.replace("rem", "")) * 16 : t.includes("em") ? Number(t.replace("em", "")) * 16 : Number(t) : NaN;
}
// node_modules/@mantine/core/esm/core/utils/units-converters/rem.mjs
function M(e) {
	return e === "0rem" ? "0rem" : `calc(${e} * var(--mantine-scale))`;
}
function N(e, { shouldScale: t = !1 } = {}) {
	function n(r) {
		if (r === 0 || r === "0") return `0${e}`;
		if (typeof r == "number") {
			let n = `${r / 16}${e}`;
			return t ? M(n) : n;
		}
		if (typeof r == "string") {
			if (r === "" || r.startsWith("calc(") || r.startsWith("clamp(") || r.includes("rgba(")) return r;
			if (r.includes(",")) return r.split(",").map((e) => n(e)).join(",");
			if (r.includes(" ")) return r.split(" ").map((e) => n(e)).join(" ");
			let i = r.replace("px", "");
			if (!Number.isNaN(Number(i))) {
				let n = `${Number(i) / 16}${e}`;
				return t ? M(n) : n;
			}
		}
		return r;
	}
	return n;
}
var P = N("rem", { shouldScale: !0 }), te = N("em");
// node_modules/@mantine/core/esm/core/utils/filter-props/filter-props.mjs
function ne(e) {
	return Object.keys(e).reduce((t, n) => (e[n] !== void 0 && (t[n] = e[n]), t), {});
}
// node_modules/@mantine/core/esm/core/utils/is-number-like/is-number-like.mjs
function F(e) {
	if (typeof e == "number") return !0;
	if (typeof e == "string") {
		if (e.startsWith("calc(") || e.startsWith("var(") || e.includes(" ") && e.trim() !== "") return !0;
		let t = /^[+-]?[0-9]+(\.[0-9]+)?(px|em|rem|ex|ch|lh|rlh|vw|vh|vmin|vmax|vb|vi|svw|svh|lvw|lvh|dvw|dvh|cm|mm|in|pt|pc|q|cqw|cqh|cqi|cqb|cqmin|cqmax|%)?$/;
		return e.trim().split(/\s+/).every((e) => t.test(e));
	}
	return !1;
}
// node_modules/@mantine/core/esm/core/utils/is-element/is-element.mjs
function I(e) {
	return Array.isArray(e) || e === null ? !1 : typeof e == "object" && e.type !== a;
}
// node_modules/@mantine/core/esm/core/utils/create-safe-context/create-safe-context.mjs
function re(e) {
	let t = s(null);
	return [t, () => {
		let n = u(t);
		if (n === null) throw Error(e);
		return n;
	}];
}
// node_modules/@mantine/core/esm/core/utils/get-safe-id/get-safe-id.mjs
function L(e, t) {
	return (n) => {
		if (typeof n != "string" || n.trim().length === 0) throw Error(t);
		return `${e}-${n}`;
	};
}
// node_modules/@mantine/core/esm/core/utils/find-element-ancestor/find-element-ancestor.mjs
function R(e, t) {
	let n = e;
	for (; (n = n.parentElement) && !n.matches(t););
	return n;
}
// node_modules/@mantine/core/esm/core/utils/create-scoped-keydown-handler/create-scoped-keydown-handler.mjs
function z(e, t, n) {
	for (let n = e - 1; n >= 0; --n) if (!t[n].disabled) return n;
	if (n) {
		for (let e = t.length - 1; e > -1; --e) if (!t[e].disabled) return e;
	}
	return e;
}
function ie(e, t, n) {
	for (let n = e + 1; n < t.length; n += 1) if (!t[n].disabled) return n;
	if (n) {
		for (let e = 0; e < t.length; e += 1) if (!t[e].disabled) return e;
	}
	return e;
}
function ae(e, t, n) {
	return R(e, n) === R(t, n);
}
function oe({ parentSelector: e, siblingSelector: t, onKeyDown: n, loop: r = !0, activateOnFocus: i = !1, dir: a = "rtl", orientation: o }) {
	return (s) => {
		n?.(s);
		let c = Array.from(R(s.currentTarget, e)?.querySelectorAll(t) || []).filter((t) => ae(s.currentTarget, t, e)), l = c.findIndex((e) => s.currentTarget === e), u = ie(l, c, r), d = z(l, c, r), f = a === "rtl" ? d : u, p = a === "rtl" ? u : d;
		switch (s.key) {
			case "ArrowRight":
				o === "horizontal" && (s.stopPropagation(), s.preventDefault(), c[f].focus(), i && c[f].click());
				break;
			case "ArrowLeft":
				o === "horizontal" && (s.stopPropagation(), s.preventDefault(), c[p].focus(), i && c[p].click());
				break;
			case "ArrowUp":
				o === "vertical" && (s.stopPropagation(), s.preventDefault(), c[d].focus(), i && c[d].click());
				break;
			case "ArrowDown":
				o === "vertical" && (s.stopPropagation(), s.preventDefault(), c[u].focus(), i && c[u].click());
				break;
			case "Home":
				s.stopPropagation(), s.preventDefault(), c[ie(-1, c, !1)]?.focus();
				break;
			case "End": s.stopPropagation(), s.preventDefault(), c[z(c.length, c, !1)]?.focus();
		}
	};
}
// node_modules/@mantine/core/esm/core/utils/get-default-z-index/get-default-z-index.mjs
var se = {
	app: 100,
	modal: 200,
	popover: 300,
	overlay: 400,
	max: 9999
};
function ce(e) {
	return se[e];
}
// node_modules/@mantine/core/esm/core/utils/noop/noop.mjs
var le = () => {};
// node_modules/@mantine/core/esm/core/utils/get-size/get-size.mjs
function B(e, t = "size", n = !0) {
	if (e !== void 0) return F(e) ? n ? P(e) : e : `var(--${t}-${e})`;
}
function V(e) {
	return B(e, "mantine-spacing");
}
function H(e) {
	return e === void 0 ? "var(--mantine-radius-default)" : B(e, "mantine-radius");
}
function U(e) {
	return B(e, "mantine-font-size");
}
function ue(e) {
	return B(e, "mantine-line-height", !1);
}
function W(e) {
	if (e) return B(e, "mantine-shadow", !1);
}
// node_modules/@mantine/core/esm/core/utils/get-breakpoint-value/get-breakpoint-value.mjs
function de(e, t) {
	return e in t ? j(t[e]) : j(e);
}
// node_modules/@mantine/core/esm/core/utils/get-sorted-breakpoints/get-sorted-breakpoints.mjs
function fe(e, t) {
	let n = e.map((e) => ({
		value: e,
		px: de(e, t)
	}));
	return n.sort((e, t) => e.px - t.px), n;
}
// node_modules/@mantine/core/esm/core/utils/get-base-value/get-base-value.mjs
function pe(e) {
	return typeof e == "object" && e ? "base" in e ? e.base : void 0 : e;
}
// node_modules/@mantine/hooks/esm/utils/clamp/clamp.mjs
function me(e, t, n) {
	return t === void 0 && n === void 0 ? e : t !== void 0 && n === void 0 ? Math.max(e, t) : Math.min(t === void 0 && n !== void 0 ? e : Math.max(e, t), n);
}
// node_modules/@mantine/hooks/esm/utils/random-id/random-id.mjs
function he(e = "mantine-") {
	return `${e}${Math.random().toString(36).slice(2, 11)}`;
}
// node_modules/@mantine/hooks/esm/utils/use-callback-ref/use-callback-ref.mjs
function ge(e) {
	let t = v(e);
	return p(() => {
		t.current = e;
	}), _(() => ((...e) => t.current?.(...e)), []);
}
// node_modules/@mantine/hooks/esm/use-debounced-callback/use-debounced-callback.mjs
function _e(e, t) {
	let { delay: n, flushOnUnmount: r, leading: i, maxWait: a } = typeof t == "number" ? {
		delay: t,
		flushOnUnmount: !1,
		leading: !1,
		maxWait: void 0
	} : t, o = ge(e), s = v(0), c = v(0), l = v(null), u = _(() => {
		let e = Object.assign((...t) => {
			window.clearTimeout(s.current), l.current = t;
			let r = e._isFirstCall;
			e._isFirstCall = !1;
			function u() {
				window.clearTimeout(s.current), window.clearTimeout(c.current), s.current = 0, c.current = 0, e._isFirstCall = !0, e._hasPendingCallback = !1;
			}
			function d() {
				a !== void 0 && c.current === 0 && (c.current = window.setTimeout(() => {
					if (c.current = 0, s.current !== 0 && e._hasPendingCallback) {
						let e = l.current;
						u(), o(...e);
					}
				}, a));
			}
			if (i && r) {
				o(...t), e.flush = () => {
					s.current !== 0 && u();
				}, e.cancel = () => {
					u();
				}, s.current = window.setTimeout(() => {
					u();
				}, n), d();
				return;
			}
			if (i && !r) {
				e._hasPendingCallback = !0, e.flush = () => {
					s.current !== 0 && (u(), o(...t));
				}, e.cancel = () => {
					u();
				}, s.current = window.setTimeout(() => {
					u();
				}, n), d();
				return;
			}
			e._hasPendingCallback = !0;
			let f = () => {
				s.current !== 0 && (u(), o(...t));
			};
			e.flush = f, e.cancel = () => {
				u();
			}, s.current = window.setTimeout(f, n), d();
		}, {
			flush: () => {},
			cancel: () => {},
			isPending: () => e._hasPendingCallback,
			_isFirstCall: !0,
			_hasPendingCallback: !1
		});
		return e;
	}, [
		o,
		n,
		i,
		a
	]);
	return p(() => () => {
		r ? u.flush() : u.cancel();
	}, [u, r]), u;
}
// node_modules/@mantine/hooks/esm/use-media-query/use-media-query.mjs
function ve(e, t) {
	if (typeof t == "boolean") return t;
	if (typeof window < "u" && "matchMedia" in window) try {
		return window.matchMedia(e).matches;
	} catch {
		return !1;
	}
	return !1;
}
function ye(e, t, { getInitialValueInEffect: n } = { getInitialValueInEffect: !0 }) {
	let [r, i] = y(n ? t : ve(e));
	return p(() => {
		try {
			if ("matchMedia" in window) {
				let t = window.matchMedia(e);
				i(t.matches);
				let n = (e) => i(e.matches);
				return t.addEventListener("change", n), () => {
					t.removeEventListener("change", n);
				};
			}
		} catch {
			return;
		}
	}, [e]), r || !1;
}
// node_modules/@mantine/hooks/esm/use-color-scheme/use-color-scheme.mjs
function be(e, t) {
	return ye("(prefers-color-scheme: dark)", e === "dark", t) ? "dark" : "light";
}
// node_modules/@mantine/hooks/esm/use-isomorphic-effect/use-isomorphic-effect.mjs
var xe = typeof document < "u" ? g : p;
// node_modules/@mantine/hooks/esm/use-did-update/use-did-update.mjs
function Se(e, t) {
	return e.length !== t.length || t.some((t, n) => !Object.is(t, e[n]));
}
function Ce(e, t) {
	let n = v(!1), r = v(null), i = v(void 0), a = {};
	p(() => {
		let o = r.current === a, s = i.current;
		if (r.current = a, i.current = t, !n.current) n.current = !0;
		else if (!o && !(t && s && !Se(s, t))) return e();
	}, t);
}
// node_modules/@mantine/hooks/esm/use-focus-return/use-focus-return.mjs
function we({ opened: e, shouldReturnFocus: t = !0 }) {
	let n = v(null), r = () => {
		n.current && "focus" in n.current && typeof n.current.focus == "function" && n.current?.focus({ preventScroll: !0 });
	};
	return Ce(() => {
		let i = -1, a = (e) => {
			e.key === "Tab" && window.clearTimeout(i);
		};
		if (document.addEventListener("keydown", a), e) n.current = document.activeElement;
		else if (t) {
			let e = document.activeElement;
			i = window.setTimeout(() => {
				let t = document.activeElement;
				(t === null || t === document.body || t === e) && r();
			}, 10);
		}
		return () => {
			window.clearTimeout(i), document.removeEventListener("keydown", a);
		};
	}, [e, t]), r;
}
// node_modules/@mantine/hooks/esm/use-focus-trap/tabbable.mjs
var Te = /input|select|textarea|button|object|summary|iframe/, Ee = "a, input, select, textarea, button, object, summary, iframe, audio[controls], video[controls], [contenteditable], [tabindex]";
function De(e) {
	let t = e.getAttribute("contenteditable");
	return t !== null && t !== "false";
}
function Oe(e) {
	let t = e.nodeName.toLowerCase();
	return (t === "audio" || t === "video") && e.hasAttribute("controls");
}
function ke(e) {
	return e.style.display === "none";
}
function Ae(e) {
	if (e.getAttribute("aria-hidden") || e.getAttribute("hidden") || e.getAttribute("type") === "hidden") return !1;
	let t = e;
	for (; t && t !== document.body && t.nodeType !== 11;) {
		if (ke(t)) return !1;
		t = t.parentNode;
	}
	return !0;
}
function je(e) {
	let t = e.getAttribute("tabindex");
	return t === null && (t = void 0), parseInt(t, 10);
}
function Me(e) {
	let t = e.nodeName.toLowerCase(), n = !Number.isNaN(je(e));
	return (Te.test(t) && !e.disabled || De(e) || Oe(e) || e instanceof HTMLAnchorElement && e.href || n) && Ae(e);
}
function Ne(e) {
	let t = je(e);
	return (Number.isNaN(t) || t >= 0) && Me(e);
}
function Pe(e) {
	let t = Array.from(e.querySelectorAll(Ee)).filter(Ne), n = t.filter((e) => je(e) > 0).sort((e, t) => je(e) - je(t)), r = t.filter((e) => !(je(e) > 0));
	return [...n, ...r];
}
// node_modules/@mantine/hooks/esm/use-focus-trap/scope-tab.mjs
var Fe = [
	"date",
	"time",
	"datetime-local",
	"month",
	"week"
], Ie = [
	"audio",
	"video",
	"iframe",
	"object",
	"embed"
];
function Le(e) {
	return !!e && e.tagName === "INPUT" && e.type === "radio";
}
function Re(e, t) {
	return e.name !== "" && e.name === t.name && e.form === t.form;
}
function ze(e) {
	let t = e.nodeName.toLowerCase();
	return t === "input" ? Fe.includes(e.type) : Ie.includes(t);
}
function Be(e, t) {
	let n = Pe(e);
	return n.filter((e) => e === t || !Le(e) ? !0 : Le(t) && Re(e, t) ? !1 : e.checked ? !0 : !n.some((t) => Le(t) && t.checked && Re(t, e)));
}
function Ve(e, t, n, r) {
	let i = e.indexOf(t);
	if (i !== -1) return i + 1;
	if (t === n) return 0;
	let a = r ? Node.DOCUMENT_POSITION_PRECEDING : Node.DOCUMENT_POSITION_FOLLOWING, o = e.findIndex((e) => (t.compareDocumentPosition(e) & a) !== 0);
	return o === -1 ? 0 : o;
}
function He(e, t, n) {
	let r = Be(e, t);
	n && r.reverse();
	let i = Ve(r, t, e, n);
	return [...r.slice(i), ...r.slice(0, i)].filter((e) => e !== t);
}
function Ue(e, t) {
	for (let n of e) if (n.focus(), t.activeElement === n) return;
}
function We(e, t) {
	let n = e.getRootNode(), r = n.activeElement;
	if (!r || r !== e && !e.contains(r)) return;
	let i = He(e, r, t.shiftKey);
	ze(r) ? setTimeout(() => {
		let t = n.activeElement;
		e.isConnected && t !== r && t !== i[0] && Ue([...i, r], n);
	}) : (t.preventDefault(), Ue(i, n));
}
// node_modules/@mantine/hooks/esm/use-focus-trap/use-focus-trap.mjs
var Ge = /* @__PURE__ */ new Set();
function Ke(e, t) {
	let n = t.getRootNode().activeElement;
	if (!n) return !1;
	for (let r of Ge) {
		let i = r.current;
		if (r !== e && i && i !== t && t.contains(i) && i.contains(n)) return !0;
	}
	return !1;
}
function qe(e = !0) {
	let t = v(null), n = (e) => {
		let t = e.querySelector("[data-autofocus]");
		if (!t) {
			let n = Array.from(e.querySelectorAll(Ee));
			t = n.find(Ne) || n.find(Me) || null, !t && Me(e) && (t = e);
		}
		t ? t.focus({ preventScroll: !0 }) : console.warn("[@mantine/hooks/use-focus-trap] Failed to find focusable element within provided node", e);
	}, r = d((r) => {
		e && (r === null ? t.current = null : t.current !== r && (setTimeout(() => {
			r.getRootNode() ? n(r) : console.warn("[@mantine/hooks/use-focus-trap] Ref node is not part of the dom", r);
		}), t.current = r));
	}, [e]);
	return p(() => {
		if (!e) return;
		t.current && setTimeout(() => {
			t.current && n(t.current);
		});
		let r = (e) => {
			e.key !== "Tab" || e.defaultPrevented || !t.current || Ke(t, t.current) || We(t.current, e);
		};
		return Ge.add(t), document.addEventListener("keydown", r), () => {
			Ge.delete(t), document.removeEventListener("keydown", r);
		};
	}, [e]), r;
}
// node_modules/@mantine/hooks/esm/use-id/use-id.mjs
function Je(e) {
	let t = h(), [n, r] = y(`mantine-${t.replace(/:/g, "")}`), i = v(!1);
	return xe(() => {
		i.current || (i.current = !0, r(he()));
	}, []), typeof e == "string" ? e : n;
}
// node_modules/@mantine/hooks/esm/use-window-event/use-window-event.mjs
function Ye(e, t, n) {
	let r = m(t);
	p(() => (window.addEventListener(e, r, n), () => window.removeEventListener(e, r, n)), [e]);
}
// node_modules/@mantine/hooks/esm/use-merged-ref/use-merged-ref.mjs
function Xe(e, t) {
	if (typeof e == "function") return e(t);
	typeof e == "object" && e && "current" in e && (e.current = t);
}
function Ze(...e) {
	let t = /* @__PURE__ */ new Map();
	return (n) => {
		if (e.forEach((e) => {
			let r = Xe(e, n);
			r && t.set(e, r);
		}), t.size > 0) return () => {
			e.forEach((e) => {
				let n = t.get(e);
				n && typeof n == "function" ? n() : Xe(e, null);
			}), t.clear();
		};
	};
}
function Qe(...e) {
	return d(Ze(...e), e);
}
// node_modules/@mantine/hooks/esm/use-uncontrolled/use-uncontrolled.mjs
function $e({ value: e, defaultValue: t, finalValue: n, onChange: r = () => {} }) {
	let [i, a] = y(t === void 0 ? n : t);
	return e === void 0 ? [
		i,
		(e, ...t) => {
			a(e), r?.(e, ...t);
		},
		!1
	] : [
		e,
		r,
		!0
	];
}
// node_modules/@mantine/hooks/esm/use-reduced-motion/use-reduced-motion.mjs
function et(e, t) {
	return ye("(prefers-reduced-motion: reduce)", e, t);
}
// node_modules/@mantine/hooks/esm/use-collapse/use-collapse.mjs
function tt(e) {
	if (!e || typeof e == "string") return 0;
	let t = e / 36;
	return Math.round((4 + 15 * t ** .25 + t / 5) * 10);
}
function nt(e) {
	return e.current ? e.current.scrollHeight : "auto";
}
function rt(e) {
	return typeof e == "number" && e > 0;
}
function it({ transitionDuration: e, transitionTimingFunction: t = "ease", onTransitionEnd: n, onTransitionStart: r, expanded: i, keepMounted: a }) {
	let o = {
		height: 0,
		overflow: "hidden",
		...a ? {} : { display: "none" }
	}, s = m(() => r?.()), c = m(() => n?.()), l = v(null), [u, d] = y(i ? {} : o), [f, p] = y(i ? "entered" : "exited"), h = (e) => {
		C(() => d(e));
	}, g = (e) => {
		h((t) => ({
			...t,
			...e
		}));
	}, _ = (n) => {
		let r = e ?? tt(n);
		return { transition: `height ${r}ms ${t}, opacity ${r}ms ${t}` };
	}, b = v(0);
	Ce(() => {
		b.current += 1;
		let t = b.current, n = () => b.current === t;
		e !== 0 && s(), i ? window.requestAnimationFrame(() => {
			n() && l.current && (C(() => p("entering")), g({
				willChange: "height",
				display: "block",
				overflow: "hidden"
			}), window.requestAnimationFrame(() => {
				if (!n() || !l.current) return;
				let e = nt(l);
				rt(e) ? g({
					..._(e),
					height: e
				}) : (h({}), p("entered"), c());
			}));
		}) : window.requestAnimationFrame(() => {
			if (!n() || !l.current) return;
			C(() => p("exiting"));
			let e = nt(l);
			rt(e) ? (g({
				..._(e),
				willChange: "height",
				height: e
			}), window.requestAnimationFrame(() => {
				n() && l.current && g({
					height: 0,
					overflow: "hidden"
				});
			})) : (h(o), p("exited"), c());
		});
	}, [i]);
	let x = (e) => {
		if (e.target === l.current && e.propertyName === "height") {
			if (i) {
				let e = nt(l);
				e === u.height ? h({}) : g({ height: e }), p("entered"), c();
			} else u.height === 0 && (h(o), p("exited"), c());
		}
	};
	return {
		state: f,
		getCollapseProps: (e) => ({
			"aria-hidden": !i,
			inert: !i,
			ref: Ze(l, e?.ref),
			onTransitionEnd: x,
			style: {
				boxSizing: "border-box",
				...e?.style,
				...u
			}
		})
	};
}
// node_modules/@mantine/hooks/esm/use-collapse/use-horizontal-collapse.mjs
function at(e) {
	if (!e || typeof e == "string") return 0;
	let t = e / 36;
	return Math.round((4 + 15 * t ** .25 + t / 5) * 10);
}
function ot(e) {
	return e.current ? e.current.scrollWidth : "auto";
}
function st({ transitionDuration: e, transitionTimingFunction: t = "ease", onTransitionEnd: n, onTransitionStart: r, expanded: i, keepMounted: a }) {
	let o = {
		width: 0,
		overflow: "hidden",
		...a ? {} : { display: "none" }
	}, s = m(() => r?.()), c = m(() => n?.()), l = v(null), [u, d] = y(i ? {} : o), [f, p] = y(i ? "entered" : "exited"), h = (e) => {
		C(() => d(e));
	}, g = (e) => {
		h((t) => ({
			...t,
			...e
		}));
	}, _ = (n) => {
		let r = e ?? at(n);
		return { transition: `width ${r}ms ${t}, opacity ${r}ms ${t}` };
	}, b = v(0);
	Ce(() => {
		b.current += 1;
		let t = b.current, n = () => b.current === t;
		e !== 0 && s(), i ? window.requestAnimationFrame(() => {
			n() && l.current && (C(() => p("entering")), g({
				willChange: "width",
				display: "block",
				overflow: "hidden"
			}), window.requestAnimationFrame(() => {
				if (!n() || !l.current) return;
				let e = ot(l);
				rt(e) ? g({
					..._(e),
					width: e
				}) : (h({}), p("entered"), c());
			}));
		}) : window.requestAnimationFrame(() => {
			if (!n() || !l.current) return;
			C(() => p("exiting"));
			let e = ot(l);
			rt(e) ? (g({
				..._(e),
				willChange: "width",
				width: e
			}), window.requestAnimationFrame(() => {
				n() && l.current && g({
					width: 0,
					overflow: "hidden"
				});
			})) : (h(o), p("exited"), c());
		});
	}, [i]);
	let x = (e) => {
		if (e.target === l.current && e.propertyName === "width") {
			if (i) {
				let e = ot(l);
				e === u.width ? h({}) : g({ width: e }), p("entered"), c();
			} else u.width === 0 && (h(o), p("exited"), c());
		}
	};
	return {
		state: f,
		getCollapseProps: (e) => ({
			"aria-hidden": !i,
			inert: !i,
			ref: Ze(l, e?.ref),
			onTransitionEnd: x,
			style: {
				boxSizing: "border-box",
				...e?.style,
				...u
			}
		})
	};
}
// node_modules/@mantine/core/esm/core/utils/get-env/get-env.mjs
function ct() {
	return typeof process < "u" && process.env, "development";
}
// node_modules/@mantine/core/esm/core/utils/get-single-element-child/get-single-element-child.mjs
function lt(e) {
	let t = i.toArray(e);
	return t.length !== 1 || !I(t[0]) ? null : t[0];
}
// node_modules/@mantine/core/esm/core/styles-api/create-vars-resolver/create-vars-resolver.mjs
function G(e) {
	return e;
}
// node_modules/clsx/dist/clsx.mjs
function ut(e) {
	var t, n, r = "";
	if (typeof e == "string" || typeof e == "number") r += e;
	else if (typeof e == "object") {
		if (Array.isArray(e)) {
			var i = e.length;
			for (t = 0; t < i; t++) e[t] && (n = ut(e[t])) && (r && (r += " "), r += n);
		} else for (n in e) e[n] && (r && (r += " "), r += n);
	}
	return r;
}
function dt() {
	for (var e, t, n = 0, r = "", i = arguments.length; n < i; n++) (e = arguments[n]) && (t = ut(e)) && (r && (r += " "), r += t);
	return r;
}
// node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/resolve-class-names/resolve-class-names.mjs
var ft = {};
function pt(e) {
	let t = {};
	return e.forEach((e) => {
		Object.entries(e).forEach(([e, n]) => {
			t[e] ? t[e] = dt(t[e], n) : t[e] = n;
		});
	}), t;
}
function mt({ theme: e, classNames: t, props: n, stylesCtx: r }) {
	return pt((Array.isArray(t) ? t : [t]).map((t) => typeof t == "function" ? t(e, n, r) : t || ft));
}
// node_modules/@mantine/core/esm/core/styles-api/use-styles/get-style/resolve-styles/resolve-styles.mjs
function ht({ theme: e, styles: t, props: n, stylesCtx: r }) {
	let i = Array.isArray(t) ? t : [t], a = {};
	for (let t of i) typeof t == "function" ? Object.assign(a, t(e, n, r)) : t && Object.assign(a, t);
	return a;
}
// node_modules/@mantine/core/esm/core/MantineProvider/color-scheme-managers/is-mantine-color-scheme.mjs
function gt(e) {
	return e === "auto" || e === "dark" || e === "light";
}
// node_modules/@mantine/core/esm/core/MantineProvider/color-scheme-managers/local-storage-manager.mjs
function _t({ key: e = "mantine-color-scheme-value" } = {}) {
	let t;
	return {
		get: (t) => {
			if (typeof window > "u") return t;
			try {
				let n = window.localStorage.getItem(e);
				return gt(n) ? n : t;
			} catch {
				return t;
			}
		},
		set: (t) => {
			try {
				window.localStorage.setItem(e, t);
			} catch (e) {
				console.warn("[@mantine/core] Local storage color scheme manager was unable to save color scheme.", e);
			}
		},
		subscribe: (n) => {
			t = (t) => {
				t.storageArea === window.localStorage && t.key === e && gt(t.newValue) && n(t.newValue);
			}, window.addEventListener("storage", t);
		},
		unsubscribe: () => {
			window.removeEventListener("storage", t);
		},
		clear: () => {
			window.localStorage.removeItem(e);
		}
	};
}
// node_modules/@mantine/core/esm/core/MantineProvider/color-functions/get-primary-shade/get-primary-shade.mjs
function vt(e, t) {
	return typeof e.primaryShade == "number" ? e.primaryShade : t === "dark" ? e.primaryShade.dark : e.primaryShade.light;
}
// node_modules/@mantine/core/esm/core/MantineProvider/color-functions/to-rgba/to-rgba.mjs
function yt(e) {
	return /^#?([0-9A-F]{3}){1,2}([0-9A-F]{2})?$/i.test(e);
}
function bt(e) {
	let t = e.replace("#", "");
	if (t.length === 3) {
		let e = t.split("");
		t = [
			e[0],
			e[0],
			e[1],
			e[1],
			e[2],
			e[2]
		].join("");
	}
	if (t.length === 8) {
		let e = parseInt(t.slice(6, 8), 16) / 255;
		return {
			r: parseInt(t.slice(0, 2), 16),
			g: parseInt(t.slice(2, 4), 16),
			b: parseInt(t.slice(4, 6), 16),
			a: e
		};
	}
	let n = parseInt(t, 16);
	return {
		r: n >> 16 & 255,
		g: n >> 8 & 255,
		b: n & 255,
		a: 1
	};
}
function xt(e) {
	let [t, n, r, i] = e.replace(/[^0-9,./]/g, "").split(/[/,]/).map(Number);
	return {
		r: t,
		g: n,
		b: r,
		a: i === void 0 ? 1 : i
	};
}
function St(e) {
	let t = e.match(/^hsla?\(\s*(\d+)\s*,\s*(\d+%)\s*,\s*(\d+%)\s*(,\s*(0?\.\d+|\d+(\.\d+)?))?\s*\)$/i);
	if (!t) return {
		r: 0,
		g: 0,
		b: 0,
		a: 1
	};
	let n = parseInt(t[1], 10), r = parseInt(t[2], 10) / 100, i = parseInt(t[3], 10) / 100, a = t[5] ? parseFloat(t[5]) : void 0, o = (1 - Math.abs(2 * i - 1)) * r, s = n / 60, c = o * (1 - Math.abs(s % 2 - 1)), l = i - o / 2, u, d, f;
	return s >= 0 && s < 1 ? (u = o, d = c, f = 0) : s >= 1 && s < 2 ? (u = c, d = o, f = 0) : s >= 2 && s < 3 ? (u = 0, d = o, f = c) : s >= 3 && s < 4 ? (u = 0, d = c, f = o) : s >= 4 && s < 5 ? (u = c, d = 0, f = o) : (u = o, d = 0, f = c), {
		r: Math.round((u + l) * 255),
		g: Math.round((d + l) * 255),
		b: Math.round((f + l) * 255),
		a: a === void 0 ? 1 : a
	};
}
function Ct(e) {
	return yt(e) ? bt(e) : e.startsWith("rgb") ? xt(e) : e.startsWith("hsl") ? St(e) : {
		r: 0,
		g: 0,
		b: 0,
		a: 1
	};
}
// node_modules/@mantine/core/esm/core/MantineProvider/color-functions/luminance/luminance.mjs
function wt(e) {
	return e <= .03928 ? e / 12.92 : ((e + .055) / 1.055) ** 2.4;
}
function Tt(e) {
	let t = e.match(/oklch\((.*?)%\s/);
	return t ? parseFloat(t[1]) : null;
}
function Et(e) {
	if (e.startsWith("oklch(")) return (Tt(e) || 0) / 100;
	let { r: t, g: n, b: r } = Ct(e), i = t / 255, a = n / 255, o = r / 255, s = wt(i), c = wt(a), l = wt(o);
	return .2126 * s + .7152 * c + .0722 * l;
}
function Dt(e, t = .179) {
	return !e.startsWith("var(") && Et(e) > t;
}
// node_modules/@mantine/core/esm/core/MantineProvider/color-functions/parse-theme-color/parse-theme-color.mjs
function Ot({ color: e, theme: t, colorScheme: n }) {
	if (typeof e != "string") throw Error(`[@mantine/core] Failed to parse color. Expected color to be a string, instead got ${typeof e}`);
	if (e === "bright") return {
		color: e,
		value: n === "dark" ? t.white : t.black,
		shade: void 0,
		isThemeColor: !1,
		isLight: Dt(n === "dark" ? t.white : t.black, t.luminanceThreshold),
		variable: "--mantine-color-bright"
	};
	if (e === "dimmed") return {
		color: e,
		value: n === "dark" ? t.colors.dark[2] : t.colors.gray[7],
		shade: void 0,
		isThemeColor: !1,
		isLight: Dt(n === "dark" ? t.colors.dark[2] : t.colors.gray[6], t.luminanceThreshold),
		variable: "--mantine-color-dimmed"
	};
	if (e === "white" || e === "black") return {
		color: e,
		value: e === "white" ? t.white : t.black,
		shade: void 0,
		isThemeColor: !1,
		isLight: Dt(e === "white" ? t.white : t.black, t.luminanceThreshold),
		variable: `--mantine-color-${e}`
	};
	let [r, i] = e.split("."), a = i ? Number(i) : void 0, o = r in t.colors;
	if (o) {
		let e = a === void 0 ? t.colors[r][vt(t, n || "light")] : t.colors[r][a];
		return {
			color: r,
			value: e,
			shade: a,
			isThemeColor: o,
			isLight: Dt(e, t.luminanceThreshold),
			variable: i ? `--mantine-color-${r}-${a}` : `--mantine-color-${r}-filled`
		};
	}
	return {
		color: e,
		value: e,
		isThemeColor: o,
		isLight: Dt(e, t.luminanceThreshold),
		shade: a,
		variable: void 0
	};
}
// node_modules/@mantine/core/esm/core/MantineProvider/color-functions/get-theme-color/get-theme-color.mjs
function kt(e, t) {
	let n = Ot({
		color: e || t.primaryColor,
		theme: t
	});
	return n.variable ? `var(${n.variable})` : e;
}
// node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/virtual-color/virtual-color.mjs
function At(e) {
	return !!e && typeof e == "object" && "mantine-virtual-color" in e;
}
// node_modules/@mantine/core/esm/core/MantineProvider/color-functions/darken/darken.mjs
function jt(e, t) {
	if (e.startsWith("var(")) return `color-mix(in srgb, ${e}, black ${t * 100}%)`;
	let { r: n, g: r, b: i, a } = Ct(e), o = 1 - t, s = (e) => Math.round(e * o);
	return `rgba(${s(n)}, ${s(r)}, ${s(i)}, ${a})`;
}
// node_modules/@mantine/core/esm/core/MantineProvider/color-functions/get-gradient/get-gradient.mjs
function Mt(e, t) {
	let n = {
		from: e?.from || t.defaultGradient.from,
		to: e?.to || t.defaultGradient.to,
		deg: e?.deg ?? t.defaultGradient.deg ?? 0
	}, r = kt(n.from, t), i = kt(n.to, t);
	return `linear-gradient(${n.deg}deg, ${r} 0%, ${i} 100%)`;
}
// node_modules/@mantine/core/esm/core/MantineProvider/color-functions/rgba/rgba.mjs
function Nt(e, t) {
	if (typeof e != "string" || t > 1 || t < 0) return "rgba(0, 0, 0, 1)";
	if (e.startsWith("var(")) return `color-mix(in srgb, ${e}, transparent ${(1 - t) * 100}%)`;
	if (e.startsWith("oklch")) return e.includes("/") ? e.replace(/\/\s*[\d.]+\s*\)/, `/ ${t})`) : e.replace(")", ` / ${t})`);
	let { r: n, g: r, b: i } = Ct(e);
	return `rgba(${n}, ${r}, ${i}, ${t})`;
}
var Pt = Nt, Ft = ({ color: e, theme: t, variant: n, gradient: r, autoContrast: i }) => {
	let a = Ot({
		color: e,
		theme: t
	}), o = typeof i == "boolean" ? i : t.autoContrast;
	if (n === "none") return {
		background: "transparent",
		hover: "transparent",
		color: "inherit",
		border: "none"
	};
	if (n === "filled") {
		let n = a.isThemeColor && a.shade === void 0 && At(t.colors[a.color]), r = o ? n ? `var(--mantine-color-${a.color}-contrast)` : a.isLight ? "var(--mantine-color-black)" : "var(--mantine-color-white)" : "var(--mantine-color-white)";
		return a.isThemeColor ? a.shade === void 0 ? {
			background: `var(--mantine-color-${e}-filled)`,
			hover: `var(--mantine-color-${e}-filled-hover)`,
			color: r,
			border: `${P(1)} solid transparent`
		} : {
			background: `var(--mantine-color-${a.color}-${a.shade})`,
			hover: `var(--mantine-color-${a.color}-${a.shade === 9 ? 8 : a.shade + 1})`,
			color: r,
			border: `${P(1)} solid transparent`
		} : {
			background: e,
			hover: jt(e, .1),
			color: r,
			border: `${P(1)} solid transparent`
		};
	}
	if (n === "light") {
		if (a.isThemeColor) {
			if (a.shade === void 0) return {
				background: `var(--mantine-color-${e}-light)`,
				hover: `var(--mantine-color-${e}-light-hover)`,
				color: `var(--mantine-color-${e}-light-color)`,
				border: `${P(1)} solid transparent`
			};
			let n = t.colors[a.color][a.shade];
			return {
				background: n,
				hover: jt(n, .1),
				color: `var(--mantine-color-${a.color}-light-color)`,
				border: `${P(1)} solid transparent`
			};
		}
		return {
			background: Nt(e, .1),
			hover: Nt(e, .12),
			color: e,
			border: `${P(1)} solid transparent`
		};
	}
	if (n === "outline") return a.isThemeColor ? a.shade === void 0 ? {
		background: "transparent",
		hover: `var(--mantine-color-${e}-outline-hover)`,
		color: `var(--mantine-color-${e}-outline)`,
		border: `${P(1)} solid var(--mantine-color-${e}-outline)`
	} : {
		background: "transparent",
		hover: Nt(t.colors[a.color][a.shade], .05),
		color: `var(--mantine-color-${a.color}-${a.shade})`,
		border: `${P(1)} solid var(--mantine-color-${a.color}-${a.shade})`
	} : {
		background: "transparent",
		hover: Nt(e, .05),
		color: e,
		border: `${P(1)} solid ${e}`
	};
	if (n === "subtle") {
		if (a.isThemeColor) {
			if (a.shade === void 0) return {
				background: "transparent",
				hover: `var(--mantine-color-${e}-light-hover)`,
				color: `var(--mantine-color-${e}-light-color)`,
				border: `${P(1)} solid transparent`
			};
			let n = t.colors[a.color][a.shade];
			return {
				background: "transparent",
				hover: Nt(n, .12),
				color: `var(--mantine-color-${a.color}-${Math.min(a.shade, 6)})`,
				border: `${P(1)} solid transparent`
			};
		}
		return {
			background: "transparent",
			hover: Nt(e, .12),
			color: e,
			border: `${P(1)} solid transparent`
		};
	}
	return n === "transparent" ? a.isThemeColor ? a.shade === void 0 ? {
		background: "transparent",
		hover: "transparent",
		color: `var(--mantine-color-${e}-light-color)`,
		border: `${P(1)} solid transparent`
	} : {
		background: "transparent",
		hover: "transparent",
		color: `var(--mantine-color-${a.color}-${Math.min(a.shade, 6)})`,
		border: `${P(1)} solid transparent`
	} : {
		background: "transparent",
		hover: "transparent",
		color: e,
		border: `${P(1)} solid transparent`
	} : n === "white" ? a.isThemeColor ? a.shade === void 0 ? {
		background: "var(--mantine-color-white)",
		hover: jt(t.white, .01),
		color: `var(--mantine-color-${e}-filled)`,
		border: `${P(1)} solid transparent`
	} : {
		background: "var(--mantine-color-white)",
		hover: jt(t.white, .01),
		color: `var(--mantine-color-${a.color}-${a.shade})`,
		border: `${P(1)} solid transparent`
	} : {
		background: "var(--mantine-color-white)",
		hover: jt(t.white, .01),
		color: e,
		border: `${P(1)} solid transparent`
	} : n === "gradient" ? {
		background: Mt(r, t),
		hover: Mt(r, t),
		color: "var(--mantine-color-white)",
		border: "none"
	} : n === "default" ? {
		background: "var(--mantine-color-default)",
		hover: "var(--mantine-color-default-hover)",
		color: "var(--mantine-color-default-color)",
		border: `${P(1)} solid var(--mantine-color-default-border)`
	} : {};
};
// node_modules/@mantine/core/esm/core/MantineProvider/color-functions/get-contrast-color/get-contrast-color.mjs
function It({ color: e, theme: t, autoContrast: n, colorScheme: r }) {
	return (typeof n == "boolean" ? n : t.autoContrast) && Ot({
		color: e || t.primaryColor,
		theme: t,
		colorScheme: r
	}).isLight ? "var(--mantine-color-black)" : "var(--mantine-color-white)";
}
function Lt(e, t, n) {
	return It({
		color: n === "dark" ? e.dark : e.light,
		theme: t,
		colorScheme: n,
		autoContrast: !0
	});
}
function Rt(e, t) {
	let n = e.colors[e.primaryColor];
	return At(n) ? e.autoContrast ? Lt(n, e, t) : "var(--mantine-color-white)" : It({
		color: n[vt(e, t)],
		theme: e,
		autoContrast: null
	});
}
// node_modules/@mantine/core/esm/core/MantineProvider/color-functions/get-auto-contrast-value/get-auto-contrast-value.mjs
function zt(e, t) {
	return typeof e == "boolean" ? e : t.autoContrast;
}
// node_modules/@mantine/core/esm/core/MantineProvider/Mantine.context.mjs
var Bt = s(null);
function Vt() {
	let e = u(Bt);
	if (!e) throw Error("[@mantine/core] MantineProvider was not found in tree");
	return e;
}
function Ht() {
	return Vt().cssVariablesResolver;
}
function Ut() {
	return Vt().classNamesPrefix;
}
function Wt() {
	return Vt().getStyleNonce;
}
function Gt() {
	return Vt().withStaticClasses;
}
function Kt() {
	return Vt().headless;
}
function qt() {
	return Vt().stylesTransform?.sx;
}
function Jt() {
	return Vt().stylesTransform?.styles;
}
function Yt() {
	return Vt().env || "default";
}
function Xt() {
	return Vt().deduplicateInlineStyles;
}
// node_modules/@mantine/core/esm/core/MantineProvider/use-mantine-color-scheme/use-mantine-color-scheme.mjs
function Zt(e) {
	let t = document.createElement("style");
	return t.setAttribute("data-mantine-styles", "inline"), t.innerHTML = "*, *::before, *::after {transition: none !important;}", t.setAttribute("data-mantine-disable-transition", "true"), e && t.setAttribute("nonce", e), document.head.appendChild(t), () => document.querySelectorAll("[data-mantine-disable-transition]").forEach((e) => e.remove());
}
function Qt({ keepTransitions: e } = {}) {
	let t = v(le), n = v(-1), r = u(Bt), i = Wt(), a = v(i?.());
	if (!r) throw Error("[@mantine/core] MantineProvider was not found in tree");
	let o = (i) => {
		r.setColorScheme(i), t.current = e ? () => {} : Zt(a.current), window.clearTimeout(n.current), n.current = window.setTimeout(() => {
			t.current?.();
		}, 10);
	}, s = () => {
		r.clearColorScheme(), t.current = e ? () => {} : Zt(a.current), window.clearTimeout(n.current), n.current = window.setTimeout(() => {
			t.current?.();
		}, 10);
	}, c = be("light", { getInitialValueInEffect: !1 }), l = r.colorScheme === "auto" ? c : r.colorScheme, f = d(() => o(l === "light" ? "dark" : "light"), [o, l]);
	return p(() => () => {
		t.current?.(), window.clearTimeout(n.current);
	}, []), {
		colorScheme: r.colorScheme,
		setColorScheme: o,
		clearColorScheme: s,
		toggleColorScheme: f
	};
}
// node_modules/@mantine/core/esm/core/MantineProvider/use-mantine-color-scheme/use-provider-color-scheme.mjs
function $t(e, t) {
	let n = typeof window < "u" && "matchMedia" in window && window.matchMedia("(prefers-color-scheme: dark)")?.matches, r = e === "auto" ? n ? "dark" : "light" : e;
	t()?.setAttribute("data-mantine-color-scheme", r);
}
function en({ manager: e, defaultColorScheme: t, getRootElement: n, forceColorScheme: r }) {
	let i = v(null), [a, o] = y(() => e.get(t)), s = r || a, c = d((t) => {
		r || ($t(t, n), o(t), e.set(t));
	}, [
		e.set,
		s,
		r
	]), l = d(() => {
		o(t), $t(t, n), e.clear();
	}, [e.clear, t]);
	return p(() => (e.subscribe(c), e.unsubscribe), [e.subscribe, e.unsubscribe]), xe(() => {
		$t(e.get(t), n);
	}, []), p(() => {
		if (r) return $t(r, n), () => {};
		r === void 0 && $t(a, n), typeof window < "u" && "matchMedia" in window && (i.current = window.matchMedia("(prefers-color-scheme: dark)"));
		let e = (e) => {
			a === "auto" && $t(e.matches ? "dark" : "light", n);
		};
		return i.current?.addEventListener("change", e), () => i.current?.removeEventListener("change", e);
	}, [a, r]), {
		colorScheme: s,
		setColorScheme: c,
		clearColorScheme: l
	};
}
// node_modules/@mantine/core/esm/core/MantineProvider/use-mantine-color-scheme/use-computed-color-scheme.mjs
function tn(e, t = { getInitialValueInEffect: !0 }) {
	let n = be(e, t), { colorScheme: r } = Qt();
	return r === "auto" ? n : r;
}
// node_modules/@mantine/core/esm/core/MantineProvider/default-colors.mjs
var nn = {
	dark: [
		"#C9C9C9",
		"#b8b8b8",
		"#828282",
		"#696969",
		"#424242",
		"#3b3b3b",
		"#2e2e2e",
		"#242424",
		"#1f1f1f",
		"#141414"
	],
	gray: [
		"#f8f9fa",
		"#f1f3f5",
		"#e9ecef",
		"#dee2e6",
		"#ced4da",
		"#adb5bd",
		"#868e96",
		"#495057",
		"#343a40",
		"#212529"
	],
	red: [
		"#fff5f5",
		"#ffe3e3",
		"#ffc9c9",
		"#ffa8a8",
		"#ff8787",
		"#ff6b6b",
		"#fa5252",
		"#f03e3e",
		"#e03131",
		"#c92a2a"
	],
	pink: [
		"#fff0f6",
		"#ffdeeb",
		"#fcc2d7",
		"#faa2c1",
		"#f783ac",
		"#f06595",
		"#e64980",
		"#d6336c",
		"#c2255c",
		"#a61e4d"
	],
	grape: [
		"#f8f0fc",
		"#f3d9fa",
		"#eebefa",
		"#e599f7",
		"#da77f2",
		"#cc5de8",
		"#be4bdb",
		"#ae3ec9",
		"#9c36b5",
		"#862e9c"
	],
	violet: [
		"#f3f0ff",
		"#e5dbff",
		"#d0bfff",
		"#b197fc",
		"#9775fa",
		"#845ef7",
		"#7950f2",
		"#7048e8",
		"#6741d9",
		"#5f3dc4"
	],
	indigo: [
		"#edf2ff",
		"#dbe4ff",
		"#bac8ff",
		"#91a7ff",
		"#748ffc",
		"#5c7cfa",
		"#4c6ef5",
		"#4263eb",
		"#3b5bdb",
		"#364fc7"
	],
	blue: [
		"#e7f5ff",
		"#d0ebff",
		"#a5d8ff",
		"#74c0fc",
		"#4dabf7",
		"#339af0",
		"#228be6",
		"#1c7ed6",
		"#1971c2",
		"#1864ab"
	],
	cyan: [
		"#e3fafc",
		"#c5f6fa",
		"#99e9f2",
		"#66d9e8",
		"#3bc9db",
		"#22b8cf",
		"#15aabf",
		"#1098ad",
		"#0c8599",
		"#0b7285"
	],
	teal: [
		"#e6fcf5",
		"#c3fae8",
		"#96f2d7",
		"#63e6be",
		"#38d9a9",
		"#20c997",
		"#12b886",
		"#0ca678",
		"#099268",
		"#087f5b"
	],
	green: [
		"#ebfbee",
		"#d3f9d8",
		"#b2f2bb",
		"#8ce99a",
		"#69db7c",
		"#51cf66",
		"#40c057",
		"#37b24d",
		"#2f9e44",
		"#2b8a3e"
	],
	lime: [
		"#f4fce3",
		"#e9fac8",
		"#d8f5a2",
		"#c0eb75",
		"#a9e34b",
		"#94d82d",
		"#82c91e",
		"#74b816",
		"#66a80f",
		"#5c940d"
	],
	yellow: [
		"#fff9db",
		"#fff3bf",
		"#ffec99",
		"#ffe066",
		"#ffd43b",
		"#fcc419",
		"#fab005",
		"#f59f00",
		"#f08c00",
		"#e67700"
	],
	orange: [
		"#fff4e6",
		"#ffe8cc",
		"#ffd8a8",
		"#ffc078",
		"#ffa94d",
		"#ff922b",
		"#fd7e14",
		"#f76707",
		"#e8590c",
		"#d9480f"
	]
}, rn = "-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Helvetica, Arial, sans-serif, Apple Color Emoji, Segoe UI Emoji", an = {
	scale: 1,
	fontSmoothing: !0,
	focusRing: "auto",
	white: "#fff",
	black: "#000",
	colors: nn,
	primaryShade: {
		light: 6,
		dark: 8
	},
	primaryColor: "blue",
	variantColorResolver: Ft,
	autoContrast: !1,
	luminanceThreshold: .3,
	fontFamily: rn,
	fontFamilyMonospace: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, Liberation Mono, Courier New, monospace",
	respectReducedMotion: !1,
	cursorType: "default",
	defaultGradient: {
		from: "blue",
		to: "cyan",
		deg: 45
	},
	defaultRadius: "md",
	activeClassName: "mantine-active",
	focusClassName: "",
	headings: {
		fontFamily: rn,
		fontWeight: "700",
		textWrap: "wrap",
		sizes: {
			h1: {
				fontSize: P(34),
				lineHeight: "1.3"
			},
			h2: {
				fontSize: P(26),
				lineHeight: "1.35"
			},
			h3: {
				fontSize: P(22),
				lineHeight: "1.4"
			},
			h4: {
				fontSize: P(18),
				lineHeight: "1.45"
			},
			h5: {
				fontSize: P(16),
				lineHeight: "1.5"
			},
			h6: {
				fontSize: P(14),
				lineHeight: "1.5"
			}
		}
	},
	fontSizes: {
		xs: P(12),
		sm: P(14),
		md: P(16),
		lg: P(18),
		xl: P(20)
	},
	lineHeights: {
		xs: "1.4",
		sm: "1.45",
		md: "1.55",
		lg: "1.6",
		xl: "1.65"
	},
	fontWeights: {
		regular: "400",
		medium: "600",
		bold: "700"
	},
	radius: {
		xs: P(2),
		sm: P(4),
		md: P(8),
		lg: P(16),
		xl: P(32)
	},
	spacing: {
		xs: P(10),
		sm: P(12),
		md: P(16),
		lg: P(20),
		xl: P(32)
	},
	breakpoints: {
		xs: "36em",
		sm: "48em",
		md: "62em",
		lg: "75em",
		xl: "88em"
	},
	shadows: {
		xs: `0 ${P(1)} ${P(3)} rgba(0, 0, 0, 0.05), 0 ${P(1)} ${P(2)} rgba(0, 0, 0, 0.1)`,
		sm: `0 ${P(1)} ${P(3)} rgba(0, 0, 0, 0.05), rgba(0, 0, 0, 0.05) 0 ${P(10)} ${P(15)} ${P(-5)}, rgba(0, 0, 0, 0.04) 0 ${P(7)} ${P(7)} ${P(-5)}`,
		md: `0 ${P(1)} ${P(3)} rgba(0, 0, 0, 0.05), rgba(0, 0, 0, 0.05) 0 ${P(20)} ${P(25)} ${P(-5)}, rgba(0, 0, 0, 0.04) 0 ${P(10)} ${P(10)} ${P(-5)}`,
		lg: `0 ${P(1)} ${P(3)} rgba(0, 0, 0, 0.05), rgba(0, 0, 0, 0.05) 0 ${P(28)} ${P(23)} ${P(-7)}, rgba(0, 0, 0, 0.04) 0 ${P(12)} ${P(12)} ${P(-7)}`,
		xl: `0 ${P(1)} ${P(3)} rgba(0, 0, 0, 0.05), rgba(0, 0, 0, 0.05) 0 ${P(36)} ${P(28)} ${P(-7)}, rgba(0, 0, 0, 0.04) 0 ${P(17)} ${P(17)} ${P(-7)}`
	},
	other: {},
	components: {}
}, on = "[@mantine/core] MantineProvider: Invalid theme.primaryColor, it accepts only key of theme.colors, learn more – https://mantine.dev/theming/colors/#primary-color", sn = "[@mantine/core] MantineProvider: Invalid theme.primaryShade, it accepts only 0-9 integers or an object { light: 0-9, dark: 0-9 }";
function cn(e) {
	return e < 0 || e > 9 ? !1 : parseInt(e.toString(), 10) === e;
}
function ln(e) {
	if (!(e.primaryColor in e.colors)) throw Error(on);
	if (typeof e.primaryShade == "object" && (!cn(e.primaryShade.dark) || !cn(e.primaryShade.light)) || typeof e.primaryShade == "number" && !cn(e.primaryShade)) throw Error(sn);
}
function un(e, t) {
	if (!t) return ln(e), e;
	let n = k(e, t);
	return t.fontFamily && !t.headings?.fontFamily && (n.headings = {
		...n.headings,
		fontFamily: t.fontFamily
	}), ln(n), n;
}
// node_modules/@mantine/core/esm/core/MantineProvider/MantineThemeProvider/MantineThemeProvider.mjs
var dn = s(null), fn = () => u(dn) || an;
function pn() {
	let e = u(dn);
	if (!e) throw Error("@mantine/core: MantineProvider was not found in component tree, make sure you have it in your app");
	return e;
}
function mn({ theme: e, children: t, inherit: n = !0 }) {
	let r = fn(), i = _(() => un(n ? r : an, e), [
		e,
		r,
		n
	]);
	return /* @__PURE__ */ T(dn, {
		value: i,
		children: t
	});
}
mn.displayName = "@mantine/core/MantineThemeProvider";
// node_modules/@mantine/core/esm/core/MantineProvider/convert-css-variables/css-variables-object-to-string.mjs
function hn(e) {
	return Object.entries(e).map(([e, t]) => `${e}: ${t};`).join("");
}
// node_modules/@mantine/core/esm/core/MantineProvider/convert-css-variables/convert-css-variables.mjs
function gn(e, t) {
	let n = t ? [t] : [":root", ":host"], r = hn(e.variables), i = r ? `${n.join(", ")}{${r}}` : "", a = hn(e.dark), o = hn(e.light), s = (e) => n.map((t) => t === ":host" ? `${t}([data-mantine-color-scheme="${e}"])` : `${t}[data-mantine-color-scheme="${e}"]`).join(", ");
	return `${i}\n\n${a ? `${s("dark")}{${a}}` : ""}\n\n${o ? `${s("light")}{${o}}` : ""}`;
}
// node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/get-css-color-variables.mjs
function _n({ theme: e, color: t, colorScheme: n, name: r = t, withColorValues: i = !0 }) {
	if (!e.colors[t]) return {};
	if (n === "light") {
		let n = vt(e, "light"), a = {
			[`--mantine-color-${r}-text`]: `var(--mantine-color-${r}-filled)`,
			[`--mantine-color-${r}-filled`]: `var(--mantine-color-${r}-${n})`,
			[`--mantine-color-${r}-filled-hover`]: `var(--mantine-color-${r}-${n === 9 ? 8 : n + 1})`,
			[`--mantine-color-${r}-light`]: `var(--mantine-color-${r}-1)`,
			[`--mantine-color-${r}-light-hover`]: `var(--mantine-color-${r}-2)`,
			[`--mantine-color-${r}-light-color`]: `var(--mantine-color-${r}-9)`,
			[`--mantine-color-${r}-outline`]: `var(--mantine-color-${r}-${n})`,
			[`--mantine-color-${r}-outline-hover`]: Pt(e.colors[t][n], .05)
		};
		return i ? {
			[`--mantine-color-${r}-0`]: e.colors[t][0],
			[`--mantine-color-${r}-1`]: e.colors[t][1],
			[`--mantine-color-${r}-2`]: e.colors[t][2],
			[`--mantine-color-${r}-3`]: e.colors[t][3],
			[`--mantine-color-${r}-4`]: e.colors[t][4],
			[`--mantine-color-${r}-5`]: e.colors[t][5],
			[`--mantine-color-${r}-6`]: e.colors[t][6],
			[`--mantine-color-${r}-7`]: e.colors[t][7],
			[`--mantine-color-${r}-8`]: e.colors[t][8],
			[`--mantine-color-${r}-9`]: e.colors[t][9],
			...a
		} : a;
	}
	let a = vt(e, "dark"), o = {
		[`--mantine-color-${r}-text`]: `var(--mantine-color-${r}-4)`,
		[`--mantine-color-${r}-filled`]: `var(--mantine-color-${r}-${a})`,
		[`--mantine-color-${r}-filled-hover`]: `var(--mantine-color-${r}-${a === 9 ? 8 : a + 1})`,
		[`--mantine-color-${r}-light`]: jt(e.colors[t][9], .5),
		[`--mantine-color-${r}-light-hover`]: jt(e.colors[t][9], .3),
		[`--mantine-color-${r}-light-color`]: `var(--mantine-color-${r}-0)`,
		[`--mantine-color-${r}-outline`]: `var(--mantine-color-${r}-${Math.max(a - 4, 0)})`,
		[`--mantine-color-${r}-outline-hover`]: Pt(e.colors[t][Math.max(a - 4, 0)], .05)
	};
	return i ? {
		[`--mantine-color-${r}-0`]: e.colors[t][0],
		[`--mantine-color-${r}-1`]: e.colors[t][1],
		[`--mantine-color-${r}-2`]: e.colors[t][2],
		[`--mantine-color-${r}-3`]: e.colors[t][3],
		[`--mantine-color-${r}-4`]: e.colors[t][4],
		[`--mantine-color-${r}-5`]: e.colors[t][5],
		[`--mantine-color-${r}-6`]: e.colors[t][6],
		[`--mantine-color-${r}-7`]: e.colors[t][7],
		[`--mantine-color-${r}-8`]: e.colors[t][8],
		[`--mantine-color-${r}-9`]: e.colors[t][9],
		...o
	} : o;
}
// node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/default-css-variables-resolver.mjs
function vn(e, t, n) {
	D(t).forEach((r) => Object.assign(e, { [`--mantine-${n}-${r}`]: t[r] }));
}
var yn = (e) => {
	let t = vt(e, "light"), n = e.defaultRadius in e.radius ? e.radius[e.defaultRadius] : P(e.defaultRadius), r = {
		variables: {
			"--mantine-z-index-app": "100",
			"--mantine-z-index-modal": "200",
			"--mantine-z-index-popover": "300",
			"--mantine-z-index-overlay": "400",
			"--mantine-z-index-max": "9999",
			"--mantine-scale": e.scale.toString(),
			"--mantine-cursor-type": e.cursorType,
			"--mantine-webkit-font-smoothing": e.fontSmoothing ? "antialiased" : "unset",
			"--mantine-moz-font-smoothing": e.fontSmoothing ? "grayscale" : "unset",
			"--mantine-color-white": e.white,
			"--mantine-color-black": e.black,
			"--mantine-line-height": e.lineHeights.md,
			"--mantine-font-family": e.fontFamily,
			"--mantine-font-family-monospace": e.fontFamilyMonospace,
			"--mantine-font-family-headings": e.headings.fontFamily,
			"--mantine-heading-font-weight": e.headings.fontWeight,
			"--mantine-heading-text-wrap": e.headings.textWrap,
			"--mantine-radius-default": n,
			"--mantine-primary-color-filled": `var(--mantine-color-${e.primaryColor}-filled)`,
			"--mantine-primary-color-filled-hover": `var(--mantine-color-${e.primaryColor}-filled-hover)`,
			"--mantine-primary-color-light": `var(--mantine-color-${e.primaryColor}-light)`,
			"--mantine-primary-color-light-hover": `var(--mantine-color-${e.primaryColor}-light-hover)`,
			"--mantine-primary-color-light-color": `var(--mantine-color-${e.primaryColor}-light-color)`
		},
		light: {
			"--mantine-color-scheme": "light",
			"--mantine-primary-color-contrast": Rt(e, "light"),
			"--mantine-color-bright": "var(--mantine-color-black)",
			"--mantine-color-text": e.black,
			"--mantine-color-body": e.white,
			"--mantine-color-error": "var(--mantine-color-red-6)",
			"--mantine-color-success": "var(--mantine-color-teal-8)",
			"--mantine-color-placeholder": "var(--mantine-color-gray-5)",
			"--mantine-color-anchor": `var(--mantine-color-${e.primaryColor}-${t})`,
			"--mantine-color-default": "var(--mantine-color-white)",
			"--mantine-color-default-hover": "var(--mantine-color-gray-0)",
			"--mantine-color-default-color": "var(--mantine-color-black)",
			"--mantine-color-default-border": "var(--mantine-color-gray-4)",
			"--mantine-color-dimmed": "var(--mantine-color-gray-6)",
			"--mantine-color-disabled": "var(--mantine-color-gray-2)",
			"--mantine-color-disabled-color": "var(--mantine-color-gray-5)",
			"--mantine-color-disabled-border": "var(--mantine-color-gray-3)"
		},
		dark: {
			"--mantine-color-scheme": "dark",
			"--mantine-primary-color-contrast": Rt(e, "dark"),
			"--mantine-color-bright": "var(--mantine-color-white)",
			"--mantine-color-text": "var(--mantine-color-dark-0)",
			"--mantine-color-body": "var(--mantine-color-dark-7)",
			"--mantine-color-error": "var(--mantine-color-red-8)",
			"--mantine-color-success": "var(--mantine-color-teal-8)",
			"--mantine-color-placeholder": "var(--mantine-color-dark-3)",
			"--mantine-color-anchor": `var(--mantine-color-${e.primaryColor}-4)`,
			"--mantine-color-default": "var(--mantine-color-dark-6)",
			"--mantine-color-default-hover": "var(--mantine-color-dark-5)",
			"--mantine-color-default-color": "var(--mantine-color-white)",
			"--mantine-color-default-border": "var(--mantine-color-dark-4)",
			"--mantine-color-dimmed": "var(--mantine-color-dark-2)",
			"--mantine-color-disabled": "var(--mantine-color-dark-6)",
			"--mantine-color-disabled-color": "var(--mantine-color-dark-3)",
			"--mantine-color-disabled-border": "var(--mantine-color-dark-4)"
		}
	};
	vn(r.variables, e.breakpoints, "breakpoint"), vn(r.variables, e.spacing, "spacing"), vn(r.variables, e.fontSizes, "font-size"), vn(r.variables, e.lineHeights, "line-height"), vn(r.variables, e.shadows, "shadow"), vn(r.variables, e.radius, "radius"), vn(r.variables, e.fontWeights, "font-weight"), e.colors[e.primaryColor].forEach((t, n) => {
		r.variables[`--mantine-primary-color-${n}`] = `var(--mantine-color-${e.primaryColor}-${n})`;
	}), D(e.colors).forEach((t) => {
		let n = e.colors[t];
		At(n) ? (Object.assign(r.light, _n({
			theme: e,
			name: n.name,
			color: n.light,
			colorScheme: "light",
			withColorValues: !0
		})), Object.assign(r.dark, _n({
			theme: e,
			name: n.name,
			color: n.dark,
			colorScheme: "dark",
			withColorValues: !0
		})), r.light[`--mantine-color-${n.name}-contrast`] = Lt(n, e, "light"), r.dark[`--mantine-color-${n.name}-contrast`] = Lt(n, e, "dark")) : (n.forEach((e, n) => {
			r.variables[`--mantine-color-${t}-${n}`] = e;
		}), Object.assign(r.light, _n({
			theme: e,
			color: t,
			colorScheme: "light",
			withColorValues: !1
		})), Object.assign(r.dark, _n({
			theme: e,
			color: t,
			colorScheme: "dark",
			withColorValues: !1
		})));
	});
	let i = e.headings.sizes;
	return D(i).forEach((t) => {
		r.variables[`--mantine-${t}-font-size`] = i[t].fontSize, r.variables[`--mantine-${t}-line-height`] = i[t].lineHeight, r.variables[`--mantine-${t}-font-weight`] = i[t].fontWeight || e.headings.fontWeight;
	}), r;
};
// node_modules/@mantine/core/esm/core/MantineProvider/MantineClasses/MantineClasses.mjs
function bn() {
	let e = pn(), t = Wt(), n = D(e.breakpoints).reduce((t, n) => {
		let r = e.breakpoints[n].includes("px"), i = j(e.breakpoints[n]);
		return `${t}@media (max-width: ${r ? `${i - .1}px` : te(i - .1)}) {.mantine-visible-from-${n} {display: none !important;}}@media (min-width: ${r ? `${i}px` : te(i)}) {.mantine-hidden-from-${n} {display: none !important;}}`;
	}, "");
	return /* @__PURE__ */ T("style", {
		"data-mantine-styles": "classes",
		nonce: t?.(),
		dangerouslySetInnerHTML: { __html: n }
	});
}
// node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/get-merged-variables.mjs
function xn({ theme: e, generator: t }) {
	let n = yn(e), r = t?.(e);
	return r ? k(n, r) : n;
}
// node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/remove-default-variables.mjs
var Sn = yn(an);
function Cn(e) {
	let t = {
		variables: {},
		light: {},
		dark: {}
	};
	return D(e.variables).forEach((n) => {
		Sn.variables[n] !== e.variables[n] && (t.variables[n] = e.variables[n]);
	}), D(e.light).forEach((n) => {
		Sn.light[n] !== e.light[n] && (t.light[n] = e.light[n]);
	}), D(e.dark).forEach((n) => {
		Sn.dark[n] !== e.dark[n] && (t.dark[n] = e.dark[n]);
	}), t;
}
// node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/MantineCssVariables.mjs
function wn(e) {
	return gn({
		variables: {},
		dark: { "--mantine-color-scheme": "dark" },
		light: { "--mantine-color-scheme": "light" }
	}, e);
}
function Tn({ cssVariablesSelector: e, deduplicateCssVariables: t }) {
	let n = pn(), r = Wt(), i = xn({
		theme: n,
		generator: Ht()
	}), a = (e === void 0 || e === ":root" || e === ":host") && t, o = gn(a ? Cn(i) : i, e);
	return o ? /* @__PURE__ */ T("style", {
		"data-mantine-styles": !0,
		nonce: r?.(),
		dangerouslySetInnerHTML: { __html: `${o}${a ? "" : wn(e)}` }
	}) : null;
}
Tn.displayName = "@mantine/CssVariables";
// node_modules/@mantine/core/esm/core/MantineProvider/use-respect-reduce-motion/use-respect-reduce-motion.mjs
function En({ respectReducedMotion: e, getRootElement: t }) {
	xe(() => {
		e && t()?.setAttribute("data-respect-reduced-motion", "true");
	}, [e]);
}
// node_modules/@mantine/core/esm/core/MantineProvider/MantineProvider.mjs
function Dn({ theme: e, children: t, getStyleNonce: n, withStaticClasses: r = !0, withGlobalClasses: i = !0, deduplicateCssVariables: a = !0, withCssVariables: o = !0, cssVariablesSelector: s, classNamesPrefix: c = "mantine", colorSchemeManager: l = _t(), defaultColorScheme: u = "light", getRootElement: d = () => document.documentElement, cssVariablesResolver: f, forceColorScheme: p, stylesTransform: m, env: h, deduplicateInlineStyles: g = !1 }) {
	let { colorScheme: _, setColorScheme: v, clearColorScheme: y } = en({
		defaultColorScheme: u,
		forceColorScheme: p,
		manager: l,
		getRootElement: d
	});
	return En({
		respectReducedMotion: e?.respectReducedMotion || !1,
		getRootElement: d
	}), /* @__PURE__ */ T(Bt, {
		value: {
			colorScheme: _,
			setColorScheme: v,
			clearColorScheme: y,
			getRootElement: d,
			classNamesPrefix: c,
			getStyleNonce: n,
			cssVariablesResolver: f,
			cssVariablesSelector: s ?? ":root",
			withStaticClasses: r,
			stylesTransform: m,
			env: h,
			deduplicateInlineStyles: g
		},
		children: /* @__PURE__ */ E(mn, {
			theme: e,
			children: [
				o && /* @__PURE__ */ T(Tn, {
					cssVariablesSelector: s,
					deduplicateCssVariables: a
				}),
				i && /* @__PURE__ */ T(bn, {}),
				t
			]
		})
	});
}
Dn.displayName = "@mantine/core/MantineProvider";
// node_modules/@mantine/core/esm/core/MantineProvider/use-props/use-props.mjs
function K(e, t, n) {
	let r = pn(), i = (Array.isArray(e) ? e : [e]).filter(Boolean), a = {};
	for (let e of i) {
		let t = r.components[e]?.defaultProps, n = typeof t == "function" ? t(r) : t;
		n && (a = {
			...a,
			...n
		});
	}
	return {
		...t,
		...a,
		...ne(n)
	};
}
// node_modules/@mantine/core/esm/core/MantineProvider/create-theme/create-theme.mjs
function On(e) {
	return e;
}
// node_modules/@mantine/core/esm/core/styles-api/use-resolved-styles-api/use-resolved-styles-api.mjs
function kn({ classNames: e, styles: t, props: n, stylesCtx: r }) {
	let i = pn();
	return {
		resolvedClassNames: e === void 0 ? void 0 : mt({
			theme: i,
			classNames: e,
			props: n,
			stylesCtx: r || void 0
		}),
		resolvedStyles: t === void 0 ? void 0 : ht({
			theme: i,
			styles: t,
			props: n,
			stylesCtx: r || void 0
		})
	};
}
// node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-global-class-names/get-global-class-names.mjs
var An = {
	always: "mantine-focus-always",
	auto: "mantine-focus-auto",
	never: "mantine-focus-never"
};
function jn({ theme: e, options: t, unstyled: n }) {
	return dt(t?.focusable && !n && (e.focusClassName || An[e.focusRing]), t?.active && !n && e.activeClassName);
}
// node_modules/@mantine/core/esm/core/utils/shallow-equal/shallow-equal.mjs
function Mn(e, t, n = 1) {
	if (Object.is(e, t)) return !0;
	if (n === 0 || typeof e != "object" || typeof t != "object" || e === null || t === null) return !1;
	if (Array.isArray(e) || Array.isArray(t)) {
		if (!Array.isArray(e) || !Array.isArray(t) || e.length !== t.length) return !1;
		for (let r = 0; r < e.length; r += 1) if (!Mn(e[r], t[r], n - 1)) return !1;
		return !0;
	}
	let r = Object.keys(e);
	if (r.length !== Object.keys(t).length) return !1;
	for (let i of r) if (!Object.hasOwn(t, i) || !Mn(e[i], t[i], n - 1)) return !1;
	return !0;
}
// node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-options-class-names/get-options-class-names.mjs
function Nn({ selector: e, stylesCtx: t, options: n, props: r, theme: i }) {
	return mt({
		theme: i,
		classNames: n?.classNames,
		props: n?.props || r,
		stylesCtx: t
	})[e];
}
// node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-resolved-class-names/get-resolved-class-names.mjs
function Pn({ selector: e, stylesCtx: t, theme: n, classNames: r, props: i }) {
	return mt({
		theme: n,
		classNames: r,
		props: i,
		stylesCtx: t
	})[e];
}
// node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-root-class-name/get-root-class-name.mjs
function Fn({ rootSelector: e, selector: t, className: n }) {
	return e === t ? n : void 0;
}
// node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-selector-class-name/get-selector-class-name.mjs
function In({ selector: e, classes: t, unstyled: n }) {
	return n ? void 0 : t[e];
}
// node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-static-class-names/get-static-class-names.mjs
function Ln({ themeName: e, classNamesPrefix: t, selector: n, withStaticClass: r }) {
	return r === !1 ? [] : e.map((e) => `${t}-${e}-${n}`);
}
// node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-variant-class-name/get-variant-class-name.mjs
function Rn({ options: e, classes: t, selector: n, unstyled: r }) {
	return e?.variant && !r ? t[`${n}--${e.variant}`] : void 0;
}
// node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-class-name.mjs
function zn({ theme: e, options: t, themeName: n, selector: r, classNamesPrefix: i, resolvedClassNames: a, resolvedThemeClassNames: o, classes: s, unstyled: c, className: l, rootSelector: u, props: d, stylesCtx: f, withStaticClasses: p, headless: m, transformedStyles: h }) {
	return dt(jn({
		theme: e,
		options: t,
		unstyled: c || m
	}), o.map((e) => e[r]), Rn({
		options: t,
		classes: s,
		selector: r,
		unstyled: c || m
	}), a[r], Pn({
		selector: r,
		stylesCtx: f,
		theme: e,
		classNames: h,
		props: d
	}), Nn({
		selector: r,
		stylesCtx: f,
		options: t,
		props: d,
		theme: e
	}), Fn({
		rootSelector: u,
		selector: r,
		className: l
	}), In({
		selector: r,
		classes: s,
		unstyled: c || m
	}), p && !m && Ln({
		themeName: n,
		classNamesPrefix: i,
		selector: r,
		withStaticClass: t?.withStaticClass
	}), t?.className);
}
// node_modules/@mantine/core/esm/core/styles-api/use-styles/get-style/resolve-style/resolve-style.mjs
function Bn({ style: e, theme: t }) {
	return Array.isArray(e) ? e.reduce((e, n) => ({
		...e,
		...Bn({
			style: n,
			theme: t
		})
	}), {}) : typeof e == "function" ? e(t) : e ?? {};
}
// node_modules/@mantine/core/esm/core/styles-api/use-styles/get-style/get-style.mjs
function Vn({ theme: e, selector: t, options: n, props: r, stylesCtx: i, rootSelector: a, withStylesTransform: o, resolvedStyles: s, resolvedThemeStyles: c, resolvedVars: l, resolvedRootStyle: u }) {
	return {
		...c[t],
		...s[t],
		...!o && ht({
			theme: e,
			styles: n?.styles,
			props: n?.props || r,
			stylesCtx: i
		})[t],
		...l[t],
		...a === t ? u : null,
		...Bn({
			style: n?.style,
			theme: e
		})
	};
}
// node_modules/@mantine/core/esm/core/styles-api/use-styles/get-style/resolve-vars/merge-vars.mjs
function Hn(e) {
	return e.reduce((e, t) => (t && Object.keys(t).forEach((n) => {
		e[n] = {
			...e[n],
			...ne(t[n])
		};
	}), e), {});
}
// node_modules/@mantine/core/esm/core/styles-api/use-styles/use-transformed-styles.mjs
function Un({ props: e, stylesCtx: t, themeName: n, theme: r }) {
	let i = Jt()?.();
	return {
		getTransformedStyles: (a) => i ? [...a.map((n) => i(n, {
			props: e,
			theme: r,
			ctx: t
		})), ...n.map((n) => i(r.components[n]?.styles, {
			props: e,
			theme: r,
			ctx: t
		}))].filter(Boolean) : [],
		withStylesTransform: !!i
	};
}
// node_modules/@mantine/core/esm/core/styles-api/use-styles/use-styles.mjs
function q({ name: e, classes: t, props: n, stylesCtx: r, className: i, style: a, rootSelector: o = "root", unstyled: s, classNames: c, styles: l, vars: u, varsResolver: d, attributes: f, stable: p }) {
	let m = pn(), h = Ut(), g = Gt(), _ = Kt(), v = (Array.isArray(e) ? e : [e]).filter((e) => e), { withStylesTransform: y, getTransformedStyles: b } = Un({
		props: n,
		stylesCtx: r,
		themeName: v,
		theme: m
	}), x = mt({
		theme: m,
		classNames: c,
		props: n,
		stylesCtx: r
	}), S = v.map((e) => mt({
		theme: m,
		classNames: m.components[e]?.classNames,
		props: n,
		stylesCtx: r
	})), C = y ? {} : ht({
		theme: m,
		styles: l,
		props: n,
		stylesCtx: r
	}), w = {};
	if (!y) for (let e of v) {
		let t = ht({
			theme: m,
			styles: m.components[e]?.styles,
			props: n,
			stylesCtx: r
		});
		for (let e of Object.keys(t)) w[e] = {
			...w[e],
			...t[e]
		};
	}
	let T = Hn([
		_ ? {} : d?.(m, n, r),
		...v.map((e) => m.components?.[e]?.vars?.(m, n, r)),
		u?.(m, n, r)
	]), E = Bn({
		style: a,
		theme: m
	});
	return Wn((e, a) => ({
		...f?.[e],
		className: zn({
			theme: m,
			options: a,
			themeName: v,
			selector: e,
			classNamesPrefix: h,
			resolvedClassNames: x,
			resolvedThemeClassNames: S,
			classes: t,
			unstyled: s,
			className: i,
			rootSelector: o,
			props: n,
			stylesCtx: r,
			withStaticClasses: g,
			headless: _,
			transformedStyles: b([a?.styles, l])
		}),
		style: Vn({
			theme: m,
			selector: e,
			options: a,
			props: n,
			stylesCtx: r,
			rootSelector: o,
			withStylesTransform: y,
			resolvedStyles: C,
			resolvedThemeStyles: w,
			resolvedVars: T,
			resolvedRootStyle: E
		})
	}), !!p, [
		m,
		h,
		g,
		_,
		y ? n : null,
		t,
		s,
		i,
		o,
		f,
		r,
		x,
		S,
		C,
		w,
		T,
		E
	]);
}
function Wn(e, t, n) {
	let r = v(null);
	return t ? (r.current && Mn(r.current.deps, n, 3) || (r.current = {
		deps: n,
		getStyles: e
	}), r.current.getStyles) : e;
}
// node_modules/@mantine/core/esm/core/InlineStyles/css-object-to-string/css-object-to-string.mjs
function Gn(e) {
	return D(e).reduce((t, n) => e[n] === void 0 ? t : `${t}${ee(n)}:${e[n]};`, "").trim();
}
// node_modules/@mantine/core/esm/core/InlineStyles/styles-to-string/styles-to-string.mjs
function Kn({ selector: e, styles: t, media: n, container: r }) {
	let i = t ? Gn(t) : "", a = Array.isArray(n) ? n.map((t) => `@media${t.query}{${e}{${Gn(t.styles)}}}`) : [], o = Array.isArray(r) ? r.map((t) => `@container ${t.query}{${e}{${Gn(t.styles)}}}`) : [];
	return `${i ? `${e}{${i}}` : ""}${a.join("")}${o.join("")}`.trim();
}
// node_modules/@mantine/core/esm/core/InlineStyles/InlineStyles.mjs
function qn(e) {
	let t = 5381;
	for (let n = 0; n < e.length; n++) t = (t << 5) + t + e.charCodeAt(n) | 0;
	return (t >>> 0).toString(36);
}
function Jn({ deduplicate: e, ...t }) {
	let n = Wt(), r = Kn(t);
	return e ? /* @__PURE__ */ T("style", {
		href: `mantine-${qn(r)}`,
		precedence: "mantine",
		nonce: n?.(),
		children: r
	}) : /* @__PURE__ */ T("style", {
		"data-mantine-styles": "inline",
		nonce: n?.(),
		dangerouslySetInnerHTML: { __html: r }
	});
}
// node_modules/@mantine/core/esm/core/InlineStyles/hash-styles.mjs
function Yn(e) {
	let t = 5381;
	for (let n = 0; n < e.length; n++) t = (t << 5) + t + e.charCodeAt(n) | 0;
	return (t >>> 0).toString(36);
}
function Xn(e, t) {
	return `__mdi__-${Yn(`${e ? Gn(e) : ""}|${Array.isArray(t) ? t.map((e) => `${e.query}:${Gn(e.styles)}`).join("|") : ""}`)}`;
}
// node_modules/@mantine/core/esm/core/Box/style-props/extract-style-props/extract-style-props.mjs
function Zn(e) {
	let { m: t, mx: n, my: r, mt: i, mb: a, ml: o, mr: s, me: c, ms: l, mis: u, mie: d, p: f, px: p, py: m, pt: h, pb: g, pl: _, pr: v, pe: y, ps: b, pis: x, pie: S, bd: C, bdrs: w, bg: T, c: E, opacity: D, ff: O, fz: k, fw: ee, lts: A, ta: j, lh: M, fs: N, tt: P, td: te, w: F, miw: I, maw: re, h: L, mih: R, mah: z, bgsz: ie, bgp: ae, bgr: oe, bga: se, pos: ce, top: le, left: B, bottom: V, right: H, inset: U, display: ue, flex: W, hiddenFrom: de, visibleFrom: fe, lightHidden: pe, darkHidden: me, sx: he, ...ge } = e;
	return {
		styleProps: ne({
			m: t,
			mx: n,
			my: r,
			mt: i,
			mb: a,
			ml: o,
			mr: s,
			me: c,
			ms: l,
			mis: u,
			mie: d,
			p: f,
			px: p,
			py: m,
			pt: h,
			pb: g,
			pl: _,
			pr: v,
			pis: x,
			pie: S,
			pe: y,
			ps: b,
			bd: C,
			bg: T,
			c: E,
			opacity: D,
			ff: O,
			fz: k,
			fw: ee,
			lts: A,
			ta: j,
			lh: M,
			fs: N,
			tt: P,
			td: te,
			w: F,
			miw: I,
			maw: re,
			h: L,
			mih: R,
			mah: z,
			bgsz: ie,
			bgp: ae,
			bgr: oe,
			bga: se,
			pos: ce,
			top: le,
			left: B,
			bottom: V,
			right: H,
			inset: U,
			display: ue,
			flex: W,
			bdrs: w,
			hiddenFrom: de,
			visibleFrom: fe,
			lightHidden: pe,
			darkHidden: me,
			sx: he
		}),
		rest: ge
	};
}
// node_modules/@mantine/core/esm/core/Box/style-props/style-props-data.mjs
var Qn = {
	m: {
		type: "spacing",
		property: "margin"
	},
	mt: {
		type: "spacing",
		property: "marginTop"
	},
	mb: {
		type: "spacing",
		property: "marginBottom"
	},
	ml: {
		type: "spacing",
		property: "marginLeft"
	},
	mr: {
		type: "spacing",
		property: "marginRight"
	},
	ms: {
		type: "spacing",
		property: "marginInlineStart"
	},
	me: {
		type: "spacing",
		property: "marginInlineEnd"
	},
	mis: {
		type: "spacing",
		property: "marginInlineStart"
	},
	mie: {
		type: "spacing",
		property: "marginInlineEnd"
	},
	mx: {
		type: "spacing",
		property: "marginInline"
	},
	my: {
		type: "spacing",
		property: "marginBlock"
	},
	p: {
		type: "spacing",
		property: "padding"
	},
	pt: {
		type: "spacing",
		property: "paddingTop"
	},
	pb: {
		type: "spacing",
		property: "paddingBottom"
	},
	pl: {
		type: "spacing",
		property: "paddingLeft"
	},
	pr: {
		type: "spacing",
		property: "paddingRight"
	},
	ps: {
		type: "spacing",
		property: "paddingInlineStart"
	},
	pe: {
		type: "spacing",
		property: "paddingInlineEnd"
	},
	pis: {
		type: "spacing",
		property: "paddingInlineStart"
	},
	pie: {
		type: "spacing",
		property: "paddingInlineEnd"
	},
	px: {
		type: "spacing",
		property: "paddingInline"
	},
	py: {
		type: "spacing",
		property: "paddingBlock"
	},
	bd: {
		type: "border",
		property: "border"
	},
	bdrs: {
		type: "radius",
		property: "borderRadius"
	},
	bg: {
		type: "color",
		property: "background"
	},
	c: {
		type: "textColor",
		property: "color"
	},
	opacity: {
		type: "identity",
		property: "opacity"
	},
	ff: {
		type: "fontFamily",
		property: "fontFamily"
	},
	fz: {
		type: "fontSize",
		property: "fontSize"
	},
	fw: {
		type: "identity",
		property: "fontWeight"
	},
	lts: {
		type: "size",
		property: "letterSpacing"
	},
	ta: {
		type: "identity",
		property: "textAlign"
	},
	lh: {
		type: "lineHeight",
		property: "lineHeight"
	},
	fs: {
		type: "identity",
		property: "fontStyle"
	},
	tt: {
		type: "identity",
		property: "textTransform"
	},
	td: {
		type: "identity",
		property: "textDecoration"
	},
	w: {
		type: "spacing",
		property: "width"
	},
	miw: {
		type: "spacing",
		property: "minWidth"
	},
	maw: {
		type: "spacing",
		property: "maxWidth"
	},
	h: {
		type: "spacing",
		property: "height"
	},
	mih: {
		type: "spacing",
		property: "minHeight"
	},
	mah: {
		type: "spacing",
		property: "maxHeight"
	},
	bgsz: {
		type: "size",
		property: "backgroundSize"
	},
	bgp: {
		type: "identity",
		property: "backgroundPosition"
	},
	bgr: {
		type: "identity",
		property: "backgroundRepeat"
	},
	bga: {
		type: "identity",
		property: "backgroundAttachment"
	},
	pos: {
		type: "identity",
		property: "position"
	},
	top: {
		type: "size",
		property: "top"
	},
	left: {
		type: "size",
		property: "left"
	},
	bottom: {
		type: "size",
		property: "bottom"
	},
	right: {
		type: "size",
		property: "right"
	},
	inset: {
		type: "size",
		property: "inset"
	},
	display: {
		type: "identity",
		property: "display"
	},
	flex: {
		type: "identity",
		property: "flex"
	}
};
// node_modules/@mantine/core/esm/core/Box/style-props/resolvers/color-resolver/color-resolver.mjs
function $n(e, t) {
	let n = Ot({
		color: e,
		theme: t
	});
	return n.color === "dimmed" ? "var(--mantine-color-dimmed)" : n.color === "bright" ? "var(--mantine-color-bright)" : n.variable ? `var(${n.variable})` : n.color;
}
function er(e, t) {
	let n = Ot({
		color: e,
		theme: t
	});
	return n.isThemeColor && n.shade === void 0 ? `var(--mantine-color-${n.color}-text)` : $n(e, t);
}
// node_modules/@mantine/core/esm/core/Box/style-props/resolvers/border-resolver/border-resolver.mjs
function tr(e, t) {
	if (typeof e == "number") return P(e);
	if (typeof e == "string") {
		let [n, r, ...i] = e.split(" ").filter((e) => e.trim() !== ""), a = `${P(n)}`;
		return r && (a += ` ${r}`), i.length > 0 && (a += ` ${$n(i.join(" "), t)}`), a.trim();
	}
	return e;
}
// node_modules/@mantine/core/esm/core/Box/style-props/resolvers/font-family-resolver/font-family-resolver.mjs
var nr = {
	text: "var(--mantine-font-family)",
	mono: "var(--mantine-font-family-monospace)",
	monospace: "var(--mantine-font-family-monospace)",
	heading: "var(--mantine-font-family-headings)",
	headings: "var(--mantine-font-family-headings)"
};
function rr(e) {
	return typeof e == "string" && e in nr ? nr[e] : e;
}
// node_modules/@mantine/core/esm/core/Box/style-props/resolvers/font-size-resolver/font-size-resolver.mjs
var ir = [
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6"
];
function ar(e, t) {
	return typeof e == "string" && e in t.fontSizes ? `var(--mantine-font-size-${e})` : typeof e == "string" && ir.includes(e) ? `var(--mantine-${e}-font-size)` : typeof e == "number" || typeof e == "string" ? P(e) : e;
}
// node_modules/@mantine/core/esm/core/Box/style-props/resolvers/identity-resolver/identity-resolver.mjs
function or(e) {
	return e;
}
// node_modules/@mantine/core/esm/core/Box/style-props/resolvers/line-height-resolver/line-height-resolver.mjs
var sr = [
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6"
];
function cr(e, t) {
	return typeof e == "string" && e in t.lineHeights ? `var(--mantine-line-height-${e})` : typeof e == "string" && sr.includes(e) ? `var(--mantine-${e}-line-height)` : e;
}
// node_modules/@mantine/core/esm/core/Box/style-props/resolvers/radius-resolver/radius-resolver.mjs
function lr(e, t) {
	return typeof e == "string" && e in t.radius ? `var(--mantine-radius-${e})` : typeof e == "number" || typeof e == "string" ? P(e) : e;
}
// node_modules/@mantine/core/esm/core/Box/style-props/resolvers/size-resolver/size-resolver.mjs
function ur(e) {
	return typeof e == "number" ? P(e) : e;
}
// node_modules/@mantine/core/esm/core/Box/style-props/resolvers/spacing-resolver/spacing-resolver.mjs
function dr(e, t) {
	if (typeof e == "number") return P(e);
	if (typeof e == "string") {
		let n = e.replace("-", "");
		if (!(n in t.spacing)) return P(e);
		let r = `--mantine-spacing-${n}`;
		return e.startsWith("-") ? `calc(var(${r}) * -1)` : `var(${r})`;
	}
	return e;
}
// node_modules/@mantine/core/esm/core/Box/style-props/resolvers/index.mjs
var fr = {
	color: $n,
	textColor: er,
	fontSize: ar,
	spacing: dr,
	radius: lr,
	identity: or,
	size: ur,
	lineHeight: cr,
	fontFamily: rr,
	border: tr
};
// node_modules/@mantine/core/esm/core/Box/style-props/parse-style-props/sort-media-queries.mjs
function pr(e) {
	return e.replace("(min-width: ", "").replace("em)", "");
}
function mr({ media: e, ...t }) {
	let n = Object.keys(e).sort((e, t) => Number(pr(e)) - Number(pr(t))).map((t) => ({
		query: t,
		styles: e[t]
	}));
	return {
		...t,
		media: n
	};
}
// node_modules/@mantine/core/esm/core/Box/style-props/parse-style-props/parse-style-props.mjs
function hr(e) {
	if (typeof e != "object" || !e) return !1;
	let t = Object.keys(e);
	return t.length !== 1 || t[0] !== "base";
}
function gr(e) {
	return typeof e == "object" && e ? "base" in e ? e.base : void 0 : e;
}
function _r(e) {
	return typeof e == "object" && e ? D(e).filter((e) => e !== "base") : [];
}
function vr(e, t) {
	return typeof e == "object" && e && t in e ? e[t] : e;
}
function yr({ styleProps: e, data: t, theme: n }) {
	return mr(D(e).reduce((r, i) => {
		if (i === "hiddenFrom" || i === "visibleFrom" || i === "sx") return r;
		let a = t[i], o = Array.isArray(a.property) ? a.property : [a.property], s = gr(e[i]);
		if (!hr(e[i])) return o.forEach((e) => {
			r.inlineStyles[e] = fr[a.type](s, n);
		}), r;
		r.hasResponsiveStyles = !0;
		let c = _r(e[i]);
		return o.forEach((t) => {
			s != null && (r.styles[t] = fr[a.type](s, n)), c.forEach((o) => {
				let s = `(min-width: ${n.breakpoints[o]})`;
				r.media[s] = {
					...r.media[s],
					[t]: fr[a.type](vr(e[i], o), n)
				};
			});
		}), r;
	}, {
		hasResponsiveStyles: !1,
		styles: {},
		inlineStyles: {},
		media: {}
	}));
}
// node_modules/@mantine/core/esm/core/Box/use-random-classname/use-random-classname.mjs
function br() {
	return `__m__-${h().replace(/[:«»]/g, "")}`;
}
// node_modules/@mantine/core/esm/core/Box/get-style-object/get-style-object.mjs
function xr(e, t) {
	return Array.isArray(e) ? [...e].reduce((e, n) => ({
		...e,
		...xr(n, t)
	}), {}) : typeof e == "function" ? e(t) : e ?? {};
}
// node_modules/@mantine/core/esm/core/factory/create-polymorphic-component.mjs
function Sr(e) {
	return e;
}
var Cr = Sr;
// node_modules/@mantine/core/esm/core/factory/factory.mjs
function wr(e) {
	return e;
}
function J(e) {
	let t = e;
	return t.extend = wr, t.withProps = (e) => {
		let n = (n) => /* @__PURE__ */ T(t, {
			...e,
			...n
		});
		return n.extend = t.extend, n.displayName = `WithProps(${t.displayName})`, n;
	}, t;
}
function Tr(e) {
	return J(e);
}
// node_modules/@mantine/core/esm/core/factory/polymorphic-factory.mjs
function Er(e) {
	let t = e;
	return t.withProps = (e) => {
		let n = (n) => /* @__PURE__ */ T(t, {
			...e,
			...n
		});
		return n.extend = t.extend, n.displayName = `WithProps(${t.displayName})`, n;
	}, t.extend = wr, t;
}
// node_modules/@mantine/core/esm/core/Box/get-box-mod/get-box-mod.mjs
function Dr(e) {
	return `data-${(e.startsWith("data-") ? e.slice(5) : e).replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase()}`;
}
function Or(e) {
	return Object.keys(e).reduce((t, n) => {
		let r = e[n];
		return r === void 0 || r === "" || r === !1 || r === null || (t[Dr(n)] = e[n]), t;
	}, {});
}
function kr(e) {
	return e ? typeof e == "string" ? { [Dr(e)]: !0 } : Array.isArray(e) ? [...e].reduce((e, t) => ({
		...e,
		...kr(t)
	}), {}) : Or(e) : null;
}
// node_modules/@mantine/core/esm/core/Box/get-box-style/get-box-style.mjs
function Ar(e, t) {
	return Array.isArray(e) ? [...e].reduce((e, n) => ({
		...e,
		...Ar(n, t)
	}), {}) : typeof e == "function" ? e(t) : e ?? {};
}
function jr({ theme: e, style: t, vars: n, styleProps: r }) {
	let i = Ar(t, e), a = Ar(n, e);
	return {
		...i,
		...a,
		...r
	};
}
// node_modules/@mantine/core/esm/core/Box/Box.mjs
function Mr({ component: e, style: t, __vars: n, className: r, variant: i, mod: a, size: o, hiddenFrom: s, visibleFrom: c, lightHidden: l, darkHidden: u, renderRoot: d, __size: f, ref: p, ...m }) {
	let h = pn(), g = e || "div", { styleProps: _, rest: v } = Zn(m), y = qt()?.()?.(_.sx), b = br(), x = yr({
		styleProps: _,
		theme: h,
		data: Qn
	}), S = Xt(), C = S && x.hasResponsiveStyles ? Xn(x.styles, x.media) : b, D = {
		ref: p,
		style: jr({
			theme: h,
			style: t,
			vars: n,
			styleProps: x.inlineStyles
		}),
		className: dt(r, y, {
			[C]: x.hasResponsiveStyles,
			"mantine-light-hidden": l,
			"mantine-dark-hidden": u,
			[`mantine-hidden-from-${s}`]: s,
			[`mantine-visible-from-${c}`]: c
		}),
		"data-variant": i,
		"data-size": F(o) ? void 0 : o || void 0,
		size: f,
		...kr(a),
		...v
	};
	return /* @__PURE__ */ E(w, { children: [x.hasResponsiveStyles && /* @__PURE__ */ T(Jn, {
		selector: `.${C}`,
		styles: x.styles,
		media: x.media,
		deduplicate: S
	}), typeof d == "function" ? d(D) : /* @__PURE__ */ T(g, { ...D })] });
}
Mr.displayName = "@mantine/core/Box";
var Y = Cr(Mr), Nr = s({
	dir: "ltr",
	toggleDirection: () => {},
	setDirection: () => {}
});
function Pr() {
	return u(Nr);
}
// node_modules/@mantine/core/esm/components/Collapse/Collapse.mjs
var Fr = {
	transitionDuration: 200,
	transitionTimingFunction: "ease",
	animateOpacity: !0,
	orientation: "vertical",
	keepMounted: !0,
	keepMountedMode: "activity"
}, Ir = J((e) => {
	let { children: t, expanded: n, transitionDuration: i, transitionTimingFunction: a, style: o, onTransitionEnd: s, onTransitionStart: c, animateOpacity: l, keepMounted: u, keepMountedMode: d, ref: f, orientation: p, ...m } = K("Collapse", Fr, e), h = Yt(), g = pn(), _ = et(), v = g.respectReducedMotion && _ ? 0 : i, y = (p === "horizontal" ? st : it)({
		expanded: n,
		transitionDuration: v,
		transitionTimingFunction: a,
		onTransitionEnd: s,
		onTransitionStart: c,
		keepMounted: !1
	});
	if (v === 0) return u === !0 && (d === "display-none" || h !== "test") ? d === "display-none" ? /* @__PURE__ */ T(Y, {
		...m,
		style: {
			...xr(o, g),
			...n ? {} : { display: "none" }
		},
		ref: f,
		children: t
	}) : /* @__PURE__ */ T(r, {
		mode: n ? "visible" : "hidden",
		children: /* @__PURE__ */ T(Y, {
			...m,
			style: o,
			ref: f,
			children: t
		})
	}) : n ? /* @__PURE__ */ T(Y, {
		...m,
		style: o,
		ref: f,
		children: t
	}) : null;
	let b = y.state === "exited", x;
	return x = u === !1 ? b ? null : t : u === !0 ? d === "display-none" ? t : /* @__PURE__ */ T(r, {
		mode: b ? "hidden" : "visible",
		children: t
	}) : t, /* @__PURE__ */ T(Y, {
		...m,
		...y.getCollapseProps({
			style: {
				opacity: n || !l ? 1 : 0,
				transition: l ? `opacity ${v}ms ${a}` : "none",
				...xr(o, g),
				...u && d === "display-none" && b ? { display: "none" } : {}
			},
			ref: f
		}),
		children: x
	});
});
Ir.displayName = "@mantine/core/Collapse";
// node_modules/@mantine/core/esm/components/ScrollArea/ScrollArea.context.mjs
var [Lr, Rr] = re("ScrollArea.Root component was not found in tree");
// node_modules/@mantine/core/esm/components/ScrollArea/use-resize-observer.mjs
function zr(e, t) {
	let n = m(t);
	xe(() => {
		let t = 0;
		if (e) {
			let r = new ResizeObserver(() => {
				cancelAnimationFrame(t), t = window.requestAnimationFrame(n);
			});
			return r.observe(e), () => {
				window.cancelAnimationFrame(t), r.unobserve(e);
			};
		}
	}, [e]);
}
// node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaCorner/ScrollAreaCorner.mjs
function Br(e) {
	let { style: t, ...n } = e, r = Rr(), [i, a] = y(0), [o, s] = y(0), c = !!(i && o);
	return zr(r.scrollbarX, () => {
		let e = r.scrollbarX?.offsetHeight || 0;
		r.onCornerHeightChange(e), s(e);
	}), zr(r.scrollbarY, () => {
		let e = r.scrollbarY?.offsetWidth || 0;
		r.onCornerWidthChange(e), a(e);
	}), c ? /* @__PURE__ */ T("div", {
		...n,
		style: {
			...t,
			width: i,
			height: o
		}
	}) : null;
}
function Vr(e) {
	let t = Rr(), n = !!(t.scrollbarX && t.scrollbarY);
	return t.type !== "scroll" && n ? /* @__PURE__ */ T(Br, { ...e }) : null;
}
// node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaRoot/ScrollAreaRoot.mjs
var Hr = {
	scrollHideDelay: 1e3,
	type: "hover"
};
function Ur(e) {
	let { type: t, scrollHideDelay: n, scrollbars: r, getStyles: i, ref: a, ...o } = K("ScrollAreaRoot", Hr, e), [s, c] = y(null), [l, u] = y(null), [d, f] = y(null), [p, m] = y(null), [h, g] = y(null), [_, v] = y(0), [b, x] = y(0), [S, C] = y(!1), [w, E] = y(!1), D = Qe(a, c);
	return /* @__PURE__ */ T(Lr, {
		value: {
			type: t,
			scrollHideDelay: n,
			scrollArea: s,
			viewport: l,
			onViewportChange: u,
			content: d,
			onContentChange: f,
			scrollbarX: p,
			onScrollbarXChange: m,
			scrollbarXEnabled: S,
			onScrollbarXEnabledChange: C,
			scrollbarY: h,
			onScrollbarYChange: g,
			scrollbarYEnabled: w,
			onScrollbarYEnabledChange: E,
			onCornerWidthChange: v,
			onCornerHeightChange: x,
			getStyles: i
		},
		children: /* @__PURE__ */ T(Y, {
			...o,
			ref: D,
			__vars: {
				"--sa-corner-width": r === "xy" ? `${_}px` : "0px",
				"--sa-corner-height": r === "xy" ? `${b}px` : "0px"
			}
		})
	});
}
Ur.displayName = "@mantine/core/ScrollAreaRoot";
// node_modules/@mantine/core/esm/components/ScrollArea/utils/get-thumb-ratio.mjs
function Wr(e, t) {
	let n = e / t;
	return Number.isNaN(n) ? 0 : n;
}
// node_modules/@mantine/core/esm/components/ScrollArea/utils/get-thumb-size.mjs
function Gr(e) {
	let t = Wr(e.viewport, e.content), n = e.scrollbar.paddingStart + e.scrollbar.paddingEnd, r = (e.scrollbar.size - n) * t;
	return Math.max(r, 18);
}
// node_modules/@mantine/core/esm/components/ScrollArea/utils/linear-scale.mjs
function Kr(e, t) {
	return (n) => {
		if (e[0] === e[1] || t[0] === t[1]) return t[0];
		let r = (t[1] - t[0]) / (e[1] - e[0]);
		return t[0] + r * (n - e[0]);
	};
}
// node_modules/@mantine/core/esm/components/ScrollArea/utils/get-thumb-offset-from-scroll.mjs
function qr(e, [t, n]) {
	return Math.min(n, Math.max(t, e));
}
function Jr(e, t, n = "ltr") {
	let r = Gr(t), i = t.scrollbar.paddingStart + t.scrollbar.paddingEnd, a = t.scrollbar.size - i, o = t.content - t.viewport, s = a - r, c = qr(e, n === "ltr" ? [0, o] : [o * -1, 0]);
	return Kr([0, o], [0, s])(c);
}
// node_modules/@mantine/core/esm/components/ScrollArea/utils/get-scroll-position-from-pointer.mjs
function Yr(e, t, n, r = "ltr") {
	let i = Gr(n), a = i / 2, o = t || a, s = i - o, c = n.scrollbar.paddingStart + o, l = n.scrollbar.size - n.scrollbar.paddingEnd - s, u = n.content - n.viewport, d = r === "ltr" ? [0, u] : [u * -1, 0];
	return Kr([c, l], d)(e);
}
// node_modules/@mantine/core/esm/components/ScrollArea/utils/is-scrolling-within-scrollbar-bounds.mjs
function Xr(e, t) {
	return e > 0 && e < t;
}
// node_modules/@mantine/core/esm/components/ScrollArea/utils/to-int.mjs
function Zr(e) {
	return e ? parseInt(e, 10) : 0;
}
// node_modules/@mantine/core/esm/components/ScrollArea/utils/compose-event-handlers.mjs
function Qr(e, t, { checkForDefaultPrevented: n = !0 } = {}) {
	return (r) => {
		e?.(r), n !== !1 && r.defaultPrevented || t?.(r);
	};
}
// node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/Scrollbar.context.mjs
var [$r, ei] = re("ScrollAreaScrollbar was not found in tree");
// node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/Scrollbar.mjs
function ti(e) {
	let { sizes: t, hasThumb: n, onThumbChange: r, onThumbPointerUp: i, onThumbPointerDown: a, onThumbPositionChange: o, onDragScroll: s, onWheelScroll: c, onResize: l, ref: u, ...d } = e, f = Rr(), [h, g] = y(null), _ = Qe(u, g), b = v(null), x = v(""), S = t.content - t.viewport, C = m((e) => c(e, S)), w = ge(o), E = _e(l, 10), D = (e) => {
		if (b.current) {
			let t = e.clientX - b.current.left, n = e.clientY - b.current.top;
			s({
				x: t,
				y: n
			});
		}
	};
	return p(() => {
		if (!h) return;
		let e = (e) => C(e);
		return h.addEventListener("wheel", e, { passive: !1 }), () => h.removeEventListener("wheel", e);
	}, [h]), p(w, [t, w]), zr(h, E), zr(f.content, E), /* @__PURE__ */ T($r, {
		value: {
			scrollbar: h,
			hasThumb: n,
			onThumbChange: ge(r),
			onThumbPointerUp: ge(i),
			onThumbPositionChange: w,
			onThumbPointerDown: ge(a)
		},
		children: /* @__PURE__ */ T("div", {
			...d,
			ref: _,
			"data-mantine-scrollbar": !0,
			style: {
				position: "absolute",
				...d.style
			},
			onPointerDown: Qr(e.onPointerDown, (e) => {
				e.preventDefault(), e.button === 0 && (e.target.setPointerCapture(e.pointerId), b.current = h.getBoundingClientRect(), x.current = document.body.style.webkitUserSelect, document.body.style.webkitUserSelect = "none", D(e));
			}),
			onPointerMove: Qr(e.onPointerMove, D),
			onPointerUp: Qr(e.onPointerUp, (e) => {
				let t = e.target;
				t.hasPointerCapture(e.pointerId) && (e.preventDefault(), t.releasePointerCapture(e.pointerId));
			}),
			onLostPointerCapture: () => {
				document.body.style.webkitUserSelect = x.current, b.current = null;
			}
		})
	});
}
// node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/ScrollbarX.mjs
var ni = (e) => {
	let { sizes: t, onSizesChange: n, style: r, ref: i, ...a } = e, o = Rr(), [s, c] = y(), l = v(null), u = Qe(i, l, o.onScrollbarXChange);
	return p(() => {
		l.current && c(getComputedStyle(l.current));
	}, [l]), /* @__PURE__ */ T(ti, {
		"data-orientation": "horizontal",
		...a,
		ref: u,
		sizes: t,
		style: {
			...r,
			"--sa-thumb-width": `${Gr(t)}px`
		},
		onThumbPointerDown: (t) => e.onThumbPointerDown(t.x),
		onDragScroll: (t) => e.onDragScroll(t.x),
		onWheelScroll: (t, n) => {
			if (o.viewport) {
				let r = o.viewport.scrollLeft + t.deltaX;
				e.onWheelScroll(r), Xr(r, n) && t.preventDefault();
			}
		},
		onResize: () => {
			l.current && o.viewport && s && n({
				content: o.viewport.scrollWidth,
				viewport: o.viewport.offsetWidth,
				scrollbar: {
					size: l.current.clientWidth,
					paddingStart: Zr(s.paddingLeft),
					paddingEnd: Zr(s.paddingRight)
				}
			});
		}
	});
};
ni.displayName = "@mantine/core/ScrollAreaScrollbarX";
// node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/ScrollbarY.mjs
function ri(e) {
	let { sizes: t, onSizesChange: n, style: r, ref: i, ...a } = e, o = Rr(), [s, c] = y(), l = v(null), u = Qe(i, l, o.onScrollbarYChange);
	return p(() => {
		l.current && c(window.getComputedStyle(l.current));
	}, []), /* @__PURE__ */ T(ti, {
		...a,
		"data-orientation": "vertical",
		ref: u,
		sizes: t,
		style: {
			"--sa-thumb-height": `${Gr(t)}px`,
			...r
		},
		onThumbPointerDown: (t) => e.onThumbPointerDown(t.y),
		onDragScroll: (t) => e.onDragScroll(t.y),
		onWheelScroll: (t, n) => {
			if (o.viewport) {
				let r = o.viewport.scrollTop + t.deltaY;
				e.onWheelScroll(r), Xr(r, n) && t.preventDefault();
			}
		},
		onResize: () => {
			l.current && o.viewport && s && n({
				content: o.viewport.scrollHeight,
				viewport: o.viewport.offsetHeight,
				scrollbar: {
					size: l.current.clientHeight,
					paddingStart: Zr(s.paddingTop),
					paddingEnd: Zr(s.paddingBottom)
				}
			});
		}
	});
}
ri.displayName = "@mantine/core/ScrollAreaScrollbarY";
// node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/ScrollAreaScrollbarVisible.mjs
function ii(e) {
	let { orientation: t = "vertical", ...n } = e, { dir: r } = Pr(), i = Rr(), a = v(null), o = v(0), [s, c] = y({
		content: 0,
		viewport: 0,
		scrollbar: {
			size: 0,
			paddingStart: 0,
			paddingEnd: 0
		}
	}), l = Wr(s.viewport, s.content), u = {
		...n,
		sizes: s,
		onSizesChange: c,
		hasThumb: l > 0 && l < 1,
		onThumbChange: (e) => {
			a.current = e;
		},
		onThumbPointerUp: () => {
			o.current = 0;
		},
		onThumbPointerDown: (e) => {
			o.current = e;
		}
	}, d = (e, t) => Yr(e, o.current, s, t);
	return t === "horizontal" ? /* @__PURE__ */ T(ni, {
		...u,
		onThumbPositionChange: () => {
			if (i.viewport && a.current) {
				let e = i.viewport.scrollLeft, t = Jr(e, s, r);
				a.current.style.transform = `translate3d(${t}px, 0, 0)`;
			}
		},
		onWheelScroll: (e) => {
			i.viewport && (i.viewport.scrollLeft = e);
		},
		onDragScroll: (e) => {
			i.viewport && (i.viewport.scrollLeft = d(e, r));
		}
	}) : t === "vertical" ? /* @__PURE__ */ T(ri, {
		...u,
		onThumbPositionChange: () => {
			if (i.viewport && a.current) {
				let e = i.viewport.scrollTop, t = Jr(e, s);
				s.scrollbar.size === 0 ? a.current.style.setProperty("--thumb-opacity", "0") : a.current.style.setProperty("--thumb-opacity", "1"), a.current.style.transform = `translate3d(0, ${t}px, 0)`;
			}
		},
		onWheelScroll: (e) => {
			i.viewport && (i.viewport.scrollTop = e);
		},
		onDragScroll: (e) => {
			i.viewport && (i.viewport.scrollTop = d(e));
		}
	}) : null;
}
ii.displayName = "@mantine/core/ScrollAreaScrollbarVisible";
// node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/ScrollAreaScrollbarAuto.mjs
function ai(e) {
	let t = Rr(), { forceMount: n, ...r } = e, [i, a] = y(!1), o = e.orientation === "horizontal", s = _e(() => {
		if (t.viewport) {
			let e = t.viewport.offsetWidth < t.viewport.scrollWidth, n = t.viewport.offsetHeight < t.viewport.scrollHeight;
			a(o ? e : n);
		}
	}, 10);
	return zr(t.viewport, s), zr(t.content, s), n || i ? /* @__PURE__ */ T(ii, {
		"data-state": i ? "visible" : "hidden",
		...r
	}) : null;
}
ai.displayName = "@mantine/core/ScrollAreaScrollbarAuto";
// node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/ScrollAreaScrollbarHover.mjs
function oi(e) {
	let { forceMount: t, ...n } = e, r = Rr(), [i, a] = y(!1);
	return p(() => {
		let { scrollArea: e } = r, t = 0;
		if (e) {
			let n = () => {
				window.clearTimeout(t), a(!0);
			}, i = () => {
				t = window.setTimeout(() => a(!1), r.scrollHideDelay);
			};
			return e.addEventListener("pointerenter", n), e.addEventListener("pointerleave", i), () => {
				window.clearTimeout(t), e.removeEventListener("pointerenter", n), e.removeEventListener("pointerleave", i);
			};
		}
	}, [r.scrollArea, r.scrollHideDelay]), t || i ? /* @__PURE__ */ T(ai, {
		"data-state": i ? "visible" : "hidden",
		...n
	}) : null;
}
oi.displayName = "@mantine/core/ScrollAreaScrollbarHover";
// node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/ScrollAreaScrollbarScroll.mjs
function si(e) {
	let { forceMount: t, ...n } = e, r = Rr(), i = e.orientation === "horizontal", [a, o] = y("hidden"), s = _e(() => o("idle"), 100);
	return p(() => {
		if (a === "idle") {
			let e = window.setTimeout(() => o("hidden"), r.scrollHideDelay);
			return () => window.clearTimeout(e);
		}
	}, [a, r.scrollHideDelay]), p(() => {
		let { viewport: e } = r, t = i ? "scrollLeft" : "scrollTop";
		if (e) {
			let n = e[t], r = () => {
				let r = e[t];
				n !== r && (o("scrolling"), s()), n = r;
			};
			return e.addEventListener("scroll", r), () => e.removeEventListener("scroll", r);
		}
	}, [
		r.viewport,
		i,
		s
	]), t || a !== "hidden" ? /* @__PURE__ */ T(ii, {
		"data-state": a === "hidden" ? "hidden" : "visible",
		...n,
		onPointerEnter: Qr(e.onPointerEnter, () => o("interacting")),
		onPointerLeave: Qr(e.onPointerLeave, () => o("idle"))
	}) : null;
}
// node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/ScrollAreaScrollbar.mjs
function ci(e) {
	let { forceMount: t, ...n } = e, r = Rr(), { onScrollbarXEnabledChange: i, onScrollbarYEnabledChange: a } = r, o = e.orientation === "horizontal";
	return p(() => (o ? i(!0) : a(!0), () => {
		o ? i(!1) : a(!1);
	}), [
		o,
		i,
		a
	]), r.type === "hover" ? /* @__PURE__ */ T(oi, {
		...n,
		forceMount: t
	}) : r.type === "scroll" ? /* @__PURE__ */ T(si, {
		...n,
		forceMount: t
	}) : r.type === "auto" ? /* @__PURE__ */ T(ai, {
		...n,
		forceMount: t
	}) : r.type === "always" ? /* @__PURE__ */ T(ii, { ...n }) : null;
}
ci.displayName = "@mantine/core/ScrollAreaScrollbar";
// node_modules/@mantine/core/esm/components/ScrollArea/utils/add-unlinked-scroll-listener.mjs
function li(e, t = () => {}) {
	let n = {
		left: e.scrollLeft,
		top: e.scrollTop
	}, r = 0;
	return (function i() {
		let a = {
			left: e.scrollLeft,
			top: e.scrollTop
		}, o = n.left !== a.left, s = n.top !== a.top;
		(o || s) && t(), n = a, r = window.requestAnimationFrame(i);
	})(), () => window.cancelAnimationFrame(r);
}
// node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaThumb/ScrollAreaThumb.mjs
function ui(e) {
	let { style: t, ref: n, ...r } = e, i = Rr(), a = ei(), { onThumbPositionChange: o } = a, s = Qe(n, a.onThumbChange), c = v(void 0), l = _e(() => {
		c.current &&= (c.current(), void 0);
	}, 100);
	return p(() => {
		let { viewport: e } = i;
		if (e) {
			let t = () => {
				if (l(), !c.current) {
					let t = li(e, o);
					c.current = t, o();
				}
			};
			return o(), e.addEventListener("scroll", t), () => {
				e.removeEventListener("scroll", t), c.current?.(), c.current = void 0;
			};
		}
	}, [
		i.viewport,
		l,
		o
	]), /* @__PURE__ */ T("div", {
		"data-state": a.hasThumb ? "visible" : "hidden",
		...r,
		ref: s,
		style: {
			width: "var(--sa-thumb-width)",
			height: "var(--sa-thumb-height)",
			...t
		},
		onPointerDownCapture: Qr(e.onPointerDownCapture, (e) => {
			let t = e.target.getBoundingClientRect(), n = e.clientX - t.left, r = e.clientY - t.top;
			a.onThumbPointerDown({
				x: n,
				y: r
			});
		}),
		onPointerUp: Qr(e.onPointerUp, a.onThumbPointerUp)
	});
}
ui.displayName = "@mantine/core/ScrollAreaThumb";
function di(e) {
	let { forceMount: t, ...n } = e, r = ei();
	return t || r.hasThumb ? /* @__PURE__ */ T(ui, { ...n }) : null;
}
di.displayName = "@mantine/core/ScrollAreaThumb";
// node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaViewport/ScrollAreaViewport.mjs
function fi({ children: e, style: t, ref: n, onWheel: r, ...i }) {
	let a = Rr(), o = Qe(n, a.onViewportChange), s = (e) => {
		if (r?.(e), a.scrollbarXEnabled && a.viewport && e.shiftKey) {
			let { scrollTop: t, scrollHeight: n, clientHeight: r, scrollWidth: i, clientWidth: o } = a.viewport, s = t < 1, c = t >= n - r - 1;
			i > o && (s || c) && e.stopPropagation();
		}
	};
	return /* @__PURE__ */ T(Y, {
		...i,
		ref: o,
		onWheel: s,
		"data-scrollarea-viewport": !0,
		style: {
			overflowX: a.scrollbarXEnabled ? "scroll" : "hidden",
			overflowY: a.scrollbarYEnabled ? "scroll" : "hidden",
			...t
		},
		children: /* @__PURE__ */ T("div", {
			...a.getStyles("content"),
			ref: a.onContentChange,
			children: e
		})
	});
}
fi.displayName = "@mantine/core/ScrollAreaViewport";
// node_modules/@mantine/core/esm/components/ScrollArea/ScrollArea.module.mjs
var pi = {
	root: "m_d57069b5",
	content: "m_b1336c6",
	viewport: "m_c0783ff9",
	viewportInner: "m_f8f631dd",
	scrollbar: "m_c44ba933",
	thumb: "m_d8b5e363",
	corner: "m_21657268"
};
({ ...t }).useInsertionEffect;
// node_modules/@floating-ui/react/dist/floating-ui.react.mjs
function mi(e) {
	let n = t.useRef(void 0), r = t.useCallback((t) => {
		let n = e.map((e) => {
			if (e != null) {
				if (typeof e == "function") {
					let n = e, r = n(t);
					return typeof r == "function" ? r : () => {
						n(null);
					};
				}
				return e.current = t, () => {
					e.current = null;
				};
			}
		});
		return () => {
			n.forEach((e) => e?.());
		};
	}, e);
	return t.useMemo(() => e.every((e) => e == null) ? null : (e) => {
		n.current &&= (n.current(), void 0), e != null && (n.current = r(e));
	}, e);
}
var hi = "ArrowLeft", gi = "ArrowRight", _i = "ArrowUp", vi = "ArrowDown", yi = [hi, gi], bi = [_i, vi];
[...yi, ...bi], { ...t }.useId, process.env.NODE_ENV;
// node_modules/@mantine/core/esm/components/ScrollArea/ScrollArea.mjs
var xi = {
	scrollHideDelay: 1e3,
	type: "hover",
	scrollbars: "xy"
}, Si = G((e, { scrollbarSize: t, overscrollBehavior: n, scrollbars: r }) => {
	let i = n;
	return n && r && (r === "x" ? i = `${n} auto` : r === "y" && (i = `auto ${n}`)), { root: {
		"--scrollarea-scrollbar-size": P(t),
		"--scrollarea-over-scroll-behavior": i,
		"--scrollarea-offset-size": void 0
	} };
}), Ci = J((e) => {
	let t = K("ScrollArea", xi, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, scrollbarSize: s, vars: c, type: l, scrollHideDelay: u, viewportProps: f, viewportRef: p, onScrollPositionChange: m, children: h, offsetScrollbars: g, scrollbars: _, onBottomReached: b, onTopReached: x, onLeftReached: S, onRightReached: C, overscrollBehavior: w, startScrollPosition: D, verticalScrollbarPosition: O, attributes: k, ...ee } = t, [A, j] = y(!1), [M, N] = y(!1), [P, te] = y(!1), ne = v(!0), F = v(!1), I = v(!0), re = v(!1), L = q({
		name: "ScrollArea",
		props: t,
		classes: pi,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: k,
		vars: c,
		varsResolver: Si
	}), R = v(null), [z, ie] = y(null), ae = mi([
		p,
		R,
		d((e) => {
			ie((t) => t === e ? t : e);
		}, [])
	]);
	return zr(g === "present" ? z : null, () => {
		let e = R.current;
		e && (N(e.scrollHeight > e.clientHeight), te(e.scrollWidth > e.clientWidth));
	}), xe(() => {
		D && R.current && R.current.scrollTo({
			left: D.x ?? 0,
			top: D.y ?? 0
		});
	}, []), /* @__PURE__ */ E(Ur, {
		getStyles: L,
		type: l === "never" ? "always" : l,
		scrollHideDelay: u,
		scrollbars: _,
		...L("root"),
		...ee,
		children: [
			/* @__PURE__ */ T(fi, {
				...f,
				...L("viewport", { style: f?.style }),
				ref: ae,
				"data-offset-scrollbars": g === !0 ? "xy" : g || void 0,
				"data-scrollbars": _ || void 0,
				"data-vertical-scrollbar-position": O || void 0,
				"data-horizontal-hidden": g === "present" && !P ? "true" : void 0,
				"data-vertical-hidden": g === "present" && !M ? "true" : void 0,
				onScroll: (e) => {
					f?.onScroll?.(e), m?.({
						x: e.currentTarget.scrollLeft,
						y: e.currentTarget.scrollTop
					});
					let { scrollTop: t, scrollHeight: n, clientHeight: r, scrollLeft: i, scrollWidth: a, clientWidth: o } = e.currentTarget, s = t - (n - r) >= -.8, c = t === 0;
					s && !F.current && b?.(), c && !ne.current && x?.(), F.current = s, ne.current = c;
					let l = i - (a - o) >= -.8, u = i === 0;
					l && !re.current && C?.(), u && !I.current && S?.(), re.current = l, I.current = u;
				},
				children: h
			}),
			(_ === "xy" || _ === "x") && /* @__PURE__ */ T(ci, {
				...L("scrollbar"),
				orientation: "horizontal",
				"data-vertical-scrollbar-position": O || void 0,
				"data-hidden": l === "never" || g === "present" && !P || void 0,
				forceMount: !0,
				onMouseEnter: () => j(!0),
				onMouseLeave: () => j(!1),
				children: /* @__PURE__ */ T(di, { ...L("thumb") })
			}),
			(_ === "xy" || _ === "y") && /* @__PURE__ */ T(ci, {
				...L("scrollbar"),
				orientation: "vertical",
				"data-vertical-scrollbar-position": O || void 0,
				"data-hidden": l === "never" || g === "present" && !M || void 0,
				forceMount: !0,
				onMouseEnter: () => j(!0),
				onMouseLeave: () => j(!1),
				children: /* @__PURE__ */ T(di, { ...L("thumb") })
			}),
			/* @__PURE__ */ T(Vr, {
				...L("corner"),
				"data-vertical-scrollbar-position": O || void 0,
				"data-hovered": A || void 0,
				"data-hidden": l === "never" || void 0
			})
		]
	});
});
Ci.displayName = "@mantine/core/ScrollArea";
var wi = J((e) => {
	let { children: t, classNames: n, styles: r, scrollbarSize: i, scrollHideDelay: a, type: o, dir: s, offsetScrollbars: c, overscrollBehavior: l, viewportRef: u, onScrollPositionChange: f, unstyled: p, variant: h, viewportProps: g, scrollbars: _, style: b, vars: x, onBottomReached: S, onTopReached: C, startScrollPosition: w, verticalScrollbarPosition: E, onOverflowChange: D, ...O } = K("ScrollAreaAutosize", xi, e), k = v(null), [ee, A] = y(null), j = mi([
		u,
		k,
		d((e) => {
			A((t) => t === e ? t : e);
		}, [])
	]), M = v(!1), N = v(!1), P = m(() => {
		let e = k.current;
		if (!e || !D) return;
		let t = e.scrollHeight > e.clientHeight;
		t !== M.current && (N.current ? D(t) : (N.current = !0, t && D(!0)), M.current = t);
	});
	return zr(D ? ee : null, P), /* @__PURE__ */ T(Y, {
		...O,
		variant: h,
		style: [{
			display: "flex",
			overflow: "hidden"
		}, b],
		children: /* @__PURE__ */ T(Y, {
			style: {
				display: "flex",
				flexDirection: "column",
				flex: 1,
				overflow: "hidden",
				..._ === "y" && { minWidth: 0 },
				..._ === "x" && { minHeight: 0 },
				..._ === "xy" && {
					minWidth: 0,
					minHeight: 0
				},
				..._ === !1 && {
					minWidth: 0,
					minHeight: 0
				}
			},
			children: /* @__PURE__ */ T(Ci, {
				classNames: n,
				styles: r,
				scrollHideDelay: a,
				scrollbarSize: i,
				type: o,
				dir: s,
				offsetScrollbars: c,
				overscrollBehavior: l,
				viewportRef: j,
				onScrollPositionChange: f,
				unstyled: p,
				variant: h,
				viewportProps: g,
				vars: x,
				scrollbars: _,
				onBottomReached: S,
				onTopReached: C,
				startScrollPosition: w,
				verticalScrollbarPosition: E,
				"data-autosize": "true",
				children: t
			})
		})
	});
});
Ci.classes = pi, Ci.varsResolver = Si, wi.displayName = "@mantine/core/ScrollAreaAutosize", wi.classes = pi, Ci.Autosize = wi;
// node_modules/@mantine/core/esm/components/UnstyledButton/UnstyledButton.module.mjs
var Ti = { root: "m_87cf2631" }, Ei = { __staticSelector: "UnstyledButton" }, Di = Er((e) => {
	let t = K("UnstyledButton", Ei, e), { className: n, component: r = "button", __staticSelector: i, unstyled: a, classNames: o, styles: s, style: c, attributes: l, ...u } = t, d = q({
		name: i,
		props: t,
		classes: Ti,
		className: n,
		style: c,
		classNames: o,
		styles: s,
		unstyled: a,
		attributes: l
	});
	return /* @__PURE__ */ T(Y, {
		...d("root", { focusable: !0 }),
		component: r,
		type: r === "button" ? "button" : void 0,
		...u
	});
});
Di.classes = Ti, Di.displayName = "@mantine/core/UnstyledButton";
// node_modules/@mantine/core/esm/components/VisuallyHidden/VisuallyHidden.module.mjs
var Oi = { root: "m_515a97f8" }, ki = J((e) => {
	let t = K("VisuallyHidden", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, attributes: c, ...l } = t, u = q({
		name: "VisuallyHidden",
		classes: Oi,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: c
	});
	return /* @__PURE__ */ T(Y, {
		component: "span",
		...u("root"),
		...l
	});
});
ki.classes = Oi, ki.displayName = "@mantine/core/VisuallyHidden";
// node_modules/@mantine/core/esm/components/Paper/Paper.module.mjs
var Ai = { root: "m_1b7284a3" }, ji = G((e, { radius: t, shadow: n }) => ({ root: {
	"--paper-radius": t === void 0 ? void 0 : H(t),
	"--paper-shadow": W(n)
} })), Mi = Er((e) => {
	let t = K("Paper", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, withBorder: s, vars: c, radius: l, shadow: u, variant: d, mod: f, attributes: p, ...m } = t, h = q({
		name: "Paper",
		props: t,
		classes: Ai,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: p,
		vars: c,
		varsResolver: ji
	});
	return /* @__PURE__ */ T(Y, {
		mod: [{ withBorder: s }, f],
		...h("root"),
		variant: d,
		...m
	});
});
Mi.classes = Ai, Mi.varsResolver = ji, Mi.displayName = "@mantine/core/Paper";
// node_modules/@mantine/core/esm/components/Overlay/Overlay.module.mjs
var Ni = { root: "m_9814e45f" }, Pi = { zIndex: ce("modal") }, Fi = G((e, { gradient: t, color: n, backgroundOpacity: r, blur: i, radius: a, zIndex: o }) => ({ root: {
	"--overlay-bg": t || (n !== void 0 || r !== void 0) && Nt(n || "#000", r ?? .6) || void 0,
	"--overlay-filter": i ? `blur(${P(i)})` : void 0,
	"--overlay-radius": a === void 0 ? void 0 : H(a),
	"--overlay-z-index": o?.toString()
} })), Ii = Er((e) => {
	let t = K("Overlay", Pi, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, fixed: c, center: l, children: u, radius: d, zIndex: f, gradient: p, blur: m, color: h, backgroundOpacity: g, mod: _, attributes: v, ...y } = t, b = q({
		name: "Overlay",
		props: t,
		classes: Ni,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: v,
		vars: s,
		varsResolver: Fi
	});
	return /* @__PURE__ */ T(Y, {
		...b("root"),
		mod: [{
			center: l,
			fixed: c
		}, _],
		...y,
		children: u
	});
});
Ii.classes = Ni, Ii.varsResolver = Fi, Ii.displayName = "@mantine/core/Overlay";
// node_modules/@mantine/core/esm/components/Portal/Portal.mjs
function Li(e) {
	let t = document.createElement("div");
	return t.setAttribute("data-portal", "true"), typeof e.className == "string" && t.classList.add(...e.className.split(" ").filter(Boolean)), typeof e.style == "object" && Object.assign(t.style, e.style), typeof e.id == "string" && t.setAttribute("id", e.id), t;
}
var Ri = null;
function zi({ target: e, reuseTargetNode: t, ...n }) {
	if (e) return typeof e == "string" ? document.querySelector(e) || Li(n) : e;
	if (t) {
		if (Ri) {
			if (document.body.contains(Ri)) return Ri;
			Ri = null;
		}
		let e = document.querySelector("[data-mantine-shared-portal-node]");
		if (e) return Ri = e, e;
		let t = Li(n);
		return t.setAttribute("data-mantine-shared-portal-node", "true"), document.body.appendChild(t), Ri = t, t;
	}
	return Li(n);
}
var Bi = { reuseTargetNode: !0 }, Vi = J((e) => {
	let { children: t, target: n, reuseTargetNode: r, ref: i, ...a } = K("Portal", Bi, e), [o, s] = y(!1), c = v(null);
	return xe(() => (s(!0), c.current = zi({
		target: n,
		reuseTargetNode: r,
		...a
	}), Xe(i, c.current), !n && !r && c.current && document.body.appendChild(c.current), () => {
		!n && !r && c.current && document.body.removeChild(c.current);
	}), [n]), !o || !c.current ? null : S(/* @__PURE__ */ T(w, { children: t }), c.current);
});
Vi.displayName = "@mantine/core/Portal";
// node_modules/@mantine/core/esm/components/Portal/OptionalPortal.mjs
var Hi = J(({ withinPortal: e = !0, children: t, ...n }) => Yt() === "test" || !e ? /* @__PURE__ */ T(w, { children: t }) : /* @__PURE__ */ T(Vi, {
	...n,
	children: t
}));
Hi.displayName = "@mantine/core/OptionalPortal";
// node_modules/@mantine/core/esm/components/Transition/transitions.mjs
var Ui = (e) => ({
	in: {
		opacity: 1,
		transform: "scale(1)"
	},
	out: {
		opacity: 0,
		transform: `scale(.9) translateY(${e === "bottom" ? 10 : -10}px)`
	},
	transitionProperty: "transform, opacity"
}), Wi = {
	fade: {
		in: { opacity: 1 },
		out: { opacity: 0 },
		transitionProperty: "opacity"
	},
	"fade-up": {
		in: {
			opacity: 1,
			transform: "translateY(0)"
		},
		out: {
			opacity: 0,
			transform: "translateY(30px)"
		},
		transitionProperty: "opacity, transform"
	},
	"fade-down": {
		in: {
			opacity: 1,
			transform: "translateY(0)"
		},
		out: {
			opacity: 0,
			transform: "translateY(-30px)"
		},
		transitionProperty: "opacity, transform"
	},
	"fade-left": {
		in: {
			opacity: 1,
			transform: "translateX(0)"
		},
		out: {
			opacity: 0,
			transform: "translateX(30px)"
		},
		transitionProperty: "opacity, transform"
	},
	"fade-right": {
		in: {
			opacity: 1,
			transform: "translateX(0)"
		},
		out: {
			opacity: 0,
			transform: "translateX(-30px)"
		},
		transitionProperty: "opacity, transform"
	},
	scale: {
		in: {
			opacity: 1,
			transform: "scale(1)"
		},
		out: {
			opacity: 0,
			transform: "scale(0)"
		},
		common: { transformOrigin: "top" },
		transitionProperty: "transform, opacity"
	},
	"scale-y": {
		in: {
			opacity: 1,
			transform: "scaleY(1)"
		},
		out: {
			opacity: 0,
			transform: "scaleY(0)"
		},
		common: { transformOrigin: "top" },
		transitionProperty: "transform, opacity"
	},
	"scale-x": {
		in: {
			opacity: 1,
			transform: "scaleX(1)"
		},
		out: {
			opacity: 0,
			transform: "scaleX(0)"
		},
		common: { transformOrigin: "left" },
		transitionProperty: "transform, opacity"
	},
	"skew-up": {
		in: {
			opacity: 1,
			transform: "translateY(0) skew(0deg, 0deg)"
		},
		out: {
			opacity: 0,
			transform: "translateY(-20px) skew(-10deg, -5deg)"
		},
		common: { transformOrigin: "top" },
		transitionProperty: "transform, opacity"
	},
	"skew-down": {
		in: {
			opacity: 1,
			transform: "translateY(0) skew(0deg, 0deg)"
		},
		out: {
			opacity: 0,
			transform: "translateY(20px) skew(-10deg, -5deg)"
		},
		common: { transformOrigin: "bottom" },
		transitionProperty: "transform, opacity"
	},
	"rotate-left": {
		in: {
			opacity: 1,
			transform: "translateY(0) rotate(0deg)"
		},
		out: {
			opacity: 0,
			transform: "translateY(20px) rotate(-5deg)"
		},
		common: { transformOrigin: "bottom" },
		transitionProperty: "transform, opacity"
	},
	"rotate-right": {
		in: {
			opacity: 1,
			transform: "translateY(0) rotate(0deg)"
		},
		out: {
			opacity: 0,
			transform: "translateY(20px) rotate(5deg)"
		},
		common: { transformOrigin: "top" },
		transitionProperty: "transform, opacity"
	},
	"slide-down": {
		in: {
			opacity: 1,
			transform: "translateY(0)"
		},
		out: {
			opacity: 0,
			transform: "translateY(-100%)"
		},
		common: { transformOrigin: "top" },
		transitionProperty: "transform, opacity"
	},
	"slide-up": {
		in: {
			opacity: 1,
			transform: "translateY(0)"
		},
		out: {
			opacity: 0,
			transform: "translateY(100%)"
		},
		common: { transformOrigin: "bottom" },
		transitionProperty: "transform, opacity"
	},
	"slide-left": {
		in: {
			opacity: 1,
			transform: "translateX(0)"
		},
		out: {
			opacity: 0,
			transform: "translateX(100%)"
		},
		common: { transformOrigin: "left" },
		transitionProperty: "transform, opacity"
	},
	"slide-right": {
		in: {
			opacity: 1,
			transform: "translateX(0)"
		},
		out: {
			opacity: 0,
			transform: "translateX(-100%)"
		},
		common: { transformOrigin: "right" },
		transitionProperty: "transform, opacity"
	},
	pop: {
		...Ui("bottom"),
		common: { transformOrigin: "center center" }
	},
	"pop-bottom-left": {
		...Ui("bottom"),
		common: { transformOrigin: "bottom left" }
	},
	"pop-bottom-right": {
		...Ui("bottom"),
		common: { transformOrigin: "bottom right" }
	},
	"pop-top-left": {
		...Ui("top"),
		common: { transformOrigin: "top left" }
	},
	"pop-top-right": {
		...Ui("top"),
		common: { transformOrigin: "top right" }
	}
}, Gi = {
	entering: "in",
	entered: "in",
	exiting: "out",
	exited: "out",
	"pre-exiting": "out",
	"pre-entering": "out"
};
function Ki({ transition: e, state: t, duration: n, timingFunction: r }) {
	let i = {
		WebkitBackfaceVisibility: "hidden",
		transitionDuration: `${n}ms`,
		transitionTimingFunction: r
	};
	return typeof e == "string" ? e in Wi ? {
		transitionProperty: Wi[e].transitionProperty,
		...i,
		...Wi[e].common,
		...Wi[e][Gi[t]]
	} : {} : {
		transitionProperty: e.transitionProperty,
		...i,
		...e.common,
		...e[Gi[t]]
	};
}
// node_modules/@mantine/core/esm/components/Transition/use-transition.mjs
function qi({ duration: e, exitDuration: t, timingFunction: n, mounted: r, onEnter: i, onExit: a, onEntered: o, onExited: s, enterDelay: c, exitDelay: l }) {
	let u = pn(), d = et(), f = u.respectReducedMotion ? d : !1, [m, h] = y(f ? 0 : e), [g, _] = y(r ? "entered" : "exited"), b = v(-1), S = v(-1), C = v(-1);
	function w() {
		window.clearTimeout(b.current), window.clearTimeout(S.current), cancelAnimationFrame(C.current), C.current = -1;
	}
	let T = (n) => {
		w();
		let r = n ? i : a, c = n ? o : s, l = f ? 0 : n ? e : t;
		if (h(l), l === 0) typeof r == "function" && r(), typeof c == "function" && c(), _(n ? "entered" : "exited");
		else {
			let e = requestAnimationFrame(() => {
				x.flushSync(() => {
					_(n ? "pre-entering" : "pre-exiting");
				}), C.current === e && (C.current = requestAnimationFrame(() => {
					typeof r == "function" && r(), _(n ? "entering" : "exiting"), b.current = window.setTimeout(() => {
						typeof c == "function" && c(), _(n ? "entered" : "exited");
					}, l);
				}));
			});
			C.current = e;
		}
	}, E = (e) => {
		w(), typeof (e ? c : l) == "number" ? S.current = window.setTimeout(() => {
			T(e);
		}, e ? c : l) : T(e);
	};
	return Ce(() => {
		E(r);
	}, [r]), p(() => () => {
		w();
	}, []), {
		transitionDuration: m,
		transitionStatus: g,
		transitionTimingFunction: n || "ease"
	};
}
// node_modules/@mantine/core/esm/components/Transition/Transition.mjs
function Ji({ keepMounted: e, keepMountedMode: t = "activity", transition: n = "fade", duration: i = 250, exitDuration: a = i, mounted: o, children: s, timingFunction: c = "ease", onExit: l, onEntered: u, onEnter: d, onExited: f, enterDelay: p, exitDelay: m }) {
	let h = Yt(), { transitionDuration: g, transitionStatus: _, transitionTimingFunction: v } = qi({
		mounted: o,
		exitDuration: a,
		duration: i,
		timingFunction: c,
		onExit: l,
		onEntered: u,
		onEnter: d,
		onExited: f,
		enterDelay: p,
		exitDelay: m
	});
	if (h === "test") return o ? /* @__PURE__ */ T(w, { children: s({}) }) : e ? s({ display: "none" }) : null;
	if (g === 0) return e ? t === "display-none" ? o ? /* @__PURE__ */ T(w, { children: s({}) }) : s({ display: "none" }) : /* @__PURE__ */ T(r, {
		mode: o ? "visible" : "hidden",
		children: s({})
	}) : o ? /* @__PURE__ */ T(w, { children: s({}) }) : null;
	let y = _ === "exited";
	if (e) {
		let e = s(y ? t === "display-none" ? { display: "none" } : {} : Ki({
			transition: n,
			duration: g,
			state: _,
			timingFunction: v
		}));
		return t === "display-none" ? e : /* @__PURE__ */ T(r, {
			mode: y ? "hidden" : "visible",
			children: e
		});
	}
	return y ? null : /* @__PURE__ */ T(w, { children: s(Ki({
		transition: n,
		duration: g,
		state: _,
		timingFunction: v
	})) });
}
Ji.displayName = "@mantine/core/Transition";
// node_modules/@mantine/core/esm/components/FocusTrap/FocusTrap.mjs
function Yi({ children: e, active: t = !0, refProp: n = "ref", innerRef: r }) {
	let i = Qe(qe(t), r), a = lt(e);
	return a ? o(a, { [n]: i }) : e;
}
function Xi(e) {
	return /* @__PURE__ */ T(ki, {
		tabIndex: -1,
		"data-autofocus": !0,
		...e
	});
}
Yi.displayName = "@mantine/core/FocusTrap", Xi.displayName = "@mantine/core/FocusTrapInitialFocus", Yi.InitialFocus = Xi;
// node_modules/@mantine/core/esm/components/Loader/Loader.module.mjs
var Zi = {
	root: "m_5ae2e3c",
	barsLoader: "m_7a2bd4cd",
	bar: "m_870bb79",
	"bars-loader-animation": "m_5d2b3b9d",
	dotsLoader: "m_4e3f22d7",
	dot: "m_870c4af",
	"loader-dots-animation": "m_aac34a1",
	ovalLoader: "m_b34414df",
	"oval-loader-animation": "m_f8e89c4b"
}, Qi = ({ className: e, ...t }) => /* @__PURE__ */ E(Y, {
	component: "span",
	className: dt(Zi.barsLoader, e),
	...t,
	children: [
		/* @__PURE__ */ T("span", { className: Zi.bar }),
		/* @__PURE__ */ T("span", { className: Zi.bar }),
		/* @__PURE__ */ T("span", { className: Zi.bar })
	]
});
Qi.displayName = "@mantine/core/Bars";
// node_modules/@mantine/core/esm/components/Loader/loaders/Dots.mjs
var $i = ({ className: e, ...t }) => /* @__PURE__ */ E(Y, {
	component: "span",
	className: dt(Zi.dotsLoader, e),
	...t,
	children: [
		/* @__PURE__ */ T("span", { className: Zi.dot }),
		/* @__PURE__ */ T("span", { className: Zi.dot }),
		/* @__PURE__ */ T("span", { className: Zi.dot })
	]
});
$i.displayName = "@mantine/core/Dots";
// node_modules/@mantine/core/esm/components/Loader/loaders/Oval.mjs
var ea = ({ className: e, ...t }) => /* @__PURE__ */ T(Y, {
	component: "span",
	className: dt(Zi.ovalLoader, e),
	...t
});
ea.displayName = "@mantine/core/Oval";
// node_modules/@mantine/core/esm/components/Loader/Loader.mjs
var ta = {
	bars: Qi,
	oval: ea,
	dots: $i
}, na = {
	loaders: ta,
	type: "oval"
}, ra = G((e, { size: t, color: n }) => ({ root: {
	"--loader-size": B(t, "loader-size"),
	"--loader-color": n ? kt(n, e) : void 0
} })), ia = J((e) => {
	let t = K("Loader", na, e), { size: n, color: r, type: i, vars: a, className: o, style: s, classNames: c, styles: l, unstyled: u, loaders: d, variant: f, children: p, attributes: m, ...h } = t, g = q({
		name: "Loader",
		props: t,
		classes: Zi,
		className: o,
		style: s,
		classNames: c,
		styles: l,
		unstyled: u,
		attributes: m,
		vars: a,
		varsResolver: ra
	});
	return p ? /* @__PURE__ */ T(Y, {
		...g("root"),
		...h,
		children: p
	}) : /* @__PURE__ */ T(Y, {
		...g("root"),
		component: d[i],
		variant: f,
		size: n,
		...h
	});
});
ia.defaultLoaders = ta, ia.classes = Zi, ia.varsResolver = ra, ia.displayName = "@mantine/core/Loader";
// node_modules/@mantine/core/esm/components/ActionIcon/ActionIcon.module.mjs
var aa = {
	root: "m_8d3f4000",
	icon: "m_8d3afb97",
	loader: "m_302b9fb1",
	group: "m_1a0f1b21",
	groupSection: "m_437b6484"
}, oa = { orientation: "horizontal" }, sa = G((e, { borderWidth: t }) => ({ group: { "--ai-border-width": P(t) } })), ca = J((e) => {
	let t = K("ActionIconGroup", oa, e), { className: n, style: r, classNames: i, styles: a, unstyled: o, orientation: s, vars: c, borderWidth: l, variant: u, mod: d, attributes: f, ...p } = t, m = q({
		name: "ActionIconGroup",
		props: t,
		classes: aa,
		className: n,
		style: r,
		classNames: i,
		styles: a,
		unstyled: o,
		attributes: f,
		vars: c,
		varsResolver: sa,
		rootSelector: "group"
	});
	return /* @__PURE__ */ T(Y, {
		...m("group"),
		variant: u,
		mod: [{ orientation: s }, d],
		role: "group",
		...p
	});
});
ca.classes = aa, ca.varsResolver = sa, ca.displayName = "@mantine/core/ActionIconGroup";
// node_modules/@mantine/core/esm/components/ActionIcon/ActionIconGroupSection/ActionIconGroupSection.mjs
var la = G((e, { radius: t, color: n, gradient: r, variant: i, autoContrast: a, size: o }) => {
	let s = e.variantColorResolver({
		color: n || e.primaryColor,
		theme: e,
		gradient: r,
		variant: i || "filled",
		autoContrast: a
	});
	return { groupSection: {
		"--section-height": B(o, "section-height"),
		"--section-padding-x": B(o, "section-padding-x"),
		"--section-fz": U(o),
		"--section-radius": t === void 0 ? void 0 : H(t),
		"--section-bg": n || i ? s.background : void 0,
		"--section-color": s.color,
		"--section-bd": n || i ? s.border : void 0
	} };
}), ua = J((e) => {
	let t = K("ActionIconGroupSection", null, e), { className: n, style: r, classNames: i, styles: a, unstyled: o, vars: s, variant: c, gradient: l, radius: u, autoContrast: d, attributes: f, ...p } = t, m = q({
		name: "ActionIconGroupSection",
		props: t,
		classes: aa,
		className: n,
		style: r,
		classNames: i,
		styles: a,
		unstyled: o,
		attributes: f,
		vars: s,
		varsResolver: la,
		rootSelector: "groupSection"
	});
	return /* @__PURE__ */ T(Y, {
		...m("groupSection"),
		variant: c,
		...p
	});
});
ua.classes = aa, ua.varsResolver = la, ua.displayName = "@mantine/core/ActionIconGroupSection";
// node_modules/@mantine/core/esm/components/ActionIcon/ActionIcon.mjs
var da = G((e, { size: t, radius: n, variant: r, gradient: i, color: a, autoContrast: o }) => {
	let s = e.variantColorResolver({
		color: a || e.primaryColor,
		theme: e,
		gradient: i,
		variant: r || "filled",
		autoContrast: o
	});
	return { root: {
		"--ai-size": B(t, "ai-size"),
		"--ai-radius": n === void 0 ? void 0 : H(n),
		"--ai-bg": a || r ? s.background : void 0,
		"--ai-hover": a || r ? s.hover : void 0,
		"--ai-hover-color": a || r ? s.hoverColor : void 0,
		"--ai-color": s.color,
		"--ai-bd": a || r ? s.border : void 0
	} };
}), fa = Er((e) => {
	let t = K("ActionIcon", null, e), { className: n, unstyled: r, variant: i, classNames: a, styles: o, style: s, loading: c, loaderProps: l, size: u, color: d, radius: f, __staticSelector: p, gradient: m, vars: h, children: g, disabled: _, "data-disabled": v, autoContrast: y, mod: b, attributes: x, ...S } = t, C = q({
		name: ["ActionIcon", p],
		props: t,
		className: n,
		style: s,
		classes: aa,
		classNames: a,
		styles: o,
		unstyled: r,
		attributes: x,
		vars: h,
		varsResolver: da
	});
	return /* @__PURE__ */ E(Di, {
		...C("root", { active: !_ && !c && !v }),
		"aria-busy": c || void 0,
		...S,
		unstyled: r,
		variant: i,
		size: u,
		disabled: _ || c,
		mod: [{
			loading: c,
			disabled: _ || v
		}, b],
		children: [typeof c == "boolean" && /* @__PURE__ */ T(Ji, {
			mounted: c,
			transition: "slide-down",
			duration: 150,
			children: (e) => /* @__PURE__ */ T(Y, {
				component: "span",
				...C("loader", { style: e }),
				"aria-hidden": !0,
				children: /* @__PURE__ */ T(ia, {
					color: "var(--ai-color)",
					size: "calc(var(--ai-size) * 0.55)",
					...l
				})
			})
		}), /* @__PURE__ */ T(Y, {
			component: "span",
			mod: { loading: c },
			...C("icon"),
			children: g
		})]
	});
});
fa.classes = aa, fa.varsResolver = da, fa.displayName = "@mantine/core/ActionIcon", fa.Group = ca, fa.GroupSection = ua;
// node_modules/@mantine/core/esm/components/CloseButton/CloseIcon.mjs
function pa({ size: e = "var(--cb-icon-size, 70%)", style: t, ...n }) {
	return /* @__PURE__ */ T("svg", {
		viewBox: "0 0 15 15",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		style: {
			...t,
			width: e,
			height: e
		},
		...n,
		children: /* @__PURE__ */ T("path", {
			d: "M11.7816 4.03157C12.0062 3.80702 12.0062 3.44295 11.7816 3.2184C11.5571 2.99385 11.193 2.99385 10.9685 3.2184L7.50005 6.68682L4.03164 3.2184C3.80708 2.99385 3.44301 2.99385 3.21846 3.2184C2.99391 3.44295 2.99391 3.80702 3.21846 4.03157L6.68688 7.49999L3.21846 10.9684C2.99391 11.193 2.99391 11.557 3.21846 11.7816C3.44301 12.0061 3.80708 12.0061 4.03164 11.7816L7.50005 8.31316L10.9685 11.7816C11.193 12.0061 11.5571 12.0061 11.7816 11.7816C12.0062 11.557 12.0062 11.193 11.7816 10.9684L8.31322 7.49999L11.7816 4.03157Z",
			fill: "currentColor",
			fillRule: "evenodd",
			clipRule: "evenodd"
		})
	});
}
pa.displayName = "@mantine/core/CloseIcon";
// node_modules/@mantine/core/esm/components/CloseButton/CloseButton.module.mjs
var ma = {
	root: "m_86a44da5",
	"root--subtle": "m_220c80f2"
}, ha = { variant: "subtle" }, ga = G((e, { size: t, radius: n, iconSize: r }) => ({ root: {
	"--cb-size": B(t, "cb-size"),
	"--cb-radius": n === void 0 ? void 0 : H(n),
	"--cb-icon-size": P(r)
} })), _a = Er((e) => {
	let t = K("CloseButton", ha, e), { iconSize: n, children: r, vars: i, radius: a, className: o, classNames: s, style: c, styles: l, unstyled: u, "data-disabled": d, disabled: f, variant: p, icon: m, mod: h, attributes: g, __staticSelector: _, ...v } = t, y = q({
		name: _ || "CloseButton",
		props: t,
		className: o,
		style: c,
		classes: ma,
		classNames: s,
		styles: l,
		unstyled: u,
		attributes: g,
		vars: i,
		varsResolver: ga
	});
	return /* @__PURE__ */ E(Di, {
		...v,
		unstyled: u,
		variant: p,
		disabled: f,
		mod: [{ disabled: f || d }, h],
		...y("root", {
			variant: p,
			active: !f && !d
		}),
		children: [m || /* @__PURE__ */ T(pa, {}), r]
	});
});
_a.classes = ma, _a.varsResolver = ga, _a.displayName = "@mantine/core/CloseButton";
// node_modules/@mantine/core/esm/components/Group/filter-falsy-children/filter-falsy-children.mjs
function va(e) {
	return i.toArray(e).filter(Boolean);
}
// node_modules/@mantine/core/esm/components/Group/Group.module.mjs
var ya = { root: "m_4081bf90" }, ba = {
	preventGrowOverflow: !0,
	gap: "md",
	align: "center",
	justify: "flex-start",
	wrap: "wrap"
}, xa = G((e, { grow: t, preventGrowOverflow: n, gap: r, align: i, justify: a, wrap: o }, { childWidth: s }) => ({ root: {
	"--group-child-width": t && n ? s : void 0,
	"--group-gap": V(r),
	"--group-align": i,
	"--group-justify": a,
	"--group-wrap": o
} })), X = J((e) => {
	let t = K("Group", ba, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, children: s, gap: c, align: l, justify: u, wrap: d, grow: f, preventGrowOverflow: p, vars: m, variant: h, __size: g, mod: _, attributes: v, ...y } = t, b = va(s), x = b.length, S = V(c ?? "md"), C = q({
		name: "Group",
		props: t,
		stylesCtx: { childWidth: `calc(${100 / x}% - (${S} - ${S} / ${x}))` },
		className: r,
		style: i,
		classes: ya,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: v,
		vars: m,
		varsResolver: xa
	});
	return /* @__PURE__ */ T(Y, {
		...C("root"),
		variant: h,
		mod: [{ grow: f }, _],
		size: g,
		...y,
		children: b
	});
});
X.classes = ya, X.varsResolver = xa, X.displayName = "@mantine/core/Group";
// node_modules/@mantine/core/esm/components/ModalBase/ModalBase.context.mjs
var [Sa, Ca] = re("ModalBase component was not found in tree");
// node_modules/@mantine/core/esm/components/ModalBase/use-lock-scroll.mjs
function wa({ opened: e, transitionDuration: t }) {
	let [n, r] = y(e), i = v(-1), a = et() ? 0 : t;
	return p(() => (e ? (r(!0), window.clearTimeout(i.current)) : a === 0 ? r(!1) : i.current = window.setTimeout(() => r(!1), a), () => window.clearTimeout(i.current)), [e, a]), n;
}
// node_modules/@mantine/core/esm/components/ModalBase/use-modal.mjs
function Ta({ id: e, transitionProps: t, opened: n, trapFocus: r, closeOnEscape: i, onClose: a, returnFocus: o, handledEscapeEvents: s }) {
	let c = Je(e), [l, u] = y(!1), [d, f] = y(!1), p = wa({
		opened: n,
		transitionDuration: typeof t?.duration == "number" ? t?.duration : 200
	});
	return Ye("keydown", (e) => {
		e.key === "Escape" && i && !e.isComposing && n && !s?.has(e) && e.target?.getAttribute("data-mantine-stop-propagation") !== "true" && (s?.add(e), a());
	}, { capture: !0 }), we({
		opened: n,
		shouldReturnFocus: r && o
	}), {
		_id: c,
		titleMounted: l,
		bodyMounted: d,
		shouldLockScroll: p,
		setTitleMounted: u,
		setBodyMounted: f
	};
}
// node_modules/tslib/tslib.es6.mjs
var Ea = function() {
	return Ea = Object.assign || function(e) {
		for (var t, n = 1, r = arguments.length; n < r; n++) for (var i in t = arguments[n], t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
		return e;
	}, Ea.apply(this, arguments);
};
function Da(e, t) {
	var n = {};
	for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
	if (e != null && typeof Object.getOwnPropertySymbols == "function") for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++) t.indexOf(r[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (n[r[i]] = e[r[i]]);
	return n;
}
function Oa(e, t, n) {
	if (n || arguments.length === 2) for (var r = 0, i = t.length, a; r < i; r++) (a || !(r in t)) && (a ||= Array.prototype.slice.call(t, 0, r), a[r] = t[r]);
	return e.concat(a || Array.prototype.slice.call(t));
}
// node_modules/react-remove-scroll-bar/dist/es2015/constants.js
var ka = "right-scroll-bar-position", Aa = "width-before-scroll-bar", ja = "with-scroll-bars-hidden", Ma = "--removed-body-scroll-bar-size";
// node_modules/use-callback-ref/dist/es2015/assignRef.js
function Na(e, t) {
	return typeof e == "function" ? e(t) : e && (e.current = t), e;
}
// node_modules/use-callback-ref/dist/es2015/useRef.js
function Pa(e, t) {
	var n = y(function() {
		return {
			value: e,
			callback: t,
			facade: {
				get current() {
					return n.value;
				},
				set current(e) {
					var t = n.value;
					t !== e && (n.value = e, n.callback(e, t));
				}
			}
		};
	})[0];
	return n.callback = t, n.facade;
}
// node_modules/use-callback-ref/dist/es2015/useMergeRef.js
var Fa = typeof window < "u" ? t.useLayoutEffect : t.useEffect, Ia = /* @__PURE__ */ new WeakMap();
function La(e, t) {
	var n = Pa(t || null, function(t) {
		return e.forEach(function(e) {
			return Na(e, t);
		});
	});
	return Fa(function() {
		var t = Ia.get(n);
		if (t) {
			var r = new Set(t), i = new Set(e), a = n.current;
			r.forEach(function(e) {
				i.has(e) || Na(e, null);
			}), i.forEach(function(e) {
				r.has(e) || Na(e, a);
			});
		}
		Ia.set(n, e);
	}, [e]), n;
}
// node_modules/use-sidecar/dist/es2015/medium.js
function Ra(e) {
	return e;
}
function za(e, t) {
	t === void 0 && (t = Ra);
	var n = [], r = !1;
	return {
		read: function() {
			if (r) throw Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
			return n.length ? n[n.length - 1] : e;
		},
		useMedium: function(e) {
			var i = t(e, r);
			return n.push(i), function() {
				n = n.filter(function(e) {
					return e !== i;
				});
			};
		},
		assignSyncMedium: function(e) {
			for (r = !0; n.length;) {
				var t = n;
				n = [], t.forEach(e);
			}
			n = {
				push: function(t) {
					return e(t);
				},
				filter: function() {
					return n;
				}
			};
		},
		assignMedium: function(e) {
			r = !0;
			var t = [];
			if (n.length) {
				var i = n;
				n = [], i.forEach(e), t = n;
			}
			var a = function() {
				var n = t;
				t = [], n.forEach(e);
			}, o = function() {
				return Promise.resolve().then(a);
			};
			o(), n = {
				push: function(e) {
					t.push(e), o();
				},
				filter: function(e) {
					return t = t.filter(e), n;
				}
			};
		}
	};
}
function Ba(e) {
	e === void 0 && (e = {});
	var t = za(null);
	return t.options = Ea({
		async: !0,
		ssr: !1
	}, e), t;
}
// node_modules/use-sidecar/dist/es2015/exports.js
var Va = function(e) {
	var n = e.sideCar, r = Da(e, ["sideCar"]);
	if (!n) throw Error("Sidecar: please provide `sideCar` property to import the right car");
	var i = n.read();
	if (!i) throw Error("Sidecar medium not found");
	return t.createElement(i, Ea({}, r));
};
Va.isSideCarExport = !0;
function Ha(e, t) {
	return e.useMedium(t), Va;
}
// node_modules/react-remove-scroll/dist/es2015/medium.js
var Ua = Ba(), Wa = function() {}, Ga = t.forwardRef(function(e, n) {
	var r = t.useRef(null), i = t.useState({
		onScrollCapture: Wa,
		onWheelCapture: Wa,
		onTouchMoveCapture: Wa
	}), a = i[0], o = i[1], s = e.forwardProps, c = e.children, l = e.className, u = e.removeScrollBar, d = e.enabled, f = e.shards, p = e.sideCar, m = e.noRelative, h = e.noIsolation, g = e.inert, _ = e.allowPinchZoom, v = e.as, y = v === void 0 ? "div" : v, b = e.gapMode, x = Da(e, [
		"forwardProps",
		"children",
		"className",
		"removeScrollBar",
		"enabled",
		"shards",
		"sideCar",
		"noRelative",
		"noIsolation",
		"inert",
		"allowPinchZoom",
		"as",
		"gapMode"
	]), S = p, C = La([r, n]), w = Ea(Ea({}, x), a);
	return t.createElement(t.Fragment, null, d && t.createElement(S, {
		sideCar: Ua,
		removeScrollBar: u,
		shards: f,
		noRelative: m,
		noIsolation: h,
		inert: g,
		setCallbacks: o,
		allowPinchZoom: !!_,
		lockRef: r,
		gapMode: b
	}), s ? t.cloneElement(t.Children.only(c), Ea(Ea({}, w), { ref: C })) : t.createElement(y, Ea({}, w, {
		className: l,
		ref: C
	}), c));
});
Ga.defaultProps = {
	enabled: !0,
	removeScrollBar: !0,
	inert: !1
}, Ga.classNames = {
	fullWidth: Aa,
	zeroRight: ka
};
// node_modules/get-nonce/dist/es2015/index.js
var Ka = function() {
	if (typeof __webpack_nonce__ < "u") return __webpack_nonce__;
};
// node_modules/react-style-singleton/dist/es2015/singleton.js
function qa() {
	if (!document) return null;
	var e = document.createElement("style");
	e.type = "text/css";
	var t = Ka();
	return t && e.setAttribute("nonce", t), e;
}
function Ja(e, t) {
	e.styleSheet ? e.styleSheet.cssText = t : e.appendChild(document.createTextNode(t));
}
function Ya(e) {
	(document.head || document.getElementsByTagName("head")[0]).appendChild(e);
}
var Xa = function() {
	var e = 0, t = null;
	return {
		add: function(n) {
			e == 0 && (t = qa()) && (Ja(t, n), Ya(t)), e++;
		},
		remove: function() {
			e--, !e && t && (t.parentNode && t.parentNode.removeChild(t), t = null);
		}
	};
}, Za = function() {
	var e = Xa();
	return function(n, r) {
		t.useEffect(function() {
			return e.add(n), function() {
				e.remove();
			};
		}, [n && r]);
	};
}, Qa = function() {
	var e = Za();
	return function(t) {
		var n = t.styles, r = t.dynamic;
		return e(n, r), null;
	};
}, $a = {
	left: 0,
	top: 0,
	right: 0,
	gap: 0
}, eo = function(e) {
	return parseInt(e || "", 10) || 0;
}, to = function(e) {
	var t = window.getComputedStyle(document.body), n = t[e === "padding" ? "paddingLeft" : "marginLeft"], r = t[e === "padding" ? "paddingTop" : "marginTop"], i = t[e === "padding" ? "paddingRight" : "marginRight"];
	return [
		eo(n),
		eo(r),
		eo(i)
	];
}, no = function(e) {
	if (e === void 0 && (e = "margin"), typeof window > "u") return $a;
	var t = to(e), n = document.documentElement.clientWidth, r = window.innerWidth;
	return {
		left: t[0],
		top: t[1],
		right: t[2],
		gap: Math.max(0, r - n + t[2] - t[0])
	};
}, ro = Qa(), io = "data-scroll-locked", ao = function(e, t, n, r) {
	var i = e.left, a = e.top, o = e.right, s = e.gap;
	return n === void 0 && (n = "margin"), `
  .${ja} {
   overflow: hidden ${r};
   padding-right: ${s}px ${r};
  }
  body[${io}] {
    overflow: hidden ${r};
    overscroll-behavior: contain;
    ${[
		t && `position: relative ${r};`,
		n === "margin" && `
    padding-left: ${i}px;
    padding-top: ${a}px;
    padding-right: ${o}px;
    margin-left:0;
    margin-top:0;
    margin-right: ${s}px ${r};
    `,
		n === "padding" && `padding-right: ${s}px ${r};`
	].filter(Boolean).join("")}
  }
  
  .${ka} {
    right: ${s}px ${r};
  }
  
  .${Aa} {
    margin-right: ${s}px ${r};
  }
  
  .${ka} .${ka} {
    right: 0 ${r};
  }
  
  .${Aa} .${Aa} {
    margin-right: 0 ${r};
  }
  
  body[${io}] {
    ${Ma}: ${s}px;
  }
`;
}, oo = function() {
	var e = parseInt(document.body.getAttribute("data-scroll-locked") || "0", 10);
	return isFinite(e) ? e : 0;
}, so = function() {
	t.useEffect(function() {
		return document.body.setAttribute(io, (oo() + 1).toString()), function() {
			var e = oo() - 1;
			e <= 0 ? document.body.removeAttribute(io) : document.body.setAttribute(io, e.toString());
		};
	}, []);
}, co = function(e) {
	var n = e.noRelative, r = e.noImportant, i = e.gapMode, a = i === void 0 ? "margin" : i;
	so();
	var o = t.useMemo(function() {
		return no(a);
	}, [a]);
	return t.createElement(ro, { styles: ao(o, !n, a, r ? "" : "!important") });
}, lo = !1;
if (typeof window < "u") try {
	var uo = Object.defineProperty({}, "passive", { get: function() {
		return lo = !0, !0;
	} });
	window.addEventListener("test", uo, uo), window.removeEventListener("test", uo, uo);
} catch {
	lo = !1;
}
var fo = lo ? { passive: !1 } : !1, po = function(e) {
	return e.tagName === "TEXTAREA";
}, mo = function(e, t) {
	if (!(e instanceof Element)) return !1;
	var n = window.getComputedStyle(e);
	return n[t] !== "hidden" && !(n.overflowY === n.overflowX && !po(e) && n[t] === "visible");
}, ho = function(e) {
	return mo(e, "overflowY");
}, go = function(e) {
	return mo(e, "overflowX");
}, _o = function(e, t) {
	var n = t.ownerDocument, r = t;
	do {
		if (typeof ShadowRoot < "u" && r instanceof ShadowRoot && (r = r.host), bo(e, r)) {
			var i = xo(e, r);
			if (i[1] > i[2]) return !0;
		}
		r = r.parentNode;
	} while (r && r !== n.body);
	return !1;
}, vo = function(e) {
	return [
		e.scrollTop,
		e.scrollHeight,
		e.clientHeight
	];
}, yo = function(e) {
	return [
		e.scrollLeft,
		e.scrollWidth,
		e.clientWidth
	];
}, bo = function(e, t) {
	return e === "v" ? ho(t) : go(t);
}, xo = function(e, t) {
	return e === "v" ? vo(t) : yo(t);
}, So = function(e, t) {
	return e === "h" && t === "rtl" ? -1 : 1;
}, Co = function(e, t, n, r, i) {
	var a = So(e, window.getComputedStyle(t).direction), o = a * r, s = n.target, c = t.contains(s), l = !1, u = o > 0, d = 0, f = 0;
	do {
		if (!s) break;
		var p = xo(e, s), m = p[0], h = p[1] - p[2] - a * m;
		(m || h) && bo(e, s) && (d += h, f += m);
		var g = s.parentNode;
		s = g && g.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? g.host : g;
	} while (!c && s !== document.body || c && (t.contains(s) || t === s));
	return (u && (i && Math.abs(d) < 1 || !i && o > d) || !u && (i && Math.abs(f) < 1 || !i && -o > f)) && (l = !0), l;
}, wo = function(e) {
	return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0];
}, To = function(e) {
	return [e.deltaX, e.deltaY];
}, Eo = function(e) {
	return e && "current" in e ? e.current : e;
}, Do = function(e, t) {
	return e[0] === t[0] && e[1] === t[1];
}, Oo = function(e) {
	return `
  .block-interactivity-${e} {pointer-events: none;}
  .allow-interactivity-${e} {pointer-events: all;}
`;
}, ko = 0, Ao = [];
function jo(e) {
	var n = t.useRef([]), r = t.useRef([0, 0]), i = t.useRef(), a = t.useState(ko++)[0], o = t.useState(Qa)[0], s = t.useRef(e);
	t.useEffect(function() {
		s.current = e;
	}, [e]), t.useEffect(function() {
		if (e.inert) {
			document.body.classList.add(`block-interactivity-${a}`);
			var t = Oa([e.lockRef.current], (e.shards || []).map(Eo), !0).filter(Boolean);
			return t.forEach(function(e) {
				return e.classList.add(`allow-interactivity-${a}`);
			}), function() {
				document.body.classList.remove(`block-interactivity-${a}`), t.forEach(function(e) {
					return e.classList.remove(`allow-interactivity-${a}`);
				});
			};
		}
	}, [
		e.inert,
		e.lockRef.current,
		e.shards
	]);
	var c = t.useCallback(function(e, t) {
		if ("touches" in e && e.touches.length === 2 || e.type === "wheel" && e.ctrlKey) return !s.current.allowPinchZoom;
		var n = wo(e), a = r.current, o = "deltaX" in e ? e.deltaX : a[0] - n[0], c = "deltaY" in e ? e.deltaY : a[1] - n[1], l, u = e.target, d = Math.abs(o) > Math.abs(c) ? "h" : "v";
		if ("touches" in e && d === "h" && u.type === "range") return !1;
		var f = window.getSelection(), p = f && f.anchorNode;
		if (p && (p === u || p.contains(u))) return !1;
		var m = _o(d, u);
		if (!m) return !0;
		if (m ? l = d : (l = d === "v" ? "h" : "v", m = _o(d, u)), !m) return !1;
		if (!i.current && "changedTouches" in e && (o || c) && (i.current = l), !l) return !0;
		var h = i.current || l;
		return Co(h, t, e, h === "h" ? o : c, !0);
	}, []), l = t.useCallback(function(e) {
		var t = e;
		if (Ao.length && Ao[Ao.length - 1] === o) {
			var r = "deltaY" in t ? To(t) : wo(t), i = n.current.filter(function(e) {
				return e.name === t.type && (e.target === t.target || t.target === e.shadowParent) && Do(e.delta, r);
			})[0];
			if (i && i.should) t.cancelable && t.preventDefault();
			else if (!i) {
				var a = (s.current.shards || []).map(Eo).filter(Boolean).filter(function(e) {
					return e.contains(t.target);
				});
				(a.length > 0 ? c(t, a[0]) : !s.current.noIsolation) && t.cancelable && t.preventDefault();
			}
		}
	}, []), u = t.useCallback(function(e, t, r, i) {
		var a = {
			name: e,
			delta: t,
			target: r,
			should: i,
			shadowParent: Mo(r)
		};
		n.current.push(a), setTimeout(function() {
			n.current = n.current.filter(function(e) {
				return e !== a;
			});
		}, 1);
	}, []), d = t.useCallback(function(e) {
		r.current = wo(e), i.current = void 0;
	}, []), f = t.useCallback(function(t) {
		u(t.type, To(t), t.target, c(t, e.lockRef.current));
	}, []), p = t.useCallback(function(t) {
		u(t.type, wo(t), t.target, c(t, e.lockRef.current));
	}, []);
	t.useEffect(function() {
		return Ao.push(o), e.setCallbacks({
			onScrollCapture: f,
			onWheelCapture: f,
			onTouchMoveCapture: p
		}), document.addEventListener("wheel", l, fo), document.addEventListener("touchmove", l, fo), document.addEventListener("touchstart", d, fo), function() {
			Ao = Ao.filter(function(e) {
				return e !== o;
			}), document.removeEventListener("wheel", l, fo), document.removeEventListener("touchmove", l, fo), document.removeEventListener("touchstart", d, fo);
		};
	}, []);
	var m = e.removeScrollBar, h = e.inert;
	return t.createElement(t.Fragment, null, h ? t.createElement(o, { styles: Oo(a) }) : null, m ? t.createElement(co, {
		noRelative: e.noRelative,
		gapMode: e.gapMode
	}) : null);
}
function Mo(e) {
	for (var t = null; e !== null;) e instanceof ShadowRoot && (t = e.host, e = e.host), e = e.parentNode;
	return t;
}
// node_modules/react-remove-scroll/dist/es2015/sidecar.js
var No = Ha(Ua, jo), Po = t.forwardRef(function(e, n) {
	return t.createElement(Ga, Ea({}, e, {
		ref: n,
		sideCar: No
	}));
});
Po.classNames = Ga.classNames;
// node_modules/@mantine/core/esm/components/ModalBase/ModalBase.mjs
function Fo({ keepMounted: e, keepMountedMode: t = "activity", opened: n, onClose: r, id: i, transitionProps: a, onExitTransitionEnd: o, onEnterTransitionEnd: s, trapFocus: c, closeOnEscape: l, returnFocus: u, closeOnClickOutside: d, withinPortal: f, portalProps: p, lockScroll: m, children: h, zIndex: g, shadow: _, padding: v, __vars: y, unstyled: b, removeScrollProps: x, __handledEscapeEvents: S, ...C }) {
	let { _id: w, titleMounted: E, bodyMounted: D, shouldLockScroll: O, setTitleMounted: k, setBodyMounted: ee } = Ta({
		id: i,
		transitionProps: a,
		opened: n,
		trapFocus: c,
		closeOnEscape: l,
		onClose: r,
		returnFocus: u,
		handledEscapeEvents: S
	}), { key: A, ...j } = x || {};
	return /* @__PURE__ */ T(Hi, {
		...p,
		withinPortal: f,
		children: /* @__PURE__ */ T(Sa, {
			value: {
				opened: n,
				onClose: r,
				closeOnClickOutside: d,
				onExitTransitionEnd: o,
				onEnterTransitionEnd: s,
				transitionProps: {
					...a,
					keepMounted: e,
					keepMountedMode: t
				},
				getTitleId: () => `${w}-title`,
				getBodyId: () => `${w}-body`,
				titleMounted: E,
				bodyMounted: D,
				setTitleMounted: k,
				setBodyMounted: ee,
				trapFocus: c,
				closeOnEscape: l,
				zIndex: g,
				unstyled: b
			},
			children: /* @__PURE__ */ T(Po, {
				enabled: O && m,
				...j,
				children: /* @__PURE__ */ T(Y, {
					...C,
					id: w,
					__vars: {
						...y,
						"--mb-z-index": (g || ce("modal")).toString(),
						"--mb-shadow": W(_),
						"--mb-padding": V(v)
					},
					children: h
				})
			}, A)
		})
	});
}
Fo.displayName = "@mantine/core/ModalBase";
// node_modules/@mantine/core/esm/components/ModalBase/use-modal-body-id.mjs
function Io() {
	let e = Ca();
	return p(() => (e.setBodyMounted(!0), () => e.setBodyMounted(!1)), []), e.getBodyId();
}
// node_modules/@mantine/core/esm/components/ModalBase/ModalBase.module.mjs
var Lo = {
	title: "m_615af6c9",
	header: "m_b5489c3c",
	inner: "m_60c222c7",
	content: "m_fd1ab0aa",
	close: "m_606cb269",
	body: "m_5df29311"
};
// node_modules/@mantine/core/esm/components/ModalBase/ModalBaseBody.mjs
function Ro({ className: e, ...t }) {
	let n = Io(), r = Ca();
	return /* @__PURE__ */ T(Y, {
		id: n,
		className: dt({ [Lo.body]: !r.unstyled }, e),
		...t
	});
}
Ro.displayName = "@mantine/core/ModalBaseBody";
// node_modules/@mantine/core/esm/components/ModalBase/ModalBaseCloseButton.mjs
function zo({ className: e, onClick: t, ...n }) {
	let r = Ca();
	return /* @__PURE__ */ T(_a, {
		...n,
		onClick: (e) => {
			r.onClose(), t?.(e);
		},
		className: dt({ [Lo.close]: !r.unstyled }, e),
		unstyled: r.unstyled
	});
}
zo.displayName = "@mantine/core/ModalBaseCloseButton";
// node_modules/@mantine/core/esm/components/ModalBase/ModalBaseContent.mjs
function Bo({ transitionProps: e, className: t, innerProps: n, onKeyDown: r, style: i, ref: a, ...o }) {
	let s = Ca();
	return /* @__PURE__ */ T(Ji, {
		mounted: s.opened,
		transition: "pop",
		...s.transitionProps,
		onExited: () => {
			s.onExitTransitionEnd?.(), s.transitionProps?.onExited?.();
		},
		onEntered: () => {
			s.onEnterTransitionEnd?.(), s.transitionProps?.onEntered?.();
		},
		...e,
		children: (e) => /* @__PURE__ */ T("div", {
			...n,
			className: dt({ [Lo.inner]: !s.unstyled }, n.className),
			children: /* @__PURE__ */ T(Yi, {
				active: s.opened && s.trapFocus,
				innerRef: a,
				children: /* @__PURE__ */ T(Mi, {
					...o,
					component: "section",
					role: "dialog",
					tabIndex: -1,
					"aria-modal": !0,
					"aria-describedby": s.bodyMounted ? s.getBodyId() : void 0,
					"aria-labelledby": s.titleMounted ? s.getTitleId() : void 0,
					style: [i, e],
					className: dt({ [Lo.content]: !s.unstyled }, t),
					unstyled: s.unstyled,
					children: o.children
				})
			})
		})
	});
}
Bo.displayName = "@mantine/core/ModalBaseContent";
// node_modules/@mantine/core/esm/components/ModalBase/ModalBaseHeader.mjs
function Vo({ className: e, ...t }) {
	let n = Ca();
	return /* @__PURE__ */ T(Y, {
		component: "header",
		className: dt({ [Lo.header]: !n.unstyled }, e),
		...t
	});
}
Vo.displayName = "@mantine/core/ModalBaseHeader";
// node_modules/@mantine/core/esm/components/ModalBase/use-modal-transition.mjs
var Ho = {
	duration: 200,
	timingFunction: "ease",
	transition: "fade"
};
function Uo(e) {
	let t = Ca();
	return {
		...Ho,
		...t.transitionProps,
		...e
	};
}
// node_modules/@mantine/core/esm/components/ModalBase/ModalBaseOverlay.mjs
function Wo({ onClick: e, transitionProps: t, style: n, visible: r, ...i }) {
	let a = Ca(), o = Uo(t);
	return /* @__PURE__ */ T(Ji, {
		mounted: r === void 0 ? a.opened : r,
		...o,
		transition: "fade",
		children: (t) => /* @__PURE__ */ T(Ii, {
			fixed: !0,
			style: [n, t],
			zIndex: a.zIndex,
			unstyled: a.unstyled,
			onClick: (t) => {
				e?.(t), a.closeOnClickOutside && a.onClose();
			},
			...i
		})
	});
}
Wo.displayName = "@mantine/core/ModalBaseOverlay";
// node_modules/@mantine/core/esm/components/ModalBase/use-modal-title-id.mjs
function Go() {
	let e = Ca();
	return p(() => (e.setTitleMounted(!0), () => e.setTitleMounted(!1)), []), e.getTitleId();
}
// node_modules/@mantine/core/esm/components/ModalBase/ModalBaseTitle.mjs
function Ko({ className: e, ...t }) {
	let n = Go(), r = Ca();
	return /* @__PURE__ */ T(Y, {
		component: "h2",
		className: dt({ [Lo.title]: !r.unstyled }, e),
		id: n,
		...t
	});
}
Ko.displayName = "@mantine/core/ModalBaseTitle";
// node_modules/@mantine/core/esm/components/ModalBase/NativeScrollArea.mjs
function qo({ children: e }) {
	return /* @__PURE__ */ T(w, { children: e });
}
// node_modules/@mantine/core/esm/components/Input/Input.context.mjs
var Jo = s({ size: "sm" }), Yo = J((e) => {
	let t = K("InputClearButton", null, e), { size: n, variant: r, vars: i, classNames: a, styles: o, ...s } = t, c = u(Jo), { resolvedClassNames: l, resolvedStyles: d } = kn({
		classNames: a,
		styles: o,
		props: t
	});
	return /* @__PURE__ */ T(_a, {
		variant: r || "transparent",
		size: n || c?.size || "sm",
		classNames: l,
		styles: d,
		__staticSelector: "InputClearButton",
		style: {
			pointerEvents: "all",
			background: "var(--input-bg)",
			...s.style
		},
		...s
	});
});
Yo.displayName = "@mantine/core/InputClearButton";
// node_modules/@mantine/core/esm/components/Input/InputClearSection/InputClearSection.mjs
var Xo = {
	xs: 7,
	sm: 8,
	md: 10,
	lg: 12,
	xl: 15
};
function Zo({ __clearable: e, __clearSection: t, rightSection: n, __defaultRightSection: r, size: i = "sm", __clearSectionMode: a = "both" }) {
	let o = e && t;
	return a === "rightSection" ? n === null ? null : n || r : a === "clear" ? n === null ? null : o || r : o && (n || r) ? /* @__PURE__ */ E("div", {
		"data-combined-clear-section": !0,
		style: {
			display: "flex",
			gap: 2,
			alignItems: "center",
			paddingInlineEnd: Xo[i]
		},
		children: [o, n || r]
	}) : n === null ? null : n || o || r;
}
// node_modules/@mantine/core/esm/components/Input/InputWrapper.context.mjs
var Qo = s({
	offsetBottom: !1,
	offsetTop: !1,
	describedBy: void 0,
	getStyles: null,
	inputId: void 0,
	labelId: void 0
}), $o = {
	wrapper: "m_6c018570",
	input: "m_8fb7ebe7",
	bottomSection: "m_93f4ed57",
	section: "m_82577fc2",
	placeholder: "m_88bacfd0",
	root: "m_46b77525",
	label: "m_8fdc1311",
	required: "m_78a94662",
	error: "m_8f816625",
	success: "m_9d9d40e0",
	description: "m_fe47ce59"
}, es = G((e, { size: t }) => ({ description: { "--input-description-size": t === void 0 ? void 0 : `calc(${U(t)} - ${P(2)})` } })), ts = J((e) => {
	let t = K("InputDescription", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, __staticSelector: c, __inheritStyles: l = !0, attributes: d, ...f } = K("InputDescription", null, t), p = u(Qo), m = q({
		name: ["InputWrapper", c],
		props: t,
		classes: $o,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: d,
		rootSelector: "description",
		vars: s,
		varsResolver: es
	}), h = l && p?.getStyles || m;
	return /* @__PURE__ */ T(Y, {
		component: "p",
		...h("description", p?.getStyles ? {
			className: r,
			style: i
		} : void 0),
		...f
	});
});
ts.classes = $o, ts.varsResolver = es, ts.displayName = "@mantine/core/InputDescription";
// node_modules/@mantine/core/esm/components/Input/InputError/InputError.mjs
var ns = G((e, { size: t }) => ({ error: { "--input-error-size": t === void 0 ? void 0 : `calc(${U(t)} - ${P(2)})` } })), rs = J((e) => {
	let t = K("InputError", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, attributes: c, __staticSelector: l, __inheritStyles: d = !0, ...f } = t, p = q({
		name: ["InputWrapper", l],
		props: t,
		classes: $o,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: c,
		rootSelector: "error",
		vars: s,
		varsResolver: ns
	}), m = u(Qo), h = d && m?.getStyles || p;
	return /* @__PURE__ */ T(Y, {
		component: "p",
		...h("error", m?.getStyles ? {
			className: r,
			style: i
		} : void 0),
		...f
	});
});
rs.classes = $o, rs.varsResolver = ns, rs.displayName = "@mantine/core/InputError";
// node_modules/@mantine/core/esm/components/Input/InputLabel/InputLabel.mjs
var is = { labelElement: "label" }, as = G((e, { size: t }) => ({ label: {
	"--input-label-size": U(t),
	"--input-asterisk-color": void 0
} })), os = J((e) => {
	let t = K("InputLabel", is, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, labelElement: c, required: l, htmlFor: d, onMouseDown: f, children: p, __staticSelector: m, mod: h, attributes: g, ..._ } = t, v = q({
		name: ["InputWrapper", m],
		props: t,
		classes: $o,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: g,
		rootSelector: "label",
		vars: s,
		varsResolver: as
	}), y = u(Qo), b = y?.getStyles || v, x = _.component || c, S = typeof x != "string" || x === "label";
	return /* @__PURE__ */ E(Y, {
		...b("label", y?.getStyles ? {
			className: r,
			style: i
		} : void 0),
		component: c,
		htmlFor: S ? d : void 0,
		mod: [{ required: l }, h],
		onMouseDown: (e) => {
			f?.(e), !e.defaultPrevented && e.detail > 1 && e.preventDefault();
		},
		..._,
		children: [p, l && /* @__PURE__ */ T("span", {
			...b("required"),
			"aria-hidden": !0,
			children: " *"
		})]
	});
});
os.classes = $o, os.varsResolver = as, os.displayName = "@mantine/core/InputLabel";
// node_modules/@mantine/core/esm/components/Input/InputPlaceholder/InputPlaceholder.mjs
var ss = J((e) => {
	let t = K("InputPlaceholder", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, __staticSelector: c, error: l, mod: u, attributes: d, ...f } = t, p = q({
		name: ["InputPlaceholder", c],
		props: t,
		classes: $o,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: d,
		rootSelector: "placeholder"
	});
	return /* @__PURE__ */ T(Y, {
		...p("placeholder"),
		mod: [{ error: !!l }, u],
		component: "span",
		...f
	});
});
ss.classes = $o, ss.displayName = "@mantine/core/InputPlaceholder";
// node_modules/@mantine/core/esm/components/Input/InputSuccess/InputSuccess.mjs
var cs = G((e, { size: t }) => ({ success: { "--input-success-size": t === void 0 ? void 0 : `calc(${U(t)} - ${P(2)})` } })), ls = J((e) => {
	let t = K("InputSuccess", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, attributes: c, __staticSelector: l, __inheritStyles: d = !0, ...f } = t, p = q({
		name: ["InputWrapper", l],
		props: t,
		classes: $o,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: c,
		rootSelector: "success",
		vars: s,
		varsResolver: cs
	}), m = u(Qo), h = d && m?.getStyles || p;
	return /* @__PURE__ */ T(Y, {
		component: "p",
		...h("success", m?.getStyles ? {
			className: r,
			style: i
		} : void 0),
		...f
	});
});
ls.classes = $o, ls.varsResolver = cs, ls.displayName = "@mantine/core/InputSuccess";
// node_modules/@mantine/core/esm/components/Input/InputWrapper/get-input-offsets/get-input-offsets.mjs
function us(e, { hasDescription: t, hasError: n }) {
	let r = e.findIndex((e) => e === "input"), i = e.slice(0, r), a = e.slice(r + 1), o = t && i.includes("description") || n && i.includes("error");
	return {
		offsetBottom: t && a.includes("description") || n && a.includes("error"),
		offsetTop: o
	};
}
// node_modules/@mantine/core/esm/components/Input/InputWrapper/InputWrapper.mjs
var ds = {
	labelElement: "label",
	inputContainer: (e) => e,
	inputWrapperOrder: [
		"label",
		"description",
		"input",
		"error"
	]
}, fs = G((e, { size: t }) => ({
	label: {
		"--input-label-size": U(t),
		"--input-asterisk-color": void 0
	},
	error: { "--input-error-size": t === void 0 ? void 0 : `calc(${U(t)} - ${P(2)})` },
	success: { "--input-success-size": t === void 0 ? void 0 : `calc(${U(t)} - ${P(2)})` },
	description: { "--input-description-size": t === void 0 ? void 0 : `calc(${U(t)} - ${P(2)})` }
})), ps = J((e) => {
	let t = K("InputWrapper", ds, e), { classNames: n, className: r, style: i, styles: o, unstyled: s, vars: l, size: u, variant: d, __staticSelector: f, inputContainer: p, inputWrapperOrder: m, label: h, error: g, success: _, description: v, labelProps: y, descriptionProps: b, errorProps: x, successProps: S, labelElement: C, children: w, withAsterisk: E, id: D, required: O, __stylesApiProps: k, mod: ee, attributes: A, ...j } = t, M = q({
		name: ["InputWrapper", f],
		props: k || t,
		classes: $o,
		className: r,
		style: i,
		classNames: n,
		styles: o,
		unstyled: s,
		attributes: A,
		vars: l,
		varsResolver: fs
	}), N = {
		size: u,
		variant: d,
		__staticSelector: f
	}, P = Je(D), te = typeof E == "boolean" ? E : O, ne = x?.id || `${P}-error`, F = S?.id || `${P}-success`, I = b?.id || `${P}-description`, re = P, L = !!g && typeof g != "boolean", R = !!_ && typeof _ != "boolean" && !g, z = !!v, ie = L && m.includes("error"), ae = R && m.includes("error"), oe = z && m.includes("description"), se = `${ie ? ne : ""} ${ae ? F : ""} ${oe ? I : ""}`, ce = se.trim().length > 0 ? se.trim() : void 0, le = y?.id || `${P}-label`, B = h && /* @__PURE__ */ T(os, {
		labelElement: C,
		id: le,
		htmlFor: re,
		required: te,
		...N,
		...y,
		children: h
	}, "label"), V = z && /* @__PURE__ */ T(ts, {
		...b,
		...N,
		size: b?.size || N.size,
		id: b?.id || I,
		children: v
	}, "description"), H = /* @__PURE__ */ T(a, { children: p(w) }, "input"), U = L && /* @__PURE__ */ c(rs, {
		...x,
		...N,
		size: x?.size || N.size,
		key: "error",
		id: x?.id || ne
	}, g), ue = R && /* @__PURE__ */ c(ls, {
		...S,
		...N,
		size: S?.size || N.size,
		key: "success",
		id: S?.id || F
	}, _), W = m.map((e) => {
		switch (e) {
			case "label": return B;
			case "input": return H;
			case "description": return V;
			case "error": return U || ue;
			default: return null;
		}
	});
	return /* @__PURE__ */ T(Qo, {
		value: {
			getStyles: M,
			describedBy: ce,
			inputId: re,
			labelId: B && m.includes("label") ? le : void 0,
			...us(m, {
				hasDescription: z,
				hasError: L || R
			})
		},
		children: /* @__PURE__ */ T(Y, {
			variant: d,
			size: u,
			mod: [{
				error: !!g,
				success: !!_ && !g
			}, ee],
			id: C === "label" ? void 0 : D,
			...M("root"),
			...j,
			children: W
		})
	});
});
ps.classes = $o, ps.varsResolver = fs, ps.displayName = "@mantine/core/InputWrapper";
// node_modules/@mantine/core/esm/components/Input/Input.mjs
var ms = {
	variant: "default",
	leftSectionPointerEvents: "none",
	rightSectionPointerEvents: "none",
	withAria: !0,
	withErrorStyles: !0,
	withSuccessStyles: !0,
	size: "sm",
	loading: !1,
	loadingPosition: "right"
}, hs = G((e, t, n) => ({ wrapper: {
	"--input-margin-top": n.offsetTop ? "calc(var(--mantine-spacing-xs) / 2)" : void 0,
	"--input-margin-bottom": n.offsetBottom ? "calc(var(--mantine-spacing-xs) / 2)" : void 0,
	"--input-height": B(t.size, "input-height"),
	"--input-fz": U(t.size),
	"--input-radius": t.radius === void 0 ? void 0 : H(t.radius),
	"--input-left-section-width": t.leftSectionWidth === void 0 ? void 0 : P(t.leftSectionWidth),
	"--input-right-section-width": t.rightSectionWidth === void 0 ? void 0 : P(t.rightSectionWidth),
	"--input-padding-y": t.multiline ? B(t.size, "input-padding-y") : void 0,
	"--input-left-section-pointer-events": t.leftSectionPointerEvents,
	"--input-right-section-pointer-events": t.rightSectionPointerEvents
} })), gs = Er((e) => {
	let t = K("Input", ms, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, required: s, __staticSelector: c, __stylesApiProps: l, size: d, wrapperProps: f, error: p, success: m, disabled: h, leftSection: g, leftSectionProps: _, leftSectionWidth: v, rightSection: y, rightSectionProps: b, rightSectionWidth: x, rightSectionPointerEvents: S, leftSectionPointerEvents: C, variant: w, vars: D, pointer: O, multiline: k, radius: ee, id: A, withAria: j, withErrorStyles: M, withSuccessStyles: N, mod: P, inputSize: te, attributes: ne, __clearSection: F, __clearable: I, __clearSectionMode: re, __defaultRightSection: L, loading: R, loadingPosition: z, __bottomSection: ie, __bottomSectionProps: ae, rootRef: oe, dir: se, ...ce } = t, { styleProps: le, rest: B } = Zn(ce), V = u(Qo), H = {
		offsetBottom: V?.offsetBottom,
		offsetTop: V?.offsetTop
	}, U = q({
		name: ["Input", c],
		props: l || t,
		classes: $o,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: ne,
		stylesCtx: H,
		rootSelector: "wrapper",
		vars: D,
		varsResolver: hs
	}), ue = j ? {
		required: s,
		disabled: h,
		"aria-invalid": p ? !0 : void 0,
		"aria-describedby": V?.describedBy,
		id: V?.inputId || A
	} : {}, W = R ? /* @__PURE__ */ T(ia, { size: z === "left" ? "calc(var(--input-left-section-size) / 2)" : "calc(var(--input-right-section-size) / 2)" }) : null, de = R && z === "left" ? W : g, fe = Zo({
		__clearable: I,
		__clearSection: F,
		rightSection: R && z === "right" ? W : y,
		__defaultRightSection: L,
		size: d,
		__clearSectionMode: re
	});
	return /* @__PURE__ */ T(Jo, {
		value: { size: d || "sm" },
		children: /* @__PURE__ */ E(Y, {
			ref: oe,
			dir: se,
			...U("wrapper"),
			...le,
			...f,
			mod: [{
				error: !!p && M,
				success: !!m && !p && N,
				pointer: O,
				disabled: h,
				multiline: k,
				withRightSection: !!fe,
				withLeftSection: !!de,
				withBottomSection: !!ie
			}, P],
			variant: w,
			size: d,
			children: [
				de && /* @__PURE__ */ T("div", {
					..._,
					"data-position": "left",
					...U("section", {
						className: _?.className,
						style: _?.style
					}),
					children: de
				}),
				/* @__PURE__ */ T(Y, {
					component: "input",
					...B,
					...ue,
					required: s,
					mod: {
						disabled: h,
						error: !!p && M,
						success: !!m && !p && N
					},
					variant: w,
					__size: te,
					...U("input")
				}),
				ie && /* @__PURE__ */ T("div", {
					...ae,
					...U("bottomSection", {
						className: ae?.className,
						style: ae?.style
					}),
					children: ie
				}),
				fe && /* @__PURE__ */ T("div", {
					...b,
					"data-position": "right",
					...U("section", {
						className: b?.className,
						style: b?.style
					}),
					children: fe
				})
			]
		})
	});
});
gs.classes = $o, gs.varsResolver = hs, gs.Wrapper = ps, gs.Label = os, gs.Error = rs, gs.Success = ls, gs.Description = ts, gs.Placeholder = ss, gs.ClearButton = Yo, gs.displayName = "@mantine/core/Input";
// node_modules/@mantine/core/esm/components/Input/use-input-props.mjs
function _s(e, t, n) {
	let r = K([
		"Input",
		"InputWrapper",
		e
	], t, n), { label: i, description: a, error: o, success: s, required: c, classNames: l, styles: u, className: d, unstyled: f, __staticSelector: p, __stylesApiProps: m, errorProps: h, successProps: g, labelProps: _, descriptionProps: v, wrapperProps: y, id: b, size: x, style: S, inputContainer: C, inputWrapperOrder: w, withAsterisk: T, variant: E, vars: D, mod: O, attributes: k, ...ee } = r, { styleProps: A, rest: j } = Zn(ee), M = {
		label: i,
		description: a,
		error: o,
		success: s,
		required: c,
		classNames: l,
		className: d,
		__staticSelector: p,
		__stylesApiProps: m || r,
		errorProps: h,
		successProps: g,
		labelProps: _,
		descriptionProps: v,
		unstyled: f,
		styles: u,
		size: x,
		style: S,
		inputContainer: C,
		inputWrapperOrder: w,
		withAsterisk: T,
		variant: E,
		id: b,
		mod: O,
		attributes: k,
		...y
	};
	return {
		...j,
		classNames: l,
		styles: u,
		unstyled: f,
		wrapperProps: {
			...M,
			...A
		},
		inputProps: {
			required: c,
			classNames: l,
			styles: u,
			unstyled: f,
			size: x,
			__staticSelector: p,
			__stylesApiProps: m || r,
			error: o,
			success: s,
			variant: E,
			id: b,
			attributes: k
		}
	};
}
// node_modules/@mantine/core/esm/components/InputBase/InputBase.mjs
var vs = {
	__staticSelector: "InputBase",
	withAria: !0,
	size: "sm"
}, ys = Er((e) => {
	let { inputProps: t, wrapperProps: n, ...r } = _s("InputBase", vs, e);
	return /* @__PURE__ */ T(gs.Wrapper, {
		...n,
		children: /* @__PURE__ */ T(gs, {
			...t,
			...r
		})
	});
});
ys.classes = {
	...gs.classes,
	...gs.Wrapper.classes
}, ys.displayName = "@mantine/core/InputBase";
// node_modules/@mantine/core/esm/components/Accordion/Accordion.context.mjs
var [bs, xs] = re("Accordion component was not found in the tree");
// node_modules/@mantine/core/esm/components/Accordion/AccordionChevron.mjs
function Ss({ style: e, size: t = 16, ...n }) {
	return /* @__PURE__ */ T("svg", {
		viewBox: "0 0 15 15",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		style: {
			...e,
			width: P(t),
			height: P(t),
			display: "block"
		},
		...n,
		children: /* @__PURE__ */ T("path", {
			d: "M3.13523 6.15803C3.3241 5.95657 3.64052 5.94637 3.84197 6.13523L7.5 9.56464L11.158 6.13523C11.3595 5.94637 11.6759 5.95657 11.8648 6.15803C12.0536 6.35949 12.0434 6.67591 11.842 6.86477L7.84197 10.6148C7.64964 10.7951 7.35036 10.7951 7.15803 10.6148L3.15803 6.86477C2.95657 6.67591 2.94637 6.35949 3.13523 6.15803Z",
			fill: "currentColor",
			fillRule: "evenodd",
			clipRule: "evenodd"
		})
	});
}
Ss.displayName = "@mantine/core/AccordionChevron";
// node_modules/@mantine/core/esm/components/Accordion/AccordionItem.context.mjs
var [Cs, ws] = re("Accordion.Item component was not found in the tree"), Ts = {
	root: "m_9bdbb667",
	panel: "m_df78851f",
	content: "m_4ba554d4",
	itemTitle: "m_8fa820a0",
	control: "m_4ba585b8",
	"control--default": "m_6939a5e9",
	"control--contained": "m_4271d21b",
	label: "m_df3ffa0f",
	chevron: "m_3f35ae96",
	icon: "m_9bd771fe",
	item: "m_9bd7b098",
	"item--default": "m_fe19b709",
	"item--contained": "m_1f921b3b",
	"item--filled": "m_2cdf939a",
	"item--separated": "m_9f59b069"
}, Es = J((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, chevron: o, icon: s, onClick: c, onKeyDown: l, children: u, disabled: d, mod: f, ...p } = K("AccordionControl", null, e), { value: m } = ws(), h = xs(), g = h.isItemActive(m), _ = typeof h.order == "number", v = `h${h.order}`, y = /* @__PURE__ */ E(Di, {
		...h.getStyles("control", {
			className: n,
			classNames: t,
			style: r,
			styles: i,
			variant: h.variant
		}),
		unstyled: h.unstyled,
		mod: [
			"accordion-control",
			{
				active: g,
				"chevron-position": h.chevronPosition,
				disabled: d
			},
			f
		],
		onClick: (e) => {
			c?.(e), h.onChange(m);
		},
		type: "button",
		disabled: d,
		"aria-expanded": g,
		"aria-controls": h.getRegionId(m),
		id: h.getControlId(m),
		onKeyDown: oe({
			siblingSelector: "[data-accordion-control]",
			parentSelector: "[data-accordion]",
			activateOnFocus: !1,
			loop: h.loop,
			orientation: "vertical",
			onKeyDown: l
		}),
		...p,
		children: [
			/* @__PURE__ */ T(Y, {
				component: "span",
				mod: {
					rotate: !h.disableChevronRotation && g,
					position: h.chevronPosition
				},
				...h.getStyles("chevron", {
					classNames: t,
					styles: i
				}),
				children: o || h.chevron
			}),
			/* @__PURE__ */ T("span", {
				...h.getStyles("label", {
					classNames: t,
					styles: i
				}),
				children: u
			}),
			s && /* @__PURE__ */ T(Y, {
				component: "span",
				mod: { "chevron-position": h.chevronPosition },
				...h.getStyles("icon", {
					classNames: t,
					styles: i
				}),
				children: s
			})
		]
	});
	return _ ? /* @__PURE__ */ T(v, {
		...h.getStyles("itemTitle", {
			classNames: t,
			styles: i
		}),
		children: y
	}) : y;
});
Es.displayName = "@mantine/core/AccordionControl", Es.classes = Ts;
// node_modules/@mantine/core/esm/components/Accordion/AccordionItem/AccordionItem.mjs
var Ds = J((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, value: o, mod: s, ...c } = K("AccordionItem", null, e), l = xs();
	return /* @__PURE__ */ T(Cs, {
		value: { value: o },
		children: /* @__PURE__ */ T(Y, {
			mod: [{ active: l.isItemActive(o) }, s],
			...l.getStyles("item", {
				className: n,
				classNames: t,
				styles: i,
				style: r,
				variant: l.variant
			}),
			...c
		})
	});
});
Ds.displayName = "@mantine/core/AccordionItem", Ds.classes = Ts;
// node_modules/@mantine/core/esm/components/Accordion/AccordionPanel/AccordionPanel.mjs
var Os = J((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, children: o, keepMounted: s, keepMountedMode: c, ...l } = K("AccordionPanel", null, e), { value: u } = ws(), d = xs();
	return /* @__PURE__ */ T(Ir, {
		...d.getStyles("panel", {
			className: n,
			classNames: t,
			style: r,
			styles: i
		}),
		expanded: d.isItemActive(u),
		transitionDuration: d.transitionDuration ?? 200,
		role: "region",
		id: d.getRegionId(u),
		"aria-labelledby": d.getControlId(u),
		keepMounted: s ?? d.keepMounted,
		keepMountedMode: c ?? d.keepMountedMode,
		...l,
		children: /* @__PURE__ */ T("div", {
			...d.getStyles("content", {
				classNames: t,
				styles: i
			}),
			children: o
		})
	});
});
Os.displayName = "@mantine/core/AccordionPanel", Os.classes = Ts;
// node_modules/@mantine/core/esm/components/Accordion/Accordion.mjs
var ks = {
	multiple: !1,
	loop: !0,
	disableChevronRotation: !1,
	disableCollapse: !1,
	chevronPosition: "right",
	variant: "default",
	chevronSize: "auto",
	chevronIconSize: 16,
	keepMountedMode: "activity"
}, As = G((e, { transitionDuration: t, chevronSize: n, radius: r }) => ({ root: {
	"--accordion-transition-duration": t === void 0 ? void 0 : `${t}ms`,
	"--accordion-chevron-size": n === void 0 ? void 0 : P(n),
	"--accordion-radius": r === void 0 ? void 0 : H(r)
} })), js = Tr((e) => {
	let t = K("Accordion", ks, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, children: c, multiple: l, value: u, defaultValue: d, onChange: f, id: p, loop: m, transitionDuration: h, disableChevronRotation: g, disableCollapse: _, chevronPosition: v, chevronSize: y, order: b, chevron: x, variant: S, radius: C, chevronIconSize: w, attributes: E, keepMounted: D, keepMountedMode: O, ...k } = t, ee = Je(p), [A, j] = $e({
		value: u,
		defaultValue: d,
		finalValue: l ? [] : null,
		onChange: f
	}), M = (e) => Array.isArray(A) ? A.includes(e) : e === A, N = (e) => {
		if (!Array.isArray(A) && _ && e === A) return;
		let t = Array.isArray(A) ? A.includes(e) ? A.filter((t) => t !== e) : [...A, e] : e === A ? null : e;
		j(t);
	}, P = q({
		name: "Accordion",
		classes: Ts,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: E,
		vars: s,
		varsResolver: As
	});
	return /* @__PURE__ */ T(bs, {
		value: {
			isItemActive: M,
			onChange: N,
			getControlId: L(`${ee}-control`, "Accordion.Item component was rendered with invalid value or without value"),
			getRegionId: L(`${ee}-panel`, "Accordion.Item component was rendered with invalid value or without value"),
			chevron: x === null ? null : x || /* @__PURE__ */ T(Ss, { size: w }),
			transitionDuration: h,
			disableChevronRotation: g,
			chevronPosition: v,
			order: b,
			loop: m,
			getStyles: P,
			variant: S,
			unstyled: o,
			keepMounted: D,
			keepMountedMode: O
		},
		children: /* @__PURE__ */ T(Y, {
			...P("root"),
			id: ee,
			...k,
			variant: S,
			"data-accordion": !0,
			children: c
		})
	});
});
js.classes = Ts, js.varsResolver = As, js.displayName = "@mantine/core/Accordion", js.Item = Ds, js.Panel = Os, js.Control = Es, js.Chevron = Ss;
// node_modules/@mantine/core/esm/components/Alert/Alert.module.mjs
var Ms = {
	root: "m_66836ed3",
	wrapper: "m_a5d60502",
	body: "m_667c2793",
	title: "m_6a03f287",
	label: "m_698f4f23",
	icon: "m_667f2a6a",
	message: "m_7fa78076",
	closeButton: "m_87f54839"
}, Ns = G((e, { radius: t, color: n, variant: r, autoContrast: i }) => {
	let a = e.variantColorResolver({
		color: n || e.primaryColor,
		theme: e,
		variant: r || "light",
		autoContrast: i
	});
	return { root: {
		"--alert-radius": t === void 0 ? void 0 : H(t),
		"--alert-bg": n || r ? a.background : void 0,
		"--alert-color": a.color,
		"--alert-bd": n || r ? a.border : void 0
	} };
}), Ps = J((e) => {
	let t = K("Alert", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, radius: c, color: l, title: u, children: d, id: f, icon: p, withCloseButton: m, onClose: h, closeButtonLabel: g, variant: _, autoContrast: v, role: y, attributes: b, ...x } = t, S = q({
		name: "Alert",
		classes: Ms,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: b,
		vars: s,
		varsResolver: Ns
	}), C = Je(f), w = u && `${C}-title` || void 0, D = `${C}-body`;
	return /* @__PURE__ */ T(Y, {
		id: C,
		...S("root", { variant: _ }),
		variant: _,
		...x,
		role: y || "alert",
		"aria-describedby": d ? D : void 0,
		"aria-labelledby": u ? w : void 0,
		children: /* @__PURE__ */ E("div", {
			...S("wrapper"),
			children: [
				p && /* @__PURE__ */ T("div", {
					...S("icon"),
					children: p
				}),
				/* @__PURE__ */ E("div", {
					...S("body"),
					children: [u && /* @__PURE__ */ T("div", {
						...S("title"),
						"data-with-close-button": m || void 0,
						children: /* @__PURE__ */ T("span", {
							id: w,
							...S("label"),
							children: u
						})
					}), d && /* @__PURE__ */ T("div", {
						id: D,
						...S("message"),
						"data-variant": _,
						children: d
					})]
				}),
				m && /* @__PURE__ */ T(_a, {
					...S("closeButton"),
					onClick: h,
					variant: "transparent",
					size: 16,
					iconSize: 16,
					"aria-label": g,
					unstyled: o
				})
			]
		})
	});
});
Ps.classes = Ms, Ps.varsResolver = Ns, Ps.displayName = "@mantine/core/Alert";
// node_modules/@mantine/core/esm/components/Text/Text.module.mjs
var Fs = { root: "m_b6d8b162" };
// node_modules/@mantine/core/esm/components/Text/Text.mjs
function Is(e) {
	if (e === "start") return "start";
	if (e === "end" || e) return "end";
}
var Ls = { inherit: !1 }, Rs = G((e, { variant: t, lineClamp: n, gradient: r, size: i, textWrap: a }) => ({ root: {
	"--text-fz": U(i),
	"--text-lh": ue(i),
	"--text-gradient": t === "gradient" ? Mt(r, e) : void 0,
	"--text-line-clamp": typeof n == "number" ? n.toString() : void 0,
	"--text-text-wrap": a
} })), Z = Er((e) => {
	let t = K("Text", Ls, e), { lineClamp: n, truncate: r, inline: i, inherit: a, gradient: o, span: s, textWrap: c, __staticSelector: l, vars: u, className: d, style: f, classNames: p, styles: m, unstyled: h, variant: g, mod: _, size: v, attributes: y, ...b } = t, x = q({
		name: ["Text", l],
		props: t,
		classes: Fs,
		className: d,
		style: f,
		classNames: p,
		styles: m,
		unstyled: h,
		attributes: y,
		vars: u,
		varsResolver: Rs
	});
	return /* @__PURE__ */ T(Y, {
		...x("root", { focusable: !0 }),
		component: s ? "span" : "p",
		variant: g,
		mod: [{
			truncate: Is(r),
			lineClamp: typeof n == "number",
			inline: i,
			inherit: a
		}, _],
		size: v,
		...b
	});
});
Z.classes = Fs, Z.varsResolver = Rs, Z.displayName = "@mantine/core/Text";
// node_modules/@mantine/core/esm/components/Combobox/get-parsed-combobox-data/get-parsed-combobox-data.mjs
function zs(e) {
	return typeof e == "string" ? {
		value: e,
		label: e
	} : typeof e == "object" && "value" in e && !("label" in e) ? {
		value: e.value,
		label: `${e.value}`,
		disabled: e.disabled
	} : typeof e == "object" && "group" in e ? {
		group: e.group,
		items: e.items.map((e) => zs(e))
	} : typeof e == "number" || typeof e == "bigint" || typeof e == "boolean" ? {
		value: e,
		label: `${e}`
	} : e;
}
function Bs(e) {
	return e ? e.map((e) => zs(e)) : [];
}
// node_modules/@mantine/core/esm/components/Combobox/Combobox.module.mjs
var Vs = {
	dropdown: "m_88b62a41",
	search: "m_985517d8",
	options: "m_b2821a6e",
	option: "m_92253aa5",
	empty: "m_2530cd1d",
	header: "m_858f94bd",
	footer: "m_82b967cb",
	group: "m_254f3e4f",
	groupLabel: "m_2bb2e9e5",
	chevron: "m_2943220b",
	optionsDropdownOption: "m_390b5f4",
	optionsDropdownCheckIcon: "m_8ee53fc2",
	optionsDropdownCheckPlaceholder: "m_a530ee0a"
}, Hs = { error: null }, Us = G((e, { size: t, color: n }) => ({ chevron: {
	"--combobox-chevron-size": B(t, "combobox-chevron-size"),
	"--combobox-chevron-color": n ? kt(n, e) : void 0
} })), Ws = J((e) => {
	let t = K("ComboboxChevron", Hs, e), { size: n, error: r, style: i, className: a, classNames: o, styles: s, unstyled: c, vars: l, attributes: u, mod: d, ...f } = t, p = q({
		name: "ComboboxChevron",
		classes: Vs,
		props: t,
		style: i,
		className: a,
		classNames: o,
		styles: s,
		unstyled: c,
		vars: l,
		varsResolver: Us,
		attributes: u,
		rootSelector: "chevron"
	});
	return /* @__PURE__ */ T(Y, {
		component: "svg",
		...f,
		...p("chevron"),
		size: n,
		viewBox: "0 0 15 15",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		mod: [
			"combobox-chevron",
			{ error: r },
			d
		],
		children: /* @__PURE__ */ T("path", {
			d: "M4.93179 5.43179C4.75605 5.60753 4.75605 5.89245 4.93179 6.06819C5.10753 6.24392 5.39245 6.24392 5.56819 6.06819L7.49999 4.13638L9.43179 6.06819C9.60753 6.24392 9.89245 6.24392 10.0682 6.06819C10.2439 5.89245 10.2439 5.60753 10.0682 5.43179L7.81819 3.18179C7.73379 3.0974 7.61933 3.04999 7.49999 3.04999C7.38064 3.04999 7.26618 3.0974 7.18179 3.18179L4.93179 5.43179ZM10.0682 9.56819C10.2439 9.39245 10.2439 9.10753 10.0682 8.93179C9.89245 8.75606 9.60753 8.75606 9.43179 8.93179L7.49999 10.8636L5.56819 8.93179C5.39245 8.75606 5.10753 8.75606 4.93179 8.93179C4.75605 9.10753 4.75605 9.39245 4.93179 9.56819L7.18179 11.8182C7.35753 11.9939 7.64245 11.9939 7.81819 11.8182L10.0682 9.56819Z",
			fill: "currentColor",
			fillRule: "evenodd",
			clipRule: "evenodd"
		})
	});
});
Ws.classes = Vs, Ws.varsResolver = Us, Ws.displayName = "@mantine/core/ComboboxChevron";
// node_modules/@mantine/core/esm/utils/InputsGroupFieldset/InputsGroupFieldset.mjs
function Gs({ children: e, role: t }) {
	let n = u(Qo);
	return n ? /* @__PURE__ */ T("div", {
		role: t,
		"aria-labelledby": n.labelId,
		"aria-describedby": n.describedBy,
		children: e
	}) : /* @__PURE__ */ T(w, { children: e });
}
// node_modules/@mantine/core/esm/components/Checkbox/CheckboxGroup/CheckboxGroup.mjs
var Ks = s(null), qs = { hiddenInputValuesSeparator: "," }, Js = Tr(((e) => {
	let { value: t, defaultValue: n, onChange: r, size: i, wrapperProps: a, children: o, readOnly: s, name: c, hiddenInputValuesSeparator: l, hiddenInputProps: u, maxSelectedValues: d, disabled: f, ...p } = K("CheckboxGroup", qs, e), [m, h] = $e({
		value: t,
		defaultValue: n,
		finalValue: [],
		onChange: r
	}), g = (e) => {
		let t = typeof e == "string" ? e : e.currentTarget.value;
		if (s) return;
		let n = m.includes(t);
		!n && d && m.length >= d || h(n ? m.filter((e) => e !== t) : [...m, t]);
	}, _ = (e) => {
		if (f) return !0;
		if (!d) return !1;
		let t = m.includes(e), n = m.length >= d;
		return !t && n;
	}, v = m.join(l);
	return /* @__PURE__ */ T(Ks, {
		value: {
			value: m,
			onChange: g,
			size: i,
			isDisabled: _
		},
		children: /* @__PURE__ */ E(gs.Wrapper, {
			size: i,
			...a,
			...p,
			labelElement: "div",
			__staticSelector: "CheckboxGroup",
			children: [/* @__PURE__ */ T(Gs, {
				role: "group",
				children: o
			}), /* @__PURE__ */ T("input", {
				type: "hidden",
				name: c,
				value: v,
				...u
			})]
		})
	});
}));
Js.classes = gs.Wrapper.classes, Js.displayName = "@mantine/core/CheckboxGroup";
// node_modules/@mantine/core/esm/components/Checkbox/CheckboxCard/CheckboxCard.module.mjs
var Ys = { card: "m_26775b0a" }, Xs = s(null), Zs = { withBorder: !0 }, Qs = G((e, { radius: t }) => ({ card: { "--card-radius": H(t) } })), $s = J((e) => {
	let t = K("CheckboxCard", Zs, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, checked: c, mod: l, withBorder: d, value: f, onClick: p, defaultChecked: m, onChange: h, indeterminate: g, attributes: _, ...v } = t, y = q({
		name: "CheckboxCard",
		classes: Ys,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: _,
		vars: s,
		varsResolver: Qs,
		rootSelector: "card"
	}), b = u(Ks), [x, S] = $e({
		value: typeof c == "boolean" ? c : b ? b.value.includes(f || "") : void 0,
		defaultValue: m,
		finalValue: !1,
		onChange: h
	});
	return /* @__PURE__ */ T(Xs, {
		value: {
			checked: x,
			indeterminate: g
		},
		children: /* @__PURE__ */ T(Di, {
			mod: [{
				"with-border": d,
				checked: x,
				indeterminate: g
			}, l],
			...y("card"),
			...v,
			role: "checkbox",
			"aria-checked": g ? "mixed" : x,
			onClick: (e) => {
				p?.(e), b?.onChange(f || ""), S(!x);
			}
		})
	});
});
$s.displayName = "@mantine/core/CheckboxCard", $s.classes = Ys, $s.varsResolver = Qs;
// node_modules/@mantine/core/esm/components/Checkbox/CheckIcon.mjs
function ec({ size: e, style: t, ...n }) {
	let r = e === void 0 ? t : {
		width: P(e),
		height: P(e),
		...t
	};
	return /* @__PURE__ */ T("svg", {
		viewBox: "0 0 10 7",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		style: r,
		"aria-hidden": !0,
		...n,
		children: /* @__PURE__ */ T("path", {
			d: "M4 4.586L1.707 2.293A1 1 0 1 0 .293 3.707l3 3a.997.997 0 0 0 1.414 0l5-5A1 1 0 1 0 8.293.293L4 4.586z",
			fill: "currentColor",
			fillRule: "evenodd",
			clipRule: "evenodd"
		})
	});
}
function tc({ indeterminate: e, ...t }) {
	return e ? /* @__PURE__ */ T("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		fill: "none",
		viewBox: "0 0 32 6",
		"aria-hidden": !0,
		...t,
		children: /* @__PURE__ */ T("rect", {
			width: "32",
			height: "6",
			fill: "currentColor",
			rx: "3"
		})
	}) : /* @__PURE__ */ T(ec, { ...t });
}
// node_modules/@mantine/core/esm/components/Checkbox/CheckboxIndicator/CheckboxIndicator.module.mjs
var nc = {
	indicator: "m_5e5256ee",
	icon: "m_1b1c543a",
	"indicator--light": "m_193e54c8",
	"indicator--outline": "m_76e20374"
}, rc = {
	icon: tc,
	variant: "filled",
	radius: "sm"
}, ic = G((e, { radius: t, color: n, size: r, iconColor: i, variant: a, autoContrast: o }) => {
	let s = Ot({
		color: n || e.primaryColor,
		theme: e
	}), c = s.isThemeColor && s.shade === void 0 ? `var(--mantine-color-${s.color}-outline)` : s.color, l = a === "light" ? e.variantColorResolver({
		color: n || e.primaryColor,
		theme: e,
		variant: "light",
		autoContrast: o
	}) : void 0, u = a === "outline" ? c : l ? l.color : kt(n, e);
	return { indicator: {
		"--checkbox-size": B(r, "checkbox-size"),
		"--checkbox-radius": t === void 0 ? void 0 : H(t),
		"--checkbox-color": u,
		"--checkbox-bg": l?.background,
		"--checkbox-icon-color": i ? kt(i, e) : l ? l.color : zt(o, e) ? It({
			color: n,
			theme: e,
			autoContrast: o
		}) : void 0
	} };
}), ac = J((e) => {
	let t = K("CheckboxIndicator", rc, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, icon: c, indeterminate: l, radius: d, color: f, iconColor: p, autoContrast: m, checked: h, mod: g, variant: _, disabled: v, attributes: y, ...b } = t, x = q({
		name: "CheckboxIndicator",
		classes: nc,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: y,
		vars: s,
		varsResolver: ic,
		rootSelector: "indicator"
	}), S = u(Xs), C = typeof l == "boolean" ? l : S?.indeterminate, w = typeof h == "boolean" || typeof l == "boolean" ? h || l : S?.checked || S?.indeterminate || !1;
	return /* @__PURE__ */ T(Y, {
		...x("indicator", { variant: _ }),
		variant: _,
		mod: [{
			checked: w,
			disabled: v
		}, g],
		...b,
		children: /* @__PURE__ */ T(c, {
			indeterminate: C,
			...x("icon")
		})
	});
});
ac.displayName = "@mantine/core/CheckboxIndicator", ac.classes = nc, ac.varsResolver = ic;
// node_modules/@mantine/core/esm/utils/InlineInput/InlineInput.module.mjs
var oc = {
	root: "m_5f75b09e",
	body: "m_5f6e695e",
	labelWrapper: "m_d3ea56bb",
	label: "m_8ee546b8",
	description: "m_328f68c0",
	error: "m_8e8a99cc"
}, sc = oc;
function cc({ __staticSelector: e, __stylesApiProps: t, className: n, classNames: r, styles: i, unstyled: a, children: o, label: s, description: c, id: l, disabled: u, error: d, size: f, labelPosition: p = "left", bodyElement: m = "div", labelElement: h = "label", variant: g, style: _, vars: v, mod: y, attributes: b, ...x }) {
	let S = q({
		name: e,
		props: t,
		className: n,
		style: _,
		classes: oc,
		classNames: r,
		styles: i,
		unstyled: a,
		attributes: b
	}), C = c ? `${l}-description` : void 0, w = d && typeof d != "boolean" ? `${l}-error` : void 0;
	return /* @__PURE__ */ T(Y, {
		...S("root"),
		__vars: {
			"--label-fz": U(f),
			"--label-lh": B(f, "label-lh")
		},
		mod: [{ "label-position": p }, y],
		variant: g,
		size: f,
		...x,
		children: /* @__PURE__ */ E(Y, {
			component: m,
			htmlFor: m === "label" ? l : void 0,
			...S("body"),
			children: [o, /* @__PURE__ */ E("div", {
				...S("labelWrapper"),
				"data-disabled": u || void 0,
				children: [
					s && /* @__PURE__ */ T(Y, {
						component: h,
						htmlFor: h === "label" ? l : void 0,
						...S("label"),
						"data-disabled": u || void 0,
						children: s
					}),
					c && /* @__PURE__ */ T(gs.Description, {
						id: C,
						size: f,
						__inheritStyles: !1,
						...S("description"),
						children: c
					}),
					d && typeof d != "boolean" && /* @__PURE__ */ T(gs.Error, {
						id: w,
						size: f,
						__inheritStyles: !1,
						...S("error"),
						children: d
					})
				]
			})]
		})
	});
}
cc.displayName = "@mantine/core/InlineInput";
// node_modules/@mantine/core/esm/components/Checkbox/Checkbox.module.mjs
var lc = {
	root: "m_bf2d988c",
	inner: "m_26062bec",
	input: "m_26063560",
	icon: "m_bf295423",
	"input--light": "m_595ab216",
	"input--outline": "m_215c4542"
}, uc = {
	labelPosition: "right",
	icon: tc,
	withErrorStyles: !0,
	variant: "filled",
	radius: "sm"
}, dc = G((e, { radius: t, color: n, size: r, iconColor: i, variant: a, autoContrast: o }) => {
	let s = Ot({
		color: n || e.primaryColor,
		theme: e
	}), c = s.isThemeColor && s.shade === void 0 ? `var(--mantine-color-${s.color}-outline)` : s.color, l = a === "light" ? e.variantColorResolver({
		color: n || e.primaryColor,
		theme: e,
		variant: "light",
		autoContrast: o
	}) : void 0, u = a === "outline" ? c : l ? l.color : kt(n, e);
	return { root: {
		"--checkbox-size": B(r, "checkbox-size"),
		"--checkbox-radius": t === void 0 ? void 0 : H(t),
		"--checkbox-color": u,
		"--checkbox-bg": l?.background,
		"--checkbox-icon-color": i ? kt(i, e) : l ? l.color : zt(o, e) ? It({
			color: n,
			theme: e,
			autoContrast: o
		}) : void 0
	} };
}), fc = J((e) => {
	let t = K("Checkbox", uc, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, color: c, label: l, id: d, size: f, radius: m, wrapperProps: h, checked: g, labelPosition: _, description: y, error: b, disabled: x, variant: S, indeterminate: C, icon: w, rootRef: D, iconColor: O, onChange: k, autoContrast: ee, mod: A, attributes: j, readOnly: M, onClick: N, withErrorStyles: P, ref: te, ...ne } = t, F = v(null), I = u(Ks), re = f || I?.size, L = q({
		name: "Checkbox",
		props: t,
		classes: lc,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: j,
		vars: s,
		varsResolver: dc
	}), { styleProps: R, rest: z } = Zn(ne), ie = Je(d), ae = [
		y ? `${ie}-description` : void 0,
		b && typeof b != "boolean" ? `${ie}-error` : void 0,
		z["aria-describedby"]
	].filter(Boolean).join(" ") || void 0, oe = {
		checked: I?.value.includes(z.value) ?? g,
		onChange: (e) => {
			M || (I?.onChange(e), k?.(e));
		}
	}, se = I?.isDisabled?.(z.value) ?? !1, ce = x || se;
	return p(() => {
		F.current && (F.current.indeterminate = C || !1, C ? F.current.setAttribute("data-indeterminate", "true") : F.current.removeAttribute("data-indeterminate"));
	}, [C]), /* @__PURE__ */ T(cc, {
		...L("root"),
		__staticSelector: "Checkbox",
		__stylesApiProps: t,
		id: ie,
		size: re,
		labelPosition: _,
		label: l,
		description: y,
		error: b,
		disabled: ce,
		classNames: n,
		styles: a,
		unstyled: o,
		"data-checked": oe.checked || g || void 0,
		variant: S,
		ref: D,
		mod: A,
		attributes: j,
		inert: z.inert,
		...R,
		...h,
		children: /* @__PURE__ */ E(Y, {
			...L("inner"),
			mod: { labelPosition: _ },
			children: [/* @__PURE__ */ T(Y, {
				component: "input",
				id: ie,
				ref: Qe(F, te),
				mod: {
					error: !!b,
					"with-error-styles": P
				},
				...L("input", {
					focusable: !0,
					variant: S
				}),
				...z,
				...oe,
				"aria-describedby": ae,
				disabled: ce,
				inert: z.inert,
				type: "checkbox",
				readOnly: M,
				onClick: (e) => {
					M && oe.checked === void 0 && e.preventDefault(), N?.(e);
				}
			}), /* @__PURE__ */ T(w, {
				indeterminate: C,
				...L("icon")
			})]
		})
	});
});
fc.classes = {
	...lc,
	...sc
}, fc.varsResolver = dc, fc.displayName = "@mantine/core/Checkbox", fc.Group = Js, fc.Indicator = ac, fc.Card = $s;
// node_modules/@mantine/core/esm/components/Badge/Badge.module.mjs
var pc = {
	root: "m_347db0ec",
	"root--dot": "m_fbd81e3d",
	label: "m_5add502a",
	section: "m_91fdda9b"
}, mc = G((e, { radius: t, color: n, gradient: r, variant: i, size: a, autoContrast: o, circle: s }) => {
	let c = e.variantColorResolver({
		color: n || e.primaryColor,
		theme: e,
		gradient: r,
		variant: i || "filled",
		autoContrast: o
	});
	return { root: {
		"--badge-height": B(a, "badge-height"),
		"--badge-padding-x": B(a, "badge-padding-x"),
		"--badge-fz": B(a, "badge-fz"),
		"--badge-radius": s || t === void 0 ? void 0 : H(t),
		"--badge-bg": n || i ? c.background : void 0,
		"--badge-color": n || i ? c.color : void 0,
		"--badge-bd": n || i ? c.border : void 0,
		"--badge-dot-color": i === "dot" ? kt(n, e) : void 0
	} };
}), hc = Er((e) => {
	let t = K("Badge", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, radius: c, color: l, gradient: u, leftSection: d, rightSection: f, children: p, variant: m, fullWidth: h, autoContrast: g, circle: _, mod: v, attributes: y, ...b } = t, x = q({
		name: "Badge",
		props: t,
		classes: pc,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: y,
		vars: s,
		varsResolver: mc
	});
	return /* @__PURE__ */ E(Y, {
		variant: m,
		mod: [{
			block: h,
			circle: _,
			"with-right-section": !!f,
			"with-left-section": !!d
		}, v],
		...x("root", { variant: m }),
		...b,
		children: [
			d && /* @__PURE__ */ T("span", {
				...x("section"),
				"data-position": "left",
				children: d
			}),
			/* @__PURE__ */ T("span", {
				...x("label"),
				children: p
			}),
			f && /* @__PURE__ */ T("span", {
				...x("section"),
				"data-position": "right",
				children: f
			})
		]
	});
});
hc.classes = pc, hc.varsResolver = mc, hc.displayName = "@mantine/core/Badge";
// node_modules/@mantine/core/esm/components/Button/Button.module.mjs
var gc = {
	root: "m_77c9d27d",
	inner: "m_80f1301b",
	label: "m_811560b9",
	section: "m_a74036a",
	loader: "m_a25b86ee",
	group: "m_80d6d844",
	groupSection: "m_70be2a01"
}, _c = { orientation: "horizontal" }, vc = G((e, { borderWidth: t }) => ({ group: { "--button-border-width": P(t) } })), yc = J((e) => {
	let t = K("ButtonGroup", _c, e), { className: n, style: r, classNames: i, styles: a, unstyled: o, orientation: s, vars: c, borderWidth: l, mod: u, attributes: d, ...f } = K("ButtonGroup", _c, e), p = q({
		name: "ButtonGroup",
		props: t,
		classes: gc,
		className: n,
		style: r,
		classNames: i,
		styles: a,
		unstyled: o,
		attributes: d,
		vars: c,
		varsResolver: vc,
		rootSelector: "group"
	});
	return /* @__PURE__ */ T(Y, {
		...p("group"),
		mod: [{ orientation: s }, u],
		role: "group",
		...f
	});
});
yc.classes = gc, yc.varsResolver = vc, yc.displayName = "@mantine/core/ButtonGroup";
// node_modules/@mantine/core/esm/components/Button/ButtonGroupSection/ButtonGroupSection.mjs
var bc = G((e, { radius: t, color: n, gradient: r, variant: i, autoContrast: a, size: o }) => {
	let s = e.variantColorResolver({
		color: n || e.primaryColor,
		theme: e,
		gradient: r,
		variant: i || "filled",
		autoContrast: a
	});
	return { groupSection: {
		"--section-height": B(o, "section-height"),
		"--section-padding-x": B(o, "section-padding-x"),
		"--section-fz": o?.includes("compact") ? U(o.replace("compact-", "")) : U(o),
		"--section-radius": t === void 0 ? void 0 : H(t),
		"--section-bg": n || i ? s.background : void 0,
		"--section-color": s.color,
		"--section-bd": n || i ? s.border : void 0
	} };
}), xc = J((e) => {
	let t = K("ButtonGroupSection", null, e), { className: n, style: r, classNames: i, styles: a, unstyled: o, vars: s, gradient: c, radius: l, autoContrast: u, attributes: d, ...f } = t, p = q({
		name: "ButtonGroupSection",
		props: t,
		classes: gc,
		className: n,
		style: r,
		classNames: i,
		styles: a,
		unstyled: o,
		attributes: d,
		vars: s,
		varsResolver: bc,
		rootSelector: "groupSection"
	});
	return /* @__PURE__ */ T(Y, {
		...p("groupSection"),
		...f
	});
});
xc.classes = gc, xc.varsResolver = bc, xc.displayName = "@mantine/core/ButtonGroupSection";
// node_modules/@mantine/core/esm/components/Button/Button.mjs
var Sc = {
	in: {
		opacity: 1,
		transform: `translate(-50%, calc(-50% + ${P(1)}))`
	},
	out: {
		opacity: 0,
		transform: "translate(-50%, -200%)"
	},
	common: { transformOrigin: "center" },
	transitionProperty: "transform, opacity"
}, Cc = G((e, { radius: t, color: n, gradient: r, variant: i, size: a, justify: o, autoContrast: s }) => {
	let c = e.variantColorResolver({
		color: n || e.primaryColor,
		theme: e,
		gradient: r,
		variant: i || "filled",
		autoContrast: s
	});
	return { root: {
		"--button-justify": o,
		"--button-height": B(a, "button-height"),
		"--button-padding-x": B(a, "button-padding-x"),
		"--button-fz": a?.includes("compact") ? U(a.replace("compact-", "")) : U(a),
		"--button-radius": t === void 0 ? void 0 : H(t),
		"--button-bg": n || i ? c.background : void 0,
		"--button-hover": n || i ? c.hover : void 0,
		"--button-color": c.color,
		"--button-bd": n || i ? c.border : void 0,
		"--button-hover-color": n || i ? c.hoverColor : void 0
	} };
}), wc = Er((e) => {
	let t = K("Button", null, e), { style: n, vars: r, className: i, color: a, disabled: o, children: s, leftSection: c, rightSection: l, fullWidth: u, variant: d, radius: f, loading: p, loaderProps: m, gradient: h, classNames: g, styles: _, unstyled: v, "data-disabled": y, autoContrast: b, mod: x, attributes: S, ...C } = t, w = q({
		name: "Button",
		props: t,
		classes: gc,
		className: i,
		style: n,
		classNames: g,
		styles: _,
		unstyled: v,
		attributes: S,
		vars: r,
		varsResolver: Cc
	}), D = !!c, O = !!l;
	return /* @__PURE__ */ E(Di, {
		...w("root", { active: !o && !p && !y }),
		unstyled: v,
		variant: d,
		disabled: o || p,
		mod: [{
			disabled: o || y,
			loading: p,
			block: u,
			"with-left-section": D,
			"with-right-section": O
		}, x],
		...C,
		children: [typeof p == "boolean" && /* @__PURE__ */ T(Ji, {
			mounted: p,
			transition: Sc,
			duration: 150,
			children: (e) => /* @__PURE__ */ T(Y, {
				component: "span",
				...w("loader", { style: e }),
				"aria-hidden": !0,
				children: /* @__PURE__ */ T(ia, {
					color: "var(--button-color)",
					size: "calc(var(--button-height) / 1.8)",
					...m
				})
			})
		}), /* @__PURE__ */ E("span", {
			...w("inner"),
			children: [
				c && /* @__PURE__ */ T(Y, {
					component: "span",
					...w("section"),
					mod: { position: "left" },
					children: c
				}),
				/* @__PURE__ */ T(Y, {
					component: "span",
					mod: { loading: p },
					...w("label"),
					children: s
				}),
				l && /* @__PURE__ */ T(Y, {
					component: "span",
					...w("section"),
					mod: { position: "right" },
					children: l
				})
			]
		})]
	});
});
wc.classes = gc, wc.varsResolver = Cc, wc.displayName = "@mantine/core/Button", wc.Group = yc, wc.GroupSection = xc;
// node_modules/@mantine/core/esm/components/Code/Code.module.mjs
var Tc = { root: "m_b183c0a2" }, Ec = G((e, { color: t }) => ({ root: { "--code-bg": t ? kt(t, e) : void 0 } })), Dc = J((e) => {
	let t = K("Code", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, color: c, block: l, mod: u, attributes: d, ...f } = t, p = q({
		name: "Code",
		props: t,
		classes: Tc,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: d,
		vars: s,
		varsResolver: Ec
	});
	return /* @__PURE__ */ T(Y, {
		component: l ? "pre" : "code",
		mod: [{ block: l }, u],
		...p("root"),
		...f,
		dir: "ltr"
	});
});
Dc.classes = Tc, Dc.varsResolver = Ec, Dc.displayName = "@mantine/core/Code";
// node_modules/@mantine/core/esm/components/Fieldset/Fieldset.module.mjs
var Oc = {
	root: "m_e9408a47",
	"root--default": "m_84c9523a",
	"root--filled": "m_ef274e49",
	"root--unstyled": "m_eda993d3",
	legend: "m_90794832",
	"legend--unstyled": "m_74ca27fe"
}, kc = { variant: "default" }, Ac = G((e, { radius: t }) => ({ root: { "--fieldset-radius": t === void 0 ? void 0 : H(t) } })), jc = J((e) => {
	let t = K("Fieldset", kc, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, legend: c, variant: l, children: u, attributes: d, ...f } = t, p = q({
		name: "Fieldset",
		classes: Oc,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: d,
		vars: s,
		varsResolver: Ac
	});
	return /* @__PURE__ */ E(Y, {
		component: "fieldset",
		variant: l,
		...p("root", { variant: l }),
		...f,
		children: [c && /* @__PURE__ */ T("legend", {
			...p("legend", { variant: l }),
			children: c
		}), u]
	});
});
jc.classes = Oc, jc.varsResolver = Ac, jc.displayName = "@mantine/core/Fieldset";
// node_modules/@mantine/core/esm/components/FileButton/FileButton.mjs
var Mc = Tr((e) => {
	let { onChange: t, children: n, multiple: r, accept: i, name: a, form: o, resetRef: s, disabled: c, capture: l, inputProps: u, ref: d, ...f } = K("FileButton", null, e), p = v(null), m = () => {
		!c && p.current?.click();
	};
	return Xe(s, () => {
		p.current && (p.current.value = "");
	}), /* @__PURE__ */ E(w, { children: [/* @__PURE__ */ T("input", {
		style: { display: "none" },
		type: "file",
		accept: i,
		multiple: r,
		onChange: (e) => {
			if (e.currentTarget.files === null) return t(r ? [] : null);
			t(r ? Array.from(e.currentTarget.files) : e.currentTarget.files[0] || null);
		},
		ref: Qe(d, p),
		name: a,
		form: o,
		capture: l,
		...u
	}), n({
		onClick: m,
		...f
	})] });
});
Mc.displayName = "@mantine/core/FileButton";
// node_modules/@mantine/core/esm/components/Textarea/Autosize.mjs
var Nc = [
	"borderBottomWidth",
	"borderLeftWidth",
	"borderRightWidth",
	"borderTopWidth",
	"boxSizing",
	"fontFamily",
	"fontSize",
	"fontStyle",
	"fontWeight",
	"letterSpacing",
	"lineHeight",
	"paddingBottom",
	"paddingLeft",
	"paddingRight",
	"paddingTop",
	"tabSize",
	"textIndent",
	"textRendering",
	"textTransform",
	"width",
	"wordBreak",
	"wordSpacing",
	"scrollbarGutter"
], Pc = {
	"min-height": "0",
	"max-height": "none",
	height: "0",
	visibility: "hidden",
	overflow: "hidden",
	position: "absolute",
	"z-index": "-1000",
	top: "0",
	right: "0",
	display: "block"
};
function Fc(e) {
	Object.keys(Pc).forEach((t) => {
		e.style.setProperty(t, Pc[t], "important");
	});
}
function Ic(e) {
	let t = window.getComputedStyle(e);
	if (t === null) return null;
	let n = {};
	for (let e of Nc) n[e] = t[e];
	return n.boxSizing === "" ? null : {
		sizingStyle: n,
		paddingSize: parseFloat(n.paddingBottom) + parseFloat(n.paddingTop),
		borderSize: parseFloat(n.borderBottomWidth) + parseFloat(n.borderTopWidth)
	};
}
var Lc = null;
function Rc(e, t, n = 1, r = Infinity) {
	Lc || (Lc = document.createElement("textarea"), Lc.setAttribute("tabindex", "-1"), Lc.setAttribute("aria-hidden", "true"), Lc.setAttribute("aria-label", "autosize measurement"), Fc(Lc)), Lc.parentNode === null && document.body.appendChild(Lc);
	let { paddingSize: i, borderSize: a, sizingStyle: o } = e, { boxSizing: s } = o;
	Object.keys(o).forEach((e) => {
		Lc.style[e] = o[e];
	}), Fc(Lc), Lc.value = t;
	let c = s === "border-box" ? Lc.scrollHeight + a : Lc.scrollHeight - i;
	Lc.value = t, c = s === "border-box" ? Lc.scrollHeight + a : Lc.scrollHeight - i, Lc.value = "x";
	let l = Lc.scrollHeight - i, u = l * n;
	s === "border-box" && (u = u + i + a), c = Math.max(u, c);
	let d = l * r;
	return s === "border-box" && (d = d + i + a), c = Math.min(d, c), [c, l];
}
function zc({ maxRows: e, minRows: t, onChange: n, ref: r, ...i }) {
	let a = i.value !== void 0, o = v(null), s = Qe(o, r), c = v(0), l = v(0), u = () => {
		let n = o.current;
		if (!n) return;
		let r = Ic(n);
		if (!r) return;
		let [i] = Rc(r, n.value || n.placeholder || "x", t, e);
		c.current !== i && (c.current = i, n.style.setProperty("height", `${i}px`, "important"));
	}, d = m(u), f = (e) => {
		a || u(), n?.(e);
	};
	return g(u), p(() => {
		let e = () => u();
		return window.addEventListener("resize", e), () => window.removeEventListener("resize", e);
	}, []), p(() => {
		let e = o.current;
		if (!e || typeof ResizeObserver > "u") return;
		l.current = e.offsetWidth;
		let t = 0, n = new ResizeObserver(() => {
			o.current && o.current.offsetWidth !== l.current && (l.current = o.current.offsetWidth, cancelAnimationFrame(t), t = requestAnimationFrame(d));
		});
		return n.observe(e), () => {
			cancelAnimationFrame(t), n.disconnect();
		};
	}, []), p(() => {
		let e = () => u();
		return document.fonts.addEventListener("loadingdone", e), () => document.fonts.removeEventListener("loadingdone", e);
	}, []), p(() => {
		let e = (e) => {
			if (o.current?.form === e.target && !a) {
				let e = o.current.value;
				requestAnimationFrame(() => {
					o.current && e !== o.current.value && u();
				});
			}
		};
		return document.body.addEventListener("reset", e), () => document.body.removeEventListener("reset", e);
	}, [a]), /* @__PURE__ */ T("textarea", {
		rows: t,
		...i,
		onChange: f,
		ref: s
	});
}
// node_modules/@mantine/core/esm/components/Textarea/Textarea.mjs
var Bc = J((e) => {
	let { autosize: t, maxRows: n, minRows: r, __staticSelector: i, resize: a, bottomSection: o, bottomSectionProps: s, ...c } = K([
		"Input",
		"InputWrapper",
		"Textarea"
	], null, e), l = t && ct() !== "test", u = l ? {
		maxRows: n,
		minRows: r
	} : {};
	return /* @__PURE__ */ T(ys, {
		component: l ? zc : "textarea",
		...c,
		__staticSelector: i || "Textarea",
		__bottomSection: o,
		__bottomSectionProps: s,
		multiline: !0,
		"data-no-overflow": t && n === void 0 || void 0,
		__vars: { "--input-resize": a },
		...u
	});
});
Bc.classes = ys.classes, Bc.displayName = "@mantine/core/Textarea";
// node_modules/@mantine/core/esm/components/List/List.context.mjs
var [Vc, Hc] = re("List component was not found in tree"), Uc = {
	root: "m_abbac491",
	item: "m_abb6bec2",
	itemWrapper: "m_75cd9f71",
	itemIcon: "m_60f83e5b"
}, Wc = J((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, icon: o, children: s, mod: c, ...l } = K("ListItem", null, e), u = Hc(), d = o || u.icon, f = {
		classNames: t,
		styles: i
	};
	return /* @__PURE__ */ T(Y, {
		...u.getStyles("item", {
			...f,
			className: n,
			style: r
		}),
		component: "li",
		mod: [{
			"with-icon": !!d,
			centered: u.center
		}, c],
		...l,
		children: /* @__PURE__ */ E("div", {
			...u.getStyles("itemWrapper", f),
			children: [d && /* @__PURE__ */ T("span", {
				...u.getStyles("itemIcon", f),
				children: d
			}), /* @__PURE__ */ T("span", {
				...u.getStyles("itemLabel", f),
				children: s
			})]
		})
	});
});
Wc.classes = Uc, Wc.displayName = "@mantine/core/ListItem";
// node_modules/@mantine/core/esm/components/List/List.mjs
var Gc = { type: "unordered" }, Kc = G((e, { size: t, spacing: n }) => ({ root: {
	"--list-fz": U(t),
	"--list-lh": ue(t),
	"--list-spacing": V(n)
} })), qc = J((e) => {
	let t = K("List", Gc, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, children: c, type: l, withPadding: u, icon: d, spacing: f, center: p, listStyleType: m, mod: h, attributes: g, ..._ } = t, v = q({
		name: "List",
		classes: Uc,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: g,
		vars: s,
		varsResolver: Kc
	});
	return /* @__PURE__ */ T(Vc, {
		value: {
			center: p,
			icon: d,
			getStyles: v
		},
		children: /* @__PURE__ */ T(Y, {
			...v("root", { style: { listStyleType: m } }),
			component: l === "unordered" ? "ul" : "ol",
			mod: [{
				"with-padding": u,
				type: d ? "none" : m
			}, h],
			..._,
			children: c
		})
	});
});
qc.classes = Uc, qc.varsResolver = Kc, qc.displayName = "@mantine/core/List", qc.Item = Wc;
// node_modules/@mantine/core/esm/components/Modal/Modal.context.mjs
var [Jc, Yc] = re("Modal component was not found in tree"), Xc = {
	root: "m_9df02822",
	content: "m_54c44539",
	inner: "m_1f958f16",
	header: "m_d0e2b9cd"
}, Zc = J((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, ...o } = K("ModalBody", null, e), s = Yc();
	return /* @__PURE__ */ T(Ro, {
		...s.getStyles("body", {
			classNames: t,
			style: r,
			styles: i,
			className: n
		}),
		...o
	});
});
Zc.classes = Xc, Zc.displayName = "@mantine/core/ModalBody";
// node_modules/@mantine/core/esm/components/Modal/ModalCloseButton.mjs
var Qc = J((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, ...o } = K("ModalCloseButton", null, e), s = Yc();
	return /* @__PURE__ */ T(zo, {
		...s.getStyles("close", {
			classNames: t,
			style: r,
			styles: i,
			className: n
		}),
		...o
	});
});
Qc.classes = Xc, Qc.displayName = "@mantine/core/ModalCloseButton";
// node_modules/@mantine/core/esm/components/Modal/ModalContent.mjs
var $c = J((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, children: o, __hidden: s, ...c } = K("ModalContent", null, e), l = Yc(), u = l.scrollAreaComponent || qo;
	return /* @__PURE__ */ T(Bo, {
		...l.getStyles("content", {
			className: n,
			style: r,
			styles: i,
			classNames: t
		}),
		innerProps: l.getStyles("inner", {
			className: n,
			style: r,
			styles: i,
			classNames: t
		}),
		"data-full-screen": l.fullScreen || void 0,
		"data-modal-content": !0,
		"data-hidden": s || void 0,
		...c,
		children: /* @__PURE__ */ T(u, {
			style: { maxHeight: l.fullScreen ? "100dvh" : `calc(100dvh - (${P(l.yOffset)} * 2))` },
			children: o
		})
	});
});
$c.classes = Xc, $c.displayName = "@mantine/core/ModalContent";
// node_modules/@mantine/core/esm/components/Modal/ModalHeader.mjs
var el = J((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, ...o } = K("ModalHeader", null, e), s = Yc();
	return /* @__PURE__ */ T(Vo, {
		...s.getStyles("header", {
			classNames: t,
			style: r,
			styles: i,
			className: n
		}),
		...o
	});
});
el.classes = Xc, el.displayName = "@mantine/core/ModalHeader";
// node_modules/@mantine/core/esm/components/Modal/ModalOverlay.mjs
var tl = J((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, ...o } = K("ModalOverlay", null, e), s = Yc();
	return /* @__PURE__ */ T(Wo, {
		...s.getStyles("overlay", {
			classNames: t,
			style: r,
			styles: i,
			className: n
		}),
		...o
	});
});
tl.classes = Xc, tl.displayName = "@mantine/core/ModalOverlay";
// node_modules/@mantine/core/esm/components/Modal/ModalRoot.mjs
var nl = {
	__staticSelector: "Modal",
	closeOnClickOutside: !0,
	withinPortal: !0,
	lockScroll: !0,
	trapFocus: !0,
	returnFocus: !0,
	closeOnEscape: !0,
	keepMounted: !1,
	zIndex: ce("modal"),
	transitionProps: {
		duration: 200,
		transition: "fade-down"
	},
	yOffset: "5dvh"
}, rl = G((e, { radius: t, size: n, yOffset: r, xOffset: i }) => ({ root: {
	"--modal-radius": t === void 0 ? void 0 : H(t),
	"--modal-size": B(n, "modal-size"),
	"--modal-y-offset": P(r),
	"--modal-x-offset": P(i)
} })), il = J((e) => {
	let t = K("ModalRoot", nl, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, yOffset: c, scrollAreaComponent: l, radius: u, fullScreen: d, centered: f, xOffset: p, __staticSelector: m, attributes: h, ...g } = t, _ = q({
		name: m,
		classes: Xc,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: h,
		vars: s,
		varsResolver: rl
	});
	return /* @__PURE__ */ T(Jc, {
		value: {
			yOffset: c,
			scrollAreaComponent: l,
			getStyles: _,
			fullScreen: d
		},
		children: /* @__PURE__ */ T(Fo, {
			..._("root"),
			"data-full-screen": d || void 0,
			"data-centered": f || void 0,
			"data-offset-scrollbars": l === Ci.Autosize || void 0,
			unstyled: o,
			...g
		})
	});
});
il.classes = Xc, il.varsResolver = rl, il.displayName = "@mantine/core/ModalRoot";
// node_modules/@mantine/core/esm/components/Modal/ModalStack.mjs
var al = s(null);
function ol({ children: e }) {
	let [t, n] = y([]), [r, i] = y(ce("modal")), [a] = y(() => /* @__PURE__ */ new WeakSet());
	return /* @__PURE__ */ T(al, {
		value: {
			stack: t,
			addModal: (e, t) => {
				n((t) => [.../* @__PURE__ */ new Set([...t, e])]), i((e) => typeof t == "number" && typeof e == "number" ? Math.max(e, t) : e);
			},
			removeModal: (e) => n((t) => t.filter((t) => t !== e)),
			getZIndex: (e) => `calc(${r} + ${t.indexOf(e)} + 1)`,
			currentId: t[t.length - 1],
			maxZIndex: r,
			handledEscapeEvents: a
		},
		children: e
	});
}
ol.displayName = "@mantine/core/ModalStack";
// node_modules/@mantine/core/esm/components/Modal/ModalTitle.mjs
var sl = J((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, ...o } = K("ModalTitle", null, e), s = Yc();
	return /* @__PURE__ */ T(Ko, {
		...s.getStyles("title", {
			classNames: t,
			style: r,
			styles: i,
			className: n
		}),
		...o
	});
});
sl.classes = Xc, sl.displayName = "@mantine/core/ModalTitle";
// node_modules/@mantine/core/esm/components/Modal/Modal.mjs
var cl = {
	closeOnClickOutside: !0,
	withinPortal: !0,
	lockScroll: !0,
	trapFocus: !0,
	returnFocus: !0,
	closeOnEscape: !0,
	keepMounted: !1,
	zIndex: ce("modal"),
	transitionProps: {
		duration: 200,
		transition: "fade-down"
	},
	withOverlay: !0,
	withCloseButton: !0
}, ll = J((e) => {
	let { title: t, withOverlay: n, overlayProps: r, withCloseButton: i, closeButtonProps: a, children: o, radius: s, opened: c, stackId: l, zIndex: d, ...f } = K("Modal", cl, e), m = u(al), h = !!t || i, g = m && l ? {
		closeOnEscape: m.currentId === l,
		trapFocus: m.currentId === l,
		zIndex: m.getZIndex(l),
		__handledEscapeEvents: m.handledEscapeEvents
	} : {}, _ = n === !1 ? !1 : l && m ? m.currentId === l : c;
	return p(() => {
		m && l && (c ? m.addModal(l, d || ce("modal")) : m.removeModal(l));
	}, [
		c,
		l,
		d
	]), /* @__PURE__ */ E(il, {
		radius: s,
		opened: c,
		zIndex: m && l ? m.getZIndex(l) : d,
		...f,
		...g,
		children: [n && /* @__PURE__ */ T(tl, {
			visible: _,
			transitionProps: m && l ? { duration: 0 } : void 0,
			...r
		}), /* @__PURE__ */ E($c, {
			radius: s,
			__hidden: m && l && c ? l !== m.currentId : !1,
			children: [h && /* @__PURE__ */ E(el, { children: [t && /* @__PURE__ */ T(sl, { children: t }), i && /* @__PURE__ */ T(Qc, { ...a })] }), /* @__PURE__ */ T(Zc, { children: o })]
		})]
	});
});
ll.classes = Xc, ll.displayName = "@mantine/core/Modal", ll.Root = il, ll.Overlay = tl, ll.Content = $c, ll.Body = Zc, ll.Header = el, ll.Title = sl, ll.CloseButton = Qc, ll.Stack = ol;
// node_modules/@mantine/core/esm/components/NativeSelect/NativeSelectOption.mjs
function ul(e) {
	return "group" in e;
}
function dl({ data: e }) {
	if (ul(e)) {
		let t = e.items.map((e) => /* @__PURE__ */ T(dl, { data: e }, e.value));
		return /* @__PURE__ */ T("optgroup", {
			label: e.group,
			children: t
		});
	}
	let { value: t, label: n, ...r } = e;
	return /* @__PURE__ */ T("option", {
		value: e.value,
		...r,
		children: e.label
	});
}
dl.displayName = "@mantine/core/NativeSelectOption";
// node_modules/@mantine/core/esm/components/NativeSelect/NativeSelect.mjs
var fl = {
	size: "sm",
	rightSectionPointerEvents: "none"
}, pl = J((e) => {
	let { data: t, children: n, size: r, error: i, rightSection: a, unstyled: o, ...s } = K([
		"Input",
		"InputWrapper",
		"NativeSelect"
	], fl, e), c = Bs(t).map((e, t) => /* @__PURE__ */ T(dl, { data: e }, t));
	return /* @__PURE__ */ T(ys, {
		component: "select",
		...s,
		__staticSelector: "NativeSelect",
		size: r,
		pointer: !0,
		error: i,
		unstyled: o,
		rightSection: a || /* @__PURE__ */ T(Ws, {
			size: r,
			error: i,
			unstyled: o
		}),
		children: n || c
	});
});
pl.classes = ys.classes, pl.displayName = "@mantine/core/NativeSelect";
// node_modules/react-number-format/dist/react-number-format.es.js
function ml(e, t) {
	var n = {};
	for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
	if (e != null && typeof Object.getOwnPropertySymbols == "function") for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++) t.indexOf(r[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (n[r[i]] = e[r[i]]);
	return n;
}
var hl;
(function(e) {
	e.event = "event", e.props = "prop";
})(hl ||= {});
function gl() {}
function _l(e) {
	var t, n = void 0;
	return function() {
		for (var r = [], i = arguments.length; i--;) r[i] = arguments[i];
		return t && r.length === t.length && r.every(function(e, n) {
			return e === t[n];
		}) || (t = r, n = e.apply(void 0, r)), n;
	};
}
function vl(e) {
	return !!(e || "").match(/\d/);
}
function yl(e) {
	return e == null;
}
function bl(e) {
	return typeof e == "number" && isNaN(e);
}
function xl(e) {
	return yl(e) || bl(e) || typeof e == "number" && !isFinite(e);
}
function Sl(e) {
	return e.replace(/[-[\]/{}()*+?.\\^$|]/g, "\\$&");
}
function Cl(e) {
	switch (e) {
		case "lakh": return /(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?/g;
		case "wan": return /(\d)(?=(\d{4})+(?!\d))/g;
		default: return /(\d)(?=(\d{3})+(?!\d))/g;
	}
}
function wl(e, t, n) {
	var r = Cl(n), i = e.search(/[1-9]/);
	return i = i === -1 ? e.length : i, e.substring(0, i) + e.substring(i, e.length).replace(r, "$1" + t);
}
function Tl(e) {
	var t = v(e);
	return t.current = e, v(function() {
		for (var e = [], n = arguments.length; n--;) e[n] = arguments[n];
		return t.current.apply(t, e);
	}).current;
}
function El(e, t) {
	t === void 0 && (t = !0);
	var n = e[0] === "-", r = n && t;
	e = e.replace("-", "");
	var i = e.split(".");
	return {
		beforeDecimal: i[0],
		afterDecimal: i[1] || "",
		hasNegation: n,
		addNegation: r
	};
}
function Dl(e) {
	if (!e) return e;
	var t = e[0] === "-";
	t && (e = e.substring(1, e.length));
	var n = e.split("."), r = n[0].replace(/^0+/, "") || "0", i = n[1] || "";
	return (t ? "-" : "") + r + (i ? "." + i : "");
}
function Ol(e, t, n) {
	for (var r = "", i = n ? "0" : "", a = 0; a <= t - 1; a++) r += e[a] || i;
	return r;
}
function kl(e, t) {
	return Array(t + 1).join(e);
}
function Al(e) {
	var t = e + "", n = t[0] === "-" ? "-" : "";
	n && (t = t.substring(1));
	var r = t.split(/[eE]/g), i = r[0], a = r[1];
	if (a = Number(a), !a) return n + i;
	i = i.replace(".", "");
	var o = 1 + a, s = i.length;
	return o < 0 ? i = "0." + kl("0", Math.abs(o)) + i : o >= s ? i += kl("0", o - s) : i = (i.substring(0, o) || "0") + "." + i.substring(o), n + i;
}
function jl(e, t, n) {
	if (["", "-"].indexOf(e) !== -1) return e;
	var r = (e.indexOf(".") !== -1 || n) && t, i = El(e), a = i.beforeDecimal, o = i.afterDecimal, s = i.hasNegation, c = parseFloat("0." + (o || "0")), l = (o.length <= t ? "0." + o : c.toFixed(t)).split("."), u = a;
	a && Number(l[0]) && (u = a.split("").reverse().reduce(function(e, t, n) {
		return e.length > n ? (Number(e[0]) + Number(t)).toString() + e.substring(1, e.length) : t + e;
	}, l[0]));
	var d = Ol(l[1] || "", t, n), f = s ? "-" : "", p = r ? "." : "";
	return "" + f + u + p + d;
}
function Ml(e, t) {
	if (e.value = e.value, e !== null) {
		if (e.createTextRange) {
			var n = e.createTextRange();
			return n.move("character", t), n.select(), !0;
		}
		return e.selectionStart || e.selectionStart === 0 ? (e.focus(), e.setSelectionRange(t, t), !0) : (e.focus(), !1);
	}
}
var Nl = _l(function(e, t) {
	for (var n = 0, r = 0, i = e.length, a = t.length; e[n] === t[n] && n < i;) n++;
	for (; e[i - 1 - r] === t[a - 1 - r] && a - r > n && i - r > n;) r++;
	return {
		from: {
			start: n,
			end: i - r
		},
		to: {
			start: n,
			end: a - r
		}
	};
}), Pl = function(e, t) {
	var n = Math.min(e.selectionStart, t);
	return {
		from: {
			start: n,
			end: e.selectionEnd
		},
		to: {
			start: n,
			end: t
		}
	};
};
function Fl(e, t, n) {
	return Math.min(Math.max(e, t), n);
}
function Il(e) {
	return Math.max(e.selectionStart, e.selectionEnd);
}
function Ll() {
	return typeof navigator < "u" && !(navigator.platform && /iPhone|iPod/.test(navigator.platform));
}
function Rl(e) {
	return {
		from: {
			start: 0,
			end: 0
		},
		to: {
			start: 0,
			end: e.length
		},
		lastValue: ""
	};
}
function zl(e) {
	var t = e.currentValue, n = e.formattedValue, r = e.currentValueIndex, i = e.formattedValueIndex;
	return t[r] === n[i];
}
function Bl(e, t, n, r, i, a, o) {
	o === void 0 && (o = zl);
	var s = i.findIndex(function(e) {
		return e;
	}), c = e.slice(0, s);
	!t && !n.startsWith(c) && (t = c, n = c + n, r += c.length);
	for (var l = n.length, u = e.length, d = {}, f = Array(l), p = 0; p < l; p++) {
		f[p] = -1;
		for (var m = 0, h = u; m < h; m++) if (o({
			currentValue: n,
			lastValue: t,
			formattedValue: e,
			currentValueIndex: p,
			formattedValueIndex: m
		}) && d[m] !== !0) {
			f[p] = m, d[m] = !0;
			break;
		}
	}
	for (var g = r; g < l && (f[g] === -1 || !a(n[g]));) g++;
	var _ = g === l || f[g] === -1 ? u : f[g];
	for (g = r - 1; g > 0 && f[g] === -1;) g--;
	var v = g === -1 || f[g] === -1 ? 0 : f[g] + 1;
	return v > _ ? _ : r - v < _ - r ? v : _;
}
function Vl(e, t, n, r) {
	var i = e.length;
	if (t = Fl(t, 0, i), r === "left") {
		for (; t >= 0 && !n[t];) t--;
		t === -1 && (t = n.indexOf(!0));
	} else {
		for (; t <= i && !n[t];) t++;
		t > i && (t = n.lastIndexOf(!0));
	}
	return t === -1 && (t = i), t;
}
function Hl(e) {
	for (var t = Array.from({ length: e.length + 1 }).map(function() {
		return !0;
	}), n = 0, r = t.length; n < r; n++) t[n] = !!(vl(e[n]) || vl(e[n - 1]));
	return t;
}
function Ul(e, t, n, r, i, a) {
	a === void 0 && (a = gl);
	var o = Tl(function(e, t) {
		var n, a;
		return xl(e) ? (a = "", n = "") : typeof e == "number" || t ? (a = typeof e == "number" ? Al(e) : e, n = r(a)) : (a = i(e, void 0), n = r(a)), {
			formattedValue: n,
			numAsString: a
		};
	}), s = y(function() {
		return o(yl(e) ? t : e, n);
	}), c = s[0], l = s[1], u = Tl(function(e, t) {
		e.formattedValue !== c.formattedValue && l({
			formattedValue: e.formattedValue,
			numAsString: e.value
		}), a(e, t);
	}), d = e, f = n;
	yl(e) && (d = c.numAsString, f = !0);
	var m = o(d, f);
	return _(function() {
		l(m);
	}, [m.formattedValue]), p(function() {
		if (!yl(t) && yl(e) && c.formattedValue !== "") {
			var n = parseFloat(c.numAsString);
			u({
				formattedValue: c.formattedValue,
				value: c.numAsString,
				floatValue: isNaN(n) ? void 0 : n
			}, {
				event: void 0,
				source: hl.props
			});
		}
	}, []), [c, u];
}
function Wl(e) {
	return e.replace(/[^0-9]/g, "");
}
function Gl(e) {
	return e;
}
function Kl(e) {
	var t = e.type;
	t === void 0 && (t = "text");
	var r = e.displayType;
	r === void 0 && (r = "input");
	var i = e.customInput, a = e.renderText, o = e.getInputRef, s = e.format;
	s === void 0 && (s = Gl);
	var c = e.removeFormatting;
	c === void 0 && (c = Wl);
	var l = e.defaultValue, u = e.valueIsNumericString, d = e.onValueChange, f = e.isAllowed, m = e.onChange;
	m === void 0 && (m = gl);
	var h = e.onKeyDown;
	h === void 0 && (h = gl);
	var _ = e.onMouseUp;
	_ === void 0 && (_ = gl);
	var b = e.onFocus;
	b === void 0 && (b = gl);
	var x = e.onBlur;
	x === void 0 && (x = gl);
	var S = e.value, C = e.getCaretBoundary;
	C === void 0 && (C = Hl);
	var w = e.isValidInputCharacter;
	w === void 0 && (w = vl);
	var T = e.isCharacterSame, E = ml(e, [
		"type",
		"displayType",
		"customInput",
		"renderText",
		"getInputRef",
		"format",
		"removeFormatting",
		"defaultValue",
		"valueIsNumericString",
		"onValueChange",
		"isAllowed",
		"onChange",
		"onKeyDown",
		"onMouseUp",
		"onFocus",
		"onBlur",
		"value",
		"getCaretBoundary",
		"isValidInputCharacter",
		"isCharacterSame"
	]), D = Ul(S, l, !!u, s, c, d), O = D[0], k = O.formattedValue, ee = O.numAsString, A = D[1], j = v(), M = v({
		formattedValue: k,
		numAsString: ee
	}), N = function(e, t) {
		M.current = {
			formattedValue: e.formattedValue,
			numAsString: e.value
		}, A(e, t);
	}, P = y(!1), te = P[0], ne = P[1], F = v(null), I = v({
		setCaretTimeout: null,
		focusTimeout: null
	});
	p(function() {
		return ne(!0), function() {
			clearTimeout(I.current.setCaretTimeout), clearTimeout(I.current.focusTimeout);
		};
	}, []);
	var re = s, L = function(e, t) {
		var n = parseFloat(t);
		return {
			formattedValue: e,
			value: t,
			floatValue: isNaN(n) ? void 0 : n
		};
	}, R = function(e, t, n) {
		(e.selectionStart !== 0 || e.selectionEnd !== e.value.length) && (Ml(e, t), I.current.setCaretTimeout = setTimeout(function() {
			e.value === n && e.selectionStart !== t && Ml(e, t);
		}, 0));
	}, z = function(e, t, n) {
		return Vl(e, t, C(e), n);
	}, ie = function(e, t, n) {
		var r = C(t), i = Bl(t, k, e, n, r, w, T);
		return i = Vl(t, i, r), i;
	}, ae = function(e) {
		var t = e.formattedValue;
		t === void 0 && (t = "");
		var n = e.input, r = e.source, i = e.event, a = e.numAsString, o;
		if (n) {
			var s = e.inputValue || n.value, c = Il(n);
			n.value = t, o = ie(s, t, c), o !== void 0 && R(n, o, t);
		}
		t !== k && N(L(t, a), {
			event: i,
			source: r
		});
	};
	p(function() {
		var e = M.current, t = e.formattedValue, n = e.numAsString;
		(k !== t || ee !== n) && N(L(k, ee), {
			event: void 0,
			source: hl.props
		});
	}, [k, ee]);
	var oe = F.current ? Il(F.current) : void 0;
	(typeof window < "u" ? g : p)(function() {
		var e = F.current;
		if (k !== M.current.formattedValue && e) {
			var t = ie(M.current.formattedValue, k, oe);
			e.value = k, R(e, t, k);
		}
	}, [k]);
	var se = function(e, t, n) {
		var r = t.target, i = j.current ? Pl(j.current, r.selectionEnd) : Nl(k, e), a = Object.assign(Object.assign({}, i), { lastValue: k }), o = c(e, a), s = re(o);
		if (o = c(s, void 0), f && !f(L(s, o))) {
			var l = t.target, u = ie(e, k, Il(l));
			return l.value = k, R(l, u, k), !1;
		}
		return ae({
			formattedValue: s,
			numAsString: o,
			inputValue: e,
			event: t,
			source: n,
			input: t.target
		}), !0;
	}, ce = function(e, t) {
		t === void 0 && (t = 0), j.current = {
			selectionStart: e.selectionStart,
			selectionEnd: e.selectionEnd + t
		};
	}, le = function(e) {
		var t = e.target.value;
		se(t, e, hl.event) && m(e), j.current = void 0;
	}, B = function(e) {
		var t = e.target, n = e.key, r = t.selectionStart, i = t.selectionEnd, a = t.value;
		a === void 0 && (a = "");
		var o;
		n === "ArrowLeft" || n === "Backspace" ? o = Math.max(r - 1, 0) : n === "ArrowRight" ? o = Math.min(r + 1, a.length) : n === "Delete" && (o = r);
		var s = 0;
		n === "Delete" && r === i && (s = 1);
		var c = n === "ArrowLeft" || n === "ArrowRight";
		if (o === void 0 || r !== i && !c) h(e), ce(t, s);
		else {
			var l = o;
			c ? (l = z(a, o, n === "ArrowLeft" ? "left" : "right"), l !== o && e.preventDefault()) : n === "Delete" && !w(a[o]) ? l = z(a, o, "right") : n === "Backspace" && !w(a[o]) && (l = z(a, o, "left")), l !== o && R(t, l, a), h(e), ce(t, s);
		}
	}, V = function(e) {
		var t = e.target, n = function() {
			var e = t.selectionStart, n = t.selectionEnd, r = t.value;
			if (r === void 0 && (r = ""), e === n) {
				var i = z(r, e);
				i !== e && R(t, i, r);
			}
		};
		n(), requestAnimationFrame(function() {
			n();
		}), _(e), ce(t);
	}, H = function(e) {
		e.persist && e.persist();
		var t = e.target, n = e.currentTarget;
		F.current = t, I.current.focusTimeout = setTimeout(function() {
			var r = t.selectionStart, i = t.selectionEnd, a = t.value;
			a === void 0 && (a = "");
			var o = z(a, r);
			o !== r && (r !== 0 || i !== a.length) && R(t, o, a), b(Object.assign(Object.assign({}, e), { currentTarget: n }));
		}, 0);
	}, U = function(e) {
		F.current = null, clearTimeout(I.current.focusTimeout), clearTimeout(I.current.setCaretTimeout), x(e);
	}, ue = te && Ll() ? "numeric" : void 0, W = Object.assign({ inputMode: ue }, E, {
		type: t,
		value: k,
		onChange: le,
		onKeyDown: B,
		onMouseUp: V,
		onFocus: H,
		onBlur: U
	});
	if (r === "text") return a ? n.createElement(n.Fragment, null, a(k, E) || null) : n.createElement("span", Object.assign({}, E, { ref: o }), k);
	if (i) {
		var de = i;
		return n.createElement(de, Object.assign({}, W, { ref: o }));
	}
	return n.createElement("input", Object.assign({}, W, { ref: o }));
}
function ql(e, t) {
	var n = t.decimalScale, r = t.fixedDecimalScale, i = t.prefix;
	i === void 0 && (i = "");
	var a = t.suffix;
	a === void 0 && (a = "");
	var o = t.allowNegative, s = t.thousandsGroupStyle;
	if (s === void 0 && (s = "thousand"), e === "" || e === "-") return e;
	var c = Jl(t), l = c.thousandSeparator, u = c.decimalSeparator, d = n !== 0 && e.indexOf(".") !== -1 || n && r, f = El(e, o), p = f.beforeDecimal, m = f.afterDecimal, h = f.addNegation;
	return n !== void 0 && (m = Ol(m, n, !!r)), l && (p = wl(p, l, s)), i && (p = i + p), a && (m += a), h && (p = "-" + p), e = p + (d && u || "") + m, e;
}
function Jl(e) {
	var t = e.decimalSeparator;
	t === void 0 && (t = ".");
	var n = e.thousandSeparator, r = e.allowedDecimalSeparators;
	return n === !0 && (n = ","), r ||= [t, "."], {
		decimalSeparator: t,
		thousandSeparator: n,
		allowedDecimalSeparators: r
	};
}
function Yl(e, t) {
	e === void 0 && (e = "");
	var n = /* @__PURE__ */ RegExp("(-)"), r = /* @__PURE__ */ RegExp("(-)(.)*(-)"), i = n.test(e), a = r.test(e);
	return e = e.replace(/-/g, ""), i && !a && t && (e = "-" + e), e;
}
function Xl(e, t) {
	return RegExp("(^-)|[0-9]|" + Sl(e), t ? "g" : void 0);
}
function Zl(e, t, n) {
	return e === "" || !t?.match(/\d/) && !n?.match(/\d/) && typeof e == "string" && !isNaN(Number(e));
}
function Ql(e, t, n) {
	var r;
	t === void 0 && (t = Rl(e));
	var i = n.allowNegative, a = n.prefix;
	a === void 0 && (a = "");
	var o = n.suffix;
	o === void 0 && (o = "");
	var s = n.decimalScale, c = t.from, l = t.to, u = l.start, d = l.end, f = Jl(n), p = f.allowedDecimalSeparators, m = f.decimalSeparator, h = e[d] === m;
	if (vl(e) && (e === a || e === o) && t.lastValue === "") return e;
	if (d - u === 1 && p.indexOf(e[u]) !== -1) {
		var g = s === 0 ? "" : m;
		e = e.substring(0, u) + g + e.substring(u + 1, e.length);
	}
	var _ = function(e, t, n) {
		var r = !1, i = !1;
		a.startsWith("-") ? r = !1 : e.startsWith("--") ? (r = !1, i = !0) : o.startsWith("-") && e.length === o.length ? r = !1 : e[0] === "-" && (r = !0);
		var s = +!!r;
		return i && (s = 2), s && (e = e.substring(s), t -= s, n -= s), {
			value: e,
			start: t,
			end: n,
			hasNegation: r
		};
	}, v = _(e, u, d), y = v.hasNegation;
	r = v, e = r.value, u = r.start, d = r.end;
	var b = _(t.lastValue, c.start, c.end), x = b.start, S = b.end, C = b.value, w = e.substring(u, d);
	e.length && C.length && (x > C.length - o.length || S < a.length) && !(w && o.startsWith(w)) && (e = C);
	var T = 0;
	e.startsWith(a) ? T += a.length : u < a.length && (T = u), e = e.substring(T), d -= T;
	var E = e.length, D = e.length - o.length;
	e.endsWith(o) ? E = D : (d > D || d > e.length - o.length) && (E = d), e = e.substring(0, E), e = Yl(y ? "-" + e : e, i), e = (e.match(Xl(m, !0)) || []).join("");
	var O = e.indexOf(m);
	e = e.replace(new RegExp(Sl(m), "g"), function(e, t) {
		return t === O ? "." : "";
	});
	var k = El(e, i), ee = k.beforeDecimal, A = k.afterDecimal, j = k.addNegation;
	return l.end - l.start < c.end - c.start && ee === "" && h && !parseFloat(A) && (e = j ? "-" : ""), e;
}
function $l(e, t) {
	var n = t.prefix;
	n === void 0 && (n = "");
	var r = t.suffix;
	r === void 0 && (r = "");
	var i = Array.from({ length: e.length + 1 }).map(function() {
		return !0;
	}), a = e[0] === "-";
	i.fill(!1, 0, Math.min(n.length + +!!a, e.length));
	var o = e.length;
	return i.fill(!1, o - r.length + 1, o + 1), i;
}
function eu(e) {
	var t = Jl(e), n = t.thousandSeparator, r = t.decimalSeparator, i = e.prefix;
	i === void 0 && (i = "");
	var a = e.allowNegative;
	if (a === void 0 && (a = !0), n === r) throw Error("\n        Decimal separator can't be same as thousand separator.\n        thousandSeparator: " + n + " (thousandSeparator = {true} is same as thousandSeparator = \",\")\n        decimalSeparator: " + r + " (default value for decimalSeparator is .)\n     ");
	return i.startsWith("-") && a && (console.error("\n      Prefix can't start with '-' when allowNegative is true.\n      prefix: " + i + "\n      allowNegative: " + a + "\n    "), a = !1), Object.assign(Object.assign({}, e), { allowNegative: a });
}
function tu(e) {
	e = eu(e), e.decimalSeparator, e.allowedDecimalSeparators, e.thousandsGroupStyle;
	var t = e.suffix, n = e.allowNegative, r = e.allowLeadingZeros, i = e.onKeyDown;
	i === void 0 && (i = gl);
	var a = e.onBlur;
	a === void 0 && (a = gl);
	var o = e.thousandSeparator, s = e.decimalScale, c = e.fixedDecimalScale, l = e.prefix;
	l === void 0 && (l = "");
	var u = e.defaultValue, d = e.value, f = e.valueIsNumericString, p = e.onValueChange, m = ml(e, [
		"decimalSeparator",
		"allowedDecimalSeparators",
		"thousandsGroupStyle",
		"suffix",
		"allowNegative",
		"allowLeadingZeros",
		"onKeyDown",
		"onBlur",
		"thousandSeparator",
		"decimalScale",
		"fixedDecimalScale",
		"prefix",
		"defaultValue",
		"value",
		"valueIsNumericString",
		"onValueChange"
	]), h = Jl(e), g = h.decimalSeparator, _ = h.allowedDecimalSeparators, v = function(t) {
		return ql(t, e);
	}, y = function(t, n) {
		return Ql(t, n, e);
	}, b = yl(d) ? u : d, x = f ?? Zl(b, l, t);
	yl(d) ? yl(u) || (x ||= typeof u == "number") : x ||= typeof d == "number";
	var S = function(e) {
		return xl(e) ? e : (typeof e == "number" && (e = Al(e)), x && typeof s == "number" ? jl(e, s, !!c) : e);
	}, C = Ul(S(d), S(u), !!x, v, y, p), w = C[0], T = w.numAsString, E = w.formattedValue, D = C[1];
	return Object.assign(Object.assign({}, m), {
		value: E,
		valueIsNumericString: !1,
		isValidInputCharacter: function(e) {
			return e === g || vl(e);
		},
		isCharacterSame: function(e) {
			var t = e.currentValue, n = e.lastValue, r = e.formattedValue, i = e.currentValueIndex, a = e.formattedValueIndex, o = t[i], u = r[a], f = Nl(n, t).to, p = function(e) {
				return y(e).indexOf(".") + l.length;
			};
			return d === 0 && c && s && t[f.start] === g && p(t) < i && p(r) > a ? !1 : i >= f.start && i < f.end && _ && _.includes(o) && u === g ? !0 : o === u;
		},
		onValueChange: D,
		format: v,
		removeFormatting: y,
		getCaretBoundary: function(t) {
			return $l(t, e);
		},
		onKeyDown: function(e) {
			var t = e.target, r = e.key, a = t.selectionStart, u = t.selectionEnd, d = t.value;
			if (d === void 0 && (d = ""), (r === "Backspace" || r === "Delete") && u < l.length && d !== "-") e.preventDefault();
			else if (a !== u) i(e);
			else {
				r === "Backspace" && d[0] === "-" && a === l.length + 1 && n && Ml(t, 1), s && c && (r === "Backspace" && d[a - 1] === g ? (Ml(t, a - 1), e.preventDefault()) : r === "Delete" && d[a] === g && e.preventDefault()), _?.includes(r) && d[a] === g && Ml(t, a + 1);
				var f = o === !0 ? "," : o;
				r === "Backspace" && d[a - 1] === f && Ml(t, a - 1), r === "Delete" && d[a] === f && Ml(t, a + 1), i(e);
			}
		},
		onBlur: function(t) {
			var n = T;
			n.match(/\d/g) || (n = ""), r || (n = Dl(n)), c && s && (n = jl(n, s, c)), n !== T && D({
				formattedValue: ql(n, e),
				value: n,
				floatValue: parseFloat(n)
			}, {
				event: t,
				source: hl.event
			}), a(t);
		}
	});
}
function nu(e) {
	var t = tu(e);
	return n.createElement(Kl, Object.assign({}, t));
}
// node_modules/@mantine/core/esm/components/NumberInput/get-caret-position-after-paste/get-caret-position-after-paste.mjs
function ru(e, t) {
	return /\d/.test(e) || e === t;
}
function iu(e, t, n, r) {
	let i = 0;
	for (let n = 0; n < t && n < e.length; n += 1) ru(e[n], r) && (i += 1);
	if (i === 0) return Math.min(t, n.length);
	for (let e = 0; e < n.length; e += 1) if (ru(n[e], r) && (--i, i === 0)) return e + 1;
	return n.length;
}
// node_modules/@mantine/core/esm/components/NumberInput/normalize-pasted-value/normalize-pasted-value.mjs
function au(e, t) {
	let n = 0;
	for (; t + n < e.length && /\d/.test(e[t + n]);) n += 1;
	return n;
}
function ou(e, { decimalSeparator: t, thousandSeparator: n, allowedDecimalSeparators: r, thousandsGroupStyle: i }) {
	let a = new Set([...r, t].filter((e) => e.length === 1)), o = e.split(""), s = o.reduce((e, t, n) => (a.has(t) && e.push(n), e), []);
	if (s.length === 0) return e;
	let c = s[s.length - 1], l = o[c], u = s.filter((e) => o[e] === l).length, d = i === "wan" ? 4 : 3, f = -1;
	return u === 1 && (f = l === t ? c : l === n && au(e, c + 1) === d ? -1 : c), o.map((e, r) => r === f ? t : a.has(e) && e !== n ? "" : e).join("");
}
// node_modules/@mantine/core/esm/components/NumberInput/NumberInputChevron.mjs
function su({ direction: e, style: t, ...n }) {
	return /* @__PURE__ */ T("svg", {
		style: {
			width: "var(--ni-chevron-size)",
			height: "var(--ni-chevron-size)",
			transform: e === "up" ? "rotate(180deg)" : void 0,
			...t
		},
		viewBox: "0 0 15 15",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		...n,
		children: /* @__PURE__ */ T("path", {
			d: "M3.13523 6.15803C3.3241 5.95657 3.64052 5.94637 3.84197 6.13523L7.5 9.56464L11.158 6.13523C11.3595 5.94637 11.6759 5.95657 11.8648 6.15803C12.0536 6.35949 12.0434 6.67591 11.842 6.86477L7.84197 10.6148C7.64964 10.7951 7.35036 10.7951 7.15803 10.6148L3.15803 6.86477C2.95657 6.67591 2.94637 6.35949 3.13523 6.15803Z",
			fill: "currentColor",
			fillRule: "evenodd",
			clipRule: "evenodd"
		})
	});
}
// node_modules/@mantine/core/esm/components/NumberInput/NumberInput.module.mjs
var cu = {
	root: "m_e2f5cd4e",
	controls: "m_95e17d22",
	control: "m_80b4b171"
}, lu = /^(0\.0*|-0(\.0*)?)$/, uu = /^-?0\d+(\.\d+)?\.?$/, du = /\.\d*0$/, fu = /^-?\d+\.$/;
function pu(e) {
	return typeof e == "string" && e !== "" && !Number.isNaN(Number(e));
}
function mu(e) {
	return typeof e == "bigint";
}
function hu(e) {
	return typeof e == "number" ? e < 2 ** 53 - 1 : e === "" || pu(e) && Number(e) < 2 ** 53 - 1;
}
function gu(e, t) {
	return e === "" || e === "-" || !t && e.startsWith("-") ? !1 : /^-?\d+$/.test(e);
}
function _u(e, t) {
	return typeof e == "bigint" || e === "" || gu(e, t);
}
function vu(e) {
	if (!/^-?\d+$/.test(e)) return null;
	try {
		return BigInt(e);
	} catch {
		return null;
	}
}
function yu(e) {
	if (typeof e == "bigint") return e;
	if (typeof e == "number" && Number.isFinite(e) && Number.isInteger(e)) return BigInt(e);
}
function bu(e, t, n) {
	return t !== void 0 && e < t ? t : n !== void 0 && e > n ? n : e;
}
function xu(e) {
	return e.toString().replace(".", "").length;
}
function Su(e, t) {
	return (typeof e == "number" ? e < 2 ** 53 - 1 : !Number.isNaN(Number(e))) && !Number.isNaN(e) && xu(t) < 14 && t !== "";
}
function Cu(e, t, n) {
	return e === void 0 || (t === void 0 || e >= t) && (n === void 0 || e <= n);
}
var wu = {
	size: "sm",
	step: 1,
	clampBehavior: "blur",
	allowDecimal: !0,
	allowNegative: !0,
	withKeyboardEvents: !0,
	allowLeadingZeros: !0,
	trimLeadingZeroesOnBlur: !0,
	startValue: 0,
	allowedDecimalSeparators: [".", ","]
}, Tu = G((e, { size: t }) => ({ controls: { "--ni-chevron-size": B(t, "ni-chevron-size") } }));
function Eu(e, t) {
	return t ? `${e}.` : e;
}
function Du(e, t) {
	let n = fu.test(e), r = t.trim ? e.replace(/^0+(?=\d)/, "") : e, i = parseFloat(r);
	if (Number.isNaN(i)) return r;
	if (!t.clamp) return t.trim ? Eu(i, n) : e;
	let a = i > 2 ** 53 - 1 && t.max !== void 0 ? t.max : me(i, t.min, t.max);
	return !t.trim && a === i ? e : Eu(a, n);
}
function Ou(e, t) {
	if (e === "" || e === "-") return e;
	let n = vu(e);
	return n === null ? e : t.clampBehavior === "blur" ? bu(n, t.min, t.max) : n;
}
var ku = Tr((e) => {
	let t = K([
		"Input",
		"InputWrapper",
		"NumberInput"
	], wu, e), { className: n, classNames: r, styles: i, unstyled: a, vars: o, onChange: s, onValueChange: c, value: l, defaultValue: u, max: d, min: f, step: p, hideControls: m, rightSection: h, isAllowed: g, clampBehavior: _, onBlur: y, allowDecimal: b, decimalScale: x, onKeyDown: S, onKeyDownCapture: C, handlersRef: w, startValue: D, disabled: O, rightSectionPointerEvents: k, allowNegative: ee, readOnly: A, size: j, rightSectionWidth: M, stepHoldInterval: N, stepHoldDelay: P, allowLeadingZeros: te, withKeyboardEvents: ne, trimLeadingZeroesOnBlur: F, allowedDecimalSeparators: I, selectAllOnFocus: re, onMinReached: L, onMaxReached: R, onFocus: z, attributes: ie, ref: ae, ...oe } = t, se = ee ?? !0, ce = te ?? !0, B = q({
		name: "NumberInput",
		classes: cu,
		props: t,
		classNames: r,
		styles: i,
		unstyled: a,
		attributes: ie,
		vars: o,
		varsResolver: Tu
	}), { resolvedClassNames: V, resolvedStyles: H } = kn({
		classNames: r,
		styles: i,
		props: t
	}), U = v(mu(l) || mu(u) ? "bigint" : "number");
	mu(l) ? U.current = "bigint" : typeof l == "number" && (U.current = "number");
	let ue = U.current === "bigint", [W, de] = $e({
		value: l,
		defaultValue: u,
		finalValue: "",
		onChange: s
	}), fe = P !== void 0 && N !== void 0, pe = v(null), he = v(null), ge = v(0), _e = typeof f == "number" ? f : void 0, ve = typeof d == "number" ? d : void 0, ye = typeof p == "number" ? p : wu.step, be = typeof D == "number" ? D : wu.startValue, xe = yu(f), Se = yu(d), Ce = yu(p) ?? BigInt(1), we = yu(D) ?? BigInt(0), Te = (e) => !gu(e, se) || ce && uu.test(e) ? e : vu(e) ?? e, Ee = (e) => {
		let t = Number(e);
		return Number.isSafeInteger(t) ? t : void 0;
	}, De = (e, t) => {
		t.source === "event" && de(ue ? Te(e.value) : Su(e.floatValue, e.value) && !lu.test(e.value) && !(ce && uu.test(e.value)) && !du.test(e.value) && !fu.test(e.value) ? e.floatValue : e.value), c?.(e, t);
	}, Oe = (e) => {
		let t = String(e).match(/(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/);
		return t ? Math.max(0, (t[1] ? t[1].length : 0) - (t[2] ? +t[2] : 0)) : 0;
	}, ke = (e) => {
		pe.current && e !== void 0 && pe.current.setSelectionRange(e, e);
	}, Ae = v(le);
	Ae.current = () => {
		if (ue) {
			if (!_u(W, se)) return;
			let e, t = W;
			if (typeof t == "bigint") {
				let n = t + Ce;
				Se !== void 0 && n > Se && R?.(), e = Se !== void 0 && n > Se ? Se : n;
			} else if (typeof t == "string" && t !== "") {
				let n = vu(t);
				if (n === null) return;
				let r = n + Ce;
				Se !== void 0 && r > Se && R?.(), e = Se !== void 0 && r > Se ? Se : r;
			} else e = bu(we, xe, Se);
			let n = e.toString();
			de(e), c?.({
				floatValue: Ee(e),
				formattedValue: n,
				value: n
			}, { source: "increment" }), setTimeout(() => ke(pe.current?.value.length), 0);
			return;
		}
		if (!hu(W)) return;
		let e, t = Oe(W), n = Oe(ye), r = Math.max(t, n), i = 10 ** r;
		if (!pu(W) && (typeof W != "number" || Number.isNaN(W))) e = me(be, _e, ve);
		else if (ve !== void 0) {
			let t = (Math.round(Number(W) * i) + Math.round(ye * i)) / i;
			t > ve && R?.(), e = t <= ve ? t : ve;
		} else e = (Math.round(Number(W) * i) + Math.round(ye * i)) / i;
		let a = e.toFixed(r);
		de(parseFloat(a)), c?.({
			floatValue: parseFloat(a),
			formattedValue: a,
			value: a
		}, { source: "increment" }), setTimeout(() => ke(pe.current?.value.length), 0);
	};
	let je = v(le);
	je.current = () => {
		if (ue) {
			if (!_u(W, se)) return;
			let e, t = xe === void 0 ? se ? void 0 : BigInt(0) : xe, n = W;
			if (typeof n == "bigint") {
				let r = n - Ce;
				t !== void 0 && r < t && L?.(), e = t !== void 0 && r < t ? t : r;
			} else if (typeof n == "string" && n !== "") {
				let r = vu(n);
				if (r === null) return;
				let i = r - Ce;
				t !== void 0 && i < t && L?.(), e = t !== void 0 && i < t ? t : i;
			} else e = bu(we, t, Se);
			let r = e.toString();
			de(e), c?.({
				floatValue: Ee(e),
				formattedValue: r,
				value: r
			}, { source: "decrement" }), setTimeout(() => ke(pe.current?.value.length), 0);
			return;
		}
		if (!hu(W)) return;
		let e, t = _e === void 0 ? se ? -(2 ** 53 - 1) : 0 : _e, n = Oe(W), r = Oe(ye), i = Math.max(n, r), a = 10 ** i;
		if (!pu(W) && typeof W != "number" || Number.isNaN(W)) e = me(be, t, ve);
		else {
			let n = (Math.round(Number(W) * a) - Math.round(ye * a)) / a;
			t !== void 0 && n < t && L?.(), e = t !== void 0 && n < t ? t : n;
		}
		let o = e.toFixed(i);
		de(parseFloat(o)), c?.({
			floatValue: parseFloat(o),
			formattedValue: o,
			value: o
		}, { source: "decrement" }), setTimeout(() => ke(pe.current?.value.length), 0);
	};
	let Me = (e) => {
		let t = e.clipboardData.getData("text"), n = oe.decimalSeparator || ".", r = ou(t, {
			decimalSeparator: n,
			thousandSeparator: oe.thousandSeparator === !0 ? "," : oe.thousandSeparator === !1 ? void 0 : oe.thousandSeparator,
			allowedDecimalSeparators: I || [".", ","],
			thousandsGroupStyle: oe.thousandsGroupStyle
		});
		if (r !== t) {
			e.preventDefault();
			let t = pe.current;
			if (t) {
				let e = t.selectionStart ?? 0, i = t.selectionEnd ?? 0, a = t.value, o = a.substring(0, e) + r + a.substring(i);
				(Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set)?.call(t, o), t.dispatchEvent(new Event("change", { bubbles: !0 }));
				let s = e + r.length;
				setTimeout(() => ke(iu(o, s, t.value, n)), 0);
			}
		}
		oe.onPaste?.(e);
	}, Ne = (e) => {
		S?.(e), !A && ne && (e.key === "ArrowUp" && (e.preventDefault(), Ae.current?.()), e.key === "ArrowDown" && (e.preventDefault(), je.current?.()));
	}, Pe = (e) => {
		if (C?.(e), e.key === "Backspace") {
			let t = pe.current;
			t && t.selectionStart === 0 && t.selectionStart === t.selectionEnd && (e.preventDefault(), window.setTimeout(() => ke(0), 0));
		}
	}, Fe = (e) => {
		re && window.setTimeout(() => pe.current?.select(), 0), z?.(e);
	}, Ie = (e) => {
		let t = W;
		ue ? (_ === "blur" && typeof t == "bigint" && (t = bu(t, xe, Se)), F && typeof t == "string" && (t = Ou(t, {
			min: xe,
			max: Se,
			clampBehavior: _
		}))) : typeof t == "number" ? _ === "blur" && (t = me(t, _e, ve)) : typeof t == "string" && (t = Du(t, {
			min: _e,
			max: ve,
			trim: !!F && Oe(t) < 15,
			clamp: _ === "blur"
		})), W !== t && de(t), y?.(e);
	};
	Xe(w, {
		increment: Ae.current,
		decrement: je.current
	});
	let Le = (e) => {
		e ? Ae.current?.() : je.current?.(), ge.current += 1;
	}, Re = (e) => {
		if (Le(e), fe) {
			let t = typeof N == "number" ? N : N(ge.current);
			he.current = window.setTimeout(() => Re(e), t);
		}
	}, ze = (e, t) => {
		e.preventDefault(), pe.current?.focus(), Le(t), fe && (he.current = window.setTimeout(() => Re(t), P));
	}, Be = () => {
		he.current && window.clearTimeout(he.current), he.current = null, ge.current = 0;
	}, Ve = /* @__PURE__ */ E("div", {
		...B("controls"),
		children: [/* @__PURE__ */ T(Di, {
			...B("control"),
			tabIndex: -1,
			"aria-hidden": !0,
			disabled: O || typeof W == "number" && ve !== void 0 && W >= ve || typeof W == "bigint" && Se !== void 0 && W >= Se,
			mod: { direction: "up" },
			onMouseDown: (e) => e.preventDefault(),
			onPointerDown: (e) => {
				ze(e, !0);
			},
			onPointerUp: Be,
			onPointerLeave: Be,
			children: /* @__PURE__ */ T(su, { direction: "up" })
		}), /* @__PURE__ */ T(Di, {
			...B("control"),
			tabIndex: -1,
			"aria-hidden": !0,
			disabled: O || typeof W == "number" && _e !== void 0 && W <= _e || typeof W == "bigint" && xe !== void 0 && W <= xe,
			mod: { direction: "down" },
			onMouseDown: (e) => e.preventDefault(),
			onPointerDown: (e) => {
				ze(e, !1);
			},
			onPointerUp: Be,
			onPointerLeave: Be,
			children: /* @__PURE__ */ T(su, { direction: "down" })
		})]
	});
	return /* @__PURE__ */ T(ys, {
		component: nu,
		allowNegative: ee,
		className: dt(cu.root, n),
		size: j,
		...oe,
		inputMode: ue ? "numeric" : "decimal",
		readOnly: A,
		disabled: O,
		value: typeof W == "bigint" ? W.toString() : W,
		getInputRef: Qe(ae, pe),
		onValueChange: De,
		rightSection: m || A || !(ue ? _u(W, se) : hu(W)) ? h : h || Ve,
		classNames: V,
		styles: H,
		unstyled: a,
		__staticSelector: "NumberInput",
		decimalScale: ue ? 0 : b ? x : 0,
		onPaste: Me,
		onFocus: Fe,
		onKeyDown: Ne,
		onKeyDownCapture: Pe,
		rightSectionPointerEvents: k ?? (O ? "none" : void 0),
		rightSectionWidth: M ?? `var(--ni-right-section-width-${j || "sm"})`,
		allowLeadingZeros: te,
		allowedDecimalSeparators: I,
		onBlur: Ie,
		attributes: ie,
		isAllowed: (e) => {
			if (g && !g(e)) return !1;
			if (_ !== "strict") return !0;
			if (!ue) return Cu(e.floatValue, _e, ve);
			if (e.value === "" || e.value === "-") return !0;
			let t = vu(e.value);
			return t === null || (xe === void 0 || t >= xe) && (Se === void 0 || t <= Se);
		}
	});
});
ku.classes = {
	...ys.classes,
	...cu
}, ku.varsResolver = Tu, ku.displayName = "@mantine/core/NumberInput";
// node_modules/@mantine/core/esm/components/SimpleGrid/SimpleGridVariables.mjs
function Au(e) {
	if (e !== void 0) return typeof e == "number" ? P(e) : e;
}
function ju({ spacing: e, verticalSpacing: t, cols: n, minColWidth: r, autoRows: i, selector: a }) {
	let o = pn(), s = t === void 0 ? e : t, c = r !== void 0, l = ne({
		"--sg-spacing-x": V(pe(e)),
		"--sg-spacing-y": V(pe(s)),
		"--sg-auto-rows": i,
		...c ? { "--sg-min-col-width": Au(r) } : { "--sg-cols": pe(n)?.toString() }
	}), u = D(o.breakpoints).reduce((t, r) => (t[r] || (t[r] = {}), typeof e == "object" && e[r] !== void 0 && (t[r]["--sg-spacing-x"] = V(e[r])), typeof s == "object" && s[r] !== void 0 && (t[r]["--sg-spacing-y"] = V(s[r])), !c && typeof n == "object" && n[r] !== void 0 && (t[r]["--sg-cols"] = n[r]), t), {}), d = fe(D(u), o.breakpoints).filter((e) => D(u[e.value]).length > 0).map((e) => ({
		query: `(min-width: ${o.breakpoints[e.value]})`,
		styles: u[e.value]
	}));
	return /* @__PURE__ */ T(Jn, {
		styles: l,
		media: d,
		selector: a
	});
}
function Mu(e) {
	return typeof e == "object" && e ? D(e) : [];
}
function Nu(e) {
	return e.sort((e, t) => j(e) - j(t));
}
function Pu({ spacing: e, verticalSpacing: t, cols: n, minColWidth: r }) {
	return Nu(Array.from(/* @__PURE__ */ new Set([
		...Mu(e),
		...Mu(t),
		...r === void 0 ? Mu(n) : []
	])));
}
function Fu({ spacing: e, verticalSpacing: t, cols: n, minColWidth: r, autoRows: i, selector: a }) {
	let o = t === void 0 ? e : t, s = r !== void 0, c = ne({
		"--sg-spacing-x": V(pe(e)),
		"--sg-spacing-y": V(pe(o)),
		"--sg-auto-rows": i,
		...s ? { "--sg-min-col-width": Au(r) } : { "--sg-cols": pe(n)?.toString() }
	}), l = Pu({
		spacing: e,
		verticalSpacing: t,
		cols: n,
		minColWidth: r
	}), u = l.reduce((t, r) => (t[r] || (t[r] = {}), typeof e == "object" && e[r] !== void 0 && (t[r]["--sg-spacing-x"] = V(e[r])), typeof o == "object" && o[r] !== void 0 && (t[r]["--sg-spacing-y"] = V(o[r])), !s && typeof n == "object" && n[r] !== void 0 && (t[r]["--sg-cols"] = n[r]), t), {}), d = l.map((e) => ({
		query: `simple-grid (min-width: ${e})`,
		styles: u[e]
	}));
	return /* @__PURE__ */ T(Jn, {
		styles: c,
		container: d,
		selector: a
	});
}
// node_modules/@mantine/core/esm/components/SimpleGrid/SimpleGrid.module.mjs
var Iu = {
	container: "m_925c2d2c",
	root: "m_2415a157"
}, Lu = {
	cols: 1,
	spacing: "md",
	type: "media"
}, Ru = J((e) => {
	let t = K("SimpleGrid", Lu, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, cols: c, verticalSpacing: l, spacing: u, type: d, minColWidth: f, autoFlow: p, autoRows: m, attributes: h, ...g } = t, _ = q({
		name: "SimpleGrid",
		classes: Iu,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: h,
		vars: s
	}), v = br(), y = f === void 0 ? void 0 : p || "auto-fill";
	return d === "container" ? /* @__PURE__ */ E(w, { children: [/* @__PURE__ */ T(Fu, {
		...t,
		selector: `.${v}`
	}), /* @__PURE__ */ T("div", {
		..._("container"),
		children: /* @__PURE__ */ T(Y, {
			..._("root", { className: v }),
			...g,
			"data-auto-cols": y
		})
	})] }) : /* @__PURE__ */ E(w, { children: [/* @__PURE__ */ T(ju, {
		...t,
		selector: `.${v}`
	}), /* @__PURE__ */ T(Y, {
		..._("root", { className: v }),
		...g,
		"data-auto-cols": y
	})] });
});
Ru.classes = Iu, Ru.displayName = "@mantine/core/SimpleGrid";
// node_modules/@mantine/core/esm/components/Stack/Stack.module.mjs
var zu = { root: "m_6d731127" }, Bu = {
	gap: "md",
	align: "stretch",
	justify: "flex-start"
}, Vu = G((e, { gap: t, align: n, justify: r }) => ({ root: {
	"--stack-gap": V(t),
	"--stack-align": n,
	"--stack-justify": r
} })), Q = J((e) => {
	let t = K("Stack", Bu, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, align: c, justify: l, gap: u, variant: d, attributes: f, ...p } = t, m = q({
		name: "Stack",
		props: t,
		classes: zu,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: f,
		vars: s,
		varsResolver: Vu
	});
	return /* @__PURE__ */ T(Y, {
		...m("root"),
		variant: d,
		...p
	});
});
Q.classes = zu, Q.varsResolver = Vu, Q.displayName = "@mantine/core/Stack";
// node_modules/@mantine/core/esm/components/Table/Table.context.mjs
var [Hu, Uu] = re("Table component was not found in the tree"), Wu = {
	table: "m_b23fa0ef",
	th: "m_4e7aa4f3",
	tr: "m_4e7aa4fd",
	td: "m_4e7aa4ef",
	tbody: "m_b2404537",
	thead: "m_b242d975",
	caption: "m_9e5a3ac7",
	scrollContainer: "m_a100c15",
	scrollContainerInner: "m_62259741"
};
// node_modules/@mantine/core/esm/components/Table/Table.components.mjs
function Gu(e, t) {
	if (!t) return;
	let n = {};
	return t.columnBorder && e.withColumnBorders && (n["data-with-column-border"] = !0), t.rowBorder && e.withRowBorders && (n["data-with-row-border"] = !0), t.striped && e.striped && (n["data-striped"] = e.striped), t.highlightOnHover && e.highlightOnHover && (n["data-hover"] = !0), t.captionSide && e.captionSide && (n["data-side"] = e.captionSide), t.stickyHeader && e.stickyHeader && (n["data-sticky"] = !0), n;
}
function Ku(e, t) {
	let n = `Table${e.charAt(0).toUpperCase()}${e.slice(1)}`, r = J((r) => {
		let i = K(n, {}, r), { classNames: a, className: o, style: s, styles: c, ...l } = i, u = Uu();
		return /* @__PURE__ */ T(Y, {
			component: e,
			...Gu(u, t),
			...u.getStyles(e, {
				className: o,
				classNames: a,
				style: s,
				styles: c,
				props: i
			}),
			...l
		});
	});
	return r.displayName = `@mantine/core/${n}`, r.classes = Wu, r;
}
var qu = Ku("th", { columnBorder: !0 }), Ju = Ku("td", { columnBorder: !0 }), Yu = Ku("tr", {
	rowBorder: !0,
	striped: !0,
	highlightOnHover: !0
}), Xu = Ku("thead", { stickyHeader: !0 }), Zu = Ku("tbody"), Qu = Ku("tfoot"), $u = Ku("caption", { captionSide: !0 }), ed = { type: "scrollarea" }, td = G((e, { minWidth: t, maxHeight: n, type: r }) => ({ scrollContainer: {
	"--table-min-width": P(t),
	"--table-max-height": P(n),
	"--table-overflow": r === "native" ? "auto" : void 0
} })), nd = J((e) => {
	let t = K("TableScrollContainer", ed, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, children: c, minWidth: l, maxHeight: u, type: d, scrollAreaProps: f, attributes: p, ...m } = t, h = q({
		name: "TableScrollContainer",
		classes: Wu,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: p,
		vars: s,
		varsResolver: td,
		rootSelector: "scrollContainer"
	});
	return /* @__PURE__ */ T(Y, {
		component: d === "scrollarea" ? Ci : "div",
		...d === "scrollarea" ? u ? {
			offsetScrollbars: "xy",
			...f
		} : {
			offsetScrollbars: "x",
			...f
		} : {},
		...h("scrollContainer"),
		...m,
		children: /* @__PURE__ */ T("div", {
			...h("scrollContainerInner"),
			children: c
		})
	});
});
nd.classes = Wu, nd.varsResolver = td, nd.displayName = "@mantine/core/TableScrollContainer";
// node_modules/@mantine/core/esm/components/Table/TableDataRenderer.mjs
function rd({ data: e }) {
	return /* @__PURE__ */ E(w, { children: [
		e.caption && /* @__PURE__ */ T($u, { children: e.caption }),
		e.head && /* @__PURE__ */ T(Xu, { children: /* @__PURE__ */ T(Yu, { children: e.head.map((e, t) => /* @__PURE__ */ T(qu, { children: e }, t)) }) }),
		e.body && /* @__PURE__ */ T(Zu, { children: e.body.map((e, t) => /* @__PURE__ */ T(Yu, { children: e.map((e, t) => /* @__PURE__ */ T(Ju, { children: e }, t)) }, t)) }),
		e.foot && /* @__PURE__ */ T(Qu, { children: /* @__PURE__ */ T(Yu, { children: e.foot.map((e, t) => /* @__PURE__ */ T(qu, { children: e }, t)) }) })
	] });
}
rd.displayName = "@mantine/core/TableDataRenderer";
// node_modules/@mantine/core/esm/components/Table/Table.mjs
var id = {
	withRowBorders: !0,
	verticalSpacing: 7
}, ad = G((e, { layout: t, captionSide: n, horizontalSpacing: r, verticalSpacing: i, borderColor: a, stripedColor: o, highlightOnHoverColor: s, striped: c, highlightOnHover: l, stickyHeaderOffset: u, stickyHeader: d }) => ({ table: {
	"--table-layout": t,
	"--table-caption-side": n,
	"--table-horizontal-spacing": V(r),
	"--table-vertical-spacing": V(i),
	"--table-border-color": a ? kt(a, e) : void 0,
	"--table-striped-color": c && o ? kt(o, e) : void 0,
	"--table-highlight-on-hover-color": l && s ? kt(s, e) : void 0,
	"--table-sticky-header-offset": d ? P(u) : void 0
} })), $ = J((e) => {
	let t = K("Table", id, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, horizontalSpacing: c, verticalSpacing: l, captionSide: u, stripedColor: d, highlightOnHoverColor: f, striped: p, highlightOnHover: m, withColumnBorders: h, withRowBorders: g, withTableBorder: v, borderColor: y, layout: b, data: x, children: S, stickyHeader: C, stickyHeaderOffset: w, mod: E, tabularNums: D, attributes: O, ...k } = t, ee = q({
		name: "Table",
		props: t,
		className: r,
		style: i,
		classes: Wu,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: O,
		rootSelector: "table",
		vars: s,
		varsResolver: ad,
		stable: !0
	}), A = p === !0 ? "odd" : p || void 0, j = u || "bottom", M = _(() => ({
		getStyles: ee,
		stickyHeader: C,
		striped: A,
		highlightOnHover: m,
		withColumnBorders: h,
		withRowBorders: g,
		captionSide: j
	}), [
		ee,
		C,
		A,
		m,
		h,
		g,
		j
	]);
	return /* @__PURE__ */ T(Hu, {
		value: M,
		children: /* @__PURE__ */ T(Y, {
			component: "table",
			mod: [{
				withTableBorder: v,
				tabularNums: D
			}, E],
			...ee("table"),
			...k,
			children: S || !!x && /* @__PURE__ */ T(rd, { data: x })
		})
	});
});
$.classes = Wu, $.varsResolver = ad, $.displayName = "@mantine/core/Table", $.Td = Ju, $.Th = qu, $.Tr = Yu, $.Thead = Xu, $.Tbody = Zu, $.Tfoot = Qu, $.Caption = $u, $.ScrollContainer = nd, $.DataRenderer = rd;
// node_modules/@mantine/core/esm/components/TextInput/TextInput.mjs
var od = J((e) => {
	let t = K([
		"Input",
		"InputWrapper",
		"TextInput"
	], null, e);
	return /* @__PURE__ */ T(ys, {
		component: "input",
		...t,
		__staticSelector: "TextInput"
	});
});
od.classes = ys.classes, od.displayName = "@mantine/core/TextInput";
// node_modules/@mantine/core/esm/components/Title/get-title-size.mjs
var sd = [
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6"
], cd = [
	"xs",
	"sm",
	"md",
	"lg",
	"xl"
];
function ld(e, t) {
	let n = t === void 0 ? `h${e}` : t;
	return sd.includes(n) ? {
		fontSize: `var(--mantine-${n}-font-size)`,
		fontWeight: `var(--mantine-${n}-font-weight)`,
		lineHeight: `var(--mantine-${n}-line-height)`
	} : cd.includes(n) ? {
		fontSize: `var(--mantine-font-size-${n})`,
		fontWeight: `var(--mantine-h${e}-font-weight)`,
		lineHeight: `var(--mantine-h${e}-line-height)`
	} : {
		fontSize: P(n),
		fontWeight: `var(--mantine-h${e}-font-weight)`,
		lineHeight: `var(--mantine-h${e}-line-height)`
	};
}
// node_modules/@mantine/core/esm/components/Title/Title.module.mjs
var ud = { root: "m_8a5d1357" }, dd = { order: 1 }, fd = G((e, { order: t, size: n, lineClamp: r, textWrap: i }) => {
	let a = ld(t || 1, n);
	return { root: {
		"--title-fw": a.fontWeight,
		"--title-lh": a.lineHeight,
		"--title-fz": a.fontSize,
		"--title-line-clamp": typeof r == "number" ? r.toString() : void 0,
		"--title-text-wrap": i
	} };
}), pd = J((e) => {
	let t = K("Title", dd, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, order: s, vars: c, size: l, variant: u, lineClamp: d, textWrap: f, mod: p, attributes: m, ...h } = t, g = q({
		name: "Title",
		props: t,
		classes: ud,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: m,
		vars: c,
		varsResolver: fd
	});
	return [
		1,
		2,
		3,
		4,
		5,
		6
	].includes(s) ? /* @__PURE__ */ T(Y, {
		...g("root"),
		component: `h${s}`,
		variant: u,
		mod: [{
			order: s,
			lineClamp: typeof d == "number"
		}, p],
		size: l,
		...h
	}) : null;
});
pd.classes = ud, pd.varsResolver = fd, pd.displayName = "@mantine/core/Title";
// src/api/sourceNames.ts
var md = {
	human: "Your override",
	ml: "Goldilocks-ML prediction",
	llm: "LLM suggestion",
	heuristic: "Heuristic default"
}, hd = "linear-gradient(90deg, #ff4a22, #7a64ff, #005de4, #08c2d3)";
function gd({ source: e }) {
	return e === "ml" ? /* @__PURE__ */ T(Y, {
		component: "span",
		fw: 700,
		style: {
			backgroundImage: hd,
			backgroundClip: "text",
			WebkitBackgroundClip: "text",
			color: "transparent"
		},
		children: md.ml
	}) : /* @__PURE__ */ T(w, { children: md[e] });
}
// src/review/warnings.ts
function _d(e) {
	return typeof e == "object" && !!e && "code" in e && "level" in e && "category" in e && "message" in e && typeof e.message == "string";
}
var vd = {
	info: "blue.8",
	warning: "yellow",
	error: "red"
}, yd = (e) => e?.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
// node_modules/lucide-react/dist/esm/shared/src/utils/toLucideIconData.mjs
function bd(e, t, n = []) {
	if (t == null) throw Error("[lucide]: iconNode is required when icon name is used");
	return {
		name: yd(e),
		size: 24,
		node: t,
		...n.length > 0 ? { aliases: n } : {}
	};
}
// node_modules/lucide-react/dist/esm/shared/src/utils/toCamelCase.mjs
var xd = (e) => {
	let t = "", n = !1;
	for (let r of e) r === "-" || r === "_" || r <= " " ? n = t.length > 0 : (t.length === 0 ? t += r.toLowerCase() : t += n ? r.toUpperCase() : r, n = !1);
	return t;
}, Sd = (e) => {
	let t = xd(e);
	return t.charAt(0).toUpperCase() + t.slice(1);
}, Cd = (...e) => e.filter((e, t, n) => !!e && e.trim() !== "" && n.indexOf(e) === t).join(" ").trim(), wd = {
	xmlns: "http://www.w3.org/2000/svg",
	width: 24,
	height: 24,
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	"stroke-width": 2,
	"stroke-linecap": "round",
	"stroke-linejoin": "round"
};
// node_modules/lucide-react/dist/esm/shared/src/build/buildLucideIconNode.mjs
function Td(e) {
	return e != null;
}
function Ed(e, t = {}) {
	let n = t.attributeNames ?? {}, r = (e) => n[e] ?? e, i = e.size ?? e.width ?? wd.width, a = e.size ?? e.height ?? wd.height, o = e.aliases?.filter((e) => typeof e == "string" && e.trim() !== "").map((e) => `lucide-${e}`) ?? [], s = [...e.name ? [`lucide-${e.name}`] : [], ...o], c = t.className?.split(" ").filter(Boolean) ?? [], l = t.includeDefaultClasses === !1 ? Cd(...c) : Cd("lucide", ...s, ...c), u = t.absoluteStrokeWidth ? Number(t.strokeWidth ?? wd["stroke-width"]) * Number(e.size ?? e.width ?? wd.width) / Number(t.size ?? t.width ?? wd.width) : t.strokeWidth ?? wd["stroke-width"];
	return [
		"svg",
		{
			...Object.entries(wd).reduce((e, [t, n]) => (e[r(t)] = n, e), {}),
			..."color" in t && t.color && { [r("stroke")]: t.color },
			..."size" in t && Td(t.size) && {
				[r("width")]: t.size,
				[r("height")]: t.size
			},
			..."width" in t && Td(t.width) && { [r("width")]: t.width },
			..."height" in t && Td(t.height) && { [r("height")]: t.height },
			[r("stroke-width")]: u,
			...l && { [r("class")]: l },
			[r("viewBox")]: `0 0 ${i} ${a}`,
			...t.hasA11yProp === !1 ? { [r("aria-hidden")]: "true" } : {},
			..."attributes" in t && t.attributes
		},
		e.node.map((e) => {
			let [n, i, a] = e, o = t.nonScalingStroke ? {
				[r("vector-effect")]: "non-scaling-stroke",
				...i
			} : i;
			return a ? [
				n,
				o,
				a
			] : [n, o];
		})
	];
}
// node_modules/lucide-react/dist/esm/shared/src/build/buildLucideIconForReact.mjs
function Dd(e, t = {}) {
	return Ed(e, {
		...t,
		attributeNames: {
			...t.attributeNames,
			class: "className",
			"stroke-width": "strokeWidth",
			"stroke-linecap": "strokeLinecap",
			"stroke-linejoin": "strokeLinejoin",
			"vector-effect": "vectorEffect"
		}
	});
}
// node_modules/lucide-react/dist/esm/shared/src/utils/hasA11yProp.mjs
var Od = (e) => {
	for (let t in e) if (t.startsWith("aria-") || t === "role" || t === "title") return !0;
	return !1;
}, kd = s({}), Ad = () => f(kd), jd = l(({ color: e, size: t, width: n, height: r, strokeWidth: i, absoluteStrokeWidth: a, nonScalingStroke: o, className: s = "", children: l, iconNode: u = [], icon: d = {
	node: u,
	aliases: [],
	size: 24
}, ...f }, p) => {
	let { size: m = 24, strokeWidth: h = 2, absoluteStrokeWidth: g = !1, nonScalingStroke: _ = !1, color: v = "currentColor", className: y = "" } = Ad() ?? {}, b = !!l || Od(f), [x, S, C = []] = Dd(d, {
		color: e ?? v,
		width: n ?? t ?? m,
		height: r ?? t ?? m,
		strokeWidth: i ?? h,
		absoluteStrokeWidth: a ?? g,
		nonScalingStroke: o ?? _,
		className: Cd(y, s),
		hasA11yProp: b,
		attributes: f
	});
	return c(x, {
		ref: p,
		...S
	}, [...C.map(([e, t]) => c(e, t)), ...Array.isArray(l) ? l : [l]]);
});
// node_modules/lucide-react/dist/esm/createLucideIcon.mjs
function Md(e, t = [], n = []) {
	let r = typeof e == "string" ? bd(e, t, n) : e, i = l(({ className: e, ...t }, n) => c(jd, {
		ref: n,
		icon: r,
		className: e,
		...t
	}));
	return r.name && (i.displayName = Sd(r.name)), i;
}
// node_modules/lucide-react/dist/esm/icons/atom.mjs
var Nd = {
	name: "atom",
	size: 24,
	node: [
		["circle", {
			cx: "12",
			cy: "12",
			r: "1",
			key: "41hilf"
		}],
		["path", {
			d: "M20.2 20.2c2.04-2.03.02-7.36-4.5-11.9-4.54-4.52-9.87-6.54-11.9-4.5-2.04 2.03-.02 7.36 4.5 11.9 4.54 4.52 9.87 6.54 11.9 4.5Z",
			key: "1l2ple"
		}],
		["path", {
			d: "M15.7 15.7c4.52-4.54 6.54-9.87 4.5-11.9-2.03-2.04-7.36-.02-11.9 4.5-4.52 4.54-6.54 9.87-4.5 11.9 2.03 2.04 7.36.02 11.9-4.5Z",
			key: "1wam0m"
		}]
	]
};
Nd.node;
var Pd = Md(Nd), Fd = {
	name: "download",
	size: 24,
	node: [
		["path", {
			d: "M12 15V3",
			key: "m9g1x1"
		}],
		["path", {
			d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
			key: "ih7n3h"
		}],
		["path", {
			d: "m7 10 5 5 5-5",
			key: "brsn70"
		}]
	]
};
Fd.node;
var Id = Md(Fd), Ld = {
	name: "info",
	size: 24,
	node: [
		["circle", {
			cx: "12",
			cy: "12",
			r: "10",
			key: "1mglay"
		}],
		["path", {
			d: "M12 16v-4",
			key: "1dtifu"
		}],
		["path", {
			d: "M12 8h.01",
			key: "e9boi3"
		}]
	]
};
Ld.node;
var Rd = Md(Ld), zd = {
	name: "moon",
	size: 24,
	node: [["path", {
		d: "M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401",
		key: "kfwtm"
	}]]
};
zd.node;
var Bd = Md(zd), Vd = {
	name: "rotate-cw",
	size: 24,
	node: [["path", {
		d: "M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8",
		key: "1p45f6"
	}], ["path", {
		d: "M21 3v5h-5",
		key: "1q7to0"
	}]]
};
Vd.node;
var Hd = Md(Vd), Ud = {
	name: "sun",
	size: 24,
	node: [
		["circle", {
			cx: "12",
			cy: "12",
			r: "4",
			key: "4exip2"
		}],
		["path", {
			d: "M12 2v2",
			key: "tus03m"
		}],
		["path", {
			d: "M12 20v2",
			key: "1lh1kg"
		}],
		["path", {
			d: "m4.93 4.93 1.41 1.41",
			key: "149t6j"
		}],
		["path", {
			d: "m17.66 17.66 1.41 1.41",
			key: "ptbguv"
		}],
		["path", {
			d: "M2 12h2",
			key: "1t8f8n"
		}],
		["path", {
			d: "M20 12h2",
			key: "1q8mjw"
		}],
		["path", {
			d: "m6.34 17.66-1.41 1.41",
			key: "1m8zz5"
		}],
		["path", {
			d: "m19.07 4.93-1.41 1.41",
			key: "1shlcs"
		}]
	]
};
Ud.node;
var Wd = Md(Ud), Gd = {
	name: "upload",
	size: 24,
	node: [
		["path", {
			d: "M12 3v12",
			key: "1x0j5s"
		}],
		["path", {
			d: "m17 8-5-5-5 5",
			key: "7q97r8"
		}],
		["path", {
			d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
			key: "ih7n3h"
		}]
	]
};
Gd.node;
var Kd = Md(Gd), qd = "5", Jd = class extends Error {
	kind;
	details;
	status;
	rawResponse;
	constructor(e, t, n = {}, r = null, i) {
		super(t), this.kind = e, this.details = n, this.status = r, this.rawResponse = i, this.name = "CoreFailure";
	}
}, Yd = class {
	fetcher;
	baseUrl;
	constructor(e = "", t = globalThis.fetch.bind(globalThis)) {
		this.fetcher = t, this.baseUrl = e.replace(/\/$/, "");
	}
	async capabilities() {
		let e = await Xd(await this.request("/capabilities", {
			headers: { Accept: "application/json" },
			method: "GET"
		}));
		if (e.vocabulary_version !== qd) throw new Jd("incompatible_vocabulary", `Goldilocks Core reports vocabulary_version ${e.vocabulary_version}, but this Workbench build expects ${qd}. The frontend and backend were built against different contracts -- regenerate the Workbench's API types against this server.`, { serverVocabularyVersion: e.vocabulary_version });
		return e;
	}
	async inspectStructure(e) {
		return Zd(await this.request("/inspect", {
			body: JSON.stringify(e),
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json"
			},
			method: "POST"
		}));
	}
	async explain(e) {
		return Xd(await this.request("/explain", {
			body: JSON.stringify(e),
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json"
			},
			method: "POST"
		}));
	}
	async magneticOrderings(e, t) {
		return Xd(await this.request("/magnetic-orderings", {
			body: JSON.stringify(e),
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json"
			},
			method: "POST",
			signal: t ?? null
		}));
	}
	async submitRanking(e, t) {
		return Xd(await this.request("/magnetic-orderings/rank", {
			body: JSON.stringify(e),
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json"
			},
			method: "POST",
			signal: t ?? null
		}));
	}
	async rankingStatus(e, t) {
		return Xd(await this.request(`/magnetic-orderings/rank/${encodeURIComponent(e)}`, {
			headers: { Accept: "application/json" },
			method: "GET",
			signal: t ?? null
		}));
	}
	async cancelRanking(e) {
		await this.request(`/magnetic-orderings/rank/${encodeURIComponent(e)}`, { method: "DELETE" });
	}
	async run(e) {
		return Xd(await this.request("/run", {
			body: JSON.stringify({
				...e,
				respond_with: "json"
			}),
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json"
			},
			method: "POST"
		}));
	}
	async runArchive(e) {
		return of(await this.request("/run", {
			body: JSON.stringify({
				...e,
				respond_with: "archive"
			}),
			headers: {
				Accept: "application/zip",
				"Content-Type": "application/json"
			},
			method: "POST"
		}), e);
	}
	async request(e, t) {
		let n;
		try {
			n = await this.fetcher(`${this.baseUrl}${e}`, t);
		} catch (e) {
			throw t.signal?.aborted ? e : new Jd("network_error", e instanceof Error ? `Cannot reach Goldilocks Core: ${e.message}` : "Cannot reach Goldilocks Core.");
		}
		return await $d(n), n;
	}
};
async function Xd(e) {
	if (!(e.headers.get("content-type") ?? "").toLowerCase().startsWith("application/json")) {
		let t = await ef(e);
		throw cf(e.status, "returned an invalid JSON response", t);
	}
	try {
		return await e.json();
	} catch {
		throw cf(e.status, "returned unreadable JSON");
	}
}
async function Zd(e) {
	let t = await Xd(e);
	return Qd(t, e.status), t;
}
function Qd(e, t) {
	if (typeof e != "object" || !e || !("schema_version" in e) || e.schema_version !== 1) throw cf(t, "returned an incompatible schema version", e);
}
async function $d(e) {
	if (e.ok) return;
	let t = await ef(e);
	if (af(t)) {
		let { error: n } = t;
		throw new Jd(n.kind, n.message, n.details ?? {}, e.status, t);
	}
	throw new Jd("http_error", `The Goldilocks Core server rejected the request (${String(e.status)}).`, { status: e.status }, e.status, t);
}
async function ef(e) {
	let t = await e.text();
	try {
		return JSON.parse(t);
	} catch {
		return t;
	}
}
function tf(e) {
	let t = e.details.findings;
	return Array.isArray(t) ? t.filter(nf) : [];
}
function nf(e) {
	return typeof e == "object" && !!e && "code" in e && typeof e.code == "string" && "message" in e && typeof e.message == "string" && "summary" in e && typeof e.summary == "string" && "fields" in e && Array.isArray(e.fields) && e.fields.every((e) => typeof e == "string") && "remedies" in e && Array.isArray(e.remedies) && e.remedies.every(rf);
}
function rf(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function af(e) {
	if (typeof e != "object" || !e || !("error" in e)) return !1;
	let t = e.error;
	return typeof t == "object" && !!t && "kind" in t && typeof t.kind == "string" && "message" in t && typeof t.message == "string";
}
async function of(e, t) {
	if (!(e.headers.get("content-type") ?? "").toLowerCase().startsWith("application/zip")) throw cf(e.status, "returned an invalid archive response");
	let n;
	try {
		n = await e.blob();
	} catch {
		throw cf(e.status, "returned unreadable archive data");
	}
	return {
		blob: n,
		filename: `${sf(t)}.zip`
	};
}
function sf(e) {
	let t = e.structure_name.replace(/[^a-zA-Z0-9._-]+/g, "_"), n = e.task;
	return t.length > 0 ? `${t}-${n}` : `goldilocks-${n}`;
}
function cf(e, t, n) {
	return new Jd("invalid_response", `Goldilocks Core ${t}.`, {}, e, n);
}
// src/workspace/pipelineStatus.ts
function lf(e, t) {
	if (t === null) return null;
	let { input: n, revision: r } = t.key;
	return n === e.structureInput && r === e.revision ? t : null;
}
function uf(e) {
	return lf(e, e.explain);
}
function df(e) {
	return lf(e, e.preview);
}
function ff(e) {
	let t = df(e);
	return t?.status === "result" ? t.value : null;
}
function pf(e) {
	let t = uf(e);
	if (t?.status === "result" && t.value.blocking.length > 0) return t.value.blocking;
	let n = df(e);
	return n?.status === "failure" ? tf(n.failure) : [];
}
function mf(e) {
	return e.structureInput !== null && e.draft !== null && e.operation === null && uf(e) === null;
}
function hf(e) {
	let t = uf(e);
	return e.operation === null && t?.status === "result" && t.value.blocking.length === 0 && df(e) === null;
}
function gf(e) {
	return e?.status === "failure" ? e : null;
}
function _f(e, t) {
	switch (t) {
		case "capabilities": return e.startupFailure === null ? null : {
			failure: e.startupFailure,
			dismissed: !1
		};
		case "inspect": return e.inspectFailure === null ? null : {
			failure: e.inspectFailure.failure,
			dismissed: !1
		};
		case "explain": return gf(uf(e));
		case "preview": return gf(df(e));
	}
}
var vf = [
	"capabilities",
	"inspect",
	"explain",
	"preview"
];
function yf(e) {
	for (let t of vf) {
		let n = _f(e, t);
		if (n !== null && !n.dismissed) return {
			operation: t,
			failure: n.failure
		};
	}
	return null;
}
function bf(e) {
	if (e.structureInput === null) return { kind: "empty" };
	let t = uf(e);
	if (t === null) return { kind: e.reviewed === null ? "computing" : "recomputing" };
	if (t.status === "failure") return {
		kind: "explainFailed",
		failure: t.failure
	};
	if (t.value.blocking.length > 0) return {
		kind: "blocked",
		findings: t.value.blocking
	};
	let n = df(e);
	return n === null ? { kind: "generating" } : n.status === "result" ? {
		kind: "ready",
		archive: n.value
	} : {
		kind: "generationFailed",
		failure: n.failure
	};
}
function xf(e) {
	let t = bf(e);
	return t.kind === "ready" ? {
		enabled: !0,
		reason: null
	} : {
		enabled: !1,
		reason: Sf(t)
	};
}
function Sf(e) {
	switch (e.kind) {
		case "empty": return "Load a structure to generate input files.";
		case "computing": return "Waiting for the recommendation.";
		case "recomputing": return "Waiting for the recommendation for the current settings.";
		case "explainFailed": return `The recommendation for the current settings failed: ${e.failure.message}`;
		case "blocked": return `Input files cannot be generated for the current settings: ${Cf(e.findings)}`;
		case "generating": return "Generating the input files for the current settings.";
		case "generationFailed": {
			let t = tf(e.failure);
			return `Input generation failed for the current settings: ${t.length === 0 ? e.failure.message : Cf(t)}`;
		}
	}
}
function Cf(e) {
	return e.map((e) => e.summary).join(" ");
}
function wf(e) {
	if (e.startupFailure !== null || e.inspectFailure !== null) return !0;
	let { kind: t } = bf(e);
	return t === "explainFailed" || t === "blocked" || t === "generationFailed";
}
// src/workspace/workspaceContext.ts
var Tf = s(null);
// src/workspace/useWorkspace.ts
function Ef() {
	let e = f(Tf);
	if (e === null) throw Error("useWorkspace must be rendered inside WorkspaceProvider");
	return e;
}
function Df() {
	let e = Ef(), t = d((t) => e.subscribe(t), [e]), n = d(() => e.getSnapshot(), [e]);
	return b(t, n, n);
}
// src/status/FindingNote.tsx
function Of(e) {
	return `Apply ${Object.entries(e).map(([e, t]) => `${e} = ${t === null ? "automatic" : kf(t)}`).join(", ")}`;
}
function kf(e) {
	return typeof e == "string" ? e : JSON.stringify(e);
}
var Af = {
	root: {
		display: "inline-flex",
		alignItems: "center",
		height: "auto",
		paddingBlock: "0.3125rem"
	},
	label: {
		whiteSpace: "normal",
		lineHeight: 1.3
	}
};
function jf({ finding: e }) {
	let t = Ef();
	return e.remedies.length === 0 ? null : /* @__PURE__ */ T(X, {
		gap: "xs",
		children: e.remedies.map((e) => {
			let n = Of(e);
			return /* @__PURE__ */ T(wc, {
				size: "xs",
				variant: "light",
				styles: Af,
				onClick: () => void t.dispatch({
					type: "draft.patch",
					overrides: Object.fromEntries(Object.entries(e).map(([e, t]) => [e, t ?? void 0]))
				}),
				children: n
			}, n);
		})
	});
}
function Mf(e) {
	return JSON.stringify([e.code, e.message]);
}
function Nf({ findings: e }) {
	return /* @__PURE__ */ T(qc, {
		size: "sm",
		spacing: "xs",
		children: e.map((e) => /* @__PURE__ */ T(qc.Item, { children: /* @__PURE__ */ T(Pf, { finding: e }) }, Mf(e)))
	});
}
function Pf({ finding: e }) {
	let [t, n] = y(!1), r = h();
	return /* @__PURE__ */ E(Q, {
		gap: 4,
		align: "flex-start",
		children: [
			/* @__PURE__ */ E(X, {
				gap: 4,
				wrap: "nowrap",
				align: "flex-start",
				children: [/* @__PURE__ */ T(Z, {
					size: "sm",
					children: e.summary
				}), /* @__PURE__ */ T(fa, {
					variant: "subtle",
					color: "gray",
					"aria-expanded": t,
					"aria-controls": r,
					"aria-label": t ? "Hide the details" : "Show the details",
					title: t ? "Hide the details" : "Show the details",
					onClick: () => {
						n(!t);
					},
					children: /* @__PURE__ */ T(Rd, {
						"aria-hidden": "true",
						size: 16
					})
				})]
			}),
			/* @__PURE__ */ T(Z, {
				id: r,
				size: "xs",
				hidden: !t,
				children: e.message
			}),
			/* @__PURE__ */ T(jf, { finding: e })
		]
	});
}
function Ff({ field: e }) {
	let t = pf(Df()).filter((t) => t.fields.includes(e));
	return t.length === 0 ? null : /* @__PURE__ */ T(Z, {
		size: "xs",
		c: "red",
		role: "note",
		"aria-label": `Blocks input generation: ${e}`,
		children: t.every((e) => e.remedies.length > 0) ? "Needs confirmation — see Bundle" : "Blocks input generation — see Bundle"
	});
}
// src/workspace/recordGroups.ts
function If(e, t) {
	let n = new Set(t.map((e) => e.key));
	return e.analysis.filter((e) => !n.has(e));
}
function Lf(e, t) {
	let n = (e) => e.filter((e) => !t.has(e)), r = e.steps.map((e) => ({
		name: e.name,
		records: n(e.records)
	})), [i] = r;
	return r.length === 1 && i !== void 0 ? {
		ungrouped: [...n(e.system), ...i.records],
		steps: []
	} : {
		ungrouped: n(e.system),
		steps: r.filter((e) => e.records.length > 0)
	};
}
// src/review/readableName.ts
function Rf(e) {
	return e.replaceAll("_", " ").replace(/\b\w/g, (e) => e.toUpperCase());
}
// src/review/ScientificRecord.tsx
function zf({ field: e }) {
	return e.status === "unavailable" ? /* @__PURE__ */ E(Z, {
		size: "sm",
		c: "dimmed",
		children: ["Unavailable -- ", e.reason ?? "no reason given"]
	}) : e.status === "blocked" ? /* @__PURE__ */ E(Z, {
		size: "sm",
		c: "red",
		children: ["Blocked -- ", e.blocked_by ?? "an upstream field failed"]
	}) : /* @__PURE__ */ E(Q, {
		gap: "xs",
		children: [
			/* @__PURE__ */ T(hc, {
				color: "gray",
				variant: "light",
				style: { alignSelf: "flex-start" },
				children: /* @__PURE__ */ T(gd, { source: e.source ?? "heuristic" })
			}),
			/* @__PURE__ */ T(Vf, { value: e.value }),
			e.field_sources === void 0 || e.field_sources === null ? null : /* @__PURE__ */ T(Bf, { sources: e.field_sources })
		]
	});
}
function Bf({ sources: e }) {
	let t = Object.entries(e);
	return t.length === 0 ? null : /* @__PURE__ */ E($, {
		layout: "fixed",
		verticalSpacing: 4,
		children: [/* @__PURE__ */ T($.Caption, { children: "Per-field sources" }), /* @__PURE__ */ T($.Tbody, { children: t.map(([e, t]) => /* @__PURE__ */ E($.Tr, { children: [/* @__PURE__ */ T($.Th, {
			scope: "row",
			children: Uf(e)
		}), /* @__PURE__ */ T($.Td, { children: /* @__PURE__ */ T(gd, { source: t }) })] }, e)) })]
	});
}
function Vf({ value: e }) {
	if (e == null) return /* @__PURE__ */ T(Z, {
		size: "sm",
		c: "dimmed",
		children: "None"
	});
	if (typeof e == "boolean") return /* @__PURE__ */ T(Z, {
		size: "sm",
		children: e ? "Yes" : "No"
	});
	if (typeof e == "number" || typeof e == "string") return /* @__PURE__ */ T(Z, {
		size: "sm",
		children: String(e)
	});
	if (Array.isArray(e)) {
		let t = e;
		return t.length === 0 ? /* @__PURE__ */ T(Z, {
			size: "sm",
			c: "dimmed",
			children: "Empty"
		}) : t.every((e) => typeof e != "object" || !e) ? /* @__PURE__ */ T(Z, {
			size: "sm",
			children: t.map(String).join(", ")
		}) : /* @__PURE__ */ T(Q, {
			gap: "xs",
			children: t.map((e, t) => /* @__PURE__ */ T(Mi, {
				withBorder: !0,
				p: "xs",
				children: /* @__PURE__ */ T(Vf, { value: e })
			}, t))
		});
	}
	let t = Object.entries(e), n = t.find(([e]) => e === "warnings")?.[1], r = t.filter(([e]) => e !== "warnings");
	return r.length === 0 && !Array.isArray(n) ? /* @__PURE__ */ T(Z, {
		size: "sm",
		c: "dimmed",
		children: "None"
	}) : /* @__PURE__ */ E(Q, {
		gap: "xs",
		children: [r.length === 0 ? null : /* @__PURE__ */ T($, {
			layout: "fixed",
			verticalSpacing: 4,
			style: { overflowWrap: "anywhere" },
			children: /* @__PURE__ */ T($.Tbody, { children: r.map(([e, t]) => /* @__PURE__ */ E($.Tr, { children: [/* @__PURE__ */ T($.Th, {
				scope: "row",
				children: Uf(e)
			}), /* @__PURE__ */ T($.Td, { children: /* @__PURE__ */ T(Vf, { value: t }) })] }, e)) })
		}), /* @__PURE__ */ T(Hf, { warnings: n })]
	});
}
function Hf({ warnings: e }) {
	return !Array.isArray(e) || e.length === 0 ? null : /* @__PURE__ */ T(Q, {
		component: "ul",
		gap: 4,
		m: 0,
		pl: "md",
		children: e.map((e, t) => /* @__PURE__ */ T(Z, {
			component: "li",
			size: "sm",
			children: _d(e) ? e.message : String(e)
		}, t))
	});
}
function Uf(e) {
	return e.replaceAll("_", " ").replace(/\b\w/g, (e) => e.toUpperCase());
}
// src/review/RecordAccordionItem.tsx
var Wf = {
	resolved: "green",
	unavailable: "yellow",
	blocked: "red"
};
function Gf({ name: e, field: t }) {
	return /* @__PURE__ */ E(js.Item, {
		value: e,
		className: "record-card",
		children: [/* @__PURE__ */ T(js.Control, { children: /* @__PURE__ */ E(X, {
			justify: "space-between",
			wrap: "nowrap",
			children: [/* @__PURE__ */ E(X, {
				gap: "xs",
				wrap: "nowrap",
				children: [/* @__PURE__ */ T(hc, {
					size: "xs",
					circle: !0,
					color: Wf[t.status],
					"aria-hidden": "true"
				}), /* @__PURE__ */ T("span", { children: Rf(e) })]
			}), /* @__PURE__ */ T(Dc, { children: e })]
		}) }), /* @__PURE__ */ T(js.Panel, { children: /* @__PURE__ */ T(zf, { field: t }) })]
	});
}
// src/controls/AdvisorRecords.tsx
function Kf({ names: e, records: t }) {
	return /* @__PURE__ */ T(w, { children: e.map((e) => {
		let n = t[e];
		return n === void 0 ? null : /* @__PURE__ */ T(Gf, {
			name: e,
			field: n
		}, e);
	}) });
}
function qf({ step: e, names: t, records: n }) {
	let r = h();
	return /* @__PURE__ */ E(Q, {
		component: "section",
		gap: "xs",
		"aria-labelledby": r,
		children: [/* @__PURE__ */ E(pd, {
			order: 3,
			id: r,
			children: [e, " step"]
		}), /* @__PURE__ */ T(js, {
			multiple: !0,
			transitionDuration: 0,
			classNames: { label: "workbench-accordion-label" },
			children: /* @__PURE__ */ T(Kf, {
				names: t,
				records: n
			})
		})]
	});
}
// src/controls/overrideFieldMeta.tsx
function Jf(e) {
	let t = e.key.replace(/_/g, " ");
	return e.unit ? `${t} · ${e.unit}` : t;
}
var Yf = {
	functional: "Functional",
	pseudo_table_id: "Pseudopotential table",
	k_grid: "K-point grid"
}, Xf = new Map(Object.entries(Yf));
function Zf(e, t) {
	let n = t.find((t) => t.key === e)?.unit ?? null;
	return Xf.get(e) ?? Jf({
		key: e,
		unit: n
	});
}
function Qf(e) {
	return typeof e == "object" && e ? JSON.stringify(e) : String(e);
}
function $f(e) {
	return e.default === void 0 ? "Automatic" : `Automatic (${Qf(e.default)})`;
}
function ep(e, t, n) {
	return t ? /* @__PURE__ */ E(w, { children: [
		e,
		" · ",
		/* @__PURE__ */ T(gd, { source: "human" })
	] }) : n ? /* @__PURE__ */ E(w, { children: [
		e,
		" · ",
		/* @__PURE__ */ T(gd, { source: n })
	] }) : e;
}
// src/controls/OverrideSelect.tsx
function tp({ label: e, description: t, disabled: n, value: r, data: i, pinned: a, onReset: o, onChange: s }) {
	return /* @__PURE__ */ T(pl, {
		label: e,
		description: t,
		disabled: n,
		rightSection: a ? /* @__PURE__ */ T(gs.ClearButton, {
			"aria-label": `Reset ${e} to automatic`,
			disabled: n,
			onMouseDown: (e) => {
				e.preventDefault();
			},
			onClick: () => {
				o();
			}
		}) : void 0,
		value: r,
		data: i,
		onChange: (e) => {
			s(e.currentTarget.value);
		}
	});
}
// src/controls/OverrideControl.tsx
function np({ meta: e, value: t, resolvedValue: n, source: r, disabled: i, onChange: a }) {
	let o = t !== void 0, s = Jf(e), c = ep(e.description, o, r), l = o ? t : n;
	return e.type === "boolean" ? /* @__PURE__ */ T(rp, {
		label: s,
		description: c,
		disabled: i,
		pinned: o,
		value: l,
		onChange: a
	}) : e.enum && e.enum.length > 0 ? /* @__PURE__ */ T(ip, {
		label: s,
		description: c,
		disabled: i,
		pinned: o,
		options: e.enum,
		value: l,
		onChange: a
	}) : e.type === "integer" || e.type === "number" ? /* @__PURE__ */ T(ku, {
		label: s,
		description: c,
		disabled: i,
		placeholder: $f(e),
		value: typeof l == "number" ? l : "",
		onChange: (e) => {
			if (e === "") {
				a(void 0);
				return;
			}
			let t = Number(e);
			Number.isFinite(t) && a(t);
		}
	}) : e.type === "string" ? /* @__PURE__ */ T(od, {
		label: s,
		description: c,
		disabled: i,
		placeholder: $f(e),
		value: typeof l == "string" ? l : "",
		onChange: (e) => {
			let t = e.currentTarget.value;
			a(t === "" ? void 0 : t);
		}
	}) : /* @__PURE__ */ T(ap, {
		label: s,
		description: e.description,
		disabled: i,
		value: t,
		onChange: a
	});
}
function rp({ label: e, description: t, disabled: n, pinned: r, value: i, onChange: a }) {
	let o = typeof i == "boolean" ? Qf(i) : "";
	return /* @__PURE__ */ T(tp, {
		label: e,
		description: t,
		disabled: n,
		pinned: r,
		value: o,
		data: [
			...o === "" ? [{
				value: "",
				label: "—",
				disabled: !0
			}] : [],
			{
				value: "true",
				label: "On"
			},
			{
				value: "false",
				label: "Off"
			}
		],
		onReset: () => {
			a(void 0);
		},
		onChange: (e) => {
			a(e === "true");
		}
	});
}
function ip({ label: e, description: t, disabled: n, pinned: r, options: i, value: a, onChange: o }) {
	let s = typeof a == "string" ? a : "", c = s === "" || !i.includes(s);
	return /* @__PURE__ */ T(tp, {
		label: e,
		description: t,
		disabled: n,
		pinned: r,
		value: s,
		data: [...c ? [{
			value: "",
			label: "—",
			disabled: !0
		}] : [], ...i.map((e) => ({
			value: e,
			label: e
		}))],
		onReset: () => {
			o(void 0);
		},
		onChange: o
	});
}
function ap({ label: e, description: t, disabled: n, value: r, onChange: i }) {
	let [a, o] = y(r), [s, c] = y(r === void 0 ? "" : JSON.stringify(r)), [l, u] = y(null);
	return r !== a && (o(r), c(r === void 0 ? "" : JSON.stringify(r)), u(null)), /* @__PURE__ */ E(Q, {
		gap: 4,
		children: [/* @__PURE__ */ T(Bc, {
			label: e,
			description: `${t} (JSON)`,
			disabled: n,
			placeholder: "Automatic",
			autosize: !0,
			minRows: 1,
			value: s,
			onChange: (e) => {
				let t = e.currentTarget.value;
				if (c(t), t.trim() === "") u(null), i(void 0);
				else try {
					i(JSON.parse(t)), u(null);
				} catch {
					u("Not valid JSON");
				}
			}
		}), l === null ? null : /* @__PURE__ */ T(Z, {
			c: "red",
			size: "xs",
			children: l
		})]
	});
}
// src/controls/resolvedSetting.ts
function op(e, t) {
	return t?.[e.resolved_in.record];
}
function sp(e, t) {
	let { path: n } = e.resolved_in;
	if (t?.status !== "resolved" || n === null) return;
	let r = t.value;
	for (let e of n) {
		if (typeof r != "object" || !r || Array.isArray(r)) return;
		r = r[e];
	}
	return r;
}
function cp(e, t) {
	let n = sp(e, t);
	if (t === void 0 || n == null) return;
	let r = t.source ?? void 0;
	if (e.resolved_in.path?.length === 0) return r;
	let i = t.field_sources?.[e.key];
	return i === void 0 ? r === "human" ? void 0 : r : i;
}
// src/controls/CalculationForm.tsx
var lp = {
	resolved: "green",
	unavailable: "yellow",
	blocked: "red"
}, up = {
	resolved: 0,
	unavailable: 1,
	blocked: 2
}, dp = [
	"k_sampling",
	"pseudo_table_id",
	"functional",
	"vdw",
	"nbnd",
	"convergence"
], fp = { cutoffs: "pseudo_table_id" };
function pp({ hpcProfiles: e, value: t, disabled: n, onChange: r }) {
	let i = e.length === 1 ? e[0] : void 0, a = t ?? i?.id ?? "";
	return /* @__PURE__ */ T(pl, {
		label: "HPC profile",
		description: i === void 0 ? void 0 : "Only installed HPC profile.",
		disabled: n,
		value: a,
		data: [...a === "" ? [{
			value: "",
			label: "—",
			disabled: !0
		}] : [], ...e.map((e) => ({
			value: e.id,
			label: e.name
		}))],
		onChange: (e) => {
			r(e.currentTarget.value || null);
		}
	});
}
function mp() {
	let e = Ef(), t = Df(), { draft: n, capabilities: r, inspection: i } = t;
	if (n === null || r === null) return null;
	let a = t.operation === "inspect" || i === null;
	return /* @__PURE__ */ E(Q, {
		gap: "sm",
		children: [
			/* @__PURE__ */ T(pl, {
				label: "Code",
				disabled: a,
				value: n.code,
				data: r.codes.map((e) => ({
					value: e.id,
					label: e.name
				})),
				onChange: (t) => {
					e.dispatch({
						type: "draft.patch",
						code: t.currentTarget.value
					});
				}
			}),
			/* @__PURE__ */ T(pl, {
				label: "Task",
				disabled: a,
				value: n.task,
				data: r.tasks.map((e) => ({
					value: e.id,
					label: e.name
				})),
				onChange: (t) => {
					e.dispatch({
						type: "draft.patch",
						task: t.currentTarget.value
					});
				}
			}),
			/* @__PURE__ */ T(pp, {
				hpcProfiles: r.hpc_profiles,
				value: n.hpc,
				disabled: a,
				onChange: (t) => {
					e.dispatch({
						type: "draft.patch",
						hpc: t
					});
				}
			})
		]
	});
}
function hp() {
	let e = Ef(), t = Df(), { draft: n, capabilities: r, inspection: i, reviewed: a } = t;
	if (n === null || r === null) return null;
	let o = t.operation === "inspect", s = o || i === null, c = i === null ? [] : gp(i), l = n.overrides, u = r.settings.filter((e) => e.tasks.includes(n.task)), d = a === null ? null : Lf(a.layout, new Set(u.map((e) => e.resolved_in.record))), f = new Set(pf(t).flatMap((e) => e.fields));
	function p(t) {
		e.dispatch({
			type: "draft.patch",
			overrides: t
		});
	}
	return /* @__PURE__ */ E(Q, { children: [
		o ? /* @__PURE__ */ T(Z, {
			c: "red",
			size: "sm",
			role: "status",
			children: "Calculation settings are disabled while the new structure loads."
		}) : null,
		i === null ? /* @__PURE__ */ T(Z, {
			c: "dimmed",
			size: "sm",
			children: "Showing default settings — load a structure to configure a calculation."
		}) : null,
		/* @__PURE__ */ E(js, {
			multiple: !0,
			transitionDuration: 0,
			classNames: { label: "workbench-accordion-label" },
			children: [/* @__PURE__ */ T(Dp, {
				settings: u,
				overrides: l,
				records: a?.records,
				findingFields: f,
				elements: c,
				pseudopotentialTables: r.pseudopotential_tables,
				disabled: s,
				onChange: p
			}), d === null || a === null ? null : /* @__PURE__ */ T(Kf, {
				names: d.ungrouped,
				records: a.records
			})]
		}),
		d === null || a === null ? null : d.steps.map((e) => /* @__PURE__ */ T(qf, {
			step: e.name,
			names: e.records,
			records: a.records
		}, e.name))
	] });
}
function gp(e) {
	return [...new Set(e.structure.sites.flatMap((e) => e.species.map((e) => e.symbol)))];
}
function _p(e) {
	return [...new Set(e.map((e) => e.functional))];
}
function vp({ tables: e, elements: t, functionalOverride: n, pinned: r, resolvedId: i, source: a, description: o, disabled: s, onChange: c }) {
	let l = e.filter((e) => (n === void 0 || e.functional === n) && t.every((t) => e.elements.includes(t))), u = typeof r == "string" ? r : void 0, d = u ?? i, f = l.length === 0 ? "No registered table supports this structure with this functional" : void 0, p = d === void 0 || !l.some((e) => e.id === d);
	return /* @__PURE__ */ T(tp, {
		label: Yf.pseudo_table_id,
		description: f ?? ep(o, u !== void 0, a),
		disabled: s,
		pinned: u !== void 0,
		value: d ?? "",
		data: [...p ? [{
			value: "",
			label: "—",
			disabled: !0
		}] : [], ...l.map((e) => ({
			value: e.id,
			label: `${e.provider} · ${e.functional} · ${e.accuracy} · ${e.relativistic}`
		}))],
		onReset: () => {
			c({ pseudo_table_id: void 0 });
		},
		onChange: (e) => {
			c({ pseudo_table_id: e === "" ? void 0 : e });
		}
	});
}
function yp({ tables: e, value: t, resolvedValue: n, source: r, description: i, disabled: a, onChange: o }) {
	let s = t !== void 0, c = s ? t : n, l = _p(e), u = c === void 0 || !l.includes(c);
	return /* @__PURE__ */ T(tp, {
		label: Yf.functional,
		description: ep(i, s, r),
		disabled: a,
		pinned: s,
		value: c ?? "",
		data: [...u ? [{
			value: "",
			label: "—",
			disabled: !0
		}] : [], ...l.map((e) => ({
			value: e,
			label: e
		}))],
		onReset: () => {
			o({
				functional: void 0,
				pseudo_table_id: void 0
			});
		},
		onChange: (e) => {
			o({
				functional: e === "" ? void 0 : e,
				pseudo_table_id: void 0
			});
		}
	});
}
var bp = { pseudo_table_id: Yf.pseudo_table_id };
function xp(e) {
	let t = bp[e];
	if (t !== void 0) return t;
	let n = e.replace(/_/g, " ");
	return n.charAt(0).toUpperCase() + n.slice(1);
}
function Sp(e) {
	return new Map(e.map((e) => [e.setting.resolved_in.record, e.record]));
}
function Cp(e, t) {
	return e.find((e) => e.originalGroup === t)?.record;
}
function wp(e) {
	if (e?.status !== "resolved") return [];
	let t = e.value;
	if (typeof t != "object" || !t || Array.isArray(t)) return [];
	let n = t.warnings;
	return Array.isArray(n) ? n.filter(_d) : [];
}
function Tp({ notes: e }) {
	return e.length === 0 ? null : /* @__PURE__ */ E(Q, {
		gap: 2,
		children: [/* @__PURE__ */ T(Z, {
			size: "xs",
			fw: 600,
			c: "dimmed",
			children: "Notes"
		}), e.map((e) => /* @__PURE__ */ T(Z, {
			size: "xs",
			c: "dimmed",
			children: e.message
		}, e.code))]
	});
}
function Ep(e, t) {
	return e.some((e) => t.has(e.setting.key)) ? "blocked" : [...Sp(e).values()].reduce((e, t) => t === void 0 ? e : e === void 0 || up[t.status] > up[e] ? t.status : e, void 0);
}
function Dp({ settings: e, overrides: t, records: n, findingFields: r, elements: i, pseudopotentialTables: a, disabled: o, onChange: s }) {
	let c = /* @__PURE__ */ new Map();
	for (let t of e) {
		let e = fp[t.group] ?? t.group, r = {
			originalGroup: t.group,
			setting: t,
			record: op(t, n)
		}, i = c.get(e);
		i === void 0 ? c.set(e, [r]) : i.push(r);
	}
	let l = [...dp.filter((e) => c.has(e)), ...[...c.keys()].filter((e) => !dp.includes(e))], u = typeof t.functional == "string" ? t.functional : void 0;
	return /* @__PURE__ */ T(w, { children: l.map((e) => {
		let n = c.get(e);
		if (n === void 0) return null;
		let l = [...Sp(n).values()], d = Ep(n, r), f = l.flatMap(wp);
		return /* @__PURE__ */ E(js.Item, {
			value: e,
			children: [/* @__PURE__ */ T(js.Control, { children: /* @__PURE__ */ E(X, {
				gap: "xs",
				wrap: "nowrap",
				children: [d === void 0 ? null : /* @__PURE__ */ T(hc, {
					size: "xs",
					circle: !0,
					color: lp[d],
					"aria-hidden": "true"
				}), /* @__PURE__ */ T("span", { children: xp(e) })]
			}) }), /* @__PURE__ */ T(js.Panel, { children: /* @__PURE__ */ E(Q, {
				gap: "sm",
				children: [/* @__PURE__ */ T(Ip, {
					group: e,
					groupedSettings: n,
					elements: i,
					pseudopotentialTables: a,
					functionalOverride: u,
					overrides: t,
					disabled: o,
					onChange: s
				}), /* @__PURE__ */ T(Tp, { notes: f })]
			}) })]
		}, e);
	}) });
}
function Op(e) {
	let { key: t } = e.entry.setting;
	return /* @__PURE__ */ E(a, { children: [kp(e), /* @__PURE__ */ T(Ff, { field: t })] }, t);
}
function kp({ entry: e, overrides: t, disabled: n, onChange: r }) {
	let { setting: i, record: a } = e;
	if (i.key === "k_grid") {
		let e = sp(i, a), o = Array.isArray(e) && e.length === 3 ? e : void 0;
		return /* @__PURE__ */ T(Lp, {
			value: t.k_grid,
			resolvedMesh: o,
			disabled: n,
			onChange: (e) => {
				r({ k_grid: e });
			}
		});
	}
	return /* @__PURE__ */ T(np, {
		meta: i,
		value: t[i.key],
		resolvedValue: sp(i, a),
		source: cp(i, a),
		disabled: n,
		onChange: (e) => {
			r({ [i.key]: e });
		}
	});
}
function Ap({ record: e }) {
	if (e?.status !== "resolved") return null;
	let t = e.value;
	if (typeof t != "object" || !t) return null;
	let n = t;
	if (n.k_distance !== null && n.k_distance !== void 0) return null;
	let r = n.k_distance_interval;
	if (!Array.isArray(r) || r.length !== 2) return null;
	let [i, a] = r, o = a === null ? `Δk ≥ ${i.toFixed(3)}` : `Δk ∈ [${i.toFixed(3)}, ${a.toFixed(3)}]`;
	return /* @__PURE__ */ E(Z, {
		size: "xs",
		c: "dimmed",
		children: [
			"This rung corresponds to ",
			o,
			" Å⁻¹"
		]
	});
}
function jp({ groupedSettings: e, pseudopotentialTables: t, functionalOverride: n, disabled: r, onChange: i }) {
	let a = e[0];
	if (a === void 0) return null;
	let o = sp(a.setting, a.record);
	return /* @__PURE__ */ E(w, { children: [/* @__PURE__ */ T(yp, {
		tables: t,
		value: n,
		resolvedValue: typeof o == "string" ? o : void 0,
		source: cp(a.setting, a.record),
		description: a.setting.description,
		disabled: r,
		onChange: i
	}), /* @__PURE__ */ T(Ff, { field: a.setting.key })] });
}
function Mp({ groupedSettings: e, elements: t, pseudopotentialTables: n, functionalOverride: r, overrides: i, disabled: a, onChange: o }) {
	let s = e.find((e) => e.originalGroup === "pseudo_table_id"), c = s === void 0 ? void 0 : sp(s.setting, s.record);
	return /* @__PURE__ */ E(w, { children: [s === void 0 ? null : /* @__PURE__ */ E(w, { children: [/* @__PURE__ */ T(vp, {
		tables: n,
		elements: t,
		functionalOverride: r,
		pinned: i.pseudo_table_id,
		resolvedId: typeof c == "string" ? c : void 0,
		source: cp(s.setting, s.record),
		description: s.setting.description,
		disabled: a,
		onChange: o
	}), /* @__PURE__ */ T(Ff, { field: s.setting.key })] }), e.filter((e) => e.originalGroup === "cutoffs").map((e) => Op({
		entry: e,
		overrides: i,
		disabled: a,
		onChange: o
	}))] });
}
function Np({ groupedSettings: e, overrides: t, disabled: n, onChange: r }) {
	return /* @__PURE__ */ E(w, { children: [e.map((e) => Op({
		entry: e,
		overrides: t,
		disabled: n,
		onChange: r
	})), /* @__PURE__ */ T(Ap, { record: Cp(e, "k_sampling") })] });
}
function Pp({ record: e }) {
	let t = h(), n = (e?.status === "resolved" && typeof e.value == "object" && e.value !== null ? e.value : void 0)?.u_values;
	return Array.isArray(n) ? n.length === 0 ? /* @__PURE__ */ T(Z, {
		size: "sm",
		c: "dimmed",
		children: "No element gets +U."
	}) : /* @__PURE__ */ E(Q, {
		gap: 2,
		children: [/* @__PURE__ */ T(Z, {
			id: t,
			size: "xs",
			fw: 600,
			c: "dimmed",
			children: "Applied +U"
		}), /* @__PURE__ */ T(Q, {
			component: "ul",
			gap: 2,
			m: 0,
			pl: "md",
			"aria-labelledby": t,
			children: n.map((e) => /* @__PURE__ */ E(Z, {
				component: "li",
				size: "sm",
				children: [
					e.element,
					" ",
					e.manifold,
					": ",
					e.u_ev,
					" eV ·",
					" ",
					e.value_source === "human" ? /* @__PURE__ */ T(gd, { source: "human" }) : e.citation
				]
			}, e.element))
		})]
	}) : null;
}
function Fp({ groupedSettings: e, overrides: t, disabled: n, onChange: r }) {
	return /* @__PURE__ */ E(w, { children: [e.map((e) => Op({
		entry: e,
		overrides: t,
		disabled: n,
		onChange: r
	})), /* @__PURE__ */ T(Pp, { record: Cp(e, "hubbard") })] });
}
function Ip({ group: e, groupedSettings: t, elements: n, pseudopotentialTables: r, functionalOverride: i, overrides: a, disabled: o, onChange: s }) {
	if (e === "functional") return /* @__PURE__ */ T(jp, {
		groupedSettings: t,
		pseudopotentialTables: r,
		functionalOverride: i,
		disabled: o,
		onChange: s
	});
	if (e === "pseudo_table_id") return /* @__PURE__ */ T(Mp, {
		groupedSettings: t,
		elements: n,
		pseudopotentialTables: r,
		functionalOverride: i,
		overrides: a,
		disabled: o,
		onChange: s
	});
	let c = {
		groupedSettings: t,
		overrides: a,
		disabled: o,
		onChange: s
	};
	return e === "k_sampling" ? /* @__PURE__ */ T(Np, { ...c }) : e === "hubbard" ? /* @__PURE__ */ T(Fp, { ...c }) : /* @__PURE__ */ T(w, { children: t.map((e) => Op({
		entry: e,
		overrides: a,
		disabled: o,
		onChange: s
	})) });
}
function Lp({ value: e, resolvedMesh: t, disabled: n, onChange: r }) {
	let i = (Array.isArray(e) && e.length === 3 ? e : void 0) ?? t;
	return /* @__PURE__ */ T(jc, {
		legend: Yf.k_grid,
		children: /* @__PURE__ */ T(Ru, {
			cols: 3,
			spacing: "xs",
			children: [
				"x",
				"y",
				"z"
			].map((e, t) => /* @__PURE__ */ T(ku, {
				"aria-label": `${Yf.k_grid} ${e}`,
				min: 1,
				max: 99,
				disabled: n,
				value: i?.[t] ?? "",
				placeholder: "Auto",
				onChange: (e) => {
					if (e === "") {
						r(void 0);
						return;
					}
					let n = Number(e);
					if (!Number.isInteger(n) || n < 1 || n > 99) return;
					let a = [...i ?? [
						1,
						1,
						1
					]];
					a[t] = n, r(a);
				}
			}, e))
		})
	});
}
// src/controls/ClearedOverridesNotice.tsx
function Rp() {
	let { capabilities: e, clearedOverrides: t } = Df(), [n, r] = y(null);
	return e === null || t.length === 0 || t === n ? null : /* @__PURE__ */ E(Ps, {
		role: "status",
		title: "Structure-specific overrides reset",
		withCloseButton: !0,
		closeButtonLabel: "Dismiss notice",
		styles: { closeButton: {
			width: 44,
			height: 44
		} },
		onClose: () => {
			r(t);
		},
		mb: "md",
		children: [/* @__PURE__ */ T(Z, {
			size: "sm",
			children: "Opening this structure set these back to automatic:"
		}), /* @__PURE__ */ T(qc, {
			size: "sm",
			children: t.map((t) => /* @__PURE__ */ T(qc.Item, { children: Zf(t, e.settings) }, t))
		})]
	});
}
// src/cards/AdvisorsCard.tsx
function zp({ kicker: e }) {
	let t = Df();
	return /* @__PURE__ */ E(Mi, {
		component: "section",
		id: "advisors-panel",
		"aria-label": "Goldilocks advisors",
		withBorder: !0,
		p: "md",
		className: "workbench-card card-advisors",
		children: [
			/* @__PURE__ */ E(X, {
				component: "header",
				className: "card-header",
				mb: "md",
				wrap: "nowrap",
				children: [/* @__PURE__ */ T(Z, {
					className: "card-kicker",
					children: e
				}), /* @__PURE__ */ T(pd, {
					order: 2,
					children: "Advisors"
				})]
			}),
			/* @__PURE__ */ T(Rp, {}),
			/* @__PURE__ */ T("div", {
				className: "card-body",
				tabIndex: 0,
				children: t.capabilities === null ? /* @__PURE__ */ T(Z, {
					c: "dimmed",
					children: "Load a structure to configure a calculation."
				}) : /* @__PURE__ */ T(hp, {})
			})
		]
	});
}
// src/analysis/FactSummary.tsx
function Bp({ fact: e, record: t }) {
	let n = h(), r = h(), i = t?.status === "resolved" ? t : void 0;
	return /* @__PURE__ */ T(gs.Wrapper, {
		size: "md",
		role: "group",
		"aria-labelledby": n,
		"aria-describedby": r,
		labelElement: "div",
		label: Jf({
			key: e.key,
			unit: null
		}),
		labelProps: { id: n },
		description: ep(e.description, !1, i?.source),
		descriptionProps: { id: r },
		children: /* @__PURE__ */ T(Z, {
			size: "md",
			children: Vp(i?.value)
		})
	});
}
function Vp(e) {
	return e == null ? "—" : typeof e == "boolean" ? e ? "Yes" : "No" : Qf(e);
}
// src/analysis/AnalysisSection.tsx
function Hp() {
	let e = Ef(), t = Df(), { capabilities: n, draft: r, inspection: i, reviewed: a } = t;
	if (n === null || r === null) return null;
	let o = t.operation === "inspect" || i === null, s = r.overrides, c = a === null ? [] : If(a.layout, n.facts).flatMap((e) => {
		let t = a.records[e];
		return t === void 0 ? [] : [[e, t]];
	});
	return /* @__PURE__ */ E(Q, {
		gap: "sm",
		children: [n.facts.length === 0 ? null : /* @__PURE__ */ T(Q, {
			gap: "sm",
			children: n.facts.map((t) => {
				let n = a?.records[t.key];
				return /* @__PURE__ */ E("div", { children: [
					t.overridable ? /* @__PURE__ */ T(np, {
						meta: {
							key: t.key,
							type: t.type,
							enum: t.values ?? void 0,
							unit: null,
							description: t.description
						},
						value: s[t.key],
						resolvedValue: n?.status === "resolved" ? n.value : void 0,
						source: n?.status === "resolved" ? n.source : void 0,
						disabled: o,
						onChange: (n) => {
							e.dispatch({
								type: "draft.patch",
								overrides: { [t.key]: n }
							});
						}
					}) : /* @__PURE__ */ T(Bp, {
						fact: t,
						record: n
					}),
					/* @__PURE__ */ T(Up, { record: n }),
					/* @__PURE__ */ T(Ff, { field: t.key })
				] }, t.key);
			})
		}), c.length === 0 ? null : /* @__PURE__ */ T(js, {
			multiple: !0,
			transitionDuration: 0,
			classNames: { label: "workbench-accordion-label" },
			children: c.map(([e, t]) => /* @__PURE__ */ T(Gf, {
				name: e,
				field: t
			}, e))
		})]
	});
}
function Up({ record: e }) {
	return e === void 0 ? null : e.status === "resolved" ? e.source_note ? /* @__PURE__ */ T(Z, {
		size: "xs",
		c: "dimmed",
		mt: 4,
		children: e.source_note
	}) : null : /* @__PURE__ */ T(Z, {
		size: "xs",
		c: e.status === "blocked" ? "red" : "dimmed",
		mt: 4,
		children: e.status === "blocked" ? `Blocked — ${e.blocked_by ?? "an upstream field failed"}` : `Unavailable — ${e.reason ?? "no reason given"}`
	});
}
// src/cards/AnalysisCard.tsx
function Wp({ kicker: e }) {
	let t = Df();
	return /* @__PURE__ */ E(Mi, {
		component: "section",
		id: "analysis-panel",
		"aria-label": "Goldilocks analysis",
		withBorder: !0,
		p: "md",
		className: "workbench-card card-analysis",
		children: [/* @__PURE__ */ E(X, {
			component: "header",
			className: "card-header",
			mb: "md",
			wrap: "nowrap",
			children: [/* @__PURE__ */ T(Z, {
				className: "card-kicker",
				children: e
			}), /* @__PURE__ */ T(pd, {
				order: 2,
				children: "Analysis"
			})]
		}), /* @__PURE__ */ T("div", {
			className: "card-body",
			tabIndex: 0,
			children: t.capabilities === null || t.inspection === null ? /* @__PURE__ */ T(Z, {
				c: "dimmed",
				children: "Load a structure to see its analysis."
			}) : /* @__PURE__ */ T(Hp, {})
		})]
	});
}
// node_modules/fflate/esm/browser.js
var Gp = Uint8Array, Kp = Uint16Array, qp = Int32Array, Jp = new Gp([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	3,
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	0,
	0,
	0,
	0
]), Yp = new Gp([
	0,
	0,
	0,
	0,
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	9,
	10,
	10,
	11,
	11,
	12,
	12,
	13,
	13,
	0,
	0
]), Xp = new Gp([
	16,
	17,
	18,
	0,
	8,
	7,
	9,
	6,
	10,
	5,
	11,
	4,
	12,
	3,
	13,
	2,
	14,
	1,
	15
]), Zp = function(e, t) {
	for (var n = new Kp(31), r = 0; r < 31; ++r) n[r] = t += 1 << e[r - 1];
	for (var i = new qp(n[30]), r = 1; r < 30; ++r) for (var a = n[r]; a < n[r + 1]; ++a) i[a] = a - n[r] << 5 | r;
	return {
		b: n,
		r: i
	};
}, Qp = Zp(Jp, 2), $p = Qp.b, em = Qp.r;
$p[28] = 258, em[258] = 28;
var tm = Zp(Yp, 0), nm = tm.b;
tm.r;
for (var rm = new Kp(32768), im = 0; im < 32768; ++im) {
	var am = (im & 43690) >> 1 | (im & 21845) << 1;
	am = (am & 52428) >> 2 | (am & 13107) << 2, am = (am & 61680) >> 4 | (am & 3855) << 4, rm[im] = ((am & 65280) >> 8 | (am & 255) << 8) >> 1;
}
for (var om = (function(e, t, n) {
	for (var r = e.length, i = 0, a = new Kp(t); i < r; ++i) e[i] && ++a[e[i] - 1];
	var o = new Kp(t);
	for (i = 1; i < t; ++i) o[i] = o[i - 1] + a[i - 1] << 1;
	var s;
	if (n) {
		s = new Kp(1 << t);
		var c = 15 - t;
		for (i = 0; i < r; ++i) if (e[i]) for (var l = i << 4 | e[i], u = t - e[i], d = o[e[i] - 1]++ << u, f = d | (1 << u) - 1; d <= f; ++d) s[rm[d] >> c] = l;
	} else for (s = new Kp(r), i = 0; i < r; ++i) e[i] && (s[i] = rm[o[e[i] - 1]++] >> 15 - e[i]);
	return s;
}), sm = new Gp(288), im = 0; im < 144; ++im) sm[im] = 8;
for (var im = 144; im < 256; ++im) sm[im] = 9;
for (var im = 256; im < 280; ++im) sm[im] = 7;
for (var im = 280; im < 288; ++im) sm[im] = 8;
for (var cm = new Gp(32), im = 0; im < 32; ++im) cm[im] = 5;
var lm = /*#__PURE__*/ om(sm, 9, 1), um = /*#__PURE__*/ om(cm, 5, 1), dm = function(e) {
	for (var t = e[0], n = 1; n < e.length; ++n) e[n] > t && (t = e[n]);
	return t;
}, fm = function(e, t, n) {
	var r = t / 8 | 0;
	return (e[r] | e[r + 1] << 8) >> (t & 7) & n;
}, pm = function(e, t) {
	var n = t / 8 | 0;
	return (e[n] | e[n + 1] << 8 | e[n + 2] << 16) >> (t & 7);
}, mm = function(e) {
	return (e + 7) / 8 | 0;
}, hm = function(e, t, n) {
	return (t == null || t < 0) && (t = 0), (n == null || n > e.length) && (n = e.length), new Gp(e.subarray(t, n));
}, gm = [
	"unexpected EOF",
	"invalid block type",
	"invalid length/literal",
	"invalid distance",
	"stream finished",
	"no stream handler",
	,
	"no callback",
	"invalid UTF-8 data",
	"extra field too long",
	"date not in range 1980-2099",
	"filename too long",
	"stream finishing",
	"invalid zip data"
], _m = function(e, t, n) {
	var r = Error(t || gm[e]);
	if (r.code = e, Error.captureStackTrace && Error.captureStackTrace(r, _m), !n) throw r;
	return r;
}, vm = function(e, t, n, r) {
	var i = e.length, a = r ? r.length : 0;
	if (!i || t.f && !t.l) return n || new Gp(0);
	var o = !n, s = o || t.i != 2, c = t.i;
	o && (n = new Gp(i * 3));
	var l = function(e) {
		var t = n.length;
		if (e > t) {
			var r = new Gp(Math.max(t * 2, e));
			r.set(n), n = r;
		}
	}, u = t.f || 0, d = t.p || 0, f = t.b || 0, p = t.l, m = t.d, h = t.m, g = t.n, _ = i * 8;
	do {
		if (!p) {
			u = fm(e, d, 1);
			var v = fm(e, d + 1, 3);
			if (d += 3, !v) {
				var y = mm(d) + 4, b = e[y - 4] | e[y - 3] << 8, x = y + b;
				if (x > i) {
					c && _m(0);
					break;
				}
				s && l(f + b), n.set(e.subarray(y, x), f), t.b = f += b, t.p = d = x * 8, t.f = u;
				continue;
			}
			if (v == 1) p = lm, m = um, h = 9, g = 5;
			else if (v == 2) {
				var S = fm(e, d, 31) + 257, C = fm(e, d + 10, 15) + 4, w = S + fm(e, d + 5, 31) + 1;
				d += 14;
				for (var T = new Gp(w), E = new Gp(19), D = 0; D < C; ++D) E[Xp[D]] = fm(e, d + D * 3, 7);
				d += C * 3;
				for (var O = dm(E), k = (1 << O) - 1, ee = om(E, O, 1), D = 0; D < w;) {
					var A = ee[fm(e, d, k)];
					d += A & 15;
					var y = A >> 4;
					if (y < 16) T[D++] = y;
					else {
						var j = 0, M = 0;
						for (y == 16 ? (M = 3 + fm(e, d, 3), d += 2, j = T[D - 1]) : y == 17 ? (M = 3 + fm(e, d, 7), d += 3) : y == 18 && (M = 11 + fm(e, d, 127), d += 7); M--;) T[D++] = j;
					}
				}
				var N = T.subarray(0, S), P = T.subarray(S);
				h = dm(N), g = dm(P), p = om(N, h, 1), m = om(P, g, 1);
			} else _m(1);
			if (d > _) {
				c && _m(0);
				break;
			}
		}
		s && l(f + 131072);
		for (var te = (1 << h) - 1, ne = (1 << g) - 1, F = d;; F = d) {
			var j = p[pm(e, d) & te], I = j >> 4;
			if (d += j & 15, d > _) {
				c && _m(0);
				break;
			}
			if (j || _m(2), I < 256) n[f++] = I;
			else if (I == 256) {
				F = d, p = null;
				break;
			} else {
				var re = I - 254;
				if (I > 264) {
					var D = I - 257, L = Jp[D];
					re = fm(e, d, (1 << L) - 1) + $p[D], d += L;
				}
				var R = m[pm(e, d) & ne], z = R >> 4;
				R || _m(3), d += R & 15;
				var P = nm[z];
				if (z > 3) {
					var L = Yp[z];
					P += pm(e, d) & (1 << L) - 1, d += L;
				}
				if (d > _) {
					c && _m(0);
					break;
				}
				s && l(f + 131072);
				var ie = f + re;
				if (f < P) {
					var ae = a - P, oe = Math.min(P, ie);
					for (ae + f < 0 && _m(3); f < oe; ++f) n[f] = r[ae + f];
				}
				for (; f < ie; ++f) n[f] = n[f - P];
			}
		}
		t.l = p, t.p = F, t.b = f, t.f = u, p && (u = 1, t.m = h, t.d = m, t.n = g);
	} while (!u);
	return f != n.length && o ? hm(n, 0, f) : n.subarray(0, f);
}, ym = /*#__PURE__*/ new Gp(0), bm = function(e, t) {
	return e[t] | e[t + 1] << 8;
}, xm = function(e, t) {
	return (e[t] | e[t + 1] << 8 | e[t + 2] << 16 | e[t + 3] << 24) >>> 0;
}, Sm = function(e, t) {
	return xm(e, t) + xm(e, t + 4) * 4294967296;
};
function Cm(e, t) {
	return vm(e, { i: 2 }, t && t.out, t && t.dictionary);
}
var wm = typeof TextDecoder < "u" && /*#__PURE__*/ new TextDecoder();
try {
	wm.decode(ym, { stream: !0 });
} catch {}
var Tm = function(e) {
	for (var t = "", n = 0;;) {
		var r = e[n++], i = (r > 127) + (r > 223) + (r > 239);
		if (n + i > e.length) return {
			s: t,
			r: hm(e, n - 1)
		};
		i ? i == 3 ? (r = ((r & 15) << 18 | (e[n++] & 63) << 12 | (e[n++] & 63) << 6 | e[n++] & 63) - 65536, t += String.fromCharCode(55296 | r >> 10, 56320 | r & 1023)) : i & 1 ? t += String.fromCharCode((r & 31) << 6 | e[n++] & 63) : t += String.fromCharCode((r & 15) << 12 | (e[n++] & 63) << 6 | e[n++] & 63) : t += String.fromCharCode(r);
	}
};
function Em(e, t) {
	if (t) {
		for (var n = "", r = 0; r < e.length; r += 16384) n += String.fromCharCode.apply(null, e.subarray(r, r + 16384));
		return n;
	}
	if (wm) return wm.decode(e);
	var i = Tm(e), a = i.s, n = i.r;
	return n.length && _m(8), a;
}
var Dm = function(e, t) {
	return t + 30 + bm(e, t + 26) + bm(e, t + 28);
}, Om = function(e, t, n) {
	var r = bm(e, t + 28), i = bm(e, t + 30), a = Em(e.subarray(t + 46, t + 46 + r), !(bm(e, t + 8) & 2048)), o = t + 46 + r, s = km(e, o, i, n, xm(e, t + 20), xm(e, t + 24), xm(e, t + 42)), c = s[0], l = s[1], u = s[2];
	return [
		bm(e, t + 10),
		c,
		l,
		a,
		o + i + bm(e, t + 32),
		u
	];
}, km = function(e, t, n, r, i, a, o) {
	var s = i == 4294967295, c = a == 4294967295, l = o == 4294967295, u = t + n, d = s + c + l;
	if (r && d) {
		for (; t + 4 < u; t += 4 + bm(e, t + 2)) if (bm(e, t) == 1) return [
			s ? Sm(e, t + 4 + 8 * c) : i,
			c ? Sm(e, t + 4) : a,
			l ? Sm(e, t + 4 + 8 * (c + s)) : o,
			1
		];
		r < 2 && _m(13);
	}
	return [
		i,
		a,
		o,
		0
	];
};
function Am(e, t) {
	for (var n = {}, r = e.length - 22; xm(e, r) != 101010256; --r) (!r || e.length - r > 65558) && _m(13);
	var i = bm(e, r + 8);
	if (!i) return {};
	var a = xm(e, r + 16), o = xm(e, r - 20) == 117853008;
	if (o) {
		var s = xm(e, r - 12);
		o = xm(e, s) == 101075792, o && (i = xm(e, s + 32), a = xm(e, s + 48));
	}
	for (var c = t && t.filter, l = 0; l < i; ++l) {
		var u = Om(e, a, o), d = u[0], f = u[1], p = u[2], m = u[3], h = u[4], g = u[5], _ = Dm(e, g);
		a = h, (!c || c({
			name: m,
			size: f,
			originalSize: p,
			compression: d
		})) && (d ? d == 8 ? n[m] = Cm(e.subarray(_, _ + f), { out: new Gp(p) }) : _m(14, "unknown compression type " + d) : n[m] = hm(e, _, _ + f));
	}
	return n;
}
// src/review/artifacts.ts
async function jm(e) {
	let t = Am(new Uint8Array(await e.blob.arrayBuffer())), n = new TextDecoder("utf-8"), r = [], i = null;
	for (let [e, a] of Object.entries(t)) {
		let t = n.decode(a);
		e === "goldilocks.json" && (i = Mm(t)), r.push({
			path: e,
			content: t
		});
	}
	return {
		manifest: i,
		files: r
	};
}
function Mm(e) {
	try {
		let t = JSON.parse(e);
		return Nm(t) ? t : null;
	} catch {
		return null;
	}
}
function Nm(e) {
	return typeof e == "object" && !!e && "files" in e && typeof e.files == "object" && "steps" in e && Array.isArray(e.steps);
}
function Pm(e, t) {
	let n = e?.files[t];
	return n === void 0 ? void 0 : {
		sha256: n.sha256,
		size_bytes: n.size_bytes
	};
}
// src/review/GeneratedInputPreview.tsx
var Fm = 352, Im = 160, Lm = {
	ArrowUp: -32,
	ArrowDown: 32,
	Home: -Infinity,
	End: Infinity
};
function Rm({ path: e, content: t }) {
	let [n, r] = y(null), [i, a] = y(Fm), o = v(null), s = v(null);
	function c(e) {
		if (e === null || o.current === e) return;
		o.current = e, e.style.height = "auto";
		let t = Math.max(Im, e.scrollHeight), n = Math.min(Fm, t);
		e.style.height = `${String(n)}px`, a(t), r(n);
	}
	function l(e) {
		r(Math.min(i, Math.max(Im, e)));
	}
	function u(e) {
		let t = n ?? Math.min(Fm, i), r = Lm[e.key];
		typeof r == "number" && (e.preventDefault(), l(t + r));
	}
	function d(e) {
		let t = s.current;
		t?.id === e.pointerId && l(t.startHeight + e.clientY - t.startY);
	}
	function f(e) {
		s.current?.id === e.pointerId && (s.current = null, e.currentTarget.hasPointerCapture(e.pointerId) && e.currentTarget.releasePointerCapture(e.pointerId));
	}
	let p = n ?? Math.min(Fm, i);
	return /* @__PURE__ */ E(Mi, {
		withBorder: !0,
		children: [/* @__PURE__ */ T(Dc, {
			block: !0,
			role: "region",
			id: "generated-input-content",
			ref: c,
			h: n ?? void 0,
			"aria-label": `Generated input ${e}`,
			tabIndex: 0,
			children: t
		}, `${e}\0${t}`), /* @__PURE__ */ T("div", {
			className: "code-resizer",
			role: "separator",
			"aria-label": "Resize generated input",
			"aria-controls": "generated-input-content",
			"aria-orientation": "horizontal",
			"aria-valuemin": Im,
			"aria-valuemax": Math.round(i),
			"aria-valuenow": Math.round(p),
			"aria-valuetext": p >= i ? "Full input file visible" : `${String(Math.round(p))} pixels high`,
			tabIndex: 0,
			title: "Drag or use arrow keys to resize the generated input",
			onKeyDown: u,
			onDoubleClick: () => {
				l(i);
			},
			onPointerDown: (e) => {
				e.button === 0 && (s.current = {
					id: e.pointerId,
					startHeight: p,
					startY: e.clientY
				}, e.currentTarget.setPointerCapture(e.pointerId), e.preventDefault());
			},
			onPointerMove: d,
			onPointerUp: f,
			onPointerCancel: f
		})]
	});
}
// src/review/GeneratedInputReview.tsx
var zm = {
	input: 0,
	submission_script: 1,
	pseudopotential: 2,
	licence: 3,
	manifest: 4,
	readme: 5,
	citations: 5
}, Bm = 6;
function Vm(e, t) {
	let n = e?.files[t]?.role;
	return n === void 0 && t === "goldilocks.json" ? "manifest" : n;
}
function Hm(e, t) {
	let n = new Map((t === null ? [] : t.steps).flatMap((e) => e.files).map((e, t) => [e, t])), r = (e) => n.get(e) ?? n.size;
	return [...e].sort((e, n) => {
		let i = zm[Vm(t, e.path) ?? ""] ?? Bm, a = zm[Vm(t, n.path) ?? ""] ?? Bm;
		if (i !== a) return i - a;
		let o = r(e.path), s = r(n.path);
		return o === s ? e.path.localeCompare(n.path) : o - s;
	});
}
function Um({ archive: e, placeholder: t }) {
	let n = Km(e);
	if (e === null) return /* @__PURE__ */ E("div", { children: [/* @__PURE__ */ T(pd, {
		order: 3,
		children: "Generated inputs"
	}), /* @__PURE__ */ T(Z, {
		c: "dimmed",
		children: t
	})] });
	if (n === null) return /* @__PURE__ */ E("div", { children: [/* @__PURE__ */ T(pd, {
		order: 3,
		children: "Generated inputs"
	}), /* @__PURE__ */ T(Z, {
		c: "dimmed",
		children: "Reading the generated archive…"
	})] });
	let { manifest: r, files: i } = n;
	return i.length === 0 ? /* @__PURE__ */ E("div", { children: [/* @__PURE__ */ T(pd, {
		order: 3,
		children: "Generated inputs"
	}), /* @__PURE__ */ T(Z, {
		c: "dimmed",
		children: "No generated input files."
	})] }) : /* @__PURE__ */ E("div", { children: [/* @__PURE__ */ E(X, {
		component: "header",
		justify: "space-between",
		mb: "xs",
		children: [/* @__PURE__ */ T(pd, {
			order: 3,
			children: "Generated inputs"
		}), /* @__PURE__ */ E(Z, {
			size: "sm",
			c: "dimmed",
			children: [i.length, " files"]
		})]
	}), /* @__PURE__ */ T(js, {
		multiple: !0,
		transitionDuration: 0,
		children: Hm(i, r).map((e) => {
			let t = Vm(r, e.path), n = Pm(r, e.path);
			return /* @__PURE__ */ E(js.Item, {
				value: e.path,
				children: [/* @__PURE__ */ T(js.Control, { children: /* @__PURE__ */ E(X, {
					justify: "space-between",
					wrap: "nowrap",
					gap: "xs",
					children: [/* @__PURE__ */ T(Z, {
						size: "sm",
						fw: 600,
						style: { overflowWrap: "anywhere" },
						children: e.path
					}), n?.sha256 === void 0 ? null : /* @__PURE__ */ T(Dc, { children: n.sha256.slice(0, 10) })]
				}) }), /* @__PURE__ */ T(js.Panel, { children: t === "pseudopotential" ? /* @__PURE__ */ T(Wm, {
					content: e.content,
					sizeBytes: n?.size_bytes,
					sha256: n?.sha256
				}) : /* @__PURE__ */ T(Rm, {
					path: e.path,
					content: e.content
				}) })]
			}, e.path);
		})
	})] });
}
function Wm({ content: e, sizeBytes: t, sha256: n }) {
	let r = Gm(e);
	return /* @__PURE__ */ T($, { children: /* @__PURE__ */ E($.Tbody, { children: [
		r === null ? null : Object.entries(r).map(([e, t]) => /* @__PURE__ */ E($.Tr, { children: [/* @__PURE__ */ T($.Th, {
			scope: "row",
			children: Rf(e)
		}), /* @__PURE__ */ T($.Td, {
			style: { overflowWrap: "anywhere" },
			children: t
		})] }, e)),
		/* @__PURE__ */ E($.Tr, { children: [/* @__PURE__ */ T($.Th, {
			scope: "row",
			children: "Size"
		}), /* @__PURE__ */ T($.Td, { children: t === void 0 ? "Unknown" : `${(t / 1024).toFixed(1)} KB` })] }),
		/* @__PURE__ */ E($.Tr, { children: [/* @__PURE__ */ T($.Th, {
			scope: "row",
			children: "SHA-256"
		}), /* @__PURE__ */ T($.Td, {
			style: { overflowWrap: "anywhere" },
			children: /* @__PURE__ */ T(Dc, { children: n ?? "unlisted" })
		})] })
	] }) });
}
function Gm(e) {
	let t = /<PP_HEADER\b([^>]*)\/?>/i.exec(e)?.[1];
	if (t === void 0) return null;
	let n = {};
	for (let e of t.matchAll(/([\w.]+)\s*=\s*"([^"]*)"/g)) {
		let [, t, r] = e;
		t !== void 0 && r !== void 0 && (n[t] = r.trim());
	}
	return Object.keys(n).length === 0 ? null : n;
}
function Km(e) {
	let [t, n] = y(null);
	return p(() => {
		if (e === null) return;
		let t = !1;
		return jm(e).then((r) => {
			t || n({
				archive: e,
				contents: r
			});
		}), () => {
			t = !0;
		};
	}, [e]), t?.archive === e ? t.contents : null;
}
// src/review/WarningsPanel.tsx
var qm = {
	error: "Errors",
	warning: "Warnings",
	info: "Notices"
};
function Jm(e) {
	let t = "record" in e ? e.record : null;
	return JSON.stringify([
		t,
		e.code,
		e.message
	]);
}
function Ym({ warnings: e }) {
	return e.length === 0 ? null : /* @__PURE__ */ T(Q, {
		gap: "sm",
		children: [
			"error",
			"warning",
			"info"
		].map((t) => {
			let n = e.filter((e) => e.level === t);
			return n.length === 0 ? null : /* @__PURE__ */ T(Ps, {
				color: vd[t],
				variant: "filled",
				autoContrast: !0,
				title: qm[t],
				role: "status",
				"aria-live": "polite",
				"aria-atomic": "true",
				children: /* @__PURE__ */ T(Q, {
					component: "ul",
					gap: "xs",
					m: 0,
					pl: "md",
					children: n.map((e) => /* @__PURE__ */ T(Z, {
						component: "li",
						size: "sm",
						children: e.message
					}, Jm(e)))
				})
			}, t);
		})
	});
}
// src/cards/BundleCard.tsx
function Xm({ kicker: e }) {
	let t = Df(), n = bf(t);
	return /* @__PURE__ */ E(Mi, {
		component: "section",
		id: "bundle-panel",
		"aria-label": "Bundle",
		"aria-busy": t.operation === "explain",
		withBorder: !0,
		p: "md",
		className: "workbench-card card-bundle",
		children: [/* @__PURE__ */ E(X, {
			component: "header",
			className: "card-header",
			mb: "md",
			wrap: "nowrap",
			children: [/* @__PURE__ */ T(Z, {
				className: "card-kicker",
				children: e
			}), /* @__PURE__ */ T(pd, {
				order: 2,
				children: "Bundle"
			})]
		}), /* @__PURE__ */ T("div", {
			className: "card-body",
			tabIndex: 0,
			children: t.reviewed === null ? /* @__PURE__ */ T(Zm, { status: n }) : /* @__PURE__ */ E(Q, {
				gap: "lg",
				children: [
					/* @__PURE__ */ T(Qm, { status: n }),
					/* @__PURE__ */ T(nh, {
						status: n,
						download: xf(t),
						previewing: t.operation === "preview"
					}),
					/* @__PURE__ */ T(Um, {
						archive: n.kind === "ready" ? n.archive : null,
						placeholder: rh(n)
					}),
					/* @__PURE__ */ T(Ym, { warnings: t.reviewed.warnings })
				]
			})
		})]
	});
}
function Zm({ status: e }) {
	if (e.kind === "explainFailed") return /* @__PURE__ */ T(Qm, { status: e });
	let t = e.kind === "computing";
	return /* @__PURE__ */ E(Q, {
		align: "center",
		justify: "center",
		mih: 160,
		role: t ? "status" : void 0,
		children: [
			t && /* @__PURE__ */ T(ia, { size: "sm" }),
			/* @__PURE__ */ T(Z, {
				fw: 600,
				children: t ? "Computing recommendation" : "No recommendation yet"
			}),
			t ? null : /* @__PURE__ */ T(Z, {
				c: "dimmed",
				size: "sm",
				children: "Load a structure to generate input files."
			})
		]
	});
}
function Qm({ status: e }) {
	let t = Ef();
	switch (e.kind) {
		case "recomputing": return /* @__PURE__ */ T(Ps, {
			role: "status",
			"aria-label": "Recommendation notice",
			"aria-live": "polite",
			"aria-atomic": "true",
			children: "Settings changed — recomputing the recommendation automatically."
		});
		case "explainFailed":
		case "generationFailed": {
			let n = e.kind === "explainFailed" ? "explain" : "preview", r = tf(e.failure);
			return /* @__PURE__ */ T(Ps, {
				role: "status",
				color: "red",
				title: eh[n],
				children: /* @__PURE__ */ E(Q, {
					gap: "xs",
					align: "flex-start",
					children: [r.length === 0 ? /* @__PURE__ */ T(Z, {
						size: "sm",
						children: e.failure.message
					}) : /* @__PURE__ */ T(Nf, { findings: r }), /* @__PURE__ */ T(wc, {
						size: "xs",
						color: "red",
						variant: "light",
						leftSection: /* @__PURE__ */ T(Hd, {
							"aria-hidden": "true",
							size: 14
						}),
						onClick: () => void t.dispatch({
							type: "failure.retry",
							operation: n
						}),
						children: th[n]
					})]
				})
			});
		}
		case "blocked": return /* @__PURE__ */ T(Ps, {
			role: "status",
			color: "red",
			title: $m(e.findings),
			children: /* @__PURE__ */ T(Nf, { findings: e.findings })
		});
		default: return null;
	}
}
function $m(e) {
	let t = e.filter((e) => e.remedies.length > 0);
	return t.length === 0 || t.length < e.length ? "Cannot generate input files" : t.length === 1 ? "Confirm one setting to generate input files" : `Confirm ${String(t.length)} settings to generate input files`;
}
var eh = {
	explain: "Recommendation failed",
	preview: "Input generation failed"
}, th = {
	explain: "Retry recommendation",
	preview: "Retry generation"
};
function nh({ status: e, download: t, previewing: n }) {
	let r = Ef(), i = h();
	return /* @__PURE__ */ E(X, {
		justify: "space-between",
		children: [
			/* @__PURE__ */ T(wc, {
				rightSection: /* @__PURE__ */ T(Id, {
					"aria-hidden": "true",
					size: 14
				}),
				loading: n,
				disabled: !t.enabled,
				"aria-describedby": t.enabled ? void 0 : i,
				onClick: () => void r.dispatch({ type: "review.download" }),
				children: "Download (.zip)"
			}),
			t.reason === null ? null : /* @__PURE__ */ T(ki, {
				id: i,
				children: t.reason
			}),
			e.kind === "ready" ? /* @__PURE__ */ E(Z, {
				size: "sm",
				role: "status",
				"aria-label": "Archive status",
				"aria-live": "polite",
				children: [e.archive.filename, " is ready"]
			}) : null
		]
	});
}
function rh(e) {
	switch (e.kind) {
		case "explainFailed": return "No input files were generated: the recommendation for the current settings failed.";
		case "blocked": return "No input files were generated for the current settings.";
		case "generationFailed": return "No input files were generated: generation failed for the current settings.";
		case "generating": return "Generating the input files for the current settings…";
		default: return "The generated files will appear here once the recommendation for the current settings is ready.";
	}
}
// node_modules/zustand/esm/vanilla.mjs
var ih = (e) => {
	let t, n = /* @__PURE__ */ new Set(), r = (e, r) => {
		let i = typeof e == "function" ? e(t) : e;
		if (!Object.is(i, t)) {
			let e = t;
			t = r ?? (typeof i != "object" || !i) ? i : Object.assign({}, t, i), n.forEach((n) => n(t, e));
		}
	}, i = () => t, a = {
		setState: r,
		getState: i,
		getInitialState: () => o,
		subscribe: (e) => (n.add(e), () => n.delete(e))
	}, o = t = e(r, i, a);
	return a;
}, ah = ((e) => e ? ih(e) : ih), oh = 2e3, sh = {
	capabilities: null,
	startupFailure: null,
	structureInput: null,
	inspection: null,
	inspectFailure: null,
	draft: null,
	clearedOverrides: [],
	revision: 0,
	reviewed: null,
	explain: null,
	preview: null,
	operation: null,
	magneticOrderings: null
};
function ch(e) {
	return {
		code: e.codes[0]?.id ?? "quantum_espresso",
		task: e.tasks[0]?.id ?? "scf_single_point",
		hpc: null,
		overrides: {},
		fetchMissing: !1
	};
}
function lh(e, t) {
	let n = new Set(t.settings.filter((e) => !e.structure_specific).map((e) => e.key)), r = Object.entries(e.overrides);
	return {
		draft: {
			...e,
			overrides: Object.fromEntries(r.filter(([e]) => n.has(e)))
		},
		cleared: r.map(([e]) => e).filter((e) => !n.has(e))
	};
}
function uh(e, t, n) {
	let r = new Map(e.settings.map((e) => [e.key, e])), i = Object.fromEntries(Object.entries(n.overrides).filter(([e]) => r.get(e)?.tasks.includes(n.task) ?? !0));
	return {
		structure_content: t.structure_content,
		structure_name: t.structure_name,
		...t.structure_format ? { structure_format: t.structure_format } : {},
		code: n.code,
		task: n.task,
		hpc: n.hpc,
		overrides: i,
		fetch_missing: n.fetchMissing
	};
}
function dh(e) {
	return {
		structure_content: e.structure_content,
		structure_name: e.structure_name,
		...e.structure_format ? { structure_format: e.structure_format } : {}
	};
}
function fh(e, t) {
	return new Promise((n, r) => {
		if (t.aborted) {
			r(t.reason);
			return;
		}
		let i = setTimeout(() => {
			t.removeEventListener("abort", a), n();
		}, e);
		function a() {
			clearTimeout(i), r(t.reason);
		}
		t.addEventListener("abort", a, { once: !0 });
	});
}
function ph(e) {
	if (!(e instanceof Jd)) throw e;
}
function mh(e, t) {
	let n = {
		...e,
		...t
	};
	return Object.fromEntries(Object.entries(n).filter(([, e]) => e !== void 0));
}
function hh(e) {
	return e?.status === "failure" ? {
		...e,
		dismissed: !0
	} : e;
}
function gh(e) {
	let t = e.magneticOrderings;
	return t?.input === e.structureInput ? t : null;
}
function _h(e, t = vh) {
	let n = ah(() => sh), r = null, i = null, a = null, o = null, s = 0;
	function c(e, t = {}) {
		let i = { operation: e };
		return r = i, n.setState({
			...t,
			operation: e
		}), i;
	}
	function l(e, t = {}) {
		r === e && (r = null, n.setState({
			...t,
			operation: null
		}));
	}
	function u(e, t, n) {
		if (r === e) {
			if (!(t instanceof Jd)) throw l(e), t;
			l(e, n(t));
		}
	}
	function d() {
		if (n.getState().capabilities !== null) return Promise.resolve();
		if (i !== null) return i.promise;
		let t = c("capabilities", { startupFailure: null }), r = e.capabilities().then((e) => {
			i?.owner === t && (i = null), l(t, {
				capabilities: e,
				draft: ch(e)
			});
		}, (e) => {
			i?.owner === t && (i = null), u(t, e, (e) => ({ startupFailure: e }));
		});
		return i = {
			owner: t,
			promise: r
		}, r;
	}
	async function f(t) {
		let i = ++s;
		n.getState().capabilities === null && await d();
		let a = n.getState().capabilities;
		if (a === null || i !== s) return;
		let o = c("inspect", { inspectFailure: null });
		try {
			let i = await e.inspectStructure(t);
			if (r !== o) return;
			v();
			let { draft: s, cleared: c } = lh(n.getState().draft ?? ch(a), a);
			l(o, {
				structureInput: t,
				inspection: i,
				draft: s,
				clearedOverrides: c,
				revision: n.getState().revision + 1,
				reviewed: null,
				explain: null,
				preview: null,
				magneticOrderings: null
			});
		} catch (e) {
			u(o, e, (e) => ({ inspectFailure: {
				input: t,
				failure: e
			} }));
		}
	}
	function p(e) {
		let t = n.getState(), r = t.draft;
		if (r === null || t.operation === "inspect") return;
		let i = {
			...r,
			..."code" in e ? { code: e.code } : {},
			..."task" in e ? { task: e.task } : {},
			..."hpc" in e ? { hpc: e.hpc } : {},
			overrides: e.overrides === void 0 ? r.overrides : mh(r.overrides, e.overrides)
		};
		n.setState({
			draft: i,
			revision: t.revision + 1
		});
	}
	async function m(e, t, r, i) {
		let a = n.getState(), { capabilities: o, structureInput: s, draft: d, revision: f } = a;
		if (o === null || s === null || d === null || !t(a)) return;
		let p = {
			input: s,
			revision: f
		}, m = uh(o, s, d), h = c(e);
		try {
			l(h, i({
				key: p,
				status: "result",
				value: await r(m)
			}));
		} catch (e) {
			u(h, e, (e) => i({
				key: p,
				status: "failure",
				failure: e,
				dismissed: !1
			}));
		}
	}
	function h() {
		return m("explain", mf, (t) => e.explain(t), (e) => e.status === "result" ? {
			explain: e,
			reviewed: e.value
		} : { explain: e });
	}
	function g() {
		return m("preview", hf, (t) => e.runArchive(t), (e) => ({ preview: e }));
	}
	function _() {
		let e = ff(n.getState());
		e !== null && t(e);
	}
	function v() {
		a?.abort(), a = null, o !== null && (e.cancelRanking(o).catch(ph), o = null);
	}
	function y(e, t = {}) {
		n.getState().magneticOrderings === e && n.setState({ magneticOrderings: {
			...e,
			...t,
			operation: null,
			ranking: null
		} });
	}
	function b(e, t) {
		if (n.getState().magneticOrderings === e) {
			if (!(t instanceof Jd)) throw y(e), t;
			y(e, { error: t.message });
		}
	}
	function x(e) {
		let t = n.getState(), r = t.structureInput, i = gh(t);
		if (r === null || i !== null && i.operation !== null) return null;
		let o = {
			input: r,
			operation: e,
			result: i?.result ?? null,
			error: null,
			ranking: null
		}, s = new AbortController();
		return a = s, n.setState({ magneticOrderings: o }), [o, s];
	}
	async function S() {
		let t = x("list");
		if (t === null) return;
		let [n, r] = t;
		try {
			y(n, { result: await e.magneticOrderings(dh(n.input), r.signal) });
		} catch (e) {
			b(n, e);
		}
	}
	async function C() {
		let t = x("rank");
		if (t === null) return;
		let [n] = t, [, r] = t, i = null;
		try {
			let t = await e.submitRanking(dh(n.input), r.signal);
			for (i = t.job_id, o = i; t.state === "queued" || t.state === "running";) n = w(n, t), await fh(oh, r.signal), t = await e.rankingStatus(i, r.signal);
			t.state === "done" ? y(n, { result: t.report }) : y(n, { error: t.error });
		} catch (e) {
			b(n, e);
		} finally {
			o === i && (o = null);
		}
	}
	function w(e, t) {
		if (n.getState().magneticOrderings !== e) return e;
		let r = {
			...e,
			ranking: t
		};
		return n.setState({ magneticOrderings: r }), r;
	}
	async function T(r) {
		let i = n.getState(), { capabilities: a, draft: o } = i, s = gh(i);
		if (a === null || o === null || s?.result == null || s.operation !== null || r.length === 0) return;
		let { input: c, result: l } = s, u = {
			...s,
			operation: "download",
			error: null
		};
		n.setState({ magneticOrderings: u });
		let d = Object.fromEntries(Object.entries(o.overrides).filter(([e]) => e !== "starting_magnetization")), f;
		try {
			f = await Promise.all(l.candidates.filter((e) => r.includes(e.label)).map((t) => e.runArchive({
				...uh(a, c, {
					...o,
					overrides: {
						...d,
						...t.overrides
					}
				}),
				structure_name: `${c.structure_name}-${t.label}`
			})));
		} catch (e) {
			b(u, e);
			return;
		}
		y(u);
		for (let e of f) t(e);
	}
	async function E(e) {
		let t = n.getState();
		if (_f(t, e) !== null) switch (e) {
			case "capabilities":
				await d();
				return;
			case "inspect":
				t.inspectFailure !== null && await f(t.inspectFailure.input);
				return;
			case "explain":
				n.setState({ explain: null }), await h();
				return;
			case "preview":
				n.setState({ preview: null }), await g();
				return;
		}
	}
	function D(e) {
		let t = n.getState();
		switch (e) {
			case "capabilities": return;
			case "inspect":
				n.setState({ inspectFailure: null });
				return;
			case "explain":
				n.setState({ explain: hh(t.explain) });
				return;
			case "preview":
				n.setState({ preview: hh(t.preview) });
				return;
		}
	}
	async function O() {
		s += 1;
		let { capabilities: e, revision: t } = n.getState(), a = i !== null && r === i.owner ? i : null;
		v(), a === null && (r = null, i = null), n.setState({
			...sh,
			capabilities: e,
			revision: t,
			operation: a?.owner.operation ?? null
		}, !0), e === null && a === null && await d();
	}
	async function k(e) {
		switch (e.type) {
			case "workspace.start":
				await d();
				return;
			case "source.open":
				await f(e.input);
				return;
			case "draft.patch":
				p(e);
				return;
			case "review.compute":
				await h();
				return;
			case "review.refreshArchive":
				await g();
				return;
			case "review.download":
				_();
				return;
			case "magneticOrderings.list":
				await S();
				return;
			case "magneticOrderings.rank":
				await C();
				return;
			case "magneticOrderings.downloadSelected":
				await T(e.labels);
				return;
			case "failure.retry": return E(e.operation);
			case "failure.dismiss":
				D(e.operation);
				return;
			case "workspace.reset": return O();
		}
	}
	return {
		getSnapshot: n.getState,
		subscribe(e) {
			return n.subscribe(e);
		},
		dispatch: k
	};
}
function vh(e) {
	let t = URL.createObjectURL(e.blob), n = document.createElement("a");
	n.href = t, n.download = e.filename, n.hidden = !0, document.body.append(n), n.click(), n.remove(), URL.revokeObjectURL(t);
}
// src/advisors/MagneticOrderingsPanel.tsx
var yh = {
	result: null,
	operation: null,
	error: null
};
function bh() {
	let e = Ef(), t = Df(), { inspection: n } = t, r = gh(t), { result: i, operation: a, error: o } = r ?? yh, [s, c] = y(/* @__PURE__ */ new Set()), [l, u] = y(i);
	if (l !== i && (u(i), c(/* @__PURE__ */ new Set())), p(() => {
		n !== null && r === null && e.dispatch({ type: "magneticOrderings.list" });
	}, [
		n,
		r,
		e
	]), n === null) return null;
	let d = i?.candidates ?? [], f = a !== null;
	function m(e, t) {
		c((n) => {
			let r = new Set(n);
			return t ? r.add(e) : r.delete(e), r;
		});
	}
	return /* @__PURE__ */ E(Q, {
		gap: "sm",
		children: [
			/* @__PURE__ */ E(Q, {
				gap: 4,
				children: [
					/* @__PURE__ */ T(X, {
						justify: "flex-start",
						children: /* @__PURE__ */ T(wc, {
							size: "xs",
							variant: "light",
							miw: 160,
							loading: a === "rank",
							disabled: f || d.length === 0,
							onClick: () => void e.dispatch({ type: "magneticOrderings.rank" }),
							children: "Run mMACE"
						})
					}),
					/* @__PURE__ */ T(Z, {
						size: "xs",
						c: "dimmed",
						children: "Relaxes each candidate ordering with mMACE (a magnetic MLIP model) and ranks them by energy per atom."
					}),
					/* @__PURE__ */ T(xh, { listing: r })
				]
			}),
			o === null ? null : /* @__PURE__ */ T(Ch, {
				error: o,
				listed: i !== null
			}),
			/* @__PURE__ */ T(Ym, { warnings: i?.warnings ?? [] }),
			d.length === 0 ? /* @__PURE__ */ T(Z, {
				c: "dimmed",
				size: "sm",
				children: a === "list" ? "Listing candidates…" : "No candidates yet."
			}) : /* @__PURE__ */ E(w, { children: [/* @__PURE__ */ T($.ScrollContainer, {
				minWidth: 420,
				children: /* @__PURE__ */ E($, {
					verticalSpacing: 4,
					children: [
						/* @__PURE__ */ T($.Caption, { children: i?.ranked ? "Ranked by mMACE-relaxed energy per atom" : "Not yet ranked" }),
						/* @__PURE__ */ T($.Thead, { children: /* @__PURE__ */ E($.Tr, { children: [
							/* @__PURE__ */ T($.Th, {
								style: { width: "2.5rem" },
								children: /* @__PURE__ */ T(ki, { children: "Select for download" })
							}),
							/* @__PURE__ */ T($.Th, { children: "Ordering" }),
							/* @__PURE__ */ T($.Th, { children: "Atoms" }),
							/* @__PURE__ */ T($.Th, { children: "E/atom (eV)" }),
							/* @__PURE__ */ T($.Th, { children: "Status" })
						] }) }),
						/* @__PURE__ */ T($.Tbody, { children: d.map((e) => /* @__PURE__ */ E($.Tr, { children: [
							/* @__PURE__ */ T($.Td, { children: /* @__PURE__ */ T(fc, {
								"aria-label": `Select ${e.label} for download`,
								checked: s.has(e.label),
								onChange: (t) => {
									m(e.label, t.currentTarget.checked);
								}
							}) }),
							/* @__PURE__ */ T($.Td, { children: /* @__PURE__ */ E(X, {
								gap: 4,
								wrap: "nowrap",
								children: [/* @__PURE__ */ T(Z, {
									size: "sm",
									children: e.label
								}), e.is_recommended ? /* @__PURE__ */ T(hc, {
									size: "xs",
									color: "teal",
									children: "Recommended"
								}) : null]
							}) }),
							/* @__PURE__ */ T($.Td, { children: e.natoms }),
							/* @__PURE__ */ T($.Td, { children: e.energy_per_atom_ev === null ? "—" : e.energy_per_atom_ev.toFixed(4) }),
							/* @__PURE__ */ T($.Td, { children: e.status ?? "—" })
						] }, e.label)) })
					]
				})
			}), /* @__PURE__ */ T(X, {
				justify: "flex-end",
				children: /* @__PURE__ */ E(wc, {
					size: "xs",
					rightSection: /* @__PURE__ */ T(Id, {
						"aria-hidden": "true",
						size: 14
					}),
					loading: a === "download",
					disabled: f || s.size === 0,
					onClick: () => void e.dispatch({
						type: "magneticOrderings.downloadSelected",
						labels: [...s]
					}),
					children: [
						"Download selected (",
						s.size,
						")"
					]
				})
			})] })
		]
	});
}
function xh({ listing: e }) {
	return e?.operation === "rank" ? /* @__PURE__ */ T(Z, {
		size: "sm",
		"aria-live": "polite",
		children: Sh(e.ranking)
	}) : null;
}
function Sh(e) {
	if (e === null) return "Submitting the ranking…";
	if (e.state === "queued") {
		let t = e.position;
		return t === 0 ? "Queued: yours runs next" : `Queued: ${String(t)} ranking${t === 1 ? "" : "s"} ahead of yours`;
	}
	let { progress: t } = e;
	return t === null ? "Ranking: listing the candidates…" : t.done < t.total ? `Ranking candidate ${String(t.done + 1)} of ${String(t.total)}` : "Ranking: comparing the energies…";
}
function Ch({ error: e, listed: t }) {
	let n = Ef();
	return /* @__PURE__ */ E(Q, {
		gap: 4,
		align: "flex-start",
		children: [/* @__PURE__ */ T(Z, {
			c: "red",
			size: "sm",
			role: "alert",
			children: e
		}), t ? null : /* @__PURE__ */ T(wc, {
			size: "xs",
			variant: "light",
			leftSection: /* @__PURE__ */ T(Hd, {
				"aria-hidden": "true",
				size: 14
			}),
			onClick: () => void n.dispatch({ type: "magneticOrderings.list" }),
			children: "Retry listing"
		})]
	});
}
// src/cards/MagneticOrderingsCard.tsx
function wh({ kicker: e }) {
	return /* @__PURE__ */ E(Mi, {
		component: "section",
		id: "magnetic-orderings-panel",
		"aria-label": "Magnetic orderings",
		withBorder: !0,
		p: "md",
		className: "workbench-card card-magnetic-orderings",
		children: [/* @__PURE__ */ E(X, {
			component: "header",
			className: "card-header",
			mb: "md",
			wrap: "nowrap",
			children: [/* @__PURE__ */ T(Z, {
				className: "card-kicker",
				children: e
			}), /* @__PURE__ */ T(pd, {
				order: 2,
				children: "Magnetic Orderings"
			})]
		}), /* @__PURE__ */ T("div", {
			className: "card-body",
			tabIndex: 0,
			children: /* @__PURE__ */ T(bh, {})
		})]
	});
}
// src/viewer/siteCount.ts
function Th(e, t) {
	return `${String(e)} ${t}${e === 1 ? "" : "s"}`;
}
// src/controls/StructureSourceControls.tsx
function Eh({ source: e, inspection: t, inspecting: n, onOpen: r }) {
	let i = v(null), a = v(0), [o, s] = y(!1), [c, l] = y(null);
	async function u(e) {
		let t = ++a.current;
		if (l(null), e.size > 5242880) l("Structure files must be 5 MB or smaller.");
		else if (e.size === 0) l("The selected structure file is empty.");
		else try {
			let n = await e.text();
			if (t !== a.current) return;
			await r({
				structure_content: n,
				structure_name: e.name,
				structure_format: Oh(e.name)
			});
		} catch {
			t === a.current && l("The selected file could not be read.");
		}
	}
	function d(e) {
		i.current?.(), e !== null && u(e);
	}
	function f(e) {
		e.preventDefault(), s(!1);
		let t = e.dataTransfer.files[0];
		t !== void 0 && u(t);
	}
	let p = "CIF or POSCAR · 5 MB maximum file size";
	e !== null && (p = "Inspecting structure"), t !== null && (p = `${Th(t.structure.site_count, "site")} · parsed`);
	let m = {
		onDragEnter: (e) => {
			e.preventDefault(), s(!0);
		},
		onDragOver: (e) => {
			e.preventDefault();
		},
		onDragLeave: () => {
			s(!1);
		},
		onDrop: f,
		"aria-busy": n,
		bg: o ? "var(--mantine-primary-color-light)" : "var(--mantine-color-body)"
	}, h = /* @__PURE__ */ T(Mc, {
		resetRef: i,
		onChange: d,
		disabled: n,
		children: (t) => /* @__PURE__ */ T(wc, {
			...t,
			variant: "subtle",
			type: "button",
			"aria-describedby": "structure-source-help",
			disabled: n,
			children: e === null ? "Browse files" : "Replace file"
		})
	});
	return /* @__PURE__ */ E(w, { children: [e === null ? /* @__PURE__ */ T(Mi, {
		withBorder: !0,
		p: "md",
		...m,
		children: /* @__PURE__ */ E(Q, {
			align: "center",
			gap: "xs",
			children: [
				/* @__PURE__ */ T(Kd, {
					"aria-hidden": "true",
					size: 18
				}),
				/* @__PURE__ */ T(Z, {
					fw: 600,
					truncate: !0,
					w: "100%",
					ta: "center",
					children: "Drop a structure"
				}),
				/* @__PURE__ */ T(Z, {
					id: "structure-source-help",
					c: "dimmed",
					size: "sm",
					ta: "center",
					children: p
				}),
				h
			]
		})
	}) : /* @__PURE__ */ T(Mi, {
		withBorder: !0,
		p: "xs",
		...m,
		children: /* @__PURE__ */ E(Q, {
			gap: 4,
			children: [
				/* @__PURE__ */ E(X, {
					gap: "xs",
					wrap: "nowrap",
					style: { minWidth: 0 },
					children: [n ? /* @__PURE__ */ T(ia, {
						size: "xs",
						"aria-hidden": "true"
					}) : /* @__PURE__ */ T(Kd, {
						"aria-hidden": "true",
						size: 16
					}), /* @__PURE__ */ T(Z, {
						fw: 600,
						truncate: !0,
						children: e.structure_name
					})]
				}),
				/* @__PURE__ */ E(X, {
					justify: "space-between",
					wrap: "nowrap",
					gap: "xs",
					children: [/* @__PURE__ */ T(Z, {
						id: "structure-source-help",
						c: "dimmed",
						size: "sm",
						truncate: !0,
						children: p
					}), h]
				}),
				t === null ? null : /* @__PURE__ */ T(Dh, { inspection: t })
			]
		})
	}), c === null ? null : /* @__PURE__ */ T(Z, {
		c: "red",
		size: "sm",
		role: "alert",
		children: c
	})] });
}
function Dh({ inspection: e }) {
	let t = e.structure, n = [...new Set(t.sites.flatMap((e) => e.species.map((e) => e.symbol)))];
	return /* @__PURE__ */ E(Z, {
		size: "sm",
		c: "dimmed",
		truncate: !0,
		"aria-label": "Inspected structure summary",
		children: [
			t.formula,
			" · ",
			n.join(" "),
			" ·",
			" ",
			t.lattice.volume_angstrom3.toFixed(1),
			" Å³"
		]
	});
}
function Oh(e) {
	return e.toLowerCase().endsWith(".cif") ? "cif" : "poscar";
}
// src/viewer/StructureFallback.tsx
function kh({ structure: e, onRetry: t, containerRef: n, hidden: r = !1 }) {
	return /* @__PURE__ */ E(Ps, {
		ref: n,
		title: "3D structure preview unavailable",
		pos: "absolute",
		top: "25%",
		left: "10%",
		right: "10%",
		style: { zIndex: 5 },
		hidden: r,
		role: "status",
		"aria-live": "polite",
		children: [
			/* @__PURE__ */ E(Z, { children: [
				e.reduced_formula,
				" ·",
				" ",
				Th(e.site_count, "atomic site")
			] }),
			/* @__PURE__ */ T(Z, {
				size: "sm",
				mt: "sm",
				children: "The parsed structure and recommendation remain available without the interactive preview."
			}),
			/* @__PURE__ */ T(wc, {
				mt: "md",
				variant: "light",
				onClick: t,
				children: "Retry 3D preview"
			})
		]
	});
}
// src/viewer/cellFraming.ts
var Ah = 1.2, jh = [
	[
		1,
		1,
		1
	],
	[
		1,
		1,
		-1
	],
	[
		1,
		-1,
		1
	],
	[
		-1,
		1,
		1
	]
];
function Mh([e, t, n], r, i) {
	let a = [
		(e[0] + t[0] + n[0]) / 2,
		(e[1] + t[1] + n[1]) / 2,
		(e[2] + t[2] + n[2]) / 2
	], o = Math.max(...jh.map(([r, i, a]) => Math.hypot(r * e[0] + i * t[0] + a * n[0], r * e[1] + i * t[1] + a * n[1], r * e[2] + i * t[2] + a * n[2]) / 2)), s = i * Math.PI / 360, c = Math.atan(Math.tan(s) * r.width / r.height), l = Math.min(s, c);
	return {
		center: a,
		distance: Ah * o / Math.sin(l)
	};
}
// src/viewer/structureViewer.ts
var Nh, Ph, Fh = 20;
function Ih(e) {
	let t = e.getCrystData();
	if (t === null) throw Error("The structure has no unit cell.");
	let [n, r, i, a, o, s, c, l, u] = t.matrix.elements;
	return [
		[
			n,
			r,
			i
		],
		[
			a,
			o,
			s
		],
		[
			c,
			l,
			u
		]
	];
}
var Lh = async (t, n) => {
	n.throwIfAborted();
	let { createViewer: r } = await import("./3Dmol-CTZO0q6j.js").then((t) => /* @__PURE__ */ e(t.default, 1));
	if (n.throwIfAborted(), Nh === void 0) {
		let e = document.createElement("div");
		e.style.cssText = "position:relative;width:100%;height:100%", t.append(e);
		try {
			let t = r(e, { antialias: !0 });
			t.setCameraParameters({ fov: Fh }), Nh = {
				viewer: t,
				surface: e
			};
		} catch (t) {
			throw e.remove(), t;
		}
	}
	let { viewer: i, surface: a } = Nh, o = Symbol();
	Ph = o, t.append(a), i.resize();
	let s, c = () => {
		let { offsetWidth: e, offsetHeight: t } = a;
		if (s === void 0 || e === 0 || t === 0) return;
		let { center: n, distance: r } = Mh(s, {
			width: e,
			height: t
		}, Fh);
		i.setPerceivedDistance(r);
		let [, , , ...o] = i.getView();
		i.setView([
			-n[0],
			-n[1],
			-n[2],
			...o
		]);
	}, l = new ResizeObserver(() => {
		Ph === o && c();
	});
	return l.observe(a), {
		show(e) {
			if (Ph !== o) return;
			i.clear();
			let t = i.addModel(e, "cif");
			i.setStyle({}, {
				sphere: {
					scale: .3,
					colorscheme: "Jmol"
				},
				stick: {
					radius: .12,
					colorscheme: "Jmol"
				}
			});
			let n = getComputedStyle(document.documentElement);
			i.addUnitCell(t, { box: {
				color: n.getPropertyValue("--mantine-color-gray-6").trim(),
				linewidth: 1.5
			} }), s = Ih(t), i.zoomTo(), c(), i.render();
		},
		refreshTheme() {
			if (Ph !== o) return;
			let e = getComputedStyle(document.documentElement).getPropertyValue("--mantine-color-body").trim();
			i.setBackgroundColor(e, 1);
		},
		dispose() {
			l.disconnect(), Ph === o && (Ph = void 0, i.clear(), a.remove());
		}
	};
}, Rh = [
	"a",
	"b",
	"c"
], zh = [
	"α",
	"β",
	"γ"
];
function Bh({ inspection: e, createViewer: t = Lh }) {
	let n = v(null), r = v(null), i = v(e.canonical_cif), a = v(null), [o, s] = y(0), c = tn("light"), [l, u] = y(!1);
	p(() => {
		let e = n.current;
		if (e === null) return;
		let o = new AbortController();
		return (async () => {
			try {
				let n = await t(e, o.signal);
				if (o.signal.aborted) {
					n.dispose();
					return;
				}
				r.current = n, n.refreshTheme(), n.show(i.current), a.current !== null && (a.current.hidden = !0);
			} catch {
				!o.signal.aborted && a.current !== null && (a.current.hidden = !1);
			}
		})(), () => {
			o.abort(), r.current?.dispose(), r.current = null;
		};
	}, [t, o]), p(() => {
		if (i.current = e.canonical_cif, r.current !== null) try {
			r.current.show(e.canonical_cif), a.current !== null && (a.current.hidden = !0);
		} catch {
			a.current !== null && (a.current.hidden = !1);
		}
	}, [e.canonical_cif]), p(() => {
		r.current?.refreshTheme();
	}, [c]);
	let d = e.structure.lattice, f = e.structure.sites.some((e) => e.species.length !== 1 || e.species.some((e) => e.occupancy !== 1));
	return /* @__PURE__ */ E(Y, {
		component: "section",
		"aria-label": "Crystal structure viewer",
		style: {
			display: "flex",
			flexDirection: "column"
		},
		w: "100%",
		h: "100%",
		children: [
			/* @__PURE__ */ E(Y, {
				pos: "relative",
				style: {
					flex: 1,
					minHeight: 0
				},
				children: [
					/* @__PURE__ */ T(Y, {
						pos: "absolute",
						inset: 0,
						ref: n
					}),
					/* @__PURE__ */ T(kh, {
						structure: e.structure,
						containerRef: a,
						hidden: !0,
						onRetry: () => {
							s((e) => e + 1);
						}
					}),
					/* @__PURE__ */ E(X, {
						pos: "absolute",
						top: 10,
						left: 10,
						align: "baseline",
						gap: 6,
						children: [/* @__PURE__ */ T(pd, {
							order: 3,
							children: e.structure.reduced_formula
						}), /* @__PURE__ */ T(Z, {
							size: "xs",
							c: "dimmed",
							children: Th(e.structure.site_count, "atomic site")
						})]
					})
				]
			}),
			/* @__PURE__ */ E(Q, {
				gap: 6,
				mt: 6,
				children: [f ? /* @__PURE__ */ T(Z, {
					size: "xs",
					c: "dimmed",
					role: "note",
					children: "Mixed or partial occupancy: this 3D preview is an approximation. Inspect the canonical site details for the exact species and occupancies."
				}) : null, /* @__PURE__ */ T(wc, {
					size: "compact-sm",
					fullWidth: !0,
					styles: { label: { whiteSpace: "normal" } },
					onClick: () => {
						u(!0);
					},
					children: "Inspect lattice, sites and occupancies"
				})]
			}),
			/* @__PURE__ */ T(ll, {
				opened: l,
				onClose: () => {
					u(!1);
				},
				title: "Lattice, sites and occupancies",
				size: "lg",
				closeButtonProps: { "aria-label": "Close canonical site details" },
				children: l ? /* @__PURE__ */ E(Q, { children: [
					/* @__PURE__ */ T(Z, {
						size: "sm",
						children: "Canonical inspection data. Occupancies are fractions of each site; coordinates are fractional lattice coordinates."
					}),
					/* @__PURE__ */ E(Mi, {
						component: "section",
						"aria-label": "Lattice parameters",
						p: "sm",
						withBorder: !0,
						children: [/* @__PURE__ */ T(pd, {
							order: 4,
							mb: "xs",
							children: "Lattice parameters"
						}), /* @__PURE__ */ E(Ru, {
							component: "dl",
							cols: 3,
							spacing: "md",
							m: 0,
							children: [
								d.lengths_angstrom.map((e, t) => /* @__PURE__ */ E("div", { children: [/* @__PURE__ */ T("dt", { children: Rh[t] }), /* @__PURE__ */ E("dd", { children: [e.toFixed(3), " Å"] })] }, t)),
								d.angles_degrees.map((e, t) => /* @__PURE__ */ E("div", { children: [/* @__PURE__ */ T("dt", { children: zh[t] }), /* @__PURE__ */ E("dd", { children: [e.toFixed(3), "°"] })] }, t)),
								/* @__PURE__ */ E("div", { children: [/* @__PURE__ */ T("dt", { children: "V" }), /* @__PURE__ */ E("dd", { children: [d.volume_angstrom3.toFixed(2), " Å³"] })] })
							]
						})]
					}),
					e.structure.sites.map((e, t) => /* @__PURE__ */ E(Mi, {
						component: "section",
						"aria-label": `Site ${String(t + 1)}`,
						p: "sm",
						withBorder: !0,
						children: [
							/* @__PURE__ */ E(pd, {
								order: 3,
								children: ["Site ", t + 1]
							}),
							/* @__PURE__ */ E(Z, {
								size: "sm",
								style: { overflowWrap: "anywhere" },
								children: [
									"Fractional coordinates:",
									" ",
									e.fractional_coordinates.join(", ")
								]
							}),
							/* @__PURE__ */ E($, {
								layout: "fixed",
								style: { overflowWrap: "anywhere" },
								children: [/* @__PURE__ */ T($.Thead, { children: /* @__PURE__ */ E($.Tr, { children: [
									/* @__PURE__ */ T($.Th, {
										scope: "col",
										children: "Species"
									}),
									/* @__PURE__ */ T($.Th, {
										scope: "col",
										children: "Element"
									}),
									/* @__PURE__ */ T($.Th, {
										scope: "col",
										children: "Occupancy"
									})
								] }) }), /* @__PURE__ */ T($.Tbody, { children: e.species.map((e, t) => /* @__PURE__ */ E($.Tr, { children: [
									/* @__PURE__ */ T($.Th, {
										scope: "row",
										children: e.label
									}),
									/* @__PURE__ */ T($.Td, { children: e.symbol }),
									/* @__PURE__ */ T($.Td, { children: e.occupancy })
								] }, t)) })]
							})
						]
					}, t))
				] }) : null
			})
		]
	});
}
// src/cards/StructureCard.tsx
function Vh({ kicker: e }) {
	let t = Ef(), n = Df();
	return /* @__PURE__ */ E(Mi, {
		component: "section",
		id: "structure-panel",
		"aria-label": "Structure workspace",
		withBorder: !0,
		p: "md",
		className: "workbench-card card-structure",
		children: [/* @__PURE__ */ E(X, {
			component: "header",
			className: "card-header",
			mb: "md",
			wrap: "nowrap",
			children: [/* @__PURE__ */ T(Z, {
				className: "card-kicker",
				children: e
			}), /* @__PURE__ */ T(pd, {
				order: 2,
				children: "Structure Setup"
			})]
		}), /* @__PURE__ */ E("div", {
			className: "card-body",
			tabIndex: 0,
			children: [
				/* @__PURE__ */ T(Eh, {
					source: n.structureInput,
					inspection: n.inspection,
					inspecting: n.operation === "inspect",
					onOpen: (e) => t.dispatch({
						type: "source.open",
						input: e
					})
				}),
				/* @__PURE__ */ T(mp, {}),
				/* @__PURE__ */ T("div", {
					className: "structure-stage",
					children: n.inspection === null ? /* @__PURE__ */ T(Hh, {
						loading: n.capabilities === null || n.operation === "inspect",
						label: n.capabilities === null ? "Loading Workbench" : void 0
					}) : /* @__PURE__ */ T(Bh, { inspection: n.inspection })
				})
			]
		})]
	});
}
function Hh({ loading: e, label: t = e ? "Reading structure" : "No structure selected" }) {
	return /* @__PURE__ */ E(Q, {
		align: "center",
		justify: "center",
		h: "100%",
		p: "xl",
		gap: "xl",
		role: e ? "status" : void 0,
		children: [e ? /* @__PURE__ */ T(ia, {
			size: "xl",
			"aria-hidden": "true"
		}) : /* @__PURE__ */ T(Pd, {
			size: 96,
			strokeWidth: 1,
			"aria-hidden": "true"
		}), /* @__PURE__ */ T(pd, {
			order: 3,
			ta: "center",
			children: t
		})]
	});
}
// src/layout/AppHeader.tsx
function Uh({ theme: e, onToggleTheme: t }) {
	return /* @__PURE__ */ E(X, {
		component: "header",
		justify: "space-between",
		wrap: "nowrap",
		px: "md",
		className: "app-header",
		children: [/* @__PURE__ */ E(X, {
			gap: "xs",
			wrap: "nowrap",
			children: [/* @__PURE__ */ T("img", {
				src: "/brand/goldilocks-logo.png",
				alt: "",
				width: 40,
				height: 40
			}), /* @__PURE__ */ T(Z, {
				style: {
					fontSize: "var(--mantine-h2-font-size)",
					fontWeight: "var(--mantine-h2-font-weight)",
					color: "#ffffff",
					lineHeight: 1.1
				},
				children: "Goldilocks"
			})]
		}), /* @__PURE__ */ T(fa, {
			variant: "subtle",
			className: "app-header-toggle",
			style: { color: "rgba(255, 255, 255, 0.85)" },
			"aria-label": e === "light" ? "Switch to dark mode" : "Switch to light mode",
			title: e === "light" ? "Dark mode" : "Light mode",
			onClick: t,
			children: T(e === "light" ? Wd : Bd, {
				"aria-hidden": "true",
				size: 17
			})
		})]
	});
}
// src/status/FailureBanner.tsx
function Wh({ failure: e, dismissAvailable: t, onRetry: n, onDismiss: r }) {
	let i = tf(e);
	return /* @__PURE__ */ T(Ps, {
		className: "failure-banner",
		color: "red",
		title: Gh[e.kind] ?? "Calculation failed",
		withCloseButton: t,
		closeButtonLabel: "Dismiss error",
		styles: { closeButton: {
			width: 44,
			height: 44
		} },
		onClose: r,
		role: "alert",
		children: /* @__PURE__ */ E(X, {
			justify: "space-between",
			children: [i.length === 0 ? /* @__PURE__ */ T(Z, {
				flex: 1,
				children: e.message
			}) : /* @__PURE__ */ T(Y, {
				flex: 1,
				children: /* @__PURE__ */ T(Nf, { findings: i })
			}), /* @__PURE__ */ T(wc, {
				color: "red",
				variant: "light",
				onClick: n,
				leftSection: /* @__PURE__ */ T(Hd, {
					"aria-hidden": "true",
					size: 15
				}),
				children: "Retry"
			})]
		})
	});
}
var Gh = {
	invalid_request: "Check the request",
	invalid_setting: "Check your overrides",
	advice_incomplete: "Recommendation incomplete",
	invalid_hpc_profile: "Check the HPC profile",
	invalid_structure: "Check the structure",
	assets_unavailable: "Runtime assets unavailable",
	asset_not_installed: "Runtime assets unavailable",
	asset_corrupt: "Runtime assets unavailable",
	pseudo_import_error: "Pseudopotential import failed",
	generation_error: "Could not generate input files",
	submission_error: "Could not generate the submission script",
	network_error: "Cannot reach Core",
	invalid_response: "Unexpected server response",
	http_error: "Request failed",
	incompatible_vocabulary: "Frontend/backend version mismatch"
};
// src/status/OperationStatus.tsx
function Kh({ operation: e, needsAttention: t }) {
	return /* @__PURE__ */ T(ki, {
		role: "status",
		"aria-label": "Workbench status",
		"aria-live": "polite",
		"aria-atomic": "true",
		children: Jh(e, t)
	});
}
var qh = {
	capabilities: "Loading capabilities",
	inspect: "Inspecting structure",
	explain: "Computing recommendation",
	preview: "Generating input files"
};
function Jh(e, t) {
	return e === null ? t ? "Needs attention" : "Ready" : qh[e];
}
// src/theme.ts
var Yh = _t({ key: "goldilocks-theme" }), Xh = On({
	primaryColor: "blue",
	primaryShade: 6,
	autoContrast: !0,
	colors: { blue: [
		"#f0f7ff",
		"#dbeafe",
		"#bfdbfe",
		"#93c5fd",
		"#60a5fa",
		"#3b82f6",
		"#0071e3",
		"#005bb8",
		"#004a94",
		"#003970"
	] },
	fontFamily: "-apple-system, BlinkMacSystemFont, Inter, \"Avenir Next\", \"Segoe UI\", ui-sans-serif, system-ui, sans-serif",
	fontFamilyMonospace: "\"IBM Plex Mono\", \"SFMono-Regular\", Consolas, monospace",
	defaultRadius: "lg",
	shadows: {
		xs: "0 1px 2px rgba(0, 0, 0, 0.04)",
		sm: "0 2px 6px rgba(0, 0, 0, 0.05)",
		md: "0 6px 16px rgba(0, 0, 0, 0.07)",
		lg: "0 16px 32px -12px rgba(0, 0, 0, 0.16)",
		xl: "0 24px 48px -16px rgba(0, 0, 0, 0.2)"
	},
	respectReducedMotion: !0,
	components: {
		Button: wc.extend({
			defaultProps: { radius: "xl" },
			styles: { root: { minHeight: 44 } }
		}),
		ActionIcon: fa.extend({ defaultProps: {
			size: 44,
			radius: "xl"
		} }),
		Input: gs.extend({ styles: { input: { minHeight: 44 } } }),
		NativeSelect: pl.extend({ defaultProps: { size: "md" } }),
		NumberInput: ku.extend({ defaultProps: {
			size: "md",
			role: "spinbutton",
			clampBehavior: "none"
		} }),
		Checkbox: fc.extend({
			defaultProps: { size: "xs" },
			styles: { body: {
				minHeight: 44,
				alignItems: "center"
			} }
		})
	}
}), Zh = 400, Qh = 150;
function $h(e, t) {
	let { revision: n } = t, r = mf(t), i = hf(t);
	p(() => {
		if (!r) return;
		let t = setTimeout(() => {
			e.dispatch({ type: "review.compute" });
		}, Zh);
		return () => {
			clearTimeout(t);
		};
	}, [
		e,
		r,
		n
	]), p(() => {
		if (!i) return;
		let t = setTimeout(() => {
			e.dispatch({ type: "review.refreshArchive" });
		}, Qh);
		return () => {
			clearTimeout(t);
		};
	}, [
		e,
		i,
		n
	]);
}
// src/App.tsx
function eg() {
	return /* @__PURE__ */ T(Dn, {
		theme: Xh,
		colorSchemeManager: Yh,
		defaultColorScheme: "light",
		children: /* @__PURE__ */ T(rg, {})
	});
}
function tg() {
	let e = Ef(), t = Df();
	$h(e, t);
	let n = ng(t.reviewed?.records.magnetic), r = n ? 2 : 1, i = 3 + r, a = yf(t);
	return /* @__PURE__ */ E("div", {
		className: "workbench-content",
		children: [
			/* @__PURE__ */ T(Kh, {
				operation: t.operation,
				needsAttention: wf(t)
			}),
			a === null ? null : /* @__PURE__ */ T(Wh, {
				failure: a.failure,
				dismissAvailable: a.operation !== "capabilities",
				onRetry: () => {
					e.dispatch({
						type: "failure.retry",
						operation: a.operation
					});
				},
				onDismiss: () => {
					e.dispatch({
						type: "failure.dismiss",
						operation: a.operation
					});
				}
			}),
			/* @__PURE__ */ E("main", {
				className: "workbench-grid",
				"aria-labelledby": "workbench-title",
				style: {
					"--workbench-columns": i,
					"--workbench-wide-columns": r
				},
				children: [
					/* @__PURE__ */ T(ki, { children: /* @__PURE__ */ T("h1", {
						id: "workbench-title",
						children: "Goldilocks SCF setup"
					}) }),
					/* @__PURE__ */ T(Vh, { kicker: "01" }),
					/* @__PURE__ */ T(Wp, { kicker: "02" }),
					/* @__PURE__ */ T(zp, { kicker: "03" }),
					n ? /* @__PURE__ */ T(wh, { kicker: "04" }) : null,
					/* @__PURE__ */ T(Xm, { kicker: n ? "05" : "04" })
				]
			})
		]
	});
}
function ng(e) {
	if (e?.status !== "resolved") return !1;
	let t = e.value;
	return typeof t != "object" || !t ? !1 : t.spin_polarized === !0;
}
function rg() {
	let e = tn("light"), { toggleColorScheme: t } = Qt();
	return p(() => {
		document.querySelector("meta[name=\"theme-color\"]")?.setAttribute("content", e === "light" ? "#ffffff" : "#242424");
	}, [e]), /* @__PURE__ */ E("div", {
		className: "app-layout",
		children: [/* @__PURE__ */ T(Uh, {
			theme: e,
			onToggleTheme: t
		}), /* @__PURE__ */ T(tg, {})]
	});
}
// src/workspace/WorkspaceProvider.tsx
function ig({ workspace: e, children: t }) {
	return p(() => {
		e.dispatch({ type: "workspace.start" });
	}, [e]), /* @__PURE__ */ T(Tf.Provider, {
		value: e,
		children: t
	});
}
export { eg as App, mp as CalculationContextControls, Yd as HttpCoreClient, Dn as MantineProvider, tg as WorkbenchContent, ig as WorkspaceProvider, yf as bannerFailure, Yh as colorSchemeManager, _h as createWorkspace, ff as currentArchive, uf as currentExplain, pf as currentFindings, gh as currentOrderings, df as currentPreview, tf as findingsOf, vh as saveArchiveToBrowser, Ef as useWorkspace, Df as useWorkspaceSnapshot, Xh as workbenchTheme };
