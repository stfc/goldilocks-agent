import { ResolvedField, Setting, Source } from '../api/coreClient';
/** The record `setting.resolved_in` names in `records`: the record of the
 * decision the setting feeds (#187). */
export declare function settingRecord(setting: Pick<Setting, "resolved_in">, records: Readonly<Record<string, ResolvedField>> | undefined): ResolvedField | undefined;
/** `setting`'s resolved value: what `setting.resolved_in.path` leads to in
 * its resolved `record`. `undefined` while the record is not resolved,
 * for a setting without a path (the record holds no value of it), and
 * where the path leads to nothing. */
export declare function resolvedValue(setting: Pick<Setting, "resolved_in">, record: ResolvedField | undefined): unknown;
/** The tier to caption `setting`'s resolved value with, naming only the
 * tier that produced that value: none while there is no value; for a value
 * that is the whole record, the record's source; else the setting's own
 * entry in the record's `field_sources`; else the record's source, unless
 * that is `human` -- a setting the request set reads `human` in
 * `field_sources` or is pinned in the draft, so a record-level `human`
 * came from another of the record's settings. */
export declare function resolvedSource(setting: Pick<Setting, "key" | "resolved_in">, record: ResolvedField | undefined): Source | undefined;
