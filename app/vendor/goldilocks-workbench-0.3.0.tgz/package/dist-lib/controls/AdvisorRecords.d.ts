import { ResolvedField } from '../api/coreClient';
/** The advisor records `names` of `records`, read-only, as items of the
 * Advisors accordion they are rendered in: decisions no setting the card
 * shows resolves into, such as `pseudopotentials` or `symmetry_eff`
 * (#187). */
export declare function AdvisorRecordItems({ names, records, }: {
    readonly names: readonly string[];
    readonly records: Readonly<Record<string, ResolvedField>>;
}): import('react').JSX.Element;
/** The read-only records `names` of one step of a task with more than one
 * step, under a heading naming the step (`nscf step`, `bands step`,
 * `relax step`): a dos task's nscf decisions under their `nscf_` names, a
 * band task's bands-step path as `k_path` and its other decisions under
 * their `bands_` names, or a phonon task's decisions of one step, such as
 * its first step's `fft_grid` (#187, #118, #215). */
export declare function AdvisorStepRecords({ step, names, records, }: {
    readonly step: string;
    readonly names: readonly string[];
    readonly records: Readonly<Record<string, ResolvedField>>;
}): import('react').JSX.Element;
