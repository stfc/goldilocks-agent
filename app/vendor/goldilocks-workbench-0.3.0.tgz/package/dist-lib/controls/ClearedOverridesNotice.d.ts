/** Names the overrides that opening the current structure set back to
 * automatic (`WorkspaceSnapshot.clearedOverrides`, #188), by the labels of
 * their controls. Dismissing it hides that list only: the next structure
 * that clears overrides stores a new list, which shows again. */
export declare function ClearedOverridesNotice(): import('react').JSX.Element | null;
