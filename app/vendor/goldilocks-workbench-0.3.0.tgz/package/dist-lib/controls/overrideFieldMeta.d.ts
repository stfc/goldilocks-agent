import { ReactNode } from 'react';
import { Setting, Source } from '../api/coreClient';
export interface OverrideFieldMeta {
    readonly key: string;
    readonly type: string;
    readonly enum?: readonly string[] | undefined;
    readonly unit?: string | null;
    readonly default?: unknown;
    readonly description: string;
}
export declare function fieldLabel(meta: Pick<OverrideFieldMeta, "key" | "unit">): string;
/** The labels of the override controls that do not show their
 * `fieldLabel`. */
export declare const CONTROL_LABELS: {
    readonly functional: "Functional";
    readonly pseudo_table_id: "Pseudopotential table";
    readonly k_grid: "K-point grid";
};
/** The label of the control that edits override `key`, a setting or a fact
 * (which has no unit): `CONTROL_LABELS` or its `fieldLabel`. */
export declare function overrideLabel(key: string, settings: readonly Setting[]): string;
/** `unknown`-safe stringification -- most override values are
 * primitives, but array/object-shaped ones (`k_grid`, `u_by_element`)
 * would otherwise stringify to the useless `"[object Object]"`. */
export declare function stringifyValue(value: unknown): string;
export declare function automaticPlaceholder(meta: OverrideFieldMeta): string;
/** An override control's own description names the tier that produced
 * the value it shows -- "Your override" once pinned, else `source`, which
 * the caller derives from the value shown (`resolvedSource`: a setting
 * without a recorded value has none, #187), else the field's own
 * description alone. */
export declare function describeSource(description: string, pinned: boolean, source: Source | null | undefined): ReactNode;
