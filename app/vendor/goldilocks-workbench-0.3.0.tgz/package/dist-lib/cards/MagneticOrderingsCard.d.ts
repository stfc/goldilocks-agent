/** Auto-shown by `Workbench` only once the magnetic decision resolves
 * spin-polarized -- see `App.tsx`'s `showMagneticOrderings` -- rather
 * than always present like the other four columns, since exploring
 * alternative magnetic orderings is meaningless for a spin-unpolarized
 * run. */
export declare function MagneticOrderingsCard({ kicker }: {
    readonly kicker: string;
}): import('react').JSX.Element;
