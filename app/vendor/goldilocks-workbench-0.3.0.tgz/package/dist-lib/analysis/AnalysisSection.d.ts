/** goldilocks-core's own analysis tier only ever needs the structure --
 * `capabilities.facts` (is_metal/is_magnetic/needs_soc/needs_correlation)
 * plus the other records the response lays out in its analysis tier
 * (composition/geometry/symmetry, `RecordLayout.analysis`, #187). A fact
 * is an override control only when `Fact.overridable` says the core takes
 * a value for it; the others (needs_soc, advice that only a notice reads,
 * #186) are read-only `FactSummary`s. Every other record lives in the
 * Advisors card, next to the setting it belongs to or read-only after
 * them. A finding that concerns a fact is shown under it (#151). Rendered
 * inside `AnalysisCard`, which owns the "Analysis" heading -- this
 * component starts directly with its content. */
export declare function AnalysisSection(): import('react').JSX.Element | null;
