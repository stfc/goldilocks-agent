import { Fact, ResolvedField } from '../api/coreClient';
/** A fact that takes no override (`Fact.overridable` false, such as
 * `needs_soc`, #186), shown read-only: the label and description of an
 * override control, at the size of the selects beside it (the theme's
 * NativeSelect size), the description naming the tier that resolved the
 * value, then the value itself as text ("—" until one resolves). A group
 * named by the label and described by the description holds the three. */
export declare function FactSummary({ fact, record, }: {
    readonly fact: Fact;
    readonly record: ResolvedField | undefined;
}): import('react').JSX.Element;
