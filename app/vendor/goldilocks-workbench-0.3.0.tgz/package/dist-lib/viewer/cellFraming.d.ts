/** A Cartesian vector in ångström. */
export type Vector3 = readonly [number, number, number];
/** Lattice vectors a, b and c of a unit cell, in the viewer's Cartesian frame. */
export type CellVectors = readonly [Vector3, Vector3, Vector3];
export interface CellFraming {
    /** Look-at point: the cell centroid (a + b + c) / 2. */
    readonly center: Vector3;
    /** Distance from the camera to the centroid, in ångström. */
    readonly distance: number;
}
/**
 * Frames a unit cell for a perspective camera whose field of view is vertical
 * (3Dmol's camera). Returns the cell centroid and the camera distance at which
 * the sphere through the cell's farthest corner, enlarged by 20%, fits the
 * canvas's narrower angular extent. The sphere does not depend on the view
 * direction, so every corner stays inside the canvas however the cell is
 * rotated. Assumes a canvas with positive width and height.
 */
export declare function frameUnitCell([a, b, c]: CellVectors, canvas: {
    readonly width: number;
    readonly height: number;
}, fovDegrees: number): CellFraming;
