import { ArchiveDownload, BlockingFinding, CoreFailure, ExplainResult } from '../api/coreClient';
import { PipelineOutcome, WorkspaceOperation, WorkspaceSnapshot } from './workspace';
/** How the current draft's `/explain` settled, or null while it has no
 * outcome (not sent yet, or in flight). */
export declare function currentExplain(snapshot: WorkspaceSnapshot): PipelineOutcome<ExplainResult> | null;
/** How the current draft's preview `/run` settled, or null while it has no
 * outcome. */
export declare function currentPreview(snapshot: WorkspaceSnapshot): PipelineOutcome<ArchiveDownload> | null;
/** The archive fetched for the current draft, or null until it arrives. The
 * generated-inputs preview shows it, and `review.download` saves it and
 * nothing else. */
export declare function currentArchive(snapshot: WorkspaceSnapshot): ArchiveDownload | null;
/** The findings of the current draft (#151): its `/explain` verdict's, or,
 * while that verdict lets it through, those its refused preview `/run`
 * returned. The Bundle card lists them, each control their `fields` name
 * shows them, and their remedies patch the draft. */
export declare function currentFindings(snapshot: WorkspaceSnapshot): readonly BlockingFinding[];
/** Whether the current draft's `/explain` is due: a structure is open,
 * nothing is in flight and the draft has no outcome yet. A failure is an
 * outcome, so it is not sent again until the draft changes or Retry clears
 * it. */
export declare function explainDue(snapshot: WorkspaceSnapshot): boolean;
/** Whether the current draft's preview `/run` is due: its recommendation
 * arrived with an empty `blocking` verdict, nothing is in flight and no
 * preview has settled for it. A draft whose verdict blocks never gets a
 * `/run`. */
export declare function previewDue(snapshot: WorkspaceSnapshot): boolean;
/** A failure the workspace holds, and the operation `failure.retry` sends
 * again for it. */
export interface WorkspaceFailure {
    readonly operation: WorkspaceOperation;
    readonly failure: CoreFailure;
}
interface RecordedFailure {
    readonly failure: CoreFailure;
    readonly dismissed: boolean;
}
/** The failure recorded for `operation`, dismissed or not: loading
 * capabilities, the last structure that could not be opened, or the current
 * draft's `/explain` or preview. */
export declare function recordedFailure(snapshot: WorkspaceSnapshot, operation: WorkspaceOperation): RecordedFailure | null;
/** The failure the banner shows: the first undismissed one of loading
 * capabilities, opening a structure, and the current draft's `/explain` and
 * preview. Every failure offers Retry. */
export declare function bannerFailure(snapshot: WorkspaceSnapshot): WorkspaceFailure | null;
/** Where the open structure's current draft is on its way to input files.
 * `computing` and `recomputing` wait for its recommendation (without and
 * with an earlier one on screen), `generating` for its archive; `blocked`
 * is a recommendation whose `/explain` verdict refuses input generation. */
export type BundleStatus = {
    readonly kind: "empty";
} | {
    readonly kind: "computing";
} | {
    readonly kind: "recomputing";
} | {
    readonly kind: "explainFailed";
    readonly failure: CoreFailure;
} | {
    readonly kind: "blocked";
    readonly findings: readonly BlockingFinding[];
} | {
    readonly kind: "generating";
} | {
    readonly kind: "generationFailed";
    readonly failure: CoreFailure;
} | {
    readonly kind: "ready";
    readonly archive: ArchiveDownload;
};
export declare function bundleStatus(snapshot: WorkspaceSnapshot): BundleStatus;
/** Whether Download can save the current draft's archive. */
export interface DownloadState {
    readonly enabled: boolean;
    /** Why Download is disabled; null while it is enabled. */
    readonly reason: string | null;
}
export declare function downloadState(snapshot: WorkspaceSnapshot): DownloadState;
/** Whether something waits for the user: capabilities or a structure that
 * could not be loaded, or a current draft whose recommendation or input
 * generation failed (dismissed or not) or whose verdict refuses it. */
export declare function needsAttention(snapshot: WorkspaceSnapshot): boolean;
export {};
