import { Workspace, WorkspaceSnapshot } from './workspace';
/** There is no manual "generate"/"update recommendation" control in the
 * UI: the open structure's current draft is sent to `/explain`
 * automatically (debounced) on load and after every settings change, and
 * once its recommendation arrives with no blocking reason, its archive is
 * fetched from `/run` as the generated-inputs preview. The "Download"
 * button only saves that archive. Each request is sent only while the
 * current draft has no outcome for it (`explainDue`, `previewDue`): a
 * failure is that draft's outcome, so a failing request is not sent again
 * until the draft or the structure changes or the user presses Retry
 * (#150). */
export declare function useAutoCompute(workspace: Workspace, snapshot: WorkspaceSnapshot): void;
