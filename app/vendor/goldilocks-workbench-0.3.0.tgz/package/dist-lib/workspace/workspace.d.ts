import { ArchiveDownload, CalcTask, Capabilities, CoreClient, ExplainResult, MagneticOrderingsResult, StructureInput, StructureInspection, CoreFailure } from '../api/coreClient';
/** The Core request in flight. `preview` is the automatic `/run` that fetches
 * the current draft's archive; saving a file is not an operation, since
 * `review.download` only saves an archive already fetched. */
export type WorkspaceOperation = "capabilities" | "inspect" | "explain" | "preview";
/** Independent of `WorkspaceOperation`: listing/ranking/downloading
 * magnetic-ordering candidates is an opt-in side-quest a user runs from
 * the Advisors card, not the main structure -> compute -> download
 * pipeline -- it must not disable the rest of that pipeline's controls
 * (or vice versa) while in flight. One nullable field, same idiom as
 * `WorkspaceOperation` itself, covering its own three concerns. */
export type MagneticOrderingsOperation = "list" | "rank" | "download";
/** A magnetic-ordering listing and the structure it was requested for.
 * `result`, `error` and the request in flight (`operation`) belong to
 * `input` alone: read them through `currentOrderings`, which returns the
 * listing only while `input` is the open structure, and candidate bundles
 * take their structure and name from `input` (#149). */
export interface MagneticOrderingsListing {
    readonly input: StructureInput;
    readonly operation: MagneticOrderingsOperation | null;
    /** The last listing or ranking that arrived; kept while a new request
     * for the same structure runs. */
    readonly result: MagneticOrderingsResult | null;
    /** Shown inline in the Magnetic Orderings card, not the global
     * `FailureBanner` -- this is a side-quest failure, not a reason to
     * block the main pipeline the banner exists for. Not re-sent on its
     * own: the card lists a structure only when it has no listing, or when
     * the user presses its Retry listing. */
    readonly error: string | null;
}
/** The v2 request shape has no `intent`/`hints` vocabulary: every tunable
 * knob is a flat `overrides` entry reflected from `capabilities().settings`/
 * `.facts` (see `capabilities.py`'s own "add an advisor, its settings
 * automatically appear" design goal). A key's absence from `overrides`
 * means "let the heuristic/ml/llm chain decide" -- there is no separate
 * "automatic" sentinel value, matching `--set`'s own semantics. Opening
 * another structure keeps the draft except the overrides that describe the
 * structure it replaces (`carryOverDraft`, #188). */
export interface CalculationDraft {
    readonly code: string;
    readonly task: CalcTask;
    readonly hpc: string | null;
    readonly overrides: Readonly<Record<string, unknown>>;
    readonly fetchMissing: boolean;
}
/** The open structure and draft revision an `/explain` or preview `/run`
 * was sent for. A revision never repeats within a workspace, so neither
 * does a key. */
export interface PipelineKey {
    readonly input: StructureInput;
    readonly revision: number;
}
/** How the request sent for `key` settled. A failure stays the outcome of
 * its key: nothing sends that request again until the key changes or
 * `failure.retry` clears it, and `dismissed` only hides it from the banner
 * (#150). Read the current draft's outcomes through `pipelineStatus.ts`. */
export type PipelineOutcome<T> = {
    readonly key: PipelineKey;
    readonly status: "result";
    readonly value: T;
} | {
    readonly key: PipelineKey;
    readonly status: "failure";
    readonly failure: CoreFailure;
    readonly dismissed: boolean;
};
/** A structure that could not be opened, and why. The open structure, if
 * any, stays open. */
export interface InspectFailure {
    readonly input: StructureInput;
    readonly failure: CoreFailure;
}
export interface WorkspaceSnapshot {
    readonly capabilities: Capabilities | null;
    /** Why loading capabilities failed; cleared when they are requested
     * again. */
    readonly startupFailure: CoreFailure | null;
    readonly structureInput: StructureInput | null;
    readonly inspection: StructureInspection | null;
    /** The last structure that failed to open; cleared by the next open,
     * Dismiss or Retry. */
    readonly inspectFailure: InspectFailure | null;
    readonly draft: CalculationDraft | null;
    /** The override keys cleared from the draft when the open structure was
     * opened, in draft order: structure-specific settings and facts, which
     * described the structure it replaced (`carryOverDraft`, #188). Empty
     * before the first structure opens and after reset; a structure that
     * fails to open changes nothing. */
    readonly clearedOverrides: readonly string[];
    /** Counts every opened structure and every draft change for the
     * workspace's lifetime and is never reset, so every `PipelineKey` is
     * new, even when an embedder opens the same `StructureInput` again. */
    readonly revision: number;
    /** The last `/explain` result for the open structure -- records, warnings
     * and the `blocking` verdict, no files. It stays on screen while a later
     * revision is recomputed or after that revision's `/explain` failed, and
     * is the current draft's only while `currentExplain` holds it.
     * `/explain` never calls `generate()`, so it succeeds even when a `/run`
     * would refuse with `advice_incomplete`, and `blocking` then lists the
     * reasons; no preview `/run` is sent for such a draft. */
    readonly reviewed: ExplainResult | null;
    /** How the last `/explain` settled; see `currentExplain`. */
    readonly explain: PipelineOutcome<ExplainResult> | null;
    /** How the last preview `/run` settled; see `currentPreview` and
     * `currentArchive`. */
    readonly preview: PipelineOutcome<ArchiveDownload> | null;
    readonly operation: WorkspaceOperation | null;
    /** Read through `currentOrderings`. */
    readonly magneticOrderings: MagneticOrderingsListing | null;
}
export type WorkspaceAction = {
    readonly type: "workspace.start";
}
/** Inspects `input` and, once it parses, makes it the open structure,
 * with the draft carried over (`carryOverDraft`) and the outcomes and
 * listing of the structure it replaces dropped. */
 | {
    readonly type: "source.open";
    readonly input: StructureInput;
} | {
    readonly type: "draft.patch";
    readonly code?: string;
    readonly task?: CalcTask;
    readonly hpc?: string | null;
    /** Shallow-merged into the current overrides. A value of
     * `undefined` clears that key back to "automatic" rather than
     * setting it to `undefined` on the wire. */
    readonly overrides?: Readonly<Record<string, unknown>>;
}
/** Sends the current draft's `/explain` when it is due (`explainDue`):
 * not while a request is in flight, and not once the draft has an
 * outcome, a failure included. */
 | {
    readonly type: "review.compute";
}
/** Fetches the current draft's archive for the live preview without
 * saving it, once its recommendation arrived with no blocking reason and
 * while no preview has settled for it (`previewDue`) -- the auto-preview
 * effect calls this, not a user action. */
 | {
    readonly type: "review.refreshArchive";
}
/** Saves the current draft's archive (`currentArchive`) through the
 * archive sink. Sends no request: with no current archive it does
 * nothing, so a file is only ever saved by this explicit action. */
 | {
    readonly type: "review.download";
} | {
    readonly type: "magneticOrderings.list";
} | {
    readonly type: "magneticOrderings.rank";
} | {
    readonly type: "magneticOrderings.downloadSelected";
    readonly labels: readonly string[];
}
/** Clears the failure recorded for `operation` and sends that request
 * again, once. */
 | {
    readonly type: "failure.retry";
    readonly operation: WorkspaceOperation;
}
/** Hides the failure recorded for `operation` from the banner without
 * sending anything; an `/explain` or preview failure stays its draft's
 * outcome. A capabilities failure cannot be dismissed. */
 | {
    readonly type: "failure.dismiss";
    readonly operation: WorkspaceOperation;
} | {
    readonly type: "workspace.reset";
};
export interface Workspace {
    getSnapshot(): WorkspaceSnapshot;
    subscribe(listener: () => void): () => void;
    dispatch(action: WorkspaceAction): Promise<void>;
}
type ArchiveSink = (archive: ArchiveDownload) => void;
/** The magnetic-ordering listing of the open structure, or null when it
 * has none (nothing requested yet, or the listing belongs to another
 * structure). The card lists the open structure whenever this is null. */
export declare function currentOrderings(snapshot: WorkspaceSnapshot): MagneticOrderingsListing | null;
export declare function createWorkspace(core: CoreClient, saveArchive?: ArchiveSink): Workspace;
export declare function saveArchiveToBrowser(archive: ArchiveDownload): void;
export {};
