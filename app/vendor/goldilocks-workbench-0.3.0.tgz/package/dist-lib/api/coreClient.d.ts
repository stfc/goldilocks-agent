import { components } from './schema';
export type StructureInput = components["schemas"]["InlineStructureDocument"];
export type ComputeRequest = components["schemas"]["ComputeRequestDocument"];
export type CalcTask = ComputeRequest["task"];
export type MagneticOrderingsRequest = components["schemas"]["MagneticOrderingsRequestDocument"];
export type Source = "human" | "ml" | "llm" | "heuristic";
export type FieldStatus = "resolved" | "unavailable" | "blocked";
/** Mirrors a published record, `resolution.ResolvedField` as
 * `records_document` projects it: a resolved record carries every
 * `resolution.Provenance` field. */
export interface ResolvedField<T = unknown> {
    readonly status: FieldStatus;
    readonly value?: T | null;
    readonly source?: Source | null;
    readonly field_sources?: Readonly<Record<string, Source>> | null;
    /** The records whose answers this record's rule followed, by name. */
    readonly derived_from?: readonly string[];
    /** The advisor's rationale, where it gives one. */
    readonly source_note?: string | null;
    /** The model that decided the value or one of its settings (a
     * `field_sources` entry `ml`). */
    readonly model?: ModelEvidence | null;
    /** What to cite for the value (a model's or the table's citation). */
    readonly citations?: readonly string[];
    readonly reason?: string | null;
    readonly blocked_by?: string | null;
}
/** Mirrors `resolution.Warning`. */
export interface AdvisorWarning {
    readonly code: string;
    readonly level: "info" | "warning" | "error";
    readonly category: string;
    readonly message: string;
}
/** Mirrors `resolution.ModelEvidence`: what a registered model returned,
 * verbatim (#156). */
export interface ModelEvidence {
    /** goldilocks-ml's id, e.g. `metallicity.is_metal.cgcnn@crystal_graph.v1`. */
    readonly model_id: string;
    /** The installed release, `<id>@<version>`. */
    readonly asset: string;
    readonly target_contract: string;
    readonly value: unknown;
    /** As returned: a classifier's `score`/`threshold`, QRF95's `interval`. */
    readonly details: Readonly<Record<string, unknown>>;
    readonly warnings: readonly AdvisorWarning[];
}
/** One entry of a response's top-level `warnings` (`resolution
 * .collect_warnings`): a record's warning, naming the record it came from
 * (`nscf_parallelisation` for a dos task's nscf step,
 * `bands_parallelisation` for a band task's bands step, `phonon` for a
 * phonon task's ph step). */
export interface RecordWarning extends AdvisorWarning {
    readonly record: string;
}
/** Where a setting's resolved value is published (#187): `record` names
 * the record of the decision the setting feeds, `path` the keys leading to
 * the setting's own value inside that record's `value` -- `[]` for the
 * value itself, `null` where the record holds no value of the setting (an
 * input-only knob such as `extra_bands`, which only shifts `nbnd`). */
export interface ResolvedIn {
    readonly record: string;
    readonly path: readonly string[] | null;
}
/** `tasks` are the tasks a setting applies to; a request for any other
 * task is refused. `steps`/`programs` are the steps (the names
 * `steps.<step>.<key>` takes) and programs a `per_step` setting applies to,
 * `null` for a `system` or `task` setting, which is set once per task.
 * `structure_specific` says whether a value is a judgement about the
 * structure it was set for (its elements, magnetism, geometry, size or
 * k-mesh) rather than a method, accuracy or job choice; opening another
 * structure clears it from the draft (#188). `resolved_in` is the only way
 * to its resolved value: a setting's key need not name its record or the
 * record's field (#187). */
export interface Setting {
    readonly key: string;
    readonly group: string;
    readonly type: string;
    readonly enum?: readonly string[];
    readonly unit: string | null;
    readonly default?: unknown;
    readonly enum_from?: string;
    readonly codes: readonly string[];
    readonly tasks: readonly string[];
    readonly steps: readonly string[] | null;
    readonly programs: readonly string[] | null;
    readonly scope: "system" | "task" | "per_step";
    readonly structure_specific: boolean;
    readonly resolved_in: ResolvedIn;
    readonly ml_target: string | null;
    readonly approaches: readonly Source[];
    readonly description: string;
}
export interface Fact {
    readonly key: string;
    readonly type: string;
    readonly values: readonly string[] | null;
    readonly ml_target: string | null;
    readonly approaches: readonly Source[];
    readonly overridable: boolean;
    readonly description: string;
}
export interface CodeInfo {
    readonly id: string;
    readonly name: string;
    readonly tasks: readonly string[];
}
export interface TaskInfo {
    readonly id: string;
    readonly name: string;
    readonly description: string;
    readonly codes: readonly string[];
    readonly step_count: number;
    readonly executables: readonly string[];
}
export interface PseudopotentialTable {
    readonly id: string;
    readonly provider: string;
    readonly version: string;
    readonly functional: string;
    readonly relativistic: string;
    readonly accuracy: string;
    readonly elements: readonly string[];
    readonly licence: string;
    readonly citation: string;
    readonly default: boolean;
}
export interface HpcProfile {
    readonly id: string;
    readonly name: string;
    readonly scheduler: string;
    readonly partitions: readonly string[];
}
export interface Capabilities {
    readonly core_version: string;
    readonly vocabulary_version: string;
    readonly codes: readonly CodeInfo[];
    readonly tasks: readonly TaskInfo[];
    readonly facts: readonly Fact[];
    readonly settings: readonly Setting[];
    readonly pseudopotential_tables: readonly PseudopotentialTable[];
    readonly hpc_profiles: readonly HpcProfile[];
    readonly models: readonly Readonly<Record<string, unknown>>[];
    readonly warnings: readonly AdvisorWarning[];
    readonly sources: readonly Source[];
}
export interface SpeciesOccupancy {
    readonly symbol: string;
    readonly label: string;
    readonly occupancy: number;
    readonly oxidation_state: number | null;
}
export interface StructureSite {
    readonly fractional_coordinates: readonly [number, number, number];
    readonly cartesian_coordinates_angstrom: readonly [number, number, number];
    /** The site's label (a CIF's `_atom_site_label`), which keys
     * `starting_magnetization`. */
    readonly label: string;
    readonly species: readonly SpeciesOccupancy[];
}
export interface LatticeDocument {
    readonly vectors_angstrom: readonly [
        readonly [number, number, number],
        readonly [number, number, number],
        readonly [number, number, number]
    ];
    readonly lengths_angstrom: readonly [number, number, number];
    readonly angles_degrees: readonly [number, number, number];
    readonly volume_angstrom3: number;
}
export interface StructureDocument {
    readonly schema_version: number;
    readonly formula: string;
    readonly reduced_formula: string;
    readonly site_count: number;
    readonly lattice: LatticeDocument;
    readonly periodicity: readonly [boolean, boolean, boolean];
    readonly sites: readonly StructureSite[];
}
export interface StructureSourceDocument {
    readonly origin: "inline" | "path" | "generated";
    readonly name: string;
    readonly format: string;
    readonly content: string | null;
    readonly sha256: string | null;
    readonly size_bytes: number | null;
}
export interface StructureInspection {
    readonly source: StructureSourceDocument;
    readonly structure: StructureDocument;
    readonly canonical_cif: string;
    readonly schema_version: number;
}
/** One step of a `RecordLayout`: its purpose (`scf`, `nscf`, `dos`,
 * `bands`, `relax`, `vc-relax`, `ph`, `q2r`, `phonon_dos`, `dispersion`)
 * and its records. A step without records, such as a band task's `bands_x`
 * or a phonon task's `d3hess`, has no entry. */
export interface StepLayout {
    readonly name: string;
    readonly records: readonly string[];
}
/** Mirrors `service.RecordLayout`: the tier and step of each record of a
 * response, by name (#187). `analysis` holds what the structure alone
 * decides, `system` what every step of the task shares, then each step's
 * own records in run order -- the task's one `job` with its first step, a
 * `dos` task's nscf decisions under their `nscf_` names, a `band` task's
 * bands-step path as `k_path` and its other decisions under their `bands_`
 * names, and a phonon task's `fft_grid` (and a relaxation's `relax`) with
 * its first step, then its `ph`, `q2r` and `phonon_dos` steps' records under
 * their own names and its `dispersion` step's path as `k_path`, the name
 * the band task's path has. Every record is in exactly one list. */
export interface RecordLayout {
    readonly analysis: readonly string[];
    readonly system: readonly string[];
    readonly steps: readonly StepLayout[];
}
/** One reason `/run` refuses a draft (`checks.Finding` on the wire, #151):
 * a stable `code`, the setting or fact keys it concerns (`fields`, as
 * `/capabilities` names them), the full `message`, the `summary` of the
 * decision it asks for (at most 200 characters, shown first, #223), and
 * `remedies`, each a complete override patch that resolves it, where `null`
 * clears that override. An `advice.blocked` finding names a decision that
 * could not be made, its root cause the message; it has no fields and no
 * remedy. */
export interface BlockingFinding {
    readonly code: string;
    readonly fields: readonly string[];
    readonly message: string;
    readonly summary: string;
    readonly remedies: readonly Readonly<Record<string, unknown>>[];
}
export interface ExplainResult {
    readonly records: Readonly<Record<string, ResolvedField>>;
    readonly warnings: readonly RecordWarning[];
    /** The findings `/run` would refuse to generate input files for (the
     * task's `check()` verdict, one per root cause in first-seen order);
     * empty when those checks pass. */
    readonly blocking: readonly BlockingFinding[];
    readonly layout: RecordLayout;
}
export interface RunResult {
    readonly files: readonly string[];
    readonly records: Readonly<Record<string, ResolvedField>>;
    readonly warnings: readonly RecordWarning[];
    readonly layout: RecordLayout;
}
export interface MagneticOrderingCandidate {
    readonly label: string;
    readonly formula: string;
    readonly natoms: number;
    readonly energy_per_atom_ev: number | null;
    readonly status: string | null;
    readonly is_recommended: boolean;
    readonly overrides: Readonly<Record<string, unknown>>;
}
export interface MagneticOrderingsResult {
    readonly ranked: boolean;
    readonly candidates: readonly MagneticOrderingCandidate[];
    readonly warnings: readonly AdvisorWarning[];
}
export interface ArchiveDownload {
    readonly blob: Blob;
    readonly filename: string;
}
export declare class CoreFailure extends Error {
    readonly kind: string;
    readonly details: Readonly<Record<string, unknown>>;
    readonly status: number | null;
    readonly rawResponse?: unknown | undefined;
    constructor(kind: string, message: string, details?: Readonly<Record<string, unknown>>, status?: number | null, rawResponse?: unknown | undefined);
}
export interface CoreClient {
    capabilities(): Promise<Capabilities>;
    inspectStructure(input: StructureInput): Promise<StructureInspection>;
    /** Advice-only preview: never generates files, and still succeeds when
     * `run` would refuse with `advice_incomplete` (the tri-state
     * "diagnosis is always available" promise) -- `blocking` then lists
     * the findings `run` would refuse with. */
    explain(request: ComputeRequest): Promise<ExplainResult>;
    /** Lists candidate magnetic orderings (FM plus any AFM candidates),
     * optionally mMACE-ranked by relaxed energy per atom. Aborting `signal`
     * abandons the request: the promise then rejects with the abort reason
     * (fetch's `AbortError`), not a `CoreFailure`. The server still finishes
     * the enumeration or ranking it started. */
    magneticOrderings(request: MagneticOrderingsRequest, signal?: AbortSignal): Promise<MagneticOrderingsResult>;
    /** Executes the pipeline and returns the JSON summary (file list +
     * records + warnings), not the files themselves. */
    run(request: ComputeRequest): Promise<RunResult>;
    /** Executes the pipeline and returns the generated input bundle as a
     * zip. Runs the pipeline a second time server-side -- there is no
     * single call that returns both the summary and the archive (v1's
     * multipart response is gone); callers that need both should call
     * `explain` for the summary/preview and `runArchive` only once the
     * user actually wants the files. */
    runArchive(request: ComputeRequest): Promise<ArchiveDownload>;
}
export declare class HttpCoreClient implements CoreClient {
    private readonly fetcher;
    private readonly baseUrl;
    constructor(baseUrl?: string, fetcher?: typeof fetch);
    capabilities(): Promise<Capabilities>;
    inspectStructure(input: StructureInput): Promise<StructureInspection>;
    explain(request: ComputeRequest): Promise<ExplainResult>;
    magneticOrderings(request: MagneticOrderingsRequest, signal?: AbortSignal): Promise<MagneticOrderingsResult>;
    run(request: ComputeRequest): Promise<RunResult>;
    runArchive(request: ComputeRequest): Promise<ArchiveDownload>;
    private request;
}
/** The findings a refused `/run` (`advice_incomplete`) carries in its error
 * envelope's `details.findings` (#151): the same findings `/explain`
 * returns as its verdict. An entry that is not a finding is left out, and
 * any other failure has none. */
export declare function findingsOf(failure: CoreFailure): readonly BlockingFinding[];
