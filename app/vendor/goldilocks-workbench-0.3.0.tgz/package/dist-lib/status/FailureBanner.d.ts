import { CoreFailure } from '../api/coreClient';
/** A failure with Retry and, but for a capabilities failure, Dismiss. A
 * refused `/run` lists its findings, each with a button per remedy, in
 * place of the message that joins them (#151). */
export declare function FailureBanner({ failure, dismissAvailable, onRetry, onDismiss, }: {
    readonly failure: CoreFailure;
    readonly dismissAvailable: boolean;
    readonly onRetry: () => void;
    readonly onDismiss: () => void;
}): import('react').JSX.Element;
