import { BlockingFinding } from '../api/coreClient';
/** One button per remedy of `finding` (#151). A click applies that override
 * patch to the draft, a `null` value clearing its key back to automatic, and
 * the draft's recommendation is recomputed. */
export declare function RemedyButtons({ finding, }: {
    readonly finding: BlockingFinding;
}): import('react').JSX.Element | null;
/** `findings` as a list, each its summary, a toggle that shows its full
 * message in place, and its remedy buttons: the failure banner's and the
 * Bundle card's account of why no input files exist, the one place a
 * finding's remedies are offered (#223). */
export declare function FindingList({ findings, }: {
    readonly findings: readonly BlockingFinding[];
}): import('react').JSX.Element;
/** One line under the control of setting or fact `field` while a finding of
 * the current draft concerns it, pointing to the Bundle card, which holds
 * the findings and their remedies (#223); nothing when none does. */
export declare function FindingNotes({ field }: {
    readonly field: string;
}): import('react').JSX.Element | null;
