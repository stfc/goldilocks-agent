import { WorkspaceOperation } from '../workspace/workspace';
/** The request in flight, or else whether something waits for the user
 * (`pipelineStatus.needsAttention`). */
export declare function OperationStatus({ operation, needsAttention, }: {
    readonly operation: WorkspaceOperation | null;
    readonly needsAttention: boolean;
}): import('react').JSX.Element;
