import { ArchiveDownload } from '../api/coreClient';
/** The files of `archive`, or `placeholder` (why there are none yet) while
 * it is null. */
export declare function GeneratedInputReview({ archive, placeholder, }: {
    readonly archive: ArchiveDownload | null;
    readonly placeholder: string;
}): import('react').JSX.Element;
