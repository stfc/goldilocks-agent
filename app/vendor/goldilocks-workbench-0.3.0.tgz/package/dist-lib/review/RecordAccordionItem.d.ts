import { ResolvedField } from '../api/coreClient';
/** One resolved record as a collapsed-by-default accordion item --
 * status dot + human name in the always-visible control, full detail
 * (value, source, per-field sources) behind the expand. Used by
 * AnalysisSection for its read-only records and by the Advisors card for
 * the advisor records no setting resolves into (`AdvisorRecords`); the
 * Advisors card's settings groups (CalculationForm's SettingsGroupItems)
 * are bespoke items instead, since their rows carry real editable controls
 * rather than a read-only detail panel -- but both opt into the shared
 * `workbench-accordion-label` class (see App.css) so the rows read as one
 * visual language, not two. */
export declare function RecordAccordionItem({ name, field, }: {
    readonly name: string;
    readonly field: ResolvedField;
}): import('react').JSX.Element;
