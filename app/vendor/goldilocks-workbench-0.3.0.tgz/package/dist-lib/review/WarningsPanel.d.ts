import { AdvisorWarning, RecordWarning } from '../api/coreClient';
export declare function WarningsPanel({ warnings, }: {
    readonly warnings: readonly (AdvisorWarning | RecordWarning)[];
}): import('react').JSX.Element | null;
