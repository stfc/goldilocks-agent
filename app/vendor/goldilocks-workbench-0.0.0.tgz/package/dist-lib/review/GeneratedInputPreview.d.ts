export declare function GeneratedInputPreview({ path, content, }: {
    readonly path: string;
    readonly content: string;
}): import("react").JSX.Element;
