import { ArchiveDownload } from '../api/coreClient';
export declare function GeneratedInputReview({ archive, }: {
    readonly archive: ArchiveDownload | null;
}): import("react").JSX.Element;
