import { ResolvedField } from '../api/coreClient';
/** One resolved record as a collapsed-by-default accordion item --
 * status dot + human name in the always-visible control, full detail
 * (value, source, per-field sources) behind the expand. Shared by
 * every place a record is shown read-only (the analysis and advisors
 * sections both use this, not a bespoke presenter each). */
export declare function RecordAccordionItem({ name, field, }: {
    readonly name: string;
    readonly field: ResolvedField;
}): import("react").JSX.Element;
