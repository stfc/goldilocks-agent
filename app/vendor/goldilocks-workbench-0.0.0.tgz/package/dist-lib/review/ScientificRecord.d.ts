import { ResolvedField } from '../api/coreClient';
/** Renders one `ResolvedField` generically -- v2's `records()` docstring
 * is explicit that there is no codified schema for a record's `value`
 * shape beyond the tri-state envelope itself ("No such key set is
 * codified anywhere else in the codebase"), so a per-record hand-coded
 * presenter (v1's approach) would just be the next contract drift
 * waiting to happen. This walks whatever value/object/array shape an
 * advisor actually returned. */
export declare function ScientificRecord({ field }: {
    readonly field: ResolvedField;
}): import("react").JSX.Element;
