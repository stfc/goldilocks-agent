export declare function GeneratedInputsCard(): import("react").JSX.Element;
