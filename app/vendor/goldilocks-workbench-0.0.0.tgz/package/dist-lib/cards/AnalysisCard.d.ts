export declare function AnalysisCard(): import("react").JSX.Element;
