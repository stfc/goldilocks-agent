export declare function StructureCard(): import("react").JSX.Element;
