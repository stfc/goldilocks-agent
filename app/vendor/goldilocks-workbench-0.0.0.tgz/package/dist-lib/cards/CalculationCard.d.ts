export declare function CalculationCard(): import("react").JSX.Element;
