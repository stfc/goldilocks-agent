import { components } from './schema';
export type StructureInput = components["schemas"]["InlineStructureDocument"];
export type ComputeRequest = components["schemas"]["ComputeRequestDocument"];
export type CalcTask = ComputeRequest["task"];
export type Source = "human" | "ml" | "llm" | "heuristic";
export type FieldStatus = "resolved" | "unavailable" | "blocked";
/** Mirrors `resolution.ResolvedField`'s wire projection (`from_state`). */
export interface ResolvedField<T = unknown> {
    readonly status: FieldStatus;
    readonly value?: T | null;
    readonly source?: Source | null;
    readonly field_sources?: Readonly<Record<string, Source>> | null;
    readonly reason?: string | null;
    readonly blocked_by?: string | null;
}
/** Mirrors `resolution.Warning`. */
export interface AdvisorWarning {
    readonly code: string;
    readonly level: "info" | "warning" | "error";
    readonly category: string;
    readonly message: string;
}
export interface Setting {
    readonly key: string;
    readonly group: string;
    readonly type: string;
    readonly enum?: readonly string[];
    readonly unit: string | null;
    readonly default?: unknown;
    readonly enum_from?: string;
    readonly codes: readonly string[] | null;
    readonly tasks: readonly string[] | null;
    readonly programs: readonly string[] | null;
    readonly scope: "system" | "per_step";
    readonly ml_target: string | null;
    readonly approaches: readonly Source[];
    readonly description: string;
}
export interface Fact {
    readonly key: string;
    readonly type: string;
    readonly values: readonly string[] | null;
    readonly ml_target: string | null;
    readonly approaches: readonly Source[];
    readonly overridable: boolean;
    readonly description: string;
}
export interface CodeInfo {
    readonly id: string;
    readonly name: string;
    readonly tasks: readonly string[];
}
export interface TaskInfo {
    readonly id: string;
    readonly name: string;
    readonly description: string;
    readonly codes: readonly string[];
    readonly step_count: number;
    readonly executables: readonly string[];
}
export interface PseudopotentialTable {
    readonly id: string;
    readonly provider: string;
    readonly version: string;
    readonly functional: string;
    readonly relativistic: string;
    readonly accuracy: string;
    readonly elements: readonly string[];
    readonly licence: string;
    readonly citation: string;
    readonly default: boolean;
}
export interface HpcProfile {
    readonly id: string;
    readonly name: string;
    readonly scheduler: string;
    readonly partitions: readonly string[];
}
export interface Capabilities {
    readonly core_version: string;
    readonly vocabulary_version: string;
    readonly codes: readonly CodeInfo[];
    readonly tasks: readonly TaskInfo[];
    readonly facts: readonly Fact[];
    readonly settings: readonly Setting[];
    readonly pseudopotential_tables: readonly PseudopotentialTable[];
    readonly hpc_profiles: readonly HpcProfile[];
    readonly models: readonly Readonly<Record<string, unknown>>[];
    readonly warnings: readonly AdvisorWarning[];
    readonly sources: readonly Source[];
}
export interface SpeciesOccupancy {
    readonly symbol: string;
    readonly label: string;
    readonly occupancy: number;
    readonly oxidation_state: number | null;
}
export interface StructureSite {
    readonly fractional_coordinates: readonly [number, number, number];
    readonly cartesian_coordinates_angstrom: readonly [number, number, number];
    readonly species: readonly SpeciesOccupancy[];
}
export interface LatticeDocument {
    readonly vectors_angstrom: readonly [
        readonly [number, number, number],
        readonly [number, number, number],
        readonly [number, number, number]
    ];
    readonly lengths_angstrom: readonly [number, number, number];
    readonly angles_degrees: readonly [number, number, number];
    readonly volume_angstrom3: number;
}
export interface StructureDocument {
    readonly schema_version: number;
    readonly formula: string;
    readonly reduced_formula: string;
    readonly site_count: number;
    readonly lattice: LatticeDocument;
    readonly periodicity: readonly [boolean, boolean, boolean];
    readonly sites: readonly StructureSite[];
}
export interface StructureSourceDocument {
    readonly origin: "inline" | "path" | "generated";
    readonly name: string;
    readonly format: string;
    readonly content: string | null;
    readonly sha256: string | null;
    readonly size_bytes: number | null;
}
export interface StructureInspection {
    readonly source: StructureSourceDocument;
    readonly structure: StructureDocument;
    readonly canonical_cif: string;
    readonly schema_version: number;
}
export interface ExplainResult {
    readonly records: Readonly<Record<string, ResolvedField>>;
    readonly warnings: readonly AdvisorWarning[];
}
export interface RunResult {
    readonly files: readonly string[];
    readonly records: Readonly<Record<string, ResolvedField>>;
    readonly warnings: readonly AdvisorWarning[];
}
export interface ArchiveDownload {
    readonly blob: Blob;
    readonly filename: string;
}
export declare class CoreFailure extends Error {
    readonly kind: string;
    readonly retryable: boolean;
    readonly details: Readonly<Record<string, unknown>>;
    readonly status: number | null;
    readonly rawResponse?: unknown | undefined;
    constructor(kind: string, message: string, retryable: boolean, details?: Readonly<Record<string, unknown>>, status?: number | null, rawResponse?: unknown | undefined);
}
export interface CoreClient {
    capabilities(): Promise<Capabilities>;
    inspectStructure(input: StructureInput): Promise<StructureInspection>;
    /** Advice-only preview: never generates files, can succeed even when
     * `run` would refuse with `advice_incomplete` (the tri-state
     * "diagnosis is always available" promise). */
    explain(request: ComputeRequest): Promise<ExplainResult>;
    /** Executes the pipeline and returns the JSON summary (file list +
     * records + warnings), not the files themselves. */
    run(request: ComputeRequest): Promise<RunResult>;
    /** Executes the pipeline and returns the generated input bundle as a
     * zip. Runs the pipeline a second time server-side -- there is no
     * single call that returns both the summary and the archive (v1's
     * multipart response is gone); callers that need both should call
     * `explain` for the summary/preview and `runArchive` only once the
     * user actually wants the files. */
    runArchive(request: ComputeRequest): Promise<ArchiveDownload>;
}
export declare class HttpCoreClient implements CoreClient {
    private readonly fetcher;
    private readonly baseUrl;
    constructor(baseUrl?: string, fetcher?: typeof fetch);
    capabilities(): Promise<Capabilities>;
    inspectStructure(input: StructureInput): Promise<StructureInspection>;
    explain(request: ComputeRequest): Promise<ExplainResult>;
    run(request: ComputeRequest): Promise<RunResult>;
    runArchive(request: ComputeRequest): Promise<ArchiveDownload>;
    private request;
}
