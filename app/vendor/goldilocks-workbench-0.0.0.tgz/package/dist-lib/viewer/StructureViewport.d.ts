import { StructureInspection } from '../api/coreClient';
import { StructureViewerFactory } from './structureViewer';
export declare function StructureViewport({ inspection, createViewer, }: {
    readonly inspection: StructureInspection;
    readonly createViewer?: StructureViewerFactory;
}): import("react").JSX.Element;
