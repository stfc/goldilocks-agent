import { Ref } from 'react';
import { StructureInspection } from '../api/coreClient';
export declare function StructureFallback({ structure, onRetry, containerRef, hidden, }: {
    readonly structure: StructureInspection["structure"];
    readonly onRetry: () => void;
    readonly containerRef?: Ref<HTMLDivElement>;
    readonly hidden?: boolean;
}): import("react").JSX.Element;
