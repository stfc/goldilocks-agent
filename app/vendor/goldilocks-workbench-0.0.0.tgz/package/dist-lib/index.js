import { n as e } from "./rolldown-runtime-DtPi1Y-2.js";
import * as t from "react";
import n, { Activity as r, Children as i, Fragment as a, cloneElement as o, createContext as s, createElement as c, forwardRef as l, use as u, useCallback as d, useContext as f, useEffect as p, useEffectEvent as m, useId as h, useLayoutEffect as g, useMemo as _, useRef as v, useState as y, useSyncExternalStore as b } from "react";
import x, { createPortal as S, flushSync as C } from "react-dom";
import { Fragment as w, jsx as T, jsxs as E } from "react/jsx-runtime";
//#region node_modules/@mantine/core/esm/core/utils/keys/keys.mjs
function D(e) {
	return Object.keys(e);
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/deep-merge/deep-merge.mjs
function O(e) {
	return e && typeof e == "object" && !Array.isArray(e);
}
function k(e, t) {
	let n = { ...e }, r = t;
	return O(e) && O(t) && Object.keys(t).forEach((t) => {
		O(r[t]) && t in e ? n[t] = k(n[t], r[t]) : n[t] = r[t];
	}), n;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/camel-to-kebab-case/camel-to-kebab-case.mjs
function ee(e) {
	return e.replace(/[A-Z]/g, (e) => `-${e.toLowerCase()}`);
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/units-converters/px.mjs
function A(e) {
	return typeof e != "string" || !e.includes("var(--mantine-scale)") ? e : e.match(/^calc\((.*?)\)$/)?.[1].split("*")[0].trim();
}
function j(e) {
	let t = A(e);
	return typeof t == "number" ? t : typeof t == "string" ? t.includes("calc") || t.includes("var") ? t : t.includes("px") ? Number(t.replace("px", "")) : t.includes("rem") ? Number(t.replace("rem", "")) * 16 : t.includes("em") ? Number(t.replace("em", "")) * 16 : Number(t) : NaN;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/units-converters/rem.mjs
function M(e) {
	return e === "0rem" ? "0rem" : `calc(${e} * var(--mantine-scale))`;
}
function N(e, { shouldScale: t = !1 } = {}) {
	function n(r) {
		if (r === 0 || r === "0") return `0${e}`;
		if (typeof r == "number") {
			let n = `${r / 16}${e}`;
			return t ? M(n) : n;
		}
		if (typeof r == "string") {
			if (r === "" || r.startsWith("calc(") || r.startsWith("clamp(") || r.includes("rgba(")) return r;
			if (r.includes(",")) return r.split(",").map((e) => n(e)).join(",");
			if (r.includes(" ")) return r.split(" ").map((e) => n(e)).join(" ");
			let i = r.replace("px", "");
			if (!Number.isNaN(Number(i))) {
				let n = `${Number(i) / 16}${e}`;
				return t ? M(n) : n;
			}
		}
		return r;
	}
	return n;
}
var P = N("rem", { shouldScale: !0 }), te = N("em");
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/filter-props/filter-props.mjs
function ne(e) {
	return Object.keys(e).reduce((t, n) => (e[n] !== void 0 && (t[n] = e[n]), t), {});
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/is-number-like/is-number-like.mjs
function F(e) {
	if (typeof e == "number") return !0;
	if (typeof e == "string") {
		if (e.startsWith("calc(") || e.startsWith("var(") || e.includes(" ") && e.trim() !== "") return !0;
		let t = /^[+-]?[0-9]+(\.[0-9]+)?(px|em|rem|ex|ch|lh|rlh|vw|vh|vmin|vmax|vb|vi|svw|svh|lvw|lvh|dvw|dvh|cm|mm|in|pt|pc|q|cqw|cqh|cqi|cqb|cqmin|cqmax|%)?$/;
		return e.trim().split(/\s+/).every((e) => t.test(e));
	}
	return !1;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/is-element/is-element.mjs
function I(e) {
	return Array.isArray(e) || e === null ? !1 : typeof e == "object" && e.type !== a;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/create-safe-context/create-safe-context.mjs
function re(e) {
	let t = s(null);
	return [t, () => {
		let n = u(t);
		if (n === null) throw Error(e);
		return n;
	}];
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/get-safe-id/get-safe-id.mjs
function L(e, t) {
	return (n) => {
		if (typeof n != "string" || n.trim().length === 0) throw Error(t);
		return `${e}-${n}`;
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/find-element-ancestor/find-element-ancestor.mjs
function R(e, t) {
	let n = e;
	for (; (n = n.parentElement) && !n.matches(t););
	return n;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/create-scoped-keydown-handler/create-scoped-keydown-handler.mjs
function z(e, t, n) {
	for (let n = e - 1; n >= 0; --n) if (!t[n].disabled) return n;
	if (n) {
		for (let e = t.length - 1; e > -1; --e) if (!t[e].disabled) return e;
	}
	return e;
}
function ie(e, t, n) {
	for (let n = e + 1; n < t.length; n += 1) if (!t[n].disabled) return n;
	if (n) {
		for (let e = 0; e < t.length; e += 1) if (!t[e].disabled) return e;
	}
	return e;
}
function ae(e, t, n) {
	return R(e, n) === R(t, n);
}
function oe({ parentSelector: e, siblingSelector: t, onKeyDown: n, loop: r = !0, activateOnFocus: i = !1, dir: a = "rtl", orientation: o }) {
	return (s) => {
		n?.(s);
		let c = Array.from(R(s.currentTarget, e)?.querySelectorAll(t) || []).filter((t) => ae(s.currentTarget, t, e)), l = c.findIndex((e) => s.currentTarget === e), u = ie(l, c, r), d = z(l, c, r), f = a === "rtl" ? d : u, p = a === "rtl" ? u : d;
		switch (s.key) {
			case "ArrowRight":
				o === "horizontal" && (s.stopPropagation(), s.preventDefault(), c[f].focus(), i && c[f].click());
				break;
			case "ArrowLeft":
				o === "horizontal" && (s.stopPropagation(), s.preventDefault(), c[p].focus(), i && c[p].click());
				break;
			case "ArrowUp":
				o === "vertical" && (s.stopPropagation(), s.preventDefault(), c[d].focus(), i && c[d].click());
				break;
			case "ArrowDown":
				o === "vertical" && (s.stopPropagation(), s.preventDefault(), c[u].focus(), i && c[u].click());
				break;
			case "Home":
				s.stopPropagation(), s.preventDefault(), c[ie(-1, c, !1)]?.focus();
				break;
			case "End": s.stopPropagation(), s.preventDefault(), c[z(c.length, c, !1)]?.focus();
		}
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/get-default-z-index/get-default-z-index.mjs
var se = {
	app: 100,
	modal: 200,
	popover: 300,
	overlay: 400,
	max: 9999
};
function ce(e) {
	return se[e];
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/noop/noop.mjs
var le = () => {};
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/get-size/get-size.mjs
function B(e, t = "size", n = !0) {
	if (e !== void 0) return F(e) ? n ? P(e) : e : `var(--${t}-${e})`;
}
function V(e) {
	return B(e, "mantine-spacing");
}
function H(e) {
	return e === void 0 ? "var(--mantine-radius-default)" : B(e, "mantine-radius");
}
function U(e) {
	return B(e, "mantine-font-size");
}
function ue(e) {
	return B(e, "mantine-line-height", !1);
}
function W(e) {
	if (e) return B(e, "mantine-shadow", !1);
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/get-breakpoint-value/get-breakpoint-value.mjs
function de(e, t) {
	return e in t ? j(t[e]) : j(e);
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/get-sorted-breakpoints/get-sorted-breakpoints.mjs
function fe(e, t) {
	let n = e.map((e) => ({
		value: e,
		px: de(e, t)
	}));
	return n.sort((e, t) => e.px - t.px), n;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/get-base-value/get-base-value.mjs
function pe(e) {
	return typeof e == "object" && e ? "base" in e ? e.base : void 0 : e;
}
//#endregion
//#region node_modules/@mantine/hooks/esm/utils/clamp/clamp.mjs
function me(e, t, n) {
	return t === void 0 && n === void 0 ? e : t !== void 0 && n === void 0 ? Math.max(e, t) : Math.min(t === void 0 && n !== void 0 ? e : Math.max(e, t), n);
}
//#endregion
//#region node_modules/@mantine/hooks/esm/utils/random-id/random-id.mjs
function he(e = "mantine-") {
	return `${e}${Math.random().toString(36).slice(2, 11)}`;
}
//#endregion
//#region node_modules/@mantine/hooks/esm/utils/use-callback-ref/use-callback-ref.mjs
function ge(e) {
	let t = v(e);
	return p(() => {
		t.current = e;
	}), _(() => ((...e) => t.current?.(...e)), []);
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-debounced-callback/use-debounced-callback.mjs
function _e(e, t) {
	let { delay: n, flushOnUnmount: r, leading: i, maxWait: a } = typeof t == "number" ? {
		delay: t,
		flushOnUnmount: !1,
		leading: !1,
		maxWait: void 0
	} : t, o = ge(e), s = v(0), c = v(0), l = v(null), u = _(() => {
		let e = Object.assign((...t) => {
			window.clearTimeout(s.current), l.current = t;
			let r = e._isFirstCall;
			e._isFirstCall = !1;
			function u() {
				window.clearTimeout(s.current), window.clearTimeout(c.current), s.current = 0, c.current = 0, e._isFirstCall = !0, e._hasPendingCallback = !1;
			}
			function d() {
				a !== void 0 && c.current === 0 && (c.current = window.setTimeout(() => {
					if (s.current !== 0) {
						let e = l.current;
						u(), o(...e);
					}
				}, a));
			}
			if (i && r) {
				o(...t), e.flush = () => {
					s.current !== 0 && (u(), o(...t));
				}, e.cancel = () => {
					u();
				}, s.current = window.setTimeout(() => {
					u();
				}, n), d();
				return;
			}
			if (i && !r) {
				e._hasPendingCallback = !0, e.flush = () => {
					s.current !== 0 && (u(), o(...t));
				}, e.cancel = () => {
					u();
				}, s.current = window.setTimeout(() => {
					u();
				}, n), d();
				return;
			}
			e._hasPendingCallback = !0;
			let f = () => {
				s.current !== 0 && (u(), o(...t));
			};
			e.flush = f, e.cancel = () => {
				u();
			}, s.current = window.setTimeout(f, n), d();
		}, {
			flush: () => {},
			cancel: () => {},
			isPending: () => e._hasPendingCallback,
			_isFirstCall: !0,
			_hasPendingCallback: !1
		});
		return e;
	}, [
		o,
		n,
		i,
		a
	]);
	return p(() => () => {
		r ? u.flush() : u.cancel();
	}, [u, r]), u;
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-media-query/use-media-query.mjs
function ve(e, t) {
	return typeof t == "boolean" ? t : typeof window < "u" && "matchMedia" in window && window.matchMedia(e).matches;
}
function ye(e, t, { getInitialValueInEffect: n } = { getInitialValueInEffect: !0 }) {
	let [r, i] = y(n ? t : ve(e));
	return p(() => {
		try {
			if ("matchMedia" in window) {
				let t = window.matchMedia(e);
				i(t.matches);
				let n = (e) => i(e.matches);
				return t.addEventListener("change", n), () => {
					t.removeEventListener("change", n);
				};
			}
		} catch {
			return;
		}
	}, [e]), r || !1;
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-color-scheme/use-color-scheme.mjs
function be(e, t) {
	return ye("(prefers-color-scheme: dark)", e === "dark", t) ? "dark" : "light";
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-isomorphic-effect/use-isomorphic-effect.mjs
var xe = typeof document < "u" ? g : p;
//#endregion
//#region node_modules/@mantine/hooks/esm/use-did-update/use-did-update.mjs
function G(e, t) {
	let n = v(!1);
	p(() => () => {
		n.current = !1;
	}, []), p(() => {
		if (n.current) return e();
		n.current = !0;
	}, t);
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-focus-return/use-focus-return.mjs
function Se({ opened: e, shouldReturnFocus: t = !0 }) {
	let n = v(null), r = () => {
		n.current && "focus" in n.current && typeof n.current.focus == "function" && n.current?.focus({ preventScroll: !0 });
	};
	return G(() => {
		let i = -1, a = (e) => {
			e.key === "Tab" && window.clearTimeout(i);
		};
		if (document.addEventListener("keydown", a), e) n.current = document.activeElement;
		else if (t) {
			let e = document.activeElement;
			i = window.setTimeout(() => {
				let t = document.activeElement;
				(t === null || t === document.body || t === e) && r();
			}, 10);
		}
		return () => {
			window.clearTimeout(i), document.removeEventListener("keydown", a);
		};
	}, [e, t]), r;
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-focus-trap/tabbable.mjs
var Ce = /input|select|textarea|button|object/, we = "a, input, select, textarea, button, object, [tabindex]";
function Te(e) {
	return e.style.display === "none";
}
function Ee(e) {
	if (e.getAttribute("aria-hidden") || e.getAttribute("hidden") || e.getAttribute("type") === "hidden") return !1;
	let t = e;
	for (; t && t !== document.body && t.nodeType !== 11;) {
		if (Te(t)) return !1;
		t = t.parentNode;
	}
	return !0;
}
function De(e) {
	let t = e.getAttribute("tabindex");
	return t === null && (t = void 0), parseInt(t, 10);
}
function Oe(e) {
	let t = e.nodeName.toLowerCase(), n = !Number.isNaN(De(e));
	return (Ce.test(t) && !e.disabled || e instanceof HTMLAnchorElement && e.href || n) && Ee(e);
}
function ke(e) {
	let t = De(e);
	return (Number.isNaN(t) || t >= 0) && Oe(e);
}
function Ae(e) {
	return Array.from(e.querySelectorAll(we)).filter(ke);
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-focus-trap/scope-tab.mjs
function je(e, t) {
	let n = Ae(e);
	if (!n.length) {
		t.preventDefault();
		return;
	}
	let r = n[t.shiftKey ? 0 : n.length - 1], i = e.getRootNode(), a = r === i.activeElement || e === i.activeElement, o = i.activeElement;
	if (o.tagName === "INPUT" && o.getAttribute("type") === "radio" && (a = n.filter((e) => e.getAttribute("type") === "radio" && e.getAttribute("name") === o.getAttribute("name")).includes(r)), !a) return;
	t.preventDefault();
	let s = n[t.shiftKey ? n.length - 1 : 0];
	s && s.focus();
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-focus-trap/use-focus-trap.mjs
function Me(e = !0) {
	let t = v(null), n = (e) => {
		let t = e.querySelector("[data-autofocus]");
		if (!t) {
			let n = Array.from(e.querySelectorAll(we));
			t = n.find(ke) || n.find(Oe) || null, !t && Oe(e) && (t = e);
		}
		t ? t.focus({ preventScroll: !0 }) : console.warn("[@mantine/hooks/use-focus-trap] Failed to find focusable element within provided node", e);
	}, r = d((r) => {
		if (e) {
			if (r === null) {
				t.current = null;
				return;
			}
			t.current !== r && (setTimeout(() => {
				r.getRootNode() ? n(r) : console.warn("[@mantine/hooks/use-focus-trap] Ref node is not part of the dom", r);
			}), t.current = r);
		}
	}, [e]);
	return p(() => {
		if (!e) return;
		t.current && setTimeout(() => {
			t.current && n(t.current);
		});
		let r = (e) => {
			e.key === "Tab" && t.current && je(t.current, e);
		};
		return document.addEventListener("keydown", r), () => document.removeEventListener("keydown", r);
	}, [e]), r;
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-id/use-id.mjs
function Ne(e) {
	let t = h(), [n, r] = y(`mantine-${t.replace(/:/g, "")}`), i = v(!1);
	return xe(() => {
		i.current || (i.current = !0, r(he()));
	}, []), typeof e == "string" ? e : n;
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-window-event/use-window-event.mjs
function Pe(e, t, n) {
	let r = m(t);
	p(() => (window.addEventListener(e, r, n), () => window.removeEventListener(e, r, n)), [e]);
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-merged-ref/use-merged-ref.mjs
function Fe(e, t) {
	if (typeof e == "function") return e(t);
	typeof e == "object" && e && "current" in e && (e.current = t);
}
function Ie(...e) {
	let t = /* @__PURE__ */ new Map();
	return (n) => {
		if (e.forEach((e) => {
			let r = Fe(e, n);
			r && t.set(e, r);
		}), t.size > 0) return () => {
			e.forEach((e) => {
				let n = t.get(e);
				n && typeof n == "function" ? n() : Fe(e, null);
			}), t.clear();
		};
	};
}
function Le(...e) {
	return d(Ie(...e), e);
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-uncontrolled/use-uncontrolled.mjs
function Re({ value: e, defaultValue: t, finalValue: n, onChange: r = () => {} }) {
	let [i, a] = y(t === void 0 ? n : t);
	return e === void 0 ? [
		i,
		(e, ...t) => {
			a(e), r?.(e, ...t);
		},
		!1
	] : [
		e,
		r,
		!0
	];
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-reduced-motion/use-reduced-motion.mjs
function ze(e, t) {
	return ye("(prefers-reduced-motion: reduce)", e, t);
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-collapse/use-collapse.mjs
function Be(e) {
	if (!e || typeof e == "string") return 0;
	let t = e / 36;
	return Math.round((4 + 15 * t ** .25 + t / 5) * 10);
}
function Ve(e) {
	return e.current ? e.current.scrollHeight : "auto";
}
function He({ transitionDuration: e, transitionTimingFunction: t = "ease", onTransitionEnd: n, onTransitionStart: r, expanded: i, keepMounted: a }) {
	let o = {
		height: 0,
		overflow: "hidden",
		...a ? {} : { display: "none" }
	}, s = m(() => r?.()), c = v(null), [l, u] = y(i ? {} : o), [d, f] = y(i ? "entered" : "exited"), p = (e) => {
		C(() => u(e));
	}, h = (e) => {
		p((t) => ({
			...t,
			...e
		}));
	}, g = (n) => {
		let r = e ?? Be(n);
		return { transition: `height ${r}ms ${t}, opacity ${r}ms ${t}` };
	};
	G(() => {
		e !== 0 && s(), i ? window.requestAnimationFrame(() => {
			C(() => f("entering")), h({
				willChange: "height",
				display: "block",
				overflow: "hidden"
			}), window.requestAnimationFrame(() => {
				let e = Ve(c);
				h({
					...g(e),
					height: e
				});
			});
		}) : window.requestAnimationFrame(() => {
			C(() => f("exiting"));
			let e = Ve(c);
			h({
				...g(e),
				willChange: "height",
				height: e
			}), window.requestAnimationFrame(() => h({
				height: 0,
				overflow: "hidden"
			}));
		});
	}, [i]);
	let _ = (e) => {
		if (e.target === c.current && e.propertyName === "height") {
			if (i) {
				let e = Ve(c);
				e === l.height ? p({}) : h({ height: e }), f("entered"), n?.();
			} else l.height === 0 && (p(o), f("exited"), n?.());
		}
	};
	return {
		state: d,
		getCollapseProps: (e) => ({
			"aria-hidden": !i,
			inert: !i,
			ref: Ie(c, e?.ref),
			onTransitionEnd: _,
			style: {
				boxSizing: "border-box",
				...e?.style,
				...l
			}
		})
	};
}
//#endregion
//#region node_modules/@mantine/hooks/esm/use-collapse/use-horizontal-collapse.mjs
function Ue(e) {
	if (!e || typeof e == "string") return 0;
	let t = e / 36;
	return Math.round((4 + 15 * t ** .25 + t / 5) * 10);
}
function We(e) {
	return e.current ? e.current.scrollWidth : "auto";
}
function Ge({ transitionDuration: e, transitionTimingFunction: t = "ease", onTransitionEnd: n, onTransitionStart: r, expanded: i, keepMounted: a }) {
	let o = {
		width: 0,
		overflow: "hidden",
		...a ? {} : { display: "none" }
	}, s = m(() => r?.()), c = v(null), [l, u] = y(i ? {} : o), [d, f] = y(i ? "entered" : "exited"), p = (e) => {
		C(() => u(e));
	}, h = (e) => {
		p((t) => ({
			...t,
			...e
		}));
	}, g = (n) => {
		let r = e ?? Ue(n);
		return { transition: `width ${r}ms ${t}, opacity ${r}ms ${t}` };
	};
	G(() => {
		e !== 0 && s(), i ? window.requestAnimationFrame(() => {
			C(() => f("entering")), h({
				willChange: "width",
				display: "block",
				overflow: "hidden"
			}), window.requestAnimationFrame(() => {
				let e = We(c);
				h({
					...g(e),
					width: e
				});
			});
		}) : window.requestAnimationFrame(() => {
			C(() => f("exiting"));
			let e = We(c);
			h({
				...g(e),
				willChange: "width",
				width: e
			}), window.requestAnimationFrame(() => h({
				width: 0,
				overflow: "hidden"
			}));
		});
	}, [i]);
	let _ = (e) => {
		if (e.target === c.current && e.propertyName === "width") {
			if (i) {
				let e = We(c);
				e === l.width ? p({}) : h({ width: e }), f("entered"), n?.();
			} else l.width === 0 && (p(o), f("exited"), n?.());
		}
	};
	return {
		state: d,
		getCollapseProps: (e) => ({
			"aria-hidden": !i,
			inert: !i,
			ref: Ie(c, e?.ref),
			onTransitionEnd: _,
			style: {
				boxSizing: "border-box",
				...e?.style,
				...l
			}
		})
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/get-env/get-env.mjs
function Ke() {
	return typeof process < "u" && process.env, "development";
}
//#endregion
//#region node_modules/@mantine/core/esm/core/utils/get-single-element-child/get-single-element-child.mjs
function qe(e) {
	let t = i.toArray(e);
	return t.length !== 1 || !I(t[0]) ? null : t[0];
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/create-vars-resolver/create-vars-resolver.mjs
function K(e) {
	return e;
}
//#endregion
//#region node_modules/clsx/dist/clsx.mjs
function Je(e) {
	var t, n, r = "";
	if (typeof e == "string" || typeof e == "number") r += e;
	else if (typeof e == "object") {
		if (Array.isArray(e)) {
			var i = e.length;
			for (t = 0; t < i; t++) e[t] && (n = Je(e[t])) && (r && (r += " "), r += n);
		} else for (n in e) e[n] && (r && (r += " "), r += n);
	}
	return r;
}
function Ye() {
	for (var e, t, n = 0, r = "", i = arguments.length; n < i; n++) (e = arguments[n]) && (t = Je(e)) && (r && (r += " "), r += t);
	return r;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/resolve-class-names/resolve-class-names.mjs
var Xe = {};
function Ze(e) {
	let t = {};
	return e.forEach((e) => {
		Object.entries(e).forEach(([e, n]) => {
			t[e] ? t[e] = Ye(t[e], n) : t[e] = n;
		});
	}), t;
}
function Qe({ theme: e, classNames: t, props: n, stylesCtx: r }) {
	return Ze((Array.isArray(t) ? t : [t]).map((t) => typeof t == "function" ? t(e, n, r) : t || Xe));
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-style/resolve-styles/resolve-styles.mjs
function $e({ theme: e, styles: t, props: n, stylesCtx: r }) {
	let i = Array.isArray(t) ? t : [t], a = {};
	for (let t of i) typeof t == "function" ? Object.assign(a, t(e, n, r)) : t && Object.assign(a, t);
	return a;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-scheme-managers/is-mantine-color-scheme.mjs
function et(e) {
	return e === "auto" || e === "dark" || e === "light";
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-scheme-managers/local-storage-manager.mjs
function tt({ key: e = "mantine-color-scheme-value" } = {}) {
	let t;
	return {
		get: (t) => {
			if (typeof window > "u") return t;
			try {
				let n = window.localStorage.getItem(e);
				return et(n) ? n : t;
			} catch {
				return t;
			}
		},
		set: (t) => {
			try {
				window.localStorage.setItem(e, t);
			} catch (e) {
				console.warn("[@mantine/core] Local storage color scheme manager was unable to save color scheme.", e);
			}
		},
		subscribe: (n) => {
			t = (t) => {
				t.storageArea === window.localStorage && t.key === e && et(t.newValue) && n(t.newValue);
			}, window.addEventListener("storage", t);
		},
		unsubscribe: () => {
			window.removeEventListener("storage", t);
		},
		clear: () => {
			window.localStorage.removeItem(e);
		}
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-functions/get-primary-shade/get-primary-shade.mjs
function nt(e, t) {
	return typeof e.primaryShade == "number" ? e.primaryShade : t === "dark" ? e.primaryShade.dark : e.primaryShade.light;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-functions/to-rgba/to-rgba.mjs
function rt(e) {
	return /^#?([0-9A-F]{3}){1,2}([0-9A-F]{2})?$/i.test(e);
}
function it(e) {
	let t = e.replace("#", "");
	if (t.length === 3) {
		let e = t.split("");
		t = [
			e[0],
			e[0],
			e[1],
			e[1],
			e[2],
			e[2]
		].join("");
	}
	if (t.length === 8) {
		let e = parseInt(t.slice(6, 8), 16) / 255;
		return {
			r: parseInt(t.slice(0, 2), 16),
			g: parseInt(t.slice(2, 4), 16),
			b: parseInt(t.slice(4, 6), 16),
			a: e
		};
	}
	let n = parseInt(t, 16);
	return {
		r: n >> 16 & 255,
		g: n >> 8 & 255,
		b: n & 255,
		a: 1
	};
}
function at(e) {
	let [t, n, r, i] = e.replace(/[^0-9,./]/g, "").split(/[/,]/).map(Number);
	return {
		r: t,
		g: n,
		b: r,
		a: i === void 0 ? 1 : i
	};
}
function ot(e) {
	let t = e.match(/^hsla?\(\s*(\d+)\s*,\s*(\d+%)\s*,\s*(\d+%)\s*(,\s*(0?\.\d+|\d+(\.\d+)?))?\s*\)$/i);
	if (!t) return {
		r: 0,
		g: 0,
		b: 0,
		a: 1
	};
	let n = parseInt(t[1], 10), r = parseInt(t[2], 10) / 100, i = parseInt(t[3], 10) / 100, a = t[5] ? parseFloat(t[5]) : void 0, o = (1 - Math.abs(2 * i - 1)) * r, s = n / 60, c = o * (1 - Math.abs(s % 2 - 1)), l = i - o / 2, u, d, f;
	return s >= 0 && s < 1 ? (u = o, d = c, f = 0) : s >= 1 && s < 2 ? (u = c, d = o, f = 0) : s >= 2 && s < 3 ? (u = 0, d = o, f = c) : s >= 3 && s < 4 ? (u = 0, d = c, f = o) : s >= 4 && s < 5 ? (u = c, d = 0, f = o) : (u = o, d = 0, f = c), {
		r: Math.round((u + l) * 255),
		g: Math.round((d + l) * 255),
		b: Math.round((f + l) * 255),
		a: a || 1
	};
}
function st(e) {
	return rt(e) ? it(e) : e.startsWith("rgb") ? at(e) : e.startsWith("hsl") ? ot(e) : {
		r: 0,
		g: 0,
		b: 0,
		a: 1
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-functions/luminance/luminance.mjs
function ct(e) {
	return e <= .03928 ? e / 12.92 : ((e + .055) / 1.055) ** 2.4;
}
function lt(e) {
	let t = e.match(/oklch\((.*?)%\s/);
	return t ? parseFloat(t[1]) : null;
}
function ut(e) {
	if (e.startsWith("oklch(")) return (lt(e) || 0) / 100;
	let { r: t, g: n, b: r } = st(e), i = t / 255, a = n / 255, o = r / 255, s = ct(i), c = ct(a), l = ct(o);
	return .2126 * s + .7152 * c + .0722 * l;
}
function dt(e, t = .179) {
	return !e.startsWith("var(") && ut(e) > t;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-functions/parse-theme-color/parse-theme-color.mjs
function ft({ color: e, theme: t, colorScheme: n }) {
	if (typeof e != "string") throw Error(`[@mantine/core] Failed to parse color. Expected color to be a string, instead got ${typeof e}`);
	if (e === "bright") return {
		color: e,
		value: n === "dark" ? t.white : t.black,
		shade: void 0,
		isThemeColor: !1,
		isLight: dt(n === "dark" ? t.white : t.black, t.luminanceThreshold),
		variable: "--mantine-color-bright"
	};
	if (e === "dimmed") return {
		color: e,
		value: n === "dark" ? t.colors.dark[2] : t.colors.gray[7],
		shade: void 0,
		isThemeColor: !1,
		isLight: dt(n === "dark" ? t.colors.dark[2] : t.colors.gray[6], t.luminanceThreshold),
		variable: "--mantine-color-dimmed"
	};
	if (e === "white" || e === "black") return {
		color: e,
		value: e === "white" ? t.white : t.black,
		shade: void 0,
		isThemeColor: !1,
		isLight: dt(e === "white" ? t.white : t.black, t.luminanceThreshold),
		variable: `--mantine-color-${e}`
	};
	let [r, i] = e.split("."), a = i ? Number(i) : void 0, o = r in t.colors;
	if (o) {
		let e = a === void 0 ? t.colors[r][nt(t, n || "light")] : t.colors[r][a];
		return {
			color: r,
			value: e,
			shade: a,
			isThemeColor: o,
			isLight: dt(e, t.luminanceThreshold),
			variable: i ? `--mantine-color-${r}-${a}` : `--mantine-color-${r}-filled`
		};
	}
	return {
		color: e,
		value: e,
		isThemeColor: o,
		isLight: dt(e, t.luminanceThreshold),
		shade: a,
		variable: void 0
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-functions/get-theme-color/get-theme-color.mjs
function pt(e, t) {
	let n = ft({
		color: e || t.primaryColor,
		theme: t
	});
	return n.variable ? `var(${n.variable})` : e;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/virtual-color/virtual-color.mjs
function mt(e) {
	return !!e && typeof e == "object" && "mantine-virtual-color" in e;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-functions/darken/darken.mjs
function ht(e, t) {
	if (e.startsWith("var(")) return `color-mix(in srgb, ${e}, black ${t * 100}%)`;
	let { r: n, g: r, b: i, a } = st(e), o = 1 - t, s = (e) => Math.round(e * o);
	return `rgba(${s(n)}, ${s(r)}, ${s(i)}, ${a})`;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-functions/get-gradient/get-gradient.mjs
function gt(e, t) {
	let n = {
		from: e?.from || t.defaultGradient.from,
		to: e?.to || t.defaultGradient.to,
		deg: e?.deg ?? t.defaultGradient.deg ?? 0
	}, r = pt(n.from, t), i = pt(n.to, t);
	return `linear-gradient(${n.deg}deg, ${r} 0%, ${i} 100%)`;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-functions/rgba/rgba.mjs
function _t(e, t) {
	if (typeof e != "string" || t > 1 || t < 0) return "rgba(0, 0, 0, 1)";
	if (e.startsWith("var(")) return `color-mix(in srgb, ${e}, transparent ${(1 - t) * 100}%)`;
	if (e.startsWith("oklch")) return e.includes("/") ? e.replace(/\/\s*[\d.]+\s*\)/, `/ ${t})`) : e.replace(")", ` / ${t})`);
	let { r: n, g: r, b: i } = st(e);
	return `rgba(${n}, ${r}, ${i}, ${t})`;
}
var vt = _t, yt = ({ color: e, theme: t, variant: n, gradient: r, autoContrast: i }) => {
	let a = ft({
		color: e,
		theme: t
	}), o = typeof i == "boolean" ? i : t.autoContrast;
	if (n === "none") return {
		background: "transparent",
		hover: "transparent",
		color: "inherit",
		border: "none"
	};
	if (n === "filled") {
		let n = a.isThemeColor && a.shade === void 0 && mt(t.colors[a.color]), r = o ? n ? `var(--mantine-color-${a.color}-contrast)` : a.isLight ? "var(--mantine-color-black)" : "var(--mantine-color-white)" : "var(--mantine-color-white)";
		return a.isThemeColor ? a.shade === void 0 ? {
			background: `var(--mantine-color-${e}-filled)`,
			hover: `var(--mantine-color-${e}-filled-hover)`,
			color: r,
			border: `${P(1)} solid transparent`
		} : {
			background: `var(--mantine-color-${a.color}-${a.shade})`,
			hover: `var(--mantine-color-${a.color}-${a.shade === 9 ? 8 : a.shade + 1})`,
			color: r,
			border: `${P(1)} solid transparent`
		} : {
			background: e,
			hover: ht(e, .1),
			color: r,
			border: `${P(1)} solid transparent`
		};
	}
	if (n === "light") {
		if (a.isThemeColor) {
			if (a.shade === void 0) return {
				background: `var(--mantine-color-${e}-light)`,
				hover: `var(--mantine-color-${e}-light-hover)`,
				color: `var(--mantine-color-${e}-light-color)`,
				border: `${P(1)} solid transparent`
			};
			let n = t.colors[a.color][a.shade];
			return {
				background: n,
				hover: ht(n, .1),
				color: `var(--mantine-color-${a.color}-light-color)`,
				border: `${P(1)} solid transparent`
			};
		}
		return {
			background: _t(e, .1),
			hover: _t(e, .12),
			color: e,
			border: `${P(1)} solid transparent`
		};
	}
	if (n === "outline") return a.isThemeColor ? a.shade === void 0 ? {
		background: "transparent",
		hover: `var(--mantine-color-${e}-outline-hover)`,
		color: `var(--mantine-color-${e}-outline)`,
		border: `${P(1)} solid var(--mantine-color-${e}-outline)`
	} : {
		background: "transparent",
		hover: _t(t.colors[a.color][a.shade], .05),
		color: `var(--mantine-color-${a.color}-${a.shade})`,
		border: `${P(1)} solid var(--mantine-color-${a.color}-${a.shade})`
	} : {
		background: "transparent",
		hover: _t(e, .05),
		color: e,
		border: `${P(1)} solid ${e}`
	};
	if (n === "subtle") {
		if (a.isThemeColor) {
			if (a.shade === void 0) return {
				background: "transparent",
				hover: `var(--mantine-color-${e}-light-hover)`,
				color: `var(--mantine-color-${e}-light-color)`,
				border: `${P(1)} solid transparent`
			};
			let n = t.colors[a.color][a.shade];
			return {
				background: "transparent",
				hover: _t(n, .12),
				color: `var(--mantine-color-${a.color}-${Math.min(a.shade, 6)})`,
				border: `${P(1)} solid transparent`
			};
		}
		return {
			background: "transparent",
			hover: _t(e, .12),
			color: e,
			border: `${P(1)} solid transparent`
		};
	}
	return n === "transparent" ? a.isThemeColor ? a.shade === void 0 ? {
		background: "transparent",
		hover: "transparent",
		color: `var(--mantine-color-${e}-light-color)`,
		border: `${P(1)} solid transparent`
	} : {
		background: "transparent",
		hover: "transparent",
		color: `var(--mantine-color-${a.color}-${Math.min(a.shade, 6)})`,
		border: `${P(1)} solid transparent`
	} : {
		background: "transparent",
		hover: "transparent",
		color: e,
		border: `${P(1)} solid transparent`
	} : n === "white" ? a.isThemeColor ? a.shade === void 0 ? {
		background: "var(--mantine-color-white)",
		hover: ht(t.white, .01),
		color: `var(--mantine-color-${e}-filled)`,
		border: `${P(1)} solid transparent`
	} : {
		background: "var(--mantine-color-white)",
		hover: ht(t.white, .01),
		color: `var(--mantine-color-${a.color}-${a.shade})`,
		border: `${P(1)} solid transparent`
	} : {
		background: "var(--mantine-color-white)",
		hover: ht(t.white, .01),
		color: e,
		border: `${P(1)} solid transparent`
	} : n === "gradient" ? {
		background: gt(r, t),
		hover: gt(r, t),
		color: "var(--mantine-color-white)",
		border: "none"
	} : n === "default" ? {
		background: "var(--mantine-color-default)",
		hover: "var(--mantine-color-default-hover)",
		color: "var(--mantine-color-default-color)",
		border: `${P(1)} solid var(--mantine-color-default-border)`
	} : {};
};
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-functions/get-contrast-color/get-contrast-color.mjs
function bt({ color: e, theme: t, autoContrast: n, colorScheme: r }) {
	return (typeof n == "boolean" ? n : t.autoContrast) && ft({
		color: e || t.primaryColor,
		theme: t,
		colorScheme: r
	}).isLight ? "var(--mantine-color-black)" : "var(--mantine-color-white)";
}
function xt(e, t, n) {
	return bt({
		color: n === "dark" ? e.dark : e.light,
		theme: t,
		colorScheme: n,
		autoContrast: !0
	});
}
function St(e, t) {
	let n = e.colors[e.primaryColor];
	return mt(n) ? e.autoContrast ? xt(n, e, t) : "var(--mantine-color-white)" : bt({
		color: n[nt(e, t)],
		theme: e,
		autoContrast: null
	});
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/color-functions/get-auto-contrast-value/get-auto-contrast-value.mjs
function Ct(e, t) {
	return typeof e == "boolean" ? e : t.autoContrast;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/Mantine.context.mjs
var wt = s(null);
function Tt() {
	let e = u(wt);
	if (!e) throw Error("[@mantine/core] MantineProvider was not found in tree");
	return e;
}
function Et() {
	return Tt().cssVariablesResolver;
}
function Dt() {
	return Tt().classNamesPrefix;
}
function Ot() {
	return Tt().getStyleNonce;
}
function kt() {
	return Tt().withStaticClasses;
}
function At() {
	return Tt().headless;
}
function jt() {
	return Tt().stylesTransform?.sx;
}
function Mt() {
	return Tt().stylesTransform?.styles;
}
function Nt() {
	return Tt().env || "default";
}
function Pt() {
	return Tt().deduplicateInlineStyles;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/use-mantine-color-scheme/use-mantine-color-scheme.mjs
function Ft(e) {
	let t = document.createElement("style");
	return t.setAttribute("data-mantine-styles", "inline"), t.innerHTML = "*, *::before, *::after {transition: none !important;}", t.setAttribute("data-mantine-disable-transition", "true"), e && t.setAttribute("nonce", e), document.head.appendChild(t), () => document.querySelectorAll("[data-mantine-disable-transition]").forEach((e) => e.remove());
}
function It({ keepTransitions: e } = {}) {
	let t = v(le), n = v(-1), r = u(wt), i = Ot(), a = v(i?.());
	if (!r) throw Error("[@mantine/core] MantineProvider was not found in tree");
	let o = (i) => {
		r.setColorScheme(i), t.current = e ? () => {} : Ft(a.current), window.clearTimeout(n.current), n.current = window.setTimeout(() => {
			t.current?.();
		}, 10);
	}, s = () => {
		r.clearColorScheme(), t.current = e ? () => {} : Ft(a.current), window.clearTimeout(n.current), n.current = window.setTimeout(() => {
			t.current?.();
		}, 10);
	}, c = be("light", { getInitialValueInEffect: !1 }), l = r.colorScheme === "auto" ? c : r.colorScheme, f = d(() => o(l === "light" ? "dark" : "light"), [o, l]);
	return p(() => () => {
		t.current?.(), window.clearTimeout(n.current);
	}, []), {
		colorScheme: r.colorScheme,
		setColorScheme: o,
		clearColorScheme: s,
		toggleColorScheme: f
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/use-mantine-color-scheme/use-provider-color-scheme.mjs
function Lt(e, t) {
	let n = typeof window < "u" && "matchMedia" in window && window.matchMedia("(prefers-color-scheme: dark)")?.matches, r = e === "auto" ? n ? "dark" : "light" : e;
	t()?.setAttribute("data-mantine-color-scheme", r);
}
function Rt({ manager: e, defaultColorScheme: t, getRootElement: n, forceColorScheme: r }) {
	let i = v(null), [a, o] = y(() => e.get(t)), s = r || a, c = d((t) => {
		r || (Lt(t, n), o(t), e.set(t));
	}, [
		e.set,
		s,
		r
	]), l = d(() => {
		o(t), Lt(t, n), e.clear();
	}, [e.clear, t]);
	return p(() => (e.subscribe(c), e.unsubscribe), [e.subscribe, e.unsubscribe]), xe(() => {
		Lt(e.get(t), n);
	}, []), p(() => {
		if (r) return Lt(r, n), () => {};
		r === void 0 && Lt(a, n), typeof window < "u" && "matchMedia" in window && (i.current = window.matchMedia("(prefers-color-scheme: dark)"));
		let e = (e) => {
			a === "auto" && Lt(e.matches ? "dark" : "light", n);
		};
		return i.current?.addEventListener("change", e), () => i.current?.removeEventListener("change", e);
	}, [a, r]), {
		colorScheme: s,
		setColorScheme: c,
		clearColorScheme: l
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/use-mantine-color-scheme/use-computed-color-scheme.mjs
function zt(e, t = { getInitialValueInEffect: !0 }) {
	let n = be(e, t), { colorScheme: r } = It();
	return r === "auto" ? n : r;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/default-colors.mjs
var Bt = {
	dark: [
		"#C9C9C9",
		"#b8b8b8",
		"#828282",
		"#696969",
		"#424242",
		"#3b3b3b",
		"#2e2e2e",
		"#242424",
		"#1f1f1f",
		"#141414"
	],
	gray: [
		"#f8f9fa",
		"#f1f3f5",
		"#e9ecef",
		"#dee2e6",
		"#ced4da",
		"#adb5bd",
		"#868e96",
		"#495057",
		"#343a40",
		"#212529"
	],
	red: [
		"#fff5f5",
		"#ffe3e3",
		"#ffc9c9",
		"#ffa8a8",
		"#ff8787",
		"#ff6b6b",
		"#fa5252",
		"#f03e3e",
		"#e03131",
		"#c92a2a"
	],
	pink: [
		"#fff0f6",
		"#ffdeeb",
		"#fcc2d7",
		"#faa2c1",
		"#f783ac",
		"#f06595",
		"#e64980",
		"#d6336c",
		"#c2255c",
		"#a61e4d"
	],
	grape: [
		"#f8f0fc",
		"#f3d9fa",
		"#eebefa",
		"#e599f7",
		"#da77f2",
		"#cc5de8",
		"#be4bdb",
		"#ae3ec9",
		"#9c36b5",
		"#862e9c"
	],
	violet: [
		"#f3f0ff",
		"#e5dbff",
		"#d0bfff",
		"#b197fc",
		"#9775fa",
		"#845ef7",
		"#7950f2",
		"#7048e8",
		"#6741d9",
		"#5f3dc4"
	],
	indigo: [
		"#edf2ff",
		"#dbe4ff",
		"#bac8ff",
		"#91a7ff",
		"#748ffc",
		"#5c7cfa",
		"#4c6ef5",
		"#4263eb",
		"#3b5bdb",
		"#364fc7"
	],
	blue: [
		"#e7f5ff",
		"#d0ebff",
		"#a5d8ff",
		"#74c0fc",
		"#4dabf7",
		"#339af0",
		"#228be6",
		"#1c7ed6",
		"#1971c2",
		"#1864ab"
	],
	cyan: [
		"#e3fafc",
		"#c5f6fa",
		"#99e9f2",
		"#66d9e8",
		"#3bc9db",
		"#22b8cf",
		"#15aabf",
		"#1098ad",
		"#0c8599",
		"#0b7285"
	],
	teal: [
		"#e6fcf5",
		"#c3fae8",
		"#96f2d7",
		"#63e6be",
		"#38d9a9",
		"#20c997",
		"#12b886",
		"#0ca678",
		"#099268",
		"#087f5b"
	],
	green: [
		"#ebfbee",
		"#d3f9d8",
		"#b2f2bb",
		"#8ce99a",
		"#69db7c",
		"#51cf66",
		"#40c057",
		"#37b24d",
		"#2f9e44",
		"#2b8a3e"
	],
	lime: [
		"#f4fce3",
		"#e9fac8",
		"#d8f5a2",
		"#c0eb75",
		"#a9e34b",
		"#94d82d",
		"#82c91e",
		"#74b816",
		"#66a80f",
		"#5c940d"
	],
	yellow: [
		"#fff9db",
		"#fff3bf",
		"#ffec99",
		"#ffe066",
		"#ffd43b",
		"#fcc419",
		"#fab005",
		"#f59f00",
		"#f08c00",
		"#e67700"
	],
	orange: [
		"#fff4e6",
		"#ffe8cc",
		"#ffd8a8",
		"#ffc078",
		"#ffa94d",
		"#ff922b",
		"#fd7e14",
		"#f76707",
		"#e8590c",
		"#d9480f"
	]
}, Vt = "-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Helvetica, Arial, sans-serif, Apple Color Emoji, Segoe UI Emoji", Ht = {
	scale: 1,
	fontSmoothing: !0,
	focusRing: "auto",
	white: "#fff",
	black: "#000",
	colors: Bt,
	primaryShade: {
		light: 6,
		dark: 8
	},
	primaryColor: "blue",
	variantColorResolver: yt,
	autoContrast: !1,
	luminanceThreshold: .3,
	fontFamily: Vt,
	fontFamilyMonospace: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, Liberation Mono, Courier New, monospace",
	respectReducedMotion: !1,
	cursorType: "default",
	defaultGradient: {
		from: "blue",
		to: "cyan",
		deg: 45
	},
	defaultRadius: "md",
	activeClassName: "mantine-active",
	focusClassName: "",
	headings: {
		fontFamily: Vt,
		fontWeight: "700",
		textWrap: "wrap",
		sizes: {
			h1: {
				fontSize: P(34),
				lineHeight: "1.3"
			},
			h2: {
				fontSize: P(26),
				lineHeight: "1.35"
			},
			h3: {
				fontSize: P(22),
				lineHeight: "1.4"
			},
			h4: {
				fontSize: P(18),
				lineHeight: "1.45"
			},
			h5: {
				fontSize: P(16),
				lineHeight: "1.5"
			},
			h6: {
				fontSize: P(14),
				lineHeight: "1.5"
			}
		}
	},
	fontSizes: {
		xs: P(12),
		sm: P(14),
		md: P(16),
		lg: P(18),
		xl: P(20)
	},
	lineHeights: {
		xs: "1.4",
		sm: "1.45",
		md: "1.55",
		lg: "1.6",
		xl: "1.65"
	},
	fontWeights: {
		regular: "400",
		medium: "600",
		bold: "700"
	},
	radius: {
		xs: P(2),
		sm: P(4),
		md: P(8),
		lg: P(16),
		xl: P(32)
	},
	spacing: {
		xs: P(10),
		sm: P(12),
		md: P(16),
		lg: P(20),
		xl: P(32)
	},
	breakpoints: {
		xs: "36em",
		sm: "48em",
		md: "62em",
		lg: "75em",
		xl: "88em"
	},
	shadows: {
		xs: `0 ${P(1)} ${P(3)} rgba(0, 0, 0, 0.05), 0 ${P(1)} ${P(2)} rgba(0, 0, 0, 0.1)`,
		sm: `0 ${P(1)} ${P(3)} rgba(0, 0, 0, 0.05), rgba(0, 0, 0, 0.05) 0 ${P(10)} ${P(15)} ${P(-5)}, rgba(0, 0, 0, 0.04) 0 ${P(7)} ${P(7)} ${P(-5)}`,
		md: `0 ${P(1)} ${P(3)} rgba(0, 0, 0, 0.05), rgba(0, 0, 0, 0.05) 0 ${P(20)} ${P(25)} ${P(-5)}, rgba(0, 0, 0, 0.04) 0 ${P(10)} ${P(10)} ${P(-5)}`,
		lg: `0 ${P(1)} ${P(3)} rgba(0, 0, 0, 0.05), rgba(0, 0, 0, 0.05) 0 ${P(28)} ${P(23)} ${P(-7)}, rgba(0, 0, 0, 0.04) 0 ${P(12)} ${P(12)} ${P(-7)}`,
		xl: `0 ${P(1)} ${P(3)} rgba(0, 0, 0, 0.05), rgba(0, 0, 0, 0.05) 0 ${P(36)} ${P(28)} ${P(-7)}, rgba(0, 0, 0, 0.04) 0 ${P(17)} ${P(17)} ${P(-7)}`
	},
	other: {},
	components: {}
}, Ut = "[@mantine/core] MantineProvider: Invalid theme.primaryColor, it accepts only key of theme.colors, learn more – https://mantine.dev/theming/colors/#primary-color", Wt = "[@mantine/core] MantineProvider: Invalid theme.primaryShade, it accepts only 0-9 integers or an object { light: 0-9, dark: 0-9 }";
function Gt(e) {
	return e < 0 || e > 9 ? !1 : parseInt(e.toString(), 10) === e;
}
function Kt(e) {
	if (!(e.primaryColor in e.colors)) throw Error(Ut);
	if (typeof e.primaryShade == "object" && (!Gt(e.primaryShade.dark) || !Gt(e.primaryShade.light)) || typeof e.primaryShade == "number" && !Gt(e.primaryShade)) throw Error(Wt);
}
function qt(e, t) {
	if (!t) return Kt(e), e;
	let n = k(e, t);
	return t.fontFamily && !t.headings?.fontFamily && (n.headings = {
		...n.headings,
		fontFamily: t.fontFamily
	}), Kt(n), n;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/MantineThemeProvider/MantineThemeProvider.mjs
var Jt = s(null), Yt = () => u(Jt) || Ht;
function Xt() {
	let e = u(Jt);
	if (!e) throw Error("@mantine/core: MantineProvider was not found in component tree, make sure you have it in your app");
	return e;
}
function Zt({ theme: e, children: t, inherit: n = !0 }) {
	let r = Yt(), i = _(() => qt(n ? r : Ht, e), [
		e,
		r,
		n
	]);
	return /* @__PURE__ */ T(Jt, {
		value: i,
		children: t
	});
}
Zt.displayName = "@mantine/core/MantineThemeProvider";
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/convert-css-variables/css-variables-object-to-string.mjs
function Qt(e) {
	return Object.entries(e).map(([e, t]) => `${e}: ${t};`).join("");
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/convert-css-variables/convert-css-variables.mjs
function $t(e, t) {
	let n = t ? [t] : [":root", ":host"], r = Qt(e.variables), i = r ? `${n.join(", ")}{${r}}` : "", a = Qt(e.dark), o = Qt(e.light), s = (e) => n.map((t) => t === ":host" ? `${t}([data-mantine-color-scheme="${e}"])` : `${t}[data-mantine-color-scheme="${e}"]`).join(", ");
	return `${i}\n\n${a ? `${s("dark")}{${a}}` : ""}\n\n${o ? `${s("light")}{${o}}` : ""}`;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/get-css-color-variables.mjs
function en({ theme: e, color: t, colorScheme: n, name: r = t, withColorValues: i = !0 }) {
	if (!e.colors[t]) return {};
	if (n === "light") {
		let n = nt(e, "light"), a = {
			[`--mantine-color-${r}-text`]: `var(--mantine-color-${r}-filled)`,
			[`--mantine-color-${r}-filled`]: `var(--mantine-color-${r}-${n})`,
			[`--mantine-color-${r}-filled-hover`]: `var(--mantine-color-${r}-${n === 9 ? 8 : n + 1})`,
			[`--mantine-color-${r}-light`]: `var(--mantine-color-${r}-1)`,
			[`--mantine-color-${r}-light-hover`]: `var(--mantine-color-${r}-2)`,
			[`--mantine-color-${r}-light-color`]: `var(--mantine-color-${r}-9)`,
			[`--mantine-color-${r}-outline`]: `var(--mantine-color-${r}-${n})`,
			[`--mantine-color-${r}-outline-hover`]: vt(e.colors[t][n], .05)
		};
		return i ? {
			[`--mantine-color-${r}-0`]: e.colors[t][0],
			[`--mantine-color-${r}-1`]: e.colors[t][1],
			[`--mantine-color-${r}-2`]: e.colors[t][2],
			[`--mantine-color-${r}-3`]: e.colors[t][3],
			[`--mantine-color-${r}-4`]: e.colors[t][4],
			[`--mantine-color-${r}-5`]: e.colors[t][5],
			[`--mantine-color-${r}-6`]: e.colors[t][6],
			[`--mantine-color-${r}-7`]: e.colors[t][7],
			[`--mantine-color-${r}-8`]: e.colors[t][8],
			[`--mantine-color-${r}-9`]: e.colors[t][9],
			...a
		} : a;
	}
	let a = nt(e, "dark"), o = {
		[`--mantine-color-${r}-text`]: `var(--mantine-color-${r}-4)`,
		[`--mantine-color-${r}-filled`]: `var(--mantine-color-${r}-${a})`,
		[`--mantine-color-${r}-filled-hover`]: `var(--mantine-color-${r}-${a === 9 ? 8 : a + 1})`,
		[`--mantine-color-${r}-light`]: ht(e.colors[t][9], .5),
		[`--mantine-color-${r}-light-hover`]: ht(e.colors[t][9], .3),
		[`--mantine-color-${r}-light-color`]: `var(--mantine-color-${r}-0)`,
		[`--mantine-color-${r}-outline`]: `var(--mantine-color-${r}-${Math.max(a - 4, 0)})`,
		[`--mantine-color-${r}-outline-hover`]: vt(e.colors[t][Math.max(a - 4, 0)], .05)
	};
	return i ? {
		[`--mantine-color-${r}-0`]: e.colors[t][0],
		[`--mantine-color-${r}-1`]: e.colors[t][1],
		[`--mantine-color-${r}-2`]: e.colors[t][2],
		[`--mantine-color-${r}-3`]: e.colors[t][3],
		[`--mantine-color-${r}-4`]: e.colors[t][4],
		[`--mantine-color-${r}-5`]: e.colors[t][5],
		[`--mantine-color-${r}-6`]: e.colors[t][6],
		[`--mantine-color-${r}-7`]: e.colors[t][7],
		[`--mantine-color-${r}-8`]: e.colors[t][8],
		[`--mantine-color-${r}-9`]: e.colors[t][9],
		...o
	} : o;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/default-css-variables-resolver.mjs
function tn(e, t, n) {
	D(t).forEach((r) => Object.assign(e, { [`--mantine-${n}-${r}`]: t[r] }));
}
var nn = (e) => {
	let t = nt(e, "light"), n = e.defaultRadius in e.radius ? e.radius[e.defaultRadius] : P(e.defaultRadius), r = {
		variables: {
			"--mantine-z-index-app": "100",
			"--mantine-z-index-modal": "200",
			"--mantine-z-index-popover": "300",
			"--mantine-z-index-overlay": "400",
			"--mantine-z-index-max": "9999",
			"--mantine-scale": e.scale.toString(),
			"--mantine-cursor-type": e.cursorType,
			"--mantine-webkit-font-smoothing": e.fontSmoothing ? "antialiased" : "unset",
			"--mantine-moz-font-smoothing": e.fontSmoothing ? "grayscale" : "unset",
			"--mantine-color-white": e.white,
			"--mantine-color-black": e.black,
			"--mantine-line-height": e.lineHeights.md,
			"--mantine-font-family": e.fontFamily,
			"--mantine-font-family-monospace": e.fontFamilyMonospace,
			"--mantine-font-family-headings": e.headings.fontFamily,
			"--mantine-heading-font-weight": e.headings.fontWeight,
			"--mantine-heading-text-wrap": e.headings.textWrap,
			"--mantine-radius-default": n,
			"--mantine-primary-color-filled": `var(--mantine-color-${e.primaryColor}-filled)`,
			"--mantine-primary-color-filled-hover": `var(--mantine-color-${e.primaryColor}-filled-hover)`,
			"--mantine-primary-color-light": `var(--mantine-color-${e.primaryColor}-light)`,
			"--mantine-primary-color-light-hover": `var(--mantine-color-${e.primaryColor}-light-hover)`,
			"--mantine-primary-color-light-color": `var(--mantine-color-${e.primaryColor}-light-color)`
		},
		light: {
			"--mantine-color-scheme": "light",
			"--mantine-primary-color-contrast": St(e, "light"),
			"--mantine-color-bright": "var(--mantine-color-black)",
			"--mantine-color-text": e.black,
			"--mantine-color-body": e.white,
			"--mantine-color-error": "var(--mantine-color-red-6)",
			"--mantine-color-success": "var(--mantine-color-teal-8)",
			"--mantine-color-placeholder": "var(--mantine-color-gray-5)",
			"--mantine-color-anchor": `var(--mantine-color-${e.primaryColor}-${t})`,
			"--mantine-color-default": "var(--mantine-color-white)",
			"--mantine-color-default-hover": "var(--mantine-color-gray-0)",
			"--mantine-color-default-color": "var(--mantine-color-black)",
			"--mantine-color-default-border": "var(--mantine-color-gray-4)",
			"--mantine-color-dimmed": "var(--mantine-color-gray-6)",
			"--mantine-color-disabled": "var(--mantine-color-gray-2)",
			"--mantine-color-disabled-color": "var(--mantine-color-gray-5)",
			"--mantine-color-disabled-border": "var(--mantine-color-gray-3)"
		},
		dark: {
			"--mantine-color-scheme": "dark",
			"--mantine-primary-color-contrast": St(e, "dark"),
			"--mantine-color-bright": "var(--mantine-color-white)",
			"--mantine-color-text": "var(--mantine-color-dark-0)",
			"--mantine-color-body": "var(--mantine-color-dark-7)",
			"--mantine-color-error": "var(--mantine-color-red-8)",
			"--mantine-color-success": "var(--mantine-color-teal-8)",
			"--mantine-color-placeholder": "var(--mantine-color-dark-3)",
			"--mantine-color-anchor": `var(--mantine-color-${e.primaryColor}-4)`,
			"--mantine-color-default": "var(--mantine-color-dark-6)",
			"--mantine-color-default-hover": "var(--mantine-color-dark-5)",
			"--mantine-color-default-color": "var(--mantine-color-white)",
			"--mantine-color-default-border": "var(--mantine-color-dark-4)",
			"--mantine-color-dimmed": "var(--mantine-color-dark-2)",
			"--mantine-color-disabled": "var(--mantine-color-dark-6)",
			"--mantine-color-disabled-color": "var(--mantine-color-dark-3)",
			"--mantine-color-disabled-border": "var(--mantine-color-dark-4)"
		}
	};
	tn(r.variables, e.breakpoints, "breakpoint"), tn(r.variables, e.spacing, "spacing"), tn(r.variables, e.fontSizes, "font-size"), tn(r.variables, e.lineHeights, "line-height"), tn(r.variables, e.shadows, "shadow"), tn(r.variables, e.radius, "radius"), tn(r.variables, e.fontWeights, "font-weight"), e.colors[e.primaryColor].forEach((t, n) => {
		r.variables[`--mantine-primary-color-${n}`] = `var(--mantine-color-${e.primaryColor}-${n})`;
	}), D(e.colors).forEach((t) => {
		let n = e.colors[t];
		if (mt(n)) {
			Object.assign(r.light, en({
				theme: e,
				name: n.name,
				color: n.light,
				colorScheme: "light",
				withColorValues: !0
			})), Object.assign(r.dark, en({
				theme: e,
				name: n.name,
				color: n.dark,
				colorScheme: "dark",
				withColorValues: !0
			})), r.light[`--mantine-color-${n.name}-contrast`] = xt(n, e, "light"), r.dark[`--mantine-color-${n.name}-contrast`] = xt(n, e, "dark");
			return;
		}
		n.forEach((e, n) => {
			r.variables[`--mantine-color-${t}-${n}`] = e;
		}), Object.assign(r.light, en({
			theme: e,
			color: t,
			colorScheme: "light",
			withColorValues: !1
		})), Object.assign(r.dark, en({
			theme: e,
			color: t,
			colorScheme: "dark",
			withColorValues: !1
		}));
	});
	let i = e.headings.sizes;
	return D(i).forEach((t) => {
		r.variables[`--mantine-${t}-font-size`] = i[t].fontSize, r.variables[`--mantine-${t}-line-height`] = i[t].lineHeight, r.variables[`--mantine-${t}-font-weight`] = i[t].fontWeight || e.headings.fontWeight;
	}), r;
};
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/MantineClasses/MantineClasses.mjs
function rn() {
	let e = Xt(), t = Ot(), n = D(e.breakpoints).reduce((t, n) => {
		let r = e.breakpoints[n].includes("px"), i = j(e.breakpoints[n]);
		return `${t}@media (max-width: ${r ? `${i - .1}px` : te(i - .1)}) {.mantine-visible-from-${n} {display: none !important;}}@media (min-width: ${r ? `${i}px` : te(i)}) {.mantine-hidden-from-${n} {display: none !important;}}`;
	}, "");
	return /* @__PURE__ */ T("style", {
		"data-mantine-styles": "classes",
		nonce: t?.(),
		dangerouslySetInnerHTML: { __html: n }
	});
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/get-merged-variables.mjs
function an({ theme: e, generator: t }) {
	let n = nn(e), r = t?.(e);
	return r ? k(n, r) : n;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/remove-default-variables.mjs
var on = nn(Ht);
function sn(e) {
	let t = {
		variables: {},
		light: {},
		dark: {}
	};
	return D(e.variables).forEach((n) => {
		on.variables[n] !== e.variables[n] && (t.variables[n] = e.variables[n]);
	}), D(e.light).forEach((n) => {
		on.light[n] !== e.light[n] && (t.light[n] = e.light[n]);
	}), D(e.dark).forEach((n) => {
		on.dark[n] !== e.dark[n] && (t.dark[n] = e.dark[n]);
	}), t;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/MantineCssVariables.mjs
function cn(e) {
	return $t({
		variables: {},
		dark: { "--mantine-color-scheme": "dark" },
		light: { "--mantine-color-scheme": "light" }
	}, e);
}
function ln({ cssVariablesSelector: e, deduplicateCssVariables: t }) {
	let n = Xt(), r = Ot(), i = an({
		theme: n,
		generator: Et()
	}), a = (e === void 0 || e === ":root" || e === ":host") && t, o = $t(a ? sn(i) : i, e);
	return o ? /* @__PURE__ */ T("style", {
		"data-mantine-styles": !0,
		nonce: r?.(),
		dangerouslySetInnerHTML: { __html: `${o}${a ? "" : cn(e)}` }
	}) : null;
}
ln.displayName = "@mantine/CssVariables";
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/use-respect-reduce-motion/use-respect-reduce-motion.mjs
function un({ respectReducedMotion: e, getRootElement: t }) {
	xe(() => {
		e && t()?.setAttribute("data-respect-reduced-motion", "true");
	}, [e]);
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/MantineProvider.mjs
function dn({ theme: e, children: t, getStyleNonce: n, withStaticClasses: r = !0, withGlobalClasses: i = !0, deduplicateCssVariables: a = !0, withCssVariables: o = !0, cssVariablesSelector: s, classNamesPrefix: c = "mantine", colorSchemeManager: l = tt(), defaultColorScheme: u = "light", getRootElement: d = () => document.documentElement, cssVariablesResolver: f, forceColorScheme: p, stylesTransform: m, env: h, deduplicateInlineStyles: g = !1 }) {
	let { colorScheme: _, setColorScheme: v, clearColorScheme: y } = Rt({
		defaultColorScheme: u,
		forceColorScheme: p,
		manager: l,
		getRootElement: d
	});
	return un({
		respectReducedMotion: e?.respectReducedMotion || !1,
		getRootElement: d
	}), /* @__PURE__ */ T(wt, {
		value: {
			colorScheme: _,
			setColorScheme: v,
			clearColorScheme: y,
			getRootElement: d,
			classNamesPrefix: c,
			getStyleNonce: n,
			cssVariablesResolver: f,
			cssVariablesSelector: s ?? ":root",
			withStaticClasses: r,
			stylesTransform: m,
			env: h,
			deduplicateInlineStyles: g
		},
		children: /* @__PURE__ */ E(Zt, {
			theme: e,
			children: [
				o && /* @__PURE__ */ T(ln, {
					cssVariablesSelector: s,
					deduplicateCssVariables: a
				}),
				i && /* @__PURE__ */ T(rn, {}),
				t
			]
		})
	});
}
dn.displayName = "@mantine/core/MantineProvider";
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/use-props/use-props.mjs
function q(e, t, n) {
	let r = Xt(), i = (Array.isArray(e) ? e : [e]).filter(Boolean), a = {};
	for (let e of i) {
		let t = r.components[e]?.defaultProps, n = typeof t == "function" ? t(r) : t;
		n && (a = {
			...a,
			...n
		});
	}
	return {
		...t,
		...a,
		...ne(n)
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/MantineProvider/create-theme/create-theme.mjs
function fn(e) {
	return e;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-resolved-styles-api/use-resolved-styles-api.mjs
function pn({ classNames: e, styles: t, props: n, stylesCtx: r }) {
	let i = Xt();
	return {
		resolvedClassNames: e === void 0 ? void 0 : Qe({
			theme: i,
			classNames: e,
			props: n,
			stylesCtx: r || void 0
		}),
		resolvedStyles: t === void 0 ? void 0 : $e({
			theme: i,
			styles: t,
			props: n,
			stylesCtx: r || void 0
		})
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-global-class-names/get-global-class-names.mjs
var mn = {
	always: "mantine-focus-always",
	auto: "mantine-focus-auto",
	never: "mantine-focus-never"
};
function hn({ theme: e, options: t, unstyled: n }) {
	return Ye(t?.focusable && !n && (e.focusClassName || mn[e.focusRing]), t?.active && !n && e.activeClassName);
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-options-class-names/get-options-class-names.mjs
function gn({ selector: e, stylesCtx: t, options: n, props: r, theme: i }) {
	return Qe({
		theme: i,
		classNames: n?.classNames,
		props: n?.props || r,
		stylesCtx: t
	})[e];
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-resolved-class-names/get-resolved-class-names.mjs
function _n({ selector: e, stylesCtx: t, theme: n, classNames: r, props: i }) {
	return Qe({
		theme: n,
		classNames: r,
		props: i,
		stylesCtx: t
	})[e];
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-root-class-name/get-root-class-name.mjs
function vn({ rootSelector: e, selector: t, className: n }) {
	return e === t ? n : void 0;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-selector-class-name/get-selector-class-name.mjs
function yn({ selector: e, classes: t, unstyled: n }) {
	return n ? void 0 : t[e];
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-static-class-names/get-static-class-names.mjs
function bn({ themeName: e, classNamesPrefix: t, selector: n, withStaticClass: r }) {
	return r === !1 ? [] : e.map((e) => `${t}-${e}-${n}`);
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-variant-class-name/get-variant-class-name.mjs
function xn({ options: e, classes: t, selector: n, unstyled: r }) {
	return e?.variant && !r ? t[`${n}--${e.variant}`] : void 0;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-class-name/get-class-name.mjs
function Sn({ theme: e, options: t, themeName: n, selector: r, classNamesPrefix: i, resolvedClassNames: a, resolvedThemeClassNames: o, classes: s, unstyled: c, className: l, rootSelector: u, props: d, stylesCtx: f, withStaticClasses: p, headless: m, transformedStyles: h }) {
	return Ye(hn({
		theme: e,
		options: t,
		unstyled: c || m
	}), o.map((e) => e[r]), xn({
		options: t,
		classes: s,
		selector: r,
		unstyled: c || m
	}), a[r], _n({
		selector: r,
		stylesCtx: f,
		theme: e,
		classNames: h,
		props: d
	}), gn({
		selector: r,
		stylesCtx: f,
		options: t,
		props: d,
		theme: e
	}), vn({
		rootSelector: u,
		selector: r,
		className: l
	}), yn({
		selector: r,
		classes: s,
		unstyled: c || m
	}), p && !m && bn({
		themeName: n,
		classNamesPrefix: i,
		selector: r,
		withStaticClass: t?.withStaticClass
	}), t?.className);
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-style/resolve-style/resolve-style.mjs
function Cn({ style: e, theme: t }) {
	return Array.isArray(e) ? e.reduce((e, n) => ({
		...e,
		...Cn({
			style: n,
			theme: t
		})
	}), {}) : typeof e == "function" ? e(t) : e ?? {};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-style/get-style.mjs
function wn({ theme: e, selector: t, options: n, props: r, stylesCtx: i, rootSelector: a, withStylesTransform: o, resolvedStyles: s, resolvedThemeStyles: c, resolvedVars: l, resolvedRootStyle: u }) {
	return {
		...c[t],
		...s[t],
		...!o && $e({
			theme: e,
			styles: n?.styles,
			props: n?.props || r,
			stylesCtx: i
		})[t],
		...l[t],
		...a === t ? u : null,
		...Cn({
			style: n?.style,
			theme: e
		})
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/get-style/resolve-vars/merge-vars.mjs
function Tn(e) {
	return e.reduce((e, t) => (t && Object.keys(t).forEach((n) => {
		e[n] = {
			...e[n],
			...ne(t[n])
		};
	}), e), {});
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/use-transformed-styles.mjs
function En({ props: e, stylesCtx: t, themeName: n, theme: r }) {
	let i = Mt()?.();
	return {
		getTransformedStyles: (a) => i ? [...a.map((n) => i(n, {
			props: e,
			theme: r,
			ctx: t
		})), ...n.map((n) => i(r.components[n]?.styles, {
			props: e,
			theme: r,
			ctx: t
		}))].filter(Boolean) : [],
		withStylesTransform: !!i
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/styles-api/use-styles/use-styles.mjs
function J({ name: e, classes: t, props: n, stylesCtx: r, className: i, style: a, rootSelector: o = "root", unstyled: s, classNames: c, styles: l, vars: u, varsResolver: d, attributes: f }) {
	let p = Xt(), m = Dt(), h = kt(), g = At(), _ = (Array.isArray(e) ? e : [e]).filter((e) => e), { withStylesTransform: v, getTransformedStyles: y } = En({
		props: n,
		stylesCtx: r,
		themeName: _,
		theme: p
	}), b = Qe({
		theme: p,
		classNames: c,
		props: n,
		stylesCtx: r
	}), x = _.map((e) => Qe({
		theme: p,
		classNames: p.components[e]?.classNames,
		props: n,
		stylesCtx: r
	})), S = v ? {} : $e({
		theme: p,
		styles: l,
		props: n,
		stylesCtx: r
	}), C = {};
	if (!v) for (let e of _) {
		let t = $e({
			theme: p,
			styles: p.components[e]?.styles,
			props: n,
			stylesCtx: r
		});
		for (let e of Object.keys(t)) C[e] = {
			...C[e],
			...t[e]
		};
	}
	let w = Tn([
		g ? {} : d?.(p, n, r),
		..._.map((e) => p.components?.[e]?.vars?.(p, n, r)),
		u?.(p, n, r)
	]), T = Cn({
		style: a,
		theme: p
	});
	return (e, a) => ({
		...f?.[e],
		className: Sn({
			theme: p,
			options: a,
			themeName: _,
			selector: e,
			classNamesPrefix: m,
			resolvedClassNames: b,
			resolvedThemeClassNames: x,
			classes: t,
			unstyled: s,
			className: i,
			rootSelector: o,
			props: n,
			stylesCtx: r,
			withStaticClasses: h,
			headless: g,
			transformedStyles: y([a?.styles, l])
		}),
		style: wn({
			theme: p,
			selector: e,
			options: a,
			props: n,
			stylesCtx: r,
			rootSelector: o,
			withStylesTransform: v,
			resolvedStyles: S,
			resolvedThemeStyles: C,
			resolvedVars: w,
			resolvedRootStyle: T
		})
	});
}
//#endregion
//#region node_modules/@mantine/core/esm/core/InlineStyles/css-object-to-string/css-object-to-string.mjs
function Dn(e) {
	return D(e).reduce((t, n) => e[n] === void 0 ? t : `${t}${ee(n)}:${e[n]};`, "").trim();
}
//#endregion
//#region node_modules/@mantine/core/esm/core/InlineStyles/styles-to-string/styles-to-string.mjs
function On({ selector: e, styles: t, media: n, container: r }) {
	let i = t ? Dn(t) : "", a = Array.isArray(n) ? n.map((t) => `@media${t.query}{${e}{${Dn(t.styles)}}}`) : [], o = Array.isArray(r) ? r.map((t) => `@container ${t.query}{${e}{${Dn(t.styles)}}}`) : [];
	return `${i ? `${e}{${i}}` : ""}${a.join("")}${o.join("")}`.trim();
}
//#endregion
//#region node_modules/@mantine/core/esm/core/InlineStyles/InlineStyles.mjs
function kn(e) {
	let t = 5381;
	for (let n = 0; n < e.length; n++) t = (t << 5) + t + e.charCodeAt(n) & 4294967295;
	return (t >>> 0).toString(36);
}
function An({ deduplicate: e, ...t }) {
	let n = Ot(), r = On(t);
	return e ? /* @__PURE__ */ T("style", {
		href: `mantine-${kn(r)}`,
		precedence: "mantine",
		nonce: n?.(),
		children: r
	}) : /* @__PURE__ */ T("style", {
		"data-mantine-styles": "inline",
		nonce: n?.(),
		dangerouslySetInnerHTML: { __html: r }
	});
}
//#endregion
//#region node_modules/@mantine/core/esm/core/InlineStyles/hash-styles.mjs
function jn(e) {
	let t = 5381;
	for (let n = 0; n < e.length; n++) t = (t << 5) + t + e.charCodeAt(n) & 4294967295;
	return (t >>> 0).toString(36);
}
function Mn(e, t) {
	return `__mdi__-${jn(`${e ? Dn(e) : ""}|${Array.isArray(t) ? t.map((e) => `${e.query}:${Dn(e.styles)}`).join("|") : ""}`)}`;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/extract-style-props/extract-style-props.mjs
function Nn(e) {
	let { m: t, mx: n, my: r, mt: i, mb: a, ml: o, mr: s, me: c, ms: l, mis: u, mie: d, p: f, px: p, py: m, pt: h, pb: g, pl: _, pr: v, pe: y, ps: b, pis: x, pie: S, bd: C, bdrs: w, bg: T, c: E, opacity: D, ff: O, fz: k, fw: ee, lts: A, ta: j, lh: M, fs: N, tt: P, td: te, w: F, miw: I, maw: re, h: L, mih: R, mah: z, bgsz: ie, bgp: ae, bgr: oe, bga: se, pos: ce, top: le, left: B, bottom: V, right: H, inset: U, display: ue, flex: W, hiddenFrom: de, visibleFrom: fe, lightHidden: pe, darkHidden: me, sx: he, ...ge } = e;
	return {
		styleProps: ne({
			m: t,
			mx: n,
			my: r,
			mt: i,
			mb: a,
			ml: o,
			mr: s,
			me: c,
			ms: l,
			mis: u,
			mie: d,
			p: f,
			px: p,
			py: m,
			pt: h,
			pb: g,
			pl: _,
			pr: v,
			pis: x,
			pie: S,
			pe: y,
			ps: b,
			bd: C,
			bg: T,
			c: E,
			opacity: D,
			ff: O,
			fz: k,
			fw: ee,
			lts: A,
			ta: j,
			lh: M,
			fs: N,
			tt: P,
			td: te,
			w: F,
			miw: I,
			maw: re,
			h: L,
			mih: R,
			mah: z,
			bgsz: ie,
			bgp: ae,
			bgr: oe,
			bga: se,
			pos: ce,
			top: le,
			left: B,
			bottom: V,
			right: H,
			inset: U,
			display: ue,
			flex: W,
			bdrs: w,
			hiddenFrom: de,
			visibleFrom: fe,
			lightHidden: pe,
			darkHidden: me,
			sx: he
		}),
		rest: ge
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/style-props-data.mjs
var Pn = {
	m: {
		type: "spacing",
		property: "margin"
	},
	mt: {
		type: "spacing",
		property: "marginTop"
	},
	mb: {
		type: "spacing",
		property: "marginBottom"
	},
	ml: {
		type: "spacing",
		property: "marginLeft"
	},
	mr: {
		type: "spacing",
		property: "marginRight"
	},
	ms: {
		type: "spacing",
		property: "marginInlineStart"
	},
	me: {
		type: "spacing",
		property: "marginInlineEnd"
	},
	mis: {
		type: "spacing",
		property: "marginInlineStart"
	},
	mie: {
		type: "spacing",
		property: "marginInlineEnd"
	},
	mx: {
		type: "spacing",
		property: "marginInline"
	},
	my: {
		type: "spacing",
		property: "marginBlock"
	},
	p: {
		type: "spacing",
		property: "padding"
	},
	pt: {
		type: "spacing",
		property: "paddingTop"
	},
	pb: {
		type: "spacing",
		property: "paddingBottom"
	},
	pl: {
		type: "spacing",
		property: "paddingLeft"
	},
	pr: {
		type: "spacing",
		property: "paddingRight"
	},
	ps: {
		type: "spacing",
		property: "paddingInlineStart"
	},
	pe: {
		type: "spacing",
		property: "paddingInlineEnd"
	},
	pis: {
		type: "spacing",
		property: "paddingInlineStart"
	},
	pie: {
		type: "spacing",
		property: "paddingInlineEnd"
	},
	px: {
		type: "spacing",
		property: "paddingInline"
	},
	py: {
		type: "spacing",
		property: "paddingBlock"
	},
	bd: {
		type: "border",
		property: "border"
	},
	bdrs: {
		type: "radius",
		property: "borderRadius"
	},
	bg: {
		type: "color",
		property: "background"
	},
	c: {
		type: "textColor",
		property: "color"
	},
	opacity: {
		type: "identity",
		property: "opacity"
	},
	ff: {
		type: "fontFamily",
		property: "fontFamily"
	},
	fz: {
		type: "fontSize",
		property: "fontSize"
	},
	fw: {
		type: "identity",
		property: "fontWeight"
	},
	lts: {
		type: "size",
		property: "letterSpacing"
	},
	ta: {
		type: "identity",
		property: "textAlign"
	},
	lh: {
		type: "lineHeight",
		property: "lineHeight"
	},
	fs: {
		type: "identity",
		property: "fontStyle"
	},
	tt: {
		type: "identity",
		property: "textTransform"
	},
	td: {
		type: "identity",
		property: "textDecoration"
	},
	w: {
		type: "spacing",
		property: "width"
	},
	miw: {
		type: "spacing",
		property: "minWidth"
	},
	maw: {
		type: "spacing",
		property: "maxWidth"
	},
	h: {
		type: "spacing",
		property: "height"
	},
	mih: {
		type: "spacing",
		property: "minHeight"
	},
	mah: {
		type: "spacing",
		property: "maxHeight"
	},
	bgsz: {
		type: "size",
		property: "backgroundSize"
	},
	bgp: {
		type: "identity",
		property: "backgroundPosition"
	},
	bgr: {
		type: "identity",
		property: "backgroundRepeat"
	},
	bga: {
		type: "identity",
		property: "backgroundAttachment"
	},
	pos: {
		type: "identity",
		property: "position"
	},
	top: {
		type: "size",
		property: "top"
	},
	left: {
		type: "size",
		property: "left"
	},
	bottom: {
		type: "size",
		property: "bottom"
	},
	right: {
		type: "size",
		property: "right"
	},
	inset: {
		type: "size",
		property: "inset"
	},
	display: {
		type: "identity",
		property: "display"
	},
	flex: {
		type: "identity",
		property: "flex"
	}
};
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/resolvers/color-resolver/color-resolver.mjs
function Fn(e, t) {
	let n = ft({
		color: e,
		theme: t
	});
	return n.color === "dimmed" ? "var(--mantine-color-dimmed)" : n.color === "bright" ? "var(--mantine-color-bright)" : n.variable ? `var(${n.variable})` : n.color;
}
function In(e, t) {
	let n = ft({
		color: e,
		theme: t
	});
	return n.isThemeColor && n.shade === void 0 ? `var(--mantine-color-${n.color}-text)` : Fn(e, t);
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/resolvers/border-resolver/border-resolver.mjs
function Ln(e, t) {
	if (typeof e == "number") return P(e);
	if (typeof e == "string") {
		let [n, r, ...i] = e.split(" ").filter((e) => e.trim() !== ""), a = `${P(n)}`;
		return r && (a += ` ${r}`), i.length > 0 && (a += ` ${Fn(i.join(" "), t)}`), a.trim();
	}
	return e;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/resolvers/font-family-resolver/font-family-resolver.mjs
var Rn = {
	text: "var(--mantine-font-family)",
	mono: "var(--mantine-font-family-monospace)",
	monospace: "var(--mantine-font-family-monospace)",
	heading: "var(--mantine-font-family-headings)",
	headings: "var(--mantine-font-family-headings)"
};
function zn(e) {
	return typeof e == "string" && e in Rn ? Rn[e] : e;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/resolvers/font-size-resolver/font-size-resolver.mjs
var Bn = [
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6"
];
function Vn(e, t) {
	return typeof e == "string" && e in t.fontSizes ? `var(--mantine-font-size-${e})` : typeof e == "string" && Bn.includes(e) ? `var(--mantine-${e}-font-size)` : typeof e == "number" || typeof e == "string" ? P(e) : e;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/resolvers/identity-resolver/identity-resolver.mjs
function Hn(e) {
	return e;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/resolvers/line-height-resolver/line-height-resolver.mjs
var Un = [
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6"
];
function Wn(e, t) {
	return typeof e == "string" && e in t.lineHeights ? `var(--mantine-line-height-${e})` : typeof e == "string" && Un.includes(e) ? `var(--mantine-${e}-line-height)` : e;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/resolvers/radius-resolver/radius-resolver.mjs
function Gn(e, t) {
	return typeof e == "string" && e in t.radius ? `var(--mantine-radius-${e})` : typeof e == "number" || typeof e == "string" ? P(e) : e;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/resolvers/size-resolver/size-resolver.mjs
function Kn(e) {
	return typeof e == "number" ? P(e) : e;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/resolvers/spacing-resolver/spacing-resolver.mjs
function qn(e, t) {
	if (typeof e == "number") return P(e);
	if (typeof e == "string") {
		let n = e.replace("-", "");
		if (!(n in t.spacing)) return P(e);
		let r = `--mantine-spacing-${n}`;
		return e.startsWith("-") ? `calc(var(${r}) * -1)` : `var(${r})`;
	}
	return e;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/resolvers/index.mjs
var Jn = {
	color: Fn,
	textColor: In,
	fontSize: Vn,
	spacing: qn,
	radius: Gn,
	identity: Hn,
	size: Kn,
	lineHeight: Wn,
	fontFamily: zn,
	border: Ln
};
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/parse-style-props/sort-media-queries.mjs
function Yn(e) {
	return e.replace("(min-width: ", "").replace("em)", "");
}
function Xn({ media: e, ...t }) {
	let n = Object.keys(e).sort((e, t) => Number(Yn(e)) - Number(Yn(t))).map((t) => ({
		query: t,
		styles: e[t]
	}));
	return {
		...t,
		media: n
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/style-props/parse-style-props/parse-style-props.mjs
function Zn(e) {
	if (typeof e != "object" || !e) return !1;
	let t = Object.keys(e);
	return t.length !== 1 || t[0] !== "base";
}
function Qn(e) {
	return typeof e == "object" && e ? "base" in e ? e.base : void 0 : e;
}
function $n(e) {
	return typeof e == "object" && e ? D(e).filter((e) => e !== "base") : [];
}
function er(e, t) {
	return typeof e == "object" && e && t in e ? e[t] : e;
}
function tr({ styleProps: e, data: t, theme: n }) {
	return Xn(D(e).reduce((r, i) => {
		if (i === "hiddenFrom" || i === "visibleFrom" || i === "sx") return r;
		let a = t[i], o = Array.isArray(a.property) ? a.property : [a.property], s = Qn(e[i]);
		if (!Zn(e[i])) return o.forEach((e) => {
			r.inlineStyles[e] = Jn[a.type](s, n);
		}), r;
		r.hasResponsiveStyles = !0;
		let c = $n(e[i]);
		return o.forEach((t) => {
			s != null && (r.styles[t] = Jn[a.type](s, n)), c.forEach((o) => {
				let s = `(min-width: ${n.breakpoints[o]})`;
				r.media[s] = {
					...r.media[s],
					[t]: Jn[a.type](er(e[i], o), n)
				};
			});
		}), r;
	}, {
		hasResponsiveStyles: !1,
		styles: {},
		inlineStyles: {},
		media: {}
	}));
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/use-random-classname/use-random-classname.mjs
function nr() {
	return `__m__-${h().replace(/[:«»]/g, "")}`;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/get-style-object/get-style-object.mjs
function rr(e, t) {
	return Array.isArray(e) ? [...e].reduce((e, n) => ({
		...e,
		...rr(n, t)
	}), {}) : typeof e == "function" ? e(t) : e ?? {};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/factory/create-polymorphic-component.mjs
function ir(e) {
	return e;
}
var ar = ir;
//#endregion
//#region node_modules/@mantine/core/esm/core/factory/factory.mjs
function or(e) {
	return e;
}
function Y(e) {
	let t = e;
	return t.extend = or, t.withProps = (e) => {
		let n = (n) => /* @__PURE__ */ T(t, {
			...e,
			...n
		});
		return n.extend = t.extend, n.displayName = `WithProps(${t.displayName})`, n;
	}, t;
}
function sr(e) {
	return Y(e);
}
//#endregion
//#region node_modules/@mantine/core/esm/core/factory/polymorphic-factory.mjs
function cr(e) {
	let t = e;
	return t.withProps = (e) => {
		let n = (n) => /* @__PURE__ */ T(t, {
			...e,
			...n
		});
		return n.extend = t.extend, n.displayName = `WithProps(${t.displayName})`, n;
	}, t.extend = or, t;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/get-box-mod/get-box-mod.mjs
function lr(e) {
	return `data-${(e.startsWith("data-") ? e.slice(5) : e).replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase()}`;
}
function ur(e) {
	return Object.keys(e).reduce((t, n) => {
		let r = e[n];
		return r === void 0 || r === "" || r === !1 || r === null || (t[lr(n)] = e[n]), t;
	}, {});
}
function dr(e) {
	return e ? typeof e == "string" ? { [lr(e)]: !0 } : Array.isArray(e) ? [...e].reduce((e, t) => ({
		...e,
		...dr(t)
	}), {}) : ur(e) : null;
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/get-box-style/get-box-style.mjs
function fr(e, t) {
	return Array.isArray(e) ? [...e].reduce((e, n) => ({
		...e,
		...fr(n, t)
	}), {}) : typeof e == "function" ? e(t) : e ?? {};
}
function pr({ theme: e, style: t, vars: n, styleProps: r }) {
	let i = fr(t, e), a = fr(n, e);
	return {
		...i,
		...a,
		...r
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/core/Box/Box.mjs
function mr({ component: e, style: t, __vars: n, className: r, variant: i, mod: a, size: o, hiddenFrom: s, visibleFrom: c, lightHidden: l, darkHidden: u, renderRoot: d, __size: f, ref: p, ...m }) {
	let h = Xt(), g = e || "div", { styleProps: _, rest: v } = Nn(m), y = jt()?.()?.(_.sx), b = nr(), x = tr({
		styleProps: _,
		theme: h,
		data: Pn
	}), S = Pt(), C = S && x.hasResponsiveStyles ? Mn(x.styles, x.media) : b, D = {
		ref: p,
		style: pr({
			theme: h,
			style: t,
			vars: n,
			styleProps: x.inlineStyles
		}),
		className: Ye(r, y, {
			[C]: x.hasResponsiveStyles,
			"mantine-light-hidden": l,
			"mantine-dark-hidden": u,
			[`mantine-hidden-from-${s}`]: s,
			[`mantine-visible-from-${c}`]: c
		}),
		"data-variant": i,
		"data-size": F(o) ? void 0 : o || void 0,
		size: f,
		...dr(a),
		...v
	};
	return /* @__PURE__ */ E(w, { children: [x.hasResponsiveStyles && /* @__PURE__ */ T(An, {
		selector: `.${C}`,
		styles: x.styles,
		media: x.media,
		deduplicate: S
	}), typeof d == "function" ? d(D) : /* @__PURE__ */ T(g, { ...D })] });
}
mr.displayName = "@mantine/core/Box";
var X = ar(mr), hr = s({
	dir: "ltr",
	toggleDirection: () => {},
	setDirection: () => {}
});
function gr() {
	return u(hr);
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Collapse/Collapse.mjs
var _r = {
	transitionDuration: 200,
	transitionTimingFunction: "ease",
	animateOpacity: !0,
	orientation: "vertical",
	keepMounted: !0,
	keepMountedMode: "activity"
}, vr = Y((e) => {
	let { children: t, expanded: n, transitionDuration: i, transitionTimingFunction: a, style: o, onTransitionEnd: s, onTransitionStart: c, animateOpacity: l, keepMounted: u, keepMountedMode: d, ref: f, orientation: p, ...m } = q("Collapse", _r, e), h = Nt(), g = Xt(), _ = ze(), v = g.respectReducedMotion && _ ? 0 : i, y = (p === "horizontal" ? Ge : He)({
		expanded: n,
		transitionDuration: v,
		transitionTimingFunction: a,
		onTransitionEnd: s,
		onTransitionStart: c,
		keepMounted: !1
	});
	if (v === 0) return u === !0 && (d === "display-none" || h !== "test") ? d === "display-none" ? /* @__PURE__ */ T(X, {
		...m,
		style: {
			...rr(o, g),
			...n ? {} : { display: "none" }
		},
		ref: f,
		children: t
	}) : /* @__PURE__ */ T(r, {
		mode: n ? "visible" : "hidden",
		children: /* @__PURE__ */ T(X, {
			...m,
			style: o,
			ref: f,
			children: t
		})
	}) : n ? /* @__PURE__ */ T(X, {
		...m,
		style: o,
		ref: f,
		children: t
	}) : null;
	let b = y.state === "exited", x;
	return x = u === !1 ? b ? null : t : u === !0 ? d === "display-none" ? t : /* @__PURE__ */ T(r, {
		mode: b ? "hidden" : "visible",
		children: t
	}) : t, /* @__PURE__ */ T(X, {
		...m,
		...y.getCollapseProps({
			style: {
				opacity: n || !l ? 1 : 0,
				transition: l ? `opacity ${v}ms ${a}` : "none",
				...rr(o, g),
				...u && d === "display-none" && b ? { display: "none" } : {}
			},
			ref: f
		}),
		children: x
	});
});
vr.displayName = "@mantine/core/Collapse";
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollArea.context.mjs
var [yr, br] = re("ScrollArea.Root component was not found in tree");
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/use-resize-observer.mjs
function xr(e, t) {
	let n = m(t);
	xe(() => {
		let t = 0;
		if (e) {
			let r = new ResizeObserver(() => {
				cancelAnimationFrame(t), t = window.requestAnimationFrame(n);
			});
			return r.observe(e), () => {
				window.cancelAnimationFrame(t), r.unobserve(e);
			};
		}
	}, [e]);
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaCorner/ScrollAreaCorner.mjs
function Sr(e) {
	let { style: t, ...n } = e, r = br(), [i, a] = y(0), [o, s] = y(0), c = !!(i && o);
	return xr(r.scrollbarX, () => {
		let e = r.scrollbarX?.offsetHeight || 0;
		r.onCornerHeightChange(e), s(e);
	}), xr(r.scrollbarY, () => {
		let e = r.scrollbarY?.offsetWidth || 0;
		r.onCornerWidthChange(e), a(e);
	}), c ? /* @__PURE__ */ T("div", {
		...n,
		style: {
			...t,
			width: i,
			height: o
		}
	}) : null;
}
function Cr(e) {
	let t = br(), n = !!(t.scrollbarX && t.scrollbarY);
	return t.type !== "scroll" && n ? /* @__PURE__ */ T(Sr, { ...e }) : null;
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaRoot/ScrollAreaRoot.mjs
var wr = {
	scrollHideDelay: 1e3,
	type: "hover"
};
function Tr(e) {
	let { type: t, scrollHideDelay: n, scrollbars: r, getStyles: i, ref: a, ...o } = q("ScrollAreaRoot", wr, e), [s, c] = y(null), [l, u] = y(null), [d, f] = y(null), [p, m] = y(null), [h, g] = y(null), [_, v] = y(0), [b, x] = y(0), [S, C] = y(!1), [w, E] = y(!1), D = Le(a, c);
	return /* @__PURE__ */ T(yr, {
		value: {
			type: t,
			scrollHideDelay: n,
			scrollArea: s,
			viewport: l,
			onViewportChange: u,
			content: d,
			onContentChange: f,
			scrollbarX: p,
			onScrollbarXChange: m,
			scrollbarXEnabled: S,
			onScrollbarXEnabledChange: C,
			scrollbarY: h,
			onScrollbarYChange: g,
			scrollbarYEnabled: w,
			onScrollbarYEnabledChange: E,
			onCornerWidthChange: v,
			onCornerHeightChange: x,
			getStyles: i
		},
		children: /* @__PURE__ */ T(X, {
			...o,
			ref: D,
			__vars: {
				"--sa-corner-width": r === "xy" ? `${_}px` : "0px",
				"--sa-corner-height": r === "xy" ? `${b}px` : "0px"
			}
		})
	});
}
Tr.displayName = "@mantine/core/ScrollAreaRoot";
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/utils/get-thumb-ratio.mjs
function Er(e, t) {
	let n = e / t;
	return Number.isNaN(n) ? 0 : n;
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/utils/get-thumb-size.mjs
function Dr(e) {
	let t = Er(e.viewport, e.content), n = e.scrollbar.paddingStart + e.scrollbar.paddingEnd, r = (e.scrollbar.size - n) * t;
	return Math.max(r, 18);
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/utils/linear-scale.mjs
function Or(e, t) {
	return (n) => {
		if (e[0] === e[1] || t[0] === t[1]) return t[0];
		let r = (t[1] - t[0]) / (e[1] - e[0]);
		return t[0] + r * (n - e[0]);
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/utils/get-thumb-offset-from-scroll.mjs
function kr(e, [t, n]) {
	return Math.min(n, Math.max(t, e));
}
function Ar(e, t, n = "ltr") {
	let r = Dr(t), i = t.scrollbar.paddingStart + t.scrollbar.paddingEnd, a = t.scrollbar.size - i, o = t.content - t.viewport, s = a - r, c = kr(e, n === "ltr" ? [0, o] : [o * -1, 0]);
	return Or([0, o], [0, s])(c);
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/utils/get-scroll-position-from-pointer.mjs
function jr(e, t, n, r = "ltr") {
	let i = Dr(n), a = i / 2, o = t || a, s = i - o, c = n.scrollbar.paddingStart + o, l = n.scrollbar.size - n.scrollbar.paddingEnd - s, u = n.content - n.viewport, d = r === "ltr" ? [0, u] : [u * -1, 0];
	return Or([c, l], d)(e);
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/utils/is-scrolling-within-scrollbar-bounds.mjs
function Mr(e, t) {
	return e > 0 && e < t;
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/utils/to-int.mjs
function Nr(e) {
	return e ? parseInt(e, 10) : 0;
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/utils/compose-event-handlers.mjs
function Pr(e, t, { checkForDefaultPrevented: n = !0 } = {}) {
	return (r) => {
		e?.(r), (n === !1 || !r.defaultPrevented) && t?.(r);
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/Scrollbar.context.mjs
var [Fr, Ir] = re("ScrollAreaScrollbar was not found in tree");
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/Scrollbar.mjs
function Lr(e) {
	let { sizes: t, hasThumb: n, onThumbChange: r, onThumbPointerUp: i, onThumbPointerDown: a, onThumbPositionChange: o, onDragScroll: s, onWheelScroll: c, onResize: l, ref: u, ...d } = e, f = br(), [h, g] = y(null), _ = Le(u, g), b = v(null), x = v(""), { viewport: S } = f, C = t.content - t.viewport, w = m(c), E = ge(o), D = _e(l, 10), O = (e) => {
		if (b.current) {
			let t = e.clientX - b.current.left, n = e.clientY - b.current.top;
			s({
				x: t,
				y: n
			});
		}
	};
	return p(() => {
		let e = (e) => {
			let t = e.target;
			h?.contains(t) && w(e, C);
		};
		return document.addEventListener("wheel", e, { passive: !1 }), () => document.removeEventListener("wheel", e, { passive: !1 });
	}, [
		S,
		h,
		C
	]), p(E, [t, E]), xr(h, D), xr(f.content, D), /* @__PURE__ */ T(Fr, {
		value: {
			scrollbar: h,
			hasThumb: n,
			onThumbChange: ge(r),
			onThumbPointerUp: ge(i),
			onThumbPositionChange: E,
			onThumbPointerDown: ge(a)
		},
		children: /* @__PURE__ */ T("div", {
			...d,
			ref: _,
			"data-mantine-scrollbar": !0,
			style: {
				position: "absolute",
				...d.style
			},
			onPointerDown: Pr(e.onPointerDown, (e) => {
				e.preventDefault(), e.button === 0 && (e.target.setPointerCapture(e.pointerId), b.current = h.getBoundingClientRect(), x.current = document.body.style.webkitUserSelect, document.body.style.webkitUserSelect = "none", O(e));
			}),
			onPointerMove: Pr(e.onPointerMove, O),
			onPointerUp: Pr(e.onPointerUp, (e) => {
				let t = e.target;
				t.hasPointerCapture(e.pointerId) && (e.preventDefault(), t.releasePointerCapture(e.pointerId));
			}),
			onLostPointerCapture: () => {
				document.body.style.webkitUserSelect = x.current, b.current = null;
			}
		})
	});
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/ScrollbarX.mjs
var Rr = (e) => {
	let { sizes: t, onSizesChange: n, style: r, ref: i, ...a } = e, o = br(), [s, c] = y(), l = v(null), u = Le(i, l, o.onScrollbarXChange);
	return p(() => {
		l.current && c(getComputedStyle(l.current));
	}, [l]), /* @__PURE__ */ T(Lr, {
		"data-orientation": "horizontal",
		...a,
		ref: u,
		sizes: t,
		style: {
			...r,
			"--sa-thumb-width": `${Dr(t)}px`
		},
		onThumbPointerDown: (t) => e.onThumbPointerDown(t.x),
		onDragScroll: (t) => e.onDragScroll(t.x),
		onWheelScroll: (t, n) => {
			if (o.viewport) {
				let r = o.viewport.scrollLeft + t.deltaX;
				e.onWheelScroll(r), Mr(r, n) && t.preventDefault();
			}
		},
		onResize: () => {
			l.current && o.viewport && s && n({
				content: o.viewport.scrollWidth,
				viewport: o.viewport.offsetWidth,
				scrollbar: {
					size: l.current.clientWidth,
					paddingStart: Nr(s.paddingLeft),
					paddingEnd: Nr(s.paddingRight)
				}
			});
		}
	});
};
Rr.displayName = "@mantine/core/ScrollAreaScrollbarX";
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/ScrollbarY.mjs
function zr(e) {
	let { sizes: t, onSizesChange: n, style: r, ref: i, ...a } = e, o = br(), [s, c] = y(), l = v(null), u = Le(i, l, o.onScrollbarYChange);
	return p(() => {
		l.current && c(window.getComputedStyle(l.current));
	}, []), /* @__PURE__ */ T(Lr, {
		...a,
		"data-orientation": "vertical",
		ref: u,
		sizes: t,
		style: {
			"--sa-thumb-height": `${Dr(t)}px`,
			...r
		},
		onThumbPointerDown: (t) => e.onThumbPointerDown(t.y),
		onDragScroll: (t) => e.onDragScroll(t.y),
		onWheelScroll: (t, n) => {
			if (o.viewport) {
				let r = o.viewport.scrollTop + t.deltaY;
				e.onWheelScroll(r), Mr(r, n) && t.preventDefault();
			}
		},
		onResize: () => {
			l.current && o.viewport && s && n({
				content: o.viewport.scrollHeight,
				viewport: o.viewport.offsetHeight,
				scrollbar: {
					size: l.current.clientHeight,
					paddingStart: Nr(s.paddingTop),
					paddingEnd: Nr(s.paddingBottom)
				}
			});
		}
	});
}
zr.displayName = "@mantine/core/ScrollAreaScrollbarY";
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/ScrollAreaScrollbarVisible.mjs
function Br(e) {
	let { orientation: t = "vertical", ...n } = e, { dir: r } = gr(), i = br(), a = v(null), o = v(0), [s, c] = y({
		content: 0,
		viewport: 0,
		scrollbar: {
			size: 0,
			paddingStart: 0,
			paddingEnd: 0
		}
	}), l = Er(s.viewport, s.content), u = {
		...n,
		sizes: s,
		onSizesChange: c,
		hasThumb: l > 0 && l < 1,
		onThumbChange: (e) => {
			a.current = e;
		},
		onThumbPointerUp: () => {
			o.current = 0;
		},
		onThumbPointerDown: (e) => {
			o.current = e;
		}
	}, d = (e, t) => jr(e, o.current, s, t);
	return t === "horizontal" ? /* @__PURE__ */ T(Rr, {
		...u,
		onThumbPositionChange: () => {
			if (i.viewport && a.current) {
				let e = i.viewport.scrollLeft, t = Ar(e, s, r);
				a.current.style.transform = `translate3d(${t}px, 0, 0)`;
			}
		},
		onWheelScroll: (e) => {
			i.viewport && (i.viewport.scrollLeft = e);
		},
		onDragScroll: (e) => {
			i.viewport && (i.viewport.scrollLeft = d(e, r));
		}
	}) : t === "vertical" ? /* @__PURE__ */ T(zr, {
		...u,
		onThumbPositionChange: () => {
			if (i.viewport && a.current) {
				let e = i.viewport.scrollTop, t = Ar(e, s);
				s.scrollbar.size === 0 ? a.current.style.setProperty("--thumb-opacity", "0") : a.current.style.setProperty("--thumb-opacity", "1"), a.current.style.transform = `translate3d(0, ${t}px, 0)`;
			}
		},
		onWheelScroll: (e) => {
			i.viewport && (i.viewport.scrollTop = e);
		},
		onDragScroll: (e) => {
			i.viewport && (i.viewport.scrollTop = d(e));
		}
	}) : null;
}
Br.displayName = "@mantine/core/ScrollAreaScrollbarVisible";
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/ScrollAreaScrollbarAuto.mjs
function Vr(e) {
	let t = br(), { forceMount: n, ...r } = e, [i, a] = y(!1), o = e.orientation === "horizontal", s = _e(() => {
		if (t.viewport) {
			let e = t.viewport.offsetWidth < t.viewport.scrollWidth, n = t.viewport.offsetHeight < t.viewport.scrollHeight;
			a(o ? e : n);
		}
	}, 10);
	return xr(t.viewport, s), xr(t.content, s), n || i ? /* @__PURE__ */ T(Br, {
		"data-state": i ? "visible" : "hidden",
		...r
	}) : null;
}
Vr.displayName = "@mantine/core/ScrollAreaScrollbarAuto";
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/ScrollAreaScrollbarHover.mjs
function Hr(e) {
	let { forceMount: t, ...n } = e, r = br(), [i, a] = y(!1);
	return p(() => {
		let { scrollArea: e } = r, t = 0;
		if (e) {
			let n = () => {
				window.clearTimeout(t), a(!0);
			}, i = () => {
				t = window.setTimeout(() => a(!1), r.scrollHideDelay);
			};
			return e.addEventListener("pointerenter", n), e.addEventListener("pointerleave", i), () => {
				window.clearTimeout(t), e.removeEventListener("pointerenter", n), e.removeEventListener("pointerleave", i);
			};
		}
	}, [r.scrollArea, r.scrollHideDelay]), t || i ? /* @__PURE__ */ T(Vr, {
		"data-state": i ? "visible" : "hidden",
		...n
	}) : null;
}
Hr.displayName = "@mantine/core/ScrollAreaScrollbarHover";
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/ScrollAreaScrollbarScroll.mjs
function Ur(e) {
	let { forceMount: t, ...n } = e, r = br(), i = e.orientation === "horizontal", [a, o] = y("hidden"), s = _e(() => o("idle"), 100);
	return p(() => {
		if (a === "idle") {
			let e = window.setTimeout(() => o("hidden"), r.scrollHideDelay);
			return () => window.clearTimeout(e);
		}
	}, [a, r.scrollHideDelay]), p(() => {
		let { viewport: e } = r, t = i ? "scrollLeft" : "scrollTop";
		if (e) {
			let n = e[t], r = () => {
				let r = e[t];
				n !== r && (o("scrolling"), s()), n = r;
			};
			return e.addEventListener("scroll", r), () => e.removeEventListener("scroll", r);
		}
	}, [
		r.viewport,
		i,
		s
	]), t || a !== "hidden" ? /* @__PURE__ */ T(Br, {
		"data-state": a === "hidden" ? "hidden" : "visible",
		...n,
		onPointerEnter: Pr(e.onPointerEnter, () => o("interacting")),
		onPointerLeave: Pr(e.onPointerLeave, () => o("idle"))
	}) : null;
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaScrollbar/ScrollAreaScrollbar.mjs
function Wr(e) {
	let { forceMount: t, ...n } = e, r = br(), { onScrollbarXEnabledChange: i, onScrollbarYEnabledChange: a } = r, o = e.orientation === "horizontal";
	return p(() => (o ? i(!0) : a(!0), () => {
		o ? i(!1) : a(!1);
	}), [
		o,
		i,
		a
	]), r.type === "hover" ? /* @__PURE__ */ T(Hr, {
		...n,
		forceMount: t
	}) : r.type === "scroll" ? /* @__PURE__ */ T(Ur, {
		...n,
		forceMount: t
	}) : r.type === "auto" ? /* @__PURE__ */ T(Vr, {
		...n,
		forceMount: t
	}) : r.type === "always" ? /* @__PURE__ */ T(Br, { ...n }) : null;
}
Wr.displayName = "@mantine/core/ScrollAreaScrollbar";
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/utils/add-unlinked-scroll-listener.mjs
function Gr(e, t = () => {}) {
	let n = {
		left: e.scrollLeft,
		top: e.scrollTop
	}, r = 0;
	return (function i() {
		let a = {
			left: e.scrollLeft,
			top: e.scrollTop
		}, o = n.left !== a.left, s = n.top !== a.top;
		(o || s) && t(), n = a, r = window.requestAnimationFrame(i);
	})(), () => window.cancelAnimationFrame(r);
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaThumb/ScrollAreaThumb.mjs
function Kr(e) {
	let { style: t, ref: n, ...r } = e, i = br(), a = Ir(), { onThumbPositionChange: o } = a, s = Le(n, a.onThumbChange), c = v(void 0), l = _e(() => {
		c.current &&= (c.current(), void 0);
	}, 100);
	return p(() => {
		let { viewport: e } = i;
		if (e) {
			let t = () => {
				if (l(), !c.current) {
					let t = Gr(e, o);
					c.current = t, o();
				}
			};
			return o(), e.addEventListener("scroll", t), () => e.removeEventListener("scroll", t);
		}
	}, [
		i.viewport,
		l,
		o
	]), /* @__PURE__ */ T("div", {
		"data-state": a.hasThumb ? "visible" : "hidden",
		...r,
		ref: s,
		style: {
			width: "var(--sa-thumb-width)",
			height: "var(--sa-thumb-height)",
			...t
		},
		onPointerDownCapture: Pr(e.onPointerDownCapture, (e) => {
			let t = e.target.getBoundingClientRect(), n = e.clientX - t.left, r = e.clientY - t.top;
			a.onThumbPointerDown({
				x: n,
				y: r
			});
		}),
		onPointerUp: Pr(e.onPointerUp, a.onThumbPointerUp)
	});
}
Kr.displayName = "@mantine/core/ScrollAreaThumb";
function qr(e) {
	let { forceMount: t, ...n } = e, r = Ir();
	return t || r.hasThumb ? /* @__PURE__ */ T(Kr, { ...n }) : null;
}
qr.displayName = "@mantine/core/ScrollAreaThumb";
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollAreaViewport/ScrollAreaViewport.mjs
function Jr({ children: e, style: t, ref: n, onWheel: r, ...i }) {
	let a = br(), o = Le(n, a.onViewportChange), s = (e) => {
		if (r?.(e), a.scrollbarXEnabled && a.viewport && e.shiftKey) {
			let { scrollTop: t, scrollHeight: n, clientHeight: r, scrollWidth: i, clientWidth: o } = a.viewport, s = t < 1, c = t >= n - r - 1;
			i > o && (s || c) && e.stopPropagation();
		}
	};
	return /* @__PURE__ */ T(X, {
		...i,
		ref: o,
		onWheel: s,
		"data-scrollarea-viewport": !0,
		style: {
			overflowX: a.scrollbarXEnabled ? "scroll" : "hidden",
			overflowY: a.scrollbarYEnabled ? "scroll" : "hidden",
			...t
		},
		children: /* @__PURE__ */ T("div", {
			...a.getStyles("content"),
			ref: a.onContentChange,
			children: e
		})
	});
}
Jr.displayName = "@mantine/core/ScrollAreaViewport";
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollArea.module.mjs
var Yr = {
	root: "m_d57069b5",
	content: "m_b1336c6",
	viewport: "m_c0783ff9",
	viewportInner: "m_f8f631dd",
	scrollbar: "m_c44ba933",
	thumb: "m_d8b5e363",
	corner: "m_21657268"
};
({ ...t }).useInsertionEffect;
//#endregion
//#region node_modules/@floating-ui/react/dist/floating-ui.react.mjs
function Xr(e) {
	let n = t.useRef(void 0), r = t.useCallback((t) => {
		let n = e.map((e) => {
			if (e != null) {
				if (typeof e == "function") {
					let n = e, r = n(t);
					return typeof r == "function" ? r : () => {
						n(null);
					};
				}
				return e.current = t, () => {
					e.current = null;
				};
			}
		});
		return () => {
			n.forEach((e) => e?.());
		};
	}, e);
	return t.useMemo(() => e.every((e) => e == null) ? null : (e) => {
		n.current &&= (n.current(), void 0), e != null && (n.current = r(e));
	}, e);
}
var Zr = "ArrowLeft", Qr = "ArrowRight", $r = "ArrowUp", ei = "ArrowDown", ti = [Zr, Qr], ni = [$r, ei];
[...ti, ...ni], { ...t }.useId, process.env.NODE_ENV;
//#endregion
//#region node_modules/@mantine/core/esm/components/ScrollArea/ScrollArea.mjs
var ri = {
	scrollHideDelay: 1e3,
	type: "hover",
	scrollbars: "xy"
}, ii = K((e, { scrollbarSize: t, overscrollBehavior: n, scrollbars: r }) => {
	let i = n;
	return n && r && (r === "x" ? i = `${n} auto` : r === "y" && (i = `auto ${n}`)), { root: {
		"--scrollarea-scrollbar-size": P(t),
		"--scrollarea-over-scroll-behavior": i
	} };
}), ai = Y((e) => {
	let t = q("ScrollArea", ri, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, scrollbarSize: s, vars: c, type: l, scrollHideDelay: u, viewportProps: f, viewportRef: p, onScrollPositionChange: m, children: h, offsetScrollbars: g, scrollbars: _, onBottomReached: b, onTopReached: x, onLeftReached: S, onRightReached: C, overscrollBehavior: w, startScrollPosition: D, verticalScrollbarPosition: O, attributes: k, ...ee } = t, [A, j] = y(!1), [M, N] = y(!1), [P, te] = y(!1), ne = v(!0), F = v(!1), I = v(!0), re = v(!1), L = J({
		name: "ScrollArea",
		props: t,
		classes: Yr,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: k,
		vars: c,
		varsResolver: ii
	}), R = v(null), [z, ie] = y(null), ae = Xr([
		p,
		R,
		d((e) => {
			ie((t) => t === e ? t : e);
		}, [])
	]);
	return xr(g === "present" ? z : null, () => {
		let e = R.current;
		e && (N(e.scrollHeight > e.clientHeight), te(e.scrollWidth > e.clientWidth));
	}), xe(() => {
		D && R.current && R.current.scrollTo({
			left: D.x ?? 0,
			top: D.y ?? 0
		});
	}, []), /* @__PURE__ */ E(Tr, {
		getStyles: L,
		type: l === "never" ? "always" : l,
		scrollHideDelay: u,
		scrollbars: _,
		...L("root"),
		...ee,
		children: [
			/* @__PURE__ */ T(Jr, {
				...f,
				...L("viewport", { style: f?.style }),
				ref: ae,
				"data-offset-scrollbars": g === !0 ? "xy" : g || void 0,
				"data-scrollbars": _ || void 0,
				"data-vertical-scrollbar-position": O || void 0,
				"data-horizontal-hidden": g === "present" && !P ? "true" : void 0,
				"data-vertical-hidden": g === "present" && !M ? "true" : void 0,
				onScroll: (e) => {
					f?.onScroll?.(e), m?.({
						x: e.currentTarget.scrollLeft,
						y: e.currentTarget.scrollTop
					});
					let { scrollTop: t, scrollHeight: n, clientHeight: r, scrollLeft: i, scrollWidth: a, clientWidth: o } = e.currentTarget, s = t - (n - r) >= -.8, c = t === 0;
					s && !F.current && b?.(), c && !ne.current && x?.(), F.current = s, ne.current = c;
					let l = i - (a - o) >= -.8, u = i === 0;
					l && !re.current && C?.(), u && !I.current && S?.(), re.current = l, I.current = u;
				},
				children: h
			}),
			(_ === "xy" || _ === "x") && /* @__PURE__ */ T(Wr, {
				...L("scrollbar"),
				orientation: "horizontal",
				"data-vertical-scrollbar-position": O || void 0,
				"data-hidden": l === "never" || g === "present" && !P || void 0,
				forceMount: !0,
				onMouseEnter: () => j(!0),
				onMouseLeave: () => j(!1),
				children: /* @__PURE__ */ T(qr, { ...L("thumb") })
			}),
			(_ === "xy" || _ === "y") && /* @__PURE__ */ T(Wr, {
				...L("scrollbar"),
				orientation: "vertical",
				"data-vertical-scrollbar-position": O || void 0,
				"data-hidden": l === "never" || g === "present" && !M || void 0,
				forceMount: !0,
				onMouseEnter: () => j(!0),
				onMouseLeave: () => j(!1),
				children: /* @__PURE__ */ T(qr, { ...L("thumb") })
			}),
			/* @__PURE__ */ T(Cr, {
				...L("corner"),
				"data-vertical-scrollbar-position": O || void 0,
				"data-hovered": A || void 0,
				"data-hidden": l === "never" || void 0
			})
		]
	});
});
ai.displayName = "@mantine/core/ScrollArea";
var oi = Y((e) => {
	let { children: t, classNames: n, styles: r, scrollbarSize: i, scrollHideDelay: a, type: o, dir: s, offsetScrollbars: c, overscrollBehavior: l, viewportRef: u, onScrollPositionChange: f, unstyled: p, variant: h, viewportProps: g, scrollbars: _, style: b, vars: x, onBottomReached: S, onTopReached: C, startScrollPosition: w, verticalScrollbarPosition: E, onOverflowChange: D, ...O } = q("ScrollAreaAutosize", ri, e), k = v(null), [ee, A] = y(null), j = Xr([
		u,
		k,
		d((e) => {
			A((t) => t === e ? t : e);
		}, [])
	]), M = v(!1), N = v(!1), P = m(() => {
		let e = k.current;
		if (!e || !D) return;
		let t = e.scrollHeight > e.clientHeight;
		t !== M.current && (N.current ? D(t) : (N.current = !0, t && D(!0)), M.current = t);
	});
	return xr(D ? ee : null, P), /* @__PURE__ */ T(X, {
		...O,
		variant: h,
		style: [{
			display: "flex",
			overflow: "hidden"
		}, b],
		children: /* @__PURE__ */ T(X, {
			style: {
				display: "flex",
				flexDirection: "column",
				flex: 1,
				overflow: "hidden",
				..._ === "y" && { minWidth: 0 },
				..._ === "x" && { minHeight: 0 },
				..._ === "xy" && {
					minWidth: 0,
					minHeight: 0
				},
				..._ === !1 && {
					minWidth: 0,
					minHeight: 0
				}
			},
			children: /* @__PURE__ */ T(ai, {
				classNames: n,
				styles: r,
				scrollHideDelay: a,
				scrollbarSize: i,
				type: o,
				dir: s,
				offsetScrollbars: c,
				overscrollBehavior: l,
				viewportRef: j,
				onScrollPositionChange: f,
				unstyled: p,
				variant: h,
				viewportProps: g,
				vars: x,
				scrollbars: _,
				onBottomReached: S,
				onTopReached: C,
				startScrollPosition: w,
				verticalScrollbarPosition: E,
				"data-autosize": "true",
				children: t
			})
		})
	});
});
ai.classes = Yr, ai.varsResolver = ii, oi.displayName = "@mantine/core/ScrollAreaAutosize", oi.classes = Yr, ai.Autosize = oi;
//#endregion
//#region node_modules/@mantine/core/esm/components/UnstyledButton/UnstyledButton.module.mjs
var si = { root: "m_87cf2631" }, ci = { __staticSelector: "UnstyledButton" }, li = cr((e) => {
	let t = q("UnstyledButton", ci, e), { className: n, component: r = "button", __staticSelector: i, unstyled: a, classNames: o, styles: s, style: c, attributes: l, ...u } = t, d = J({
		name: i,
		props: t,
		classes: si,
		className: n,
		style: c,
		classNames: o,
		styles: s,
		unstyled: a,
		attributes: l
	});
	return /* @__PURE__ */ T(X, {
		...d("root", { focusable: !0 }),
		component: r,
		type: r === "button" ? "button" : void 0,
		...u
	});
});
li.classes = si, li.displayName = "@mantine/core/UnstyledButton";
//#endregion
//#region node_modules/@mantine/core/esm/components/VisuallyHidden/VisuallyHidden.module.mjs
var ui = { root: "m_515a97f8" }, di = Y((e) => {
	let t = q("VisuallyHidden", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, attributes: c, ...l } = t, u = J({
		name: "VisuallyHidden",
		classes: ui,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: c
	});
	return /* @__PURE__ */ T(X, {
		component: "span",
		...u("root"),
		...l
	});
});
di.classes = ui, di.displayName = "@mantine/core/VisuallyHidden";
//#endregion
//#region node_modules/@mantine/core/esm/components/Paper/Paper.module.mjs
var fi = { root: "m_1b7284a3" }, pi = K((e, { radius: t, shadow: n }) => ({ root: {
	"--paper-radius": t === void 0 ? void 0 : H(t),
	"--paper-shadow": W(n)
} })), mi = cr((e) => {
	let t = q("Paper", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, withBorder: s, vars: c, radius: l, shadow: u, variant: d, mod: f, attributes: p, ...m } = t, h = J({
		name: "Paper",
		props: t,
		classes: fi,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: p,
		vars: c,
		varsResolver: pi
	});
	return /* @__PURE__ */ T(X, {
		mod: [{ withBorder: s }, f],
		...h("root"),
		variant: d,
		...m
	});
});
mi.classes = fi, mi.varsResolver = pi, mi.displayName = "@mantine/core/Paper";
//#endregion
//#region node_modules/@mantine/core/esm/components/Overlay/Overlay.module.mjs
var hi = { root: "m_9814e45f" }, gi = { zIndex: ce("modal") }, _i = K((e, { gradient: t, color: n, backgroundOpacity: r, blur: i, radius: a, zIndex: o }) => ({ root: {
	"--overlay-bg": t || (n !== void 0 || r !== void 0) && _t(n || "#000", r ?? .6) || void 0,
	"--overlay-filter": i ? `blur(${P(i)})` : void 0,
	"--overlay-radius": a === void 0 ? void 0 : H(a),
	"--overlay-z-index": o?.toString()
} })), vi = cr((e) => {
	let t = q("Overlay", gi, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, fixed: c, center: l, children: u, radius: d, zIndex: f, gradient: p, blur: m, color: h, backgroundOpacity: g, mod: _, attributes: v, ...y } = t, b = J({
		name: "Overlay",
		props: t,
		classes: hi,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: v,
		vars: s,
		varsResolver: _i
	});
	return /* @__PURE__ */ T(X, {
		...b("root"),
		mod: [{
			center: l,
			fixed: c
		}, _],
		...y,
		children: u
	});
});
vi.classes = hi, vi.varsResolver = _i, vi.displayName = "@mantine/core/Overlay";
//#endregion
//#region node_modules/@mantine/core/esm/components/Portal/Portal.mjs
function yi(e) {
	let t = document.createElement("div");
	return t.setAttribute("data-portal", "true"), typeof e.className == "string" && t.classList.add(...e.className.split(" ").filter(Boolean)), typeof e.style == "object" && Object.assign(t.style, e.style), typeof e.id == "string" && t.setAttribute("id", e.id), t;
}
function bi({ target: e, reuseTargetNode: t, ...n }) {
	if (e) return typeof e == "string" ? document.querySelector(e) || yi(n) : e;
	if (t) {
		let e = document.querySelector("[data-mantine-shared-portal-node]");
		if (e) return e;
		let t = yi(n);
		return t.setAttribute("data-mantine-shared-portal-node", "true"), document.body.appendChild(t), t;
	}
	return yi(n);
}
var xi = { reuseTargetNode: !0 }, Si = Y((e) => {
	let { children: t, target: n, reuseTargetNode: r, ref: i, ...a } = q("Portal", xi, e), [o, s] = y(!1), c = v(null);
	return xe(() => (s(!0), c.current = bi({
		target: n,
		reuseTargetNode: r,
		...a
	}), Fe(i, c.current), !n && !r && c.current && document.body.appendChild(c.current), () => {
		!n && !r && c.current && document.body.removeChild(c.current);
	}), [n]), !o || !c.current ? null : S(/* @__PURE__ */ T(w, { children: t }), c.current);
});
Si.displayName = "@mantine/core/Portal";
//#endregion
//#region node_modules/@mantine/core/esm/components/Portal/OptionalPortal.mjs
var Ci = Y(({ withinPortal: e = !0, children: t, ...n }) => Nt() === "test" || !e ? /* @__PURE__ */ T(w, { children: t }) : /* @__PURE__ */ T(Si, {
	...n,
	children: t
}));
Ci.displayName = "@mantine/core/OptionalPortal";
//#endregion
//#region node_modules/@mantine/core/esm/components/Transition/transitions.mjs
var wi = (e) => ({
	in: {
		opacity: 1,
		transform: "scale(1)"
	},
	out: {
		opacity: 0,
		transform: `scale(.9) translateY(${e === "bottom" ? 10 : -10}px)`
	},
	transitionProperty: "transform, opacity"
}), Ti = {
	fade: {
		in: { opacity: 1 },
		out: { opacity: 0 },
		transitionProperty: "opacity"
	},
	"fade-up": {
		in: {
			opacity: 1,
			transform: "translateY(0)"
		},
		out: {
			opacity: 0,
			transform: "translateY(30px)"
		},
		transitionProperty: "opacity, transform"
	},
	"fade-down": {
		in: {
			opacity: 1,
			transform: "translateY(0)"
		},
		out: {
			opacity: 0,
			transform: "translateY(-30px)"
		},
		transitionProperty: "opacity, transform"
	},
	"fade-left": {
		in: {
			opacity: 1,
			transform: "translateX(0)"
		},
		out: {
			opacity: 0,
			transform: "translateX(30px)"
		},
		transitionProperty: "opacity, transform"
	},
	"fade-right": {
		in: {
			opacity: 1,
			transform: "translateX(0)"
		},
		out: {
			opacity: 0,
			transform: "translateX(-30px)"
		},
		transitionProperty: "opacity, transform"
	},
	scale: {
		in: {
			opacity: 1,
			transform: "scale(1)"
		},
		out: {
			opacity: 0,
			transform: "scale(0)"
		},
		common: { transformOrigin: "top" },
		transitionProperty: "transform, opacity"
	},
	"scale-y": {
		in: {
			opacity: 1,
			transform: "scaleY(1)"
		},
		out: {
			opacity: 0,
			transform: "scaleY(0)"
		},
		common: { transformOrigin: "top" },
		transitionProperty: "transform, opacity"
	},
	"scale-x": {
		in: {
			opacity: 1,
			transform: "scaleX(1)"
		},
		out: {
			opacity: 0,
			transform: "scaleX(0)"
		},
		common: { transformOrigin: "left" },
		transitionProperty: "transform, opacity"
	},
	"skew-up": {
		in: {
			opacity: 1,
			transform: "translateY(0) skew(0deg, 0deg)"
		},
		out: {
			opacity: 0,
			transform: "translateY(-20px) skew(-10deg, -5deg)"
		},
		common: { transformOrigin: "top" },
		transitionProperty: "transform, opacity"
	},
	"skew-down": {
		in: {
			opacity: 1,
			transform: "translateY(0) skew(0deg, 0deg)"
		},
		out: {
			opacity: 0,
			transform: "translateY(20px) skew(-10deg, -5deg)"
		},
		common: { transformOrigin: "bottom" },
		transitionProperty: "transform, opacity"
	},
	"rotate-left": {
		in: {
			opacity: 1,
			transform: "translateY(0) rotate(0deg)"
		},
		out: {
			opacity: 0,
			transform: "translateY(20px) rotate(-5deg)"
		},
		common: { transformOrigin: "bottom" },
		transitionProperty: "transform, opacity"
	},
	"rotate-right": {
		in: {
			opacity: 1,
			transform: "translateY(0) rotate(0deg)"
		},
		out: {
			opacity: 0,
			transform: "translateY(20px) rotate(5deg)"
		},
		common: { transformOrigin: "top" },
		transitionProperty: "transform, opacity"
	},
	"slide-down": {
		in: {
			opacity: 1,
			transform: "translateY(0)"
		},
		out: {
			opacity: 0,
			transform: "translateY(-100%)"
		},
		common: { transformOrigin: "top" },
		transitionProperty: "transform, opacity"
	},
	"slide-up": {
		in: {
			opacity: 1,
			transform: "translateY(0)"
		},
		out: {
			opacity: 0,
			transform: "translateY(100%)"
		},
		common: { transformOrigin: "bottom" },
		transitionProperty: "transform, opacity"
	},
	"slide-left": {
		in: {
			opacity: 1,
			transform: "translateX(0)"
		},
		out: {
			opacity: 0,
			transform: "translateX(100%)"
		},
		common: { transformOrigin: "left" },
		transitionProperty: "transform, opacity"
	},
	"slide-right": {
		in: {
			opacity: 1,
			transform: "translateX(0)"
		},
		out: {
			opacity: 0,
			transform: "translateX(-100%)"
		},
		common: { transformOrigin: "right" },
		transitionProperty: "transform, opacity"
	},
	pop: {
		...wi("bottom"),
		common: { transformOrigin: "center center" }
	},
	"pop-bottom-left": {
		...wi("bottom"),
		common: { transformOrigin: "bottom left" }
	},
	"pop-bottom-right": {
		...wi("bottom"),
		common: { transformOrigin: "bottom right" }
	},
	"pop-top-left": {
		...wi("top"),
		common: { transformOrigin: "top left" }
	},
	"pop-top-right": {
		...wi("top"),
		common: { transformOrigin: "top right" }
	}
}, Ei = {
	entering: "in",
	entered: "in",
	exiting: "out",
	exited: "out",
	"pre-exiting": "out",
	"pre-entering": "out"
};
function Di({ transition: e, state: t, duration: n, timingFunction: r }) {
	let i = {
		WebkitBackfaceVisibility: "hidden",
		transitionDuration: `${n}ms`,
		transitionTimingFunction: r
	};
	return typeof e == "string" ? e in Ti ? {
		transitionProperty: Ti[e].transitionProperty,
		...i,
		...Ti[e].common,
		...Ti[e][Ei[t]]
	} : {} : {
		transitionProperty: e.transitionProperty,
		...i,
		...e.common,
		...e[Ei[t]]
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Transition/use-transition.mjs
function Oi({ duration: e, exitDuration: t, timingFunction: n, mounted: r, onEnter: i, onExit: a, onEntered: o, onExited: s, enterDelay: c, exitDelay: l }) {
	let u = Xt(), d = ze(), f = u.respectReducedMotion ? d : !1, [m, h] = y(f ? 0 : e), [g, _] = y(r ? "entered" : "exited"), b = v(-1), S = v(-1), C = v(-1);
	function w() {
		window.clearTimeout(b.current), window.clearTimeout(S.current), cancelAnimationFrame(C.current);
	}
	let T = (n) => {
		w();
		let r = n ? i : a, c = n ? o : s, l = f ? 0 : n ? e : t;
		h(l), l === 0 ? (typeof r == "function" && r(), typeof c == "function" && c(), _(n ? "entered" : "exited")) : C.current = requestAnimationFrame(() => {
			x.flushSync(() => {
				_(n ? "pre-entering" : "pre-exiting");
			}), C.current = requestAnimationFrame(() => {
				typeof r == "function" && r(), _(n ? "entering" : "exiting"), b.current = window.setTimeout(() => {
					typeof c == "function" && c(), _(n ? "entered" : "exited");
				}, l);
			});
		});
	}, E = (e) => {
		if (w(), typeof (e ? c : l) != "number") {
			T(e);
			return;
		}
		S.current = window.setTimeout(() => {
			T(e);
		}, e ? c : l);
	};
	return G(() => {
		E(r);
	}, [r]), p(() => () => {
		w();
	}, []), {
		transitionDuration: m,
		transitionStatus: g,
		transitionTimingFunction: n || "ease"
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Transition/Transition.mjs
function ki({ keepMounted: e, keepMountedMode: t = "activity", transition: n = "fade", duration: i = 250, exitDuration: a = i, mounted: o, children: s, timingFunction: c = "ease", onExit: l, onEntered: u, onEnter: d, onExited: f, enterDelay: p, exitDelay: m }) {
	let h = Nt(), { transitionDuration: g, transitionStatus: _, transitionTimingFunction: v } = Oi({
		mounted: o,
		exitDuration: a,
		duration: i,
		timingFunction: c,
		onExit: l,
		onEntered: u,
		onEnter: d,
		onExited: f,
		enterDelay: p,
		exitDelay: m
	});
	if (h === "test") return o ? /* @__PURE__ */ T(w, { children: s({}) }) : e ? s({ display: "none" }) : null;
	if (g === 0) return e ? t === "display-none" ? o ? /* @__PURE__ */ T(w, { children: s({}) }) : s({ display: "none" }) : /* @__PURE__ */ T(r, {
		mode: o ? "visible" : "hidden",
		children: s({})
	}) : o ? /* @__PURE__ */ T(w, { children: s({}) }) : null;
	let y = _ === "exited";
	if (e) {
		let e = s(y ? t === "display-none" ? { display: "none" } : {} : Di({
			transition: n,
			duration: g,
			state: _,
			timingFunction: v
		}));
		return t === "display-none" ? e : /* @__PURE__ */ T(r, {
			mode: y ? "hidden" : "visible",
			children: e
		});
	}
	return y ? null : /* @__PURE__ */ T(w, { children: s(Di({
		transition: n,
		duration: g,
		state: _,
		timingFunction: v
	})) });
}
ki.displayName = "@mantine/core/Transition";
//#endregion
//#region node_modules/@mantine/core/esm/components/FocusTrap/FocusTrap.mjs
function Ai({ children: e, active: t = !0, refProp: n = "ref", innerRef: r }) {
	let i = Le(Me(t), r), a = qe(e);
	return a ? o(a, { [n]: i }) : e;
}
function ji(e) {
	return /* @__PURE__ */ T(di, {
		tabIndex: -1,
		"data-autofocus": !0,
		...e
	});
}
Ai.displayName = "@mantine/core/FocusTrap", ji.displayName = "@mantine/core/FocusTrapInitialFocus", Ai.InitialFocus = ji;
//#endregion
//#region node_modules/@mantine/core/esm/components/Loader/Loader.module.mjs
var Mi = {
	root: "m_5ae2e3c",
	barsLoader: "m_7a2bd4cd",
	bar: "m_870bb79",
	"bars-loader-animation": "m_5d2b3b9d",
	dotsLoader: "m_4e3f22d7",
	dot: "m_870c4af",
	"loader-dots-animation": "m_aac34a1",
	ovalLoader: "m_b34414df",
	"oval-loader-animation": "m_f8e89c4b"
}, Ni = ({ className: e, ...t }) => /* @__PURE__ */ E(X, {
	component: "span",
	className: Ye(Mi.barsLoader, e),
	...t,
	children: [
		/* @__PURE__ */ T("span", { className: Mi.bar }),
		/* @__PURE__ */ T("span", { className: Mi.bar }),
		/* @__PURE__ */ T("span", { className: Mi.bar })
	]
});
Ni.displayName = "@mantine/core/Bars";
//#endregion
//#region node_modules/@mantine/core/esm/components/Loader/loaders/Dots.mjs
var Pi = ({ className: e, ...t }) => /* @__PURE__ */ E(X, {
	component: "span",
	className: Ye(Mi.dotsLoader, e),
	...t,
	children: [
		/* @__PURE__ */ T("span", { className: Mi.dot }),
		/* @__PURE__ */ T("span", { className: Mi.dot }),
		/* @__PURE__ */ T("span", { className: Mi.dot })
	]
});
Pi.displayName = "@mantine/core/Dots";
//#endregion
//#region node_modules/@mantine/core/esm/components/Loader/loaders/Oval.mjs
var Fi = ({ className: e, ...t }) => /* @__PURE__ */ T(X, {
	component: "span",
	className: Ye(Mi.ovalLoader, e),
	...t
});
Fi.displayName = "@mantine/core/Oval";
//#endregion
//#region node_modules/@mantine/core/esm/components/Loader/Loader.mjs
var Ii = {
	bars: Ni,
	oval: Fi,
	dots: Pi
}, Li = {
	loaders: Ii,
	type: "oval"
}, Ri = K((e, { size: t, color: n }) => ({ root: {
	"--loader-size": B(t, "loader-size"),
	"--loader-color": n ? pt(n, e) : void 0
} })), zi = Y((e) => {
	let t = q("Loader", Li, e), { size: n, color: r, type: i, vars: a, className: o, style: s, classNames: c, styles: l, unstyled: u, loaders: d, variant: f, children: p, attributes: m, ...h } = t, g = J({
		name: "Loader",
		props: t,
		classes: Mi,
		className: o,
		style: s,
		classNames: c,
		styles: l,
		unstyled: u,
		attributes: m,
		vars: a,
		varsResolver: Ri
	});
	return p ? /* @__PURE__ */ T(X, {
		...g("root"),
		...h,
		children: p
	}) : /* @__PURE__ */ T(X, {
		...g("root"),
		component: d[i],
		variant: f,
		size: n,
		...h
	});
});
zi.defaultLoaders = Ii, zi.classes = Mi, zi.varsResolver = Ri, zi.displayName = "@mantine/core/Loader";
//#endregion
//#region node_modules/@mantine/core/esm/components/ActionIcon/ActionIcon.module.mjs
var Bi = {
	root: "m_8d3f4000",
	icon: "m_8d3afb97",
	loader: "m_302b9fb1",
	group: "m_1a0f1b21",
	groupSection: "m_437b6484"
}, Vi = { orientation: "horizontal" }, Hi = K((e, { borderWidth: t }) => ({ group: { "--ai-border-width": P(t) } })), Ui = Y((e) => {
	let t = q("ActionIconGroup", Vi, e), { className: n, style: r, classNames: i, styles: a, unstyled: o, orientation: s, vars: c, borderWidth: l, variant: u, mod: d, attributes: f, ...p } = t, m = J({
		name: "ActionIconGroup",
		props: t,
		classes: Bi,
		className: n,
		style: r,
		classNames: i,
		styles: a,
		unstyled: o,
		attributes: f,
		vars: c,
		varsResolver: Hi,
		rootSelector: "group"
	});
	return /* @__PURE__ */ T(X, {
		...m("group"),
		variant: u,
		mod: [{ orientation: s }, d],
		role: "group",
		...p
	});
});
Ui.classes = Bi, Ui.varsResolver = Hi, Ui.displayName = "@mantine/core/ActionIconGroup";
//#endregion
//#region node_modules/@mantine/core/esm/components/ActionIcon/ActionIconGroupSection/ActionIconGroupSection.mjs
var Wi = K((e, { radius: t, color: n, gradient: r, variant: i, autoContrast: a, size: o }) => {
	let s = e.variantColorResolver({
		color: n || e.primaryColor,
		theme: e,
		gradient: r,
		variant: i || "filled",
		autoContrast: a
	});
	return { groupSection: {
		"--section-height": B(o, "section-height"),
		"--section-padding-x": B(o, "section-padding-x"),
		"--section-fz": U(o),
		"--section-radius": t === void 0 ? void 0 : H(t),
		"--section-bg": n || i ? s.background : void 0,
		"--section-color": s.color,
		"--section-bd": n || i ? s.border : void 0
	} };
}), Gi = Y((e) => {
	let t = q("ActionIconGroupSection", null, e), { className: n, style: r, classNames: i, styles: a, unstyled: o, vars: s, variant: c, gradient: l, radius: u, autoContrast: d, attributes: f, ...p } = t, m = J({
		name: "ActionIconGroupSection",
		props: t,
		classes: Bi,
		className: n,
		style: r,
		classNames: i,
		styles: a,
		unstyled: o,
		attributes: f,
		vars: s,
		varsResolver: Wi,
		rootSelector: "groupSection"
	});
	return /* @__PURE__ */ T(X, {
		...m("groupSection"),
		variant: c,
		...p
	});
});
Gi.classes = Bi, Gi.varsResolver = Wi, Gi.displayName = "@mantine/core/ActionIconGroupSection";
//#endregion
//#region node_modules/@mantine/core/esm/components/ActionIcon/ActionIcon.mjs
var Ki = K((e, { size: t, radius: n, variant: r, gradient: i, color: a, autoContrast: o }) => {
	let s = e.variantColorResolver({
		color: a || e.primaryColor,
		theme: e,
		gradient: i,
		variant: r || "filled",
		autoContrast: o
	});
	return { root: {
		"--ai-size": B(t, "ai-size"),
		"--ai-radius": n === void 0 ? void 0 : H(n),
		"--ai-bg": a || r ? s.background : void 0,
		"--ai-hover": a || r ? s.hover : void 0,
		"--ai-hover-color": a || r ? s.hoverColor : void 0,
		"--ai-color": s.color,
		"--ai-bd": a || r ? s.border : void 0
	} };
}), qi = cr((e) => {
	let t = q("ActionIcon", null, e), { className: n, unstyled: r, variant: i, classNames: a, styles: o, style: s, loading: c, loaderProps: l, size: u, color: d, radius: f, __staticSelector: p, gradient: m, vars: h, children: g, disabled: _, "data-disabled": v, autoContrast: y, mod: b, attributes: x, ...S } = t, C = J({
		name: ["ActionIcon", p],
		props: t,
		className: n,
		style: s,
		classes: Bi,
		classNames: a,
		styles: o,
		unstyled: r,
		attributes: x,
		vars: h,
		varsResolver: Ki
	});
	return /* @__PURE__ */ E(li, {
		...C("root", { active: !_ && !c && !v }),
		"aria-busy": c || void 0,
		...S,
		unstyled: r,
		variant: i,
		size: u,
		disabled: _ || c,
		mod: [{
			loading: c,
			disabled: _ || v
		}, b],
		children: [typeof c == "boolean" && /* @__PURE__ */ T(ki, {
			mounted: c,
			transition: "slide-down",
			duration: 150,
			children: (e) => /* @__PURE__ */ T(X, {
				component: "span",
				...C("loader", { style: e }),
				"aria-hidden": !0,
				children: /* @__PURE__ */ T(zi, {
					color: "var(--ai-color)",
					size: "calc(var(--ai-size) * 0.55)",
					...l
				})
			})
		}), /* @__PURE__ */ T(X, {
			component: "span",
			mod: { loading: c },
			...C("icon"),
			children: g
		})]
	});
});
qi.classes = Bi, qi.varsResolver = Ki, qi.displayName = "@mantine/core/ActionIcon", qi.Group = Ui, qi.GroupSection = Gi;
//#endregion
//#region node_modules/@mantine/core/esm/components/CloseButton/CloseIcon.mjs
function Ji({ size: e = "var(--cb-icon-size, 70%)", style: t, ...n }) {
	return /* @__PURE__ */ T("svg", {
		viewBox: "0 0 15 15",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		style: {
			...t,
			width: e,
			height: e
		},
		...n,
		children: /* @__PURE__ */ T("path", {
			d: "M11.7816 4.03157C12.0062 3.80702 12.0062 3.44295 11.7816 3.2184C11.5571 2.99385 11.193 2.99385 10.9685 3.2184L7.50005 6.68682L4.03164 3.2184C3.80708 2.99385 3.44301 2.99385 3.21846 3.2184C2.99391 3.44295 2.99391 3.80702 3.21846 4.03157L6.68688 7.49999L3.21846 10.9684C2.99391 11.193 2.99391 11.557 3.21846 11.7816C3.44301 12.0061 3.80708 12.0061 4.03164 11.7816L7.50005 8.31316L10.9685 11.7816C11.193 12.0061 11.5571 12.0061 11.7816 11.7816C12.0062 11.557 12.0062 11.193 11.7816 10.9684L8.31322 7.49999L11.7816 4.03157Z",
			fill: "currentColor",
			fillRule: "evenodd",
			clipRule: "evenodd"
		})
	});
}
Ji.displayName = "@mantine/core/CloseIcon";
//#endregion
//#region node_modules/@mantine/core/esm/components/CloseButton/CloseButton.module.mjs
var Yi = {
	root: "m_86a44da5",
	"root--subtle": "m_220c80f2"
}, Xi = { variant: "subtle" }, Zi = K((e, { size: t, radius: n, iconSize: r }) => ({ root: {
	"--cb-size": B(t, "cb-size"),
	"--cb-radius": n === void 0 ? void 0 : H(n),
	"--cb-icon-size": P(r)
} })), Qi = cr((e) => {
	let t = q("CloseButton", Xi, e), { iconSize: n, children: r, vars: i, radius: a, className: o, classNames: s, style: c, styles: l, unstyled: u, "data-disabled": d, disabled: f, variant: p, icon: m, mod: h, attributes: g, __staticSelector: _, ...v } = t, y = J({
		name: _ || "CloseButton",
		props: t,
		className: o,
		style: c,
		classes: Yi,
		classNames: s,
		styles: l,
		unstyled: u,
		attributes: g,
		vars: i,
		varsResolver: Zi
	});
	return /* @__PURE__ */ E(li, {
		...v,
		unstyled: u,
		variant: p,
		disabled: f,
		mod: [{ disabled: f || d }, h],
		...y("root", {
			variant: p,
			active: !f && !d
		}),
		children: [m || /* @__PURE__ */ T(Ji, {}), r]
	});
});
Qi.classes = Yi, Qi.varsResolver = Zi, Qi.displayName = "@mantine/core/CloseButton";
//#endregion
//#region node_modules/@mantine/core/esm/components/Group/filter-falsy-children/filter-falsy-children.mjs
function $i(e) {
	return i.toArray(e).filter(Boolean);
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Group/Group.module.mjs
var ea = { root: "m_4081bf90" }, ta = {
	preventGrowOverflow: !0,
	gap: "md",
	align: "center",
	justify: "flex-start",
	wrap: "wrap"
}, na = K((e, { grow: t, preventGrowOverflow: n, gap: r, align: i, justify: a, wrap: o }, { childWidth: s }) => ({ root: {
	"--group-child-width": t && n ? s : void 0,
	"--group-gap": V(r),
	"--group-align": i,
	"--group-justify": a,
	"--group-wrap": o
} })), Z = Y((e) => {
	let t = q("Group", ta, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, children: s, gap: c, align: l, justify: u, wrap: d, grow: f, preventGrowOverflow: p, vars: m, variant: h, __size: g, mod: _, attributes: v, ...y } = t, b = $i(s), x = b.length, S = V(c ?? "md"), C = J({
		name: "Group",
		props: t,
		stylesCtx: { childWidth: `calc(${100 / x}% - (${S} - ${S} / ${x}))` },
		className: r,
		style: i,
		classes: ea,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: v,
		vars: m,
		varsResolver: na
	});
	return /* @__PURE__ */ T(X, {
		...C("root"),
		variant: h,
		mod: [{ grow: f }, _],
		size: g,
		...y,
		children: b
	});
});
Z.classes = ea, Z.varsResolver = na, Z.displayName = "@mantine/core/Group";
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/ModalBase.context.mjs
var [ra, ia] = re("ModalBase component was not found in tree");
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/use-lock-scroll.mjs
function aa({ opened: e, transitionDuration: t }) {
	let [n, r] = y(e), i = v(-1), a = ze() ? 0 : t;
	return p(() => (e ? (r(!0), window.clearTimeout(i.current)) : a === 0 ? r(!1) : i.current = window.setTimeout(() => r(!1), a), () => window.clearTimeout(i.current)), [e, a]), n;
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/use-modal.mjs
function oa({ id: e, transitionProps: t, opened: n, trapFocus: r, closeOnEscape: i, onClose: a, returnFocus: o }) {
	let s = Ne(e), [c, l] = y(!1), [u, d] = y(!1), f = aa({
		opened: n,
		transitionDuration: typeof t?.duration == "number" ? t?.duration : 200
	});
	return Pe("keydown", (e) => {
		e.key === "Escape" && i && !e.isComposing && n && e.target?.getAttribute("data-mantine-stop-propagation") !== "true" && a();
	}, { capture: !0 }), Se({
		opened: n,
		shouldReturnFocus: r && o
	}), {
		_id: s,
		titleMounted: c,
		bodyMounted: u,
		shouldLockScroll: f,
		setTitleMounted: l,
		setBodyMounted: d
	};
}
//#endregion
//#region node_modules/tslib/tslib.es6.mjs
var sa = function() {
	return sa = Object.assign || function(e) {
		for (var t, n = 1, r = arguments.length; n < r; n++) for (var i in t = arguments[n], t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
		return e;
	}, sa.apply(this, arguments);
};
function ca(e, t) {
	var n = {};
	for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
	if (e != null && typeof Object.getOwnPropertySymbols == "function") for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++) t.indexOf(r[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (n[r[i]] = e[r[i]]);
	return n;
}
function la(e, t, n) {
	if (n || arguments.length === 2) for (var r = 0, i = t.length, a; r < i; r++) (a || !(r in t)) && (a ||= Array.prototype.slice.call(t, 0, r), a[r] = t[r]);
	return e.concat(a || Array.prototype.slice.call(t));
}
//#endregion
//#region node_modules/react-remove-scroll-bar/dist/es2015/constants.js
var ua = "right-scroll-bar-position", da = "width-before-scroll-bar", fa = "with-scroll-bars-hidden", pa = "--removed-body-scroll-bar-size";
//#endregion
//#region node_modules/use-callback-ref/dist/es2015/assignRef.js
function ma(e, t) {
	return typeof e == "function" ? e(t) : e && (e.current = t), e;
}
//#endregion
//#region node_modules/use-callback-ref/dist/es2015/useRef.js
function ha(e, t) {
	var n = y(function() {
		return {
			value: e,
			callback: t,
			facade: {
				get current() {
					return n.value;
				},
				set current(e) {
					var t = n.value;
					t !== e && (n.value = e, n.callback(e, t));
				}
			}
		};
	})[0];
	return n.callback = t, n.facade;
}
//#endregion
//#region node_modules/use-callback-ref/dist/es2015/useMergeRef.js
var ga = typeof window < "u" ? t.useLayoutEffect : t.useEffect, _a = /* @__PURE__ */ new WeakMap();
function va(e, t) {
	var n = ha(t || null, function(t) {
		return e.forEach(function(e) {
			return ma(e, t);
		});
	});
	return ga(function() {
		var t = _a.get(n);
		if (t) {
			var r = new Set(t), i = new Set(e), a = n.current;
			r.forEach(function(e) {
				i.has(e) || ma(e, null);
			}), i.forEach(function(e) {
				r.has(e) || ma(e, a);
			});
		}
		_a.set(n, e);
	}, [e]), n;
}
//#endregion
//#region node_modules/use-sidecar/dist/es2015/medium.js
function ya(e) {
	return e;
}
function ba(e, t) {
	t === void 0 && (t = ya);
	var n = [], r = !1;
	return {
		read: function() {
			if (r) throw Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
			return n.length ? n[n.length - 1] : e;
		},
		useMedium: function(e) {
			var i = t(e, r);
			return n.push(i), function() {
				n = n.filter(function(e) {
					return e !== i;
				});
			};
		},
		assignSyncMedium: function(e) {
			for (r = !0; n.length;) {
				var t = n;
				n = [], t.forEach(e);
			}
			n = {
				push: function(t) {
					return e(t);
				},
				filter: function() {
					return n;
				}
			};
		},
		assignMedium: function(e) {
			r = !0;
			var t = [];
			if (n.length) {
				var i = n;
				n = [], i.forEach(e), t = n;
			}
			var a = function() {
				var n = t;
				t = [], n.forEach(e);
			}, o = function() {
				return Promise.resolve().then(a);
			};
			o(), n = {
				push: function(e) {
					t.push(e), o();
				},
				filter: function(e) {
					return t = t.filter(e), n;
				}
			};
		}
	};
}
function xa(e) {
	e === void 0 && (e = {});
	var t = ba(null);
	return t.options = sa({
		async: !0,
		ssr: !1
	}, e), t;
}
//#endregion
//#region node_modules/use-sidecar/dist/es2015/exports.js
var Sa = function(e) {
	var n = e.sideCar, r = ca(e, ["sideCar"]);
	if (!n) throw Error("Sidecar: please provide `sideCar` property to import the right car");
	var i = n.read();
	if (!i) throw Error("Sidecar medium not found");
	return t.createElement(i, sa({}, r));
};
Sa.isSideCarExport = !0;
function Ca(e, t) {
	return e.useMedium(t), Sa;
}
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/medium.js
var wa = xa(), Ta = function() {}, Ea = t.forwardRef(function(e, n) {
	var r = t.useRef(null), i = t.useState({
		onScrollCapture: Ta,
		onWheelCapture: Ta,
		onTouchMoveCapture: Ta
	}), a = i[0], o = i[1], s = e.forwardProps, c = e.children, l = e.className, u = e.removeScrollBar, d = e.enabled, f = e.shards, p = e.sideCar, m = e.noRelative, h = e.noIsolation, g = e.inert, _ = e.allowPinchZoom, v = e.as, y = v === void 0 ? "div" : v, b = e.gapMode, x = ca(e, [
		"forwardProps",
		"children",
		"className",
		"removeScrollBar",
		"enabled",
		"shards",
		"sideCar",
		"noRelative",
		"noIsolation",
		"inert",
		"allowPinchZoom",
		"as",
		"gapMode"
	]), S = p, C = va([r, n]), w = sa(sa({}, x), a);
	return t.createElement(t.Fragment, null, d && t.createElement(S, {
		sideCar: wa,
		removeScrollBar: u,
		shards: f,
		noRelative: m,
		noIsolation: h,
		inert: g,
		setCallbacks: o,
		allowPinchZoom: !!_,
		lockRef: r,
		gapMode: b
	}), s ? t.cloneElement(t.Children.only(c), sa(sa({}, w), { ref: C })) : t.createElement(y, sa({}, w, {
		className: l,
		ref: C
	}), c));
});
Ea.defaultProps = {
	enabled: !0,
	removeScrollBar: !0,
	inert: !1
}, Ea.classNames = {
	fullWidth: da,
	zeroRight: ua
};
//#endregion
//#region node_modules/get-nonce/dist/es2015/index.js
var Da = function() {
	if (typeof __webpack_nonce__ < "u") return __webpack_nonce__;
};
//#endregion
//#region node_modules/react-style-singleton/dist/es2015/singleton.js
function Oa() {
	if (!document) return null;
	var e = document.createElement("style");
	e.type = "text/css";
	var t = Da();
	return t && e.setAttribute("nonce", t), e;
}
function ka(e, t) {
	e.styleSheet ? e.styleSheet.cssText = t : e.appendChild(document.createTextNode(t));
}
function Aa(e) {
	(document.head || document.getElementsByTagName("head")[0]).appendChild(e);
}
var ja = function() {
	var e = 0, t = null;
	return {
		add: function(n) {
			e == 0 && (t = Oa()) && (ka(t, n), Aa(t)), e++;
		},
		remove: function() {
			e--, !e && t && (t.parentNode && t.parentNode.removeChild(t), t = null);
		}
	};
}, Ma = function() {
	var e = ja();
	return function(n, r) {
		t.useEffect(function() {
			return e.add(n), function() {
				e.remove();
			};
		}, [n && r]);
	};
}, Na = function() {
	var e = Ma();
	return function(t) {
		var n = t.styles, r = t.dynamic;
		return e(n, r), null;
	};
}, Pa = {
	left: 0,
	top: 0,
	right: 0,
	gap: 0
}, Fa = function(e) {
	return parseInt(e || "", 10) || 0;
}, Ia = function(e) {
	var t = window.getComputedStyle(document.body), n = t[e === "padding" ? "paddingLeft" : "marginLeft"], r = t[e === "padding" ? "paddingTop" : "marginTop"], i = t[e === "padding" ? "paddingRight" : "marginRight"];
	return [
		Fa(n),
		Fa(r),
		Fa(i)
	];
}, La = function(e) {
	if (e === void 0 && (e = "margin"), typeof window > "u") return Pa;
	var t = Ia(e), n = document.documentElement.clientWidth, r = window.innerWidth;
	return {
		left: t[0],
		top: t[1],
		right: t[2],
		gap: Math.max(0, r - n + t[2] - t[0])
	};
}, Ra = Na(), za = "data-scroll-locked", Ba = function(e, t, n, r) {
	var i = e.left, a = e.top, o = e.right, s = e.gap;
	return n === void 0 && (n = "margin"), `
  .${fa} {
   overflow: hidden ${r};
   padding-right: ${s}px ${r};
  }
  body[${za}] {
    overflow: hidden ${r};
    overscroll-behavior: contain;
    ${[
		t && `position: relative ${r};`,
		n === "margin" && `
    padding-left: ${i}px;
    padding-top: ${a}px;
    padding-right: ${o}px;
    margin-left:0;
    margin-top:0;
    margin-right: ${s}px ${r};
    `,
		n === "padding" && `padding-right: ${s}px ${r};`
	].filter(Boolean).join("")}
  }
  
  .${ua} {
    right: ${s}px ${r};
  }
  
  .${da} {
    margin-right: ${s}px ${r};
  }
  
  .${ua} .${ua} {
    right: 0 ${r};
  }
  
  .${da} .${da} {
    margin-right: 0 ${r};
  }
  
  body[${za}] {
    ${pa}: ${s}px;
  }
`;
}, Va = function() {
	var e = parseInt(document.body.getAttribute("data-scroll-locked") || "0", 10);
	return isFinite(e) ? e : 0;
}, Ha = function() {
	t.useEffect(function() {
		return document.body.setAttribute(za, (Va() + 1).toString()), function() {
			var e = Va() - 1;
			e <= 0 ? document.body.removeAttribute(za) : document.body.setAttribute(za, e.toString());
		};
	}, []);
}, Ua = function(e) {
	var n = e.noRelative, r = e.noImportant, i = e.gapMode, a = i === void 0 ? "margin" : i;
	Ha();
	var o = t.useMemo(function() {
		return La(a);
	}, [a]);
	return t.createElement(Ra, { styles: Ba(o, !n, a, r ? "" : "!important") });
}, Wa = !1;
if (typeof window < "u") try {
	var Ga = Object.defineProperty({}, "passive", { get: function() {
		return Wa = !0, !0;
	} });
	window.addEventListener("test", Ga, Ga), window.removeEventListener("test", Ga, Ga);
} catch {
	Wa = !1;
}
var Ka = Wa ? { passive: !1 } : !1, qa = function(e) {
	return e.tagName === "TEXTAREA";
}, Ja = function(e, t) {
	if (!(e instanceof Element)) return !1;
	var n = window.getComputedStyle(e);
	return n[t] !== "hidden" && !(n.overflowY === n.overflowX && !qa(e) && n[t] === "visible");
}, Ya = function(e) {
	return Ja(e, "overflowY");
}, Xa = function(e) {
	return Ja(e, "overflowX");
}, Za = function(e, t) {
	var n = t.ownerDocument, r = t;
	do {
		if (typeof ShadowRoot < "u" && r instanceof ShadowRoot && (r = r.host), eo(e, r)) {
			var i = to(e, r);
			if (i[1] > i[2]) return !0;
		}
		r = r.parentNode;
	} while (r && r !== n.body);
	return !1;
}, Qa = function(e) {
	return [
		e.scrollTop,
		e.scrollHeight,
		e.clientHeight
	];
}, $a = function(e) {
	return [
		e.scrollLeft,
		e.scrollWidth,
		e.clientWidth
	];
}, eo = function(e, t) {
	return e === "v" ? Ya(t) : Xa(t);
}, to = function(e, t) {
	return e === "v" ? Qa(t) : $a(t);
}, no = function(e, t) {
	return e === "h" && t === "rtl" ? -1 : 1;
}, ro = function(e, t, n, r, i) {
	var a = no(e, window.getComputedStyle(t).direction), o = a * r, s = n.target, c = t.contains(s), l = !1, u = o > 0, d = 0, f = 0;
	do {
		if (!s) break;
		var p = to(e, s), m = p[0], h = p[1] - p[2] - a * m;
		(m || h) && eo(e, s) && (d += h, f += m);
		var g = s.parentNode;
		s = g && g.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? g.host : g;
	} while (!c && s !== document.body || c && (t.contains(s) || t === s));
	return (u && (i && Math.abs(d) < 1 || !i && o > d) || !u && (i && Math.abs(f) < 1 || !i && -o > f)) && (l = !0), l;
}, io = function(e) {
	return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0];
}, ao = function(e) {
	return [e.deltaX, e.deltaY];
}, oo = function(e) {
	return e && "current" in e ? e.current : e;
}, so = function(e, t) {
	return e[0] === t[0] && e[1] === t[1];
}, co = function(e) {
	return `
  .block-interactivity-${e} {pointer-events: none;}
  .allow-interactivity-${e} {pointer-events: all;}
`;
}, lo = 0, uo = [];
function fo(e) {
	var n = t.useRef([]), r = t.useRef([0, 0]), i = t.useRef(), a = t.useState(lo++)[0], o = t.useState(Na)[0], s = t.useRef(e);
	t.useEffect(function() {
		s.current = e;
	}, [e]), t.useEffect(function() {
		if (e.inert) {
			document.body.classList.add(`block-interactivity-${a}`);
			var t = la([e.lockRef.current], (e.shards || []).map(oo), !0).filter(Boolean);
			return t.forEach(function(e) {
				return e.classList.add(`allow-interactivity-${a}`);
			}), function() {
				document.body.classList.remove(`block-interactivity-${a}`), t.forEach(function(e) {
					return e.classList.remove(`allow-interactivity-${a}`);
				});
			};
		}
	}, [
		e.inert,
		e.lockRef.current,
		e.shards
	]);
	var c = t.useCallback(function(e, t) {
		if ("touches" in e && e.touches.length === 2 || e.type === "wheel" && e.ctrlKey) return !s.current.allowPinchZoom;
		var n = io(e), a = r.current, o = "deltaX" in e ? e.deltaX : a[0] - n[0], c = "deltaY" in e ? e.deltaY : a[1] - n[1], l, u = e.target, d = Math.abs(o) > Math.abs(c) ? "h" : "v";
		if ("touches" in e && d === "h" && u.type === "range") return !1;
		var f = window.getSelection(), p = f && f.anchorNode;
		if (p && (p === u || p.contains(u))) return !1;
		var m = Za(d, u);
		if (!m) return !0;
		if (m ? l = d : (l = d === "v" ? "h" : "v", m = Za(d, u)), !m) return !1;
		if (!i.current && "changedTouches" in e && (o || c) && (i.current = l), !l) return !0;
		var h = i.current || l;
		return ro(h, t, e, h === "h" ? o : c, !0);
	}, []), l = t.useCallback(function(e) {
		var t = e;
		if (!(!uo.length || uo[uo.length - 1] !== o)) {
			var r = "deltaY" in t ? ao(t) : io(t), i = n.current.filter(function(e) {
				return e.name === t.type && (e.target === t.target || t.target === e.shadowParent) && so(e.delta, r);
			})[0];
			if (i && i.should) {
				t.cancelable && t.preventDefault();
				return;
			}
			if (!i) {
				var a = (s.current.shards || []).map(oo).filter(Boolean).filter(function(e) {
					return e.contains(t.target);
				});
				(a.length > 0 ? c(t, a[0]) : !s.current.noIsolation) && t.cancelable && t.preventDefault();
			}
		}
	}, []), u = t.useCallback(function(e, t, r, i) {
		var a = {
			name: e,
			delta: t,
			target: r,
			should: i,
			shadowParent: po(r)
		};
		n.current.push(a), setTimeout(function() {
			n.current = n.current.filter(function(e) {
				return e !== a;
			});
		}, 1);
	}, []), d = t.useCallback(function(e) {
		r.current = io(e), i.current = void 0;
	}, []), f = t.useCallback(function(t) {
		u(t.type, ao(t), t.target, c(t, e.lockRef.current));
	}, []), p = t.useCallback(function(t) {
		u(t.type, io(t), t.target, c(t, e.lockRef.current));
	}, []);
	t.useEffect(function() {
		return uo.push(o), e.setCallbacks({
			onScrollCapture: f,
			onWheelCapture: f,
			onTouchMoveCapture: p
		}), document.addEventListener("wheel", l, Ka), document.addEventListener("touchmove", l, Ka), document.addEventListener("touchstart", d, Ka), function() {
			uo = uo.filter(function(e) {
				return e !== o;
			}), document.removeEventListener("wheel", l, Ka), document.removeEventListener("touchmove", l, Ka), document.removeEventListener("touchstart", d, Ka);
		};
	}, []);
	var m = e.removeScrollBar, h = e.inert;
	return t.createElement(t.Fragment, null, h ? t.createElement(o, { styles: co(a) }) : null, m ? t.createElement(Ua, {
		noRelative: e.noRelative,
		gapMode: e.gapMode
	}) : null);
}
function po(e) {
	for (var t = null; e !== null;) e instanceof ShadowRoot && (t = e.host, e = e.host), e = e.parentNode;
	return t;
}
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/sidecar.js
var mo = Ca(wa, fo), ho = t.forwardRef(function(e, n) {
	return t.createElement(Ea, sa({}, e, {
		ref: n,
		sideCar: mo
	}));
});
ho.classNames = Ea.classNames;
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/ModalBase.mjs
function go({ keepMounted: e, keepMountedMode: t = "activity", opened: n, onClose: r, id: i, transitionProps: a, onExitTransitionEnd: o, onEnterTransitionEnd: s, trapFocus: c, closeOnEscape: l, returnFocus: u, closeOnClickOutside: d, withinPortal: f, portalProps: p, lockScroll: m, children: h, zIndex: g, shadow: _, padding: v, __vars: y, unstyled: b, removeScrollProps: x, ...S }) {
	let { _id: C, titleMounted: w, bodyMounted: E, shouldLockScroll: D, setTitleMounted: O, setBodyMounted: k } = oa({
		id: i,
		transitionProps: a,
		opened: n,
		trapFocus: c,
		closeOnEscape: l,
		onClose: r,
		returnFocus: u
	}), { key: ee, ...A } = x || {};
	return /* @__PURE__ */ T(Ci, {
		...p,
		withinPortal: f,
		children: /* @__PURE__ */ T(ra, {
			value: {
				opened: n,
				onClose: r,
				closeOnClickOutside: d,
				onExitTransitionEnd: o,
				onEnterTransitionEnd: s,
				transitionProps: {
					...a,
					keepMounted: e,
					keepMountedMode: t
				},
				getTitleId: () => `${C}-title`,
				getBodyId: () => `${C}-body`,
				titleMounted: w,
				bodyMounted: E,
				setTitleMounted: O,
				setBodyMounted: k,
				trapFocus: c,
				closeOnEscape: l,
				zIndex: g,
				unstyled: b
			},
			children: /* @__PURE__ */ T(ho, {
				enabled: D && m,
				...A,
				children: /* @__PURE__ */ T(X, {
					...S,
					id: C,
					__vars: {
						...y,
						"--mb-z-index": (g || ce("modal")).toString(),
						"--mb-shadow": W(_),
						"--mb-padding": V(v)
					},
					children: h
				})
			}, ee)
		})
	});
}
go.displayName = "@mantine/core/ModalBase";
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/use-modal-body-id.mjs
function _o() {
	let e = ia();
	return p(() => (e.setBodyMounted(!0), () => e.setBodyMounted(!1)), []), e.getBodyId();
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/ModalBase.module.mjs
var vo = {
	title: "m_615af6c9",
	header: "m_b5489c3c",
	inner: "m_60c222c7",
	content: "m_fd1ab0aa",
	close: "m_606cb269",
	body: "m_5df29311"
};
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/ModalBaseBody.mjs
function yo({ className: e, ...t }) {
	let n = _o(), r = ia();
	return /* @__PURE__ */ T(X, {
		id: n,
		className: Ye({ [vo.body]: !r.unstyled }, e),
		...t
	});
}
yo.displayName = "@mantine/core/ModalBaseBody";
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/ModalBaseCloseButton.mjs
function bo({ className: e, onClick: t, ...n }) {
	let r = ia();
	return /* @__PURE__ */ T(Qi, {
		...n,
		onClick: (e) => {
			r.onClose(), t?.(e);
		},
		className: Ye({ [vo.close]: !r.unstyled }, e),
		unstyled: r.unstyled
	});
}
bo.displayName = "@mantine/core/ModalBaseCloseButton";
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/ModalBaseContent.mjs
function xo({ transitionProps: e, className: t, innerProps: n, onKeyDown: r, style: i, ref: a, ...o }) {
	let s = ia();
	return /* @__PURE__ */ T(ki, {
		mounted: s.opened,
		transition: "pop",
		...s.transitionProps,
		onExited: () => {
			s.onExitTransitionEnd?.(), s.transitionProps?.onExited?.();
		},
		onEntered: () => {
			s.onEnterTransitionEnd?.(), s.transitionProps?.onEntered?.();
		},
		...e,
		children: (e) => /* @__PURE__ */ T("div", {
			...n,
			className: Ye({ [vo.inner]: !s.unstyled }, n.className),
			children: /* @__PURE__ */ T(Ai, {
				active: s.opened && s.trapFocus,
				innerRef: a,
				children: /* @__PURE__ */ T(mi, {
					...o,
					component: "section",
					role: "dialog",
					tabIndex: -1,
					"aria-modal": !0,
					"aria-describedby": s.bodyMounted ? s.getBodyId() : void 0,
					"aria-labelledby": s.titleMounted ? s.getTitleId() : void 0,
					style: [i, e],
					className: Ye({ [vo.content]: !s.unstyled }, t),
					unstyled: s.unstyled,
					children: o.children
				})
			})
		})
	});
}
xo.displayName = "@mantine/core/ModalBaseContent";
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/ModalBaseHeader.mjs
function So({ className: e, ...t }) {
	let n = ia();
	return /* @__PURE__ */ T(X, {
		component: "header",
		className: Ye({ [vo.header]: !n.unstyled }, e),
		...t
	});
}
So.displayName = "@mantine/core/ModalBaseHeader";
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/use-modal-transition.mjs
var Co = {
	duration: 200,
	timingFunction: "ease",
	transition: "fade"
};
function wo(e) {
	let t = ia();
	return {
		...Co,
		...t.transitionProps,
		...e
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/ModalBaseOverlay.mjs
function To({ onClick: e, transitionProps: t, style: n, visible: r, ...i }) {
	let a = ia(), o = wo(t);
	return /* @__PURE__ */ T(ki, {
		mounted: r === void 0 ? a.opened : r,
		...o,
		transition: "fade",
		children: (t) => /* @__PURE__ */ T(vi, {
			fixed: !0,
			style: [n, t],
			zIndex: a.zIndex,
			unstyled: a.unstyled,
			onClick: (t) => {
				e?.(t), a.closeOnClickOutside && a.onClose();
			},
			...i
		})
	});
}
To.displayName = "@mantine/core/ModalBaseOverlay";
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/use-modal-title-id.mjs
function Eo() {
	let e = ia();
	return p(() => (e.setTitleMounted(!0), () => e.setTitleMounted(!1)), []), e.getTitleId();
}
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/ModalBaseTitle.mjs
function Do({ className: e, ...t }) {
	let n = Eo(), r = ia();
	return /* @__PURE__ */ T(X, {
		component: "h2",
		className: Ye({ [vo.title]: !r.unstyled }, e),
		id: n,
		...t
	});
}
Do.displayName = "@mantine/core/ModalBaseTitle";
//#endregion
//#region node_modules/@mantine/core/esm/components/ModalBase/NativeScrollArea.mjs
function Oo({ children: e }) {
	return /* @__PURE__ */ T(w, { children: e });
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Input/Input.context.mjs
var ko = s({ size: "sm" }), Ao = Y((e) => {
	let t = q("InputClearButton", null, e), { size: n, variant: r, vars: i, classNames: a, styles: o, ...s } = t, c = u(ko), { resolvedClassNames: l, resolvedStyles: d } = pn({
		classNames: a,
		styles: o,
		props: t
	});
	return /* @__PURE__ */ T(Qi, {
		variant: r || "transparent",
		size: n || c?.size || "sm",
		classNames: l,
		styles: d,
		__staticSelector: "InputClearButton",
		style: {
			pointerEvents: "all",
			background: "var(--input-bg)",
			...s.style
		},
		...s
	});
});
Ao.displayName = "@mantine/core/InputClearButton";
//#endregion
//#region node_modules/@mantine/core/esm/components/Input/InputClearSection/InputClearSection.mjs
var jo = {
	xs: 7,
	sm: 8,
	md: 10,
	lg: 12,
	xl: 15
};
function Mo({ __clearable: e, __clearSection: t, rightSection: n, __defaultRightSection: r, size: i = "sm", __clearSectionMode: a = "both" }) {
	let o = e && t;
	return a === "rightSection" ? n === null ? null : n || r : a === "clear" ? n === null ? null : o || r : o && (n || r) ? /* @__PURE__ */ E("div", {
		"data-combined-clear-section": !0,
		style: {
			display: "flex",
			gap: 2,
			alignItems: "center",
			paddingInlineEnd: jo[i]
		},
		children: [o, n || r]
	}) : n === null ? null : n || o || r;
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Input/InputWrapper.context.mjs
var No = s({
	offsetBottom: !1,
	offsetTop: !1,
	describedBy: void 0,
	getStyles: null,
	inputId: void 0,
	labelId: void 0
}), Po = {
	wrapper: "m_6c018570",
	input: "m_8fb7ebe7",
	bottomSection: "m_93f4ed57",
	section: "m_82577fc2",
	placeholder: "m_88bacfd0",
	root: "m_46b77525",
	label: "m_8fdc1311",
	required: "m_78a94662",
	error: "m_8f816625",
	success: "m_9d9d40e0",
	description: "m_fe47ce59"
}, Fo = K((e, { size: t }) => ({ description: { "--input-description-size": t === void 0 ? void 0 : `calc(${U(t)} - ${P(2)})` } })), Io = Y((e) => {
	let t = q("InputDescription", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, __staticSelector: c, __inheritStyles: l = !0, attributes: d, ...f } = q("InputDescription", null, t), p = u(No), m = J({
		name: ["InputWrapper", c],
		props: t,
		classes: Po,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: d,
		rootSelector: "description",
		vars: s,
		varsResolver: Fo
	}), h = l && p?.getStyles || m;
	return /* @__PURE__ */ T(X, {
		component: "p",
		...h("description", p?.getStyles ? {
			className: r,
			style: i
		} : void 0),
		...f
	});
});
Io.classes = Po, Io.varsResolver = Fo, Io.displayName = "@mantine/core/InputDescription";
//#endregion
//#region node_modules/@mantine/core/esm/components/Input/InputError/InputError.mjs
var Lo = K((e, { size: t }) => ({ error: { "--input-error-size": t === void 0 ? void 0 : `calc(${U(t)} - ${P(2)})` } })), Ro = Y((e) => {
	let t = q("InputError", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, attributes: c, __staticSelector: l, __inheritStyles: d = !0, ...f } = t, p = J({
		name: ["InputWrapper", l],
		props: t,
		classes: Po,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: c,
		rootSelector: "error",
		vars: s,
		varsResolver: Lo
	}), m = u(No), h = d && m?.getStyles || p;
	return /* @__PURE__ */ T(X, {
		component: "p",
		...h("error", m?.getStyles ? {
			className: r,
			style: i
		} : void 0),
		...f
	});
});
Ro.classes = Po, Ro.varsResolver = Lo, Ro.displayName = "@mantine/core/InputError";
//#endregion
//#region node_modules/@mantine/core/esm/components/Input/InputLabel/InputLabel.mjs
var zo = { labelElement: "label" }, Bo = K((e, { size: t }) => ({ label: {
	"--input-label-size": U(t),
	"--input-asterisk-color": void 0
} })), Vo = Y((e) => {
	let t = q("InputLabel", zo, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, labelElement: c, required: l, htmlFor: d, onMouseDown: f, children: p, __staticSelector: m, mod: h, attributes: g, ..._ } = t, v = J({
		name: ["InputWrapper", m],
		props: t,
		classes: Po,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: g,
		rootSelector: "label",
		vars: s,
		varsResolver: Bo
	}), y = u(No), b = y?.getStyles || v, x = _.component || c, S = typeof x != "string" || x === "label";
	return /* @__PURE__ */ E(X, {
		...b("label", y?.getStyles ? {
			className: r,
			style: i
		} : void 0),
		component: c,
		htmlFor: S ? d : void 0,
		mod: [{ required: l }, h],
		onMouseDown: (e) => {
			f?.(e), !e.defaultPrevented && e.detail > 1 && e.preventDefault();
		},
		..._,
		children: [p, l && /* @__PURE__ */ T("span", {
			...b("required"),
			"aria-hidden": !0,
			children: " *"
		})]
	});
});
Vo.classes = Po, Vo.varsResolver = Bo, Vo.displayName = "@mantine/core/InputLabel";
//#endregion
//#region node_modules/@mantine/core/esm/components/Input/InputPlaceholder/InputPlaceholder.mjs
var Ho = Y((e) => {
	let t = q("InputPlaceholder", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, __staticSelector: c, error: l, mod: u, attributes: d, ...f } = t, p = J({
		name: ["InputPlaceholder", c],
		props: t,
		classes: Po,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: d,
		rootSelector: "placeholder"
	});
	return /* @__PURE__ */ T(X, {
		...p("placeholder"),
		mod: [{ error: !!l }, u],
		component: "span",
		...f
	});
});
Ho.classes = Po, Ho.displayName = "@mantine/core/InputPlaceholder";
//#endregion
//#region node_modules/@mantine/core/esm/components/Input/InputSuccess/InputSuccess.mjs
var Uo = K((e, { size: t }) => ({ success: { "--input-success-size": t === void 0 ? void 0 : `calc(${U(t)} - ${P(2)})` } })), Wo = Y((e) => {
	let t = q("InputSuccess", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, attributes: c, __staticSelector: l, __inheritStyles: d = !0, ...f } = t, p = J({
		name: ["InputWrapper", l],
		props: t,
		classes: Po,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: c,
		rootSelector: "success",
		vars: s,
		varsResolver: Uo
	}), m = u(No), h = d && m?.getStyles || p;
	return /* @__PURE__ */ T(X, {
		component: "p",
		...h("success", m?.getStyles ? {
			className: r,
			style: i
		} : void 0),
		...f
	});
});
Wo.classes = Po, Wo.varsResolver = Uo, Wo.displayName = "@mantine/core/InputSuccess";
//#endregion
//#region node_modules/@mantine/core/esm/components/Input/InputWrapper/get-input-offsets/get-input-offsets.mjs
function Go(e, { hasDescription: t, hasError: n }) {
	let r = e.findIndex((e) => e === "input"), i = e.slice(0, r), a = e.slice(r + 1), o = t && i.includes("description") || n && i.includes("error");
	return {
		offsetBottom: t && a.includes("description") || n && a.includes("error"),
		offsetTop: o
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Input/InputWrapper/InputWrapper.mjs
var Ko = {
	labelElement: "label",
	inputContainer: (e) => e,
	inputWrapperOrder: [
		"label",
		"description",
		"input",
		"error"
	]
}, qo = K((e, { size: t }) => ({
	label: {
		"--input-label-size": U(t),
		"--input-asterisk-color": void 0
	},
	error: { "--input-error-size": t === void 0 ? void 0 : `calc(${U(t)} - ${P(2)})` },
	success: { "--input-success-size": t === void 0 ? void 0 : `calc(${U(t)} - ${P(2)})` },
	description: { "--input-description-size": t === void 0 ? void 0 : `calc(${U(t)} - ${P(2)})` }
})), Jo = Y((e) => {
	let t = q("InputWrapper", Ko, e), { classNames: n, className: r, style: i, styles: o, unstyled: s, vars: l, size: u, variant: d, __staticSelector: f, inputContainer: p, inputWrapperOrder: m, label: h, error: g, success: _, description: v, labelProps: y, descriptionProps: b, errorProps: x, successProps: S, labelElement: C, children: w, withAsterisk: E, id: D, required: O, __stylesApiProps: k, mod: ee, attributes: A, ...j } = t, M = J({
		name: ["InputWrapper", f],
		props: k || t,
		classes: Po,
		className: r,
		style: i,
		classNames: n,
		styles: o,
		unstyled: s,
		attributes: A,
		vars: l,
		varsResolver: qo
	}), N = {
		size: u,
		variant: d,
		__staticSelector: f
	}, P = Ne(D), te = typeof E == "boolean" ? E : O, ne = x?.id || `${P}-error`, F = S?.id || `${P}-success`, I = b?.id || `${P}-description`, re = P, L = !!g && typeof g != "boolean", R = !!_ && typeof _ != "boolean" && !g, z = !!v, ie = L && m.includes("error"), ae = R && m.includes("error"), oe = z && m.includes("description"), se = `${ie ? ne : ""} ${ae ? F : ""} ${oe ? I : ""}`, ce = se.trim().length > 0 ? se.trim() : void 0, le = y?.id || `${P}-label`, B = h && /* @__PURE__ */ T(Vo, {
		labelElement: C,
		id: le,
		htmlFor: re,
		required: te,
		...N,
		...y,
		children: h
	}, "label"), V = z && /* @__PURE__ */ T(Io, {
		...b,
		...N,
		size: b?.size || N.size,
		id: b?.id || I,
		children: v
	}, "description"), H = /* @__PURE__ */ T(a, { children: p(w) }, "input"), U = L && /* @__PURE__ */ c(Ro, {
		...x,
		...N,
		size: x?.size || N.size,
		key: "error",
		id: x?.id || ne
	}, g), ue = R && /* @__PURE__ */ c(Wo, {
		...S,
		...N,
		size: S?.size || N.size,
		key: "success",
		id: S?.id || F
	}, _), W = m.map((e) => {
		switch (e) {
			case "label": return B;
			case "input": return H;
			case "description": return V;
			case "error": return U || ue;
			default: return null;
		}
	});
	return /* @__PURE__ */ T(No, {
		value: {
			getStyles: M,
			describedBy: ce,
			inputId: re,
			labelId: le,
			...Go(m, {
				hasDescription: z,
				hasError: L || R
			})
		},
		children: /* @__PURE__ */ T(X, {
			variant: d,
			size: u,
			mod: [{
				error: !!g,
				success: !!_ && !g
			}, ee],
			id: C === "label" ? void 0 : D,
			...M("root"),
			...j,
			children: W
		})
	});
});
Jo.classes = Po, Jo.varsResolver = qo, Jo.displayName = "@mantine/core/InputWrapper";
//#endregion
//#region node_modules/@mantine/core/esm/components/Input/Input.mjs
var Yo = {
	variant: "default",
	leftSectionPointerEvents: "none",
	rightSectionPointerEvents: "none",
	withAria: !0,
	withErrorStyles: !0,
	withSuccessStyles: !0,
	size: "sm",
	loading: !1,
	loadingPosition: "right"
}, Xo = K((e, t, n) => ({ wrapper: {
	"--input-margin-top": n.offsetTop ? "calc(var(--mantine-spacing-xs) / 2)" : void 0,
	"--input-margin-bottom": n.offsetBottom ? "calc(var(--mantine-spacing-xs) / 2)" : void 0,
	"--input-height": B(t.size, "input-height"),
	"--input-fz": U(t.size),
	"--input-radius": t.radius === void 0 ? void 0 : H(t.radius),
	"--input-left-section-width": t.leftSectionWidth === void 0 ? void 0 : P(t.leftSectionWidth),
	"--input-right-section-width": t.rightSectionWidth === void 0 ? void 0 : P(t.rightSectionWidth),
	"--input-padding-y": t.multiline ? B(t.size, "input-padding-y") : void 0,
	"--input-left-section-pointer-events": t.leftSectionPointerEvents,
	"--input-right-section-pointer-events": t.rightSectionPointerEvents
} })), Zo = cr((e) => {
	let t = q("Input", Yo, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, required: s, __staticSelector: c, __stylesApiProps: l, size: d, wrapperProps: f, error: p, success: m, disabled: h, leftSection: g, leftSectionProps: _, leftSectionWidth: v, rightSection: y, rightSectionProps: b, rightSectionWidth: x, rightSectionPointerEvents: S, leftSectionPointerEvents: C, variant: w, vars: D, pointer: O, multiline: k, radius: ee, id: A, withAria: j, withErrorStyles: M, withSuccessStyles: N, mod: P, inputSize: te, attributes: ne, __clearSection: F, __clearable: I, __clearSectionMode: re, __defaultRightSection: L, loading: R, loadingPosition: z, __bottomSection: ie, __bottomSectionProps: ae, rootRef: oe, dir: se, ...ce } = t, { styleProps: le, rest: B } = Nn(ce), V = u(No), H = {
		offsetBottom: V?.offsetBottom,
		offsetTop: V?.offsetTop
	}, U = J({
		name: ["Input", c],
		props: l || t,
		classes: Po,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: ne,
		stylesCtx: H,
		rootSelector: "wrapper",
		vars: D,
		varsResolver: Xo
	}), ue = j ? {
		required: s,
		disabled: h,
		"aria-invalid": p ? !0 : void 0,
		"aria-describedby": V?.describedBy,
		id: V?.inputId || A
	} : {}, W = R ? /* @__PURE__ */ T(zi, { size: z === "left" ? "calc(var(--input-left-section-size) / 2)" : "calc(var(--input-right-section-size) / 2)" }) : null, de = R && z === "left" ? W : g, fe = Mo({
		__clearable: I,
		__clearSection: F,
		rightSection: R && z === "right" ? W : y,
		__defaultRightSection: L,
		size: d,
		__clearSectionMode: re
	});
	return /* @__PURE__ */ T(ko, {
		value: { size: d || "sm" },
		children: /* @__PURE__ */ E(X, {
			ref: oe,
			dir: se,
			...U("wrapper"),
			...le,
			...f,
			mod: [{
				error: !!p && M,
				success: !!m && !p && N,
				pointer: O,
				disabled: h,
				multiline: k,
				withRightSection: !!fe,
				withLeftSection: !!de,
				withBottomSection: !!ie
			}, P],
			variant: w,
			size: d,
			children: [
				de && /* @__PURE__ */ T("div", {
					..._,
					"data-position": "left",
					...U("section", {
						className: _?.className,
						style: _?.style
					}),
					children: de
				}),
				/* @__PURE__ */ T(X, {
					component: "input",
					...B,
					...ue,
					required: s,
					mod: {
						disabled: h,
						error: !!p && M,
						success: !!m && !p && N
					},
					variant: w,
					__size: te,
					...U("input")
				}),
				ie && /* @__PURE__ */ T("div", {
					...ae,
					...U("bottomSection", {
						className: ae?.className,
						style: ae?.style
					}),
					children: ie
				}),
				fe && /* @__PURE__ */ T("div", {
					...b,
					"data-position": "right",
					...U("section", {
						className: b?.className,
						style: b?.style
					}),
					children: fe
				})
			]
		})
	});
});
Zo.classes = Po, Zo.varsResolver = Xo, Zo.Wrapper = Jo, Zo.Label = Vo, Zo.Error = Ro, Zo.Success = Wo, Zo.Description = Io, Zo.Placeholder = Ho, Zo.ClearButton = Ao, Zo.displayName = "@mantine/core/Input";
//#endregion
//#region node_modules/@mantine/core/esm/components/Input/use-input-props.mjs
function Qo(e, t, n) {
	let r = q([
		"Input",
		"InputWrapper",
		e
	], t, n), { label: i, description: a, error: o, success: s, required: c, classNames: l, styles: u, className: d, unstyled: f, __staticSelector: p, __stylesApiProps: m, errorProps: h, successProps: g, labelProps: _, descriptionProps: v, wrapperProps: y, id: b, size: x, style: S, inputContainer: C, inputWrapperOrder: w, withAsterisk: T, variant: E, vars: D, mod: O, attributes: k, ...ee } = r, { styleProps: A, rest: j } = Nn(ee), M = {
		label: i,
		description: a,
		error: o,
		success: s,
		required: c,
		classNames: l,
		className: d,
		__staticSelector: p,
		__stylesApiProps: m || r,
		errorProps: h,
		successProps: g,
		labelProps: _,
		descriptionProps: v,
		unstyled: f,
		styles: u,
		size: x,
		style: S,
		inputContainer: C,
		inputWrapperOrder: w,
		withAsterisk: T,
		variant: E,
		id: b,
		mod: O,
		attributes: k,
		...y
	};
	return {
		...j,
		classNames: l,
		styles: u,
		unstyled: f,
		wrapperProps: {
			...M,
			...A
		},
		inputProps: {
			required: c,
			classNames: l,
			styles: u,
			unstyled: f,
			size: x,
			__staticSelector: p,
			__stylesApiProps: m || r,
			error: o,
			success: s,
			variant: E,
			id: b,
			attributes: k
		}
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/components/InputBase/InputBase.mjs
var $o = {
	__staticSelector: "InputBase",
	withAria: !0,
	size: "sm"
}, es = cr((e) => {
	let { inputProps: t, wrapperProps: n, ...r } = Qo("InputBase", $o, e);
	return /* @__PURE__ */ T(Zo.Wrapper, {
		...n,
		children: /* @__PURE__ */ T(Zo, {
			...t,
			...r
		})
	});
});
es.classes = {
	...Zo.classes,
	...Zo.Wrapper.classes
}, es.displayName = "@mantine/core/InputBase";
//#endregion
//#region node_modules/@mantine/core/esm/components/Accordion/Accordion.context.mjs
var [ts, ns] = re("Accordion component was not found in the tree");
//#endregion
//#region node_modules/@mantine/core/esm/components/Accordion/AccordionChevron.mjs
function rs({ style: e, size: t = 16, ...n }) {
	return /* @__PURE__ */ T("svg", {
		viewBox: "0 0 15 15",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		style: {
			...e,
			width: P(t),
			height: P(t),
			display: "block"
		},
		...n,
		children: /* @__PURE__ */ T("path", {
			d: "M3.13523 6.15803C3.3241 5.95657 3.64052 5.94637 3.84197 6.13523L7.5 9.56464L11.158 6.13523C11.3595 5.94637 11.6759 5.95657 11.8648 6.15803C12.0536 6.35949 12.0434 6.67591 11.842 6.86477L7.84197 10.6148C7.64964 10.7951 7.35036 10.7951 7.15803 10.6148L3.15803 6.86477C2.95657 6.67591 2.94637 6.35949 3.13523 6.15803Z",
			fill: "currentColor",
			fillRule: "evenodd",
			clipRule: "evenodd"
		})
	});
}
rs.displayName = "@mantine/core/AccordionChevron";
//#endregion
//#region node_modules/@mantine/core/esm/components/Accordion/AccordionItem.context.mjs
var [is, as] = re("Accordion.Item component was not found in the tree"), os = {
	root: "m_9bdbb667",
	panel: "m_df78851f",
	content: "m_4ba554d4",
	itemTitle: "m_8fa820a0",
	control: "m_4ba585b8",
	"control--default": "m_6939a5e9",
	"control--contained": "m_4271d21b",
	label: "m_df3ffa0f",
	chevron: "m_3f35ae96",
	icon: "m_9bd771fe",
	item: "m_9bd7b098",
	"item--default": "m_fe19b709",
	"item--contained": "m_1f921b3b",
	"item--filled": "m_2cdf939a",
	"item--separated": "m_9f59b069"
}, ss = Y((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, chevron: o, icon: s, onClick: c, onKeyDown: l, children: u, disabled: d, mod: f, ...p } = q("AccordionControl", null, e), { value: m } = as(), h = ns(), g = h.isItemActive(m), _ = typeof h.order == "number", v = `h${h.order}`, y = /* @__PURE__ */ E(li, {
		...h.getStyles("control", {
			className: n,
			classNames: t,
			style: r,
			styles: i,
			variant: h.variant
		}),
		unstyled: h.unstyled,
		mod: [
			"accordion-control",
			{
				active: g,
				"chevron-position": h.chevronPosition,
				disabled: d
			},
			f
		],
		onClick: (e) => {
			c?.(e), h.onChange(m);
		},
		type: "button",
		disabled: d,
		"aria-expanded": g,
		"aria-controls": h.getRegionId(m),
		id: h.getControlId(m),
		onKeyDown: oe({
			siblingSelector: "[data-accordion-control]",
			parentSelector: "[data-accordion]",
			activateOnFocus: !1,
			loop: h.loop,
			orientation: "vertical",
			onKeyDown: l
		}),
		...p,
		children: [
			/* @__PURE__ */ T(X, {
				component: "span",
				mod: {
					rotate: !h.disableChevronRotation && g,
					position: h.chevronPosition
				},
				...h.getStyles("chevron", {
					classNames: t,
					styles: i
				}),
				children: o || h.chevron
			}),
			/* @__PURE__ */ T("span", {
				...h.getStyles("label", {
					classNames: t,
					styles: i
				}),
				children: u
			}),
			s && /* @__PURE__ */ T(X, {
				component: "span",
				mod: { "chevron-position": h.chevronPosition },
				...h.getStyles("icon", {
					classNames: t,
					styles: i
				}),
				children: s
			})
		]
	});
	return _ ? /* @__PURE__ */ T(v, {
		...h.getStyles("itemTitle", {
			classNames: t,
			styles: i
		}),
		children: y
	}) : y;
});
ss.displayName = "@mantine/core/AccordionControl", ss.classes = os;
//#endregion
//#region node_modules/@mantine/core/esm/components/Accordion/AccordionItem/AccordionItem.mjs
var cs = Y((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, value: o, mod: s, ...c } = q("AccordionItem", null, e), l = ns();
	return /* @__PURE__ */ T(is, {
		value: { value: o },
		children: /* @__PURE__ */ T(X, {
			mod: [{ active: l.isItemActive(o) }, s],
			...l.getStyles("item", {
				className: n,
				classNames: t,
				styles: i,
				style: r,
				variant: l.variant
			}),
			...c
		})
	});
});
cs.displayName = "@mantine/core/AccordionItem", cs.classes = os;
//#endregion
//#region node_modules/@mantine/core/esm/components/Accordion/AccordionPanel/AccordionPanel.mjs
var ls = Y((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, children: o, keepMounted: s, keepMountedMode: c, ...l } = q("AccordionPanel", null, e), { value: u } = as(), d = ns();
	return /* @__PURE__ */ T(vr, {
		...d.getStyles("panel", {
			className: n,
			classNames: t,
			style: r,
			styles: i
		}),
		expanded: d.isItemActive(u),
		transitionDuration: d.transitionDuration ?? 200,
		role: "region",
		id: d.getRegionId(u),
		"aria-labelledby": d.getControlId(u),
		keepMounted: s ?? d.keepMounted,
		keepMountedMode: c ?? d.keepMountedMode,
		...l,
		children: /* @__PURE__ */ T("div", {
			...d.getStyles("content", {
				classNames: t,
				styles: i
			}),
			children: o
		})
	});
});
ls.displayName = "@mantine/core/AccordionPanel", ls.classes = os;
//#endregion
//#region node_modules/@mantine/core/esm/components/Accordion/Accordion.mjs
var us = {
	multiple: !1,
	loop: !0,
	disableChevronRotation: !1,
	disableCollapse: !1,
	chevronPosition: "right",
	variant: "default",
	chevronSize: "auto",
	chevronIconSize: 16,
	keepMountedMode: "activity"
}, ds = K((e, { transitionDuration: t, chevronSize: n, radius: r }) => ({ root: {
	"--accordion-transition-duration": t === void 0 ? void 0 : `${t}ms`,
	"--accordion-chevron-size": n === void 0 ? void 0 : P(n),
	"--accordion-radius": r === void 0 ? void 0 : H(r)
} })), fs = sr((e) => {
	let t = q("Accordion", us, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, children: c, multiple: l, value: u, defaultValue: d, onChange: f, id: p, loop: m, transitionDuration: h, disableChevronRotation: g, disableCollapse: _, chevronPosition: v, chevronSize: y, order: b, chevron: x, variant: S, radius: C, chevronIconSize: w, attributes: E, keepMounted: D, keepMountedMode: O, ...k } = t, ee = Ne(p), [A, j] = Re({
		value: u,
		defaultValue: d,
		finalValue: l ? [] : null,
		onChange: f
	}), M = (e) => Array.isArray(A) ? A.includes(e) : e === A, N = (e) => {
		if (!Array.isArray(A) && _ && e === A) return;
		let t = Array.isArray(A) ? A.includes(e) ? A.filter((t) => t !== e) : [...A, e] : e === A ? null : e;
		j(t);
	}, P = J({
		name: "Accordion",
		classes: os,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: E,
		vars: s,
		varsResolver: ds
	});
	return /* @__PURE__ */ T(ts, {
		value: {
			isItemActive: M,
			onChange: N,
			getControlId: L(`${ee}-control`, "Accordion.Item component was rendered with invalid value or without value"),
			getRegionId: L(`${ee}-panel`, "Accordion.Item component was rendered with invalid value or without value"),
			chevron: x === null ? null : x || /* @__PURE__ */ T(rs, { size: w }),
			transitionDuration: h,
			disableChevronRotation: g,
			chevronPosition: v,
			order: b,
			loop: m,
			getStyles: P,
			variant: S,
			unstyled: o,
			keepMounted: D,
			keepMountedMode: O
		},
		children: /* @__PURE__ */ T(X, {
			...P("root"),
			id: ee,
			...k,
			variant: S,
			"data-accordion": !0,
			children: c
		})
	});
});
fs.classes = os, fs.varsResolver = ds, fs.displayName = "@mantine/core/Accordion", fs.Item = cs, fs.Panel = ls, fs.Control = ss, fs.Chevron = rs;
//#endregion
//#region node_modules/@mantine/core/esm/components/Alert/Alert.module.mjs
var ps = {
	root: "m_66836ed3",
	wrapper: "m_a5d60502",
	body: "m_667c2793",
	title: "m_6a03f287",
	label: "m_698f4f23",
	icon: "m_667f2a6a",
	message: "m_7fa78076",
	closeButton: "m_87f54839"
}, ms = K((e, { radius: t, color: n, variant: r, autoContrast: i }) => {
	let a = e.variantColorResolver({
		color: n || e.primaryColor,
		theme: e,
		variant: r || "light",
		autoContrast: i
	});
	return { root: {
		"--alert-radius": t === void 0 ? void 0 : H(t),
		"--alert-bg": n || r ? a.background : void 0,
		"--alert-color": a.color,
		"--alert-bd": n || r ? a.border : void 0
	} };
}), hs = Y((e) => {
	let t = q("Alert", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, radius: c, color: l, title: u, children: d, id: f, icon: p, withCloseButton: m, onClose: h, closeButtonLabel: g, variant: _, autoContrast: v, role: y, attributes: b, ...x } = t, S = J({
		name: "Alert",
		classes: ps,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: b,
		vars: s,
		varsResolver: ms
	}), C = Ne(f), w = u && `${C}-title` || void 0, D = `${C}-body`;
	return /* @__PURE__ */ T(X, {
		id: C,
		...S("root", { variant: _ }),
		variant: _,
		...x,
		role: y || "alert",
		"aria-describedby": d ? D : void 0,
		"aria-labelledby": u ? w : void 0,
		children: /* @__PURE__ */ E("div", {
			...S("wrapper"),
			children: [
				p && /* @__PURE__ */ T("div", {
					...S("icon"),
					children: p
				}),
				/* @__PURE__ */ E("div", {
					...S("body"),
					children: [u && /* @__PURE__ */ T("div", {
						...S("title"),
						"data-with-close-button": m || void 0,
						children: /* @__PURE__ */ T("span", {
							id: w,
							...S("label"),
							children: u
						})
					}), d && /* @__PURE__ */ T("div", {
						id: D,
						...S("message"),
						"data-variant": _,
						children: d
					})]
				}),
				m && /* @__PURE__ */ T(Qi, {
					...S("closeButton"),
					onClick: h,
					variant: "transparent",
					size: 16,
					iconSize: 16,
					"aria-label": g,
					unstyled: o
				})
			]
		})
	});
});
hs.classes = ps, hs.varsResolver = ms, hs.displayName = "@mantine/core/Alert";
//#endregion
//#region node_modules/@mantine/core/esm/components/Text/Text.module.mjs
var gs = { root: "m_b6d8b162" };
//#endregion
//#region node_modules/@mantine/core/esm/components/Text/Text.mjs
function _s(e) {
	if (e === "start") return "start";
	if (e === "end" || e) return "end";
}
var vs = { inherit: !1 }, ys = K((e, { variant: t, lineClamp: n, gradient: r, size: i, textWrap: a }) => ({ root: {
	"--text-fz": U(i),
	"--text-lh": ue(i),
	"--text-gradient": t === "gradient" ? gt(r, e) : void 0,
	"--text-line-clamp": typeof n == "number" ? n.toString() : void 0,
	"--text-text-wrap": a
} })), Q = cr((e) => {
	let t = q("Text", vs, e), { lineClamp: n, truncate: r, inline: i, inherit: a, gradient: o, span: s, textWrap: c, __staticSelector: l, vars: u, className: d, style: f, classNames: p, styles: m, unstyled: h, variant: g, mod: _, size: v, attributes: y, ...b } = t, x = J({
		name: ["Text", l],
		props: t,
		classes: gs,
		className: d,
		style: f,
		classNames: p,
		styles: m,
		unstyled: h,
		attributes: y,
		vars: u,
		varsResolver: ys
	});
	return /* @__PURE__ */ T(X, {
		...x("root", { focusable: !0 }),
		component: s ? "span" : "p",
		variant: g,
		mod: [{
			truncate: _s(r),
			lineClamp: typeof n == "number",
			inline: i,
			inherit: a
		}, _],
		size: v,
		...b
	});
});
Q.classes = gs, Q.varsResolver = ys, Q.displayName = "@mantine/core/Text";
//#endregion
//#region node_modules/@mantine/core/esm/components/Combobox/get-parsed-combobox-data/get-parsed-combobox-data.mjs
function bs(e) {
	return typeof e == "string" ? {
		value: e,
		label: e
	} : typeof e == "object" && "value" in e && !("label" in e) ? {
		value: e.value,
		label: `${e.value}`,
		disabled: e.disabled
	} : typeof e == "object" && "group" in e ? {
		group: e.group,
		items: e.items.map((e) => bs(e))
	} : typeof e == "number" || typeof e == "bigint" || typeof e == "boolean" ? {
		value: e,
		label: `${e}`
	} : e;
}
function xs(e) {
	return e ? e.map((e) => bs(e)) : [];
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Combobox/Combobox.module.mjs
var Ss = {
	dropdown: "m_88b62a41",
	search: "m_985517d8",
	options: "m_b2821a6e",
	option: "m_92253aa5",
	empty: "m_2530cd1d",
	header: "m_858f94bd",
	footer: "m_82b967cb",
	group: "m_254f3e4f",
	groupLabel: "m_2bb2e9e5",
	chevron: "m_2943220b",
	optionsDropdownOption: "m_390b5f4",
	optionsDropdownCheckIcon: "m_8ee53fc2",
	optionsDropdownCheckPlaceholder: "m_a530ee0a"
}, Cs = { error: null }, ws = K((e, { size: t, color: n }) => ({ chevron: {
	"--combobox-chevron-size": B(t, "combobox-chevron-size"),
	"--combobox-chevron-color": n ? pt(n, e) : void 0
} })), Ts = Y((e) => {
	let t = q("ComboboxChevron", Cs, e), { size: n, error: r, style: i, className: a, classNames: o, styles: s, unstyled: c, vars: l, attributes: u, mod: d, ...f } = t, p = J({
		name: "ComboboxChevron",
		classes: Ss,
		props: t,
		style: i,
		className: a,
		classNames: o,
		styles: s,
		unstyled: c,
		vars: l,
		varsResolver: ws,
		attributes: u,
		rootSelector: "chevron"
	});
	return /* @__PURE__ */ T(X, {
		component: "svg",
		...f,
		...p("chevron"),
		size: n,
		viewBox: "0 0 15 15",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		mod: [
			"combobox-chevron",
			{ error: r },
			d
		],
		children: /* @__PURE__ */ T("path", {
			d: "M4.93179 5.43179C4.75605 5.60753 4.75605 5.89245 4.93179 6.06819C5.10753 6.24392 5.39245 6.24392 5.56819 6.06819L7.49999 4.13638L9.43179 6.06819C9.60753 6.24392 9.89245 6.24392 10.0682 6.06819C10.2439 5.89245 10.2439 5.60753 10.0682 5.43179L7.81819 3.18179C7.73379 3.0974 7.61933 3.04999 7.49999 3.04999C7.38064 3.04999 7.26618 3.0974 7.18179 3.18179L4.93179 5.43179ZM10.0682 9.56819C10.2439 9.39245 10.2439 9.10753 10.0682 8.93179C9.89245 8.75606 9.60753 8.75606 9.43179 8.93179L7.49999 10.8636L5.56819 8.93179C5.39245 8.75606 5.10753 8.75606 4.93179 8.93179C4.75605 9.10753 4.75605 9.39245 4.93179 9.56819L7.18179 11.8182C7.35753 11.9939 7.64245 11.9939 7.81819 11.8182L10.0682 9.56819Z",
			fill: "currentColor",
			fillRule: "evenodd",
			clipRule: "evenodd"
		})
	});
});
Ts.classes = Ss, Ts.varsResolver = ws, Ts.displayName = "@mantine/core/ComboboxChevron";
//#endregion
//#region node_modules/@mantine/core/esm/utils/InputsGroupFieldset/InputsGroupFieldset.mjs
function Es({ children: e, role: t }) {
	let n = u(No);
	return n ? /* @__PURE__ */ T("div", {
		role: t,
		"aria-labelledby": n.labelId,
		"aria-describedby": n.describedBy,
		children: e
	}) : /* @__PURE__ */ T(w, { children: e });
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Checkbox/CheckboxGroup/CheckboxGroup.mjs
var Ds = s(null), Os = { hiddenInputValuesSeparator: "," }, ks = sr(((e) => {
	let { value: t, defaultValue: n, onChange: r, size: i, wrapperProps: a, children: o, readOnly: s, name: c, hiddenInputValuesSeparator: l, hiddenInputProps: u, maxSelectedValues: d, disabled: f, ...p } = q("CheckboxGroup", Os, e), [m, h] = Re({
		value: t,
		defaultValue: n,
		finalValue: [],
		onChange: r
	}), g = (e) => {
		let t = typeof e == "string" ? e : e.currentTarget.value;
		if (s) return;
		let n = m.includes(t);
		!n && d && m.length >= d || h(n ? m.filter((e) => e !== t) : [...m, t]);
	}, _ = (e) => {
		if (f) return !0;
		if (!d) return !1;
		let t = m.includes(e), n = m.length >= d;
		return !t && n;
	}, v = m.join(l);
	return /* @__PURE__ */ T(Ds, {
		value: {
			value: m,
			onChange: g,
			size: i,
			isDisabled: _
		},
		children: /* @__PURE__ */ E(Zo.Wrapper, {
			size: i,
			...a,
			...p,
			labelElement: "div",
			__staticSelector: "CheckboxGroup",
			children: [/* @__PURE__ */ T(Es, {
				role: "group",
				children: o
			}), /* @__PURE__ */ T("input", {
				type: "hidden",
				name: c,
				value: v,
				...u
			})]
		})
	});
}));
ks.classes = Zo.Wrapper.classes, ks.displayName = "@mantine/core/CheckboxGroup";
//#endregion
//#region node_modules/@mantine/core/esm/components/Checkbox/CheckboxCard/CheckboxCard.module.mjs
var As = { card: "m_26775b0a" }, js = s(null), Ms = { withBorder: !0 }, Ns = K((e, { radius: t }) => ({ card: { "--card-radius": H(t) } })), Ps = Y((e) => {
	let t = q("CheckboxCard", Ms, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, checked: c, mod: l, withBorder: d, value: f, onClick: p, defaultChecked: m, onChange: h, indeterminate: g, attributes: _, ...v } = t, y = J({
		name: "CheckboxCard",
		classes: As,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: _,
		vars: s,
		varsResolver: Ns,
		rootSelector: "card"
	}), b = u(Ds), [x, S] = Re({
		value: typeof c == "boolean" ? c : b ? b.value.includes(f || "") : void 0,
		defaultValue: m,
		finalValue: !1,
		onChange: h
	});
	return /* @__PURE__ */ T(js, {
		value: {
			checked: x,
			indeterminate: g
		},
		children: /* @__PURE__ */ T(li, {
			mod: [{
				"with-border": d,
				checked: x,
				indeterminate: g
			}, l],
			...y("card"),
			...v,
			role: "checkbox",
			"aria-checked": g ? "mixed" : x,
			onClick: (e) => {
				p?.(e), b?.onChange(f || ""), S(!x);
			}
		})
	});
});
Ps.displayName = "@mantine/core/CheckboxCard", Ps.classes = As, Ps.varsResolver = Ns;
//#endregion
//#region node_modules/@mantine/core/esm/components/Checkbox/CheckIcon.mjs
function Fs({ size: e, style: t, ...n }) {
	let r = e === void 0 ? t : {
		width: P(e),
		height: P(e),
		...t
	};
	return /* @__PURE__ */ T("svg", {
		viewBox: "0 0 10 7",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		style: r,
		"aria-hidden": !0,
		...n,
		children: /* @__PURE__ */ T("path", {
			d: "M4 4.586L1.707 2.293A1 1 0 1 0 .293 3.707l3 3a.997.997 0 0 0 1.414 0l5-5A1 1 0 1 0 8.293.293L4 4.586z",
			fill: "currentColor",
			fillRule: "evenodd",
			clipRule: "evenodd"
		})
	});
}
function Is({ indeterminate: e, ...t }) {
	return e ? /* @__PURE__ */ T("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		fill: "none",
		viewBox: "0 0 32 6",
		"aria-hidden": !0,
		...t,
		children: /* @__PURE__ */ T("rect", {
			width: "32",
			height: "6",
			fill: "currentColor",
			rx: "3"
		})
	}) : /* @__PURE__ */ T(Fs, { ...t });
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Checkbox/CheckboxIndicator/CheckboxIndicator.module.mjs
var Ls = {
	indicator: "m_5e5256ee",
	icon: "m_1b1c543a",
	"indicator--outline": "m_76e20374"
}, Rs = {
	icon: Is,
	variant: "filled",
	radius: "sm"
}, zs = K((e, { radius: t, color: n, size: r, iconColor: i, variant: a, autoContrast: o }) => {
	let s = ft({
		color: n || e.primaryColor,
		theme: e
	}), c = s.isThemeColor && s.shade === void 0 ? `var(--mantine-color-${s.color}-outline)` : s.color;
	return { indicator: {
		"--checkbox-size": B(r, "checkbox-size"),
		"--checkbox-radius": t === void 0 ? void 0 : H(t),
		"--checkbox-color": a === "outline" ? c : pt(n, e),
		"--checkbox-icon-color": i ? pt(i, e) : Ct(o, e) ? bt({
			color: n,
			theme: e,
			autoContrast: o
		}) : void 0
	} };
}), Bs = Y((e) => {
	let t = q("CheckboxIndicator", Rs, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, icon: c, indeterminate: l, radius: d, color: f, iconColor: p, autoContrast: m, checked: h, mod: g, variant: _, disabled: v, attributes: y, ...b } = t, x = J({
		name: "CheckboxIndicator",
		classes: Ls,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: y,
		vars: s,
		varsResolver: zs,
		rootSelector: "indicator"
	}), S = u(js), C = typeof l == "boolean" ? l : S?.indeterminate, w = typeof h == "boolean" || typeof l == "boolean" ? h || l : S?.checked || S?.indeterminate || !1;
	return /* @__PURE__ */ T(X, {
		...x("indicator", { variant: _ }),
		variant: _,
		mod: [{
			checked: w,
			disabled: v
		}, g],
		...b,
		children: /* @__PURE__ */ T(c, {
			indeterminate: C,
			...x("icon")
		})
	});
});
Bs.displayName = "@mantine/core/CheckboxIndicator", Bs.classes = Ls, Bs.varsResolver = zs;
//#endregion
//#region node_modules/@mantine/core/esm/utils/InlineInput/InlineInput.module.mjs
var Vs = {
	root: "m_5f75b09e",
	body: "m_5f6e695e",
	labelWrapper: "m_d3ea56bb",
	label: "m_8ee546b8",
	description: "m_328f68c0",
	error: "m_8e8a99cc"
}, Hs = Vs;
function Us({ __staticSelector: e, __stylesApiProps: t, className: n, classNames: r, styles: i, unstyled: a, children: o, label: s, description: c, id: l, disabled: u, error: d, size: f, labelPosition: p = "left", bodyElement: m = "div", labelElement: h = "label", variant: g, style: _, vars: v, mod: y, attributes: b, ...x }) {
	let S = J({
		name: e,
		props: t,
		className: n,
		style: _,
		classes: Vs,
		classNames: r,
		styles: i,
		unstyled: a,
		attributes: b
	}), C = c ? `${l}-description` : void 0, w = d && typeof d != "boolean" ? `${l}-error` : void 0;
	return /* @__PURE__ */ T(X, {
		...S("root"),
		__vars: {
			"--label-fz": U(f),
			"--label-lh": B(f, "label-lh")
		},
		mod: [{ "label-position": p }, y],
		variant: g,
		size: f,
		...x,
		children: /* @__PURE__ */ E(X, {
			component: m,
			htmlFor: m === "label" ? l : void 0,
			...S("body"),
			children: [o, /* @__PURE__ */ E("div", {
				...S("labelWrapper"),
				"data-disabled": u || void 0,
				children: [
					s && /* @__PURE__ */ T(X, {
						component: h,
						htmlFor: h === "label" ? l : void 0,
						...S("label"),
						"data-disabled": u || void 0,
						children: s
					}),
					c && /* @__PURE__ */ T(Zo.Description, {
						id: C,
						size: f,
						__inheritStyles: !1,
						...S("description"),
						children: c
					}),
					d && typeof d != "boolean" && /* @__PURE__ */ T(Zo.Error, {
						id: w,
						size: f,
						__inheritStyles: !1,
						...S("error"),
						children: d
					})
				]
			})]
		})
	});
}
Us.displayName = "@mantine/core/InlineInput";
//#endregion
//#region node_modules/@mantine/core/esm/components/Checkbox/Checkbox.module.mjs
var Ws = {
	root: "m_bf2d988c",
	inner: "m_26062bec",
	input: "m_26063560",
	icon: "m_bf295423",
	"input--outline": "m_215c4542"
}, Gs = {
	labelPosition: "right",
	icon: Is,
	withErrorStyles: !0,
	variant: "filled",
	radius: "sm"
}, Ks = K((e, { radius: t, color: n, size: r, iconColor: i, variant: a, autoContrast: o }) => {
	let s = ft({
		color: n || e.primaryColor,
		theme: e
	}), c = s.isThemeColor && s.shade === void 0 ? `var(--mantine-color-${s.color}-outline)` : s.color;
	return { root: {
		"--checkbox-size": B(r, "checkbox-size"),
		"--checkbox-radius": t === void 0 ? void 0 : H(t),
		"--checkbox-color": a === "outline" ? c : pt(n, e),
		"--checkbox-icon-color": i ? pt(i, e) : Ct(o, e) ? bt({
			color: n,
			theme: e,
			autoContrast: o
		}) : void 0
	} };
}), qs = Y((e) => {
	let t = q("Checkbox", Gs, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, color: c, label: l, id: d, size: f, radius: m, wrapperProps: h, checked: g, labelPosition: _, description: y, error: b, disabled: x, variant: S, indeterminate: C, icon: w, rootRef: D, iconColor: O, onChange: k, autoContrast: ee, mod: A, attributes: j, readOnly: M, onClick: N, withErrorStyles: P, ref: te, ...ne } = t, F = v(null), I = u(Ds), re = f || I?.size, L = J({
		name: "Checkbox",
		props: t,
		classes: Ws,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: j,
		vars: s,
		varsResolver: Ks
	}), { styleProps: R, rest: z } = Nn(ne), ie = Ne(d), ae = [
		y ? `${ie}-description` : void 0,
		b && typeof b != "boolean" ? `${ie}-error` : void 0,
		z["aria-describedby"]
	].filter(Boolean).join(" ") || void 0, oe = {
		checked: I?.value.includes(z.value) ?? g,
		onChange: (e) => {
			M || (I?.onChange(e), k?.(e));
		}
	}, se = I?.isDisabled?.(z.value) ?? !1, ce = x || se;
	return p(() => {
		F.current && (F.current.indeterminate = C || !1, C ? F.current.setAttribute("data-indeterminate", "true") : F.current.removeAttribute("data-indeterminate"));
	}, [C]), /* @__PURE__ */ T(Us, {
		...L("root"),
		__staticSelector: "Checkbox",
		__stylesApiProps: t,
		id: ie,
		size: re,
		labelPosition: _,
		label: l,
		description: y,
		error: b,
		disabled: ce,
		classNames: n,
		styles: a,
		unstyled: o,
		"data-checked": oe.checked || g || void 0,
		variant: S,
		ref: D,
		mod: A,
		attributes: j,
		inert: z.inert,
		...R,
		...h,
		children: /* @__PURE__ */ E(X, {
			...L("inner"),
			mod: { labelPosition: _ },
			children: [/* @__PURE__ */ T(X, {
				component: "input",
				id: ie,
				ref: Le(F, te),
				mod: {
					error: !!b,
					"with-error-styles": P
				},
				...L("input", {
					focusable: !0,
					variant: S
				}),
				...z,
				...oe,
				"aria-describedby": ae,
				disabled: ce,
				inert: z.inert,
				type: "checkbox",
				onClick: (e) => {
					M && oe.checked === void 0 && e.preventDefault(), N?.(e);
				}
			}), /* @__PURE__ */ T(w, {
				indeterminate: C,
				...L("icon")
			})]
		})
	});
});
qs.classes = {
	...Ws,
	...Hs
}, qs.varsResolver = Ks, qs.displayName = "@mantine/core/Checkbox", qs.Group = ks, qs.Indicator = Bs, qs.Card = Ps;
//#endregion
//#region node_modules/@mantine/core/esm/components/Badge/Badge.module.mjs
var Js = {
	root: "m_347db0ec",
	"root--dot": "m_fbd81e3d",
	label: "m_5add502a",
	section: "m_91fdda9b"
}, Ys = K((e, { radius: t, color: n, gradient: r, variant: i, size: a, autoContrast: o, circle: s }) => {
	let c = e.variantColorResolver({
		color: n || e.primaryColor,
		theme: e,
		gradient: r,
		variant: i || "filled",
		autoContrast: o
	});
	return { root: {
		"--badge-height": B(a, "badge-height"),
		"--badge-padding-x": B(a, "badge-padding-x"),
		"--badge-fz": B(a, "badge-fz"),
		"--badge-radius": s || t === void 0 ? void 0 : H(t),
		"--badge-bg": n || i ? c.background : void 0,
		"--badge-color": n || i ? c.color : void 0,
		"--badge-bd": n || i ? c.border : void 0,
		"--badge-dot-color": i === "dot" ? pt(n, e) : void 0
	} };
}), Xs = cr((e) => {
	let t = q("Badge", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, radius: c, color: l, gradient: u, leftSection: d, rightSection: f, children: p, variant: m, fullWidth: h, autoContrast: g, circle: _, mod: v, attributes: y, ...b } = t, x = J({
		name: "Badge",
		props: t,
		classes: Js,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: y,
		vars: s,
		varsResolver: Ys
	});
	return /* @__PURE__ */ E(X, {
		variant: m,
		mod: [{
			block: h,
			circle: _,
			"with-right-section": !!f,
			"with-left-section": !!d
		}, v],
		...x("root", { variant: m }),
		...b,
		children: [
			d && /* @__PURE__ */ T("span", {
				...x("section"),
				"data-position": "left",
				children: d
			}),
			/* @__PURE__ */ T("span", {
				...x("label"),
				children: p
			}),
			f && /* @__PURE__ */ T("span", {
				...x("section"),
				"data-position": "right",
				children: f
			})
		]
	});
});
Xs.classes = Js, Xs.varsResolver = Ys, Xs.displayName = "@mantine/core/Badge";
//#endregion
//#region node_modules/@mantine/core/esm/components/Button/Button.module.mjs
var Zs = {
	root: "m_77c9d27d",
	inner: "m_80f1301b",
	label: "m_811560b9",
	section: "m_a74036a",
	loader: "m_a25b86ee",
	group: "m_80d6d844",
	groupSection: "m_70be2a01"
}, Qs = { orientation: "horizontal" }, $s = K((e, { borderWidth: t }) => ({ group: { "--button-border-width": P(t) } })), ec = Y((e) => {
	let t = q("ButtonGroup", Qs, e), { className: n, style: r, classNames: i, styles: a, unstyled: o, orientation: s, vars: c, borderWidth: l, mod: u, attributes: d, ...f } = q("ButtonGroup", Qs, e), p = J({
		name: "ButtonGroup",
		props: t,
		classes: Zs,
		className: n,
		style: r,
		classNames: i,
		styles: a,
		unstyled: o,
		attributes: d,
		vars: c,
		varsResolver: $s,
		rootSelector: "group"
	});
	return /* @__PURE__ */ T(X, {
		...p("group"),
		mod: [{ orientation: s }, u],
		role: "group",
		...f
	});
});
ec.classes = Zs, ec.varsResolver = $s, ec.displayName = "@mantine/core/ButtonGroup";
//#endregion
//#region node_modules/@mantine/core/esm/components/Button/ButtonGroupSection/ButtonGroupSection.mjs
var tc = K((e, { radius: t, color: n, gradient: r, variant: i, autoContrast: a, size: o }) => {
	let s = e.variantColorResolver({
		color: n || e.primaryColor,
		theme: e,
		gradient: r,
		variant: i || "filled",
		autoContrast: a
	});
	return { groupSection: {
		"--section-height": B(o, "section-height"),
		"--section-padding-x": B(o, "section-padding-x"),
		"--section-fz": o?.includes("compact") ? U(o.replace("compact-", "")) : U(o),
		"--section-radius": t === void 0 ? void 0 : H(t),
		"--section-bg": n || i ? s.background : void 0,
		"--section-color": s.color,
		"--section-bd": n || i ? s.border : void 0
	} };
}), nc = Y((e) => {
	let t = q("ButtonGroupSection", null, e), { className: n, style: r, classNames: i, styles: a, unstyled: o, vars: s, gradient: c, radius: l, autoContrast: u, attributes: d, ...f } = t, p = J({
		name: "ButtonGroupSection",
		props: t,
		classes: Zs,
		className: n,
		style: r,
		classNames: i,
		styles: a,
		unstyled: o,
		attributes: d,
		vars: s,
		varsResolver: tc,
		rootSelector: "groupSection"
	});
	return /* @__PURE__ */ T(X, {
		...p("groupSection"),
		...f
	});
});
nc.classes = Zs, nc.varsResolver = tc, nc.displayName = "@mantine/core/ButtonGroupSection";
//#endregion
//#region node_modules/@mantine/core/esm/components/Button/Button.mjs
var rc = {
	in: {
		opacity: 1,
		transform: `translate(-50%, calc(-50% + ${P(1)}))`
	},
	out: {
		opacity: 0,
		transform: "translate(-50%, -200%)"
	},
	common: { transformOrigin: "center" },
	transitionProperty: "transform, opacity"
}, ic = K((e, { radius: t, color: n, gradient: r, variant: i, size: a, justify: o, autoContrast: s }) => {
	let c = e.variantColorResolver({
		color: n || e.primaryColor,
		theme: e,
		gradient: r,
		variant: i || "filled",
		autoContrast: s
	});
	return { root: {
		"--button-justify": o,
		"--button-height": B(a, "button-height"),
		"--button-padding-x": B(a, "button-padding-x"),
		"--button-fz": a?.includes("compact") ? U(a.replace("compact-", "")) : U(a),
		"--button-radius": t === void 0 ? void 0 : H(t),
		"--button-bg": n || i ? c.background : void 0,
		"--button-hover": n || i ? c.hover : void 0,
		"--button-color": c.color,
		"--button-bd": n || i ? c.border : void 0,
		"--button-hover-color": n || i ? c.hoverColor : void 0
	} };
}), ac = cr((e) => {
	let t = q("Button", null, e), { style: n, vars: r, className: i, color: a, disabled: o, children: s, leftSection: c, rightSection: l, fullWidth: u, variant: d, radius: f, loading: p, loaderProps: m, gradient: h, classNames: g, styles: _, unstyled: v, "data-disabled": y, autoContrast: b, mod: x, attributes: S, ...C } = t, w = J({
		name: "Button",
		props: t,
		classes: Zs,
		className: i,
		style: n,
		classNames: g,
		styles: _,
		unstyled: v,
		attributes: S,
		vars: r,
		varsResolver: ic
	}), D = !!c, O = !!l;
	return /* @__PURE__ */ E(li, {
		...w("root", { active: !o && !p && !y }),
		unstyled: v,
		variant: d,
		disabled: o || p,
		mod: [{
			disabled: o || y,
			loading: p,
			block: u,
			"with-left-section": D,
			"with-right-section": O
		}, x],
		...C,
		children: [typeof p == "boolean" && /* @__PURE__ */ T(ki, {
			mounted: p,
			transition: rc,
			duration: 150,
			children: (e) => /* @__PURE__ */ T(X, {
				component: "span",
				...w("loader", { style: e }),
				"aria-hidden": !0,
				children: /* @__PURE__ */ T(zi, {
					color: "var(--button-color)",
					size: "calc(var(--button-height) / 1.8)",
					...m
				})
			})
		}), /* @__PURE__ */ E("span", {
			...w("inner"),
			children: [
				c && /* @__PURE__ */ T(X, {
					component: "span",
					...w("section"),
					mod: { position: "left" },
					children: c
				}),
				/* @__PURE__ */ T(X, {
					component: "span",
					mod: { loading: p },
					...w("label"),
					children: s
				}),
				l && /* @__PURE__ */ T(X, {
					component: "span",
					...w("section"),
					mod: { position: "right" },
					children: l
				})
			]
		})]
	});
});
ac.classes = Zs, ac.varsResolver = ic, ac.displayName = "@mantine/core/Button", ac.Group = ec, ac.GroupSection = nc;
//#endregion
//#region node_modules/@mantine/core/esm/components/Code/Code.module.mjs
var oc = { root: "m_b183c0a2" }, sc = K((e, { color: t }) => ({ root: { "--code-bg": t ? pt(t, e) : void 0 } })), cc = Y((e) => {
	let t = q("Code", null, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, color: c, block: l, mod: u, attributes: d, ...f } = t, p = J({
		name: "Code",
		props: t,
		classes: oc,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: d,
		vars: s,
		varsResolver: sc
	});
	return /* @__PURE__ */ T(X, {
		component: l ? "pre" : "code",
		mod: [{ block: l }, u],
		...p("root"),
		...f,
		dir: "ltr"
	});
});
cc.classes = oc, cc.varsResolver = sc, cc.displayName = "@mantine/core/Code";
//#endregion
//#region node_modules/@mantine/core/esm/components/Fieldset/Fieldset.module.mjs
var lc = {
	root: "m_e9408a47",
	"root--default": "m_84c9523a",
	"root--filled": "m_ef274e49",
	"root--unstyled": "m_eda993d3",
	legend: "m_90794832",
	"legend--unstyled": "m_74ca27fe"
}, uc = { variant: "default" }, dc = K((e, { radius: t }) => ({ root: { "--fieldset-radius": t === void 0 ? void 0 : H(t) } })), fc = Y((e) => {
	let t = q("Fieldset", uc, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, legend: c, variant: l, children: u, attributes: d, ...f } = t, p = J({
		name: "Fieldset",
		classes: lc,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: d,
		vars: s,
		varsResolver: dc
	});
	return /* @__PURE__ */ E(X, {
		component: "fieldset",
		variant: l,
		...p("root", { variant: l }),
		...f,
		children: [c && /* @__PURE__ */ T("legend", {
			...p("legend", { variant: l }),
			children: c
		}), u]
	});
});
fc.classes = lc, fc.varsResolver = dc, fc.displayName = "@mantine/core/Fieldset";
//#endregion
//#region node_modules/@mantine/core/esm/components/FileButton/FileButton.mjs
var pc = sr((e) => {
	let { onChange: t, children: n, multiple: r, accept: i, name: a, form: o, resetRef: s, disabled: c, capture: l, inputProps: u, ref: d, ...f } = q("FileButton", null, e), p = v(null), m = () => {
		!c && p.current?.click();
	};
	return Fe(s, () => {
		p.current && (p.current.value = "");
	}), /* @__PURE__ */ E(w, { children: [/* @__PURE__ */ T("input", {
		style: { display: "none" },
		type: "file",
		accept: i,
		multiple: r,
		onChange: (e) => {
			if (e.currentTarget.files === null) return t(r ? [] : null);
			t(r ? Array.from(e.currentTarget.files) : e.currentTarget.files[0] || null);
		},
		ref: Le(d, p),
		name: a,
		form: o,
		capture: l,
		...u
	}), n({
		onClick: m,
		...f
	})] });
});
pc.displayName = "@mantine/core/FileButton";
//#endregion
//#region node_modules/@mantine/core/esm/components/Textarea/Autosize.mjs
var mc = [
	"borderBottomWidth",
	"borderLeftWidth",
	"borderRightWidth",
	"borderTopWidth",
	"boxSizing",
	"fontFamily",
	"fontSize",
	"fontStyle",
	"fontWeight",
	"letterSpacing",
	"lineHeight",
	"paddingBottom",
	"paddingLeft",
	"paddingRight",
	"paddingTop",
	"tabSize",
	"textIndent",
	"textRendering",
	"textTransform",
	"width",
	"wordBreak",
	"wordSpacing",
	"scrollbarGutter"
], hc = {
	"min-height": "0",
	"max-height": "none",
	height: "0",
	visibility: "hidden",
	overflow: "hidden",
	position: "absolute",
	"z-index": "-1000",
	top: "0",
	right: "0",
	display: "block"
};
function gc(e) {
	Object.keys(hc).forEach((t) => {
		e.style.setProperty(t, hc[t], "important");
	});
}
function _c(e) {
	let t = window.getComputedStyle(e);
	if (t === null) return null;
	let n = {};
	for (let e of mc) n[e] = t[e];
	return n.boxSizing === "" ? null : {
		sizingStyle: n,
		paddingSize: parseFloat(n.paddingBottom) + parseFloat(n.paddingTop),
		borderSize: parseFloat(n.borderBottomWidth) + parseFloat(n.borderTopWidth)
	};
}
var vc = null;
function yc(e, t, n = 1, r = Infinity) {
	vc || (vc = document.createElement("textarea"), vc.setAttribute("tabindex", "-1"), vc.setAttribute("aria-hidden", "true"), vc.setAttribute("aria-label", "autosize measurement"), gc(vc)), vc.parentNode === null && document.body.appendChild(vc);
	let { paddingSize: i, borderSize: a, sizingStyle: o } = e, { boxSizing: s } = o;
	Object.keys(o).forEach((e) => {
		vc.style[e] = o[e];
	}), gc(vc), vc.value = t;
	let c = s === "border-box" ? vc.scrollHeight + a : vc.scrollHeight - i;
	vc.value = t, c = s === "border-box" ? vc.scrollHeight + a : vc.scrollHeight - i, vc.value = "x";
	let l = vc.scrollHeight - i, u = l * n;
	s === "border-box" && (u = u + i + a), c = Math.max(u, c);
	let d = l * r;
	return s === "border-box" && (d = d + i + a), c = Math.min(d, c), [c, l];
}
function bc({ maxRows: e, minRows: t, onChange: n, ref: r, ...i }) {
	let a = i.value !== void 0, o = v(null), s = Le(o, r), c = v(0), l = v(0), u = () => {
		let n = o.current;
		if (!n) return;
		let r = _c(n);
		if (!r) return;
		let [i] = yc(r, n.value || n.placeholder || "x", t, e);
		c.current !== i && (c.current = i, n.style.setProperty("height", `${i}px`, "important"));
	}, d = (e) => {
		a || u(), n?.(e);
	};
	return g(u), p(() => {
		let e = () => u();
		return window.addEventListener("resize", e), () => window.removeEventListener("resize", e);
	}, []), p(() => {
		let e = o.current;
		if (!e || typeof ResizeObserver > "u") return;
		l.current = e.offsetWidth;
		let t = new ResizeObserver(() => {
			o.current && o.current.offsetWidth !== l.current && (l.current = o.current.offsetWidth, u());
		});
		return t.observe(e), () => t.disconnect();
	}, []), p(() => {
		let e = () => u();
		return document.fonts.addEventListener("loadingdone", e), () => document.fonts.removeEventListener("loadingdone", e);
	}, []), p(() => {
		let e = (e) => {
			if (o.current?.form === e.target && !a) {
				let e = o.current.value;
				requestAnimationFrame(() => {
					o.current && e !== o.current.value && u();
				});
			}
		};
		return document.body.addEventListener("reset", e), () => document.body.removeEventListener("reset", e);
	}, [a]), /* @__PURE__ */ T("textarea", {
		rows: t,
		...i,
		onChange: d,
		ref: s
	});
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Textarea/Textarea.mjs
var xc = Y((e) => {
	let { autosize: t, maxRows: n, minRows: r, __staticSelector: i, resize: a, bottomSection: o, bottomSectionProps: s, ...c } = q([
		"Input",
		"InputWrapper",
		"Textarea"
	], null, e), l = t && Ke() !== "test", u = l ? {
		maxRows: n,
		minRows: r
	} : {};
	return /* @__PURE__ */ T(es, {
		component: l ? bc : "textarea",
		...c,
		__staticSelector: i || "Textarea",
		__bottomSection: o,
		__bottomSectionProps: s,
		multiline: !0,
		"data-no-overflow": t && n === void 0 || void 0,
		__vars: { "--input-resize": a },
		...u
	});
});
xc.classes = es.classes, xc.displayName = "@mantine/core/Textarea";
//#endregion
//#region node_modules/@mantine/core/esm/components/Modal/Modal.context.mjs
var [Sc, Cc] = re("Modal component was not found in tree"), wc = {
	root: "m_9df02822",
	content: "m_54c44539",
	inner: "m_1f958f16",
	header: "m_d0e2b9cd"
}, Tc = Y((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, ...o } = q("ModalBody", null, e), s = Cc();
	return /* @__PURE__ */ T(yo, {
		...s.getStyles("body", {
			classNames: t,
			style: r,
			styles: i,
			className: n
		}),
		...o
	});
});
Tc.classes = wc, Tc.displayName = "@mantine/core/ModalBody";
//#endregion
//#region node_modules/@mantine/core/esm/components/Modal/ModalCloseButton.mjs
var Ec = Y((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, ...o } = q("ModalCloseButton", null, e), s = Cc();
	return /* @__PURE__ */ T(bo, {
		...s.getStyles("close", {
			classNames: t,
			style: r,
			styles: i,
			className: n
		}),
		...o
	});
});
Ec.classes = wc, Ec.displayName = "@mantine/core/ModalCloseButton";
//#endregion
//#region node_modules/@mantine/core/esm/components/Modal/ModalContent.mjs
var Dc = Y((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, children: o, __hidden: s, ...c } = q("ModalContent", null, e), l = Cc(), u = l.scrollAreaComponent || Oo;
	return /* @__PURE__ */ T(xo, {
		...l.getStyles("content", {
			className: n,
			style: r,
			styles: i,
			classNames: t
		}),
		innerProps: l.getStyles("inner", {
			className: n,
			style: r,
			styles: i,
			classNames: t
		}),
		"data-full-screen": l.fullScreen || void 0,
		"data-modal-content": !0,
		"data-hidden": s || void 0,
		...c,
		children: /* @__PURE__ */ T(u, {
			style: { maxHeight: l.fullScreen ? "100dvh" : `calc(100dvh - (${P(l.yOffset)} * 2))` },
			children: o
		})
	});
});
Dc.classes = wc, Dc.displayName = "@mantine/core/ModalContent";
//#endregion
//#region node_modules/@mantine/core/esm/components/Modal/ModalHeader.mjs
var Oc = Y((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, ...o } = q("ModalHeader", null, e), s = Cc();
	return /* @__PURE__ */ T(So, {
		...s.getStyles("header", {
			classNames: t,
			style: r,
			styles: i,
			className: n
		}),
		...o
	});
});
Oc.classes = wc, Oc.displayName = "@mantine/core/ModalHeader";
//#endregion
//#region node_modules/@mantine/core/esm/components/Modal/ModalOverlay.mjs
var kc = Y((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, ...o } = q("ModalOverlay", null, e), s = Cc();
	return /* @__PURE__ */ T(To, {
		...s.getStyles("overlay", {
			classNames: t,
			style: r,
			styles: i,
			className: n
		}),
		...o
	});
});
kc.classes = wc, kc.displayName = "@mantine/core/ModalOverlay";
//#endregion
//#region node_modules/@mantine/core/esm/components/Modal/ModalRoot.mjs
var Ac = {
	__staticSelector: "Modal",
	closeOnClickOutside: !0,
	withinPortal: !0,
	lockScroll: !0,
	trapFocus: !0,
	returnFocus: !0,
	closeOnEscape: !0,
	keepMounted: !1,
	zIndex: ce("modal"),
	transitionProps: {
		duration: 200,
		transition: "fade-down"
	},
	yOffset: "5dvh"
}, jc = K((e, { radius: t, size: n, yOffset: r, xOffset: i }) => ({ root: {
	"--modal-radius": t === void 0 ? void 0 : H(t),
	"--modal-size": B(n, "modal-size"),
	"--modal-y-offset": P(r),
	"--modal-x-offset": P(i)
} })), Mc = Y((e) => {
	let t = q("ModalRoot", Ac, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, yOffset: c, scrollAreaComponent: l, radius: u, fullScreen: d, centered: f, xOffset: p, __staticSelector: m, attributes: h, ...g } = t, _ = J({
		name: m,
		classes: wc,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: h,
		vars: s,
		varsResolver: jc
	});
	return /* @__PURE__ */ T(Sc, {
		value: {
			yOffset: c,
			scrollAreaComponent: l,
			getStyles: _,
			fullScreen: d
		},
		children: /* @__PURE__ */ T(go, {
			..._("root"),
			"data-full-screen": d || void 0,
			"data-centered": f || void 0,
			"data-offset-scrollbars": l === ai.Autosize || void 0,
			unstyled: o,
			...g
		})
	});
});
Mc.classes = wc, Mc.varsResolver = jc, Mc.displayName = "@mantine/core/ModalRoot";
//#endregion
//#region node_modules/@mantine/core/esm/components/Modal/ModalStack.mjs
var Nc = s(null);
function Pc({ children: e }) {
	let [t, n] = y([]), [r, i] = y(ce("modal"));
	return /* @__PURE__ */ T(Nc, {
		value: {
			stack: t,
			addModal: (e, t) => {
				n((t) => [.../* @__PURE__ */ new Set([...t, e])]), i((e) => typeof t == "number" && typeof e == "number" ? Math.max(e, t) : e);
			},
			removeModal: (e) => n((t) => t.filter((t) => t !== e)),
			getZIndex: (e) => `calc(${r} + ${t.indexOf(e)} + 1)`,
			currentId: t[t.length - 1],
			maxZIndex: r
		},
		children: e
	});
}
Pc.displayName = "@mantine/core/ModalStack";
//#endregion
//#region node_modules/@mantine/core/esm/components/Modal/ModalTitle.mjs
var Fc = Y((e) => {
	let { classNames: t, className: n, style: r, styles: i, vars: a, ...o } = q("ModalTitle", null, e), s = Cc();
	return /* @__PURE__ */ T(Do, {
		...s.getStyles("title", {
			classNames: t,
			style: r,
			styles: i,
			className: n
		}),
		...o
	});
});
Fc.classes = wc, Fc.displayName = "@mantine/core/ModalTitle";
//#endregion
//#region node_modules/@mantine/core/esm/components/Modal/Modal.mjs
var Ic = {
	closeOnClickOutside: !0,
	withinPortal: !0,
	lockScroll: !0,
	trapFocus: !0,
	returnFocus: !0,
	closeOnEscape: !0,
	keepMounted: !1,
	zIndex: ce("modal"),
	transitionProps: {
		duration: 200,
		transition: "fade-down"
	},
	withOverlay: !0,
	withCloseButton: !0
}, Lc = Y((e) => {
	let { title: t, withOverlay: n, overlayProps: r, withCloseButton: i, closeButtonProps: a, children: o, radius: s, opened: c, stackId: l, zIndex: d, ...f } = q("Modal", Ic, e), m = u(Nc), h = !!t || i, g = m && l ? {
		closeOnEscape: m.currentId === l,
		trapFocus: m.currentId === l,
		zIndex: m.getZIndex(l)
	} : {}, _ = n === !1 ? !1 : l && m ? m.currentId === l : c;
	return p(() => {
		m && l && (c ? m.addModal(l, d || ce("modal")) : m.removeModal(l));
	}, [
		c,
		l,
		d
	]), /* @__PURE__ */ E(Mc, {
		radius: s,
		opened: c,
		zIndex: m && l ? m.getZIndex(l) : d,
		...f,
		...g,
		children: [n && /* @__PURE__ */ T(kc, {
			visible: _,
			transitionProps: m && l ? { duration: 0 } : void 0,
			...r
		}), /* @__PURE__ */ E(Dc, {
			radius: s,
			__hidden: m && l && c ? l !== m.currentId : !1,
			children: [h && /* @__PURE__ */ E(Oc, { children: [t && /* @__PURE__ */ T(Fc, { children: t }), i && /* @__PURE__ */ T(Ec, { ...a })] }), /* @__PURE__ */ T(Tc, { children: o })]
		})]
	});
});
Lc.classes = wc, Lc.displayName = "@mantine/core/Modal", Lc.Root = Mc, Lc.Overlay = kc, Lc.Content = Dc, Lc.Body = Tc, Lc.Header = Oc, Lc.Title = Fc, Lc.CloseButton = Ec, Lc.Stack = Pc;
//#endregion
//#region node_modules/@mantine/core/esm/components/NativeSelect/NativeSelectOption.mjs
function Rc(e) {
	return "group" in e;
}
function zc({ data: e }) {
	if (Rc(e)) {
		let t = e.items.map((e) => /* @__PURE__ */ T(zc, { data: e }, e.value));
		return /* @__PURE__ */ T("optgroup", {
			label: e.group,
			children: t
		});
	}
	let { value: t, label: n, ...r } = e;
	return /* @__PURE__ */ T("option", {
		value: e.value,
		...r,
		children: e.label
	});
}
zc.displayName = "@mantine/core/NativeSelectOption";
//#endregion
//#region node_modules/@mantine/core/esm/components/NativeSelect/NativeSelect.mjs
var Bc = {
	size: "sm",
	rightSectionPointerEvents: "none"
}, Vc = Y((e) => {
	let { data: t, children: n, size: r, error: i, rightSection: a, unstyled: o, ...s } = q([
		"Input",
		"InputWrapper",
		"NativeSelect"
	], Bc, e), c = xs(t).map((e, t) => /* @__PURE__ */ T(zc, { data: e }, t));
	return /* @__PURE__ */ T(es, {
		component: "select",
		...s,
		__staticSelector: "NativeSelect",
		size: r,
		pointer: !0,
		error: i,
		unstyled: o,
		rightSection: a || /* @__PURE__ */ T(Ts, {
			size: r,
			error: i,
			unstyled: o
		}),
		children: n || c
	});
});
Vc.classes = es.classes, Vc.displayName = "@mantine/core/NativeSelect";
//#endregion
//#region node_modules/react-number-format/dist/react-number-format.es.js
function Hc(e, t) {
	var n = {};
	for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
	if (e != null && typeof Object.getOwnPropertySymbols == "function") for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++) t.indexOf(r[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (n[r[i]] = e[r[i]]);
	return n;
}
var Uc;
(function(e) {
	e.event = "event", e.props = "prop";
})(Uc ||= {});
function Wc() {}
function Gc(e) {
	var t, n = void 0;
	return function() {
		for (var r = [], i = arguments.length; i--;) r[i] = arguments[i];
		return t && r.length === t.length && r.every(function(e, n) {
			return e === t[n];
		}) ? n : (t = r, n = e.apply(void 0, r), n);
	};
}
function Kc(e) {
	return !!(e || "").match(/\d/);
}
function qc(e) {
	return e == null;
}
function Jc(e) {
	return typeof e == "number" && isNaN(e);
}
function Yc(e) {
	return qc(e) || Jc(e) || typeof e == "number" && !isFinite(e);
}
function Xc(e) {
	return e.replace(/[-[\]/{}()*+?.\\^$|]/g, "\\$&");
}
function Zc(e) {
	switch (e) {
		case "lakh": return /(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?/g;
		case "wan": return /(\d)(?=(\d{4})+(?!\d))/g;
		default: return /(\d)(?=(\d{3})+(?!\d))/g;
	}
}
function Qc(e, t, n) {
	var r = Zc(n), i = e.search(/[1-9]/);
	return i = i === -1 ? e.length : i, e.substring(0, i) + e.substring(i, e.length).replace(r, "$1" + t);
}
function $c(e) {
	var t = v(e);
	return t.current = e, v(function() {
		for (var e = [], n = arguments.length; n--;) e[n] = arguments[n];
		return t.current.apply(t, e);
	}).current;
}
function el(e, t) {
	t === void 0 && (t = !0);
	var n = e[0] === "-", r = n && t;
	e = e.replace("-", "");
	var i = e.split(".");
	return {
		beforeDecimal: i[0],
		afterDecimal: i[1] || "",
		hasNegation: n,
		addNegation: r
	};
}
function tl(e) {
	if (!e) return e;
	var t = e[0] === "-";
	t && (e = e.substring(1, e.length));
	var n = e.split("."), r = n[0].replace(/^0+/, "") || "0", i = n[1] || "";
	return (t ? "-" : "") + r + (i ? "." + i : "");
}
function nl(e, t, n) {
	for (var r = "", i = n ? "0" : "", a = 0; a <= t - 1; a++) r += e[a] || i;
	return r;
}
function rl(e, t) {
	return Array(t + 1).join(e);
}
function il(e) {
	var t = e + "", n = t[0] === "-" ? "-" : "";
	n && (t = t.substring(1));
	var r = t.split(/[eE]/g), i = r[0], a = r[1];
	if (a = Number(a), !a) return n + i;
	i = i.replace(".", "");
	var o = 1 + a, s = i.length;
	return o < 0 ? i = "0." + rl("0", Math.abs(o)) + i : o >= s ? i += rl("0", o - s) : i = (i.substring(0, o) || "0") + "." + i.substring(o), n + i;
}
function al(e, t, n) {
	if (["", "-"].indexOf(e) !== -1) return e;
	var r = (e.indexOf(".") !== -1 || n) && t, i = el(e), a = i.beforeDecimal, o = i.afterDecimal, s = i.hasNegation, c = parseFloat("0." + (o || "0")), l = (o.length <= t ? "0." + o : c.toFixed(t)).split("."), u = a;
	a && Number(l[0]) && (u = a.split("").reverse().reduce(function(e, t, n) {
		return e.length > n ? (Number(e[0]) + Number(t)).toString() + e.substring(1, e.length) : t + e;
	}, l[0]));
	var d = nl(l[1] || "", t, n), f = s ? "-" : "", p = r ? "." : "";
	return "" + f + u + p + d;
}
function ol(e, t) {
	if (e.value = e.value, e !== null) {
		if (e.createTextRange) {
			var n = e.createTextRange();
			return n.move("character", t), n.select(), !0;
		}
		return e.selectionStart || e.selectionStart === 0 ? (e.focus(), e.setSelectionRange(t, t), !0) : (e.focus(), !1);
	}
}
var sl = Gc(function(e, t) {
	for (var n = 0, r = 0, i = e.length, a = t.length; e[n] === t[n] && n < i;) n++;
	for (; e[i - 1 - r] === t[a - 1 - r] && a - r > n && i - r > n;) r++;
	return {
		from: {
			start: n,
			end: i - r
		},
		to: {
			start: n,
			end: a - r
		}
	};
}), cl = function(e, t) {
	var n = Math.min(e.selectionStart, t);
	return {
		from: {
			start: n,
			end: e.selectionEnd
		},
		to: {
			start: n,
			end: t
		}
	};
};
function ll(e, t, n) {
	return Math.min(Math.max(e, t), n);
}
function ul(e) {
	return Math.max(e.selectionStart, e.selectionEnd);
}
function dl() {
	return typeof navigator < "u" && !(navigator.platform && /iPhone|iPod/.test(navigator.platform));
}
function fl(e) {
	return {
		from: {
			start: 0,
			end: 0
		},
		to: {
			start: 0,
			end: e.length
		},
		lastValue: ""
	};
}
function pl(e) {
	var t = e.currentValue, n = e.formattedValue, r = e.currentValueIndex, i = e.formattedValueIndex;
	return t[r] === n[i];
}
function ml(e, t, n, r, i, a, o) {
	o === void 0 && (o = pl);
	var s = i.findIndex(function(e) {
		return e;
	}), c = e.slice(0, s);
	!t && !n.startsWith(c) && (t = c, n = c + n, r += c.length);
	for (var l = n.length, u = e.length, d = {}, f = Array(l), p = 0; p < l; p++) {
		f[p] = -1;
		for (var m = 0, h = u; m < h; m++) if (o({
			currentValue: n,
			lastValue: t,
			formattedValue: e,
			currentValueIndex: p,
			formattedValueIndex: m
		}) && d[m] !== !0) {
			f[p] = m, d[m] = !0;
			break;
		}
	}
	for (var g = r; g < l && (f[g] === -1 || !a(n[g]));) g++;
	var _ = g === l || f[g] === -1 ? u : f[g];
	for (g = r - 1; g > 0 && f[g] === -1;) g--;
	var v = g === -1 || f[g] === -1 ? 0 : f[g] + 1;
	return v > _ ? _ : r - v < _ - r ? v : _;
}
function hl(e, t, n, r) {
	var i = e.length;
	if (t = ll(t, 0, i), r === "left") {
		for (; t >= 0 && !n[t];) t--;
		t === -1 && (t = n.indexOf(!0));
	} else {
		for (; t <= i && !n[t];) t++;
		t > i && (t = n.lastIndexOf(!0));
	}
	return t === -1 && (t = i), t;
}
function gl(e) {
	for (var t = Array.from({ length: e.length + 1 }).map(function() {
		return !0;
	}), n = 0, r = t.length; n < r; n++) t[n] = !!(Kc(e[n]) || Kc(e[n - 1]));
	return t;
}
function _l(e, t, n, r, i, a) {
	a === void 0 && (a = Wc);
	var o = $c(function(e, t) {
		var n, a;
		return Yc(e) ? (a = "", n = "") : typeof e == "number" || t ? (a = typeof e == "number" ? il(e) : e, n = r(a)) : (a = i(e, void 0), n = r(a)), {
			formattedValue: n,
			numAsString: a
		};
	}), s = y(function() {
		return o(qc(e) ? t : e, n);
	}), c = s[0], l = s[1], u = $c(function(e, t) {
		e.formattedValue !== c.formattedValue && l({
			formattedValue: e.formattedValue,
			numAsString: e.value
		}), a(e, t);
	}), d = e, f = n;
	qc(e) && (d = c.numAsString, f = !0);
	var m = o(d, f);
	return _(function() {
		l(m);
	}, [m.formattedValue]), p(function() {
		if (!qc(t) && qc(e) && c.formattedValue !== "") {
			var n = parseFloat(c.numAsString);
			u({
				formattedValue: c.formattedValue,
				value: c.numAsString,
				floatValue: isNaN(n) ? void 0 : n
			}, {
				event: void 0,
				source: Uc.props
			});
		}
	}, []), [c, u];
}
function vl(e) {
	return e.replace(/[^0-9]/g, "");
}
function yl(e) {
	return e;
}
function bl(e) {
	var t = e.type;
	t === void 0 && (t = "text");
	var r = e.displayType;
	r === void 0 && (r = "input");
	var i = e.customInput, a = e.renderText, o = e.getInputRef, s = e.format;
	s === void 0 && (s = yl);
	var c = e.removeFormatting;
	c === void 0 && (c = vl);
	var l = e.defaultValue, u = e.valueIsNumericString, d = e.onValueChange, f = e.isAllowed, m = e.onChange;
	m === void 0 && (m = Wc);
	var h = e.onKeyDown;
	h === void 0 && (h = Wc);
	var _ = e.onMouseUp;
	_ === void 0 && (_ = Wc);
	var b = e.onFocus;
	b === void 0 && (b = Wc);
	var x = e.onBlur;
	x === void 0 && (x = Wc);
	var S = e.value, C = e.getCaretBoundary;
	C === void 0 && (C = gl);
	var w = e.isValidInputCharacter;
	w === void 0 && (w = Kc);
	var T = e.isCharacterSame, E = Hc(e, [
		"type",
		"displayType",
		"customInput",
		"renderText",
		"getInputRef",
		"format",
		"removeFormatting",
		"defaultValue",
		"valueIsNumericString",
		"onValueChange",
		"isAllowed",
		"onChange",
		"onKeyDown",
		"onMouseUp",
		"onFocus",
		"onBlur",
		"value",
		"getCaretBoundary",
		"isValidInputCharacter",
		"isCharacterSame"
	]), D = _l(S, l, !!u, s, c, d), O = D[0], k = O.formattedValue, ee = O.numAsString, A = D[1], j = v(), M = v({
		formattedValue: k,
		numAsString: ee
	}), N = function(e, t) {
		M.current = {
			formattedValue: e.formattedValue,
			numAsString: e.value
		}, A(e, t);
	}, P = y(!1), te = P[0], ne = P[1], F = v(null), I = v({
		setCaretTimeout: null,
		focusTimeout: null
	});
	p(function() {
		return ne(!0), function() {
			clearTimeout(I.current.setCaretTimeout), clearTimeout(I.current.focusTimeout);
		};
	}, []);
	var re = s, L = function(e, t) {
		var n = parseFloat(t);
		return {
			formattedValue: e,
			value: t,
			floatValue: isNaN(n) ? void 0 : n
		};
	}, R = function(e, t, n) {
		(e.selectionStart !== 0 || e.selectionEnd !== e.value.length) && (ol(e, t), I.current.setCaretTimeout = setTimeout(function() {
			e.value === n && e.selectionStart !== t && ol(e, t);
		}, 0));
	}, z = function(e, t, n) {
		return hl(e, t, C(e), n);
	}, ie = function(e, t, n) {
		var r = C(t), i = ml(t, k, e, n, r, w, T);
		return i = hl(t, i, r), i;
	}, ae = function(e) {
		var t = e.formattedValue;
		t === void 0 && (t = "");
		var n = e.input, r = e.source, i = e.event, a = e.numAsString, o;
		if (n) {
			var s = e.inputValue || n.value, c = ul(n);
			n.value = t, o = ie(s, t, c), o !== void 0 && R(n, o, t);
		}
		t !== k && N(L(t, a), {
			event: i,
			source: r
		});
	};
	p(function() {
		var e = M.current, t = e.formattedValue, n = e.numAsString;
		(k !== t || ee !== n) && N(L(k, ee), {
			event: void 0,
			source: Uc.props
		});
	}, [k, ee]);
	var oe = F.current ? ul(F.current) : void 0;
	(typeof window < "u" ? g : p)(function() {
		var e = F.current;
		if (k !== M.current.formattedValue && e) {
			var t = ie(M.current.formattedValue, k, oe);
			e.value = k, R(e, t, k);
		}
	}, [k]);
	var se = function(e, t, n) {
		var r = t.target, i = j.current ? cl(j.current, r.selectionEnd) : sl(k, e), a = Object.assign(Object.assign({}, i), { lastValue: k }), o = c(e, a), s = re(o);
		if (o = c(s, void 0), f && !f(L(s, o))) {
			var l = t.target, u = ie(e, k, ul(l));
			return l.value = k, R(l, u, k), !1;
		}
		return ae({
			formattedValue: s,
			numAsString: o,
			inputValue: e,
			event: t,
			source: n,
			input: t.target
		}), !0;
	}, ce = function(e, t) {
		t === void 0 && (t = 0), j.current = {
			selectionStart: e.selectionStart,
			selectionEnd: e.selectionEnd + t
		};
	}, le = function(e) {
		var t = e.target.value;
		se(t, e, Uc.event) && m(e), j.current = void 0;
	}, B = function(e) {
		var t = e.target, n = e.key, r = t.selectionStart, i = t.selectionEnd, a = t.value;
		a === void 0 && (a = "");
		var o;
		n === "ArrowLeft" || n === "Backspace" ? o = Math.max(r - 1, 0) : n === "ArrowRight" ? o = Math.min(r + 1, a.length) : n === "Delete" && (o = r);
		var s = 0;
		n === "Delete" && r === i && (s = 1);
		var c = n === "ArrowLeft" || n === "ArrowRight";
		if (o === void 0 || r !== i && !c) {
			h(e), ce(t, s);
			return;
		}
		var l = o;
		c ? (l = z(a, o, n === "ArrowLeft" ? "left" : "right"), l !== o && e.preventDefault()) : n === "Delete" && !w(a[o]) ? l = z(a, o, "right") : n === "Backspace" && !w(a[o]) && (l = z(a, o, "left")), l !== o && R(t, l, a), h(e), ce(t, s);
	}, V = function(e) {
		var t = e.target, n = function() {
			var e = t.selectionStart, n = t.selectionEnd, r = t.value;
			if (r === void 0 && (r = ""), e === n) {
				var i = z(r, e);
				i !== e && R(t, i, r);
			}
		};
		n(), requestAnimationFrame(function() {
			n();
		}), _(e), ce(t);
	}, H = function(e) {
		e.persist && e.persist();
		var t = e.target, n = e.currentTarget;
		F.current = t, I.current.focusTimeout = setTimeout(function() {
			var r = t.selectionStart, i = t.selectionEnd, a = t.value;
			a === void 0 && (a = "");
			var o = z(a, r);
			o !== r && (r !== 0 || i !== a.length) && R(t, o, a), b(Object.assign(Object.assign({}, e), { currentTarget: n }));
		}, 0);
	}, U = function(e) {
		F.current = null, clearTimeout(I.current.focusTimeout), clearTimeout(I.current.setCaretTimeout), x(e);
	}, ue = te && dl() ? "numeric" : void 0, W = Object.assign({ inputMode: ue }, E, {
		type: t,
		value: k,
		onChange: le,
		onKeyDown: B,
		onMouseUp: V,
		onFocus: H,
		onBlur: U
	});
	if (r === "text") return a ? n.createElement(n.Fragment, null, a(k, E) || null) : n.createElement("span", Object.assign({}, E, { ref: o }), k);
	if (i) {
		var de = i;
		return n.createElement(de, Object.assign({}, W, { ref: o }));
	}
	return n.createElement("input", Object.assign({}, W, { ref: o }));
}
function xl(e, t) {
	var n = t.decimalScale, r = t.fixedDecimalScale, i = t.prefix;
	i === void 0 && (i = "");
	var a = t.suffix;
	a === void 0 && (a = "");
	var o = t.allowNegative, s = t.thousandsGroupStyle;
	if (s === void 0 && (s = "thousand"), e === "" || e === "-") return e;
	var c = Sl(t), l = c.thousandSeparator, u = c.decimalSeparator, d = n !== 0 && e.indexOf(".") !== -1 || n && r, f = el(e, o), p = f.beforeDecimal, m = f.afterDecimal, h = f.addNegation;
	return n !== void 0 && (m = nl(m, n, !!r)), l && (p = Qc(p, l, s)), i && (p = i + p), a && (m += a), h && (p = "-" + p), e = p + (d && u || "") + m, e;
}
function Sl(e) {
	var t = e.decimalSeparator;
	t === void 0 && (t = ".");
	var n = e.thousandSeparator, r = e.allowedDecimalSeparators;
	return n === !0 && (n = ","), r ||= [t, "."], {
		decimalSeparator: t,
		thousandSeparator: n,
		allowedDecimalSeparators: r
	};
}
function Cl(e, t) {
	e === void 0 && (e = "");
	var n = /* @__PURE__ */ RegExp("(-)"), r = /* @__PURE__ */ RegExp("(-)(.)*(-)"), i = n.test(e), a = r.test(e);
	return e = e.replace(/-/g, ""), i && !a && t && (e = "-" + e), e;
}
function wl(e, t) {
	return RegExp("(^-)|[0-9]|" + Xc(e), t ? "g" : void 0);
}
function Tl(e, t, n) {
	return e === "" || !t?.match(/\d/) && !n?.match(/\d/) && typeof e == "string" && !isNaN(Number(e));
}
function El(e, t, n) {
	var r;
	t === void 0 && (t = fl(e));
	var i = n.allowNegative, a = n.prefix;
	a === void 0 && (a = "");
	var o = n.suffix;
	o === void 0 && (o = "");
	var s = n.decimalScale, c = t.from, l = t.to, u = l.start, d = l.end, f = Sl(n), p = f.allowedDecimalSeparators, m = f.decimalSeparator, h = e[d] === m;
	if (Kc(e) && (e === a || e === o) && t.lastValue === "") return e;
	if (d - u === 1 && p.indexOf(e[u]) !== -1) {
		var g = s === 0 ? "" : m;
		e = e.substring(0, u) + g + e.substring(u + 1, e.length);
	}
	var _ = function(e, t, n) {
		var r = !1, i = !1;
		a.startsWith("-") ? r = !1 : e.startsWith("--") ? (r = !1, i = !0) : o.startsWith("-") && e.length === o.length ? r = !1 : e[0] === "-" && (r = !0);
		var s = +!!r;
		return i && (s = 2), s && (e = e.substring(s), t -= s, n -= s), {
			value: e,
			start: t,
			end: n,
			hasNegation: r
		};
	}, v = _(e, u, d), y = v.hasNegation;
	r = v, e = r.value, u = r.start, d = r.end;
	var b = _(t.lastValue, c.start, c.end), x = b.start, S = b.end, C = b.value, w = e.substring(u, d);
	e.length && C.length && (x > C.length - o.length || S < a.length) && !(w && o.startsWith(w)) && (e = C);
	var T = 0;
	e.startsWith(a) ? T += a.length : u < a.length && (T = u), e = e.substring(T), d -= T;
	var E = e.length, D = e.length - o.length;
	e.endsWith(o) ? E = D : (d > D || d > e.length - o.length) && (E = d), e = e.substring(0, E), e = Cl(y ? "-" + e : e, i), e = (e.match(wl(m, !0)) || []).join("");
	var O = e.indexOf(m);
	e = e.replace(new RegExp(Xc(m), "g"), function(e, t) {
		return t === O ? "." : "";
	});
	var k = el(e, i), ee = k.beforeDecimal, A = k.afterDecimal, j = k.addNegation;
	return l.end - l.start < c.end - c.start && ee === "" && h && !parseFloat(A) && (e = j ? "-" : ""), e;
}
function Dl(e, t) {
	var n = t.prefix;
	n === void 0 && (n = "");
	var r = t.suffix;
	r === void 0 && (r = "");
	var i = Array.from({ length: e.length + 1 }).map(function() {
		return !0;
	}), a = e[0] === "-";
	i.fill(!1, 0, Math.min(n.length + +!!a, e.length));
	var o = e.length;
	return i.fill(!1, o - r.length + 1, o + 1), i;
}
function Ol(e) {
	var t = Sl(e), n = t.thousandSeparator, r = t.decimalSeparator, i = e.prefix;
	i === void 0 && (i = "");
	var a = e.allowNegative;
	if (a === void 0 && (a = !0), n === r) throw Error("\n        Decimal separator can't be same as thousand separator.\n        thousandSeparator: " + n + " (thousandSeparator = {true} is same as thousandSeparator = \",\")\n        decimalSeparator: " + r + " (default value for decimalSeparator is .)\n     ");
	return i.startsWith("-") && a && (console.error("\n      Prefix can't start with '-' when allowNegative is true.\n      prefix: " + i + "\n      allowNegative: " + a + "\n    "), a = !1), Object.assign(Object.assign({}, e), { allowNegative: a });
}
function kl(e) {
	e = Ol(e), e.decimalSeparator, e.allowedDecimalSeparators, e.thousandsGroupStyle;
	var t = e.suffix, n = e.allowNegative, r = e.allowLeadingZeros, i = e.onKeyDown;
	i === void 0 && (i = Wc);
	var a = e.onBlur;
	a === void 0 && (a = Wc);
	var o = e.thousandSeparator, s = e.decimalScale, c = e.fixedDecimalScale, l = e.prefix;
	l === void 0 && (l = "");
	var u = e.defaultValue, d = e.value, f = e.valueIsNumericString, p = e.onValueChange, m = Hc(e, [
		"decimalSeparator",
		"allowedDecimalSeparators",
		"thousandsGroupStyle",
		"suffix",
		"allowNegative",
		"allowLeadingZeros",
		"onKeyDown",
		"onBlur",
		"thousandSeparator",
		"decimalScale",
		"fixedDecimalScale",
		"prefix",
		"defaultValue",
		"value",
		"valueIsNumericString",
		"onValueChange"
	]), h = Sl(e), g = h.decimalSeparator, _ = h.allowedDecimalSeparators, v = function(t) {
		return xl(t, e);
	}, y = function(t, n) {
		return El(t, n, e);
	}, b = qc(d) ? u : d, x = f ?? Tl(b, l, t);
	qc(d) ? qc(u) || (x ||= typeof u == "number") : x ||= typeof d == "number";
	var S = function(e) {
		return Yc(e) ? e : (typeof e == "number" && (e = il(e)), x && typeof s == "number" ? al(e, s, !!c) : e);
	}, C = _l(S(d), S(u), !!x, v, y, p), w = C[0], T = w.numAsString, E = w.formattedValue, D = C[1];
	return Object.assign(Object.assign({}, m), {
		value: E,
		valueIsNumericString: !1,
		isValidInputCharacter: function(e) {
			return e === g || Kc(e);
		},
		isCharacterSame: function(e) {
			var t = e.currentValue, n = e.lastValue, r = e.formattedValue, i = e.currentValueIndex, a = e.formattedValueIndex, o = t[i], u = r[a], f = sl(n, t).to, p = function(e) {
				return y(e).indexOf(".") + l.length;
			};
			return d === 0 && c && s && t[f.start] === g && p(t) < i && p(r) > a ? !1 : i >= f.start && i < f.end && _ && _.includes(o) && u === g ? !0 : o === u;
		},
		onValueChange: D,
		format: v,
		removeFormatting: y,
		getCaretBoundary: function(t) {
			return Dl(t, e);
		},
		onKeyDown: function(e) {
			var t = e.target, r = e.key, a = t.selectionStart, u = t.selectionEnd, d = t.value;
			if (d === void 0 && (d = ""), (r === "Backspace" || r === "Delete") && u < l.length && d !== "-") {
				e.preventDefault();
				return;
			}
			if (a !== u) {
				i(e);
				return;
			}
			r === "Backspace" && d[0] === "-" && a === l.length + 1 && n && ol(t, 1), s && c && (r === "Backspace" && d[a - 1] === g ? (ol(t, a - 1), e.preventDefault()) : r === "Delete" && d[a] === g && e.preventDefault()), _?.includes(r) && d[a] === g && ol(t, a + 1);
			var f = o === !0 ? "," : o;
			r === "Backspace" && d[a - 1] === f && ol(t, a - 1), r === "Delete" && d[a] === f && ol(t, a + 1), i(e);
		},
		onBlur: function(t) {
			var n = T;
			n.match(/\d/g) || (n = ""), r || (n = tl(n)), c && s && (n = al(n, s, c)), n !== T && D({
				formattedValue: xl(n, e),
				value: n,
				floatValue: parseFloat(n)
			}, {
				event: t,
				source: Uc.event
			}), a(t);
		}
	});
}
function Al(e) {
	var t = kl(e);
	return n.createElement(bl, Object.assign({}, t));
}
//#endregion
//#region node_modules/@mantine/core/esm/components/NumberInput/NumberInputChevron.mjs
function jl({ direction: e, style: t, ...n }) {
	return /* @__PURE__ */ T("svg", {
		style: {
			width: "var(--ni-chevron-size)",
			height: "var(--ni-chevron-size)",
			transform: e === "up" ? "rotate(180deg)" : void 0,
			...t
		},
		viewBox: "0 0 15 15",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		...n,
		children: /* @__PURE__ */ T("path", {
			d: "M3.13523 6.15803C3.3241 5.95657 3.64052 5.94637 3.84197 6.13523L7.5 9.56464L11.158 6.13523C11.3595 5.94637 11.6759 5.95657 11.8648 6.15803C12.0536 6.35949 12.0434 6.67591 11.842 6.86477L7.84197 10.6148C7.64964 10.7951 7.35036 10.7951 7.15803 10.6148L3.15803 6.86477C2.95657 6.67591 2.94637 6.35949 3.13523 6.15803Z",
			fill: "currentColor",
			fillRule: "evenodd",
			clipRule: "evenodd"
		})
	});
}
//#endregion
//#region node_modules/@mantine/core/esm/components/NumberInput/NumberInput.module.mjs
var Ml = {
	root: "m_e2f5cd4e",
	controls: "m_95e17d22",
	control: "m_80b4b171"
}, Nl = /^(0\.0*|-0(\.0*)?)$/, Pl = /^-?0\d+(\.\d+)?\.?$/, Fl = /\.\d*0$/, Il = /^-?\d+\.$/;
function Ll(e) {
	return typeof e == "string" && e !== "" && !Number.isNaN(Number(e));
}
function Rl(e) {
	return typeof e == "bigint";
}
function zl(e) {
	return typeof e == "number" ? e < 2 ** 53 - 1 : e === "" || Ll(e) && Number(e) < 2 ** 53 - 1;
}
function Bl(e, t) {
	return e === "" || e === "-" || !t && e.startsWith("-") ? !1 : /^-?\d+$/.test(e);
}
function Vl(e, t) {
	return typeof e == "bigint" || e === "" || Bl(e, t);
}
function Hl(e) {
	if (!/^-?\d+$/.test(e)) return null;
	try {
		return BigInt(e);
	} catch {
		return null;
	}
}
function Ul(e) {
	if (typeof e == "bigint") return e;
	if (typeof e == "number" && Number.isFinite(e) && Number.isInteger(e)) return BigInt(e);
}
function Wl(e, t, n) {
	return t !== void 0 && e < t ? t : n !== void 0 && e > n ? n : e;
}
function Gl(e) {
	return e.toString().replace(".", "").length;
}
function Kl(e, t) {
	return (typeof e == "number" ? e < 2 ** 53 - 1 : !Number.isNaN(Number(e))) && !Number.isNaN(e) && Gl(t) < 14 && t !== "";
}
function ql(e, t, n) {
	return e === void 0 || (t === void 0 || e >= t) && (n === void 0 || e <= n);
}
var Jl = {
	size: "sm",
	step: 1,
	clampBehavior: "blur",
	allowDecimal: !0,
	allowNegative: !0,
	withKeyboardEvents: !0,
	allowLeadingZeros: !0,
	trimLeadingZeroesOnBlur: !0,
	startValue: 0,
	allowedDecimalSeparators: [".", ","]
}, Yl = K((e, { size: t }) => ({ controls: { "--ni-chevron-size": B(t, "ni-chevron-size") } }));
function Xl(e, t, n) {
	let r = e.toString(), i = Il.test(r), a = r.replace(/^0+(?=\d)/, ""), o = parseFloat(a);
	if (Number.isNaN(o)) return a;
	if (o > 2 ** 53 - 1) return t === void 0 ? a : t;
	let s = me(o, n, t);
	return i ? `${s.toString().replace(/^0+(?=\d)/, "")}.` : s;
}
function Zl(e, t) {
	if (e === "" || e === "-") return e;
	let n = Hl(e);
	return n === null ? e : t.clampBehavior === "blur" ? Wl(n, t.min, t.max) : n;
}
var Ql = sr((e) => {
	let t = q([
		"Input",
		"InputWrapper",
		"NumberInput"
	], Jl, e), { className: n, classNames: r, styles: i, unstyled: a, vars: o, onChange: s, onValueChange: c, value: l, defaultValue: u, max: d, min: f, step: p, hideControls: m, rightSection: h, isAllowed: g, clampBehavior: _, onBlur: y, allowDecimal: b, decimalScale: x, onKeyDown: S, onKeyDownCapture: C, handlersRef: w, startValue: D, disabled: O, rightSectionPointerEvents: k, allowNegative: ee, readOnly: A, size: j, rightSectionWidth: M, stepHoldInterval: N, stepHoldDelay: P, allowLeadingZeros: te, withKeyboardEvents: ne, trimLeadingZeroesOnBlur: F, allowedDecimalSeparators: I, selectAllOnFocus: re, onMinReached: L, onMaxReached: R, onFocus: z, attributes: ie, ref: ae, ...oe } = t, se = ee ?? !0, ce = te ?? !0, B = J({
		name: "NumberInput",
		classes: Ml,
		props: t,
		classNames: r,
		styles: i,
		unstyled: a,
		attributes: ie,
		vars: o,
		varsResolver: Yl
	}), { resolvedClassNames: V, resolvedStyles: H } = pn({
		classNames: r,
		styles: i,
		props: t
	}), U = v(Rl(l) || Rl(u) ? "bigint" : "number");
	Rl(l) ? U.current = "bigint" : typeof l == "number" && (U.current = "number");
	let ue = U.current === "bigint", [W, de] = Re({
		value: l,
		defaultValue: u,
		finalValue: "",
		onChange: s
	}), fe = P !== void 0 && N !== void 0, pe = v(null), he = v(null), ge = v(0), _e = typeof f == "number" ? f : void 0, ve = typeof d == "number" ? d : void 0, ye = typeof p == "number" ? p : Jl.step, be = typeof D == "number" ? D : Jl.startValue, xe = Ul(f), G = Ul(d), Se = Ul(p) ?? BigInt(1), Ce = Ul(D) ?? BigInt(0), we = (e) => !Bl(e, se) || ce && Pl.test(e) ? e : Hl(e) ?? e, Te = (e) => {
		let t = Number(e);
		return Number.isSafeInteger(t) ? t : void 0;
	}, Ee = (e, t) => {
		t.source === "event" && de(ue ? we(e.value) : Kl(e.floatValue, e.value) && !Nl.test(e.value) && !(ce && Pl.test(e.value)) && !Fl.test(e.value) && !Il.test(e.value) ? e.floatValue : e.value), c?.(e, t);
	}, De = (e) => {
		let t = String(e).match(/(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/);
		return t ? Math.max(0, (t[1] ? t[1].length : 0) - (t[2] ? +t[2] : 0)) : 0;
	}, Oe = (e) => {
		pe.current && e !== void 0 && pe.current.setSelectionRange(e, e);
	}, ke = v(le);
	ke.current = () => {
		if (ue) {
			if (!Vl(W, se)) return;
			let e, t = W;
			if (typeof t == "bigint") {
				let n = t + Se;
				G !== void 0 && n > G && R?.(), e = G !== void 0 && n > G ? G : n;
			} else if (typeof t == "string" && t !== "") {
				let n = Hl(t);
				if (n === null) return;
				let r = n + Se;
				G !== void 0 && r > G && R?.(), e = G !== void 0 && r > G ? G : r;
			} else e = Wl(Ce, xe, G);
			let n = e.toString();
			de(e), c?.({
				floatValue: Te(e),
				formattedValue: n,
				value: n
			}, { source: "increment" }), setTimeout(() => Oe(pe.current?.value.length), 0);
			return;
		}
		if (!zl(W)) return;
		let e, t = De(W), n = De(ye), r = Math.max(t, n), i = 10 ** r;
		if (!Ll(W) && (typeof W != "number" || Number.isNaN(W))) e = me(be, _e, ve);
		else if (ve !== void 0) {
			let t = (Math.round(Number(W) * i) + Math.round(ye * i)) / i;
			t > ve && R?.(), e = t <= ve ? t : ve;
		} else e = (Math.round(Number(W) * i) + Math.round(ye * i)) / i;
		let a = e.toFixed(r);
		de(parseFloat(a)), c?.({
			floatValue: parseFloat(a),
			formattedValue: a,
			value: a
		}, { source: "increment" }), setTimeout(() => Oe(pe.current?.value.length), 0);
	};
	let Ae = v(le);
	Ae.current = () => {
		if (ue) {
			if (!Vl(W, se)) return;
			let e, t = xe === void 0 ? se ? void 0 : BigInt(0) : xe, n = W;
			if (typeof n == "bigint") {
				let r = n - Se;
				t !== void 0 && r < t && L?.(), e = t !== void 0 && r < t ? t : r;
			} else if (typeof n == "string" && n !== "") {
				let r = Hl(n);
				if (r === null) return;
				let i = r - Se;
				t !== void 0 && i < t && L?.(), e = t !== void 0 && i < t ? t : i;
			} else e = Wl(Ce, t, G);
			let r = e.toString();
			de(e), c?.({
				floatValue: Te(e),
				formattedValue: r,
				value: r
			}, { source: "decrement" }), setTimeout(() => Oe(pe.current?.value.length), 0);
			return;
		}
		if (!zl(W)) return;
		let e, t = _e === void 0 ? se ? -(2 ** 53 - 1) : 0 : _e, n = De(W), r = De(ye), i = Math.max(n, r), a = 10 ** i;
		if (!Ll(W) && typeof W != "number" || Number.isNaN(W)) e = me(be, t, ve);
		else {
			let n = (Math.round(Number(W) * a) - Math.round(ye * a)) / a;
			t !== void 0 && n < t && L?.(), e = t !== void 0 && n < t ? t : n;
		}
		let o = e.toFixed(i);
		de(parseFloat(o)), c?.({
			floatValue: parseFloat(o),
			formattedValue: o,
			value: o
		}, { source: "decrement" }), setTimeout(() => Oe(pe.current?.value.length), 0);
	};
	let je = (e) => {
		let t = e.clipboardData.getData("text"), n = oe.decimalSeparator || ".", r = (I || [".", ","]).filter((e) => e !== n);
		if (r.some((e) => t.includes(e))) {
			e.preventDefault();
			let i = t;
			r.forEach((e) => {
				i = i.split(e).join(n);
			});
			let a = pe.current;
			if (a) {
				let e = a.selectionStart ?? 0, t = a.selectionEnd ?? 0, n = a.value, r = n.substring(0, e) + i + n.substring(t);
				(Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set)?.call(a, r), a.dispatchEvent(new Event("change", { bubbles: !0 }));
				let o = e + i.length;
				setTimeout(() => Oe(o), 0);
			}
		}
		oe.onPaste?.(e);
	}, Me = (e) => {
		S?.(e), !(A || !ne) && (e.key === "ArrowUp" && (e.preventDefault(), ke.current?.()), e.key === "ArrowDown" && (e.preventDefault(), Ae.current?.()));
	}, Ne = (e) => {
		if (C?.(e), e.key === "Backspace") {
			let t = pe.current;
			t && t.selectionStart === 0 && t.selectionStart === t.selectionEnd && (e.preventDefault(), window.setTimeout(() => Oe(0), 0));
		}
	}, Pe = (e) => {
		re && window.setTimeout(() => pe.current?.select(), 0), z?.(e);
	}, Ie = (e) => {
		let t = W;
		ue ? (_ === "blur" && typeof t == "bigint" && (t = Wl(t, xe, G)), F && typeof t == "string" && (t = Zl(t, {
			min: xe,
			max: G,
			clampBehavior: _
		}))) : (_ === "blur" && typeof t == "number" && (t = me(t, _e, ve)), F && typeof t == "string" && De(t) < 15 && (t = Xl(t, ve, _e))), W !== t && de(t), y?.(e);
	};
	Fe(w, {
		increment: ke.current,
		decrement: Ae.current
	});
	let ze = (e) => {
		e ? ke.current?.() : Ae.current?.(), ge.current += 1;
	}, Be = (e) => {
		if (ze(e), fe) {
			let t = typeof N == "number" ? N : N(ge.current);
			he.current = window.setTimeout(() => Be(e), t);
		}
	}, Ve = (e, t) => {
		e.preventDefault(), pe.current?.focus(), ze(t), fe && (he.current = window.setTimeout(() => Be(t), P));
	}, He = () => {
		he.current && window.clearTimeout(he.current), he.current = null, ge.current = 0;
	}, Ue = /* @__PURE__ */ E("div", {
		...B("controls"),
		children: [/* @__PURE__ */ T(li, {
			...B("control"),
			tabIndex: -1,
			"aria-hidden": !0,
			disabled: O || typeof W == "number" && ve !== void 0 && W >= ve || typeof W == "bigint" && G !== void 0 && W >= G,
			mod: { direction: "up" },
			onMouseDown: (e) => e.preventDefault(),
			onPointerDown: (e) => {
				Ve(e, !0);
			},
			onPointerUp: He,
			onPointerLeave: He,
			children: /* @__PURE__ */ T(jl, { direction: "up" })
		}), /* @__PURE__ */ T(li, {
			...B("control"),
			tabIndex: -1,
			"aria-hidden": !0,
			disabled: O || typeof W == "number" && _e !== void 0 && W <= _e || typeof W == "bigint" && xe !== void 0 && W <= xe,
			mod: { direction: "down" },
			onMouseDown: (e) => e.preventDefault(),
			onPointerDown: (e) => {
				Ve(e, !1);
			},
			onPointerUp: He,
			onPointerLeave: He,
			children: /* @__PURE__ */ T(jl, { direction: "down" })
		})]
	});
	return /* @__PURE__ */ T(es, {
		component: Al,
		allowNegative: ee,
		className: Ye(Ml.root, n),
		size: j,
		...oe,
		inputMode: ue ? "numeric" : "decimal",
		readOnly: A,
		disabled: O,
		value: typeof W == "bigint" ? W.toString() : W,
		getInputRef: Le(ae, pe),
		onValueChange: Ee,
		rightSection: m || A || !(ue ? Vl(W, se) : zl(W)) ? h : h || Ue,
		classNames: V,
		styles: H,
		unstyled: a,
		__staticSelector: "NumberInput",
		decimalScale: ue ? 0 : b ? x : 0,
		onPaste: je,
		onFocus: Pe,
		onKeyDown: Me,
		onKeyDownCapture: Ne,
		rightSectionPointerEvents: k ?? (O ? "none" : void 0),
		rightSectionWidth: M ?? `var(--ni-right-section-width-${j || "sm"})`,
		allowLeadingZeros: te,
		allowedDecimalSeparators: I,
		onBlur: Ie,
		attributes: ie,
		isAllowed: (e) => {
			if (!(!g || g(e))) return !1;
			if (_ !== "strict") return !0;
			if (!ue) return ql(e.floatValue, _e, ve);
			if (e.value === "" || e.value === "-") return !0;
			let t = Hl(e.value);
			return t === null || (xe === void 0 || t >= xe) && (G === void 0 || t <= G);
		}
	});
});
Ql.classes = {
	...es.classes,
	...Ml
}, Ql.varsResolver = Yl, Ql.displayName = "@mantine/core/NumberInput";
//#endregion
//#region node_modules/@mantine/core/esm/components/SimpleGrid/SimpleGridVariables.mjs
function $l(e) {
	if (e !== void 0) return typeof e == "number" ? P(e) : e;
}
function eu({ spacing: e, verticalSpacing: t, cols: n, minColWidth: r, autoRows: i, selector: a }) {
	let o = Xt(), s = t === void 0 ? e : t, c = r !== void 0, l = ne({
		"--sg-spacing-x": V(pe(e)),
		"--sg-spacing-y": V(pe(s)),
		"--sg-auto-rows": i,
		...c ? { "--sg-min-col-width": $l(r) } : { "--sg-cols": pe(n)?.toString() }
	}), u = D(o.breakpoints).reduce((t, r) => (t[r] || (t[r] = {}), typeof e == "object" && e[r] !== void 0 && (t[r]["--sg-spacing-x"] = V(e[r])), typeof s == "object" && s[r] !== void 0 && (t[r]["--sg-spacing-y"] = V(s[r])), !c && typeof n == "object" && n[r] !== void 0 && (t[r]["--sg-cols"] = n[r]), t), {}), d = fe(D(u), o.breakpoints).filter((e) => D(u[e.value]).length > 0).map((e) => ({
		query: `(min-width: ${o.breakpoints[e.value]})`,
		styles: u[e.value]
	}));
	return /* @__PURE__ */ T(An, {
		styles: l,
		media: d,
		selector: a
	});
}
function tu(e) {
	return typeof e == "object" && e ? D(e) : [];
}
function nu(e) {
	return e.sort((e, t) => j(e) - j(t));
}
function ru({ spacing: e, verticalSpacing: t, cols: n, minColWidth: r }) {
	return nu(Array.from(/* @__PURE__ */ new Set([
		...tu(e),
		...tu(t),
		...r === void 0 ? tu(n) : []
	])));
}
function iu({ spacing: e, verticalSpacing: t, cols: n, minColWidth: r, autoRows: i, selector: a }) {
	let o = t === void 0 ? e : t, s = r !== void 0, c = ne({
		"--sg-spacing-x": V(pe(e)),
		"--sg-spacing-y": V(pe(o)),
		"--sg-auto-rows": i,
		...s ? { "--sg-min-col-width": $l(r) } : { "--sg-cols": pe(n)?.toString() }
	}), l = ru({
		spacing: e,
		verticalSpacing: t,
		cols: n,
		minColWidth: r
	}), u = l.reduce((t, r) => (t[r] || (t[r] = {}), typeof e == "object" && e[r] !== void 0 && (t[r]["--sg-spacing-x"] = V(e[r])), typeof o == "object" && o[r] !== void 0 && (t[r]["--sg-spacing-y"] = V(o[r])), !s && typeof n == "object" && n[r] !== void 0 && (t[r]["--sg-cols"] = n[r]), t), {}), d = l.map((e) => ({
		query: `simple-grid (min-width: ${e})`,
		styles: u[e]
	}));
	return /* @__PURE__ */ T(An, {
		styles: c,
		container: d,
		selector: a
	});
}
//#endregion
//#region node_modules/@mantine/core/esm/components/SimpleGrid/SimpleGrid.module.mjs
var au = {
	container: "m_925c2d2c",
	root: "m_2415a157"
}, ou = {
	cols: 1,
	spacing: "md",
	type: "media"
}, su = Y((e) => {
	let t = q("SimpleGrid", ou, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, cols: c, verticalSpacing: l, spacing: u, type: d, minColWidth: f, autoFlow: p, autoRows: m, attributes: h, ...g } = t, _ = J({
		name: "SimpleGrid",
		classes: au,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: h,
		vars: s
	}), v = nr(), y = f === void 0 ? void 0 : p || "auto-fill";
	return d === "container" ? /* @__PURE__ */ E(w, { children: [/* @__PURE__ */ T(iu, {
		...t,
		selector: `.${v}`
	}), /* @__PURE__ */ T("div", {
		..._("container"),
		children: /* @__PURE__ */ T(X, {
			..._("root", { className: v }),
			...g,
			"data-auto-cols": y
		})
	})] }) : /* @__PURE__ */ E(w, { children: [/* @__PURE__ */ T(eu, {
		...t,
		selector: `.${v}`
	}), /* @__PURE__ */ T(X, {
		..._("root", { className: v }),
		...g,
		"data-auto-cols": y
	})] });
});
su.classes = au, su.displayName = "@mantine/core/SimpleGrid";
//#endregion
//#region node_modules/@mantine/core/esm/components/Stack/Stack.module.mjs
var cu = { root: "m_6d731127" }, lu = {
	gap: "md",
	align: "stretch",
	justify: "flex-start"
}, uu = K((e, { gap: t, align: n, justify: r }) => ({ root: {
	"--stack-gap": V(t),
	"--stack-align": n,
	"--stack-justify": r
} })), du = Y((e) => {
	let t = q("Stack", lu, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, align: c, justify: l, gap: u, variant: d, attributes: f, ...p } = t, m = J({
		name: "Stack",
		props: t,
		classes: cu,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: f,
		vars: s,
		varsResolver: uu
	});
	return /* @__PURE__ */ T(X, {
		...m("root"),
		variant: d,
		...p
	});
});
du.classes = cu, du.varsResolver = uu, du.displayName = "@mantine/core/Stack";
//#endregion
//#region node_modules/@mantine/core/esm/components/Table/Table.context.mjs
var [fu, pu] = re("Table component was not found in the tree"), mu = {
	table: "m_b23fa0ef",
	th: "m_4e7aa4f3",
	tr: "m_4e7aa4fd",
	td: "m_4e7aa4ef",
	tbody: "m_b2404537",
	thead: "m_b242d975",
	caption: "m_9e5a3ac7",
	scrollContainer: "m_a100c15",
	scrollContainerInner: "m_62259741"
};
//#endregion
//#region node_modules/@mantine/core/esm/components/Table/Table.components.mjs
function hu(e, t) {
	if (!t) return;
	let n = {};
	return t.columnBorder && e.withColumnBorders && (n["data-with-column-border"] = !0), t.rowBorder && e.withRowBorders && (n["data-with-row-border"] = !0), t.striped && e.striped && (n["data-striped"] = e.striped), t.highlightOnHover && e.highlightOnHover && (n["data-hover"] = !0), t.captionSide && e.captionSide && (n["data-side"] = e.captionSide), t.stickyHeader && e.stickyHeader && (n["data-sticky"] = !0), n;
}
function gu(e, t) {
	let n = `Table${e.charAt(0).toUpperCase()}${e.slice(1)}`, r = Y((r) => {
		let i = q(n, {}, r), { classNames: a, className: o, style: s, styles: c, ...l } = i, u = pu();
		return /* @__PURE__ */ T(X, {
			component: e,
			...hu(u, t),
			...u.getStyles(e, {
				className: o,
				classNames: a,
				style: s,
				styles: c,
				props: i
			}),
			...l
		});
	});
	return r.displayName = `@mantine/core/${n}`, r.classes = mu, r;
}
var _u = gu("th", { columnBorder: !0 }), vu = gu("td", { columnBorder: !0 }), yu = gu("tr", {
	rowBorder: !0,
	striped: !0,
	highlightOnHover: !0
}), bu = gu("thead", { stickyHeader: !0 }), xu = gu("tbody"), Su = gu("tfoot"), Cu = gu("caption", { captionSide: !0 }), wu = { type: "scrollarea" }, Tu = K((e, { minWidth: t, maxHeight: n, type: r }) => ({ scrollContainer: {
	"--table-min-width": P(t),
	"--table-max-height": P(n),
	"--table-overflow": r === "native" ? "auto" : void 0
} })), Eu = Y((e) => {
	let t = q("TableScrollContainer", wu, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, children: c, minWidth: l, maxHeight: u, type: d, scrollAreaProps: f, attributes: p, ...m } = t, h = J({
		name: "TableScrollContainer",
		classes: mu,
		props: t,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: p,
		vars: s,
		varsResolver: Tu,
		rootSelector: "scrollContainer"
	});
	return /* @__PURE__ */ T(X, {
		component: d === "scrollarea" ? ai : "div",
		...d === "scrollarea" ? u ? {
			offsetScrollbars: "xy",
			...f
		} : {
			offsetScrollbars: "x",
			...f
		} : {},
		...h("scrollContainer"),
		...m,
		children: /* @__PURE__ */ T("div", {
			...h("scrollContainerInner"),
			children: c
		})
	});
});
Eu.classes = mu, Eu.varsResolver = Tu, Eu.displayName = "@mantine/core/TableScrollContainer";
//#endregion
//#region node_modules/@mantine/core/esm/components/Table/TableDataRenderer.mjs
function Du({ data: e }) {
	return /* @__PURE__ */ E(w, { children: [
		e.caption && /* @__PURE__ */ T(Cu, { children: e.caption }),
		e.head && /* @__PURE__ */ T(bu, { children: /* @__PURE__ */ T(yu, { children: e.head.map((e, t) => /* @__PURE__ */ T(_u, { children: e }, t)) }) }),
		e.body && /* @__PURE__ */ T(xu, { children: e.body.map((e, t) => /* @__PURE__ */ T(yu, { children: e.map((e, t) => /* @__PURE__ */ T(vu, { children: e }, t)) }, t)) }),
		e.foot && /* @__PURE__ */ T(Su, { children: /* @__PURE__ */ T(yu, { children: e.foot.map((e, t) => /* @__PURE__ */ T(_u, { children: e }, t)) }) })
	] });
}
Du.displayName = "@mantine/core/TableDataRenderer";
//#endregion
//#region node_modules/@mantine/core/esm/components/Table/Table.mjs
var Ou = {
	withRowBorders: !0,
	verticalSpacing: 7
}, ku = K((e, { layout: t, captionSide: n, horizontalSpacing: r, verticalSpacing: i, borderColor: a, stripedColor: o, highlightOnHoverColor: s, striped: c, highlightOnHover: l, stickyHeaderOffset: u, stickyHeader: d }) => ({ table: {
	"--table-layout": t,
	"--table-caption-side": n,
	"--table-horizontal-spacing": V(r),
	"--table-vertical-spacing": V(i),
	"--table-border-color": a ? pt(a, e) : void 0,
	"--table-striped-color": c && o ? pt(o, e) : void 0,
	"--table-highlight-on-hover-color": l && s ? pt(s, e) : void 0,
	"--table-sticky-header-offset": d ? P(u) : void 0
} })), $ = Y((e) => {
	let t = q("Table", Ou, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, vars: s, horizontalSpacing: c, verticalSpacing: l, captionSide: u, stripedColor: d, highlightOnHoverColor: f, striped: p, highlightOnHover: m, withColumnBorders: h, withRowBorders: g, withTableBorder: _, borderColor: v, layout: y, data: b, children: x, stickyHeader: S, stickyHeaderOffset: C, mod: w, tabularNums: E, attributes: D, ...O } = t, k = J({
		name: "Table",
		props: t,
		className: r,
		style: i,
		classes: mu,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: D,
		rootSelector: "table",
		vars: s,
		varsResolver: ku
	});
	return /* @__PURE__ */ T(fu, {
		value: {
			getStyles: k,
			stickyHeader: S,
			striped: p === !0 ? "odd" : p || void 0,
			highlightOnHover: m,
			withColumnBorders: h,
			withRowBorders: g,
			captionSide: u || "bottom"
		},
		children: /* @__PURE__ */ T(X, {
			component: "table",
			mod: [{
				withTableBorder: _,
				tabularNums: E
			}, w],
			...k("table"),
			...O,
			children: x || !!b && /* @__PURE__ */ T(Du, { data: b })
		})
	});
});
$.classes = mu, $.varsResolver = ku, $.displayName = "@mantine/core/Table", $.Td = vu, $.Th = _u, $.Tr = yu, $.Thead = bu, $.Tbody = xu, $.Tfoot = Su, $.Caption = Cu, $.ScrollContainer = Eu, $.DataRenderer = Du;
//#endregion
//#region node_modules/@mantine/core/esm/components/TextInput/TextInput.mjs
var Au = Y((e) => {
	let t = q([
		"Input",
		"InputWrapper",
		"TextInput"
	], null, e);
	return /* @__PURE__ */ T(es, {
		component: "input",
		...t,
		__staticSelector: "TextInput"
	});
});
Au.classes = es.classes, Au.displayName = "@mantine/core/TextInput";
//#endregion
//#region node_modules/@mantine/core/esm/components/Title/get-title-size.mjs
var ju = [
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6"
], Mu = [
	"xs",
	"sm",
	"md",
	"lg",
	"xl"
];
function Nu(e, t) {
	let n = t === void 0 ? `h${e}` : t;
	return ju.includes(n) ? {
		fontSize: `var(--mantine-${n}-font-size)`,
		fontWeight: `var(--mantine-${n}-font-weight)`,
		lineHeight: `var(--mantine-${n}-line-height)`
	} : Mu.includes(n) ? {
		fontSize: `var(--mantine-font-size-${n})`,
		fontWeight: `var(--mantine-h${e}-font-weight)`,
		lineHeight: `var(--mantine-h${e}-line-height)`
	} : {
		fontSize: P(n),
		fontWeight: `var(--mantine-h${e}-font-weight)`,
		lineHeight: `var(--mantine-h${e}-line-height)`
	};
}
//#endregion
//#region node_modules/@mantine/core/esm/components/Title/Title.module.mjs
var Pu = { root: "m_8a5d1357" }, Fu = { order: 1 }, Iu = K((e, { order: t, size: n, lineClamp: r, textWrap: i }) => {
	let a = Nu(t || 1, n);
	return { root: {
		"--title-fw": a.fontWeight,
		"--title-lh": a.lineHeight,
		"--title-fz": a.fontSize,
		"--title-line-clamp": typeof r == "number" ? r.toString() : void 0,
		"--title-text-wrap": i
	} };
}), Lu = Y((e) => {
	let t = q("Title", Fu, e), { classNames: n, className: r, style: i, styles: a, unstyled: o, order: s, vars: c, size: l, variant: u, lineClamp: d, textWrap: f, mod: p, attributes: m, ...h } = t, g = J({
		name: "Title",
		props: t,
		classes: Pu,
		className: r,
		style: i,
		classNames: n,
		styles: a,
		unstyled: o,
		attributes: m,
		vars: c,
		varsResolver: Iu
	});
	return [
		1,
		2,
		3,
		4,
		5,
		6
	].includes(s) ? /* @__PURE__ */ T(X, {
		...g("root"),
		component: `h${s}`,
		variant: u,
		mod: [{
			order: s,
			lineClamp: typeof d == "number"
		}, p],
		size: l,
		...h
	}) : null;
});
Lu.classes = Pu, Lu.varsResolver = Iu, Lu.displayName = "@mantine/core/Title";
//#endregion
//#region src/controls/overrideFieldMeta.ts
function Ru(e) {
	let t = e.key.replace(/_/g, " ");
	return e.unit ? `${t} · ${e.unit}` : t;
}
function zu(e) {
	return typeof e == "object" && e ? JSON.stringify(e) : String(e);
}
function Bu(e) {
	return e.default === void 0 ? "Automatic" : `Automatic (${zu(e.default)})`;
}
//#endregion
//#region src/controls/OverrideControl.tsx
function Vu({ meta: e, value: t, disabled: n, onChange: r }) {
	let i = t !== void 0, a = Ru(e);
	return e.type === "boolean" ? /* @__PURE__ */ T(Vc, {
		label: a,
		description: e.description,
		disabled: n,
		value: i ? zu(t) : "",
		data: [
			{
				value: "",
				label: Bu(e)
			},
			{
				value: "true",
				label: "On"
			},
			{
				value: "false",
				label: "Off"
			}
		],
		onChange: (e) => {
			let t = e.currentTarget.value;
			r(t === "" ? void 0 : t === "true");
		}
	}) : e.enum && e.enum.length > 0 ? /* @__PURE__ */ T(Vc, {
		label: a,
		description: e.description,
		disabled: n,
		value: i ? zu(t) : "",
		data: [{
			value: "",
			label: Bu(e)
		}, ...e.enum.map((e) => ({
			value: e,
			label: e
		}))],
		onChange: (e) => {
			let t = e.currentTarget.value;
			r(t === "" ? void 0 : t);
		}
	}) : e.type === "integer" || e.type === "number" ? /* @__PURE__ */ T(Ql, {
		label: a,
		description: e.description,
		disabled: n,
		placeholder: Bu(e),
		value: i ? t : "",
		onChange: (e) => {
			if (e === "") {
				r(void 0);
				return;
			}
			let t = Number(e);
			Number.isFinite(t) && r(t);
		}
	}) : e.type === "string" ? /* @__PURE__ */ T(Au, {
		label: a,
		description: e.description,
		disabled: n,
		placeholder: Bu(e),
		value: i ? zu(t) : "",
		onChange: (e) => {
			let t = e.currentTarget.value;
			r(t === "" ? void 0 : t);
		}
	}) : /* @__PURE__ */ T(Hu, {
		label: a,
		description: e.description,
		disabled: n,
		value: t,
		onChange: r
	});
}
function Hu({ label: e, description: t, disabled: n, value: r, onChange: i }) {
	let [a, o] = y(r), [s, c] = y(r === void 0 ? "" : JSON.stringify(r)), [l, u] = y(null);
	return r !== a && (o(r), c(r === void 0 ? "" : JSON.stringify(r)), u(null)), /* @__PURE__ */ E(du, {
		gap: 4,
		children: [/* @__PURE__ */ T(xc, {
			label: e,
			description: `${t} (JSON)`,
			disabled: n,
			placeholder: "Automatic",
			autosize: !0,
			minRows: 1,
			value: s,
			onChange: (e) => {
				let t = e.currentTarget.value;
				if (c(t), t.trim() === "") {
					u(null), i(void 0);
					return;
				}
				try {
					i(JSON.parse(t)), u(null);
				} catch {
					u("Not valid JSON");
				}
			}
		}), l === null ? null : /* @__PURE__ */ T(Q, {
			c: "red",
			size: "xs",
			children: l
		})]
	});
}
//#endregion
//#region src/review/readableName.ts
function Uu(e) {
	return e.replaceAll("_", " ").replace(/\b\w/g, (e) => e.toUpperCase());
}
//#endregion
//#region src/review/warnings.ts
function Wu(e) {
	return typeof e == "object" && !!e && "code" in e && "level" in e && "category" in e && "message" in e && typeof e.message == "string";
}
var Gu = {
	info: "blue.8",
	warning: "yellow",
	error: "red"
}, Ku = {
	human: "Your override",
	ml: "Model prediction",
	llm: "LLM suggestion",
	heuristic: "Heuristic default"
};
function qu({ field: e }) {
	return e.status === "unavailable" ? /* @__PURE__ */ E(Q, {
		size: "sm",
		c: "dimmed",
		children: ["Unavailable -- ", e.reason ?? "no reason given"]
	}) : e.status === "blocked" ? /* @__PURE__ */ E(Q, {
		size: "sm",
		c: "red",
		children: ["Blocked -- ", e.blocked_by ?? "an upstream field failed"]
	}) : /* @__PURE__ */ E(du, {
		gap: "xs",
		children: [
			/* @__PURE__ */ T(Xs, {
				color: "gray",
				variant: "light",
				style: { alignSelf: "flex-start" },
				children: Ku[e.source ?? "heuristic"]
			}),
			/* @__PURE__ */ T(Yu, { value: e.value }),
			e.field_sources === void 0 || e.field_sources === null ? null : /* @__PURE__ */ T(Ju, { sources: e.field_sources })
		]
	});
}
function Ju({ sources: e }) {
	let t = Object.entries(e);
	return t.length === 0 ? null : /* @__PURE__ */ E($, {
		layout: "fixed",
		verticalSpacing: 4,
		children: [/* @__PURE__ */ T($.Caption, { children: "Per-field sources" }), /* @__PURE__ */ T($.Tbody, { children: t.map(([e, t]) => /* @__PURE__ */ E($.Tr, { children: [/* @__PURE__ */ T($.Th, {
			scope: "row",
			children: Zu(e)
		}), /* @__PURE__ */ T($.Td, { children: Ku[t] })] }, e)) })]
	});
}
function Yu({ value: e }) {
	if (e == null) return /* @__PURE__ */ T(Q, {
		size: "sm",
		c: "dimmed",
		children: "None"
	});
	if (typeof e == "boolean") return /* @__PURE__ */ T(Q, {
		size: "sm",
		children: e ? "Yes" : "No"
	});
	if (typeof e == "number" || typeof e == "string") return /* @__PURE__ */ T(Q, {
		size: "sm",
		children: String(e)
	});
	if (Array.isArray(e)) {
		let t = e;
		return t.length === 0 ? /* @__PURE__ */ T(Q, {
			size: "sm",
			c: "dimmed",
			children: "Empty"
		}) : t.every((e) => typeof e != "object" || !e) ? /* @__PURE__ */ T(Q, {
			size: "sm",
			children: t.map(String).join(", ")
		}) : /* @__PURE__ */ T(du, {
			gap: "xs",
			children: t.map((e, t) => /* @__PURE__ */ T(mi, {
				withBorder: !0,
				p: "xs",
				children: /* @__PURE__ */ T(Yu, { value: e })
			}, t))
		});
	}
	let t = Object.entries(e), n = t.find(([e]) => e === "warnings")?.[1], r = t.filter(([e]) => e !== "warnings");
	return r.length === 0 && !Array.isArray(n) ? /* @__PURE__ */ T(Q, {
		size: "sm",
		c: "dimmed",
		children: "None"
	}) : /* @__PURE__ */ E(du, {
		gap: "xs",
		children: [r.length === 0 ? null : /* @__PURE__ */ T($, {
			layout: "fixed",
			verticalSpacing: 4,
			style: { overflowWrap: "anywhere" },
			children: /* @__PURE__ */ T($.Tbody, { children: r.map(([e, t]) => /* @__PURE__ */ E($.Tr, { children: [/* @__PURE__ */ T($.Th, {
				scope: "row",
				children: Zu(e)
			}), /* @__PURE__ */ T($.Td, { children: /* @__PURE__ */ T(Yu, { value: t }) })] }, e)) })
		}), /* @__PURE__ */ T(Xu, { warnings: n })]
	});
}
function Xu({ warnings: e }) {
	return !Array.isArray(e) || e.length === 0 ? null : /* @__PURE__ */ T(du, {
		component: "ul",
		gap: 4,
		m: 0,
		pl: "md",
		children: e.map((e, t) => /* @__PURE__ */ T(Q, {
			component: "li",
			size: "sm",
			children: Wu(e) ? e.message : String(e)
		}, t))
	});
}
function Zu(e) {
	return e.replaceAll("_", " ").replace(/\b\w/g, (e) => e.toUpperCase());
}
//#endregion
//#region src/review/RecordAccordionItem.tsx
var Qu = {
	resolved: "green",
	unavailable: "yellow",
	blocked: "red"
};
function $u({ name: e, field: t }) {
	return /* @__PURE__ */ E(fs.Item, {
		value: e,
		className: "record-card",
		children: [/* @__PURE__ */ T(fs.Control, { children: /* @__PURE__ */ E(Z, {
			justify: "space-between",
			wrap: "nowrap",
			children: [/* @__PURE__ */ E(Z, {
				gap: "xs",
				wrap: "nowrap",
				children: [/* @__PURE__ */ T(Xs, {
					size: "xs",
					circle: !0,
					color: Qu[t.status],
					"aria-hidden": "true"
				}), /* @__PURE__ */ T("span", { children: Uu(e) })]
			}), /* @__PURE__ */ T(cc, { children: e })]
		}) }), /* @__PURE__ */ T(fs.Panel, { children: /* @__PURE__ */ T(qu, { field: t }) })]
	});
}
//#endregion
//#region src/workspace/recordGroups.ts
function ed(e, t) {
	return e === "pseudo_table" || e === "pseudopotentials" || t.settings.some((t) => t.group === e);
}
//#endregion
//#region src/workspace/workspaceContext.ts
var td = s(null);
//#endregion
//#region src/workspace/useWorkspace.ts
function nd() {
	let e = f(td);
	if (e === null) throw Error("useWorkspace must be rendered inside WorkspaceProvider");
	return e;
}
function rd() {
	let e = nd(), t = d((t) => e.subscribe(t), [e]), n = d(() => e.getSnapshot(), [e]);
	return b(t, n, n);
}
//#endregion
//#region src/analysis/AnalysisSection.tsx
var id = {
	resolved: "green",
	unavailable: "yellow",
	blocked: "red"
};
function ad() {
	let e = nd(), t = rd(), { capabilities: n, draft: r, inspection: i, reviewed: a } = t;
	if (n === null || r === null) return null;
	let o = t.operation === "inspect" || i === null, s = r.overrides, c = new Set(n.facts.map((e) => e.key)), l = Object.entries(a?.records ?? {}).filter(([e]) => !c.has(e) && !ed(e, n));
	return /* @__PURE__ */ E(du, {
		gap: "sm",
		children: [n.facts.length === 0 ? null : /* @__PURE__ */ T(du, {
			gap: "sm",
			children: n.facts.map((t) => {
				let n = a?.records[t.key];
				return /* @__PURE__ */ E("div", { children: [n === void 0 ? null : /* @__PURE__ */ E(Z, {
					gap: "xs",
					mb: 4,
					children: [/* @__PURE__ */ T(Xs, {
						size: "xs",
						circle: !0,
						color: id[n.status],
						"aria-hidden": "true"
					}), /* @__PURE__ */ T(Q, {
						size: "xs",
						c: "dimmed",
						children: n.status
					})]
				}), /* @__PURE__ */ T(Vu, {
					meta: {
						key: t.key,
						type: t.type,
						enum: t.values ?? void 0,
						unit: null,
						description: t.description
					},
					value: s[t.key],
					disabled: o,
					onChange: (n) => {
						e.dispatch({
							type: "draft.patch",
							overrides: { [t.key]: n }
						});
					}
				})] }, t.key);
			})
		}), l.length === 0 ? null : /* @__PURE__ */ T(fs, {
			multiple: !0,
			transitionDuration: 0,
			children: l.map(([e, t]) => /* @__PURE__ */ T($u, {
				name: e,
				field: t
			}, e))
		})]
	});
}
//#endregion
//#region src/cards/AnalysisCard.tsx
function od() {
	let e = rd();
	return /* @__PURE__ */ E(mi, {
		component: "section",
		id: "analysis-panel",
		"aria-label": "Goldilocks analysis",
		withBorder: !0,
		p: "md",
		className: "workbench-card card-analysis",
		children: [/* @__PURE__ */ E(Z, {
			component: "header",
			className: "card-header",
			mb: "md",
			wrap: "nowrap",
			children: [/* @__PURE__ */ T(Q, {
				className: "card-kicker",
				children: "02"
			}), /* @__PURE__ */ T(Lu, {
				order: 2,
				children: "Goldilocks analysis"
			})]
		}), /* @__PURE__ */ T("div", {
			className: "card-body",
			children: e.capabilities === null ? /* @__PURE__ */ T(Q, {
				c: "dimmed",
				children: "Load a structure to see the Goldilocks analysis."
			}) : /* @__PURE__ */ T(ad, {})
		})]
	});
}
//#endregion
//#region src/controls/CalculationForm.tsx
var sd = { relax: ["relax", "vc-relax"] }, cd = {
	resolved: "green",
	unavailable: "yellow",
	blocked: "red"
};
function ld() {
	let e = nd(), t = rd(), { draft: n, capabilities: r, inspection: i, reviewed: a } = t;
	if (n === null || r === null) return null;
	let o = t.operation === "inspect", s = o || i === null, c = i === null ? [] : ud(i), l = n.overrides;
	function u(t) {
		e.dispatch({
			type: "draft.patch",
			overrides: t
		});
	}
	return /* @__PURE__ */ E(du, { children: [
		o ? /* @__PURE__ */ T(Q, {
			c: "red",
			size: "sm",
			role: "status",
			children: "Calculation settings are disabled while the new structure loads."
		}) : null,
		i === null ? /* @__PURE__ */ T(Q, {
			c: "dimmed",
			size: "sm",
			children: "Showing default settings — load a structure to configure a calculation."
		}) : null,
		/* @__PURE__ */ E(su, {
			cols: {
				base: 1,
				xs: 2
			},
			children: [/* @__PURE__ */ T(Vc, {
				label: "Code",
				disabled: s,
				value: n.code,
				data: r.codes.map((e) => ({
					value: e.id,
					label: e.name
				})),
				onChange: (t) => {
					e.dispatch({
						type: "draft.patch",
						code: t.currentTarget.value
					});
				}
			}), /* @__PURE__ */ T(Vc, {
				label: "Task",
				disabled: s,
				value: n.task,
				data: r.tasks.map((e) => ({
					value: e.id,
					label: e.name
				})),
				onChange: (t) => {
					e.dispatch({
						type: "draft.patch",
						task: t.currentTarget.value
					});
				}
			})]
		}),
		/* @__PURE__ */ T(Vc, {
			label: "HPC profile",
			disabled: s,
			value: n.hpc ?? "",
			data: [{
				value: "",
				label: "Automatic"
			}, ...r.hpc_profiles.map((e) => ({
				value: e.id,
				label: e.name
			}))],
			onChange: (t) => {
				e.dispatch({
					type: "draft.patch",
					hpc: t.currentTarget.value || null
				});
			}
		}),
		/* @__PURE__ */ T(fs, {
			multiple: !0,
			transitionDuration: 0,
			children: /* @__PURE__ */ T(_d, {
				settings: r.settings,
				task: n.task,
				overrides: l,
				reviewed: a,
				elements: c,
				pseudopotentialTables: r.pseudopotential_tables,
				disabled: s,
				onChange: u
			})
		})
	] });
}
function ud(e) {
	return [...new Set(e.structure.sites.flatMap((e) => e.species.map((e) => e.symbol)))];
}
function dd(e) {
	return [...new Set(e.map((e) => e.functional))];
}
function fd({ tables: e, elements: t, functionalOverride: n, pinned: r, disabled: i, onChange: a }) {
	let o = e.filter((e) => (n === void 0 || e.functional === n) && t.every((t) => e.elements.includes(t)));
	return /* @__PURE__ */ T(Vc, {
		label: "Pseudopotential table",
		description: o.length === 0 ? "No registered table supports this structure with this functional" : void 0,
		disabled: i,
		value: typeof r == "string" ? r : "",
		data: [{
			value: "",
			label: "Automatic"
		}, ...o.map((e) => ({
			value: e.id,
			label: `${e.provider} · ${e.functional} · ${e.accuracy} · ${e.relativistic}`
		}))],
		onChange: (e) => {
			let t = e.currentTarget.value;
			a({ pseudo_table_id: t === "" ? void 0 : t });
		}
	});
}
function pd({ tables: e, value: t, disabled: n, onChange: r }) {
	return /* @__PURE__ */ T(Vc, {
		label: "Functional",
		disabled: n,
		value: t ?? "",
		data: [{
			value: "",
			label: "Automatic"
		}, ...dd(e).map((e) => ({
			value: e,
			label: e
		}))],
		onChange: (e) => {
			let t = e.currentTarget.value;
			r({
				functional: t === "" ? void 0 : t,
				pseudo_table_id: void 0
			});
		}
	});
}
var md = { pseudo_table_id: "Pseudopotential table" };
function hd(e) {
	let t = md[e];
	if (t !== void 0) return t;
	let n = e.replace(/_/g, " ");
	return n.charAt(0).toUpperCase() + n.slice(1);
}
function gd(e) {
	return e === "pseudo_table_id" ? "pseudo_table" : e;
}
function _d({ settings: e, task: t, overrides: n, reviewed: r, elements: i, pseudopotentialTables: a, disabled: o, onChange: s }) {
	let c = /* @__PURE__ */ new Map();
	for (let n of e) {
		let e = sd[n.group];
		if (e !== void 0 && !e.includes(t)) continue;
		let r = c.get(n.group);
		r === void 0 ? c.set(n.group, [n]) : r.push(n);
	}
	let l = typeof n.functional == "string" ? n.functional : void 0;
	return /* @__PURE__ */ T(w, { children: [...c.entries()].map(([e, t]) => {
		let c = r?.records[gd(e)];
		return /* @__PURE__ */ E(fs.Item, {
			value: e,
			children: [/* @__PURE__ */ T(fs.Control, { children: /* @__PURE__ */ E(Z, {
				gap: "xs",
				wrap: "nowrap",
				children: [c === void 0 ? null : /* @__PURE__ */ T(Xs, {
					size: "xs",
					circle: !0,
					color: cd[c.status],
					"aria-hidden": "true"
				}), /* @__PURE__ */ T("span", { children: hd(e) })]
			}) }), /* @__PURE__ */ T(fs.Panel, { children: /* @__PURE__ */ E(du, {
				gap: "sm",
				children: [c === void 0 ? null : /* @__PURE__ */ T(mi, {
					withBorder: !0,
					p: "xs",
					bg: "var(--mantine-color-default)",
					children: /* @__PURE__ */ T(qu, { field: c })
				}), /* @__PURE__ */ T(vd, {
					group: e,
					groupSettings: t,
					elements: i,
					pseudopotentialTables: a,
					functionalOverride: l,
					overrides: n,
					disabled: o,
					onChange: s
				})]
			}) })]
		}, e);
	}) });
}
function vd({ group: e, groupSettings: t, elements: n, pseudopotentialTables: r, functionalOverride: i, overrides: a, disabled: o, onChange: s }) {
	return e === "functional" ? /* @__PURE__ */ T(pd, {
		tables: r,
		value: i,
		disabled: o,
		onChange: s
	}) : e === "pseudo_table_id" ? /* @__PURE__ */ T(fd, {
		tables: r,
		elements: n,
		functionalOverride: i,
		pinned: a.pseudo_table_id,
		disabled: o,
		onChange: s
	}) : /* @__PURE__ */ T(w, { children: t.map((e) => e.key === "k_grid" ? /* @__PURE__ */ T(yd, {
		value: a.k_grid,
		disabled: o,
		onChange: (e) => {
			s({ k_grid: e });
		}
	}, e.key) : /* @__PURE__ */ T(Vu, {
		meta: e,
		value: a[e.key],
		disabled: o,
		onChange: (t) => {
			s({ [e.key]: t });
		}
	}, e.key)) });
}
function yd({ value: e, disabled: t, onChange: n }) {
	let r = Array.isArray(e) && e.length === 3 ? e : null;
	return /* @__PURE__ */ E(fc, {
		legend: "K-point grid",
		children: [/* @__PURE__ */ T(qs, {
			label: "Set an explicit grid",
			checked: r !== null,
			disabled: t,
			onChange: (e) => {
				n(e.currentTarget.checked ? [
					1,
					1,
					1
				] : void 0);
			}
		}), /* @__PURE__ */ T(su, {
			cols: 3,
			mt: "sm",
			spacing: "xs",
			children: [
				"x",
				"y",
				"z"
			].map((e, i) => /* @__PURE__ */ T(Ql, {
				"aria-label": `K-point grid ${e}`,
				min: 1,
				max: 99,
				disabled: r === null || t,
				value: r?.[i] ?? "",
				placeholder: "Auto",
				onChange: (e) => {
					if (r === null) return;
					let t = Number(e);
					if (!Number.isInteger(t) || t < 1 || t > 99) return;
					let a = [...r];
					a[i] = t, n(a);
				}
			}, e))
		})]
	});
}
//#endregion
//#region src/cards/CalculationCard.tsx
function bd() {
	let e = rd();
	return /* @__PURE__ */ E(mi, {
		component: "section",
		id: "calculation-panel",
		"aria-label": "Calculation setup",
		withBorder: !0,
		p: "md",
		className: "workbench-card card-calculation",
		children: [/* @__PURE__ */ E(Z, {
			component: "header",
			className: "card-header",
			mb: "md",
			wrap: "nowrap",
			children: [/* @__PURE__ */ T(Q, {
				className: "card-kicker",
				children: "03"
			}), /* @__PURE__ */ T(Lu, {
				order: 2,
				children: "Goldilocks advisors"
			})]
		}), /* @__PURE__ */ T("div", {
			className: "card-body",
			children: e.capabilities === null ? /* @__PURE__ */ T(Q, {
				c: "dimmed",
				children: "Load a structure to configure a calculation."
			}) : /* @__PURE__ */ T(ld, {})
		})]
	});
}
//#endregion
//#region node_modules/lucide-react/dist/esm/shared/src/utils/mergeClasses.mjs
var xd = (...e) => e.filter((e, t, n) => !!e && e.trim() !== "" && n.indexOf(e) === t).join(" ").trim(), Sd = (e) => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), Cd = (e) => e.replace(/^([A-Z])|[\s-_]+(\w)/g, (e, t, n) => n ? n.toUpperCase() : t.toLowerCase()), wd = (e) => {
	let t = Cd(e);
	return t.charAt(0).toUpperCase() + t.slice(1);
}, Td = {
	xmlns: "http://www.w3.org/2000/svg",
	width: 24,
	height: 24,
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	strokeWidth: 2,
	strokeLinecap: "round",
	strokeLinejoin: "round"
}, Ed = (e) => {
	for (let t in e) if (t.startsWith("aria-") || t === "role" || t === "title") return !0;
	return !1;
}, Dd = s({}), Od = () => f(Dd), kd = l(({ color: e, size: t, strokeWidth: n, absoluteStrokeWidth: r, className: i = "", children: a, iconNode: o, ...s }, l) => {
	let { size: u = 24, strokeWidth: d = 2, absoluteStrokeWidth: f = !1, color: p = "currentColor", className: m = "" } = Od() ?? {}, h = r ?? f ? Number(n ?? d) * 24 / Number(t ?? u) : n ?? d;
	return c("svg", {
		ref: l,
		...Td,
		width: t ?? u ?? Td.width,
		height: t ?? u ?? Td.height,
		stroke: e ?? p,
		strokeWidth: h,
		className: xd("lucide", m, i),
		...!a && !Ed(s) && { "aria-hidden": "true" },
		...s
	}, [...o.map(([e, t]) => c(e, t)), ...Array.isArray(a) ? a : [a]]);
}), Ad = (e, t) => {
	let n = l(({ className: n, ...r }, i) => c(kd, {
		ref: i,
		iconNode: t,
		className: xd(`lucide-${Sd(wd(e))}`, `lucide-${e}`, n),
		...r
	}));
	return n.displayName = wd(e), n;
}, jd = Ad("atom", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "1",
		key: "41hilf"
	}],
	["path", {
		d: "M20.2 20.2c2.04-2.03.02-7.36-4.5-11.9-4.54-4.52-9.87-6.54-11.9-4.5-2.04 2.03-.02 7.36 4.5 11.9 4.54 4.52 9.87 6.54 11.9 4.5Z",
		key: "1l2ple"
	}],
	["path", {
		d: "M15.7 15.7c4.52-4.54 6.54-9.87 4.5-11.9-2.03-2.04-7.36-.02-11.9 4.5-4.52 4.54-6.54 9.87-4.5 11.9 2.03 2.04 7.36.02 11.9-4.5Z",
		key: "1wam0m"
	}]
]), Md = Ad("download", [
	["path", {
		d: "M12 15V3",
		key: "m9g1x1"
	}],
	["path", {
		d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
		key: "ih7n3h"
	}],
	["path", {
		d: "m7 10 5 5 5-5",
		key: "brsn70"
	}]
]), Nd = Ad("moon", [["path", {
	d: "M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401",
	key: "kfwtm"
}]]), Pd = Ad("rotate-cw", [["path", {
	d: "M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8",
	key: "1p45f6"
}], ["path", {
	d: "M21 3v5h-5",
	key: "1q7to0"
}]]), Fd = Ad("sun", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "4",
		key: "4exip2"
	}],
	["path", {
		d: "M12 2v2",
		key: "tus03m"
	}],
	["path", {
		d: "M12 20v2",
		key: "1lh1kg"
	}],
	["path", {
		d: "m4.93 4.93 1.41 1.41",
		key: "149t6j"
	}],
	["path", {
		d: "m17.66 17.66 1.41 1.41",
		key: "ptbguv"
	}],
	["path", {
		d: "M2 12h2",
		key: "1t8f8n"
	}],
	["path", {
		d: "M20 12h2",
		key: "1q8mjw"
	}],
	["path", {
		d: "m6.34 17.66-1.41 1.41",
		key: "1m8zz5"
	}],
	["path", {
		d: "m19.07 4.93-1.41 1.41",
		key: "1shlcs"
	}]
]), Id = Ad("upload", [
	["path", {
		d: "M12 3v12",
		key: "1x0j5s"
	}],
	["path", {
		d: "m17 8-5-5-5 5",
		key: "7q97r8"
	}],
	["path", {
		d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
		key: "ih7n3h"
	}]
]), Ld = Uint8Array, Rd = Uint16Array, zd = Int32Array, Bd = new Ld([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	3,
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	0,
	0,
	0,
	0
]), Vd = new Ld([
	0,
	0,
	0,
	0,
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	9,
	10,
	10,
	11,
	11,
	12,
	12,
	13,
	13,
	0,
	0
]), Hd = new Ld([
	16,
	17,
	18,
	0,
	8,
	7,
	9,
	6,
	10,
	5,
	11,
	4,
	12,
	3,
	13,
	2,
	14,
	1,
	15
]), Ud = function(e, t) {
	for (var n = new Rd(31), r = 0; r < 31; ++r) n[r] = t += 1 << e[r - 1];
	for (var i = new zd(n[30]), r = 1; r < 30; ++r) for (var a = n[r]; a < n[r + 1]; ++a) i[a] = a - n[r] << 5 | r;
	return {
		b: n,
		r: i
	};
}, Wd = Ud(Bd, 2), Gd = Wd.b, Kd = Wd.r;
Gd[28] = 258, Kd[258] = 28;
var qd = Ud(Vd, 0), Jd = qd.b;
qd.r;
for (var Yd = new Rd(32768), Xd = 0; Xd < 32768; ++Xd) {
	var Zd = (Xd & 43690) >> 1 | (Xd & 21845) << 1;
	Zd = (Zd & 52428) >> 2 | (Zd & 13107) << 2, Zd = (Zd & 61680) >> 4 | (Zd & 3855) << 4, Yd[Xd] = ((Zd & 65280) >> 8 | (Zd & 255) << 8) >> 1;
}
for (var Qd = (function(e, t, n) {
	for (var r = e.length, i = 0, a = new Rd(t); i < r; ++i) e[i] && ++a[e[i] - 1];
	var o = new Rd(t);
	for (i = 1; i < t; ++i) o[i] = o[i - 1] + a[i - 1] << 1;
	var s;
	if (n) {
		s = new Rd(1 << t);
		var c = 15 - t;
		for (i = 0; i < r; ++i) if (e[i]) for (var l = i << 4 | e[i], u = t - e[i], d = o[e[i] - 1]++ << u, f = d | (1 << u) - 1; d <= f; ++d) s[Yd[d] >> c] = l;
	} else for (s = new Rd(r), i = 0; i < r; ++i) e[i] && (s[i] = Yd[o[e[i] - 1]++] >> 15 - e[i]);
	return s;
}), $d = new Ld(288), Xd = 0; Xd < 144; ++Xd) $d[Xd] = 8;
for (var Xd = 144; Xd < 256; ++Xd) $d[Xd] = 9;
for (var Xd = 256; Xd < 280; ++Xd) $d[Xd] = 7;
for (var Xd = 280; Xd < 288; ++Xd) $d[Xd] = 8;
for (var ef = new Ld(32), Xd = 0; Xd < 32; ++Xd) ef[Xd] = 5;
var tf = /*#__PURE__*/ Qd($d, 9, 1), nf = /*#__PURE__*/ Qd(ef, 5, 1), rf = function(e) {
	for (var t = e[0], n = 1; n < e.length; ++n) e[n] > t && (t = e[n]);
	return t;
}, af = function(e, t, n) {
	var r = t / 8 | 0;
	return (e[r] | e[r + 1] << 8) >> (t & 7) & n;
}, of = function(e, t) {
	var n = t / 8 | 0;
	return (e[n] | e[n + 1] << 8 | e[n + 2] << 16) >> (t & 7);
}, sf = function(e) {
	return (e + 7) / 8 | 0;
}, cf = function(e, t, n) {
	return (t == null || t < 0) && (t = 0), (n == null || n > e.length) && (n = e.length), new Ld(e.subarray(t, n));
}, lf = [
	"unexpected EOF",
	"invalid block type",
	"invalid length/literal",
	"invalid distance",
	"stream finished",
	"no stream handler",
	,
	"no callback",
	"invalid UTF-8 data",
	"extra field too long",
	"date not in range 1980-2099",
	"filename too long",
	"stream finishing",
	"invalid zip data"
], uf = function(e, t, n) {
	var r = Error(t || lf[e]);
	if (r.code = e, Error.captureStackTrace && Error.captureStackTrace(r, uf), !n) throw r;
	return r;
}, df = function(e, t, n, r) {
	var i = e.length, a = r ? r.length : 0;
	if (!i || t.f && !t.l) return n || new Ld(0);
	var o = !n, s = o || t.i != 2, c = t.i;
	o && (n = new Ld(i * 3));
	var l = function(e) {
		var t = n.length;
		if (e > t) {
			var r = new Ld(Math.max(t * 2, e));
			r.set(n), n = r;
		}
	}, u = t.f || 0, d = t.p || 0, f = t.b || 0, p = t.l, m = t.d, h = t.m, g = t.n, _ = i * 8;
	do {
		if (!p) {
			u = af(e, d, 1);
			var v = af(e, d + 1, 3);
			if (d += 3, !v) {
				var y = sf(d) + 4, b = e[y - 4] | e[y - 3] << 8, x = y + b;
				if (x > i) {
					c && uf(0);
					break;
				}
				s && l(f + b), n.set(e.subarray(y, x), f), t.b = f += b, t.p = d = x * 8, t.f = u;
				continue;
			}
			if (v == 1) p = tf, m = nf, h = 9, g = 5;
			else if (v == 2) {
				var S = af(e, d, 31) + 257, C = af(e, d + 10, 15) + 4, w = S + af(e, d + 5, 31) + 1;
				d += 14;
				for (var T = new Ld(w), E = new Ld(19), D = 0; D < C; ++D) E[Hd[D]] = af(e, d + D * 3, 7);
				d += C * 3;
				for (var O = rf(E), k = (1 << O) - 1, ee = Qd(E, O, 1), D = 0; D < w;) {
					var A = ee[af(e, d, k)];
					d += A & 15;
					var y = A >> 4;
					if (y < 16) T[D++] = y;
					else {
						var j = 0, M = 0;
						for (y == 16 ? (M = 3 + af(e, d, 3), d += 2, j = T[D - 1]) : y == 17 ? (M = 3 + af(e, d, 7), d += 3) : y == 18 && (M = 11 + af(e, d, 127), d += 7); M--;) T[D++] = j;
					}
				}
				var N = T.subarray(0, S), P = T.subarray(S);
				h = rf(N), g = rf(P), p = Qd(N, h, 1), m = Qd(P, g, 1);
			} else uf(1);
			if (d > _) {
				c && uf(0);
				break;
			}
		}
		s && l(f + 131072);
		for (var te = (1 << h) - 1, ne = (1 << g) - 1, F = d;; F = d) {
			var j = p[of(e, d) & te], I = j >> 4;
			if (d += j & 15, d > _) {
				c && uf(0);
				break;
			}
			if (j || uf(2), I < 256) n[f++] = I;
			else if (I == 256) {
				F = d, p = null;
				break;
			} else {
				var re = I - 254;
				if (I > 264) {
					var D = I - 257, L = Bd[D];
					re = af(e, d, (1 << L) - 1) + Gd[D], d += L;
				}
				var R = m[of(e, d) & ne], z = R >> 4;
				R || uf(3), d += R & 15;
				var P = Jd[z];
				if (z > 3) {
					var L = Vd[z];
					P += of(e, d) & (1 << L) - 1, d += L;
				}
				if (d > _) {
					c && uf(0);
					break;
				}
				s && l(f + 131072);
				var ie = f + re;
				if (f < P) {
					var ae = a - P, oe = Math.min(P, ie);
					for (ae + f < 0 && uf(3); f < oe; ++f) n[f] = r[ae + f];
				}
				for (; f < ie; ++f) n[f] = n[f - P];
			}
		}
		t.l = p, t.p = F, t.b = f, t.f = u, p && (u = 1, t.m = h, t.d = m, t.n = g);
	} while (!u);
	return f != n.length && o ? cf(n, 0, f) : n.subarray(0, f);
}, ff = /*#__PURE__*/ new Ld(0), pf = function(e, t) {
	return e[t] | e[t + 1] << 8;
}, mf = function(e, t) {
	return (e[t] | e[t + 1] << 8 | e[t + 2] << 16 | e[t + 3] << 24) >>> 0;
}, hf = function(e, t) {
	return mf(e, t) + mf(e, t + 4) * 4294967296;
};
function gf(e, t) {
	return df(e, { i: 2 }, t && t.out, t && t.dictionary);
}
var _f = typeof TextDecoder < "u" && /*#__PURE__*/ new TextDecoder();
try {
	_f.decode(ff, { stream: !0 });
} catch {}
var vf = function(e) {
	for (var t = "", n = 0;;) {
		var r = e[n++], i = (r > 127) + (r > 223) + (r > 239);
		if (n + i > e.length) return {
			s: t,
			r: cf(e, n - 1)
		};
		i ? i == 3 ? (r = ((r & 15) << 18 | (e[n++] & 63) << 12 | (e[n++] & 63) << 6 | e[n++] & 63) - 65536, t += String.fromCharCode(55296 | r >> 10, 56320 | r & 1023)) : i & 1 ? t += String.fromCharCode((r & 31) << 6 | e[n++] & 63) : t += String.fromCharCode((r & 15) << 12 | (e[n++] & 63) << 6 | e[n++] & 63) : t += String.fromCharCode(r);
	}
};
function yf(e, t) {
	if (t) {
		for (var n = "", r = 0; r < e.length; r += 16384) n += String.fromCharCode.apply(null, e.subarray(r, r + 16384));
		return n;
	}
	if (_f) return _f.decode(e);
	var i = vf(e), a = i.s, n = i.r;
	return n.length && uf(8), a;
}
var bf = function(e, t) {
	return t + 30 + pf(e, t + 26) + pf(e, t + 28);
}, xf = function(e, t, n) {
	var r = pf(e, t + 28), i = yf(e.subarray(t + 46, t + 46 + r), !(pf(e, t + 8) & 2048)), a = t + 46 + r, o = mf(e, t + 20), s = n && o == 4294967295 ? Sf(e, a) : [
		o,
		mf(e, t + 24),
		mf(e, t + 42)
	], c = s[0], l = s[1], u = s[2];
	return [
		pf(e, t + 10),
		c,
		l,
		i,
		a + pf(e, t + 30) + pf(e, t + 32),
		u
	];
}, Sf = function(e, t) {
	for (; pf(e, t) != 1; t += 4 + pf(e, t + 2));
	return [
		hf(e, t + 12),
		hf(e, t + 4),
		hf(e, t + 20)
	];
};
function Cf(e, t) {
	for (var n = {}, r = e.length - 22; mf(e, r) != 101010256; --r) (!r || e.length - r > 65558) && uf(13);
	var i = pf(e, r + 8);
	if (!i) return {};
	var a = mf(e, r + 16), o = a == 4294967295 || i == 65535;
	if (o) {
		var s = mf(e, r - 12);
		o = mf(e, s) == 101075792, o && (i = mf(e, s + 32), a = mf(e, s + 48));
	}
	for (var c = t && t.filter, l = 0; l < i; ++l) {
		var u = xf(e, a, o), d = u[0], f = u[1], p = u[2], m = u[3], h = u[4], g = u[5], _ = bf(e, g);
		a = h, (!c || c({
			name: m,
			size: f,
			originalSize: p,
			compression: d
		})) && (d ? d == 8 ? n[m] = gf(e.subarray(_, _ + f), { out: new Ld(p) }) : uf(14, "unknown compression type " + d) : n[m] = cf(e, _, _ + f));
	}
	return n;
}
//#endregion
//#region src/review/artifacts.ts
function wf(e) {
	let t = e.split("/").at(-1) ?? e;
	return e.endsWith(".in") ? 0 : t === "submit.sh" ? 1 : t === "README.md" ? 2 : e.endsWith(".json") ? 3 : e.endsWith(".md") ? 4 : 5;
}
async function Tf(e) {
	let t = Cf(new Uint8Array(await e.blob.arrayBuffer())), n = new TextDecoder("utf-8"), r = [], i = null;
	for (let [e, a] of Object.entries(t)) {
		let t = n.decode(a);
		e === "goldilocks.json" && (i = Ef(t)), r.push({
			path: e,
			content: t
		});
	}
	return r.sort((e, t) => {
		let n = wf(e.path) - wf(t.path);
		return n === 0 ? e.path.localeCompare(t.path) : n;
	}), {
		manifest: i,
		files: r
	};
}
function Ef(e) {
	try {
		let t = JSON.parse(e);
		return Df(t) ? t : null;
	} catch {
		return null;
	}
}
function Df(e) {
	return typeof e == "object" && !!e && "files" in e && typeof e.files == "object";
}
function Of(e, t) {
	let n = e?.files[t];
	return n === void 0 ? void 0 : {
		sha256: n.sha256,
		size_bytes: n.size_bytes
	};
}
//#endregion
//#region src/review/GeneratedInputPreview.tsx
var kf = 352, Af = 160, jf = {
	ArrowUp: -32,
	ArrowDown: 32,
	Home: -Infinity,
	End: Infinity
};
function Mf({ path: e, content: t }) {
	let [n, r] = y(null), [i, a] = y(kf), o = v(null), s = v(null);
	function c(e) {
		if (e === null || o.current === e) return;
		o.current = e, e.style.height = "auto";
		let t = Math.max(Af, e.scrollHeight), n = Math.min(kf, t);
		e.style.height = `${String(n)}px`, a(t), r(n);
	}
	function l(e) {
		r(Math.min(i, Math.max(Af, e)));
	}
	function u(e) {
		let t = n ?? Math.min(kf, i), r = jf[e.key];
		typeof r == "number" && (e.preventDefault(), l(t + r));
	}
	function d(e) {
		let t = s.current;
		t?.id === e.pointerId && l(t.startHeight + e.clientY - t.startY);
	}
	function f(e) {
		s.current?.id === e.pointerId && (s.current = null, e.currentTarget.hasPointerCapture(e.pointerId) && e.currentTarget.releasePointerCapture(e.pointerId));
	}
	let p = n ?? Math.min(kf, i);
	return /* @__PURE__ */ E(mi, {
		withBorder: !0,
		children: [/* @__PURE__ */ T(cc, {
			block: !0,
			role: "region",
			id: "generated-input-content",
			ref: c,
			h: n ?? void 0,
			"aria-label": `Generated input ${e}`,
			tabIndex: 0,
			children: t
		}, `${e}\0${t}`), /* @__PURE__ */ T("div", {
			className: "code-resizer",
			role: "separator",
			"aria-label": "Resize generated input",
			"aria-controls": "generated-input-content",
			"aria-orientation": "horizontal",
			"aria-valuemin": Af,
			"aria-valuemax": Math.round(i),
			"aria-valuenow": Math.round(p),
			"aria-valuetext": p >= i ? "Full input file visible" : `${String(Math.round(p))} pixels high`,
			tabIndex: 0,
			title: "Drag or use arrow keys to resize the generated input",
			onKeyDown: u,
			onDoubleClick: () => {
				l(i);
			},
			onPointerDown: (e) => {
				e.button === 0 && (s.current = {
					id: e.pointerId,
					startHeight: p,
					startY: e.clientY
				}, e.currentTarget.setPointerCapture(e.pointerId), e.preventDefault());
			},
			onPointerMove: d,
			onPointerUp: f,
			onPointerCancel: f
		})]
	});
}
//#endregion
//#region src/review/GeneratedInputReview.tsx
var Nf = {
	input: 0,
	submission_script: 1,
	pseudopotential: 2,
	manifest: 3,
	readme: 4,
	citations: 4
};
function Pf(e, t) {
	let n = e?.files[t]?.role;
	return n === void 0 && t === "goldilocks.json" ? "manifest" : n;
}
function Ff(e, t) {
	return [...e].sort((e, n) => {
		let r = Nf[Pf(t, e.path) ?? ""] ?? 5, i = Nf[Pf(t, n.path) ?? ""] ?? 5;
		return r === i ? e.path.localeCompare(n.path) : r - i;
	});
}
function If({ archive: e }) {
	let t = zf(e);
	if (e === null) return /* @__PURE__ */ E("div", { children: [/* @__PURE__ */ T(Lu, {
		order: 3,
		children: "Generated inputs"
	}), /* @__PURE__ */ T(Q, {
		c: "dimmed",
		children: "The generated files will appear here automatically once a recommendation is ready."
	})] });
	if (t === null) return /* @__PURE__ */ E("div", { children: [/* @__PURE__ */ T(Lu, {
		order: 3,
		children: "Generated inputs"
	}), /* @__PURE__ */ T(Q, {
		c: "dimmed",
		children: "Reading the generated archive…"
	})] });
	let { manifest: n, files: r } = t;
	return r.length === 0 ? /* @__PURE__ */ E("div", { children: [/* @__PURE__ */ T(Lu, {
		order: 3,
		children: "Generated inputs"
	}), /* @__PURE__ */ T(Q, {
		c: "dimmed",
		children: "No generated input files."
	})] }) : /* @__PURE__ */ E("div", { children: [/* @__PURE__ */ E(Z, {
		component: "header",
		justify: "space-between",
		mb: "xs",
		children: [/* @__PURE__ */ T(Lu, {
			order: 3,
			children: "Generated inputs"
		}), /* @__PURE__ */ E(Q, {
			size: "sm",
			c: "dimmed",
			children: [r.length, " files"]
		})]
	}), /* @__PURE__ */ T(fs, {
		multiple: !0,
		transitionDuration: 0,
		children: Ff(r, n).map((e) => {
			let t = Pf(n, e.path), r = Of(n, e.path);
			return /* @__PURE__ */ E(fs.Item, {
				value: e.path,
				children: [/* @__PURE__ */ T(fs.Control, { children: /* @__PURE__ */ E(Z, {
					justify: "space-between",
					wrap: "nowrap",
					gap: "xs",
					children: [/* @__PURE__ */ T(Q, {
						size: "sm",
						fw: 600,
						style: { overflowWrap: "anywhere" },
						children: e.path
					}), r?.sha256 === void 0 ? null : /* @__PURE__ */ T(cc, { children: r.sha256.slice(0, 10) })]
				}) }), /* @__PURE__ */ T(fs.Panel, { children: t === "pseudopotential" ? /* @__PURE__ */ T(Lf, {
					content: e.content,
					sizeBytes: r?.size_bytes,
					sha256: r?.sha256
				}) : /* @__PURE__ */ T(Mf, {
					path: e.path,
					content: e.content
				}) })]
			}, e.path);
		})
	})] });
}
function Lf({ content: e, sizeBytes: t, sha256: n }) {
	let r = Rf(e);
	return /* @__PURE__ */ T($, { children: /* @__PURE__ */ E($.Tbody, { children: [
		r === null ? null : Object.entries(r).map(([e, t]) => /* @__PURE__ */ E($.Tr, { children: [/* @__PURE__ */ T($.Th, {
			scope: "row",
			children: Uu(e)
		}), /* @__PURE__ */ T($.Td, {
			style: { overflowWrap: "anywhere" },
			children: t
		})] }, e)),
		/* @__PURE__ */ E($.Tr, { children: [/* @__PURE__ */ T($.Th, {
			scope: "row",
			children: "Size"
		}), /* @__PURE__ */ T($.Td, { children: t === void 0 ? "Unknown" : `${(t / 1024).toFixed(1)} KB` })] }),
		/* @__PURE__ */ E($.Tr, { children: [/* @__PURE__ */ T($.Th, {
			scope: "row",
			children: "SHA-256"
		}), /* @__PURE__ */ T($.Td, {
			style: { overflowWrap: "anywhere" },
			children: /* @__PURE__ */ T(cc, { children: n ?? "unlisted" })
		})] })
	] }) });
}
function Rf(e) {
	let t = /<PP_HEADER\b([^>]*)\/?>/i.exec(e)?.[1];
	if (t === void 0) return null;
	let n = {};
	for (let e of t.matchAll(/([\w.]+)\s*=\s*"([^"]*)"/g)) {
		let [, t, r] = e;
		t !== void 0 && r !== void 0 && (n[t] = r.trim());
	}
	return Object.keys(n).length === 0 ? null : n;
}
function zf(e) {
	let [t, n] = y(null);
	return p(() => {
		if (e === null) return;
		let t = !1;
		return Tf(e).then((r) => {
			t || n({
				archive: e,
				contents: r
			});
		}), () => {
			t = !0;
		};
	}, [e]), t?.archive === e ? t.contents : null;
}
//#endregion
//#region src/review/WarningsPanel.tsx
var Bf = {
	error: "Errors",
	warning: "Warnings",
	info: "Notices"
};
function Vf({ warnings: e }) {
	return e.length === 0 ? null : /* @__PURE__ */ T(du, {
		gap: "sm",
		children: [
			"error",
			"warning",
			"info"
		].map((t) => {
			let n = e.filter((e) => e.level === t);
			return n.length === 0 ? null : /* @__PURE__ */ T(hs, {
				color: Gu[t],
				variant: "filled",
				autoContrast: !0,
				title: Bf[t],
				role: "status",
				"aria-live": "polite",
				"aria-atomic": "true",
				children: /* @__PURE__ */ T(du, {
					component: "ul",
					gap: "xs",
					m: 0,
					pl: "md",
					children: n.map((e) => /* @__PURE__ */ T(Q, {
						component: "li",
						size: "sm",
						children: e.message
					}, e.code))
				})
			}, t);
		})
	});
}
//#endregion
//#region src/cards/GeneratedInputsCard.tsx
function Hf() {
	let e = nd(), t = rd(), n = t.reviewed;
	return /* @__PURE__ */ E(mi, {
		component: "section",
		id: "generated-inputs-panel",
		"aria-label": "Generated input files",
		"aria-busy": t.operation === "explain",
		withBorder: !0,
		p: "md",
		className: "workbench-card card-inputs",
		children: [/* @__PURE__ */ E(Z, {
			component: "header",
			className: "card-header",
			mb: "md",
			wrap: "nowrap",
			children: [/* @__PURE__ */ T(Q, {
				className: "card-kicker",
				children: "04"
			}), /* @__PURE__ */ T(Lu, {
				order: 2,
				children: "Goldilocks bundles"
			})]
		}), /* @__PURE__ */ T("div", {
			className: "card-body",
			children: n === null ? /* @__PURE__ */ E(du, {
				align: "center",
				justify: "center",
				mih: 160,
				role: t.operation === "explain" ? "status" : void 0,
				children: [
					t.operation === "explain" && /* @__PURE__ */ T(zi, { size: "sm" }),
					/* @__PURE__ */ T(Q, {
						fw: 600,
						children: t.operation === "explain" ? "Computing recommendation" : "No recommendation yet"
					}),
					t.operation === "explain" ? null : /* @__PURE__ */ T(Q, {
						c: "dimmed",
						size: "sm",
						children: "Load a structure to generate input files."
					})
				]
			}) : /* @__PURE__ */ E(du, {
				gap: "lg",
				children: [
					t.outOfDate && /* @__PURE__ */ T(hs, {
						role: "status",
						"aria-label": "Recommendation notice",
						"aria-live": "polite",
						"aria-atomic": "true",
						children: "Settings changed — recomputing the recommendation automatically."
					}),
					/* @__PURE__ */ E(Z, {
						justify: "space-between",
						children: [/* @__PURE__ */ T(ac, {
							rightSection: /* @__PURE__ */ T(Md, {
								"aria-hidden": "true",
								size: 14
							}),
							loading: t.operation === "download",
							disabled: t.outOfDate || t.operation !== null,
							onClick: () => void e.dispatch({ type: "review.download" }),
							children: "Download (.zip)"
						}), t.lastDownload === null || t.outOfDate ? null : /* @__PURE__ */ E(Q, {
							size: "sm",
							role: "status",
							"aria-label": "Archive status",
							"aria-live": "polite",
							children: [t.lastDownload.filename, " is ready"]
						})]
					}),
					/* @__PURE__ */ T(If, { archive: t.outOfDate ? null : t.lastDownload }),
					/* @__PURE__ */ T(Vf, { warnings: n.warnings })
				]
			})
		})]
	});
}
//#endregion
//#region src/controls/StructureSourceControls.tsx
function Uf({ source: e, inspection: t, inspecting: n, onOpen: r }) {
	let i = v(null), a = v(0), [o, s] = y(!1), [c, l] = y(null);
	async function u(e) {
		let t = ++a.current;
		if (l(null), e.size > 5242880) {
			l("Structure files must be 5 MB or smaller.");
			return;
		}
		if (e.size === 0) {
			l("The selected structure file is empty.");
			return;
		}
		try {
			let n = await e.text();
			if (t !== a.current) return;
			await r({
				structure_content: n,
				structure_name: e.name,
				structure_format: Gf(e.name)
			});
		} catch {
			t === a.current && l("The selected file could not be read.");
		}
	}
	function d(e) {
		i.current?.(), e !== null && u(e);
	}
	function f(e) {
		e.preventDefault(), s(!1);
		let t = e.dataTransfer.files[0];
		t !== void 0 && u(t);
	}
	let p = "CIF or POSCAR · 5 MB maximum file size";
	e !== null && (p = "Inspecting structure"), t !== null && (p = `${String(t.structure.site_count)} sites · parsed`);
	let m = {
		onDragEnter: (e) => {
			e.preventDefault(), s(!0);
		},
		onDragOver: (e) => {
			e.preventDefault();
		},
		onDragLeave: () => {
			s(!1);
		},
		onDrop: f,
		"aria-busy": n,
		bg: o ? "var(--mantine-primary-color-light)" : "var(--mantine-color-body)"
	}, h = /* @__PURE__ */ T(pc, {
		resetRef: i,
		onChange: d,
		disabled: n,
		children: (t) => /* @__PURE__ */ T(ac, {
			...t,
			variant: "subtle",
			type: "button",
			"aria-describedby": "structure-source-help",
			"aria-label": e === null ? "Choose a CIF or POSCAR structure" : "Replace structure file",
			disabled: n,
			children: e === null ? "Browse files" : "Replace file"
		})
	});
	return /* @__PURE__ */ E(w, { children: [
		e === null ? /* @__PURE__ */ E(mi, {
			withBorder: !0,
			p: "xs",
			...m,
			children: [/* @__PURE__ */ E(Z, {
				justify: "center",
				gap: "xs",
				wrap: "wrap",
				children: [
					/* @__PURE__ */ T(Id, {
						"aria-hidden": "true",
						size: 16
					}),
					/* @__PURE__ */ T(Q, {
						fw: 600,
						size: "sm",
						children: "Drop a structure"
					}),
					/* @__PURE__ */ T(Q, {
						size: "sm",
						c: "dimmed",
						children: "or"
					}),
					h
				]
			}), /* @__PURE__ */ T(Q, {
				id: "structure-source-help",
				c: "dimmed",
				size: "xs",
				ta: "center",
				mt: 2,
				children: p
			})]
		}) : /* @__PURE__ */ T(mi, {
			withBorder: !0,
			p: "xs",
			...m,
			children: /* @__PURE__ */ E(Z, {
				justify: "space-between",
				wrap: "nowrap",
				gap: "xs",
				children: [/* @__PURE__ */ E(Z, {
					gap: "xs",
					wrap: "nowrap",
					style: { minWidth: 0 },
					children: [
						n ? /* @__PURE__ */ T(zi, {
							size: "xs",
							"aria-hidden": "true"
						}) : /* @__PURE__ */ T(Id, {
							"aria-hidden": "true",
							size: 16
						}),
						/* @__PURE__ */ T(Q, {
							fw: 600,
							truncate: !0,
							children: e.structure_name
						}),
						/* @__PURE__ */ T(Q, {
							id: "structure-source-help",
							c: "dimmed",
							size: "sm",
							truncate: !0,
							children: p
						})
					]
				}), h]
			})
		}),
		c === null ? null : /* @__PURE__ */ T(Q, {
			c: "red",
			size: "sm",
			role: "alert",
			children: c
		}),
		t === null ? null : /* @__PURE__ */ T(Wf, { inspection: t })
	] });
}
function Wf({ inspection: e }) {
	let t = e.structure, n = [...new Set(t.sites.flatMap((e) => e.species.map((e) => e.symbol)))], r = t.periodicity.every(Boolean) ? "3D" : "Partial";
	return /* @__PURE__ */ E(Q, {
		size: "sm",
		c: "dimmed",
		mt: "xs",
		truncate: !0,
		"aria-label": "Inspected structure summary",
		children: [
			t.formula,
			" · ",
			n.join(" "),
			" ·",
			" ",
			t.lattice.volume_angstrom3.toFixed(1),
			" Å³ · ",
			r
		]
	});
}
function Gf(e) {
	return e.toLowerCase().endsWith(".cif") ? "cif" : "poscar";
}
//#endregion
//#region src/viewer/StructureFallback.tsx
function Kf({ structure: e, onRetry: t, containerRef: n, hidden: r = !1 }) {
	let i = e.site_count === 1 ? "1 atomic site" : `${String(e.site_count)} atomic sites`;
	return /* @__PURE__ */ E(hs, {
		ref: n,
		title: "3D structure preview unavailable",
		pos: "absolute",
		top: "25%",
		left: "10%",
		right: "10%",
		style: { zIndex: 5 },
		hidden: r,
		role: "status",
		"aria-live": "polite",
		children: [
			/* @__PURE__ */ E(Q, { children: [
				e.reduced_formula,
				" · ",
				i
			] }),
			/* @__PURE__ */ T(Q, {
				size: "sm",
				mt: "sm",
				children: "The parsed structure and recommendation remain available without the interactive preview."
			}),
			/* @__PURE__ */ T(ac, {
				mt: "md",
				variant: "light",
				onClick: t,
				children: "Retry 3D preview"
			})
		]
	});
}
//#endregion
//#region src/viewer/structureViewer.ts
var qf, Jf, Yf = async (t, n) => {
	n.throwIfAborted();
	let { createViewer: r } = await import("./3Dmol-BIKt0Ru5.js").then((t) => /* @__PURE__ */ e(t.default, 1));
	if (n.throwIfAborted(), qf === void 0) {
		let e = document.createElement("div");
		e.style.cssText = "position:relative;width:100%;height:100%", t.append(e);
		try {
			qf = {
				viewer: r(e, { antialias: !0 }),
				surface: e
			};
		} catch (t) {
			throw e.remove(), t;
		}
	}
	let { viewer: i, surface: a } = qf, o = Symbol();
	return Jf = o, t.append(a), i.resize(), {
		show(e) {
			if (Jf !== o) return;
			i.clear();
			let t = i.addModel(e, "cif");
			i.setStyle({}, {
				sphere: {
					scale: .3,
					colorscheme: "Jmol"
				},
				stick: {
					radius: .12,
					colorscheme: "Jmol"
				}
			});
			let n = getComputedStyle(document.documentElement);
			i.addUnitCell(t, { box: {
				color: n.getPropertyValue("--mantine-color-gray-6").trim(),
				linewidth: 1.5
			} }), i.zoomTo(), i.render();
		},
		refreshTheme() {
			if (Jf !== o) return;
			let e = getComputedStyle(document.documentElement).getPropertyValue("--mantine-color-body").trim();
			i.setBackgroundColor(e, 1);
		},
		dispose() {
			Jf === o && (Jf = void 0, i.clear(), a.remove());
		}
	};
}, Xf = [
	"a",
	"b",
	"c"
];
function Zf({ inspection: e, createViewer: t = Yf }) {
	let n = v(null), r = v(null), i = v(e.canonical_cif), a = v(null), [o, s] = y(0), c = zt("light"), [l, u] = y(!1);
	p(() => {
		let e = n.current;
		if (e === null) return;
		let o = new AbortController();
		return (async () => {
			try {
				let n = await t(e, o.signal);
				if (o.signal.aborted) {
					n.dispose();
					return;
				}
				r.current = n, n.refreshTheme(), n.show(i.current), a.current !== null && (a.current.hidden = !0);
			} catch {
				!o.signal.aborted && a.current !== null && (a.current.hidden = !1);
			}
		})(), () => {
			o.abort(), r.current?.dispose(), r.current = null;
		};
	}, [t, o]), p(() => {
		if (i.current = e.canonical_cif, r.current !== null) try {
			r.current.show(e.canonical_cif), a.current !== null && (a.current.hidden = !0);
		} catch {
			a.current !== null && (a.current.hidden = !1);
		}
	}, [e.canonical_cif]), p(() => {
		r.current?.refreshTheme();
	}, [c]);
	let d = e.structure.lattice, f = e.structure.sites.some((e) => e.species.length !== 1 || e.species.some((e) => e.occupancy !== 1));
	return /* @__PURE__ */ E(X, {
		component: "section",
		"aria-label": "Crystal structure viewer",
		style: {
			display: "flex",
			flexDirection: "column"
		},
		w: "100%",
		h: "100%",
		children: [
			/* @__PURE__ */ E(X, {
				pos: "relative",
				style: {
					flex: 1,
					minHeight: 0
				},
				children: [
					/* @__PURE__ */ T(X, {
						pos: "absolute",
						inset: 0,
						ref: n
					}),
					/* @__PURE__ */ T(Kf, {
						structure: e.structure,
						containerRef: a,
						hidden: !0,
						onRetry: () => {
							s((e) => e + 1);
						}
					}),
					/* @__PURE__ */ E(Z, {
						pos: "absolute",
						top: 10,
						left: 10,
						align: "baseline",
						gap: 6,
						children: [/* @__PURE__ */ T(Lu, {
							order: 5,
							children: e.structure.reduced_formula
						}), /* @__PURE__ */ E(Q, {
							size: "xs",
							c: "dimmed",
							children: [e.structure.site_count, " atomic sites"]
						})]
					})
				]
			}),
			/* @__PURE__ */ E(du, {
				gap: 6,
				mt: 6,
				children: [f ? /* @__PURE__ */ T(Q, {
					size: "xs",
					c: "dimmed",
					role: "note",
					children: "Mixed or partial occupancy: this 3D preview is an approximation. Inspect the canonical site details for the exact species and occupancies."
				}) : null, /* @__PURE__ */ T(ac, {
					size: "compact-sm",
					fullWidth: !0,
					styles: { label: { whiteSpace: "normal" } },
					onClick: () => {
						u(!0);
					},
					children: "Inspect lattice, sites and occupancies"
				})]
			}),
			/* @__PURE__ */ T(Lc, {
				opened: l,
				onClose: () => {
					u(!1);
				},
				title: "Lattice, sites and occupancies",
				size: "lg",
				closeButtonProps: { "aria-label": "Close canonical site details" },
				children: l ? /* @__PURE__ */ E(du, { children: [
					/* @__PURE__ */ T(Q, {
						size: "sm",
						children: "Canonical inspection data. Occupancies are fractions of each site; coordinates are fractional lattice coordinates."
					}),
					/* @__PURE__ */ E(mi, {
						component: "section",
						"aria-label": "Lattice parameters",
						p: "sm",
						withBorder: !0,
						children: [/* @__PURE__ */ T(Lu, {
							order: 4,
							mb: "xs",
							children: "Lattice parameters"
						}), /* @__PURE__ */ E(su, {
							component: "dl",
							cols: 4,
							spacing: "md",
							m: 0,
							children: [d.lengths_angstrom.map((e, t) => /* @__PURE__ */ E("div", { children: [/* @__PURE__ */ T("dt", { children: Xf[t] }), /* @__PURE__ */ E("dd", { children: [e.toFixed(3), " Å"] })] }, t)), /* @__PURE__ */ E("div", { children: [/* @__PURE__ */ T("dt", { children: "V" }), /* @__PURE__ */ E("dd", { children: [d.volume_angstrom3.toFixed(2), " Å³"] })] })]
						})]
					}),
					e.structure.sites.map((e, t) => /* @__PURE__ */ E(mi, {
						component: "section",
						"aria-label": `Site ${String(t + 1)}`,
						p: "sm",
						withBorder: !0,
						children: [
							/* @__PURE__ */ E(Lu, {
								order: 3,
								children: ["Site ", t + 1]
							}),
							/* @__PURE__ */ E(Q, {
								size: "sm",
								style: { overflowWrap: "anywhere" },
								children: [
									"Fractional coordinates:",
									" ",
									e.fractional_coordinates.join(", ")
								]
							}),
							/* @__PURE__ */ E($, {
								layout: "fixed",
								style: { overflowWrap: "anywhere" },
								children: [/* @__PURE__ */ T($.Thead, { children: /* @__PURE__ */ E($.Tr, { children: [
									/* @__PURE__ */ T($.Th, {
										scope: "col",
										children: "Species"
									}),
									/* @__PURE__ */ T($.Th, {
										scope: "col",
										children: "Element"
									}),
									/* @__PURE__ */ T($.Th, {
										scope: "col",
										children: "Occupancy"
									})
								] }) }), /* @__PURE__ */ T($.Tbody, { children: e.species.map((e, t) => /* @__PURE__ */ E($.Tr, { children: [
									/* @__PURE__ */ T($.Th, {
										scope: "row",
										children: e.label
									}),
									/* @__PURE__ */ T($.Td, { children: e.symbol }),
									/* @__PURE__ */ T($.Td, { children: e.occupancy })
								] }, t)) })]
							})
						]
					}, t))
				] }) : null
			})
		]
	});
}
//#endregion
//#region src/cards/StructureCard.tsx
function Qf() {
	let e = nd(), t = rd();
	return /* @__PURE__ */ E(mi, {
		component: "section",
		id: "structure-panel",
		"aria-label": "Structure workspace",
		withBorder: !0,
		p: "md",
		className: "workbench-card card-structure",
		children: [/* @__PURE__ */ E(Z, {
			component: "header",
			className: "card-header",
			mb: "md",
			wrap: "nowrap",
			children: [/* @__PURE__ */ T(Q, {
				className: "card-kicker",
				children: "01"
			}), /* @__PURE__ */ T(Lu, {
				order: 2,
				children: "Structure"
			})]
		}), /* @__PURE__ */ E("div", {
			className: "card-body",
			children: [/* @__PURE__ */ T(Uf, {
				source: t.structureInput,
				inspection: t.inspection,
				inspecting: t.operation === "inspect",
				onOpen: (t) => e.dispatch({
					type: "source.open",
					input: t
				})
			}), /* @__PURE__ */ T("div", {
				className: "structure-stage",
				children: t.inspection === null ? /* @__PURE__ */ T($f, {
					loading: t.capabilities === null || t.operation === "inspect",
					label: t.capabilities === null ? "Loading Workbench" : void 0
				}) : /* @__PURE__ */ T(Zf, { inspection: t.inspection })
			})]
		})]
	});
}
function $f({ loading: e, label: t = e ? "Reading structure" : "No structure selected" }) {
	return /* @__PURE__ */ E(du, {
		align: "center",
		justify: "center",
		h: "100%",
		p: "xl",
		gap: "xl",
		role: e ? "status" : void 0,
		children: [e ? /* @__PURE__ */ T(zi, {
			size: "xl",
			"aria-hidden": "true"
		}) : /* @__PURE__ */ T(jd, {
			size: 96,
			strokeWidth: 1,
			"aria-hidden": "true"
		}), /* @__PURE__ */ T(Lu, {
			order: 3,
			ta: "center",
			children: t
		})]
	});
}
//#endregion
//#region src/layout/AppHeader.tsx
function ep({ theme: e, onToggleTheme: t }) {
	return /* @__PURE__ */ E(Z, {
		component: "header",
		justify: "space-between",
		wrap: "nowrap",
		px: "md",
		className: "app-header",
		children: [/* @__PURE__ */ E(Z, {
			gap: "xs",
			wrap: "nowrap",
			children: [/* @__PURE__ */ T("img", {
				src: "/brand/goldilocks-logo.png",
				alt: "",
				width: 40,
				height: 40
			}), /* @__PURE__ */ E(du, {
				gap: 0,
				children: [/* @__PURE__ */ T(Q, {
					style: {
						fontSize: "var(--mantine-h2-font-size)",
						fontWeight: "var(--mantine-h2-font-weight)",
						color: "#ffffff",
						lineHeight: 1.1
					},
					children: "Goldilocks"
				}), /* @__PURE__ */ T(Q, {
					style: {
						fontSize: "0.75rem",
						fontStyle: "italic",
						color: "rgba(255, 255, 255, 0.7)",
						lineHeight: 1.1
					},
					children: "Towards Greener Computation"
				})]
			})]
		}), /* @__PURE__ */ T(qi, {
			variant: "subtle",
			className: "app-header-toggle",
			style: { color: "rgba(255, 255, 255, 0.85)" },
			"aria-label": e === "light" ? "Switch to dark mode" : "Switch to light mode",
			title: e === "light" ? "Dark mode" : "Light mode",
			onClick: t,
			children: T(e === "light" ? Fd : Nd, {
				"aria-hidden": "true",
				size: 17
			})
		})]
	});
}
//#endregion
//#region src/status/FailureBanner.tsx
function tp({ failure: e, retryAvailable: t, dismissAvailable: n, onRetry: r, onDismiss: i }) {
	return /* @__PURE__ */ T(hs, {
		color: "red",
		title: np[e.kind] ?? "Calculation failed",
		withCloseButton: n,
		closeButtonLabel: "Dismiss error",
		styles: { closeButton: {
			width: 44,
			height: 44
		} },
		onClose: i,
		role: "alert",
		children: /* @__PURE__ */ E(Z, {
			justify: "space-between",
			children: [/* @__PURE__ */ T(Q, {
				flex: 1,
				children: e.message
			}), t ? /* @__PURE__ */ T(ac, {
				color: "red",
				variant: "light",
				onClick: r,
				leftSection: /* @__PURE__ */ T(Pd, {
					"aria-hidden": "true",
					size: 15
				}),
				children: "Retry"
			}) : null]
		})
	});
}
var np = {
	invalid_request: "Check the request",
	invalid_setting: "Check your overrides",
	advice_incomplete: "Recommendation incomplete",
	invalid_hpc_profile: "Check the HPC profile",
	invalid_structure: "Check the structure",
	assets_unavailable: "Runtime assets unavailable",
	asset_not_installed: "Runtime assets unavailable",
	asset_corrupt: "Runtime assets unavailable",
	generation_error: "Could not generate input files",
	submission_error: "Could not generate the submission script",
	network_error: "Cannot reach Core",
	invalid_response: "Unexpected server response",
	http_error: "Request failed",
	incompatible_vocabulary: "Frontend/backend version mismatch"
};
//#endregion
//#region src/status/OperationStatus.tsx
function rp({ operation: e, hasFailure: t }) {
	return /* @__PURE__ */ T(di, {
		role: "status",
		"aria-label": "Workbench status",
		"aria-live": "polite",
		"aria-atomic": "true",
		children: ap(e, t)
	});
}
var ip = {
	capabilities: "Loading capabilities",
	inspect: "Inspecting structure",
	explain: "Computing recommendation",
	download: "Generating input files"
};
function ap(e, t) {
	return t ? "Needs attention" : e === null ? "Ready" : ip[e];
}
//#endregion
//#region src/theme.ts
var op = tt({ key: "goldilocks-theme" }), sp = fn({
	primaryColor: "blue",
	primaryShade: 6,
	autoContrast: !0,
	colors: { blue: [
		"#f0f7ff",
		"#dbeafe",
		"#bfdbfe",
		"#93c5fd",
		"#60a5fa",
		"#3b82f6",
		"#0071e3",
		"#005bb8",
		"#004a94",
		"#003970"
	] },
	fontFamily: "-apple-system, BlinkMacSystemFont, Inter, \"Avenir Next\", \"Segoe UI\", ui-sans-serif, system-ui, sans-serif",
	fontFamilyMonospace: "\"IBM Plex Mono\", \"SFMono-Regular\", Consolas, monospace",
	defaultRadius: "lg",
	shadows: {
		xs: "0 1px 2px rgba(0, 0, 0, 0.04)",
		sm: "0 2px 6px rgba(0, 0, 0, 0.05)",
		md: "0 6px 16px rgba(0, 0, 0, 0.07)",
		lg: "0 16px 32px -12px rgba(0, 0, 0, 0.16)",
		xl: "0 24px 48px -16px rgba(0, 0, 0, 0.2)"
	},
	respectReducedMotion: !0,
	components: {
		Button: ac.extend({
			defaultProps: { radius: "xl" },
			styles: { root: { minHeight: 44 } }
		}),
		ActionIcon: qi.extend({ defaultProps: {
			size: 44,
			radius: "xl"
		} }),
		Input: Zo.extend({ styles: { input: { minHeight: 44 } } }),
		NativeSelect: Vc.extend({ defaultProps: { size: "md" } }),
		NumberInput: Ql.extend({ defaultProps: {
			size: "md",
			role: "spinbutton",
			clampBehavior: "none"
		} }),
		Checkbox: qs.extend({
			defaultProps: { size: "xs" },
			styles: { body: {
				minHeight: 44,
				alignItems: "center"
			} }
		}),
		Accordion: fs.extend({ styles: { control: {
			paddingTop: "var(--mantine-spacing-lg)",
			paddingBottom: "var(--mantine-spacing-lg)"
		} } })
	}
}), cp = 400, lp = 150;
function up(e, t) {
	let { draft: n, structureInput: r, operation: i, outOfDate: a, reviewed: o, lastDownload: s, failureOperation: c } = t;
	p(() => {
		if (n === null || r === null || i !== null || c === "explain" || o !== null && !a) return;
		let t = setTimeout(() => {
			e.dispatch({ type: "review.compute" });
		}, cp);
		return () => {
			clearTimeout(t);
		};
	}, [
		e,
		n,
		r,
		i,
		a,
		o,
		c
	]), p(() => {
		if (i !== null || c === "download" || o === null || a || s !== null) return;
		let t = setTimeout(() => {
			e.dispatch({ type: "review.refreshArchive" });
		}, lp);
		return () => {
			clearTimeout(t);
		};
	}, [
		e,
		i,
		a,
		o,
		s,
		c
	]);
}
//#endregion
//#region src/App.tsx
function dp() {
	return /* @__PURE__ */ T(dn, {
		theme: sp,
		colorSchemeManager: op,
		defaultColorScheme: "light",
		children: /* @__PURE__ */ T(fp, {})
	});
}
function fp() {
	let e = zt("light"), { toggleColorScheme: t } = It();
	return p(() => {
		document.querySelector("meta[name=\"theme-color\"]")?.setAttribute("content", e === "light" ? "#ffffff" : "#242424");
	}, [e]), /* @__PURE__ */ E(w, { children: [/* @__PURE__ */ T(ep, {
		theme: e,
		onToggleTheme: t
	}), /* @__PURE__ */ T(pp, {})] });
}
function pp() {
	let e = nd(), t = rd();
	return up(e, t), /* @__PURE__ */ E(w, { children: [
		/* @__PURE__ */ T(rp, {
			operation: t.operation,
			hasFailure: t.failure !== null
		}),
		t.failure === null ? null : /* @__PURE__ */ T(tp, {
			failure: t.failure,
			retryAvailable: t.failure.retryable || t.failureOperation === "capabilities",
			dismissAvailable: t.capabilities !== null,
			onRetry: () => {
				e.dispatch({ type: "failure.retry" });
			},
			onDismiss: () => {
				e.dispatch({ type: "failure.dismiss" });
			}
		}),
		/* @__PURE__ */ E("main", {
			className: "workbench-grid",
			"aria-labelledby": "workbench-title",
			children: [
				/* @__PURE__ */ T(di, { children: /* @__PURE__ */ T("h1", {
					id: "workbench-title",
					children: "Goldilocks SCF setup"
				}) }),
				/* @__PURE__ */ T(Qf, {}),
				/* @__PURE__ */ T(od, {}),
				/* @__PURE__ */ T(bd, {}),
				/* @__PURE__ */ T(Hf, {})
			]
		})
	] });
}
//#endregion
//#region src/workspace/WorkspaceProvider.tsx
function mp({ workspace: e, children: t }) {
	return p(() => {
		e.dispatch({ type: "workspace.start" });
	}, [e]), /* @__PURE__ */ T(td.Provider, {
		value: e,
		children: t
	});
}
//#endregion
//#region node_modules/zustand/esm/vanilla.mjs
var hp = (e) => {
	let t, n = /* @__PURE__ */ new Set(), r = (e, r) => {
		let i = typeof e == "function" ? e(t) : e;
		if (!Object.is(i, t)) {
			let e = t;
			t = r ?? (typeof i != "object" || !i) ? i : Object.assign({}, t, i), n.forEach((n) => n(t, e));
		}
	}, i = () => t, a = {
		setState: r,
		getState: i,
		getInitialState: () => o,
		subscribe: (e) => (n.add(e), () => n.delete(e))
	}, o = t = e(r, i, a);
	return a;
}, gp = ((e) => e ? hp(e) : hp), _p = "1", vp = class extends Error {
	kind;
	retryable;
	details;
	status;
	rawResponse;
	constructor(e, t, n, r = {}, i = null, a) {
		super(t), this.kind = e, this.retryable = n, this.details = r, this.status = i, this.rawResponse = a, this.name = "CoreFailure";
	}
}, yp = class {
	fetcher;
	baseUrl;
	constructor(e = "", t = globalThis.fetch.bind(globalThis)) {
		this.fetcher = t, this.baseUrl = e.replace(/\/$/, "");
	}
	async capabilities() {
		let e = await bp(await this.request("/capabilities", {
			headers: { Accept: "application/json" },
			method: "GET"
		}));
		if (e.vocabulary_version !== _p) throw new vp("incompatible_vocabulary", `Goldilocks Core reports vocabulary_version ${e.vocabulary_version}, but this Workbench build expects ${_p}. The frontend and backend were built against different contracts -- regenerate the Workbench's API types against this server.`, !1, { serverVocabularyVersion: e.vocabulary_version });
		return e;
	}
	async inspectStructure(e) {
		return xp(await this.request("/inspect", {
			body: JSON.stringify(e),
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json"
			},
			method: "POST"
		}));
	}
	async explain(e) {
		return bp(await this.request("/explain", {
			body: JSON.stringify(e),
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json"
			},
			method: "POST"
		}));
	}
	async run(e) {
		return bp(await this.request("/run", {
			body: JSON.stringify({
				...e,
				respond_with: "json"
			}),
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json"
			},
			method: "POST"
		}));
	}
	async runArchive(e) {
		return Ep(await this.request("/run", {
			body: JSON.stringify({
				...e,
				respond_with: "archive"
			}),
			headers: {
				Accept: "application/zip",
				"Content-Type": "application/json"
			},
			method: "POST"
		}), e);
	}
	async request(e, t) {
		let n;
		try {
			n = await this.fetcher(`${this.baseUrl}${e}`, t);
		} catch (e) {
			throw new vp("network_error", e instanceof Error ? `Cannot reach Goldilocks Core: ${e.message}` : "Cannot reach Goldilocks Core.", !0);
		}
		return await Cp(n), n;
	}
};
async function bp(e) {
	if (!(e.headers.get("content-type") ?? "").toLowerCase().startsWith("application/json")) {
		let t = await wp(e);
		throw Op(e.status, "returned an invalid JSON response", t);
	}
	try {
		return await e.json();
	} catch {
		throw Op(e.status, "returned unreadable JSON");
	}
}
async function xp(e) {
	let t = await bp(e);
	return Sp(t, e.status), t;
}
function Sp(e, t) {
	if (typeof e != "object" || !e || !("schema_version" in e) || e.schema_version !== 1) throw Op(t, "returned an incompatible schema version", e);
}
async function Cp(e) {
	if (e.ok) return;
	let t = await wp(e);
	if (Tp(t)) {
		let { error: n } = t;
		throw new vp(n.kind, n.message, e.status >= 500, n.details ?? {}, e.status, t);
	}
	throw new vp("http_error", `The Goldilocks Core server rejected the request (${String(e.status)}).`, e.status >= 500, { status: e.status }, e.status, t);
}
async function wp(e) {
	let t = await e.text();
	try {
		return JSON.parse(t);
	} catch {
		return t;
	}
}
function Tp(e) {
	if (typeof e != "object" || !e || !("error" in e)) return !1;
	let t = e.error;
	return typeof t == "object" && !!t && "kind" in t && typeof t.kind == "string" && "message" in t && typeof t.message == "string";
}
async function Ep(e, t) {
	if (!(e.headers.get("content-type") ?? "").toLowerCase().startsWith("application/zip")) throw Op(e.status, "returned an invalid archive response");
	let n;
	try {
		n = await e.blob();
	} catch {
		throw Op(e.status, "returned unreadable archive data");
	}
	return {
		blob: n,
		filename: `${Dp(t)}.zip`
	};
}
function Dp(e) {
	let t = e.structure_name.replace(/[^a-zA-Z0-9._-]+/g, "_"), n = e.task;
	return t.length > 0 ? `${t}-${n}` : `goldilocks-${n}`;
}
function Op(e, t, n) {
	return new vp("invalid_response", `Goldilocks Core ${t}.`, !1, {}, e, n);
}
//#endregion
//#region src/workspace/workspace.ts
var kp = {
	capabilities: null,
	structureInput: null,
	attemptedStructureInput: null,
	inspection: null,
	draft: null,
	reviewed: null,
	outOfDate: !1,
	lastDownload: null,
	operation: null,
	failure: null,
	failureOperation: null
};
function Ap(e) {
	return {
		code: e.codes[0]?.id ?? "quantum_espresso",
		task: e.tasks[0]?.id ?? "scf_single_point",
		hpc: null,
		overrides: {},
		fetchMissing: !1
	};
}
function jp(e, t) {
	return {
		structure_content: e.structure_content,
		structure_name: e.structure_name,
		...e.structure_format ? { structure_format: e.structure_format } : {},
		code: t.code,
		task: t.task,
		hpc: t.hpc,
		overrides: t.overrides,
		fetch_missing: t.fetchMissing
	};
}
function Mp(e, t) {
	let n = {
		...e,
		...t
	};
	return Object.fromEntries(Object.entries(n).filter(([, e]) => e !== void 0));
}
function Np(e, t = Pp) {
	let n = gp(() => kp), r = null, i = null, a = 0;
	function o(e) {
		let t = { operation: e };
		return r = t, n.setState({
			operation: e,
			failure: null,
			failureOperation: null
		}), t;
	}
	function s(e, t = {}) {
		r === e && (r = null, n.setState({
			...t,
			operation: null
		}));
	}
	function c(e, t) {
		if (r === e) {
			if (!(t instanceof vp)) throw s(e), t;
			s(e, {
				failure: t,
				failureOperation: e.operation
			});
		}
	}
	function l() {
		if (n.getState().capabilities !== null) return Promise.resolve();
		if (i !== null) return i.promise;
		let t = o("capabilities"), r = e.capabilities().then((e) => {
			i?.owner === t && (i = null), s(t, {
				capabilities: e,
				draft: Ap(e)
			});
		}, (e) => {
			i?.owner === t && (i = null), c(t, e);
		});
		return i = {
			owner: t,
			promise: r
		}, r;
	}
	async function u(t) {
		let i = n.getState().capabilities;
		if (i === null) return;
		let l = o("inspect");
		n.setState({ attemptedStructureInput: t });
		try {
			let n = await e.inspectStructure(t);
			if (r !== l) return;
			a = 0, s(l, {
				structureInput: t,
				attemptedStructureInput: null,
				inspection: n,
				draft: Ap(i),
				reviewed: null,
				outOfDate: !1,
				lastDownload: null
			});
		} catch (e) {
			c(l, e);
		}
	}
	function d(e) {
		let t = n.getState(), r = t.draft;
		if (r === null || t.operation === "inspect") return;
		a += 1;
		let i = {
			...r,
			..."code" in e ? { code: e.code } : {},
			..."task" in e ? { task: e.task } : {},
			..."hpc" in e ? { hpc: e.hpc } : {},
			overrides: e.overrides === void 0 ? r.overrides : Mp(r.overrides, e.overrides)
		};
		n.setState({
			draft: i,
			outOfDate: t.reviewed !== null,
			failure: null,
			failureOperation: null
		});
	}
	async function f() {
		let t = n.getState();
		if (t.structureInput === null || t.draft === null || t.operation !== null) return;
		let r = a, i = jp(t.structureInput, t.draft), l = o("explain");
		try {
			s(l, {
				reviewed: await e.explain(i),
				outOfDate: r !== a,
				lastDownload: null
			});
		} catch (e) {
			c(l, e);
		}
	}
	async function p() {
		let t = n.getState();
		if (t.structureInput === null || t.draft === null || t.reviewed === null || t.outOfDate || t.operation !== null) return null;
		let r = a, i = jp(t.structureInput, t.draft), l = o("download");
		try {
			let t = await e.runArchive(i), n = r !== a;
			return s(l, {
				lastDownload: t,
				outOfDate: n
			}), n ? null : t;
		} catch (e) {
			return c(l, e), null;
		}
	}
	async function m() {
		let e = n.getState();
		if (e.outOfDate) return;
		let r = e.lastDownload ?? await p();
		r !== null && t(r);
	}
	async function h() {
		let { failureOperation: e, attemptedStructureInput: t } = n.getState();
		switch (e) {
			case "capabilities": return l();
			case "inspect":
				t !== null && await u(t);
				return;
			case "explain": return f();
			case "download": return m();
			case null: return;
		}
	}
	async function g() {
		let e = n.getState().capabilities, t = i !== null && r === i.owner ? i : null;
		a = 0, t === null && (r = null, i = null), n.setState({
			...kp,
			capabilities: e,
			operation: t?.owner.operation ?? null
		}, !0), e === null && t === null && await l();
	}
	async function _(e) {
		switch (e.type) {
			case "workspace.start":
				await l();
				return;
			case "source.open":
				await u(e.input);
				return;
			case "draft.patch":
				d(e);
				return;
			case "review.compute":
				await f();
				return;
			case "review.refreshArchive":
				await p();
				return;
			case "review.download":
				await m();
				return;
			case "failure.retry": return h();
			case "failure.dismiss":
				if (n.getState().capabilities === null) return;
				n.setState({
					attemptedStructureInput: null,
					failure: null,
					failureOperation: null
				});
				return;
			case "workspace.reset": return g();
		}
	}
	return {
		getSnapshot: n.getState,
		subscribe(e) {
			return n.subscribe(e);
		},
		dispatch: _
	};
}
function Pp(e) {
	let t = URL.createObjectURL(e.blob), n = document.createElement("a");
	n.href = t, n.download = e.filename, n.hidden = !0, document.body.append(n), n.click(), n.remove(), URL.revokeObjectURL(t);
}
//#endregion
export { dp as App, yp as HttpCoreClient, dn as MantineProvider, pp as WorkbenchContent, mp as WorkspaceProvider, op as colorSchemeManager, Np as createWorkspace, nd as useWorkspace, rd as useWorkspaceSnapshot, sp as workbenchTheme };
