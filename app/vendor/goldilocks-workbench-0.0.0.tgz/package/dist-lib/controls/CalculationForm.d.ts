export declare function CalculationForm(): import("react").JSX.Element | null;
