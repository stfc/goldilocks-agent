export interface OverrideFieldMeta {
    readonly key: string;
    readonly type: string;
    readonly enum?: readonly string[] | undefined;
    readonly unit?: string | null;
    readonly default?: unknown;
    readonly description: string;
}
export declare function fieldLabel(meta: OverrideFieldMeta): string;
/** `unknown`-safe stringification -- most override values are
 * primitives, but array/object-shaped ones (`k_grid`, `u_by_element`)
 * would otherwise stringify to the useless `"[object Object]"`. */
export declare function stringifyValue(value: unknown): string;
export declare function automaticPlaceholder(meta: OverrideFieldMeta): string;
