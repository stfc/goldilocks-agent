import { OverrideFieldMeta } from './overrideFieldMeta';
/** One human/heuristic override control, generic over the field's
 * declared `type` -- shared by the advisors accordion (settings) and
 * the analysis section (facts), since both are the same
 * human > ml > llm > heuristic override shape underneath. */
export declare function OverrideControl({ meta, value, disabled, onChange, }: {
    readonly meta: OverrideFieldMeta;
    readonly value: unknown;
    readonly disabled: boolean;
    readonly onChange: (value: unknown) => void;
}): import("react").JSX.Element;
