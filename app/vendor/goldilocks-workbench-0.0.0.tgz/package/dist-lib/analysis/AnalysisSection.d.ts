/** goldilocks-core's own analysis tier only ever needs the structure --
 * `capabilities.facts` (is_metal/is_magnetic/needs_soc/needs_correlation,
 * each overridable) plus any other resolved record that isn't tied to a
 * settings group (composition/geometry/symmetry/... -- see
 * recordGroups.ts for exactly how that split is derived). Advisor
 * records live in the Goldilocks advisors card instead, next to the
 * override control they belong to. Rendered inside AnalysisCard, which
 * supplies the "Goldilocks analysis" heading -- this component is just
 * the body. */
export declare function AnalysisSection(): import("react").JSX.Element | null;
