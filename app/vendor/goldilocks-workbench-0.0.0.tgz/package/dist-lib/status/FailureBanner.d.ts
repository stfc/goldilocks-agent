import { CoreFailure } from '../api/coreClient';
export declare function FailureBanner({ failure, retryAvailable, dismissAvailable, onRetry, onDismiss, }: {
    readonly failure: CoreFailure;
    readonly retryAvailable: boolean;
    readonly dismissAvailable: boolean;
    readonly onRetry: () => void;
    readonly onDismiss: () => void;
}): import("react").JSX.Element;
