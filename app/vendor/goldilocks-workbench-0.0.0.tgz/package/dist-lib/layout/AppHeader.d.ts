import { Theme } from '../theme';
export declare function AppHeader({ theme, onToggleTheme, }: {
    readonly theme: Theme;
    readonly onToggleTheme: () => void;
}): import("react").JSX.Element;
