export declare function App(): import("react").JSX.Element;
export declare function WorkbenchContent(): import("react").JSX.Element;
